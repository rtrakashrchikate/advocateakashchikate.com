# Installation Guide - Claude Skills Library

Complete installation guide for all 205+ production-ready skills across multiple AI agents and platforms.

## Table of Contents

- [Quick Start](#quick-start)
- [Claude Code Native Marketplace](#claude-code-native-marketplace-new)
- [Universal Installer](#universal-installer)
- [OpenAI Codex Installation](#openai-codex-installation)
- [Gemini CLI Installation](#gemini-cli-installation)
- [Mistral Vibe Installation](#mistral-vibe-installation)
- [OpenClaw Installation](#openclaw-installation)
- [Per-Skill Installation](#per-skill-installation)
- [Multi-Agent Setup](#multi-agent-setup)
- [Manual Installation](#manual-installation)
- [Verification & Testing](#verification--testing)
- [Windows Notes](#windows-notes)
- [Troubleshooting](#troubleshooting)
- [Uninstallation](#uninstallation)

---

## Quick Start

**Choose your agent:**

### For Claude Code Users (Recommended)

```bash
# In Claude Code, run:
/plugin marketplace add alirezarezvani/claude-skills
/plugin install marketing-skills@claude-code-skills
```

Native integration with automatic updates and version management.

### For OpenAI Codex Users

```bash
# Option 1: Universal installer
npx agent-skills-cli add alirezarezvani/claude-skills --agent codex

# Option 2: Direct installation script
git clone https://github.com/alirezarezvani/claude-skills.git
cd claude-skills
./scripts/codex-install.sh
```

### For Gemini CLI Users

```bash
# Setup script for Gemini CLI
git clone https://github.com/alirezarezvani/claude-skills.git
cd claude-skills
./scripts/gemini-install.sh
```

Skills install to `.gemini/skills/` and are activated via `activate_skill(name="skill-name")`.

### For Mistral Vibe Users

```bash
# Setup script for Mistral Vibe
git clone https://github.com/alirezarezvani/claude-skills.git
cd claude-skills
./scripts/vibe-install.sh
```

Skills install to `~/.vibe/skills/claude-skills/` (symlinked) and are discovered automatically by Vibe via the standard `SKILL.md` + YAML frontmatter contract. See [Mistral Vibe Installation](#mistral-vibe-installation) for details.

Skills install to `~/.codex/skills/`. See [OpenAI Codex Installation](#openai-codex-installation) for detailed instructions.

### For OpenClaw Users

```bash
# Install from ClawHub
clawhub install alirezarezvani/claude-skills

# Or manual installation
git clone https://github.com/alirezarezvani/claude-skills.git
cp -r claude-skills/engineering-team ~/.openclaw/skills/
```

Skills load via YAML frontmatter triggers. See [OpenClaw Installation](#openclaw-installation) for details.

### For All Other Agents (Cursor, VS Code, Goose, etc.)

```bash
npx agent-skills-cli add alirezarezvani/claude-skills
```

This single command installs all skills to all supported agents automatically.

**What this does:**
- ✅ Detects all 205+ skills automatically
- ✅ Installs to Claude, Cursor, Copilot, Windsurf, Cline, and 37+ other AI agents
- ✅ Works across all skill formats

Learn more: https://www.agentskills.in

---

## Claude Code Native Marketplace (New!)

**Best for Claude Code users** - Native integration with Claude Code's plugin system.

### Add the Marketplace

```bash
# In Claude Code, run:
/plugin marketplace add alirezarezvani/claude-skills
```

This adds the skills library to your available marketplaces.

### Install Skill Bundles

```bash
# Install by domain (bundles of skills)
/plugin install marketing-skills@claude-code-skills     # 42 marketing skills
/plugin install engineering-skills@claude-code-skills   # 23 engineering skills
/plugin install engineering-advanced-skills@claude-code-skills  # 25 advanced engineering skills
/plugin install product-skills@claude-code-skills       # 8 product skills
/plugin install c-level-skills@claude-code-skills       # 28 C-level advisory skills
/plugin install pm-skills@claude-code-skills            # 6 project management skills
/plugin install ra-qm-skills@claude-code-skills         # 12 regulatory/quality skills
/plugin install business-growth-skills@claude-code-skills  # 4 business & growth skills
/plugin install finance-skills@claude-code-skills       # 2 finance skills
```

### Install Individual Skills

```bash
# Marketing
/plugin install content-creator@claude-code-skills
/plugin install demand-gen@claude-code-skills

# Engineering
/plugin install fullstack-engineer@claude-code-skills
/plugin install aws-architect@claude-code-skills

# Product
/plugin install product-manager@claude-code-skills

# Project Management
/plugin install scrum-master@claude-code-skills
```

### Update Skills

```bash
# Update all installed plugins
/plugin update

# Update specific plugin
/plugin update marketing-skills
```

### Remove Skills

```bash
# Remove specific plugin
/plugin remove marketing-skills

# Remove marketplace
/plugin marketplace remove claude-code-skills
```

**Benefits:**
- ✅ Native Claude Code integration
- ✅ Automatic updates with `/plugin update`
- ✅ Version management with git tags
- ✅ Skills installed to `~/.claude/skills/`
- ✅ Managed through Claude Code UI

---

## Universal Installer

The universal installer uses the [Agent Skills CLI](https://github.com/Karanjot786/agent-skills-cli) package to install skills across multiple agents simultaneously.

### Install All Skills

```bash
# Install to all supported agents
npx agent-skills-cli add alirezarezvani/claude-skills
```

**This installs to:**
- Claude Code → `~/.claude/skills/`
- Cursor → `.cursor/skills/`
- VS Code/Copilot → `.github/skills/`
- Goose → `~/.config/goose/skills/`
- Amp → Platform-specific location
- Codex → Platform-specific location
- Letta → Platform-specific location
- OpenCode → Platform-specific location

### Install to Specific Agent

```bash
# Claude Code only
npx agent-skills-cli add alirezarezvani/claude-skills --agent claude

# Cursor only
npx agent-skills-cli add alirezarezvani/claude-skills --agent cursor

# VS Code/Copilot only
npx agent-skills-cli add alirezarezvani/claude-skills --agent vscode

# Goose only
npx agent-skills-cli add alirezarezvani/claude-skills --agent goose

# Project-specific installation (portable)
npx agent-skills-cli add alirezarezvani/claude-skills --agent project
```

### Preview Before Installing

```bash
# Dry run to see what will be installed
npx agent-skills-cli add alirezarezvani/claude-skills --dry-run
```

---

## Per-Skill Installation

Install individual skills instead of the entire library:

### Marketing Skills

```bash
# Content Creator
npx agent-skills-cli add alirezarezvani/claude-skills/marketing-skill/content-creator

# Demand Generation & Acquisition
npx agent-skills-cli add alirezarezvani/claude-skills/marketing-skill/marketing-demand-acquisition

# Product Marketing Strategy
npx agent-skills-cli add alirezarezvani/claude-skills/marketing-skill/marketing-strategy-pmm

# App Store Optimization
npx agent-skills-cli add alirezarezvani/claude-skills/marketing-skill/app-store-optimization

# Social Media Analyzer
npx agent-skills-cli add alirezarezvani/claude-skills/marketing-skill/social-media-analyzer
```

### C-Level Advisory Skills

```bash
# CEO Advisor
npx agent-skills-cli add alirezarezvani/claude-skills/c-level-advisor/ceo-advisor

# CTO Advisor
npx agent-skills-cli add alirezarezvani/claude-skills/c-level-advisor/cto-advisor
```

### Product Team Skills

```bash
# Product Manager Toolkit
npx agent-skills-cli add alirezarezvani/claude-skills/product-team/product-manager-toolkit

# Agile Product Owner
npx agent-skills-cli add alirezarezvani/claude-skills/product-team/agile-product-owner

# Product Strategist
npx agent-skills-cli add alirezarezvani/claude-skills/product-team/product-strategist

# UX Researcher Designer
npx agent-skills-cli add alirezarezvani/claude-skills/product-team/ux-researcher-designer

# UI Design System
npx agent-skills-cli add alirezarezvani/claude-skills/product-team/ui-design-system
```

### Project Management Skills

```bash
# Senior PM Expert
npx agent-skills-cli add alirezarezvani/claude-skills/project-management/senior-pm

# Scrum Master Expert
npx agent-skills-cli add alirezarezvani/claude-skills/project-management/scrum-master

# Atlassian Jira Expert
npx agent-skills-cli add alirezarezvani/claude-skills/project-management/jira-expert

# Atlassian Confluence Expert
npx agent-skills-cli add alirezarezvani/claude-skills/project-management/confluence-expert

# Atlassian Administrator
npx agent-skills-cli add alirezarezvani/claude-skills/project-management/atlassian-admin

# Atlassian Template Creator
npx agent-skills-cli add alirezarezvani/claude-skills/project-management/atlassian-templates
```

### Engineering Team Skills

```bash
# Core Engineering
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-architect
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-frontend
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-backend
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-fullstack
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-qa
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-devops
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-secops
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/code-reviewer
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-security

# Cloud & Enterprise
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/aws-solution-architect
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/ms365-tenant-manager

# Development Tools
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/tdd-guide
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/tech-stack-evaluator

# AI/ML/Data
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-data-scientist
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-data-engineer
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-ml-engineer
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-prompt-engineer
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-computer-vision
```

### Regulatory Affairs & Quality Management Skills

```bash
# Regulatory & Quality Leadership
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/regulatory-affairs-head
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/quality-manager-qmr
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/quality-manager-qms-iso13485

# Quality Processes
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/capa-officer
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/quality-documentation-manager
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/risk-management-specialist

# Security & Privacy
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/information-security-manager-iso27001
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/gdpr-dsgvo-expert

# Regional Compliance
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/mdr-745-specialist
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/fda-consultant-specialist

# Audit & Assessment
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/qms-audit-expert
npx agent-skills-cli add alirezarezvani/claude-skills/ra-qm-team/isms-audit-expert
```

---

## Multi-Agent Setup

Install the same skills across different agents for team consistency:

### Example: Marketing Team Setup

```bash
# Install marketing skills to Claude Code (for content strategist)
npx agent-skills-cli add alirezarezvani/claude-skills/marketing-skill/content-creator --agent claude

# Install same skills to Cursor (for developer working on content)
npx agent-skills-cli add alirezarezvani/claude-skills/marketing-skill/content-creator --agent cursor

# Install to VS Code (for SEO specialist)
npx agent-skills-cli add alirezarezvani/claude-skills/marketing-skill/content-creator --agent vscode
```

### Example: Engineering Team Setup

```bash
# Full engineering suite to Claude Code
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team --agent claude

# Same suite to Cursor
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team --agent cursor
```

---

## Manual Installation

For development, customization, or offline use:

### Prerequisites

- **Python 3.7+** (for running analysis scripts)
- **Git** (for cloning repository)
- **Claude AI account** or **Claude Code** (for using skills)

### Step 1: Clone Repository

```bash
git clone https://github.com/alirezarezvani/claude-skills.git
cd claude-skills
```

### Step 2: Install Dependencies (Optional)

Most scripts use Python standard library only:

```bash
# Optional dependencies for future features
pip install pyyaml
```

### Step 3: Manual Copy to Agent Directory

#### For Claude Code

```bash
# Copy all skills
cp -r marketing-skill ~/.claude/skills/
cp -r c-level-advisor ~/.claude/skills/
cp -r product-team ~/.claude/skills/
cp -r project-management ~/.claude/skills/
cp -r engineering-team ~/.claude/skills/
cp -r ra-qm-team ~/.claude/skills/

# Or copy single skill
cp -r marketing-skill/content-creator ~/.claude/skills/content-creator
```

#### For Cursor

```bash
# Copy to project directory
mkdir -p .cursor/skills
cp -r marketing-skill .cursor/skills/
```

#### For VS Code/Copilot

```bash
# Copy to project directory
mkdir -p .github/skills
cp -r engineering-team .github/skills/
```

### Step 4: Verify Python Tools

```bash
# Test marketing tools
python3 marketing-skill/content-production/scripts/brand_voice_analyzer.py --help
python3 marketing-skill/content-production/scripts/seo_optimizer.py --help

# Test C-level tools
python3 c-level-advisor/cto-advisor/scripts/tech_debt_analyzer.py --help
python3 c-level-advisor/ceo-advisor/scripts/strategy_analyzer.py --help

# Test product tools
python3 product-team/product-manager-toolkit/scripts/rice_prioritizer.py --help
python3 product-team/ui-design-system/scripts/design_token_generator.py --help
```

---

## Verification & Testing

### Verify Universal Installer Installation

```bash
# Check Claude Code installation
ls ~/.claude/skills/

# Check Cursor installation
ls .cursor/skills/

# Check VS Code installation
ls .github/skills/

# Check Goose installation
ls ~/.config/goose/skills/
```

### Test Skill Usage

#### In Claude Code

1. Open Claude Code
2. Start a new conversation
3. Test a skill:
   ```
   Using the content-creator skill, analyze this text for brand voice:
   "Our platform revolutionizes data analytics..."
   ```

#### In Cursor

1. Open Cursor
2. Use Cmd+K or Ctrl+K
3. Reference skill:
   ```
   @content-creator analyze brand voice for this file
   ```

### Test Python Tools Locally

```bash
# Create test file
echo "Sample content for analysis" > test-article.txt

# Run brand voice analysis
python3 ~/.claude/skills/content-production/scripts/brand_voice_analyzer.py test-article.txt

# Run SEO optimization
python3 ~/.claude/skills/content-production/scripts/seo_optimizer.py test-article.txt "sample keyword"
```

---

## Windows Notes

Two Windows-specific caveats to know before cloning or running skills (issues #968 and #969):

### Symlinks: mirror trees need `core.symlinks=true`

The cross-platform mirror trees (`.gemini/`, `.codex/`, `.vibe/`, `.hermes/`) are built from **relative symlinks** into the real skill directories. Git for Windows defaults to `core.symlinks=false`, so a default clone checks those 1,300+ links out as **1-line text files containing only the target path** — copying a skill folder from a mirror tree then silently gives you dead pointer files instead of skills.

Before cloning on Windows:

1. Enable **Developer Mode** (Settings → System → For developers), or run Git from an elevated prompt.
2. Clone with symlinks enabled:

   ```powershell
   git clone -c core.symlinks=true https://github.com/alirezarezvani/claude-skills.git
   ```

If you already cloned without it, either re-clone as above, or **copy skills from the real domain directories** (e.g. `engineering-team/`, `marketing-skill/`) instead of the mirror trees — the Claude Code plugin/marketplace path always uses the real directories and is unaffected. Quick sanity check after any copy: a real `SKILL.md` is more than one line long.

### Console encoding: run Python tools with UTF-8

Windows consoles often default to a legacy codepage (e.g. cp1252) that cannot encode the box-drawing and comparison characters (`╔`, `≥`, `✅`) some skill tools print, which crashes the script at print time with `UnicodeEncodeError`. The most-affected tools now re-encode their own output, but as a blanket fix for every script in this library, enable Python's UTF-8 mode:

```powershell
# Per session
$env:PYTHONUTF8 = "1"

# Or permanently
setx PYTHONUTF8 1
```

---

## Troubleshooting

### Universal Installer Issues

#### Issue: "Command not found: npx"

**Solution:** Install Node.js and npm

```bash
# macOS
brew install node

# Ubuntu/Debian
sudo apt-get install nodejs npm

# Windows
# Download from https://nodejs.org/
```

#### Issue: "Skill not found" when installing a domain bundle

**Solution:** Use `agent-skills-cli` (not `ai-agent-skills`) and specify the correct path:

```bash
# Install entire domain bundle
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team

# Or install individual skills
npx agent-skills-cli add alirezarezvani/claude-skills/engineering-team/senior-frontend
```

Note: The older `ai-agent-skills` package may not support bundle installation. Use `agent-skills-cli` instead.

#### Issue: "Failed to install skills"

**Solution:** Check network connection and permissions

```bash
# Check network
curl https://github.com/alirezarezvani/claude-skills

# Check write permissions
ls -la ~/.claude/
```

#### Issue: "Skills not showing in agent"

**Solution:** Restart agent and verify installation location

```bash
# Verify installation
ls -R ~/.claude/skills/

# Restart Claude Code
# Close and reopen application
```

### Manual Installation Issues

#### Issue: Python scripts not executable

**Solution:** Add execute permissions

```bash
chmod +x marketing-skill/content-creator/scripts/*.py
chmod +x c-level-advisor/*/scripts/*.py
chmod +x product-team/*/scripts/*.py
```

#### Issue: "Module not found" errors

**Solution:** Install required dependencies

```bash
# Install Python dependencies
pip install pyyaml

# Or use Python 3 specifically
pip3 install pyyaml
```

#### Issue: Skills not recognized by agent

**Solution:** Verify SKILL.md format and location

```bash
# Check SKILL.md exists
ls ~/.claude/skills/content-creator/SKILL.md

# Verify YAML frontmatter
head -20 ~/.claude/skills/content-creator/SKILL.md
```

### Agent-Specific Issues

#### Claude Code

```bash
# Reset skills directory
rm -rf ~/.claude/skills/
mkdir -p ~/.claude/skills/

# Reinstall
npx agent-skills-cli add alirezarezvani/claude-skills --agent claude
```

#### Cursor

```bash
# Cursor uses project-local skills
# Verify project directory has .cursor/skills/

ls .cursor/skills/
```

#### VS Code/Copilot

```bash
# GitHub Copilot uses .github/skills/
# Verify directory structure

ls .github/skills/
```

---

## Uninstallation

### Universal Installer (All Agents)

```bash
# Remove from Claude Code
rm -rf ~/.claude/skills/alirezarezvani/claude-skills/

# Remove from Cursor
rm -rf .cursor/skills/alirezarezvani/claude-skills/

# Remove from VS Code
rm -rf .github/skills/alirezarezvani/claude-skills/

# Remove from Goose
rm -rf ~/.config/goose/skills/alirezarezvani/claude-skills/
```

### Manual Installation

```bash
# Clone directory
rm -rf claude-skills/

# Copied skills
rm -rf ~/.claude/skills/marketing-skill/
rm -rf ~/.claude/skills/engineering-team/
# etc.
```

### Remove Individual Skills

```bash
# Example: Remove content-creator from Claude Code
rm -rf ~/.claude/skills/content-creator/

# Example: Remove fullstack-engineer from Cursor
rm -rf .cursor/skills/fullstack-engineer/
```

---

## Gemini CLI Installation

Gemini CLI users can install skills using the setup script below. This repository provides Gemini CLI compatibility through a `.gemini/skills/` directory with symlinks to all 205+ skills, agents, and commands.

### Setup Instructions

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/alirezarezvani/claude-skills.git
    cd claude-skills
    ```

2.  **Run the Gemini setup script:**
    ```bash
    ./scripts/gemini-install.sh
    ```
    This script performs the following:
    - Scans all 9 domain folders for `SKILL.md` files.
    - Scans the `agents/` folder for multi-agent persona definitions.
    - Scans the `commands/` folder for predefined slash command workflows.
    - Creates a `.gemini/skills/` directory with standardized subfolders for each.
    - Generates a `skills-index.json` manifest for discovery.

3.  **Activate Skills in Gemini CLI:**
    Gemini CLI can now activate any of these 205+ skills by name. Use the `activate_skill` tool:
    ```javascript
    // Activate a core skill
    activate_skill(name="senior-architect")

    // Activate a marketing specialist
    activate_skill(name="content-creator")

    // Activate a C-level advisor
    activate_skill(name="cto-advisor")

    // Activate a multi-agent persona
    activate_skill(name="cs-engineering-lead")

    // Activate a slash command workflow
    activate_skill(name="tdd")
    ```

### Python CLI Tools

Every skill includes deterministic Python CLI tools in its `scripts/` folder. These use the standard library only and can be run directly from your terminal or by the Gemini CLI.

Example:
```bash
python3 marketing-skill/content-production/scripts/brand_voice_analyzer.py article.txt
```

---

## Mistral Vibe Installation

[Mistral Vibe](https://github.com/mistralai/mistral-vibe) is Mistral AI's open-source CLI coding agent (Apache-2.0). It uses the same [`SKILL.md` + YAML frontmatter](https://docs.mistral.ai/mistral-vibe/agents-skills) standard as Claude Code and Hermes, so this repo installs into Vibe with **zero format conversion** — just symlinks.

Vibe discovers skills from three paths (per the [official docs](https://docs.mistral.ai/mistral-vibe/agents-skills)):

- `~/.vibe/skills/` — user-global (what this script writes to)
- `.vibe/skills/` — project-local
- `.agents/skills/` — Agent Skills standard path

### Setup Instructions

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/alirezarezvani/claude-skills.git
    cd claude-skills
    ```

2.  **Run the Vibe setup script:**
    ```bash
    ./scripts/vibe-install.sh
    ```
    This installs all skills as symlinks under `~/.vibe/skills/claude-skills/<domain>/<skill-name>/`, namespaced to avoid collisions with Vibe built-ins. It also writes a `skills-index.json` manifest for discovery.

3.  **Use skills in Vibe:**
    ```text
    > /skills                    # list all installed skills
    > /senior-architect          # invoke a skill by slug
    > review my API design       # auto-loads matching skills via SKILL.md description
    ```

### Direct Python invocation

For finer-grained control (one domain at a time, copy instead of symlink, JSON output for tooling):

```bash
# Preview without writing
python3 scripts/sync-vibe-skills.py --dry-run --verbose

# Sync only one domain
python3 scripts/sync-vibe-skills.py --domain engineering

# Copy (instead of symlink) — useful for portable installs
python3 scripts/sync-vibe-skills.py --copy

# JSON output (for CI / scripting)
python3 scripts/sync-vibe-skills.py --json

# Custom target (instead of ~/.vibe/skills/)
python3 scripts/sync-vibe-skills.py --target /opt/team-vibe/skills/
```

### What gets installed

| Layout | Path | Count |
|--------|------|-------|
| Skill folders (symlinked) | `~/.vibe/skills/claude-skills/<domain>/<skill>/` | 306 |
| Domain directories | `~/.vibe/skills/claude-skills/<domain>/` | 14 |
| Index manifest | `~/.vibe/skills/claude-skills/skills-index.json` | 1 |

A pre-generated copy of the same tree is also committed at `.vibe/skills/claude-skills/` in this repo for reference and for users who want to inspect what will land before running the installer.

### Verify Installation

```bash
# Count installed skills
ls ~/.vibe/skills/claude-skills/*/ | wc -l

# Inspect the manifest
cat ~/.vibe/skills/claude-skills/skills-index.json | python3 -m json.tool | head -20

# Verify a skill's frontmatter resolved correctly through the symlink
head -10 ~/.vibe/skills/claude-skills/engineering/senior-architect/SKILL.md
```

### Uninstall

```bash
rm -rf ~/.vibe/skills/claude-skills/
```

The namespaced subdirectory means uninstalling never touches Vibe's built-in skills or any skills you installed from other sources.

### Python CLI Tools

Every skill includes deterministic Python CLI tools in its `scripts/` folder. These use the standard library only and run anywhere Python runs — Vibe can invoke them via its shell tool, or you can run them directly:

```bash
python3 ~/.vibe/skills/claude-skills/marketing-skill/content-production/scripts/brand_voice_analyzer.py article.txt
```

---

## OpenClaw Installation

OpenClaw loads skills via YAML frontmatter in `SKILL.md` files. Every skill in this repository includes OpenClaw-compatible frontmatter with `name`, `description`, and `tags` fields.

### Method 1: ClawHub (Recommended)

```bash
# Install from ClawHub registry
clawhub install alirezarezvani/claude-skills

# Install specific skill
clawhub install alirezarezvani/claude-skills/engineering-team/senior-frontend
```

### Method 2: Manual Installation

```bash
# Clone the repository
git clone https://github.com/alirezarezvani/claude-skills.git
cd claude-skills

# Copy a skill to your OpenClaw skills directory
cp -r engineering-team/senior-frontend ~/.openclaw/skills/senior-frontend

# Or copy an entire domain
cp -r engineering-team ~/.openclaw/skills/engineering-team
```

### How Skills Load in OpenClaw

OpenClaw reads the YAML frontmatter from each `SKILL.md` to determine when to activate a skill:

```yaml
---
name: "senior-frontend"
description: "Frontend development skill for React, Next.js, TypeScript..."
tags:
  - frontend
  - react
  - nextjs
---
```

The `description` field triggers skill activation — when your prompt matches the described use case, OpenClaw loads the skill automatically.

### Verify Installation

```bash
# List installed skills
ls ~/.openclaw/skills/

# Verify a skill's frontmatter
head -20 ~/.openclaw/skills/senior-frontend/SKILL.md
```

### Available Domains

| Domain | Folder | Skills |
|--------|--------|--------|
| Engineering (Core) | `engineering-team/` | 23 |
| Engineering (Advanced) | `engineering/` | 25 |
| Marketing | `marketing-skill/` | 42 |
| C-Level Advisory | `c-level-advisor/` | 28 |
| Product Team | `product-team/` | 8 |
| Project Management | `project-management/` | 6 |
| RA/QM Compliance | `ra-qm-team/` | 12 |
| Business & Growth | `business-growth/` | 4 |
| Finance | `finance/` | 2 |

### Python Tools

All Python scripts work independently of OpenClaw — run them directly:

```bash
python3 engineering-team/senior-security/scripts/threat_modeler.py --help
python3 finance/financial-analyst/scripts/dcf_valuation.py --help
```

---

## OpenAI Codex Installation

OpenAI Codex users can install skills using the methods below. This repository provides full Codex compatibility through a `.codex/skills/` directory with symlinks to all skills.

### Method 1: Universal Installer (Recommended)

```bash
# Install all skills to Codex
npx agent-skills-cli add alirezarezvani/claude-skills --agent codex

# Preview before installing
npx agent-skills-cli add alirezarezvani/claude-skills --agent codex --dry-run
```

### Method 2: Direct Installation Script

For manual installation using the provided scripts:

**macOS/Linux:**
```bash
# Clone repository
git clone https://github.com/alirezarezvani/claude-skills.git
cd claude-skills

# Generate symlinks (if not already present)
python3 scripts/sync-codex-skills.py

# Install all skills to ~/.codex/skills/
./scripts/codex-install.sh

# Or install specific category
./scripts/codex-install.sh --category marketing
./scripts/codex-install.sh --category engineering

# Or install single skill
./scripts/codex-install.sh --skill content-creator

# List available skills
./scripts/codex-install.sh --list
```

**Windows:**
```cmd
REM Clone repository
git clone https://github.com/alirezarezvani/claude-skills.git
cd claude-skills

REM Generate structure (if not already present)
python scripts\sync-codex-skills.py

REM Install all skills to %USERPROFILE%\.codex\skills\
scripts\codex-install.bat

REM Or install single skill
scripts\codex-install.bat --skill content-creator

REM List available skills
scripts\codex-install.bat --list
```

### Method 3: Manual Installation

```bash
# Clone repository
git clone https://github.com/alirezarezvani/claude-skills.git
cd claude-skills

# Copy skills (following symlinks) to Codex directory
mkdir -p ~/.codex/skills
cp -rL .codex/skills/* ~/.codex/skills/
```

### Verification

```bash
# Check installed skills
ls ~/.codex/skills/

# Verify skill structure
ls ~/.codex/skills/content-creator/
# Should show: SKILL.md, scripts/, references/, assets/

# Check total skill count
ls ~/.codex/skills/ | wc -l
```

### Available Categories

| Category | Skills | Examples |
|----------|--------|----------|
| **c-level** | 28 | ceo-advisor, cto-advisor, cfo-advisor, executive-mentor |
| **engineering** | 23 | senior-fullstack, aws-solution-architect, senior-ml-engineer, playwright-pro |
| **engineering-advanced** | 25 | agent-designer, rag-architect, mcp-server-builder, performance-profiler |
| **marketing** | 42 | content-creator, seo-audit, campaign-analytics, content-strategy |
| **product** | 8 | product-manager-toolkit, agile-product-owner, saas-scaffolder |
| **project-management** | 6 | scrum-master, senior-pm, jira-expert, confluence-expert |
| **ra-qm** | 12 | regulatory-affairs-head, quality-manager-qms-iso13485, gdpr-dsgvo-expert |
| **business-growth** | 4 | customer-success-manager, sales-engineer, revenue-operations |
| **finance** | 2 | financial-analyst, saas-metrics-coach |

See `.codex/skills-index.json` for the complete manifest with descriptions.

---

## Advanced: Installation Locations Reference

| Agent | Default Location | Flag | Notes |
|-------|------------------|------|-------|
| **Claude Code** | `~/.claude/skills/` | `--agent claude` | User-level installation |
| **Cursor** | `.cursor/skills/` | `--agent cursor` | Project-level installation |
| **VS Code/Copilot** | `.github/skills/` | `--agent vscode` | Project-level installation |
| **Goose** | `~/.config/goose/skills/` | `--agent goose` | User-level installation |
| **Amp** | Platform-specific | `--agent amp` | Varies by platform |
| **Codex** | `~/.codex/skills/` | `--agent codex` | User-level installation |
| **Letta** | Platform-specific | `--agent letta` | Varies by platform |
| **OpenCode** | Platform-specific | `--agent opencode` | Varies by platform |
| **OpenClaw** | `~/.openclaw/skills/` | `clawhub install` | YAML frontmatter triggers |
| **Gemini CLI** | `.gemini/skills/` | `gemini-install.sh` | Symlink-based discovery |
| **Mistral Vibe** | `~/.vibe/skills/` | `vibe-install.sh` | Same `SKILL.md` standard, no conversion |
| **Project** | `.skills/` | `--agent project` | Portable, project-specific |

---

## Support

**Installation Issues?**
- Check [Troubleshooting](#troubleshooting) section above
- Review [Agent Skills CLI documentation](https://github.com/Karanjot786/agent-skills-cli)
- Open issue: https://github.com/alirezarezvani/claude-skills/issues

**Feature Requests:**
- Submit via GitHub Issues with `enhancement` label

**General Questions:**
- Visit: https://alirezarezvani.com
- Blog: https://medium.com/@alirezarezvani

---

**Last Updated:** March 2026
**Skills Version:** 2.1.2 (205+ production skills across 9 domains)
**Universal Installer:** [Agent Skills CLI](https://github.com/Karanjot786/agent-skills-cli)
