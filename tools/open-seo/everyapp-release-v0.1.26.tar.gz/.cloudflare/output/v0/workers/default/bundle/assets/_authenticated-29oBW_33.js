import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { n as Outlet } from "./Match-Djim5BGq.js";
import { t as useMatch } from "./useMatch-BB4BMDVC.js";
import { f as usesBetterAuthClient } from "./auth-mode-DhGCw2Bx.js";
import { t as Button } from "./button-DrcZrdio.js";
import { n as AuthPageCard, r as AuthPageShell } from "./AuthPage-Bxu7AMPh.js";
import { t as PageLoading } from "./Spinner-NR-t-8YM.js";
import { t as useHostedAuthRouteGuard } from "./useHostedAuthRouteGuard-CrzAilsp.js";
//#region src/routes/_authenticated.tsx?tsr-split=component
var import_jsx_runtime = require_jsx_runtime();
function AuthenticatedShellLayout() {
	const authGate = useHostedAuthRouteGuard();
	if (!(Boolean(useMatch({
		from: "/_authenticated/oauth-consent",
		shouldThrow: false
	})) ? usesBetterAuthClient() : authGate.isHostedMode)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPageShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPageCard, {
		title: "Not available",
		helperText: "This page isn't available right now.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			nativeButton: false,
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, { to: "/" }),
			variant: "secondary",
			className: "w-full",
			children: "Back to OpenSEO"
		})
	}) });
	if (!authGate.canRenderAuthenticatedContent) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageLoading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPageShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) });
}
//#endregion
export { AuthenticatedShellLayout as component };
