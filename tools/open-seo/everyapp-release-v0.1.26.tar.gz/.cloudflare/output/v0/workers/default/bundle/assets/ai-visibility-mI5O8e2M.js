import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { m as queryClient } from "./QueryState-Q8BZIblk.js";
import { t as pageHead } from "./pageHead-BfhwMlwa.js";
import { d as aiResearchSetupQueryOptions, p as aiTrackerQueryOptions } from "./shared-BW7GMYqD.js";
//#region src/routes/_app/p/$projectId/ai-visibility.tsx
var $$splitComponentImporter = () => import("./ai-visibility-C7xxV2Gf.js");
var Route = createFileRoute("/_app/p/$projectId/ai-visibility")({
	head: () => pageHead("Prompt Tracking"),
	loader: ({ params }) => {
		queryClient.prefetchQuery(aiResearchSetupQueryOptions(params.projectId));
		queryClient.prefetchQuery(aiTrackerQueryOptions(params.projectId));
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
