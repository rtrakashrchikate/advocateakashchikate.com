import { f as parseResearchTarget } from "./researchScope-DHudUdg3.js";
//#region tests/fixtures/domain-overview-fixtures.ts
function getFixtureOverview(domain) {
	const parsed = parseResearchTarget(domain);
	const target = parsed.ok ? parsed.target : null;
	return {
		domain: target?.hostname ?? domain,
		scope: target?.scope ?? "domain",
		displayTarget: target?.display ?? domain,
		organicTraffic: 373,
		organicKeywords: 307,
		backlinks: null,
		referringDomains: null,
		hasData: true,
		fetchedAt: "2026-05-19T00:00:00.000Z"
	};
}
function getFixturePagesPage(data) {
	const pages = [
		[
			"/section-a/page-001",
			179,
			34
		],
		[
			"/section-a/page-002",
			63,
			9
		],
		[
			"/section-b/page-003",
			23,
			25
		],
		[
			"/section-b/page-004",
			19,
			16
		],
		[
			"/section-b/page-005",
			17,
			12
		],
		[
			"/section-c/page-006",
			8,
			7
		],
		[
			"/section-c/page-007",
			8,
			11
		],
		[
			"/guides/topic-008",
			3,
			10
		],
		[
			"/guides/topic-009",
			3,
			11
		],
		[
			"/guides/topic-010",
			3,
			7
		],
		[
			"/guides/topic-011",
			3,
			6
		],
		[
			"/guides/topic-012",
			2,
			5
		]
	].map(([path, traffic, keywords]) => ({
		page: `https://${data.domain}${path}`,
		relativePath: String(path),
		organicTraffic: Number(traffic),
		keywords: Number(keywords)
	}));
	return {
		domain: data.domain,
		page: data.page,
		pageSize: data.pageSize,
		totalCount: 66,
		hasMore: data.page * data.pageSize < 66,
		pages,
		fetchedAt: "2026-05-19T00:00:00.000Z"
	};
}
function getFixtureKeywordsPage(data) {
	const keywords = [
		[
			"primary sample query",
			1,
			4400,
			86,
			.61,
			18
		],
		[
			"secondary sample query",
			2,
			3600,
			74,
			.82,
			24
		],
		[
			"tertiary sample query",
			1,
			1900,
			51,
			.44,
			21
		],
		[
			"sample comparison term",
			3,
			1600,
			39,
			.52,
			28
		],
		[
			"sample evaluation term",
			4,
			1300,
			31,
			.49,
			25
		],
		[
			"sample reference term",
			5,
			1100,
			24,
			.37,
			19
		]
	].map(([keyword, position, searchVolume, traffic, cpc, keywordDifficulty]) => ({
		keyword: String(keyword),
		position: Number(position),
		searchVolume: Number(searchVolume),
		traffic: Number(traffic),
		cpc: Number(cpc),
		url: `https://${data.domain}/section-a/page-001`,
		relativeUrl: "/section-a/page-001",
		keywordDifficulty: Number(keywordDifficulty)
	}));
	return {
		domain: data.domain,
		page: data.page,
		pageSize: data.pageSize,
		totalCount: 307,
		hasMore: data.page * data.pageSize < 307,
		keywords,
		fetchedAt: "2026-05-19T00:00:00.000Z"
	};
}
//#endregion
export { getFixtureKeywordsPage, getFixtureOverview, getFixturePagesPage };
