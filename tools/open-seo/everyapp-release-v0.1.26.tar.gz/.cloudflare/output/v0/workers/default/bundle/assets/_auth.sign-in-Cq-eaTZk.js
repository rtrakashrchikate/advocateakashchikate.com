import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { o as authRedirectSearchSchema } from "./AuthPage-Bxu7AMPh.js";
import { t as pageHead } from "./pageHead-BfhwMlwa.js";
//#region src/routes/_auth.sign-in.tsx
var $$splitComponentImporter = () => import("./_auth.sign-in-J6-qkGH9.js");
var Route = createFileRoute("/_auth/sign-in")({
	head: () => pageHead("Sign in"),
	validateSearch: authRedirectSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
