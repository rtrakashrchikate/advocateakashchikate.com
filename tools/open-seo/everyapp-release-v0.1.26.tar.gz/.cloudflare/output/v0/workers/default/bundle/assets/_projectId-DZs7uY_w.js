import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as DashboardPage } from "./DashboardPage-CZEuuOi9.js";
import { t as Route } from "./_projectId-BVsPv53I.js";
//#region src/routes/_app/p/$projectId/index.tsx?tsr-split=component
var import_jsx_runtime = require_jsx_runtime();
function DashboardRoute() {
	const { projectId } = Route.useParams();
	const search = Route.useSearch();
	const navigate = Route.useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashboardPage, {
		projectId,
		tab: search.tab,
		onTabChange: (tab) => void navigate({ search: { tab } })
	}, projectId);
}
//#endregion
export { DashboardRoute as component };
