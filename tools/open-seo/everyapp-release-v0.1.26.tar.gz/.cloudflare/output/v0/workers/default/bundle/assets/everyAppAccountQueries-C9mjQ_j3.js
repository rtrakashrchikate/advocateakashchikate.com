import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { t as queryOptions } from "./queryOptions-Dji4xsRu.js";
import { t as createSsrRpc } from "./createSsrRpc-Vp3C13VD.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
//#region src/serverFunctions/everyApp.ts
/**
* Where the account menu sends people behind an Every App gateway, which
* owns sign-in, sign-out, organizations and teams. The deploy sets
* GATEWAY_URL; the identity tokens' issuer is the same origin, so it stands
* in where GATEWAY_URL isn't set (local dev).
*/
/** The signed-in person and their gateway, for the account menu. */
var getEveryAppAccount = createServerFn({ method: "GET" }).middleware(requireAuthenticatedContext).handler(createSsrRpc("928b81f17cde1c7afd6fa15afb9df0d43555915dba7bc5d293cda200d87d5806"));
//#endregion
//#region src/client/features/every-app/everyAppAccountQueries.ts
/**
* The member's Every App account and the gateway to link back to; null off
* Every App. Read by the sidebar footer and the settings page.
*/
var everyAppAccountQueryOptions = () => queryOptions({
	queryKey: ["every-app-account"],
	queryFn: () => getEveryAppAccount(),
	staleTime: 3e5
});
//#endregion
export { everyAppAccountQueryOptions as t };
