import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { n as AI_ENGINE_LABELS } from "./ai-visibility-b7Nyzqt-.js";
import { t as useQuery, x as keepPreviousData } from "./useQuery-B93OR2NQ.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { t as queryOptions } from "./queryOptions-Dji4xsRu.js";
import { H as LoaderCircle, t as Button } from "./button-DrcZrdio.js";
import { E as runAiVisibilityCheck, O as setAiVisibilitySchedule, h as aiVisibilityKey, r as AiQueryError, s as aiMoney, t as AiLoading, v as estimateAiVisibilityCost } from "./shared-BW7GMYqD.js";
import { i as OpenAIIcon, t as ClaudeIcon } from "./AgentIcons-BM9OjT5t.js";
import { a as FieldLabel, r as FieldDescription, t as Field } from "./field-CjRT_5Cr.js";
import { t as FormDialog } from "./FormDialog-BB0krQ3j.js";
import { a as withBrowserTimeZone, i as randomScheduleDate, r as localScheduleTimeFrom, t as ScheduleField } from "./ScheduleField-AOI31vZV.js";
//#region src/client/features/ai-visibility/EngineIcon.tsx
var import_jsx_runtime = require_jsx_runtime();
function Mark({ paths, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		xmlns: "http://www.w3.org/2000/svg",
		viewBox: "0 0 24 24",
		fill: "currentColor",
		fillRule: "evenodd",
		"aria-hidden": "true",
		...props,
		children: paths.map((path) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: path }, path))
	});
}
var GEMINI = ["M20.616 10.835a14.147 14.147 0 01-4.45-3.001 14.111 14.111 0 01-3.678-6.452.503.503 0 00-.975 0 14.134 14.134 0 01-3.679 6.452 14.155 14.155 0 01-4.45 3.001c-.65.28-1.318.505-2.002.678a.502.502 0 000 .975c.684.172 1.35.397 2.002.677a14.147 14.147 0 014.45 3.001 14.112 14.112 0 013.679 6.453.502.502 0 00.975 0c.172-.685.397-1.351.677-2.003a14.145 14.145 0 013.001-4.45 14.113 14.113 0 016.453-3.678.503.503 0 000-.975 13.245 13.245 0 01-2.003-.678z"];
var GOOGLE = [
	"M23 12.245c0-.905-.075-1.565-.236-2.25h-10.54v4.083h6.186c-.124 1.014-.797 2.542-2.294 3.569l-.021.136 3.332 2.53.23.022C21.779 18.417 23 15.593 23 12.245z",
	"M12.225 23c3.03 0 5.574-.978 7.433-2.665l-3.542-2.688c-.948.648-2.22 1.1-3.891 1.1a6.745 6.745 0 01-6.386-4.572l-.132.011-3.465 2.628-.045.124C4.043 20.531 7.835 23 12.225 23z",
	"M5.84 14.175A6.65 6.65 0 015.463 12c0-.758.138-1.491.361-2.175l-.006-.147-3.508-2.67-.115.054A10.831 10.831 0 001 12c0 1.772.436 3.447 1.197 4.938l3.642-2.763z",
	"M12.225 5.253c2.108 0 3.529.892 4.34 1.638l3.167-3.031C17.787 2.088 15.255 1 12.225 1 7.834 1 4.043 3.469 2.197 7.062l3.63 2.763a6.77 6.77 0 016.398-4.572z"
];
var PERPLEXITY = ["M19.785 0v7.272H22.5V17.62h-2.935V24l-7.037-6.194v6.145h-1.091v-6.152L4.392 24v-6.465H1.5V7.188h2.884V0l7.053 6.494V.19h1.09v6.49L19.786 0zm-7.257 9.044v7.319l5.946 5.234V14.44l-5.946-5.397zm-1.099-.08l-5.946 5.398v7.235l5.946-5.234V8.965zm8.136 7.58h1.844V8.349H13.46l6.105 5.54v2.655zm-8.982-8.28H2.59v8.195h1.8v-2.576l6.192-5.62zM5.475 2.476v4.71h5.115l-5.115-4.71zm13.219 0l-5.115 4.71h5.115v-4.71z"];
function EngineIcon({ engine, ...props }) {
	if (engine === "chatgpt") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpenAIIcon, { ...props });
	if (engine === "gemini") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
		paths: GEMINI,
		...props
	});
	if (engine === "claude") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClaudeIcon, { ...props });
	if (engine === "perplexity") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
		paths: PERPLEXITY,
		...props
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
		paths: GOOGLE,
		...props
	});
}
//#endregion
//#region src/client/features/ai-visibility/EngineLabel.tsx
function EngineLabel({ engine, label = AI_ENGINE_LABELS[engine] }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5 whitespace-nowrap align-middle",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EngineIcon, {
			engine,
			className: "size-4 shrink-0",
			"aria-hidden": "true"
		}), label]
	});
}
//#endregion
//#region src/client/features/ai-visibility/TrackingCostReview.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var costEstimateQueryOptions = ({ projectId, mode, scheduleInterval, promptIds }) => queryOptions({
	queryKey: [
		...aiVisibilityKey(projectId),
		"estimate",
		mode,
		scheduleInterval,
		promptIds
	],
	queryFn: () => estimateAiVisibilityCost({ data: {
		projectId,
		promptIds,
		scheduleInterval: mode === "schedule" ? scheduleInterval : void 0
	} }),
	staleTime: 0,
	retry: false,
	refetchOnWindowFocus: false
});
/** Starts pricing a run before Run now is clicked, so the dialog opens on a price. */
function prefetchRunNowCost(queryClient, projectId, tracker, promptIds) {
	queryClient.prefetchQuery(costEstimateQueryOptions({
		projectId,
		mode: "check",
		scheduleInterval: tracker.scheduleInterval,
		promptIds
	}));
}
function TrackingCostReview({ projectId, tracker, mode, promptIds, onClose, onStarted }) {
	const [scheduleInterval, setScheduleInterval] = (0, import_react.useState)(tracker.scheduleInterval);
	const [scheduleTime, setScheduleTime] = (0, import_react.useState)(() => localScheduleTimeFrom(tracker.enabled && tracker.nextCheckAt ? new Date(tracker.nextCheckAt) : randomScheduleDate()));
	const [scheduleTimeEdited, setScheduleTimeEdited] = (0, import_react.useState)(false);
	const estimate = useQuery({
		...costEstimateQueryOptions({
			projectId,
			mode,
			scheduleInterval,
			promptIds
		}),
		placeholderData: keepPreviousData
	});
	const cost = estimate.data;
	const runCostUsd = (mode === "check" ? cost?.runNowCostUsd : cost?.costUsd) ?? 0;
	const start = useMutation({
		mutationFn: async () => {
			if (!cost) throw new Error("Review the estimate before starting.");
			if (mode === "schedule") return (await setAiVisibilitySchedule({ data: {
				projectId,
				enabled: true,
				scheduleInterval,
				scheduleTime: !tracker.enabled || scheduleTimeEdited || scheduleInterval !== tracker.scheduleInterval ? withBrowserTimeZone(scheduleTime) : void 0
			} })).run;
			return runAiVisibilityCheck({ data: {
				projectId,
				maxCostUsd: cost.runNowCostUsd,
				promptIds
			} });
		},
		onSuccess: onStarted
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormDialog, {
		title: mode === "check" ? "Run now" : tracker.enabled ? "Change tracking schedule" : "Schedule tracking",
		onClose: () => {
			if (!start.isPending) onClose();
		},
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			disabled: start.isPending,
			onClick: onClose,
			children: "Cancel"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			disabled: !cost || estimate.isFetching || start.isPending || cost.observations === 0,
			onClick: () => start.mutate(),
			children: [start.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }), mode === "check" ? "Run now" : tracker.enabled ? "Save schedule" : "Start tracking"]
		})] }),
		children: estimate.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiLoading, {}) : estimate.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiQueryError, {
			error: estimate.error,
			retry: () => {
				estimate.refetch();
			}
		}) : cost && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			mode === "schedule" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScheduleField, {
				allowManual: false,
				schedule: scheduleInterval,
				onScheduleChange: (value) => {
					if (value !== "manual") setScheduleInterval(value);
				},
				scheduleTime,
				onScheduleTimeChange: (time) => {
					setScheduleTime(time);
					setScheduleTimeEdited(true);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, { children: mode === "schedule" ? "Cost per run" : "Cost" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-2xl font-semibold tabular-nums",
					children: aiMoney(runCostUsd)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: `${cost.observations} ${cost.observations === 1 ? "answer" : "answers"}${mode === "schedule" ? ` \u00B7 about ${aiMoney(cost.monthlyCostUsd)} a month (${cost.checksPerMonth} ${cost.checksPerMonth === 1 ? "run" : "runs"})` : " \u00B7 live answers, ready in a few minutes"}` }),
				mode === "check" && tracker.nextCheckAt && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: "Your scheduled tracking doesn't change." })
			] }),
			start.error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiQueryError, { error: start.error })
		] })
	});
}
//#endregion
export { EngineIcon as i, prefetchRunNowCost as n, EngineLabel as r, TrackingCostReview as t };
