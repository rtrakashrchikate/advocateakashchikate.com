import { Et as _enum, Fn as object, Jn as string, Nt as array, or as union, qn as strictObject } from "./schemas-BPIpYT5n.js";
//#region src/types/schemas/projectContext.ts
var PROJECT_CONTEXT_SECTION_KEYS = [
	"business_overview",
	"current_goal",
	"positioning",
	"writing_preferences"
];
var projectContextSectionKeySchema = _enum(PROJECT_CONTEXT_SECTION_KEYS);
var PROJECT_CONTEXT_SECTION_LABELS = {
	business_overview: "Business overview",
	current_goal: "Current goal",
	positioning: "Positioning",
	writing_preferences: "Writing preferences"
};
/** Cap on every prose section, enforced by the service and hinted in the UI. */
var PROSE_MAX_CHARS = 4e3;
var KEY_PAGE_ROLES = [
	"hub",
	"spoke",
	"money",
	"other"
];
var keyPageRoleSchema = _enum(KEY_PAGE_ROLES);
_enum([
	"user",
	"sam",
	"mcp"
]);
var customSectionSlugSchema = string().trim().max(60).regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, "Use a lowercase slug like 'launch-plan'").describe("Lowercase letters and digits separated by hyphens, e.g. 'launch-plan'. No underscores or spaces. Use the same slug to edit or delete the section.");
var CUSTOM_SECTION_KEY_PREFIX = "custom:";
var competitorInputSchema = object({
	domain: string().trim().min(1).max(255),
	name: string().trim().max(120).optional(),
	notes: string().trim().max(500).optional()
});
var keyPageInputSchema = object({
	url: string().trim().min(1).max(2048),
	role: keyPageRoleSchema.optional(),
	topic: string().trim().max(200).optional(),
	notes: string().trim().max(500).optional()
});
var projectContextUpdateSchema = union([
	strictObject({ brandName: string().trim().max(120) }),
	strictObject({
		section: projectContextSectionKeySchema,
		content: string()
	}),
	strictObject({
		customSection: customSectionSlugSchema,
		title: string().trim().min(1).max(120).optional(),
		content: string()
	}),
	strictObject({ deleteCustomSection: customSectionSlugSchema }),
	strictObject({ addCompetitors: array(competitorInputSchema).min(1).max(100) }),
	strictObject({ removeCompetitors: array(string().trim().min(1)).min(1).max(100) }),
	strictObject({ addKeyPages: array(keyPageInputSchema).min(1).max(100) }),
	strictObject({ removeKeyPages: array(string().trim().min(1)).min(1).max(100) }),
	strictObject({ removeResearchLog: array(string().min(1)).min(1).max(100) }),
	strictObject({ appendResearchLog: object({ summary: string().trim().min(1).max(1e3) }) })
]);
var getProjectContextSchema = object({ projectId: string().min(1) });
var updateProjectContextSchema = object({
	projectId: string().min(1),
	updates: array(projectContextUpdateSchema).min(1).max(50)
});
//#endregion
export { PROSE_MAX_CHARS as a, PROJECT_CONTEXT_SECTION_LABELS as i, KEY_PAGE_ROLES as n, getProjectContextSchema as o, PROJECT_CONTEXT_SECTION_KEYS as r, updateProjectContextSchema as s, CUSTOM_SECTION_KEY_PREFIX as t };
