import { t as t$1 } from "./purry-DMI_Uzu-.js";
//#region node_modules/.pnpm/remeda@2.33.6/node_modules/remeda/dist/hasAtLeast.js
function t(...t) {
	return t$1(n, t);
}
var n = (e, t) => e.length >= t;
//#endregion
export { t };
