import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { t as pageHead } from "./pageHead-BfhwMlwa.js";
import { r as lighthouseIssuesSearchSchema } from "./lighthouse-EBq35meS.js";
//#region src/routes/_app/p/$projectId/audit/issues/$resultId.tsx
var $$splitComponentImporter = () => import("./_resultId-7QT78WpY.js");
var Route = createFileRoute("/_app/p/$projectId/audit/issues/$resultId")({
	head: () => pageHead("Site Audit"),
	validateSearch: lighthouseIssuesSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
