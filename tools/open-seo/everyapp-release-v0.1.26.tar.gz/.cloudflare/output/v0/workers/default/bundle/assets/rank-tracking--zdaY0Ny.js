import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { f as FeatureFlag, p as isFeatureFlagOn } from "./resolve-DrNDcpX6.js";
import { R as captureServerEvent, U as AppError, W as asAppError, t as markOnboardingMilestone } from "./onboarding-drip-B7bIbv_6.js";
import { t as RankTrackingRepository } from "./RankTrackingRepository-JQXdgQbb.js";
import { n as requireAuthenticatedContext, r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { a as getConfigsSchema, c as getLatestRunSchema, d as removeKeywordsSchema, f as setKeywordsPinnedSchema, i as getConfigTrendSchema, l as getPositionMatrixSchema, m as updateConfigSchema, n as createConfigSchema, o as getKeywordHistorySchema, p as triggerCheckSchema, r as estimateCostSchema, s as getLatestResultsSchema, t as addKeywordsSchema, u as refreshMetricsSchema } from "./rank-tracking-CLTTFoBR.js";
import { n as RankTrackingKeywordService, r as getLatestResults, t as RankTrackingService } from "./RankTrackingService-uvkmCR7N.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
import { waitUntil } from "cloudflare:workers";
//#region src/serverFunctions/rank-tracking.ts?tss-serverfn-split
async function requireConfig(configId, projectId) {
	const config = await RankTrackingRepository.getConfigById({
		configId,
		projectId
	});
	if (!config) throw new AppError("INTERNAL_ERROR", "Rank tracking config not found");
	return config;
}
var getRankTrackingConfigs_createServerFn_handler = createServerRpc({
	id: "2498dc9ae1c9692a93484405a16016aa8af2296e6a6ac6c892aeff22c4154f17",
	name: "getRankTrackingConfigs",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => getRankTrackingConfigs.__executeServer(opts));
var getRankTrackingConfigs = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getConfigsSchema).handler(getRankTrackingConfigs_createServerFn_handler, async ({ context }) => {
	return RankTrackingRepository.getConfigsForProject(context.projectId);
});
var getRankTrackingConfigSummaries_createServerFn_handler = createServerRpc({
	id: "bb79e98e928653ebc50e8c4bfd905ed74cfd81dc4ad11c40a96e517c7a538648",
	name: "getRankTrackingConfigSummaries",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => getRankTrackingConfigSummaries.__executeServer(opts));
var getRankTrackingConfigSummaries = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getConfigsSchema).handler(getRankTrackingConfigSummaries_createServerFn_handler, async ({ context }) => {
	return RankTrackingRepository.getConfigSummaries(context.projectId);
});
var getScheduledRankChecksPaused_createServerFn_handler = createServerRpc({
	id: "2d12fc6a75afd97cb13d427976226e3dbfeb02b74b6ced8ab774e2b094fe37ec",
	name: "getScheduledRankChecksPaused",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => getScheduledRankChecksPaused.__executeServer(opts));
var getScheduledRankChecksPaused = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).handler(getScheduledRankChecksPaused_createServerFn_handler, () => isFeatureFlagOn(FeatureFlag.PauseScheduledRankChecks));
var createRankTrackingConfig_createServerFn_handler = createServerRpc({
	id: "258d28f360a42fb9dc6a60c60b05f23782f2fe2bf58c46d6e683b5d80693aadf",
	name: "createRankTrackingConfig",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => createRankTrackingConfig.__executeServer(opts));
var createRankTrackingConfig = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(createConfigSchema).handler(createRankTrackingConfig_createServerFn_handler, async ({ data, context }) => {
	const result = await RankTrackingService.createConfig({
		projectId: context.projectId,
		projectMarket: context.project,
		domain: data.domain,
		locationCode: data.locationCode,
		languageCode: data.languageCode,
		locationName: data.locationName,
		devices: data.devices,
		serpDepth: data.serpDepth,
		scheduleInterval: data.scheduleInterval,
		scheduleTime: data.scheduleTime
	});
	await runAutoCheck({
		configId: result.id,
		projectId: context.projectId,
		billingCustomer: context
	});
	await markOnboardingMilestone(context, "rankTrackingSetUp");
	waitUntil(captureServerEvent({
		distinctId: context.userId,
		event: "rank_tracking:config_create",
		organizationId: context.organizationId,
		properties: {
			project_id: context.projectId,
			devices: data.devices ?? "both",
			schedule: data.scheduleInterval ?? "weekly"
		}
	}));
	return result;
});
var updateRankTrackingConfig_createServerFn_handler = createServerRpc({
	id: "16b8b61d3cfc645bc36be38a136d9d7ad7096edf8550536a9b522e2833bd5c45",
	name: "updateRankTrackingConfig",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => updateRankTrackingConfig.__executeServer(opts));
var updateRankTrackingConfig = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(updateConfigSchema).handler(updateRankTrackingConfig_createServerFn_handler, async ({ data, context }) => {
	await RankTrackingService.updateConfig(data.configId, context.projectId, {
		domain: data.domain,
		locationCode: data.locationCode,
		languageCode: data.languageCode,
		locationName: data.locationName,
		devices: data.devices,
		serpDepth: data.serpDepth,
		scheduleInterval: data.scheduleInterval,
		scheduleTime: data.scheduleTime,
		isActive: data.isActive
	});
	return { success: true };
});
var triggerRankCheck_createServerFn_handler = createServerRpc({
	id: "0e2299d91fe830180a5418ad53dd35b4fca59a0bcbd2727c9f3eff6680a88592",
	name: "triggerRankCheck",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => triggerRankCheck.__executeServer(opts));
var triggerRankCheck = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(triggerCheckSchema).handler(triggerRankCheck_createServerFn_handler, async ({ data, context }) => {
	const result = await RankTrackingService.triggerCheck({
		configId: data.configId,
		projectId: context.projectId,
		billingCustomer: context,
		keywordIds: data.keywordIds
	});
	if (result.ok) waitUntil(captureServerEvent({
		distinctId: context.userId,
		event: "rank_tracking:check_trigger",
		organizationId: context.organizationId,
		properties: {
			project_id: context.projectId,
			config_id: data.configId,
			run_id: result.runId
		}
	}));
	return result;
});
var getLatestRankResults_createServerFn_handler = createServerRpc({
	id: "ddd165935e6b49d3557cb04d17f77f9775c81fbb0c0f735387a032421a266542",
	name: "getLatestRankResults",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => getLatestRankResults.__executeServer(opts));
var getLatestRankResults = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getLatestResultsSchema).handler(getLatestRankResults_createServerFn_handler, async ({ data, context }) => {
	return getLatestResults(data.configId, context.projectId, data.comparePeriod);
});
var getLatestRankRun_createServerFn_handler = createServerRpc({
	id: "e07b0dfacb31a403133cc5bf5e671e8b7735dd63c2c993749b4ecd399e779acb",
	name: "getLatestRankRun",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => getLatestRankRun.__executeServer(opts));
var getLatestRankRun = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getLatestRunSchema).handler(getLatestRankRun_createServerFn_handler, async ({ data, context }) => {
	return RankTrackingService.getLatestRun(data.configId, context.projectId);
});
var estimateRankCheckCost_createServerFn_handler = createServerRpc({
	id: "1e3e63b95fa90f1fafbcda79f9999a31747ab722474f0eae185243ffdd1b06ab",
	name: "estimateRankCheckCost",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => estimateRankCheckCost.__executeServer(opts));
var estimateRankCheckCost = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(estimateCostSchema).handler(estimateRankCheckCost_createServerFn_handler, async ({ data, context }) => {
	return RankTrackingService.estimateCost(data.configId, context.projectId);
});
function logAutoActionFailure(action, err) {
	const appErr = asAppError(err);
	if (appErr?.code === "PAYMENT_REQUIRED") console.info(`[rank-tracking] ${action} skipped: paid plan required`);
	else if (appErr?.code === "INSUFFICIENT_CREDITS") console.info(`[rank-tracking] ${action} skipped: insufficient credits`);
	else console.error(`[rank-tracking] ${action} failed:`, err);
}
async function runAutoCheck(input) {
	try {
		const result = await RankTrackingService.triggerAutoCheck(input);
		if (!result.ok && result.reason !== "no_keywords") console.info("[rank-tracking] auto-check skipped: %s", result.reason);
		return result;
	} catch (err) {
		logAutoActionFailure("auto-check", err);
		return null;
	}
}
var addTrackingKeywords_createServerFn_handler = createServerRpc({
	id: "9632bd92f3de61b172319c2b693ceaafbbc52f214ba2a4fb93531fefa5b96d74",
	name: "addTrackingKeywords",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => addTrackingKeywords.__executeServer(opts));
var addTrackingKeywords = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(addKeywordsSchema).handler(addTrackingKeywords_createServerFn_handler, async ({ data, context }) => {
	const result = await RankTrackingService.addKeywords(data.configId, context.projectId, data.keywords, { kind: "direct_user_action" }, data.matchCase);
	const autoCheck = result.addedIds.length > 0 ? await runAutoCheck({
		configId: data.configId,
		projectId: context.projectId,
		billingCustomer: context,
		keywordIds: result.addedIds
	}) : null;
	if (result.added > 0) try {
		await RankTrackingService.refreshKeywordMetrics(data.configId, context.projectId, context);
	} catch (err) {
		logAutoActionFailure("auto-metrics-refresh", err);
	}
	return {
		...result,
		checkTriggered: autoCheck?.ok ?? false,
		checkScheduledSoon: autoCheck?.ok === false && autoCheck.reason === "scheduled_soon"
	};
});
var removeTrackingKeywords_createServerFn_handler = createServerRpc({
	id: "d034f8888a5e1014831023cf2a868291cfd466101140d59d1f4251fd53203037",
	name: "removeTrackingKeywords",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => removeTrackingKeywords.__executeServer(opts));
var removeTrackingKeywords = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(removeKeywordsSchema).handler(removeTrackingKeywords_createServerFn_handler, async ({ data, context }) => {
	return RankTrackingService.removeKeywords(data.configId, context.projectId, data.keywordIds);
});
var setTrackingKeywordsPinned_createServerFn_handler = createServerRpc({
	id: "ca9c08a11ec01d215de1872722fd6d9aff065e1f082c6191040a443bd949a710",
	name: "setTrackingKeywordsPinned",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => setTrackingKeywordsPinned.__executeServer(opts));
var setTrackingKeywordsPinned = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(setKeywordsPinnedSchema).handler(setTrackingKeywordsPinned_createServerFn_handler, async ({ data, context }) => {
	return RankTrackingKeywordService.setKeywordsPinned(data.configId, context.projectId, data.keywordIds, data.pinned);
});
var refreshTrackingKeywordMetrics_createServerFn_handler = createServerRpc({
	id: "17c1167140bde128372935a660b28fd6e0e183774ca3f90271799ba787ecb243",
	name: "refreshTrackingKeywordMetrics",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => refreshTrackingKeywordMetrics.__executeServer(opts));
var refreshTrackingKeywordMetrics = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(refreshMetricsSchema).handler(refreshTrackingKeywordMetrics_createServerFn_handler, async ({ data, context }) => {
	const result = await RankTrackingService.refreshKeywordMetrics(data.configId, context.projectId, context);
	waitUntil(captureServerEvent({
		distinctId: context.userId,
		event: "rank_tracking:metrics_refresh",
		organizationId: context.organizationId,
		properties: {
			project_id: context.projectId,
			config_id: data.configId,
			updated: result.updated
		}
	}));
	return result;
});
var getRankKeywordHistory_createServerFn_handler = createServerRpc({
	id: "e808431fe24faa5cddaa82ff3cee05037bdd2ddd1ba1ceef693aac01ca8e68bc",
	name: "getRankKeywordHistory",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => getRankKeywordHistory.__executeServer(opts));
var getRankKeywordHistory = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getKeywordHistorySchema).handler(getRankKeywordHistory_createServerFn_handler, async ({ data, context }) => {
	await requireConfig(data.configId, context.projectId);
	return RankTrackingRepository.getKeywordHistory(data.configId, data.trackingKeywordId, data.sinceDays);
});
var getRankConfigTrend_createServerFn_handler = createServerRpc({
	id: "9da63329d53b960da32b79472469175d63f38b5e71bcef0cacabb66cba684931",
	name: "getRankConfigTrend",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => getRankConfigTrend.__executeServer(opts));
var getRankConfigTrend = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getConfigTrendSchema).handler(getRankConfigTrend_createServerFn_handler, async ({ data, context }) => {
	await requireConfig(data.configId, context.projectId);
	return (await RankTrackingRepository.getConfigTrend(data.configId, data.device, data.sinceDays)).map((row) => {
		const top3 = Number(row.top3) || 0;
		const top4to10 = Number(row.top4to10) || 0;
		const top11to20 = Number(row.top11to20) || 0;
		const total = Number(row.total) || 0;
		return {
			runId: row.runId,
			checkedAt: row.checkedAt,
			top3,
			top4to10,
			top11to20,
			notRanking: Math.max(0, total - top3 - top4to10 - top11to20),
			notChecked: Math.max(0, row.keywordsTotal - total)
		};
	});
});
var getRankPositionMatrix_createServerFn_handler = createServerRpc({
	id: "c6715a7072113d7f7ea076796cf28e47be1bab5e1dfd14502e72467efab53306",
	name: "getRankPositionMatrix",
	filename: "src/serverFunctions/rank-tracking.ts"
}, (opts) => getRankPositionMatrix.__executeServer(opts));
var getRankPositionMatrix = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getPositionMatrixSchema).handler(getRankPositionMatrix_createServerFn_handler, async ({ data, context }) => {
	await requireConfig(data.configId, context.projectId);
	return RankTrackingRepository.getPositionMatrix(data.configId, data.device, data.runLimit);
});
//#endregion
export { addTrackingKeywords_createServerFn_handler, createRankTrackingConfig_createServerFn_handler, estimateRankCheckCost_createServerFn_handler, getLatestRankResults_createServerFn_handler, getLatestRankRun_createServerFn_handler, getRankConfigTrend_createServerFn_handler, getRankKeywordHistory_createServerFn_handler, getRankPositionMatrix_createServerFn_handler, getRankTrackingConfigSummaries_createServerFn_handler, getRankTrackingConfigs_createServerFn_handler, getScheduledRankChecksPaused_createServerFn_handler, refreshTrackingKeywordMetrics_createServerFn_handler, removeTrackingKeywords_createServerFn_handler, setTrackingKeywordsPinned_createServerFn_handler, triggerRankCheck_createServerFn_handler, updateRankTrackingConfig_createServerFn_handler };
