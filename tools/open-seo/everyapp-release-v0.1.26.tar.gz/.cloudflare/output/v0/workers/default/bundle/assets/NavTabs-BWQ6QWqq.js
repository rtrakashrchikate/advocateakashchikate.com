import { n as createLink } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as cn } from "./dist-fVOGIv0D.js";
//#region src/client/components/NavTabs.tsx
var import_jsx_runtime = require_jsx_runtime();
/** A strip of router links styled as tabs, for pages with their own URL. */
function NavTabs({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		"aria-label": label,
		className: "flex gap-1 border-b border-border",
		children
	});
}
function NavTabAnchor({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className: cn("relative inline-flex h-9 items-center px-3 text-sm font-medium text-muted-foreground transition-colors outline-none hover:text-foreground focus-visible:rounded-md focus-visible:ring-3 focus-visible:ring-ring/50 data-[status=active]:text-foreground", "after:absolute after:inset-x-0 after:-bottom-px after:h-0.5 after:bg-foreground after:opacity-0 data-[status=active]:after:opacity-100", className),
		...props
	});
}
var NavTab = createLink(NavTabAnchor);
//#endregion
export { NavTabs as n, NavTab as t };
