import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { Et as _enum, Fn as object, Jn as string, xn as literal } from "./schemas-BPIpYT5n.js";
import { it as GSC_SELF_HOSTED_SETUP_DOCS_URL } from "./resolve-DrNDcpX6.js";
import { j as useQueryClient, t as useQuery } from "./useQuery-B93OR2NQ.js";
import { t as QueryError } from "./QueryState-Q8BZIblk.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { r as getStandardErrorMessage } from "./error-messages-D7nntGF_.js";
import { t as ChevronDown } from "./chevron-down-Bmgnw7hU.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as Plus } from "./plus-C1Kukp-u.js";
import { t as X } from "./x-CPPij64W.js";
import { i as AlertTitle, n as AlertAction, r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { t as createSsrRpc } from "./createSsrRpc-Vp3C13VD.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
import { c as reportGoogleLinkErrorOnce, o as clearGoogleLinkError, s as getGoogleLinkError } from "./googleProviders-BsIoKvco.js";
import { n as Spinner } from "./Spinner-NR-t-8YM.js";
import { t as googleAuthErrorCopy } from "./googleAuthErrorCopy-p_IR_8l4.js";
import { a as PopoverTitle, i as PopoverHeader, n as PopoverContent, o as PopoverTrigger, r as PopoverDescription, t as Popover } from "./popover-DZ7jxG4_.js";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C8cX1CPK.js";
import { a as ComboboxCollection, c as ComboboxGroup, d as ComboboxLabel, f as ComboboxList, l as ComboboxInput, o as ComboboxContent, s as ComboboxEmpty, t as Combobox, u as ComboboxItem } from "./combobox-BYdKkOBU.js";
//#region src/client/features/integrations/GoogleLinkErrorAlert.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var PROVIDER_LABELS = {
	gsc: "Search Console",
	ga4: "Google Analytics"
};
/**
* Inline error shown on a connect surface after a failed Google link flow.
* The OAuth callback sends failures back to the page that started the connect
* (see googleOAuth.ts); googleLinkError.ts captures the params before the
* router can redirect them away, and this renders the explanation next to the
* Connect button that retries it. Persists until dismissed or the user
* navigates.
*/
function GoogleLinkErrorAlert({ provider, className }) {
	const [error] = import_react.useState(() => getGoogleLinkError(provider));
	const [dismissed, setDismissed] = import_react.useState(false);
	import_react.useEffect(() => {
		if (error) reportGoogleLinkErrorOnce();
	}, [error]);
	if (!error || dismissed) return null;
	const copy = googleAuthErrorCopy(error.code, PROVIDER_LABELS[provider]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "destructive",
		className,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: copy.title }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: copy.description }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertAction, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon-xs",
				"aria-label": "Dismiss",
				onClick: () => {
					setDismissed(true);
					clearGoogleLinkError();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
			}) })
		]
	});
}
//#endregion
//#region src/client/features/integrations/GscPropertySetupHelp.tsx
function GscPropertySetupHelp({ accounts, loading, busy, linking, onRetry, onReconnect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3 rounded-lg border border-border bg-muted/30 p-4 text-sm",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-semibold",
				children: "We couldn\u2019t find your website"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "break-words text-muted-foreground",
				children: [
					"We checked",
					" ",
					accounts.map((account) => account.email ?? `Google account \u00B7 ${account.accountId.slice(-6)}`).join(", "),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-muted-foreground",
				children: [
					"Add your site to Search Console, or ask whoever manages it to give",
					accounts.length === 1 ? " this account" : " one of these accounts",
					" ",
					"access."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-x-4 gap-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://search.google.com/search-console",
					target: "_blank",
					rel: "noopener noreferrer",
					className: "underline underline-offset-4",
					children: "Open Search Console \u2197"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://openseo.so/blogs/google-search-console-setup",
					target: "_blank",
					rel: "noopener noreferrer",
					className: "underline underline-offset-4",
					children: "Setup guide"
				})]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			size: "sm",
			onClick: onRetry,
			disabled: loading || busy,
			children: loading ? "Refreshing\u2026" : "Refresh"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "sm",
			onClick: onReconnect,
			disabled: loading || busy,
			pending: linking,
			children: linking ? "Opening Google\u2026" : "Use a different Google account"
		})]
	})] });
}
function hasNoGscWebsites(accounts, loading, error) {
	return !loading && !error && accounts.length > 0 && accounts.every((account) => !account.requiresReconnect && !account.unavailable && account.properties.length === 0);
}
//#endregion
//#region src/client/features/integrations/GoogleAccounts.tsx
function accountLabel(account) {
	return account.email ?? `Google account \u00B7 ${account.accountId.slice(-6)}`;
}
function accountStatus(account, provider) {
	if (account.requiresReconnect) return "Connection expired";
	if (account.unavailable) return account.apiDisabled ? "Search Console API isn't enabled" : "Couldn't load properties";
	if (account.properties.length === 0) return provider === "gsc" ? "No websites found" : "No properties found";
	return null;
}
function needsAttention(account) {
	return account.requiresReconnect || Boolean(account.unavailable);
}
/**
* The Google accounts under the property field. People rarely manage them,
* so the list sits behind a one-line popover trigger. Accounts that need a
* reconnect or retry stay in view, since they explain missing properties.
* `inline` shows the whole list, for viewers who can only manage accounts.
*/
function GoogleAccounts({ inline, ...props }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	if (inline) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountList, { ...props });
	if (props.accounts.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddAccountButton, { ...props });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1",
		children: [props.loading ? null : props.accounts.filter(needsAttention).map((account) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountRow, {
			...props,
			account,
			onRemove: void 0
		}, account.accountId)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Popover, {
			open,
			onOpenChange: setOpen,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverTrigger, {
				render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "xs",
					className: "-ml-2 max-w-full text-muted-foreground"
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: props.accounts.length === 1 ? accountLabel(props.accounts[0]) : `${props.accounts.length} Google accounts`
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3.5 shrink-0" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverContent, {
				align: "start",
				className: "w-80",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PopoverHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverTitle, { children: "Google accounts" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PopoverDescription, { children: "Properties come from these accounts." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountList, {
					...props,
					onRemove: (account) => {
						setOpen(false);
						props.onRemove(account);
					}
				})]
			})]
		})]
	});
}
function AccountList(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1",
		children: [props.accounts.map((account) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountRow, {
			...props,
			account,
			onRemove: () => props.onRemove(account)
		}, account.accountId)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddAccountButton, { ...props })]
	});
}
function AddAccountButton({ linking, saving, onReconnect }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "ghost",
		size: "xs",
		className: "-ml-2",
		onClick: onReconnect,
		disabled: saving || linking,
		pending: linking,
		children: [linking ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), linking ? "Opening Google\u2026" : "Add Google account"]
	}) });
}
function AccountRow({ account, provider, loading, linking, saving, onReconnect, onRetry, onRemove }) {
	const label = accountLabel(account);
	const status = loading ? null : accountStatus(account, provider);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center justify-between gap-x-3 gap-y-1 text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0 break-all",
			children: [
				label,
				status ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-muted-foreground",
					children: [" \u00B7 ", status]
				}) : null,
				account.apiDisabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `${GSC_SELF_HOSTED_SETUP_DOCS_URL}#troubleshooting`,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "underline underline-offset-4",
					children: "How to enable it \u2197"
				})] }) : null
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex shrink-0 items-center",
			children: [account.requiresReconnect ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "xs",
				onClick: onReconnect,
				"aria-label": `Reconnect ${label}`,
				disabled: linking,
				"aria-busy": linking,
				children: linking ? "Opening Google\u2026" : "Reconnect"
			}) : account.unavailable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "xs",
				onClick: onRetry,
				"aria-label": `Retry ${label}`,
				children: "Try again"
			}) : null, onRemove ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "xs",
				className: "text-muted-foreground hover:text-destructive",
				disabled: saving,
				onClick: onRemove,
				"aria-label": `Remove ${label}`,
				children: "Remove"
			}) : null]
		})]
	});
}
//#endregion
//#region src/serverFunctions/googleAccounts.ts
var accountSchema = object({
	provider: _enum(["gsc", "ga4"]),
	accountId: string().min(1)
});
var getGoogleAccountRemovalImpact = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(accountSchema).handler(createSsrRpc("c1ed1bc6e0cd3fb1ff5741765a7752d9bb54f9e240f6d82b76251789102af69f"));
var removeGoogleAccount = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(accountSchema.extend({ confirmed: literal(true) })).handler(createSsrRpc("97f60b5e66484cee89a92a95c9026d73eb41370f8bbed1e07a16530b77daf61f"));
//#endregion
//#region src/client/features/integrations/GoogleAccountRemovalDialog.tsx
function GoogleAccountRemovalDialog({ provider, accountId, label, onClose, onRemoved }) {
	const queryClient = useQueryClient();
	const impact = useQuery({
		queryKey: [
			"googleAccountRemovalImpact",
			provider,
			accountId
		],
		queryFn: () => getGoogleAccountRemovalImpact({ data: {
			provider,
			accountId
		} }),
		staleTime: 0,
		gcTime: 0
	});
	const removal = useMutation({
		meta: { errorToast: false },
		mutationFn: () => removeGoogleAccount({ data: {
			provider,
			accountId,
			confirmed: true
		} }),
		onSuccess: async () => {
			const keys = provider === "gsc" ? [
				"gscConnection",
				"gscSites",
				"gscGrantStatus",
				"searchPerformance",
				"searchPerformanceTable",
				"dashboardGscReport",
				"dashboardActivation"
			] : [
				"ga4Connection",
				"ga4Properties",
				"dashboardGa4Report",
				"dashboardActivation"
			];
			await Promise.all(keys.map((key) => queryClient.invalidateQueries({ queryKey: [key] })));
			toast.success("Google account removed");
			onRemoved();
		}
	});
	const name = provider === "gsc" ? "Search Console" : "Google Analytics";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => {
			if (!open && !removal.isPending) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-md",
			showCloseButton: false,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Remove Google account?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					"This removes the account\u2019s ",
					name,
					" connection from OpenSEO. You can reconnect it anytime."
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "break-all text-sm font-medium",
					children: label
				}),
				impact.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "status",
					className: "text-sm text-muted-foreground",
					children: "Checking connected projects\u2026"
				}) : impact.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					role: "alert",
					className: "text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-destructive",
						children: "Couldn't check connected projects."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => void impact.refetch(),
						children: "Try again"
					})]
				}) : impact.data.projectCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-medium",
					children: [
						"This will also disconnect ",
						name,
						" from ",
						impact.data.projectCount,
						" ",
						"project",
						impact.data.projectCount === 1 ? "" : "s",
						"."
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No projects will be affected."
				}),
				removal.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-sm text-destructive",
					children: getStandardErrorMessage(removal.error)
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					disabled: removal.isPending,
					onClick: onClose,
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "destructive",
					size: "sm",
					disabled: !impact.isSuccess || impact.isFetching || removal.isPending,
					onClick: () => removal.mutate(),
					children: removal.isPending ? "Removing\u2026" : "Remove account"
				})] })
			]
		})
	});
}
//#endregion
//#region src/client/features/integrations/GooglePropertyPicker.tsx
var GSC_SETUP_GUIDE_URL = "https://openseo.so/blogs/google-search-console-setup";
function matchesProperty(option, query) {
	return `${option.name} ${option.detail ?? ""} ${option.id}`.toLowerCase().includes(query.trim().toLowerCase());
}
function GooglePropertyPicker({ provider, readOnly = false, loading, linking = false, error, accounts, selection, onSelect, onSave, saving, saveLabel = "Save property", onRetry, onReconnect, secondaryAction, renderActions }) {
	const [removing, setRemoving] = (0, import_react.useState)(null);
	const groups = accounts.filter((account) => account.properties.length > 0).map((account) => ({
		accountId: account.accountId,
		label: accountLabel(account),
		items: account.properties.map((property) => ({
			...property,
			accountId: account.accountId,
			propertyId: property.id
		}))
	}));
	const options = groups.flatMap((group) => group.items);
	const selected = options.find((option) => option.accountId === selection?.accountId && option.propertyId === selection?.propertyId) ?? null;
	const canSave = Boolean(selected?.selectable) && !loading && !error;
	const emptyGsc = provider === "gsc" && hasNoGscWebsites(accounts, loading, error);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			removing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleAccountRemovalDialog, {
				provider,
				accountId: removing.accountId,
				label: accountLabel(removing),
				onClose: () => setRemoving(null),
				onRemoved: () => {
					if (selection?.accountId === removing.accountId) onSelect(null);
					setRemoving(null);
				}
			}) : null,
			emptyGsc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GscPropertySetupHelp, {
				accounts,
				loading,
				busy: saving || linking,
				linking,
				onRetry,
				onReconnect
			}) : null,
			!emptyGsc || readOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					readOnly ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Manage Google accounts"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-sm font-medium",
						children: "Choose property"
					}), loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {
						size: "sm",
						label: "Loading properties\u2026"
					}) : error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
						fallback: "Couldn't load properties.",
						onRetry
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Combobox, {
						items: groups,
						value: selected,
						itemToStringLabel: (option) => option.name,
						isItemEqualToValue: (option, value) => option.accountId === value.accountId && option.propertyId === value.propertyId,
						filter: matchesProperty,
						autoHighlight: true,
						onValueChange: (option) => {
							if (option) onSelect({
								accountId: option.accountId,
								propertyId: option.propertyId
							});
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxInput, {
							className: "w-full",
							placeholder: "Select a property\u2026",
							"aria-label": "Search properties",
							disabled: saving
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxEmpty, { children: options.length > 0 ? "No matching properties." : "No properties available. Check the Google accounts below." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxList, { children: (group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxGroup, {
							items: group.items,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxLabel, {
								className: "break-all",
								children: group.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxCollection, { children: (option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxItem, {
								value: option,
								disabled: !option.selectable,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block break-words",
											children: option.name
										}),
										option.detail ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs text-muted-foreground",
											children: option.detail
										}) : null,
										!option.selectable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs",
											children: provider === "gsc" ? "Ask the property owner for Full access, or verify ownership in Search Console." : "No verified access"
										}) : null
									]
								})
							}, `${option.accountId} ${option.id}`) })]
						}, group.accountId) })] })]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleAccounts, {
						inline: readOnly,
						accounts,
						provider,
						loading,
						linking,
						saving,
						onReconnect,
						onRetry,
						onRemove: setRemoving
					}),
					provider === "gsc" && !loading && !emptyGsc && accounts.some((account) => accountStatus(account, provider) !== null) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							"Having trouble?",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: GSC_SETUP_GUIDE_URL,
								target: "_blank",
								rel: "noopener noreferrer",
								className: "underline underline-offset-4",
								children: "Setup guide \u2197"
							})
						]
					}) : null
				]
			}) : null,
			renderActions ? renderActions(!canSave || saving) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-1",
				children: [readOnly ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: onSave,
					disabled: !canSave || saving,
					children: saving ? "Saving\u2026" : saveLabel
				}), secondaryAction ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "sm",
					disabled: saving || secondaryAction.disabled,
					onClick: secondaryAction.onClick,
					children: secondaryAction.label
				}) : null]
			})
		]
	});
}
//#endregion
export { hasNoGscWebsites as n, GoogleLinkErrorAlert as r, GooglePropertyPicker as t };
