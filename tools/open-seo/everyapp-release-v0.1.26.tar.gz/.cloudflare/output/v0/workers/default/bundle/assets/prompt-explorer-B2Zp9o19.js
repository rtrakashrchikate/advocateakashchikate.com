import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { Fn as object, Jn as string, Lt as boolean, Nt as array } from "./schemas-BPIpYT5n.js";
import { s as t } from "./r2-cache-DRcgqCM_.js";
import { t as e } from "./identity-41c0vDC1.js";
import { i as supportsWebSearchCountry, n as ignoresWebSearchCountry, r as projectWebSearchCountry, t as WEB_SEARCH_COUNTRY_CODES } from "./prompt-search-countries-DwmF4BXn.js";
import { a as remarkGfm } from "./lib-whvfvsPY.js";
import { r as Markdown, t as MARKDOWN_COMPONENTS } from "./Markdown-kD1IlFSX.js";
import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { _ as CircleAlert, c as Skeleton } from "./QueryState-Q8BZIblk.js";
import { n as createLucideIcon, t as cn } from "./dist-fVOGIv0D.js";
import { t as ChevronDown } from "./chevron-down-Bmgnw7hU.js";
import { b as ChevronUp } from "./resolveAriaLabelledBy-GDrxn-Sb.js";
import { t as CircleCheck } from "./circle-check-BGTFRkka.js";
import { t as CircleX } from "./circle-x-CaPvgutn.js";
import { n as AiResearchSetupGate, t as ProjectWebsiteGate } from "./ProjectWebsiteGate-Bm5vqOti.js";
import { t as ExternalLink } from "./external-link-HZIbqzY5.js";
import { t as Globe } from "./globe-CcyiZQla.js";
import { n as RecentSearches } from "./useLocalHistoryStore-h4ZxP0MM.js";
import { t as Info } from "./info-DgK-a8-X.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as MessageSquare } from "./message-square-C0Mxfw3u.js";
import { t as Checkbox } from "./checkbox-CdxmE4wQ.js";
import { t as Sparkles } from "./sparkles-BtdH_814.js";
import { r as CardContent, t as Card } from "./card-CqQO-5bL.js";
import { t as Badge } from "./badge-B9fV075d.js";
import { a as PromptTrackingWithoutUpgradeButton } from "./shared-BW7GMYqD.js";
import { c as promptExplorerModelSchema, d as webSearchCountrySelectionSchema, t as PROMPT_EXPLORER_MODELS } from "./ai-search-BKw5OSiv.js";
import { t as Route } from "./prompt-explorer-D-Kpszer.js";
import { t as Input } from "./input-B1cALAbz.js";
import { n as BackLink } from "./PageHeader-a3_4WaC8.js";
import { t as Label } from "./label-JSQAcpYi.js";
import { a as FieldLabel, o as FieldLegend, r as FieldDescription, s as FieldSet, t as Field } from "./field-CjRT_5Cr.js";
import { t as Textarea } from "./textarea-CsL-KvnQ.js";
import { n as TooltipContent, r as TooltipTrigger, t as Tooltip } from "./tooltip-D5ss-ZNP.js";
import { f as ComboboxList, l as ComboboxInput, o as ComboboxContent, s as ComboboxEmpty, t as Combobox, u as ComboboxItem } from "./combobox-BYdKkOBU.js";
import { n as CollapsibleContent, r as CollapsibleTrigger, t as Collapsible } from "./collapsible-C81XyjKp.js";
import { t as useHostedPlanGate } from "./HostedPlanGate-DjbmgzY5.js";
import { c as PROMPT_EXPLORER_STALE_TIME_MS, l as buildPromptExplorerQueryKey, n as useSearchTabNavigation, r as SearchTabStrip, u as promptExplorerQueryFn } from "./useSearchTabNavigation-BkfjRe_u.js";
import { c as ResearchPageShell, n as ExpandableList, s as getModelAccent, t as useTimestampedSearchHistory } from "./useTimestampedSearchHistory-Bl0Pbhrw.js";
import { n as formatUrlForDisplay } from "./url-CqteAjL5.js";
import { t as useProjectMarket } from "./useProjectMarket-DMO-4o34.js";
import { n as formatModelLabel, t as formatCountryLabel } from "./prompt-explorer-labels-QY61Qix6.js";
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Columns3 = createLucideIcon("columns-3", [
	["rect", {
		width: "18",
		height: "18",
		x: "3",
		y: "3",
		rx: "2",
		key: "afitv7"
	}],
	["path", {
		d: "M9 3v18",
		key: "fh3hqa"
	}],
	["path", {
		d: "M15 3v18",
		key: "14nvp0"
	}]
]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var SearchCheck = createLucideIcon("search-check", [
	["path", {
		d: "m8 11 2 2 4-4",
		key: "1sed1v"
	}],
	["circle", {
		cx: "11",
		cy: "11",
		r: "8",
		key: "4ej97u"
	}],
	["path", {
		d: "m21 21-4.3-4.3",
		key: "1qie3q"
	}]
]);
//#endregion
//#region src/client/features/ai-search/components/PromptExplorerForm.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var COUNTRY_ITEMS = [{
	value: "default",
	label: "No country preference"
}, ...t(WEB_SEARCH_COUNTRY_CODES.map((code) => ({
	value: code,
	label: formatCountryLabel(code)
})), (item) => item.label)];
function getCountryNote(model, form) {
	if (!form.webSearch || form.webSearchCountryCode === "default") return null;
	const label = formatModelLabel(model);
	if (ignoresWebSearchCountry(model)) return `${label} can\u2019t specify a country.`;
	if (supportsWebSearchCountry(model, form.webSearchCountryCode)) return null;
	return `${label} can\u2019t specify this country.`;
}
function PromptExplorerForm({ form, onPromptChange, onHighlightBrandChange, onModelsChange, onWebSearchChange, onCountryChange, onSubmit, validationError }) {
	const toggleModel = (model) => {
		if (form.models.includes(model)) onModelsChange(form.models.filter((m) => m !== model));
		else onModelsChange([...form.models, model]);
	};
	const countryItems = COUNTRY_ITEMS.filter((item) => item.value === "default" || item.value === form.webSearchCountryCode || form.models.some((model) => supportsWebSearchCountry(model, item.value)));
	const unsupportedModels = form.webSearch && form.webSearchCountryCode !== "default" ? PROMPT_EXPLORER_MODELS.filter((model) => !ignoresWebSearchCountry(model) && !supportsWebSearchCountry(model, form.webSearchCountryCode)) : [];
	const supportedModels = form.models.filter((model) => !unsupportedModels.includes(model));
	const promptCharCount = form.prompt.length;
	const promptOverLimit = promptCharCount > 500;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit,
		noValidate: true,
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "prompt-explorer-prompt",
					children: "Prompt"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					id: "prompt-explorer-prompt",
					className: "resize-none",
					rows: 3,
					value: form.prompt,
					maxLength: 550,
					onChange: (event) => onPromptChange(event.target.value),
					"aria-invalid": promptOverLimit ? true : void 0,
					autoFocus: true
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldDescription, {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "What your customers might ask AI." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: cn("tabular-nums", promptOverLimit && "font-medium text-destructive"),
						children: [
							promptCharCount,
							"/",
							500
						]
					})]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 gap-5 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "prompt-explorer-brand",
						children: "Highlight brand (optional)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "prompt-explorer-brand",
						value: form.highlightBrand,
						onChange: (event) => onHighlightBrandChange(event.target.value),
						autoComplete: "off",
						spellCheck: false
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: "We'll flag whether each model mentions this brand." })
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldSet, {
					className: "gap-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLegend, {
						variant: "label",
						className: "mb-2",
						children: "Models"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap items-center gap-x-5 gap-y-2 pt-1.5",
						children: PROMPT_EXPLORER_MODELS.map((model) => {
							const unsupported = unsupportedModels.includes(model);
							const countryNote = getCountryNote(model, form);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
									className: cn("font-normal", unsupported && "cursor-not-allowed text-muted-foreground"),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
										checked: form.models.includes(model) && !unsupported,
										disabled: unsupported,
										onCheckedChange: () => toggleModel(model)
									}), formatModelLabel(model)]
								}), countryNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
									render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": `About ${formatModelLabel(model)} and country targeting`,
										className: "text-muted-foreground"
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-3.5" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: countryNote })] }) : null]
							}, model);
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
							className: "font-normal",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
								checked: form.webSearch,
								onCheckedChange: onWebSearchChange
							}), "Allow web search"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Combobox, {
							items: countryItems,
							value: COUNTRY_ITEMS.find((item) => item.value === form.webSearchCountryCode) ?? null,
							itemToStringLabel: (item) => item.label,
							autoHighlight: true,
							onValueChange: (item) => {
								if (item) onCountryChange(item.value);
							},
							disabled: !form.webSearch,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxInput, {
								"aria-label": "Web search country",
								placeholder: "Search countries",
								className: "w-full sm:w-80"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxEmpty, { children: "No supported countries match." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxList, { children: (item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxItem, {
								value: item,
								children: item.label
							}, item.value) })] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
							render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": "About country targeting",
								className: "text-muted-foreground"
							}),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, { className: "size-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: "A country guides web search when a model supports it. Models may answer without searching. Leave it unset to run all selected models." })] })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "submit",
					className: "px-6",
					disabled: supportedModels.length === 0,
					children: [
						"Run ",
						supportedModels.length,
						" ",
						supportedModels.length === 1 ? "model" : "models"
					]
				})]
			}),
			validationError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				role: "alert",
				className: "text-sm text-destructive",
				children: validationError
			}) : null
		]
	}) }) });
}
//#endregion
//#region src/client/features/ai-search/components/PromptExplorerLoadingState.tsx
function PromptExplorerLoadingState({ models }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-5",
		"aria-busy": "true",
		"aria-label": "Loading answers",
		children: models.map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: cn("overflow-hidden rounded-r-lg border border-l-4 border-border bg-card", getModelAccent(model).border),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-2 border-b border-border bg-muted/40 px-5 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("size-2 rounded-full", getModelAccent(model).dot) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-semibold",
								children: formatModelLabel(model)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-24" })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-16" })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2.5 px-5 py-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-3/4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-full" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-11/12" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-5/6" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-2/3" })
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2 border-t border-border px-5 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-28" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-1/2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-2/5" })
					]
				})
			]
		}, model))
	});
}
//#endregion
//#region src/client/features/ai-search/components/MarkdownAnswer.tsx
/**
* Collapsed-state max height in px. Roughly 9 lines of body text \u2014 enough
* to convey the shape of an answer without dominating the page when four
* models are stacked.
*/
var COLLAPSED_MAX_PX = 240;
/**
* Render an LLM's markdown answer with explicit per-element Tailwind classes.
*
* Long answers collapse to ~12 lines with a fade-out gradient and a
* "Read more" toggle so a side-by-side comparison of four models stays
* scannable. We measure the rendered scroll height to decide whether the
* toggle is needed.
*
* Anchor URLs are sanitized to http(s) only \u2014 LLMs can be coaxed into
* emitting `javascript:` payloads.
*/
function MarkdownAnswer({ text }) {
	const contentRef = (0, import_react.useRef)(null);
	const [expanded, setExpanded] = (0, import_react.useState)(false);
	const [needsCollapse, setNeedsCollapse] = (0, import_react.useState)(false);
	const { thinking, body } = extractThinkingBlocks(text);
	const normalized = normalizeLlmMarkdown(body);
	(0, import_react.useLayoutEffect)(() => {
		const el = contentRef.current;
		if (!el) return;
		setNeedsCollapse(el.scrollHeight > 248);
	}, [normalized]);
	if (normalized.trim().length === 0 && thinking.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground italic",
		children: "Model returned an empty response."
	});
	const isCollapsed = needsCollapse && !expanded;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-sm leading-relaxed",
		children: [
			thinking.map((block, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThinkingBlock, { text: block }, index)),
			normalized.trim().length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					ref: contentRef,
					style: isCollapsed ? { maxHeight: `${COLLAPSED_MAX_PX}px` } : void 0,
					className: isCollapsed ? "overflow-hidden" : void 0,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, {
						remarkPlugins: [remarkGfm],
						components: MARKDOWN_COMPONENTS,
						children: normalized
					})
				}), isCollapsed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					"aria-hidden": true,
					className: "pointer-events-none absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-card to-transparent"
				}) : null]
			}) : null,
			needsCollapse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "link",
				size: "xs",
				onClick: () => setExpanded((prev) => !prev),
				className: "mt-2 h-auto px-0",
				"aria-expanded": expanded,
				children: expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, { "data-icon": "inline-start" }), "Show less"] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { "data-icon": "inline-start" }), "Read more"] })
			}) : null
		]
	});
}
function ThinkingBlock({ text }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Collapsible, {
		defaultOpen: true,
		className: "mb-3 rounded-lg border border-border bg-muted/40",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CollapsibleTrigger, {
			className: "group flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-medium text-muted-foreground outline-none hover:text-foreground focus-visible:ring-3 focus-visible:ring-ring/50",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "size-3.5 transition-transform group-data-panel-open:rotate-180" }), "Model Thinking"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollapsibleContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "overflow-x-auto rounded-b-lg border-t border-border bg-muted/60 px-3 py-2.5 font-mono text-xs break-words whitespace-pre-wrap text-foreground/80",
			children: text
		}) })]
	});
}
/**
* Reasoning models (e.g. Perplexity sonar-reasoning-pro) wrap their chain of
* thought in `<think>...</think>` tags inline with the answer. Pull those out
* so we can render them in a separate, collapsible block.
*
* Tolerates an unclosed final `<think>` (e.g. from a truncated stream) by
* treating everything after it as a thinking block.
*/
function extractThinkingBlocks(text) {
	const thinking = [];
	let body = text;
	body = body.replace(/<think>([\s\S]*?)<\/think>/gi, (_, inner) => {
		thinking.push(inner.trim());
		return "";
	});
	body = body.replace(/<think>([\s\S]*)$/i, (_, inner) => {
		thinking.push(inner.trim());
		return "";
	});
	return {
		thinking,
		body
	};
}
/**
* Fix a class of malformed markdown we see from LLM responses: a list marker
* (`-`, `*`, `+`, or `1.`) on a line by itself, followed by a blank line,
* followed by the actual item content as a separate paragraph. Default
* markdown correctly renders that as an empty bullet + detached paragraph,
* which looks broken. Collapse the blank line so the marker and content
* form a proper list item.
*/
function normalizeLlmMarkdown(text) {
	return text.replace(/^([ \t]*)([-*+]|\d+\.)[ \t]*\r?\n[ \t]*\r?\n(?=\S)(?![ \t]*(?:[-*+]|\d+\.)[ \t])/gm, "$1$2 ");
}
//#endregion
//#region src/client/features/ai-search/components/PromptExplorerResults.tsx
var ARTICLE_CLASS = "overflow-hidden rounded-r-lg border border-l-4 border-border bg-card";
function PromptExplorerResults({ result }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-5",
		children: result.results.map((modelResult) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModelResultCard, {
			modelResult,
			highlightBrand: result.highlightBrand
		}, modelResult.model))
	});
}
function ModelResultCard({ modelResult, highlightBrand }) {
	const accent = getModelAccent(modelResult.model);
	if (modelResult.status === "error") {
		const skipped = modelResult.errorCode === "UNSUPPORTED_COUNTRY";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: cn(ARTICLE_CLASS, accent.border),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModelHeader, {
				model: modelResult.model,
				modelName: null,
				tokens: null,
				webSearch: null,
				brandMentioned: null,
				highlightBrand: null,
				status: skipped ? "skipped" : "error"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("flex items-start gap-2 px-5 py-4 text-sm", skipped ? "text-muted-foreground" : "text-destructive"),
				children: [!skipped ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "mt-0.5 size-4 shrink-0" }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: modelResult.message })]
			})]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn(ARTICLE_CLASS, accent.border),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModelHeader, {
				model: modelResult.model,
				modelName: modelResult.modelName,
				tokens: modelResult.outputTokens,
				webSearch: modelResult.webSearch,
				brandMentioned: modelResult.brandMentioned,
				highlightBrand,
				status: "success"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "px-5 pt-3 text-xs text-muted-foreground",
				children: modelResult.webSearchCountryCode ? `Country hint sent: ${formatCountryLabel(modelResult.webSearchCountryCode)}. This is not a verified search location.` : "No country hint sent. Any search uses the provider\u2019s default location."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-5 py-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkdownAnswer, { text: modelResult.text })
			}),
			modelResult.citations.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CitationsList, {
				citations: modelResult.citations,
				highlightBrand
			}) : null,
			modelResult.fanOutQueries.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border px-5 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs font-medium tracking-wider text-muted-foreground uppercase",
					children: "Related queries the model considered"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: modelResult.fanOutQueries.map((query, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "outline",
						className: "font-normal text-muted-foreground",
						children: query
					}, `${query}-${index}`))
				})]
			}) : null
		]
	});
}
function CitationsList({ citations, highlightBrand }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-border bg-muted/30 px-5 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mb-2 text-xs font-medium tracking-wider text-muted-foreground uppercase",
			children: [
				"Cited sources (",
				citations.length,
				")"
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpandableList, {
			items: citations,
			className: "space-y-1.5",
			renderItem: (citation, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-start gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 size-1 shrink-0 rounded-full bg-foreground/30" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: citation.url,
						target: "_blank",
						rel: "noreferrer",
						className: `inline-flex items-start gap-1 underline underline-offset-2 ${citation.matchedBrand ? "font-medium text-primary" : ""}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "break-all",
							children: citation.title || formatUrlForDisplay(citation.url)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "mt-1 size-3 shrink-0" })]
					}),
					citation.matchedBrand && highlightBrand ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						size: "sm",
						children: highlightBrand
					}) : null
				]
			}, `${citation.url}-${index}`)
		})]
	});
}
function ModelHeader({ model, modelName, tokens, webSearch, brandMentioned, highlightBrand, status }) {
	const accent = getModelAccent(model);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex flex-wrap items-center justify-between gap-2 border-b border-border bg-muted/40 px-5 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-2 rounded-full ${accent.dot}` }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: formatModelLabel(model)
				}),
				modelName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
					className: "text-xs text-muted-foreground",
					children: modelName
				}) : null,
				status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "destructive",
					children: "Error"
				}) : null,
				status === "skipped" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "secondary",
					children: "Skipped"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMentionBadge, {
					mentioned: brandMentioned,
					highlightBrand
				}),
				webSearch ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-3" }), "web search"]
				}) : webSearch === false ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-1 text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Globe, { className: "size-3" }), "no web search"]
				}) : null
			]
		}), tokens != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-xs text-muted-foreground tabular-nums",
			children: [tokens.toLocaleString(), " tokens"]
		}) : null]
	});
}
function BrandMentionBadge({ mentioned, highlightBrand }) {
	if (mentioned == null || !highlightBrand) return null;
	if (mentioned) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
		variant: "success",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { "data-icon": "inline-start" }), highlightBrand]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
		variant: "secondary",
		className: "font-normal text-muted-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { "data-icon": "inline-start" }),
			"no ",
			highlightBrand
		]
	});
}
//#endregion
//#region src/client/hooks/usePromptExplorerSearchHistory.ts
var promptExplorerSearchBodySchema = object({
	prompt: string(),
	highlightBrand: string(),
	models: array(promptExplorerModelSchema),
	webSearch: boolean(),
	webSearchCountryCode: webSearchCountrySelectionSchema
});
function sameModels(a, b) {
	if (a.length !== b.length) return false;
	const sortedA = t(a, e());
	const sortedB = t(b, e());
	return sortedA.every((model, index) => model === sortedB[index]);
}
function isSameSearch(a, b) {
	return a.prompt === b.prompt && a.highlightBrand === b.highlightBrand && a.webSearch === b.webSearch && a.webSearchCountryCode === b.webSearchCountryCode && sameModels(a.models, b.models);
}
function usePromptExplorerSearchHistory(projectId) {
	return useTimestampedSearchHistory({
		storageKey: `prompt-explorer-search-history:${projectId}`,
		bodySchema: promptExplorerSearchBodySchema,
		isSame: isSameSearch
	});
}
//#endregion
//#region src/client/features/ai-search/PromptExplorerPage.tsx
var PROMPT_EXPLORER_BULLETS = [
	{
		icon: Columns3,
		title: "Four models side-by-side",
		body: "Run one prompt across ChatGPT, Claude, Gemini, and Perplexity and compare answers in a single view."
	},
	{
		icon: SearchCheck,
		title: "See what the models cite",
		body: "Every answer lists the sources it drew from, so you can audit where each model gets its information."
	},
	{
		icon: Sparkles,
		title: "Check brand mentions",
		body: "Highlight a brand to instantly see whether it shows up in the answer text or the cited sources."
	}
];
function promptTabLabel(input) {
	if (input.type !== "prompt") return "";
	return input.models.length > 1 ? `${input.prompt} \u00B7 ${input.models.length} models` : input.prompt;
}
function PromptExplorerPage({ projectId, urlState, onSubmit, onClear }) {
	const planStatus = useHostedPlanGate();
	const [form, setForm] = (0, import_react.useState)(urlState);
	const [validationError, setValidationError] = (0, import_react.useState)(null);
	const { history, isLoaded: historyLoaded, addSearch, removeHistoryItem } = usePromptExplorerSearchHistory(projectId);
	const trimmedPrompt = urlState.prompt.trim();
	const hasActivePrompt = trimmedPrompt.length > 0;
	const urlInput = (0, import_react.useMemo)(() => {
		const prompt = urlState.prompt.trim();
		if (!prompt) return null;
		return {
			type: "prompt",
			...urlState,
			prompt,
			highlightBrand: urlState.highlightBrand.trim()
		};
	}, [urlState]);
	const searchTabs = useSearchTabNavigation({
		storageKey: `prompt-explorer:${projectId}`,
		urlInput,
		getLabel: promptTabLabel,
		navigateToInput: (0, import_react.useCallback)((input) => {
			if (input?.type !== "prompt") {
				onClear();
				return;
			}
			const { type: _type, ...search } = input;
			onSubmit(search);
		}, [onClear, onSubmit])
	});
	const exploreQuery = useQuery({
		queryKey: buildPromptExplorerQueryKey(projectId, urlState),
		queryFn: () => promptExplorerQueryFn(projectId, urlState),
		enabled: hasActivePrompt && planStatus === "paid",
		staleTime: PROMPT_EXPLORER_STALE_TIME_MS,
		gcTime: PROMPT_EXPLORER_STALE_TIME_MS,
		retry: false,
		refetchOnReconnect: false,
		refetchOnWindowFocus: false
	});
	const handleSubmit = (event) => {
		event.preventDefault();
		const trimmed = form.prompt.trim();
		if (trimmed.length === 0) {
			setValidationError("Enter a prompt");
			return;
		}
		if (trimmed.length > 500) {
			setValidationError(`Keep prompts under 500 characters`);
			return;
		}
		if (form.highlightBrand.trim().length > 250) {
			setValidationError(`Keep the brand under 250 characters`);
			return;
		}
		if (form.models.length === 0) {
			setValidationError("Select at least one model");
			return;
		}
		setValidationError(null);
		onSubmit({
			...form,
			prompt: trimmed,
			highlightBrand: form.highlightBrand.trim()
		});
	};
	const updateForm = (key, value) => {
		setForm((prev) => ({
			...prev,
			[key]: value
		}));
		if (validationError) setValidationError(null);
	};
	const historyKey = [
		projectId,
		trimmedPrompt,
		urlState.highlightBrand.trim(),
		t(urlState.models, e()).join(","),
		urlState.webSearch,
		urlState.webSearchCountryCode
	].join("|");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResearchPageShell, {
		contained: true,
		title: "Prompt Explorer",
		description: "Ask any prompt across ChatGPT, Claude, Gemini, and Perplexity side-by-side.",
		gate: {
			feature: "Prompt Explorer",
			description: "Ask one prompt across ChatGPT, Claude, Gemini, and Perplexity at the same time and compare their answers: including which sources each model cites.",
			features: PROMPT_EXPLORER_BULLETS,
			alternative: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptTrackingWithoutUpgradeButton, { projectId })
		},
		form: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptExplorerForm, {
			form,
			onPromptChange: (value) => updateForm("prompt", value),
			onHighlightBrandChange: (value) => updateForm("highlightBrand", value),
			onModelsChange: (value) => updateForm("models", value),
			onWebSearchChange: (value) => updateForm("webSearch", value),
			onCountryChange: (value) => updateForm("webSearchCountryCode", value),
			onSubmit: handleSubmit,
			validationError
		}),
		tabs: hasActivePrompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchTabStrip, {
			projectId,
			activeTabId: searchTabs.activeTabId,
			tabs: searchTabs.tabs,
			onSelect: searchTabs.selectTab,
			onClose: searchTabs.closeTab,
			onViewed: searchTabs.markTabViewed
		}) : null,
		loadingState: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptExplorerLoadingState, { models: urlState.models }),
		query: exploreQuery,
		hasActiveQuery: hasActivePrompt,
		errorFallback: "Failed to load prompt results",
		urlKey: `${projectId}:${JSON.stringify(urlState)}`,
		onUrlChange: () => {
			setForm(urlState);
			setValidationError(null);
		},
		historyKey,
		onSuccess: () => addSearch({
			prompt: trimmedPrompt,
			highlightBrand: urlState.highlightBrand.trim(),
			models: urlState.models,
			webSearch: urlState.webSearch,
			webSearchCountryCode: urlState.webSearchCountryCode
		}),
		backLink: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {
			from: "/p/$projectId/prompt-explorer",
			to: "/p/$projectId/prompt-explorer",
			params: { projectId },
			search: {},
			replace: true,
			children: "Recent searches"
		}),
		renderResults: (result) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptExplorerResults, { result }),
		history: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecentSearches, {
			items: history,
			loaded: historyLoaded,
			onRemove: removeHistoryItem,
			emptyIcon: MessageSquare,
			emptyTitle: "Enter a prompt to compare model answers",
			getTitle: (item) => item.prompt,
			getSubtitle: (item) => item.models.map(formatModelLabel).join(", "),
			renderLink: (item, props) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				from: "/p/$projectId/prompt-explorer",
				to: "/p/$projectId/prompt-explorer",
				params: { projectId },
				search: {
					q: item.prompt,
					models: item.models,
					web: item.webSearch ? void 0 : false,
					cc: item.webSearchCountryCode,
					hb: item.highlightBrand || void 0
				},
				replace: true,
				...props
			})
		})
	});
}
//#endregion
//#region src/routes/_app/p/$projectId/prompt-explorer.tsx?tsr-split=component
function PromptExplorerRoute() {
	const { projectId } = Route.useParams();
	const navigate = useNavigate({ from: Route.fullPath });
	const search = Route.useSearch();
	const market = useProjectMarket(projectId);
	const urlState = (0, import_react.useMemo)(() => {
		const models = search.models && search.models.length > 0 ? search.models : ["chat_gpt"];
		return {
			prompt: search.q ?? "",
			highlightBrand: search.hb ?? "",
			models,
			webSearch: search.web ?? true,
			webSearchCountryCode: search.cc ?? (market && projectWebSearchCountry(market.locationCode, models)) ?? "default"
		};
	}, [search, market]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-auto px-4 py-4 pb-24 md:px-6 md:py-6 md:pb-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-7xl space-y-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectWebsiteGate, {
				projectId,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiResearchSetupGate, {
					projectId,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptExplorerPage, {
						projectId,
						urlState,
						onSubmit: (values) => {
							navigate({
								search: {
									q: values.prompt,
									models: values.models,
									web: values.webSearch ? void 0 : false,
									cc: values.webSearchCountryCode,
									hb: values.highlightBrand || void 0
								},
								replace: true
							});
						},
						onClear: () => {
							navigate({
								search: {},
								replace: true
							});
						}
					})
				})
			})
		}, projectId)
	});
}
//#endregion
export { PromptExplorerRoute as component };
