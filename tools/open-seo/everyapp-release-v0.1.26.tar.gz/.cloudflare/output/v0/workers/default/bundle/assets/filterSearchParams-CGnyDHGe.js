import { n as createLucideIcon } from "./dist-fVOGIv0D.js";
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var RefreshCw = createLucideIcon("refresh-cw", [
	["path", {
		d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8",
		key: "v9h5vc"
	}],
	["path", {
		d: "M21 3v5h-5",
		key: "1q7to0"
	}],
	["path", {
		d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16",
		key: "3uifl3"
	}],
	["path", {
		d: "M8 16H3v5",
		key: "1cv678"
	}]
]);
//#endregion
//#region src/client/lib/filterSearchParams.ts
/**
* Filter panels hold text. The URL holds numeric fields as numbers, so it
* reads `?minVol=100` and not `?minVol="100"`. `include` and `exclude` stay
* text.
*/
function isTextField(key) {
	return key === "include" || key === "exclude";
}
function filterValuesFromSearch(search, empty) {
	const values = { ...empty };
	for (const key in empty) {
		const value = search[key];
		if (value !== void 0) Object.assign(values, { [key]: String(value) });
	}
	return values;
}
function filterValuesToSearch(values) {
	const update = {};
	for (const [key, raw] of Object.entries(values)) {
		const value = raw.trim();
		const parsed = Number(value);
		Object.assign(update, { [key]: value === "" ? void 0 : isTextField(key) ? value : Number.isFinite(parsed) ? parsed : void 0 });
	}
	return update;
}
/** Filter values as they come back from the URL ("10." becomes "10"). */
function normalizeFilterValues(values, empty) {
	return filterValuesFromSearch(filterValuesToSearch(values), empty);
}
//#endregion
export { RefreshCw as i, filterValuesToSearch as n, normalizeFilterValues as r, filterValuesFromSearch as t };
