import { Fn as object, Jn as string, Kt as custom, Lt as boolean, Nt as array, Pn as number, Un as record, sr as unknown } from "./schemas-BPIpYT5n.js";
import { U as AppError } from "./onboarding-drip-B7bIbv_6.js";
import { h as serpKeywordCostMultiplier, i as costPerSerpAtDepth } from "./rank-tracking-CfsrxyGC.js";
import { a as DataforseoChargedTaskError, c as failedResponseError, d as isRecord, f as isTaskInProgress, g as warnIfUpstreamResponseFailed, h as parseTaskTotalCount, i as readDataforseoText, l as invalidFieldName, m as parseTaskItems, n as dataforseoPost, o as assertOk, p as isUpstreamFailureStatus, r as dataforseoPostResponse, s as buildTaskBilling, t as dataforseoGet, u as isNoResultsTask } from "./core-CaMSzKx_.js";
import { n as isGoogleRedirect } from "./google-serp-url-uC4XmGTB.js";
import { i as storedLighthousePayloadSchema, n as buildStoredLighthouseMetrics, r as scoreToPercent, t as buildStoredLighthouseIssues } from "./lighthouseStoredPayload-ClYiMQ6E.js";
import { i as supportsWebSearchCountry } from "./prompt-search-countries-DwmF4BXn.js";
import { c as aiEngineUsesModelApi, i as AI_RECORD_COST_USD, r as AI_LIVE_RECORD_COST_USD } from "./ai-visibility-b7Nyzqt-.js";
//#region src/server/lib/dataforseo/business.ts
var NO_RETRY = { maxServerErrorRetries: 0 };
function locationParams(input) {
	return input.locationCoordinate ? { location_coordinate: input.locationCoordinate } : { location_code: input.locationCode };
}
async function fetchBusinessListingsSearch(input) {
	const response = await dataforseoPost("/v3/business_data/business_listings/search/live", [{
		categories: input.categories,
		title: input.title,
		location_coordinate: input.locationCoordinate,
		is_claimed: input.isClaimed,
		filters: input.filters,
		order_by: input.orderBy,
		limit: input.limit,
		offset: input.offset
	}]);
	const task = assertOk(response, { treatNoResultsAsEmpty: true });
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
var questionsResultSchema = object({
	items: array(record(string(), unknown())).nullable().optional(),
	items_without_answers: array(record(string(), unknown())).nullable().optional()
}).passthrough();
function combinedQuestionItems(results) {
	return (Array.isArray(results) ? results : []).flatMap((result) => {
		const parsed = questionsResultSchema.safeParse(result ?? {});
		if (!parsed.success) return [];
		return [...parsed.data.items ?? [], ...parsed.data.items_without_answers ?? []];
	});
}
async function fetchQuestionsAnswers(input) {
	const response = await dataforseoPost("/v3/business_data/google/questions_and_answers/live", [{
		keyword: input.keyword,
		location_coordinate: input.locationCoordinate,
		language_code: input.languageCode,
		depth: input.depth
	}]);
	const task = assertOk(response, { treatNoResultsAsEmpty: true });
	return {
		data: combinedQuestionItems(task.result),
		billing: buildTaskBilling(task)
	};
}
async function fetchMyBusinessInfo(input) {
	const response = await dataforseoPost("/v3/business_data/google/my_business_info/live", [{
		keyword: input.keyword,
		...locationParams(input),
		language_code: input.languageCode
	}]);
	const task = assertOk(response, { treatNoResultsAsEmpty: true });
	const entry = task.result?.[0];
	const item = entry?.items?.[0];
	if (!isRecord(item)) return {
		data: null,
		billing: buildTaskBilling(task)
	};
	if (item.check_url == null) item.check_url = entry?.check_url;
	return {
		data: item,
		billing: buildTaskBilling(task)
	};
}
/** High execution priority: reviews normally settle within ~20s instead of
*  minutes, which is what makes a single MCP call able to return them. */
var TASK_PRIORITY_HIGH$1 = 2;
/**
* Validates a task_post response and returns the created task's id. `assertOk`
* applies the standard charged-failure ladder (a rejected post entry still
* carries the cost DataForSEO charged, and "Invalid Field" rejections stay
* non-reportable); 20100 "Task Created" is the success status for posts.
*/
function postedTaskId(response) {
	const task = assertOk(response, { okTaskStatusCode: 20100 });
	if (!task.id) throw new AppError("INTERNAL_ERROR", "DataForSEO did not return a task id");
	return {
		data: task.id,
		billing: buildTaskBilling(task)
	};
}
async function postGoogleReviewsTask(input) {
	if (input.includeOtherSources) return postedTaskId(await dataforseoPost("/v3/business_data/google/extended_reviews/task_post", [{
		keyword: input.keyword,
		cid: input.cid,
		place_id: input.placeId,
		...locationParams(input),
		language_code: input.languageCode,
		depth: input.depth,
		priority: TASK_PRIORITY_HIGH$1
	}], NO_RETRY));
	return postedTaskId(await dataforseoPost("/v3/business_data/google/reviews/task_post", [{
		keyword: input.keyword,
		cid: input.cid,
		place_id: input.placeId,
		...locationParams(input),
		language_code: input.languageCode,
		depth: input.depth,
		sort_by: input.sortBy,
		priority: TASK_PRIORITY_HIGH$1
	}], NO_RETRY));
}
async function postMyBusinessUpdatesTask(input) {
	return postedTaskId(await dataforseoPost("/v3/business_data/google/my_business_updates/task_post", [{
		keyword: input.keyword,
		...locationParams(input),
		language_code: input.languageCode,
		depth: input.depth,
		priority: TASK_PRIORITY_HIGH$1
	}], NO_RETRY));
}
/**
* Collects one queued business_data task. Deliberately not metered and not
* wrapped in the billing envelope: collection is free (the task was charged at
* task_post), so routing it through the metering seam would charge twice.
*/
async function fetchBusinessDataTaskResult(input) {
	const response = await dataforseoGet(`/v3/business_data/google/${input.endpoint}/task_get/${encodeURIComponent(input.taskId)}`);
	const task = response?.tasks?.[0];
	if (!response || response.status_code !== 2e4 || !task) throw failedResponseError(response, "DataForSEO task_get failed");
	if (isTaskInProgress(task)) return {
		status: "pending",
		result: null
	};
	if (task.status_code !== 2e4) {
		if (!isNoResultsTask(task)) throw new AppError("INTERNAL_ERROR", task.status_message || `DataForSEO task failed (${task.status_code})`);
		return {
			status: "completed",
			result: null
		};
	}
	const first = task.result?.[0];
	return {
		status: "completed",
		result: isRecord(first) ? first : null
	};
}
var businessCategorySchema = object({
	category_name: string(),
	business_count: number().nullable().optional()
}).passthrough();
/** Top Business Listings categories by business count. Free at DataForSEO. */
async function fetchBusinessListingsCategories() {
	const response = await dataforseoGet("/v3/business_data/business_listings/categories");
	const task = assertOk(response);
	return {
		data: (task.result ?? []).flatMap((entry) => {
			const parsed = businessCategorySchema.safeParse(entry);
			if (!parsed.success) return [];
			return [{
				category: parsed.data.category_name,
				businessCount: parsed.data.business_count ?? null
			}];
		}),
		billing: buildTaskBilling(task)
	};
}
//#endregion
//#region src/server/lib/dataforseoBillingClassification.ts
var BILLING_SIGNALS = [
	"insufficient funds",
	"balance is too low",
	"payment required",
	"billing",
	"balance",
	"problem billing",
	"recharged"
];
var BILLING_STATUS_CODES = /* @__PURE__ */ new Set([
	40200,
	40210,
	402
]);
/**
* Maps DataForSEO balance/payment failures for a given API section to a typed
* billing error. Feature-enablement is no longer classified: Backlinks and AI
* Optimization are included in every DataForSEO account, so the only remaining
* account-level failure is a depleted balance.
*/
function createDataforseoBillingClassifier(config) {
	return (status, details, path) => {
		if (!path.includes(config.pathPrefix)) return null;
		const text = details.toLowerCase();
		const matchesBillingStatus = status != null && BILLING_STATUS_CODES.has(status);
		const matchesBillingText = BILLING_SIGNALS.some((signal) => text.includes(signal));
		if (matchesBillingStatus || matchesBillingText) return new AppError(config.billingIssueCode, config.billingIssueMessage);
		return null;
	};
}
//#endregion
//#region src/server/lib/dataforseo/backlinks.ts
var classifyBacklinksError = createDataforseoBillingClassifier({
	pathPrefix: "/backlinks/",
	billingIssueCode: "BACKLINKS_BILLING_ISSUE",
	billingIssueMessage: "The connected DataForSEO account has a billing or balance issue"
});
var backlinksSummaryItemSchema = object({
	target: string().optional(),
	rank: number().nullable().optional(),
	backlinks: number().nullable().optional(),
	referring_pages: number().nullable().optional(),
	referring_domains: number().nullable().optional(),
	broken_backlinks: number().nullable().optional(),
	broken_pages: number().nullable().optional(),
	new_backlinks: number().nullable().optional(),
	lost_backlinks: number().nullable().optional(),
	new_reffering_domains: number().nullable().optional(),
	lost_reffering_domains: number().nullable().optional(),
	new_referring_domains: number().nullable().optional(),
	lost_referring_domains: number().nullable().optional(),
	backlinks_spam_score: number().nullable().optional(),
	info: object({ target_spam_score: number().nullable().optional() }).passthrough().nullable().optional()
}).passthrough();
var backlinksItemSchema = object({
	domain_from: string().nullable().optional(),
	url_from: string().nullable().optional(),
	url_to: string().nullable().optional(),
	anchor: string().nullable().optional(),
	item_type: string().nullable().optional(),
	dofollow: boolean().nullable().optional(),
	rank: number().nullable().optional(),
	domain_from_rank: number().nullable().optional(),
	page_from_rank: number().nullable().optional(),
	backlinks_spam_score: number().nullable().optional(),
	backlink_spam_score: number().nullable().optional(),
	first_seen: string().nullable().optional(),
	last_seen: string().nullable().optional(),
	last_visited: string().nullable().optional(),
	lost_date: string().nullable().optional(),
	is_new: boolean().nullable().optional(),
	is_lost: boolean().nullable().optional(),
	is_broken: boolean().nullable().optional(),
	links_count: number().nullable().optional(),
	rel_attributes: array(string()).nullable().optional(),
	attributes: array(string()).nullable().optional()
}).passthrough();
var referringDomainItemSchema = object({
	domain: string().nullable().optional(),
	backlinks: number().nullable().optional(),
	referring_pages: number().nullable().optional(),
	rank: number().nullable().optional(),
	first_seen: string().nullable().optional(),
	broken_backlinks: number().nullable().optional(),
	broken_pages: number().nullable().optional(),
	backlinks_spam_score: number().nullable().optional(),
	target_spam_score: number().nullable().optional()
}).passthrough();
var domainPageSummaryItemSchema = object({
	page: string().nullable().optional(),
	url: string().nullable().optional(),
	backlinks: number().nullable().optional(),
	referring_domains: number().nullable().optional(),
	rank: number().nullable().optional(),
	broken_backlinks: number().nullable().optional()
}).passthrough();
var backlinksHistoryItemSchema = object({
	date: string().nullable().optional(),
	rank: number().nullable().optional(),
	backlinks: number().nullable().optional(),
	referring_domains: number().nullable().optional(),
	new_backlinks: number().nullable().optional(),
	lost_backlinks: number().nullable().optional(),
	new_reffering_domains: number().nullable().optional(),
	lost_reffering_domains: number().nullable().optional(),
	new_referring_domains: number().nullable().optional(),
	lost_referring_domains: number().nullable().optional()
}).passthrough();
function buildCommonPayload(input) {
	return {
		target: input.target,
		include_subdomains: input.includeSubdomains ?? true,
		include_indirect_links: true,
		exclude_internal_backlinks: true,
		backlinks_status_type: "live",
		rank_scale: "one_hundred"
	};
}
var assertOptions$1 = (path) => ({
	classify: classifyBacklinksError,
	classifyPath: path
});
/**
* Joins caller-provided filter expressions with the spam-score condition.
* `userFilters` arrives already and/or-joined, so the spam condition is
* appended with a single top-level "and".
*/
function combineFilters(userFilters, spamCondition) {
	const merged = [];
	if (userFilters && userFilters.length > 0) merged.push(...userFilters);
	if (spamCondition) {
		if (merged.length > 0) merged.push("and");
		merged.push(spamCondition);
	}
	return merged.length > 0 ? merged : void 0;
}
async function fetchBacklinksSummary(input) {
	const response = await dataforseoPost("/v3/backlinks/summary/live", [buildCommonPayload(input)], { classify: classifyBacklinksError });
	const task = assertOk(response, assertOptions$1("/v3/backlinks/summary/live"));
	const firstResult = task.result?.[0];
	if (firstResult) {
		const parsed = backlinksSummaryItemSchema.safeParse(firstResult);
		if (!parsed.success) {
			console.error("dataforseo.backlinks-summary-live.invalid-result", parsed.error.issues.slice(0, 5));
			throw new AppError("INTERNAL_ERROR", "DataForSEO backlinks-summary-live returned an invalid response shape");
		}
		return {
			data: parsed.data,
			billing: buildTaskBilling(task)
		};
	}
	return {
		data: {},
		billing: buildTaskBilling(task)
	};
}
async function fetchBacklinksRows(input) {
	const filters = combineFilters(input.filters, input.hideSpam ?? true ? [
		[
			"backlink_spam_score",
			"<",
			40
		],
		"or",
		[
			"backlink_spam_score",
			"=",
			null
		]
	] : void 0);
	const response = await dataforseoPost("/v3/backlinks/backlinks/live", [{
		...buildCommonPayload(input),
		backlinks_status_type: input.status ?? "live",
		limit: input.limit ?? 100,
		offset: input.offset,
		order_by: input.orderBy ?? ["rank,desc"],
		mode: input.mode,
		...filters ? { filters } : {}
	}], { classify: classifyBacklinksError });
	const task = assertOk(response, assertOptions$1("/v3/backlinks/backlinks/live"));
	return {
		data: {
			items: parseTaskItems("backlinks-live", task, backlinksItemSchema),
			totalCount: parseTaskTotalCount(task)
		},
		billing: buildTaskBilling(task)
	};
}
async function fetchReferringDomains(input) {
	const filters = combineFilters(input.filters, input.hideSpam ?? true ? [
		"backlinks_spam_score",
		"<=",
		40
	] : void 0);
	const response = await dataforseoPost("/v3/backlinks/referring_domains/live", [{
		...buildCommonPayload(input),
		limit: input.limit ?? 100,
		offset: input.offset,
		order_by: input.orderBy ?? ["backlinks,desc"],
		...filters ? { filters } : {}
	}], { classify: classifyBacklinksError });
	const task = assertOk(response, assertOptions$1("/v3/backlinks/referring_domains/live"));
	return {
		data: {
			items: parseTaskItems("referring-domains-live", task, referringDomainItemSchema),
			totalCount: parseTaskTotalCount(task)
		},
		billing: buildTaskBilling(task)
	};
}
async function fetchDomainPagesSummary(input) {
	const filters = input.filters && input.filters.length > 0 ? input.filters : void 0;
	const response = await dataforseoPost("/v3/backlinks/domain_pages_summary/live", [{
		...buildCommonPayload(input),
		limit: input.limit ?? 100,
		offset: input.offset,
		order_by: input.orderBy ?? ["backlinks,desc"],
		...filters ? { filters } : {}
	}], { classify: classifyBacklinksError });
	const task = assertOk(response, assertOptions$1("/v3/backlinks/domain_pages_summary/live"));
	return {
		data: {
			items: parseTaskItems("domain-pages-summary-live", task, domainPageSummaryItemSchema),
			totalCount: parseTaskTotalCount(task)
		},
		billing: buildTaskBilling(task)
	};
}
async function fetchBacklinksHistory(input) {
	const response = await dataforseoPost("/v3/backlinks/history/live", [{
		target: input.target,
		date_from: input.dateFrom,
		date_to: input.dateTo,
		rank_scale: "one_hundred"
	}], { classify: classifyBacklinksError });
	const task = assertOk(response, assertOptions$1("/v3/backlinks/history/live"));
	return {
		data: parseTaskItems("backlinks-history-live", task, backlinksHistoryItemSchema),
		billing: buildTaskBilling(task)
	};
}
//#endregion
//#region src/server/lib/dataforseo/labs.ts
var rankedSerpItemSchema = object({
	url: string().nullable().optional(),
	relative_url: string().nullable().optional(),
	rank_absolute: number().nullable().optional(),
	etv: number().nullable().optional()
}).passthrough();
var domainRankedKeywordItemSchema = object({
	keyword_data: object({
		keyword: string().nullable().optional(),
		keyword_info: object({
			search_volume: number().nullable().optional(),
			cpc: number().nullable().optional(),
			keyword_difficulty: number().nullable().optional()
		}).passthrough().nullable().optional(),
		keyword_properties: object({ keyword_difficulty: number().nullable().optional() }).passthrough().nullable().optional()
	}).passthrough().nullable().optional(),
	ranked_serp_element: object({
		serp_item: rankedSerpItemSchema.nullable().optional(),
		url: string().nullable().optional(),
		relative_url: string().nullable().optional(),
		rank_absolute: number().nullable().optional(),
		etv: number().nullable().optional()
	}).passthrough().nullable().optional(),
	keyword: string().nullable().optional()
}).passthrough();
async function fetchRelatedKeywords(input) {
	const response = await dataforseoPost("/v3/dataforseo_labs/google/related_keywords/live", [{
		keyword: input.keyword,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: input.limit,
		depth: input.depth ?? 3,
		ignore_synonyms: input.ignoreSynonyms ?? false,
		include_clickstream_data: input.includeClickstreamData ?? false,
		include_serp_info: false
	}]);
	const task = assertOk(response);
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
async function fetchKeywordSuggestions(input) {
	const response = await dataforseoPost("/v3/dataforseo_labs/google/keyword_suggestions/live", [{
		keyword: input.keyword,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: input.limit,
		include_clickstream_data: input.includeClickstreamData ?? false,
		include_serp_info: false,
		include_seed_keyword: true,
		ignore_synonyms: input.ignoreSynonyms ?? false,
		exact_match: false,
		filters: input.filters
	}]);
	const task = assertOk(response);
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
async function fetchKeywordIdeas(input) {
	const response = await dataforseoPost("/v3/dataforseo_labs/google/keyword_ideas/live", [{
		keywords: [input.keyword],
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: input.limit,
		include_clickstream_data: input.includeClickstreamData ?? false,
		include_serp_info: false,
		ignore_synonyms: input.ignoreSynonyms ?? false,
		closely_variants: false
	}]);
	const task = assertOk(response);
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
async function fetchDomainRankOverview(input) {
	const response = await dataforseoPost("/v3/dataforseo_labs/google/domain_rank_overview/live", [{
		target: input.target,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: 1
	}]);
	const task = assertOk(response);
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
async function fetchRankedKeywords(input) {
	const response = await dataforseoPost("/v3/dataforseo_labs/google/ranked_keywords/live", [{
		target: input.target,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: input.limit,
		offset: input.offset,
		order_by: input.orderBy,
		filters: input.filters,
		item_types: input.itemTypes
	}]);
	const task = assertOk(response);
	return {
		data: {
			items: parseTaskItems("google-ranked-keywords-live", task, domainRankedKeywordItemSchema),
			totalCount: task.result?.[0]?.total_count ?? null
		},
		billing: buildTaskBilling(task)
	};
}
async function fetchRelevantPages(input) {
	const response = await dataforseoPost("/v3/dataforseo_labs/google/relevant_pages/live", [{
		target: input.target,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: input.limit,
		offset: input.offset,
		order_by: input.orderBy,
		filters: input.filters
	}]);
	const task = assertOk(response);
	return {
		data: {
			items: task.result?.[0]?.items ?? [],
			totalCount: task.result?.[0]?.total_count ?? null
		},
		billing: buildTaskBilling(task)
	};
}
async function fetchKeywordOverview(input) {
	const response = await dataforseoPost("/v3/dataforseo_labs/google/keyword_overview/live", [{
		keywords: input.keywords,
		location_code: input.locationCode,
		language_code: input.languageCode,
		include_clickstream_data: input.includeClickstreamData ?? false
	}]);
	const task = assertOk(response);
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
async function fetchSerpCompetitors(input) {
	const response = await dataforseoPost("/v3/dataforseo_labs/google/serp_competitors/live", [{
		keywords: input.keywords,
		location_code: input.locationCode,
		language_code: input.languageCode,
		item_types: input.itemTypes,
		include_subdomains: input.includeSubdomains,
		limit: input.limit,
		offset: input.offset
	}]);
	const task = assertOk(response);
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
//#endregion
//#region src/server/lib/dataforseo/google-ads.ts
function taskItems(task) {
	return task.result ?? [];
}
var ADS_INVALID_KEYWORD_CHARS = /[!@%,*(){}<>|^~;=?`]|\p{Extended_Pictographic}/u;
/** Whether Google Ads search_volume accepts this keyword text. */
function isAdsKeyword(keyword) {
	return keyword.length <= 80 && keyword.split(/\s+/).length <= 10 && !ADS_INVALID_KEYWORD_CHARS.test(keyword);
}
function adsLanguageCode(languageCode) {
	return languageCode === "nb" ? "no" : languageCode;
}
async function fetchAdsSearchVolume(input) {
	const locationParams = input.locationName ? { location_name: input.locationName } : { location_code: input.locationCode };
	const response = await dataforseoPost("/v3/keywords_data/google_ads/search_volume/live", [{
		keywords: input.keywords,
		...locationParams,
		language_code: adsLanguageCode(input.languageCode)
	}]);
	const task = assertOk(response);
	return {
		data: taskItems(task),
		billing: buildTaskBilling(task)
	};
}
async function fetchAdsKeywordIdeas(input) {
	const response = await dataforseoPost("/v3/keywords_data/google_ads/keywords_for_keywords/live", [{
		keywords: [input.keyword],
		location_code: input.locationCode,
		language_code: adsLanguageCode(input.languageCode),
		sort_by: "search_volume"
	}]);
	const task = assertOk(response);
	return {
		data: taskItems(task).slice(0, input.limit),
		billing: buildTaskBilling(task)
	};
}
/** High priority finishes in ~10-40 s; the normal queue takes minutes. */
var TASK_PRIORITY_HIGH = 2;
/** DataForSEO bills SERPs in pages of 10; depth outside 10-100 is rejected. */
function clampSerpDepth(depth) {
	return Math.min(100, Math.max(10, depth));
}
var serpSnapshotItemSchema = object({
	type: string(),
	rank_group: number().nullable().optional(),
	rank_absolute: number().nullable().optional(),
	domain: string().nullable().optional(),
	title: string().nullable().optional(),
	url: string().nullable().optional(),
	description: string().nullable().optional(),
	breadcrumb: string().nullable().optional(),
	etv: number().nullable().optional(),
	estimated_paid_traffic_cost: number().nullable().optional(),
	backlinks_info: object({
		referring_domains: number().nullable().optional(),
		backlinks: number().nullable().optional()
	}).passthrough().nullable().optional(),
	rank_changes: object({
		previous_rank_absolute: number().nullable().optional(),
		is_new: boolean().nullable().optional(),
		is_up: boolean().nullable().optional(),
		is_down: boolean().nullable().optional()
	}).passthrough().nullable().optional()
}).passthrough().transform(unwrapGoogleRedirect);
/**
* Google wraps many organic results in a google.com/goto redirect, and
* DataForSEO reports them with domain "google.com" and an encoded URL. The
* real site is only in the breadcrumb ("https://www.runnersworld.com \u203a gear").
* When the breadcrumb isn't a URL (Reddit's "230+ comments") the domain is
* unknown, which beats crediting google.com with the result.
*/
function unwrapGoogleRedirect(item) {
	if (!item.url || !isGoogleRedirect(item.url)) return item;
	return {
		...item,
		domain: breadcrumbHost(item.breadcrumb)
	};
}
function breadcrumbHost(breadcrumb) {
	const first = breadcrumb?.split("\u203A")[0]?.trim();
	if (!first || !/^https?:\/\//i.test(first)) return null;
	try {
		return new URL(first).hostname.toLowerCase().replace(/^www\./, "");
	} catch {
		return null;
	}
}
function serpQueryParams(input) {
	const device = input.device ?? "desktop";
	const locationParams = input.locationName ? { location_name: input.locationName } : { location_code: input.locationCode };
	return {
		keyword: input.keyword,
		...locationParams,
		language_code: input.languageCode,
		device,
		os: device === "desktop" ? "windows" : "android",
		depth: clampSerpDepth(input.depth ?? 10)
	};
}
async function fetchLiveSerp(input) {
	const response = await dataforseoPost("/v3/serp/google/organic/live/advanced", [serpQueryParams(input)]);
	const task = assertOk(response, { treatNoResultsAsEmpty: true });
	return {
		data: parseTaskItems("google-organic-live-advanced", task, serpSnapshotItemSchema),
		billing: buildTaskBilling(task)
	};
}
function buildRankCheckResult(input, items) {
	const target = input.targetDomain.toLowerCase();
	const organicMatch = items.find((item) => {
		if (item.type !== "organic" || item.domain == null) return false;
		const domain = item.domain.toLowerCase();
		return domain === target || domain.endsWith(`.${target}`);
	});
	return {
		keywordId: input.keywordId,
		keyword: input.keyword,
		position: organicMatch ? organicMatch.rank_group ?? organicMatch.rank_absolute ?? null : null,
		url: organicMatch?.url ?? null,
		serpFeatures: [...new Set(items.map((item) => item.type).filter(Boolean))]
	};
}
async function postRankCheckTasks(input) {
	if (input.tasks.length === 0 || input.tasks.length > 100) throw new AppError("INTERNAL_ERROR", `task_post accepts 1-100 tasks, got ${input.tasks.length}`);
	const depth = clampSerpDepth(input.depth);
	const locationParams = input.locationName ? { location_name: input.locationName } : { location_code: input.locationCode };
	const response = await dataforseoPost("/v3/serp/google/organic/task_post", input.tasks.map((task) => ({
		keyword: task.keyword,
		...locationParams,
		language_code: input.languageCode,
		device: task.device,
		os: task.device === "desktop" ? "windows" : "android",
		depth,
		tag: `${task.keywordId}:${task.device}`
	})));
	if (!response || response.status_code !== 2e4) throw failedResponseError(response, "DataForSEO task_post failed");
	const byTag = new Map(input.tasks.map((task) => [`${task.keywordId}:${task.device}`, task]));
	const posted = [];
	let costUsd = 0;
	for (const entry of response.tasks ?? []) {
		costUsd += entry.cost ?? 0;
		const tag = entry.data?.tag;
		const task = typeof tag === "string" ? byTag.get(tag) : void 0;
		if (entry.status_code !== 20100 || !entry.id || !task) {
			console.warn(`dataforseo.task_post.rejected-entry (${entry.status_code}): ${entry.status_message}`);
			continue;
		}
		posted.push({
			...task,
			taskId: entry.id
		});
	}
	return {
		data: posted,
		billing: {
			path: [
				"v3",
				"serp",
				"google",
				"organic",
				"task_post"
			],
			costUsd
		}
	};
}
/**
* Collect one queued task's result. Deliberately not metered and not wrapped
* in the billing envelope: collection is free (the task was charged at
* task_post), so running it through the metering seam would charge the customer
* twice.
*/
async function fetchRankCheckTaskResult(input) {
	const outcome = await fetchSerpTaskResult(input.taskId);
	if (outcome.status !== "completed") return outcome;
	return {
		status: "completed",
		result: buildRankCheckResult(input, outcome.items)
	};
}
/** Collects one queued organic SERP task. Free, so not metered (see above). */
async function fetchSerpTaskResult(taskId, signal) {
	const response = await dataforseoGet(`/v3/serp/google/organic/task_get/advanced/${encodeURIComponent(taskId)}`, { signal });
	const task = response?.tasks?.[0];
	if (!response || response.status_code !== 2e4 || !task) throw failedResponseError(response, "DataForSEO task_get failed");
	if (isTaskInProgress(task)) return { status: "pending" };
	if (task.status_code !== 2e4) {
		if (!isNoResultsTask(task)) return {
			status: "failed",
			message: task.status_message || `DataForSEO task failed (${task.status_code})`
		};
		return {
			status: "completed",
			items: []
		};
	}
	return {
		status: "completed",
		items: parseTaskItems("google-organic-task-get-advanced", task, serpSnapshotItemSchema)
	};
}
/**
* Posts one query's reads and returns the accepted task ids. Not retried on a
* 5xx, which does not prove the post went unbilled.
*/
async function postSerpReadTasks(input) {
	const response = await dataforseoPost("/v3/serp/google/organic/task_post", Array.from({ length: 3 }, () => ({
		...serpQueryParams(input),
		priority: TASK_PRIORITY_HIGH
	})), { maxServerErrorRetries: 0 });
	if (!response || response.status_code !== 2e4) throw failedResponseError(response, "DataForSEO task_post failed");
	const taskIds = [];
	let costUsd = 0;
	for (const entry of response.tasks ?? []) {
		costUsd += entry.cost ?? 0;
		if (entry.status_code === 20100 && entry.id) taskIds.push(entry.id);
		else console.warn(`dataforseo.task_post.rejected-entry (${entry.status_code}): ${entry.status_message}`);
	}
	const billing = {
		path: [
			"v3",
			"serp",
			"google",
			"organic",
			"task_post"
		],
		costUsd
	};
	if (taskIds.length === 0) {
		const message = response.tasks?.[0]?.status_message || "DataForSEO created no tasks";
		throw new DataforseoChargedTaskError(message, billing, invalidFieldName(message) !== null);
	}
	return {
		data: taskIds,
		billing
	};
}
async function fetchLocalSerp(input) {
	const os = input.device === "desktop" ? "windows" : "android";
	if (input.searchType === "maps") {
		const response = await dataforseoPost("/v3/serp/google/maps/live/advanced", [{
			keyword: input.keyword,
			location_coordinate: input.locationCoordinate,
			location_name: input.locationName,
			language_code: input.languageCode,
			device: input.device,
			os,
			depth: input.depth,
			search_places: input.searchPlaces
		}]);
		const task = assertOk(response, { treatNoResultsAsEmpty: true });
		return {
			data: task.result?.[0]?.items ?? [],
			billing: buildTaskBilling(task)
		};
	}
	const response = await dataforseoPost("/v3/serp/google/local_finder/live/advanced", [{
		keyword: input.keyword,
		location_coordinate: input.locationCoordinate,
		location_name: input.locationName,
		language_code: input.languageCode,
		device: input.device,
		os,
		depth: input.depth
	}]);
	const task = assertOk(response, { treatNoResultsAsEmpty: true });
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
/**
* Posts one Maps task per coordinate and returns the task ids in input
* order, null where DataForSEO rejected an entry. Not retried on a 5xx,
* which does not prove the post went unbilled.
*/
async function postLocalSerpTasks(input) {
	const response = await dataforseoPost("/v3/serp/google/maps/task_post", input.locationCoordinates.map((coordinate, index) => ({
		keyword: input.keyword,
		location_coordinate: coordinate,
		language_code: input.languageCode,
		device: input.device,
		os: input.device === "desktop" ? "windows" : "android",
		depth: input.depth,
		search_places: false,
		priority: TASK_PRIORITY_HIGH,
		tag: String(index)
	})), { maxServerErrorRetries: 0 });
	if (!response || response.status_code !== 2e4) throw failedResponseError(response, "DataForSEO task_post failed");
	const taskIds = input.locationCoordinates.map(() => null);
	let costUsd = 0;
	for (const entry of response.tasks ?? []) {
		costUsd += entry.cost ?? 0;
		const index = Number(entry.data?.tag);
		if (entry.status_code === 20100 && entry.id && taskIds[index] === null) taskIds[index] = entry.id;
		else console.warn(`dataforseo.task_post.rejected-entry (${entry.status_code}): ${entry.status_message}`);
	}
	const billing = {
		path: [
			"v3",
			"serp",
			"google",
			"maps",
			"task_post"
		],
		costUsd
	};
	if (taskIds.every((id) => id === null)) {
		const message = response.tasks?.[0]?.status_message || "DataForSEO created no tasks";
		throw new DataforseoChargedTaskError(message, billing, invalidFieldName(message) !== null);
	}
	return {
		data: taskIds,
		billing
	};
}
/**
* Collects one queued Maps task. Not metered, like fetchRankCheckTaskResult:
* the task was charged at task_post.
*/
async function fetchLocalSerpTaskResult(taskId) {
	const response = await dataforseoGet(`/v3/serp/google/maps/task_get/advanced/${encodeURIComponent(taskId)}`);
	const task = response?.tasks?.[0];
	if (!response || response.status_code !== 2e4 || !task) throw failedResponseError(response, "DataForSEO task_get failed");
	if (isTaskInProgress(task)) return { status: "pending" };
	if (task.status_code !== 2e4) {
		if (isNoResultsTask(task)) return {
			status: "completed",
			items: []
		};
		return {
			status: "failed",
			message: task.status_message || `DataForSEO task failed (${task.status_code})`
		};
	}
	return {
		status: "completed",
		items: task.result?.[0]?.items ?? []
	};
}
//#endregion
//#region src/server/lib/dataforseoLighthousePayload.ts
var requestCategories = [
	"performance",
	"accessibility",
	"best_practices",
	"seo"
];
var lighthouseResponseSchema = object({
	requestedUrl: string().optional(),
	finalUrl: string().optional(),
	lighthouseVersion: string().optional(),
	categories: record(string(), custom()).optional(),
	audits: record(string(), custom()).optional()
});
var dataforseoTaskSchema = object({
	id: string().optional(),
	cost: number().optional(),
	status_code: number().optional(),
	status_message: string().optional(),
	result: array(lighthouseResponseSchema).optional()
});
var dataforseoLighthouseResponseSchema = object({
	status_code: number().optional(),
	status_message: string().optional(),
	tasks: array(dataforseoTaskSchema).optional()
});
function summarizeZodIssues(error, maxIssues = 3) {
	return error.issues.slice(0, maxIssues).map((issue) => {
		return `${issue.path.length > 0 ? issue.path.join(".") : "<root>"}: ${issue.message}`;
	}).join("; ");
}
function parseDataforseoLighthousePayload(payload, input) {
	const parsed = dataforseoLighthouseResponseSchema.safeParse(payload);
	if (!parsed.success) throw new Error(`DataForSEO Lighthouse returned an invalid response: ${summarizeZodIssues(parsed.error)}`);
	if (parsed.data.status_code !== 2e4) throw new Error(parsed.data.status_message ?? "DataForSEO Lighthouse request failed");
	const task = parsed.data.tasks?.[0];
	if (!task) throw new Error("DataForSEO Lighthouse response missing task");
	if (task.status_code !== 2e4) throw new Error(task.status_message ?? "DataForSEO Lighthouse task failed");
	const result = task.result?.[0];
	if (!result) throw new Error("DataForSEO Lighthouse response missing result");
	const fetchedAt = (/* @__PURE__ */ new Date()).toISOString();
	const categories = result.categories ?? {};
	const audits = result.audits ?? {};
	const issueReport = buildStoredLighthouseIssues({
		audits,
		categories
	});
	const metrics = buildStoredLighthouseMetrics({ audits });
	const storedPayload = {
		version: 2,
		source: "dataforseo-lighthouse",
		hasIssueDetails: issueReport.hasIssueDetails,
		metadata: {
			requestedUrl: result.requestedUrl ?? input.url,
			finalUrl: result.finalUrl ?? input.url,
			strategy: input.strategy,
			fetchedAt,
			lighthouseVersion: result.lighthouseVersion ?? null,
			taskId: task.id ?? null,
			cost: task.cost ?? null
		},
		scores: {
			performance: scoreToPercent(categories.performance?.score),
			accessibility: scoreToPercent(categories.accessibility?.score),
			"best-practices": scoreToPercent(categories["best-practices"]?.score),
			seo: scoreToPercent(categories.seo?.score)
		},
		metrics,
		issues: issueReport.issues
	};
	if (Object.values(storedPayload.scores).every((score) => score == null)) throw new Error(`DataForSEO Lighthouse returned no category scores for ${storedPayload.metadata.finalUrl}`);
	const validated = storedLighthousePayloadSchema.safeParse(storedPayload);
	if (!validated.success) throw new Error(`DataForSEO Lighthouse returned an invalid report: ${summarizeZodIssues(validated.error)}`);
	return storedPayload;
}
//#endregion
//#region src/server/lib/dataforseo/lighthouse.ts
var LIGHTHOUSE_PATH = "/v3/on_page/lighthouse/live/json";
var REQUEST_TIMEOUT_MS = 6e4;
var parseChain = Promise.resolve();
function withParseLock(fn) {
	const run = parseChain.then(fn, fn);
	parseChain = run.catch(() => {});
	return run;
}
async function fetchLighthouseResult(input) {
	const controller = new AbortController();
	const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
	let response;
	try {
		response = await dataforseoPostResponse(LIGHTHOUSE_PATH, [{
			url: input.url,
			for_mobile: input.strategy === "mobile",
			categories: [...requestCategories]
		}], {
			maxServerErrorRetries: 0,
			signal: controller.signal
		});
	} finally {
		clearTimeout(timeout);
	}
	return withParseLock(async () => {
		const body = JSON.parse(await readDataforseoText(response));
		warnIfUpstreamResponseFailed(body, LIGHTHOUSE_PATH);
		const task = assertOk(body);
		const billing = buildTaskBilling(task);
		try {
			return {
				data: parseDataforseoLighthousePayload(body, input),
				billing
			};
		} catch (error) {
			const message = error instanceof Error ? error.message : String(error);
			throw new DataforseoChargedTaskError(message, billing);
		}
	});
}
//#endregion
//#region src/server/lib/dataforseoLlmSchemas.ts
/**
* Zod schemas for DataForSEO AI Optimization endpoints.
*
* The DataForSEO SDK does not yet ship typed bindings for `/ai_optimization/*`,
* so we POST raw JSON and validate the responses ourselves. All schemas use
* `.passthrough()` to tolerate fields the API may add in future versions.
*/
var monthlyVolumeSchema = object({
	year: number().int(),
	month: number().int().min(1).max(12),
	search_volume: number().nullable().optional()
}).passthrough();
var mentionSourceSchema = object({
	url: string().nullable().optional(),
	title: string().nullable().optional(),
	domain: string().nullable().optional()
}).passthrough();
var brandEntitySchema = object({ title: string().nullable().optional() }).passthrough();
var llmMentionItemSchema = object({
	question: string().nullable().optional(),
	answer: string().nullable().optional(),
	sources: array(mentionSourceSchema).nullable().optional(),
	search_results: array(mentionSourceSchema).nullable().optional(),
	ai_search_volume: number().nullable().optional(),
	monthly_searches: array(monthlyVolumeSchema).nullable().optional(),
	first_response_at: string().nullable().optional(),
	last_response_at: string().nullable().optional(),
	brand_entities: array(brandEntitySchema).nullable().optional()
}).passthrough();
var groupElementSchema = object({
	type: string().nullable().optional(),
	key: string().nullable().optional(),
	mentions: number().nullable().optional(),
	ai_search_volume: number().nullable().optional(),
	impressions: number().nullable().optional()
}).passthrough();
var llmAggregatedTotalSchema = object({ platform: array(groupElementSchema).nullable().optional() }).passthrough();
var llmTopPagesItemSchema = object({
	key: string().nullable().optional(),
	platform: array(groupElementSchema).nullable().optional()
}).passthrough();
var llmCrossAggregatedItemSchema = object({
	key: string().nullable().optional(),
	platform: array(groupElementSchema).nullable().optional()
}).passthrough();
var responseAnnotationSchema = object({
	type: string().nullable().optional(),
	title: string().nullable().optional(),
	url: string().nullable().optional()
}).passthrough();
var responseSectionSchema = object({
	type: string().nullable().optional(),
	text: string().nullable().optional(),
	annotations: array(responseAnnotationSchema).nullable().optional()
}).passthrough();
var responseItemSchema = object({
	type: string().nullable().optional(),
	sections: array(responseSectionSchema).nullable().optional()
}).passthrough();
var llmResponseResultSchema = object({
	model_name: string().nullable().optional(),
	output_tokens: number().nullable().optional(),
	web_search: boolean().nullable().optional(),
	items: array(responseItemSchema).nullable().optional(),
	fan_out_queries: array(string()).nullable().optional()
}).passthrough();
//#endregion
//#region src/server/lib/dataforseo/llm-models.ts
/**
* Model names come from DataForSEO's FREE ($0) per-provider catalog
* (`/v3/ai_optimization/{slug}/llm_responses/models`), so the app tracks new
* model families without code changes. This matters twice over: a hardcoded
* pin goes stale (we shipped gpt-5 while the catalog had gpt-5.5), and
* DataForSEO BILLS tasks that fail with `Invalid Field: 'model_name'`, so a
* name must be validated against the catalog before a paid dispatch.
*/
var catalogRowSchema = object({ model_name: string() });
/**
* Snapshot fallback (2026-08-25) used when the catalog endpoint is
* unreachable or lists no flagship alias: the aliases we know DataForSEO
* accepts, newest first.
*/
var FALLBACK_MODEL_NAMES = {
	chat_gpt: [
		"gpt-5.6-luna",
		"gpt-5.5",
		"gpt-5.4",
		"gpt-5.2",
		"gpt-5.1",
		"gpt-5"
	],
	claude: [
		"claude-sonnet-5",
		"claude-sonnet-4-6",
		"claude-sonnet-4-5"
	],
	gemini: ["gemini-3.5-flash"],
	perplexity: [
		"sonar-reasoning-pro",
		"sonar-pro",
		"sonar"
	]
};
/**
* Explicit preferred model per provider, taking precedence over the plain-
* alias rule below while the catalog still lists it (a dropped pin falls back
* to the rule instead of dispatching a billed-invalid name). ChatGPT is pinned
* to the 5.6 tier by maintainer choice \u2014 the plain-alias rule can't rank tier
* variants (terra/sol/luna), and 5.6 is newer than the plain gpt-5.5 alias.
* Live-verified accepted + cited (2026-08-25).
*/
var PINNED_MODEL_NAMES = {
	chat_gpt: "gpt-5.6-luna",
	claude: "claude-sonnet-5",
	gemini: "gemini-3.5-flash"
};
/**
* The flagship alias per provider: a plain, undated, un-suffixed family name.
* Dated releases ("gpt-5.5-2026-04-23") duplicate their alias, and suffixed
* variants (mini/nano/-lite, or tier names like "gpt-5.6-terra"/"-sol") are
* size/speed tiers whose consumer-default semantics we can't know \u2014 so the
* highest plain alias is what "latest" means here. DataForSEO resolves an
* alias to its latest dated version server-side.
*/
var LATEST_RULES = {
	chat_gpt: /^gpt-(\d+(?:\.\d+)*)$/,
	claude: /^claude-sonnet-(\d+(?:-\d+)*)$/,
	gemini: /^gemini-(\d+(?:\.\d+)*)-flash$/,
	perplexity: /^sonar-reasoning-pro$/
};
function compareVersions(a, b) {
	for (let i = 0; i < Math.max(a.length, b.length); i++) {
		const diff = (a[i] ?? 0) - (b[i] ?? 0);
		if (diff !== 0) return diff;
	}
	return 0;
}
function pickLatestLlmModelName(slug, names) {
	const pinned = PINNED_MODEL_NAMES[slug];
	if (pinned && names.includes(pinned)) return pinned;
	const rule = LATEST_RULES[slug];
	let best = null;
	for (const name of names) {
		const match = rule.exec(name);
		if (!match) continue;
		const version = (match[1] ?? "0").split(/[.-]/).map(Number);
		if (!best || compareVersions(version, best.version) > 0) best = {
			name,
			version
		};
	}
	const fallback = FALLBACK_MODEL_NAMES[slug];
	return best?.name ?? fallback.find((n) => names.includes(n)) ?? fallback[0];
}
var CATALOG_TTL_MS = 36e5;
var catalogCache = /* @__PURE__ */ new Map();
async function getLlmModelNames(slug) {
	const cached = catalogCache.get(slug);
	if (cached && Date.now() - cached.fetchedAt < CATALOG_TTL_MS) return cached.names;
	try {
		const response = await dataforseoGet(`/v3/ai_optimization/${slug}/llm_responses/models`);
		const names = (assertOk(response).result ?? []).flatMap((row) => {
			const parsed = catalogRowSchema.safeParse(row);
			return parsed.success ? [parsed.data.model_name] : [];
		});
		if (names.length === 0) return FALLBACK_MODEL_NAMES[slug];
		catalogCache.set(slug, {
			names,
			fetchedAt: Date.now()
		});
		return names;
	} catch (error) {
		console.warn(`dataforseo.llm-models.catalog-fetch failed (${slug})`, error);
		return FALLBACK_MODEL_NAMES[slug];
	}
}
/** The model to use for a provider, picked from the live catalog. */
async function resolveLatestLlmModelName(slug) {
	return pickLatestLlmModelName(slug, await getLlmModelNames(slug));
}
/** Whether DataForSEO's catalog accepts this model name. Checked before every
*  paid dispatch because an unknown `model_name` fails as a BILLED task. */
async function isKnownLlmModelName(slug, modelName) {
	return (await getLlmModelNames(slug)).includes(modelName);
}
//#endregion
//#region src/server/lib/dataforseo/ai.ts
var classifyAiSearchError = createDataforseoBillingClassifier({
	pathPrefix: "/ai_optimization/",
	billingIssueCode: "AI_SEARCH_BILLING_ISSUE",
	billingIssueMessage: "The connected DataForSEO account has a billing or balance issue"
});
var assertOptions = (path) => ({
	classify: classifyAiSearchError,
	classifyPath: path
});
function clampLimit(value, min, max) {
	return Math.min(max, Math.max(min, Math.floor(value)));
}
function resolveLlmMentionsLimit(limit) {
	return clampLimit(limit ?? 100, 1, 1e3);
}
function targetList(target) {
	return [target];
}
function firstResult(task) {
	const first = task.result?.[0];
	return isRecord(first) ? first : null;
}
async function fetchLlmMentionsSearch(input) {
	const response = await dataforseoPost("/v3/ai_optimization/llm_mentions/search/live", [{
		target: targetList(input.target),
		platform: input.platform,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: resolveLlmMentionsLimit(input.limit),
		order_by: input.orderBy
	}], { classify: classifyAiSearchError });
	const task = assertOk(response, assertOptions("/v3/ai_optimization/llm_mentions/search/live"));
	const items = array(llmMentionItemSchema).safeParse(firstResult(task)?.items ?? []);
	if (!items.success) throw new AppError("INTERNAL_ERROR", "DataForSEO llm_mentions/search returned an invalid mention items shape");
	return {
		data: items.data,
		billing: buildTaskBilling(task)
	};
}
async function fetchLlmAggregatedMetrics(input) {
	const response = await dataforseoPost("/v3/ai_optimization/llm_mentions/aggregated_metrics/live", [{
		target: targetList(input.target),
		platform: input.platform,
		location_code: input.locationCode,
		language_code: input.languageCode,
		internal_list_limit: clampLimit(input.internalListLimit ?? 10, 1, 20)
	}], { classify: classifyAiSearchError });
	const task = assertOk(response, assertOptions("/v3/ai_optimization/llm_mentions/aggregated_metrics/live"));
	const total = llmAggregatedTotalSchema.safeParse(firstResult(task)?.total ?? {});
	if (!total.success) throw new AppError("INTERNAL_ERROR", "DataForSEO llm_mentions/aggregated_metrics returned an invalid shape");
	return {
		data: total.data,
		billing: buildTaskBilling(task)
	};
}
async function fetchLlmTopPages(input) {
	const response = await dataforseoPost("/v3/ai_optimization/llm_mentions/top_pages/live", [{
		target: targetList(input.target),
		platform: input.platform,
		location_code: input.locationCode,
		language_code: input.languageCode,
		links_scope: "sources",
		items_list_limit: clampLimit(input.itemsListLimit ?? 10, 1, 10),
		internal_list_limit: 5
	}], { classify: classifyAiSearchError });
	const task = assertOk(response, assertOptions("/v3/ai_optimization/llm_mentions/top_pages/live"));
	const items = array(llmTopPagesItemSchema).safeParse(firstResult(task)?.items ?? []);
	if (!items.success) throw new AppError("INTERNAL_ERROR", "DataForSEO llm_mentions/top_pages returned an invalid shape");
	return {
		data: items.data,
		billing: buildTaskBilling(task)
	};
}
async function fetchLlmCrossAggregatedMetrics(input) {
	if (input.groups.length < 2 || input.groups.length > 10) throw new AppError("VALIDATION_ERROR", "DataForSEO llm_mentions/cross_aggregated_metrics requires 2 to 10 target groups");
	const response = await dataforseoPost("/v3/ai_optimization/llm_mentions/cross_aggregated_metrics/live", [{
		targets: input.groups.map((group) => ({
			aggregation_key: group.key,
			target: targetList(group.target)
		})),
		platform: input.platform,
		location_code: input.locationCode,
		language_code: input.languageCode,
		internal_list_limit: clampLimit(input.internalListLimit ?? 5, 1, 10)
	}], { classify: classifyAiSearchError });
	const task = assertOk(response, assertOptions("/v3/ai_optimization/llm_mentions/cross_aggregated_metrics/live"));
	const items = array(llmCrossAggregatedItemSchema).safeParse(firstResult(task)?.items ?? []);
	if (!items.success) throw new AppError("INTERNAL_ERROR", "DataForSEO llm_mentions/cross_aggregated_metrics returned an invalid shape");
	return {
		data: items.data,
		billing: buildTaskBilling(task)
	};
}
async function fetchLlmResponse(input) {
	if (!await isKnownLlmModelName(input.modelSlug, input.modelName)) throw new AppError("VALIDATION_ERROR", `Unsupported DataForSEO model_name "${input.modelName}" for ${input.modelSlug}`);
	const webSearch = input.webSearch ?? true;
	if (webSearch && input.webSearchCountryCode && !supportsWebSearchCountry(input.modelSlug, input.webSearchCountryCode)) throw new AppError("VALIDATION_ERROR", `Unsupported web-search country ${input.webSearchCountryCode} for ${input.modelSlug}`);
	const fields = {
		user_prompt: input.userPrompt,
		model_name: input.modelName,
		web_search: webSearch,
		...webSearch && input.modelSlug === "claude" ? { force_web_search: true } : {},
		max_output_tokens: clampLimit(input.maxOutputTokens ?? 1024, 256, 4096),
		...webSearch && input.webSearchCountryCode ? { web_search_country_iso_code: input.webSearchCountryCode } : {}
	};
	const response = await dataforseoPost(`/v3/ai_optimization/${input.modelSlug}/llm_responses/live`, [fields], {
		classify: classifyAiSearchError,
		maxServerErrorRetries: 0
	});
	const task = assertOk(response, assertOptions(`/v3/ai_optimization/${input.modelSlug}/llm_responses/live`));
	const result = llmResponseResultSchema.safeParse(firstResult(task) ?? {});
	if (!result.success) throw new AppError("INTERNAL_ERROR", "DataForSEO llm_responses returned an invalid response shape");
	return {
		data: result.data,
		billing: buildTaskBilling(task)
	};
}
//#endregion
//#region src/server/lib/dataforseo/ai-tracking.ts
var AI_TRACKING_ENDPOINTS = {
	chatgpt: "/v3/ai_optimization/chat_gpt/llm_scraper",
	gemini: "/v3/ai_optimization/gemini/llm_scraper",
	google_ai_overview: "/v3/serp/google/organic"
};
/** Live engines have no LLM Scraper: their answers come from the live API. */
function trackingEndpoint(engine) {
	if (aiEngineUsesModelApi(engine)) throw new AppError("INTERNAL_ERROR", `${engine} answers cannot be queued`);
	return AI_TRACKING_ENDPOINTS[engine];
}
var LIVE_REQUEST_TIMEOUT_MS = 15e4;
/**
* The LLM Scraper language lists name three project-market languages
* differently, and Gemini only offers Brazilian Portuguese. The organic
* SERP uses the project-market codes.
*/
function providerLanguageCode(engine, languageCode) {
	if (engine === "google_ai_overview") return languageCode;
	if (languageCode === "nb") return "no";
	if (languageCode === "tl") return "fil";
	if (languageCode === "pt" && engine !== "chatgpt") return "pt-BR";
	return languageCode;
}
function aiTrackingTaskBody(engine, market, task) {
	return {
		keyword: task.prompt.replace(/%/g, "%25").replace(/\+/g, "%2B"),
		location_code: market.locationCode,
		language_code: providerLanguageCode(engine, market.languageCode),
		...engine === "google_ai_overview" ? {
			depth: 10,
			load_async_ai_overview: true
		} : {},
		tag: task.tag
	};
}
/**
* Posts up to 100 prompts for one engine. DataForSEO bills at task_post; the
* metered client holds credits for it and charges each task once its answer
* arrives. Rejected entries come back without a task; the caller fails their
* answers.
*/
async function postAiTrackingTasks(input) {
	if (input.tasks.length === 0 || input.tasks.length > 100) throw new AppError("INTERNAL_ERROR", `task_post accepts 1-100 tasks, got ${input.tasks.length}`);
	const endpoint = trackingEndpoint(input.engine);
	const response = await dataforseoPost(`${endpoint}/task_post`, input.tasks.map((task) => aiTrackingTaskBody(input.engine, input, task)), { maxServerErrorRetries: 0 });
	if (!response || response.status_code !== 2e4) throw failedResponseError(response, "DataForSEO task_post failed");
	const posted = [];
	let costUsd = 0;
	for (const entry of response.tasks ?? []) {
		costUsd += entry.cost ?? 0;
		const tag = entry.data?.tag;
		if (entry.status_code !== 20100 || !entry.id || typeof tag !== "string") {
			console.warn(`dataforseo.ai_tracking.task_post.rejected-entry (${entry.status_code}): ${entry.status_message}`);
			continue;
		}
		posted.push({
			tag,
			taskId: entry.id,
			costUsd: entry.cost ?? 0
		});
	}
	return {
		data: posted,
		billing: {
			path: `${endpoint}/task_post`.slice(1).split("/"),
			costUsd
		}
	};
}
/**
* Collects one queued answer. Not metered, like fetchRankCheckTaskResult: the
* task was charged at task_post.
*/
async function fetchAiTrackingTaskResult(input) {
	const response = await dataforseoGet(`${trackingEndpoint(input.engine)}/task_get/advanced/${encodeURIComponent(input.taskId)}`);
	const task = response?.tasks?.[0];
	if (!response || response.status_code !== 2e4 || !task) throw failedResponseError(response, "DataForSEO task_get failed");
	if (isTaskInProgress(task)) return { status: "pending" };
	return aiTrackingAnswer(task);
}
function aiTrackingAnswer(task) {
	if (task.status_code !== 2e4) {
		if (isNoResultsTask(task)) return {
			status: "completed",
			result: null
		};
		const upstream = isUpstreamFailureStatus(task.status_code);
		return {
			status: "failed",
			message: task.status_message || `DataForSEO task failed (${task.status_code})`,
			code: upstream ? "UPSTREAM_UNAVAILABLE" : "INTERNAL_ERROR",
			retryable: upstream
		};
	}
	return {
		status: "completed",
		result: task.result?.[0] ?? null
	};
}
/**
* Fetches one answer from the live endpoint. DataForSEO bills each live call,
* so this is the metered call. A failed task returns a failed outcome with
* its charge, so the caller fails only that answer.
*/
async function fetchAiTrackingLiveAnswer(input) {
	const endpoint = `${trackingEndpoint(input.engine)}/live/advanced`;
	const response = await dataforseoPost(endpoint, [aiTrackingTaskBody(input.engine, input, input.task)], {
		maxServerErrorRetries: 0,
		signal: AbortSignal.timeout(LIVE_REQUEST_TIMEOUT_MS)
	});
	const task = response?.tasks?.[0];
	if (!response || response.status_code !== 2e4 || !task) throw failedResponseError(response, "DataForSEO live request failed");
	return {
		data: aiTrackingAnswer(task),
		billing: {
			path: endpoint.slice(1).split("/"),
			costUsd: task.cost ?? 0
		}
	};
}
//#endregion
//#region src/server/lib/dataforseo/pricing.ts
/**
* Raw DataForSEO USD upper bound for one metered call, computed from the
* fetcher's input before the call is made. The metering seam reserves
* `creditsForProviderUsd(estimate)` and settles on the provider's real
* `cost`, so every number here must be >= what DataForSEO actually charges
* for that input. Overestimating only refuses a call slightly early at the
* tail of a balance; underestimating lets spend past the balance.
*
* Prices are raw (pre-markup) USD from DataForSEO's per-account price table
* (the `price` object on the free GET /v3/appendix/user_data), read Sep 2026.
* That table has only each endpoint's base price, so per-page, per-depth and
* token-priced shapes are "measured": set from real billed costs, which the
* free POST /v3/<api>/id_list returns per task alongside the request
* parameters for the last month. Re-check a price against id_list, not a
* one-off fixture.
*/
var LABS_TASK_USD = .012;
var LABS_ROW_USD = 12e-5;
var GOOGLE_ADS_LIVE_TASK_USD = .09;
var BACKLINKS_TASK_USD = .024;
var BACKLINKS_ROW_USD = 36e-6;
var BUSINESS_LISTINGS_TASK_USD = .012;
var BUSINESS_LISTINGS_ROW_USD = 36e-5;
var MY_BUSINESS_INFO_LIVE_USD = .0054;
var QUESTIONS_ANSWERS_PER_20_USD = .0054;
var REVIEWS_PRIORITY_TASK_USD = .001;
var REVIEWS_PRIORITY_PER_10_USD = .0015;
var EXTENDED_REVIEWS_PRIORITY_PER_20_USD = .01;
var UPDATES_PRIORITY_TASK_USD = .003;
var UPDATES_PRIORITY_PER_10_USD = .0015;
var LIGHTHOUSE_LIVE_USD = .005;
var LLM_MENTIONS_TASK_USD = .1;
var LLM_MENTIONS_ROW_USD = .001;
var LLM_MENTIONS_ONE_ROW_USD = .101;
var LLM_RESPONSE_USD = {
	chat_gpt: {
		webSearch: .09,
		noSearch: .05
	},
	claude: {
		webSearch: .18,
		noSearch: .08
	},
	gemini: {
		webSearch: .11,
		noSearch: .05
	},
	perplexity: {
		webSearch: .04,
		noSearch: .04
	}
};
/** Estimated USD for one live LLM response at the 4096-token output cap. */
function llmResponseUsd(modelSlug, webSearch) {
	const price = LLM_RESPONSE_USD[modelSlug];
	return webSearch ? price.webSearch : price.noSearch;
}
var LOCAL_SERP_PAGE_USD = .002;
var LOCAL_SERP_TASK_USD = .0012;
/** Ties an estimator to a fetcher so it is typed against that fetcher's input. */
function priced(_fetcher, estimate) {
	return estimate;
}
function labsUsd(rows, clickstream) {
	return (LABS_TASK_USD + rows * LABS_ROW_USD) * (clickstream ? 2 : 1);
}
function backlinksUsd(rows) {
	return BACKLINKS_TASK_USD + rows * BACKLINKS_ROW_USD;
}
/** SERP endpoints bill per page of 10; a partial page is a full page. */
function serpUsd(depth, keyword) {
	return costPerSerpAtDepth(Math.ceil(depth / 10) * 10) * serpKeywordCostMultiplier(keyword);
}
function daysInclusive(from, to) {
	const ms = new Date(to).getTime() - new Date(from).getTime();
	return Math.max(1, Math.floor(ms / 864e5) + 1);
}
/** One raw-USD upper-bound estimator per entry in createDataforseoClient. */
var dataforseoPricing = {
	business: {
		businessListings: priced(fetchBusinessListingsSearch, (input) => BUSINESS_LISTINGS_TASK_USD + input.limit * BUSINESS_LISTINGS_ROW_USD),
		questionsAnswers: priced(fetchQuestionsAnswers, (input) => Math.ceil(input.depth / 20) * QUESTIONS_ANSWERS_PER_20_USD),
		myBusinessInfo: priced(fetchMyBusinessInfo, () => MY_BUSINESS_INFO_LIVE_USD),
		reviewsTaskPost: priced(postGoogleReviewsTask, (input) => input.includeOtherSources ? Math.ceil(input.depth / 20) * EXTENDED_REVIEWS_PRIORITY_PER_20_USD : REVIEWS_PRIORITY_TASK_USD + Math.ceil(input.depth / 10) * REVIEWS_PRIORITY_PER_10_USD),
		updatesTaskPost: priced(postMyBusinessUpdatesTask, (input) => UPDATES_PRIORITY_TASK_USD + Math.ceil(input.depth / 10) * UPDATES_PRIORITY_PER_10_USD)
	},
	backlinks: {
		summary: priced(fetchBacklinksSummary, () => backlinksUsd(1)),
		rows: priced(fetchBacklinksRows, (input) => backlinksUsd(input.limit ?? 100)),
		referringDomains: priced(fetchReferringDomains, (input) => backlinksUsd(input.limit ?? 100)),
		domainPages: priced(fetchDomainPagesSummary, (input) => backlinksUsd(input.limit ?? 100)),
		history: priced(fetchBacklinksHistory, (input) => backlinksUsd(daysInclusive(input.dateFrom, input.dateTo)))
	},
	keywords: {
		related: priced(fetchRelatedKeywords, (input) => labsUsd(input.limit, input.includeClickstreamData)),
		suggestions: priced(fetchKeywordSuggestions, (input) => labsUsd(input.limit, input.includeClickstreamData)),
		ideas: priced(fetchKeywordIdeas, (input) => labsUsd(input.limit, input.includeClickstreamData)),
		adsIdeas: priced(fetchAdsKeywordIdeas, () => GOOGLE_ADS_LIVE_TASK_USD),
		adsSearchVolume: priced(fetchAdsSearchVolume, () => GOOGLE_ADS_LIVE_TASK_USD)
	},
	domain: {
		rankOverview: priced(fetchDomainRankOverview, () => labsUsd(1)),
		rankedKeywords: priced(fetchRankedKeywords, (input) => labsUsd(input.limit)),
		relevantPages: priced(fetchRelevantPages, (input) => labsUsd(input.limit))
	},
	serp: {
		readsTaskPost: priced(postSerpReadTasks, (input) => 6 * serpUsd(clampSerpDepth(input.depth ?? 10), input.keyword)),
		rankCheckTaskPost: priced(postRankCheckTasks, (input) => input.tasks.reduce((sum, task) => sum + serpUsd(clampSerpDepth(input.depth), task.keyword), 0)),
		local: priced(fetchLocalSerp, (input) => input.searchType === "maps" ? LOCAL_SERP_PAGE_USD : Math.ceil(input.depth / 10) * LOCAL_SERP_PAGE_USD),
		localTaskPost: priced(postLocalSerpTasks, (input) => input.locationCoordinates.length * LOCAL_SERP_TASK_USD)
	},
	labs: {
		keywordOverview: priced(fetchKeywordOverview, (input) => labsUsd(input.keywords.length, input.includeClickstreamData)),
		serpCompetitors: priced(fetchSerpCompetitors, (input) => labsUsd(input.limit))
	},
	lighthouse: { live: priced(fetchLighthouseResult, () => LIGHTHOUSE_LIVE_USD) },
	aiSearch: {
		mentionsSearch: priced(fetchLlmMentionsSearch, (input) => LLM_MENTIONS_TASK_USD + resolveLlmMentionsLimit(input.limit) * LLM_MENTIONS_ROW_USD),
		aggregatedMetrics: priced(fetchLlmAggregatedMetrics, () => LLM_MENTIONS_ONE_ROW_USD),
		topPages: priced(fetchLlmTopPages, () => LLM_MENTIONS_ONE_ROW_USD),
		crossAggregatedMetrics: priced(fetchLlmCrossAggregatedMetrics, () => LLM_MENTIONS_ONE_ROW_USD),
		trackingTaskPost: priced(postAiTrackingTasks, (input) => input.tasks.length * AI_RECORD_COST_USD),
		trackingLive: priced(fetchAiTrackingLiveAnswer, () => AI_LIVE_RECORD_COST_USD),
		llmResponse: priced(fetchLlmResponse, (input) => llmResponseUsd(input.modelSlug, input.webSearch ?? true))
	}
};
//#endregion
export { fetchRelatedKeywords as A, fetchBusinessDataTaskResult as B, fetchAdsSearchVolume as C, fetchKeywordOverview as D, fetchKeywordIdeas as E, fetchBacklinksRows as F, postGoogleReviewsTask as G, fetchBusinessListingsSearch as H, fetchBacklinksSummary as I, postMyBusinessUpdatesTask as K, fetchDomainPagesSummary as L, fetchSerpCompetitors as M, backlinksItemSchema as N, fetchKeywordSuggestions as O, fetchBacklinksHistory as P, fetchReferringDomains as R, fetchAdsKeywordIdeas as S, fetchDomainRankOverview as T, fetchMyBusinessInfo as U, fetchBusinessListingsCategories as V, fetchQuestionsAnswers as W, fetchSerpTaskResult as _, postAiTrackingTasks as a, postSerpReadTasks as b, fetchLlmMentionsSearch as c, resolveLatestLlmModelName as d, fetchLighthouseResult as f, fetchRankCheckTaskResult as g, fetchLocalSerpTaskResult as h, fetchAiTrackingTaskResult as i, fetchRelevantPages as j, fetchRankedKeywords as k, fetchLlmResponse as l, fetchLocalSerp as m, llmResponseUsd as n, fetchLlmAggregatedMetrics as o, fetchLiveSerp as p, fetchAiTrackingLiveAnswer as r, fetchLlmCrossAggregatedMetrics as s, dataforseoPricing as t, fetchLlmTopPages as u, postLocalSerpTasks as v, isAdsKeyword as w, serpSnapshotItemSchema as x, postRankCheckTasks as y, referringDomainItemSchema as z };
