import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
import { t as fetchSerpLocationsForCountry } from "./serp-locations-B8PLFv6B.js";
import { t as rankSerpLocations } from "./serp-location-search-C4BgGOiO.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/serverFunctions/serp-locations.ts?tss-serverfn-split
/** ISO 3166-1 alpha-2, e.g. "us" \u2014 DataForSEO rejects country names. */
var countryCodeField = string().regex(/^[a-z]{2}$/i);
var searchSerpLocationsSchema = object({
	query: string().min(1).max(100),
	countryCode: countryCodeField
});
var searchSerpLocations_createServerFn_handler = createServerRpc({
	id: "16b95567643a21275b38fde625b8e1428bd2aeaff2440637c2a21009637d64d9",
	name: "searchSerpLocations",
	filename: "src/serverFunctions/serp-locations.ts"
}, (opts) => searchSerpLocations.__executeServer(opts));
var searchSerpLocations = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(searchSerpLocationsSchema).handler(searchSerpLocations_createServerFn_handler, async ({ data }) => {
	const all = await fetchSerpLocationsForCountry(data.countryCode);
	return rankSerpLocations(data.query, all, data.countryCode);
});
var prewarmSerpLocations_createServerFn_handler = createServerRpc({
	id: "364efb68f010cdd93e01da48b22253ac6e745a792ce18710f489a70100cde203",
	name: "prewarmSerpLocations",
	filename: "src/serverFunctions/serp-locations.ts"
}, (opts) => prewarmSerpLocations.__executeServer(opts));
var prewarmSerpLocations = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(object({ countryCode: countryCodeField })).handler(prewarmSerpLocations_createServerFn_handler, async ({ data }) => {
	await fetchSerpLocationsForCountry(data.countryCode);
	return { warmed: true };
});
//#endregion
export { prewarmSerpLocations_createServerFn_handler, searchSerpLocations_createServerFn_handler };
