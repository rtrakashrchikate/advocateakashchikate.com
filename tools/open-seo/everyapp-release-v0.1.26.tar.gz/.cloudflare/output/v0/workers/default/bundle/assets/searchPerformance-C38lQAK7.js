import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { c as searchPerformanceTableExportInputSchema, l as searchPerformanceTableInputSchema, o as searchPerformanceInputSchema } from "./search-performance-_Wo3-qrs.js";
import { f as GscNotConnectedError, l as resolveDateRange, n as isExpectedGrantFailure, t as GscService } from "./GscService-BMp-LMRy.js";
import { a as sumSearchTotals, i as previousPeriod, n as buildDailyTrend, o as toDimensionRows, r as buildStrikingDistanceRows } from "./searchPerformanceReport-n3LTMTGm.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/serverFunctions/searchPerformance.ts?tss-serverfn-split
var STRIKING_DISTANCE_FETCH_LIMIT = 1e3;
var DAILY_ROW_LIMIT = 200;
var COUNTRY_ROW_LIMIT = 25;
var EXPORT_ROW_LIMIT = 1e3;
/** Build GSC filter groups shared by every call. Device, page, and query apply everywhere;
*  country applies everywhere except the country breakdown itself (so the
*  dropdown keeps every option visible while one country is selected). */
function buildGscFilters(data) {
	const nonCountryFilters = data.device ? [{
		dimension: "device",
		operator: "equals",
		expression: data.device
	}] : [];
	if (data.pageFilter) nonCountryFilters.push({
		dimension: "page",
		...data.pageFilter
	});
	if (data.queryFilter && data.searchType === "web") nonCountryFilters.push({
		dimension: "query",
		...data.queryFilter
	});
	return {
		nonCountryFilters,
		filters: data.country ? [...nonCountryFilters, {
			dimension: "country",
			operator: "equals",
			expression: data.country
		}] : nonCountryFilters
	};
}
/** Not connected, or a dead/denied grant (token failure or 401/403): the page
*  renders the connect card. Other statuses (429, 5xx) are real faults. */
function isExpectedConnectionFailure(error) {
	return error instanceof GscNotConnectedError || isExpectedGrantFailure(error);
}
/**
* The Search Performance overview: current + previous-period totals, the
* striking-distance rows, and the country list that powers the filter dropdown.
* The queries/pages tables paginate separately (getSearchPerformanceTable) so
* page-flips never re-run the striking-distance scan. All first-party GSC data,
* free.
*/
var getSearchPerformanceReport_createServerFn_handler = createServerRpc({
	id: "a251675043aa688af223c180c37e19f98f6652a33f993dc7d1b14c4ce4ed3589",
	name: "getSearchPerformanceReport",
	filename: "src/serverFunctions/searchPerformance.ts"
}, (opts) => getSearchPerformanceReport.__executeServer(opts));
var getSearchPerformanceReport = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(searchPerformanceInputSchema).handler(getSearchPerformanceReport_createServerFn_handler, async ({ data, context }) => {
	const { startDate, endDate } = resolveDateRange({ dateRange: data.dateRange });
	const prev = previousPeriod(startDate, endDate);
	const projectId = context.projectId;
	const { nonCountryFilters, filters } = buildGscFilters(data);
	const type = data.searchType;
	try {
		const [current, previous, queryPages, countries] = await Promise.all([
			GscService.getPerformance({
				projectId,
				startDate,
				endDate,
				type,
				dimensions: ["date"],
				filters,
				rowLimit: DAILY_ROW_LIMIT
			}),
			GscService.getPerformance({
				projectId,
				startDate: prev.startDate,
				endDate: prev.endDate,
				type,
				dimensions: ["date"],
				filters,
				rowLimit: DAILY_ROW_LIMIT
			}),
			type === "web" ? GscService.getPerformance({
				projectId,
				startDate,
				endDate,
				type,
				dimensions: ["query", "page"],
				filters,
				rowLimit: STRIKING_DISTANCE_FETCH_LIMIT
			}) : { rows: [] },
			GscService.getPerformance({
				projectId,
				startDate,
				endDate,
				type,
				dimensions: ["country"],
				filters: nonCountryFilters,
				rowLimit: COUNTRY_ROW_LIMIT
			})
		]);
		return {
			connected: true,
			range: {
				startDate,
				endDate,
				prevStartDate: prev.startDate,
				prevEndDate: prev.endDate
			},
			totals: sumSearchTotals(current.rows),
			prevTotals: sumSearchTotals(previous.rows),
			trend: buildDailyTrend(current.rows, startDate, endDate),
			strikingDistance: buildStrikingDistanceRows(queryPages.rows),
			countries: toDimensionRows(countries.rows)
		};
	} catch (error) {
		if (isExpectedConnectionFailure(error)) return { connected: false };
		throw error;
	}
});
var getSearchPerformanceTable_createServerFn_handler = createServerRpc({
	id: "a4aee3230867065a09c55145cf58c1f5bc0fb9ed2f053bda4ac2d635a4d2bcb4",
	name: "getSearchPerformanceTable",
	filename: "src/serverFunctions/searchPerformance.ts"
}, (opts) => getSearchPerformanceTable.__executeServer(opts));
var getSearchPerformanceTable = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(searchPerformanceTableInputSchema).handler(getSearchPerformanceTable_createServerFn_handler, async ({ data, context }) => {
	const { startDate, endDate } = resolveDateRange({ dateRange: data.dateRange });
	const { filters } = buildGscFilters(data);
	const offset = (data.page - 1) * data.pageSize;
	try {
		const result = await GscService.getPerformance({
			projectId: context.projectId,
			startDate,
			endDate,
			type: data.searchType,
			dimensions: [data.dimension],
			filters,
			rowLimit: data.pageSize + 1,
			startRow: offset
		});
		const fetched = toDimensionRows(result.rows);
		const hasNextPage = fetched.length > data.pageSize;
		const rows = hasNextPage ? fetched.slice(0, data.pageSize) : fetched;
		return {
			connected: true,
			dimension: data.dimension,
			page: data.page,
			pageSize: data.pageSize,
			hasNextPage,
			totalCount: !hasNextPage && (offset === 0 || rows.length > 0) ? offset + rows.length : null,
			rows
		};
	} catch (error) {
		if (isExpectedConnectionFailure(error)) return { connected: false };
		throw error;
	}
});
var exportSearchPerformanceTable_createServerFn_handler = createServerRpc({
	id: "03f6b933adea1749a90a3091b941383771384ee499865ac928e32750bb3b6da1",
	name: "exportSearchPerformanceTable",
	filename: "src/serverFunctions/searchPerformance.ts"
}, (opts) => exportSearchPerformanceTable.__executeServer(opts));
var exportSearchPerformanceTable = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(searchPerformanceTableExportInputSchema).handler(exportSearchPerformanceTable_createServerFn_handler, async ({ data, context }) => {
	const { startDate, endDate } = resolveDateRange({ dateRange: data.dateRange });
	const { filters } = buildGscFilters(data);
	const result = await GscService.getPerformance({
		projectId: context.projectId,
		startDate,
		endDate,
		type: data.searchType,
		dimensions: [data.dimension],
		filters,
		rowLimit: EXPORT_ROW_LIMIT
	});
	return {
		dimension: data.dimension,
		rows: toDimensionRows(result.rows)
	};
});
//#endregion
export { exportSearchPerformanceTable_createServerFn_handler, getSearchPerformanceReport_createServerFn_handler, getSearchPerformanceTable_createServerFn_handler };
