import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { o as devicesLabel, p as scheduleLabel, u as isScheduledRankTrackingInterval } from "./rank-tracking-CfsrxyGC.js";
import { a as SERP_LANGUAGE_OPTIONS, o as formatLocationLabel, r as LOCATIONS } from "./keyword-locations-4GfvBtRY.js";
import { j as useQueryClient, t as useQuery } from "./useQuery-B93OR2NQ.js";
import { _ as CircleAlert, c as Skeleton, d as useCreditBalance, g as EmptyState, l as GetCreditsButton, t as QueryError } from "./QueryState-Q8BZIblk.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { t as Archive } from "./archive-CtdwYGhq.js";
import { t as ChevronRight } from "./chevron-right-CMQSolKd.js";
import { t as Globe } from "./globe-CcyiZQla.js";
import { t as Info } from "./info-DgK-a8-X.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as Plus } from "./plus-C1Kukp-u.js";
import { t as TriangleAlert } from "./triangle-alert-C9SRPVjv.js";
import { r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { n as CardAction, o as CardHeader, s as CardTitle, t as Card } from "./card-CqQO-5bL.js";
import { t as Route } from "./rank-tracking-DbBxGhLe.js";
import { n as TooltipContent, r as TooltipTrigger, t as Tooltip } from "./tooltip-D5ss-ZNP.js";
import { t as ConfirmDialog } from "./ConfirmDialog-CI0zpKxJ.js";
import { n as parseDbTimestamp } from "./db-timestamp-D5yyHS4V.js";
import { n as formatNextCheck } from "./ScheduleField-AOI31vZV.js";
import { t as useDebouncedDraft } from "./useDebouncedDraft-Ixxzt3-2.js";
import { g as updateRankTrackingConfig, l as getRankTrackingConfigSummaries } from "./rank-tracking-DwOdsORG.js";
import { a as applyDomainListFilters, l as getDomainListFilterOptions, n as DomainListFilterBar, s as countActiveDomainListFilters, t as RankTrackingConfigModal, u as ScheduledChecksPausedAlert } from "./RankTrackingConfigModal-BCiTmDoJ.js";
//#region src/client/features/rank-tracking/RankTrackingDomainList.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var FILTER_BAR_MIN_DOMAINS = 6;
function RankTrackingDomainList({ projectId, search, onSearchChange, onAddDomain }) {
	const queryClient = useQueryClient();
	const [archiveTarget, setArchiveTarget] = (0, import_react.useState)(null);
	const [query, setQuery] = useDebouncedDraft(search.q ?? "", (q) => onSearchChange({
		...search,
		q: q || void 0
	}));
	const filters = {
		query,
		device: search.device ?? "all",
		locationCode: search.loc ? String(search.loc) : "all"
	};
	const setFilters = (next) => {
		setQuery(next.query);
		if (next.device === filters.device && next.locationCode === filters.locationCode) return;
		onSearchChange({
			q: next.query || void 0,
			device: next.device === "all" ? void 0 : next.device,
			loc: next.locationCode === "all" ? void 0 : Number(next.locationCode)
		});
	};
	const clearFilters = () => {
		setQuery("");
		onSearchChange({});
	};
	const summariesQuery = useQuery({
		queryKey: ["rankTrackingConfigSummaries", projectId],
		queryFn: () => getRankTrackingConfigSummaries({ data: { projectId } })
	});
	const summaries = summariesQuery.data;
	const allSummaries = (0, import_react.useMemo)(() => summaries ?? [], [summaries]);
	const filteredSummaries = applyDomainListFilters(allSummaries, filters);
	const filterOptions = (0, import_react.useMemo)(() => {
		const options = getDomainListFilterOptions(allSummaries);
		const { device, loc } = search;
		if (device && !options.devices.some((o) => o.value === device)) options.devices.push({
			value: device,
			label: devicesLabel(device)
		});
		if (loc && !options.locations.some((o) => o.value === String(loc))) options.locations.push({
			value: String(loc),
			label: LOCATIONS[loc] ?? String(loc)
		});
		return options;
	}, [allSummaries, search]);
	const activeFilterCount = countActiveDomainListFilters(filters);
	const archiveMutation = useMutation({
		mutationFn: (configId) => updateRankTrackingConfig({ data: {
			projectId,
			configId,
			isActive: false
		} }),
		onSuccess: () => {
			setArchiveTarget(null);
			queryClient.invalidateQueries({ queryKey: ["rankTrackingConfigSummaries", projectId] });
			queryClient.invalidateQueries({ queryKey: ["rankTrackingConfigs", projectId] });
			toast.success("Domain archived");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScheduledChecksPausedAlert, { hasScheduledCheck: allSummaries.some((summary) => isScheduledRankTrackingInterval(summary.scheduleInterval)) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "gap-0 py-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, {
				className: "px-5 pt-4 pb-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Tracked Domains"
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardAction, {
					className: "self-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: onAddDomain,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "data-icon": "inline-start" }), "Add Domain"]
					})
				})]
			}),
			(allSummaries.length >= FILTER_BAR_MIN_DOMAINS || activeFilterCount > 0) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DomainListFilterBar, {
				filters,
				options: filterOptions,
				activeFilterCount,
				onChange: setFilters,
				onReset: clearFilters
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "divide-y divide-border border-t border-border",
				children: [summariesQuery.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-5 py-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
						error: summariesQuery.error,
						fallback: "Failed to load tracked domains",
						onRetry: () => void summariesQuery.refetch(),
						isRetrying: summariesQuery.isFetching
					})
				}), summariesQuery.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-4 px-5 py-4",
					"aria-busy": true,
					children: Array.from({ length: 3 }).map((_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-48" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-72" })]
					}, index))
				}) : !summaries ? null : summaries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					variant: "plain",
					icon: Globe,
					title: "No tracked domains yet",
					description: "Add a domain to start monitoring keyword rankings over time."
				}) : filteredSummaries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					variant: "plain",
					kind: "filtered",
					title: "No matching tracked domains",
					description: "Try clearing search or adjusting filters.",
					action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: clearFilters,
						children: "Clear filters"
					})
				}) : filteredSummaries.map((summary) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DomainRow, {
					projectId,
					summary,
					showLanguage: allSummaries.some((other) => other.domain === summary.domain && other.locationCode === summary.locationCode && other.languageCode !== summary.languageCode),
					onArchive: () => setArchiveTarget(summary)
				}, summary.id))]
			}),
			archiveTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				title: `Archive ${archiveTarget.domain}?`,
				confirmLabel: "Archive",
				destructive: true,
				pending: archiveMutation.isPending,
				onConfirm: () => archiveMutation.mutate(archiveTarget.id),
				onClose: () => setArchiveTarget(null),
				children: "Scheduled checks will stop and this domain will be hidden from the list. Ranking history is preserved."
			})
		]
	})] });
}
/** A spent auto-reload budget holds credits back, so it isn't "out of credits". */
function CreditsSkipNotice() {
	const { autoReloadState } = useCreditBalance();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-1 flex items-center gap-2 text-xs text-destructive",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "size-3" }),
			"Scheduled check skipped: ",
			autoReloadState === "budget_spent" ? "monthly auto-reload budget reached" : "out of credits",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "pointer-events-auto relative z-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GetCreditsButton, {})
			})
		]
	});
}
function DomainRow({ projectId, summary, showLanguage, onArchive }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex w-full items-center gap-4 px-5 py-3.5 transition-colors hover:bg-foreground/[0.03]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/p/$projectId/rank-tracking/$configId",
				params: {
					projectId,
					configId: summary.id
				},
				className: "absolute inset-0 z-0",
				"aria-label": `Open ${summary.domain}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1 pointer-events-none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium truncate",
						children: summary.domain
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							summary.locationName ? formatLocationLabel(summary.locationName, 2) : LOCATIONS[summary.locationCode] ?? "US",
							" ",
							showLanguage && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								"\u00B7",
								" ",
								SERP_LANGUAGE_OPTIONS.find((option) => option.code === summary.languageCode)?.label ?? summary.languageCode,
								" "
							] }),
							"\u00B7 ",
							devicesLabel(summary.devices),
							" \u00B7",
							" ",
							scheduleLabel(summary.scheduleInterval),
							summary.scheduleInterval !== "manual" && summary.nextCheckAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" \u00B7 Next: ", formatNextCheck(summary.nextCheckAt)] }),
							summary.lastRunCompletedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								" ",
								"\u00B7 Last:",
								" ",
								parseDbTimestamp(summary.lastRunCompletedAt).toLocaleDateString(),
								summary.lastRunIncomplete && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
									render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										"aria-label": "Last check incomplete",
										className: "pointer-events-auto relative z-10 ml-1 inline-flex cursor-help align-text-bottom"
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
										className: "size-3.5",
										"aria-hidden": true
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: "Some results from the last check are missing." })] })
							] })
						]
					}),
					summary.lastSkipReason === "insufficient_credits" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditsSkipNotice, {}),
					summary.lastSkipReason === "plan_required" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-center gap-1 text-xs text-warning",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-3" }), "Scheduled check skipped \u2014 paid plan required"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "hidden sm:flex items-center gap-6 text-sm pointer-events-none",
				children: summary.keywordCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-wide text-muted-foreground",
						children: "Keywords"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono font-medium",
						children: summary.keywordCount
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon-xs",
				className: "relative z-10 text-muted-foreground hover:text-destructive",
				title: "Archive domain",
				"aria-label": `Archive ${summary.domain}`,
				onClick: (e) => {
					e.stopPropagation();
					e.preventDefault();
					onArchive();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, { className: "size-4" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 shrink-0 text-muted-foreground pointer-events-none" })
		]
	});
}
//#endregion
//#region src/client/features/rank-tracking/RankTrackingChangesAlert.tsx
function RankTrackingChangesAlert() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "info",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, {
			className: "text-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "Rank tracking now reads every keyword several times."
				}),
				" ",
				"Since September, Google has been serving incomplete results to all rank trackers.",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://openseo.so/blogs/state-of-rank-tracking-november-2026",
					target: "_blank",
					rel: "noopener noreferrer",
					className: "font-medium underline underline-offset-4",
					children: "Read what changed"
				})
			] })
		})]
	});
}
//#endregion
//#region src/routes/_app/p/$projectId/rank-tracking/index.tsx?tsr-split=component
function RankTrackingIndex() {
	const { projectId } = Route.useParams();
	const navigate = useNavigate();
	const search = Route.useSearch();
	const queryClient = useQueryClient();
	const [showConfigModal, setShowConfigModal] = (0, import_react.useState)(false);
	const invalidateConfigs = () => {
		queryClient.invalidateQueries({ queryKey: ["rankTrackingConfigs", projectId] });
		queryClient.invalidateQueries({ queryKey: ["rankTrackingConfigSummaries", projectId] });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrackingChangesAlert, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrackingDomainList, {
				projectId,
				search,
				onSearchChange: (next) => {
					navigate({
						from: Route.fullPath,
						search: next,
						replace: true
					});
				},
				onAddDomain: () => setShowConfigModal(true)
			}),
			showConfigModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrackingConfigModal, {
				projectId,
				existingConfig: null,
				onClose: () => setShowConfigModal(false),
				onConfigCreated: invalidateConfigs,
				onSaved: (createdConfigId) => {
					setShowConfigModal(false);
					invalidateConfigs();
					if (createdConfigId) navigate({
						to: "/p/$projectId/rank-tracking/$configId",
						params: {
							projectId,
							configId: createdConfigId
						}
					});
				}
			})
		]
	});
}
//#endregion
export { RankTrackingIndex as component };
