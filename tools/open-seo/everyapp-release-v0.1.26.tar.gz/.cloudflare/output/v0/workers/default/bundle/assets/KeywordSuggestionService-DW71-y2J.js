import { Et as _enum, Fn as object, Jn as string, Lt as boolean, Nt as array, Pn as number, or as union } from "./schemas-BPIpYT5n.js";
import { U as AppError } from "./onboarding-drip-B7bIbv_6.js";
import { G as eq, H as asc, J as gte, U as desc, W as and, X as inArray, at as notInArray, ct as sql, t as db, tt as lte } from "./db-DhHkpZWI.js";
import { t as count } from "./aggregate-CkzWoiih.js";
import { J as savedKeywords, K as savedKeywordTagAssignments, R as projects, S as keywordMetrics, q as savedKeywordTags } from "./schema-Cn_vcAkd.js";
import { n as runBatch } from "./runBatch-CENJH-Sm.js";
import { o as isHostedServerAuthMode } from "./runtime-env-eoXh4Ywz.js";
import { a as getCached, n as CACHE_TTL, o as setCached, r as buildCacheKey, s as t } from "./r2-cache-DRcgqCM_.js";
import { t as checkUsageCreditsDepleted } from "./subscription-DYEizD5D.js";
import { t as createDataforseoClient } from "./client-D7Glrscv.js";
import { _ as fetchSerpTaskResult, x as serpSnapshotItemSchema } from "./pricing-CjqMqwbe.js";
import { c as getKeywordDataProvider, i as LOCATION_OPTIONS, o as formatLocationLabel, s as getIsoCountryCode } from "./keyword-locations-4GfvBtRY.js";
import { n as fetchKeywordMetricsForList, t as fetchAdsSearchVolumeForKeywords } from "./keyword-metrics-Dws_fIDn.js";
import { r as writeResearchKeywords, t as AiVisibilityRepository } from "./AiVisibilityRepository-BleS-LTq.js";
import { t as researchWebsite } from "./websiteResearch-COwYhfGf.js";
import { t as jsonCodec } from "./json-BlSCT10u.js";
import { i as wildcardAnchor, n as hasKeywordWildcard, r as keywordWildcardError, t as KeywordSuggestionReason } from "./keyword-suggestions-RofatJrC.js";
import { a as joinClauses, i as escapeLikeTerm } from "./filters-BOEIvD_t.js";
import { t as fetchSerpLocationsForCountry } from "./serp-locations-B8PLFv6B.js";
import { f as GscNotConnectedError, l as resolveDateRange, n as isExpectedGrantFailure, t as GscService } from "./GscService-BMp-LMRy.js";
import { t as formatCount } from "./format-hVsegOKI.js";
import { t as bestPagePerQuery } from "./searchPerformanceReport-n3LTMTGm.js";
import { env, waitUntil } from "cloudflare:workers";
//#region src/server/features/keywords/services/research/helpers.ts
function normalizeKeyword(input) {
	return input.trim().toLowerCase();
}
/**
* Alternates rows from two sources into one list, deduping by keyword, so a
* volume-sorted source can't crowd out the other before the limit is reached.
*/
function interleaveRows(first, second, limit) {
	const rows = [];
	const seen = /* @__PURE__ */ new Set();
	const longest = Math.max(first.length, second.length);
	for (let i = 0; i < longest && rows.length < limit; i++) for (const source of [first, second]) {
		const row = source[i];
		if (!row || seen.has(row.keyword) || rows.length >= limit) continue;
		seen.add(row.keyword);
		rows.push(row);
	}
	return rows;
}
function normalizeIntent(raw) {
	if (!raw) return "unknown";
	const value = raw.toLowerCase();
	if (value.includes("inform")) return "informational";
	if (value.includes("commerc")) return "commercial";
	if (value.includes("transact")) return "transactional";
	if (value.includes("navig")) return "navigational";
	return "unknown";
}
//#endregion
//#region src/server/features/keywords/services/research/research-data.ts
function mapKeywordDataItems(items) {
	const rows = [];
	const seen = /* @__PURE__ */ new Set();
	for (const item of items) {
		const keyword = item.keyword;
		if (!keyword) continue;
		const normalized = normalizeKeyword(keyword);
		if (seen.has(normalized)) continue;
		seen.add(normalized);
		const keywordInfo = item.keyword_info_normalized_with_clickstream?.search_volume ? item.keyword_info_normalized_with_clickstream : item.keyword_info;
		rows.push({
			keyword: normalized,
			searchVolume: keywordInfo?.search_volume ?? null,
			trend: (keywordInfo?.monthly_searches ?? []).map((entry) => ({
				year: entry.year ?? 0,
				month: entry.month ?? 0,
				searchVolume: entry.search_volume ?? 0
			})),
			cpc: item.keyword_info?.cpc ?? null,
			competition: item.keyword_info?.competition ?? null,
			keywordDifficulty: item.keyword_properties?.keyword_difficulty ?? null,
			intent: normalizeIntent(item.search_intent_info?.main_intent)
		});
	}
	return rows;
}
/**
* Google Ads items carry volume / CPC / paid competition but no keyword
* difficulty or search intent (those are Labs-only).
*/
function mapAdsKeywordItems(items) {
	const rows = [];
	const seen = /* @__PURE__ */ new Set();
	for (const item of items) {
		const keyword = item.keyword;
		if (!keyword) continue;
		const normalized = normalizeKeyword(keyword);
		if (seen.has(normalized)) continue;
		seen.add(normalized);
		rows.push({
			keyword: normalized,
			searchVolume: item.search_volume ?? null,
			trend: (item.monthly_searches ?? []).map((entry) => ({
				year: entry.year ?? 0,
				month: entry.month ?? 0,
				searchVolume: entry.search_volume ?? 0
			})),
			cpc: item.cpc ?? null,
			competition: item.competition_index != null ? item.competition_index / 100 : null,
			keywordDifficulty: null,
			intent: "unknown"
		});
	}
	return rows;
}
/** Research rows for countries DataForSEO Labs doesn't support. */
async function fetchGoogleAdsResearchRows(params, billingCustomer) {
	return mapAdsKeywordItems(await createDataforseoClient(billingCustomer).keywords.adsIdeas({
		keyword: params.seedKeyword,
		locationCode: params.locationCode,
		languageCode: params.languageCode,
		limit: params.resultLimit,
		creditFeature: params.creditFeature
	}));
}
async function fetchRelatedRows(params, dataforseo) {
	return mapKeywordDataItems((await dataforseo.keywords.related({
		keyword: params.seedKeyword,
		locationCode: params.locationCode,
		languageCode: params.languageCode,
		limit: params.resultLimit,
		depth: 3,
		includeClickstreamData: params.includeClickstreamData,
		ignoreSynonyms: params.ignoreSynonyms,
		creditFeature: params.creditFeature
	})).map((item) => item.keyword_data).filter((data) => data != null));
}
async function fetchResearchRowsBySource(params, billingCustomer) {
	const dataforseo = createDataforseoClient(billingCustomer);
	if (params.source === "related") return fetchRelatedRows(params, dataforseo);
	if (params.source === "suggestions") return mapKeywordDataItems(await dataforseo.keywords.suggestions({
		keyword: params.seedKeyword,
		locationCode: params.locationCode,
		languageCode: params.languageCode,
		limit: params.resultLimit,
		includeClickstreamData: params.includeClickstreamData,
		ignoreSynonyms: params.ignoreSynonyms,
		filters: params.filters,
		creditFeature: params.creditFeature
	}));
	return mapKeywordDataItems(await dataforseo.keywords.ideas({
		keyword: params.seedKeyword,
		locationCode: params.locationCode,
		languageCode: params.languageCode,
		limit: params.resultLimit,
		includeClickstreamData: params.includeClickstreamData,
		ignoreSynonyms: params.ignoreSynonyms,
		creditFeature: params.creditFeature
	}));
}
//#endregion
//#region src/server/features/keywords/services/research/local-volume.ts
/**
* Reject a location that is not a city, county, or region of the country
* before any paid call runs. The registry is the same list the location
* picker searches, so it also keeps postal codes out.
*/
async function assertLocalResearchLocation(locationCode, locationName) {
	if ((await fetchSerpLocationsForCountry(getIsoCountryCode(locationCode))).some((location) => location.locationName === locationName)) return;
	const country = LOCATION_OPTIONS.find((option) => option.code === locationCode)?.label ?? "this country";
	throw new AppError("UNKNOWN_LOCATION", `"${formatLocationLabel(locationName)}" is not a city, county, or region we can find in ${country}.`);
}
/**
* Replace each row's volume, trend, CPC, and competition with Google Ads
* numbers for one city, county, or region. Keyword difficulty and intent stay
* national: Labs only serves countries. A keyword Google Ads does not return
* (collapsed close variants, or text Ads rejects) gets null metrics, never the
* national numbers.
*/
async function localizeResearchRows(rows, params, billingCustomer) {
	const items = await fetchAdsSearchVolumeForKeywords(createDataforseoClient(billingCustomer), {
		...params,
		keywords: rows.map((row) => row.keyword)
	});
	const localByKeyword = new Map(mapAdsKeywordItems(items).map((local) => [local.keyword, local]));
	return rows.map((row) => {
		const local = localByKeyword.get(row.keyword);
		return {
			...row,
			searchVolume: local?.searchVolume ?? null,
			trend: local?.trend ?? [],
			cpc: local?.cpc ?? null,
			competition: local?.competition ?? null
		};
	});
}
//#endregion
//#region src/server/features/keywords/services/research/serpReads.ts
var READ_COLLECT_MS = 4e4;
var READ_POLL_INTERVAL_MS = 3e3;
var READ_POLL_MIN_MS = 1e3;
var READ_RECEIPT_TTL_SECONDS = 43200;
var readReceiptSchema = union([array(string()).min(1), object({ reads: array(array(serpSnapshotItemSchema)) })]);
var FUSION_K = 60;
function wait(ms) {
	return new Promise((resolve) => setTimeout(resolve, ms));
}
/** One organic row per site; a SERP feature row per type and site. */
function mergeKey(item) {
	const site = item.domain?.toLowerCase().replace(/^www\./, "");
	return `${item.type}|${site ?? item.title ?? ""}`;
}
function bestPosition(item) {
	return item.rank_group ?? item.rank_absolute ?? Number.MAX_SAFE_INTEGER;
}
/**
* Merges several reads of one SERP. Organic rows come first, the sites the
* reads agree on at the top, each reported at the best position any read gave
* it. SERP features follow in page order.
*/
function mergeSerpReads(reads) {
	const rows = /* @__PURE__ */ new Map();
	for (const read of reads) {
		const seenOnRead = /* @__PURE__ */ new Set();
		for (const item of read) {
			const key = mergeKey(item);
			if (seenOnRead.has(key)) continue;
			seenOnRead.add(key);
			const row = rows.get(key);
			const score = 1 / (FUSION_K + bestPosition(item));
			if (!row) {
				rows.set(key, {
					item,
					seenIn: 1,
					score
				});
				continue;
			}
			row.seenIn += 1;
			row.score += score;
			if (bestPosition(item) < bestPosition(row.item)) row.item = item;
		}
	}
	const all = [...rows.values()];
	const organic = all.filter((row) => row.item.type === "organic");
	organic.sort((a, b) => b.score - a.score);
	const features = all.filter((row) => row.item.type !== "organic");
	features.sort((a, b) => (a.item.rank_absolute ?? Number.MAX_SAFE_INTEGER) - (b.item.rank_absolute ?? Number.MAX_SAFE_INTEGER));
	return [...organic, ...features].map((row) => ({
		...row.item,
		seenIn: row.seenIn
	}));
}
/** Polls one read until it finishes or the deadline passes, or just once. */
async function collectRead(taskId, deadline, once) {
	for (;;) {
		const outcome = await fetchSerpTaskResult(taskId, AbortSignal.timeout(Math.max(deadline - Date.now(), READ_POLL_MIN_MS))).catch((error) => {
			console.warn(`serp-reads.poll failed for ${taskId}:`, error);
			return { status: "pending" };
		});
		if (once || outcome.status !== "pending" || Date.now() + READ_POLL_INTERVAL_MS > deadline) return outcome;
		await wait(READ_POLL_INTERVAL_MS);
	}
}
function forgetReceipt(receiptKey) {
	return setCached(receiptKey, null, 0).catch((error) => {
		console.error("serp-reads.receipt-reset failed:", error);
	});
}
async function collectMergedSerp(taskIds, receiptKey, deadline, { replay }) {
	const reads = await Promise.all(taskIds.map((taskId) => collectRead(taskId, deadline, replay)));
	const completed = reads.flatMap((read) => read.status === "completed" ? [read.items] : []);
	const items = mergeSerpReads(completed);
	const pending = reads.some((read) => read.status === "pending");
	if (items.length > 0) {
		if (!pending) await setCached(receiptKey, { reads: completed }, READ_RECEIPT_TTL_SECONDS).catch((error) => {
			console.error("serp-reads.result-write failed:", error);
		});
		return {
			status: "completed",
			items
		};
	}
	if (pending) return { status: "processing" };
	await forgetReceipt(receiptKey);
	const failed = reads.find((read) => read.status === "failed");
	if (failed?.status === "failed") return {
		status: "failed",
		error: new AppError("UPSTREAM_UNAVAILABLE", `Every read of this search failed at DataForSEO: ${failed.message}`)
	};
	return {
		status: "completed",
		items: []
	};
}
/**
* Reads each query several times and merges the reads, because any one read can
* be a poisoned page. Reads that aren't back by the deadline are left out of
* the merge; the same query again collects them at no charge. Resolves per
* query, in order.
*/
async function readMergedSerps(billing, requests) {
	const deadline = Date.now() + READ_COLLECT_MS;
	const receipts = await Promise.all(requests.map(async ({ receiptKey }) => {
		const receipt = readReceiptSchema.safeParse(await getCached(receiptKey));
		return receipt.success ? receipt.data : null;
	}));
	const toPost = requests.filter((_, index) => receipts[index] === null);
	const posted = toPost.length > 0 ? await createDataforseoClient(billing).serp.readsTaskPostBatch(toPost.map(({ query }) => query)).catch((reason) => toPost.map(() => ({
		status: "rejected",
		reason
	}))) : [];
	return Promise.all(requests.map(async (request, index) => {
		const receipt = receipts[index];
		if (receipt && "reads" in receipt) return {
			status: "completed",
			items: mergeSerpReads(receipt.reads)
		};
		if (receipt) return collectMergedSerp(receipt, request.receiptKey, deadline, { replay: true });
		const outcome = posted[toPost.indexOf(request)];
		if (outcome.status === "rejected") return {
			status: "failed",
			error: outcome.reason
		};
		await setCached(request.receiptKey, outcome.value, READ_RECEIPT_TTL_SECONDS).catch((error) => {
			console.error("serp-reads.receipt-write failed:", error);
		});
		return collectMergedSerp(outcome.value, request.receiptKey, deadline, { replay: false });
	}));
}
//#endregion
//#region src/shared/saved-keyword-tags.ts
function normalizeSavedKeywordTag(value) {
	const name = value.trim().replace(/\s+/g, " ");
	if (name.length === 0) return null;
	return {
		name,
		normalizedName: name.toLocaleLowerCase()
	};
}
function normalizeSavedKeywordTags(values) {
	const tags = /* @__PURE__ */ new Map();
	for (const value of values ?? []) {
		const tag = normalizeSavedKeywordTag(value);
		if (!tag || tags.has(tag.normalizedName)) continue;
		tags.set(tag.normalizedName, tag);
	}
	return [...tags.values()];
}
//#endregion
//#region src/server/features/keywords/repositories/SavedKeywordTagsRepository.ts
var QUERY_CHUNK_SIZE$1 = 80;
var DELETE_PAIR_CHUNK_SIZE = 45;
var ASSIGNMENT_INSERT_CHUNK_SIZE = 40;
var REPLACE_DELETE_KEYWORD_CHUNK_SIZE = 70;
async function getTagFilterIds(params) {
	const directTagIds = params.tagIds ?? [];
	const normalizedTags = normalizeSavedKeywordTags(params.tagNames);
	if (normalizedTags.length === 0) return {
		tagIds: [...new Set(directTagIds)],
		emptyTagNameMatch: false
	};
	const rows = await db.select({ id: savedKeywordTags.id }).from(savedKeywordTags).where(and(eq(savedKeywordTags.projectId, params.projectId), inArray(savedKeywordTags.normalizedName, normalizedTags.map((tag) => tag.normalizedName))));
	return {
		tagIds: [.../* @__PURE__ */ new Set([...directTagIds, ...rows.map((row) => row.id)])],
		emptyTagNameMatch: directTagIds.length === 0 && rows.length === 0
	};
}
async function listSavedKeywordTagsByProject(projectId) {
	return db.select({
		id: savedKeywordTags.id,
		projectId: savedKeywordTags.projectId,
		name: savedKeywordTags.name,
		normalizedName: savedKeywordTags.normalizedName,
		color: savedKeywordTags.color,
		createdAt: savedKeywordTags.createdAt,
		keywordCount: count(savedKeywordTagAssignments.savedKeywordId)
	}).from(savedKeywordTags).leftJoin(savedKeywordTagAssignments, eq(savedKeywordTagAssignments.tagId, savedKeywordTags.id)).where(eq(savedKeywordTags.projectId, projectId)).groupBy(savedKeywordTags.id, savedKeywordTags.projectId, savedKeywordTags.name, savedKeywordTags.normalizedName, savedKeywordTags.color, savedKeywordTags.createdAt).orderBy(asc(savedKeywordTags.normalizedName));
}
async function listTagsBySavedKeywordIds(projectId, savedKeywordIds) {
	const tagsByKeywordId = /* @__PURE__ */ new Map();
	if (savedKeywordIds.length === 0) return tagsByKeywordId;
	for (let i = 0; i < savedKeywordIds.length; i += QUERY_CHUNK_SIZE$1) {
		const chunk = savedKeywordIds.slice(i, i + QUERY_CHUNK_SIZE$1);
		const rows = await db.select({
			savedKeywordId: savedKeywordTagAssignments.savedKeywordId,
			tag: savedKeywordTags
		}).from(savedKeywordTagAssignments).innerJoin(savedKeywordTags, eq(savedKeywordTags.id, savedKeywordTagAssignments.tagId)).where(and(eq(savedKeywordTags.projectId, projectId), inArray(savedKeywordTagAssignments.savedKeywordId, chunk))).orderBy(asc(savedKeywordTags.normalizedName));
		for (const { savedKeywordId, tag } of rows) {
			const tags = tagsByKeywordId.get(savedKeywordId) ?? [];
			tags.push(tag);
			tagsByKeywordId.set(savedKeywordId, tags);
		}
	}
	return tagsByKeywordId;
}
async function addTagsToSavedKeywords(params) {
	const savedKeywordRows = await listSavedKeywordRowsByIds(params.projectId, params.savedKeywordIds);
	if (savedKeywordRows.length === 0) return {
		savedKeywordCount: 0,
		tags: []
	};
	const tags = await upsertSavedKeywordTags(params.projectId, params.tagNames);
	const assignments = savedKeywordRows.flatMap((row) => tags.map((tag) => ({
		savedKeywordId: row.id,
		tagId: tag.id
	})));
	for (let i = 0; i < assignments.length; i += ASSIGNMENT_INSERT_CHUNK_SIZE) {
		const chunk = assignments.slice(i, i + ASSIGNMENT_INSERT_CHUNK_SIZE);
		await db.insert(savedKeywordTagAssignments).values(chunk).onConflictDoNothing();
	}
	return {
		savedKeywordCount: savedKeywordRows.length,
		tags
	};
}
async function replaceTagsForSavedKeywords(params) {
	const addResult = await addTagsToSavedKeywords(params);
	const keepTagIds = addResult.tags.map((tag) => tag.id);
	if (addResult.savedKeywordCount === 0 || keepTagIds.length === 0) return {
		...addResult,
		removedCount: 0
	};
	let removedCount = 0;
	for (let i = 0; i < params.savedKeywordIds.length; i += REPLACE_DELETE_KEYWORD_CHUNK_SIZE) {
		const chunk = params.savedKeywordIds.slice(i, i + REPLACE_DELETE_KEYWORD_CHUNK_SIZE);
		const savedKeywordIds = (await listSavedKeywordRowsByIds(params.projectId, chunk)).map((row) => row.id);
		if (savedKeywordIds.length === 0) continue;
		const deleted = await db.delete(savedKeywordTagAssignments).where(and(inArray(savedKeywordTagAssignments.savedKeywordId, savedKeywordIds), notInArray(savedKeywordTagAssignments.tagId, keepTagIds))).returning({ id: savedKeywordTagAssignments.savedKeywordId });
		removedCount += deleted.length;
	}
	return {
		...addResult,
		removedCount
	};
}
async function removeTagsFromSavedKeywords(params) {
	const [savedKeywordRows, tags] = await Promise.all([listSavedKeywordRowsByIds(params.projectId, params.savedKeywordIds), listSavedKeywordTagsByIds(params.projectId, params.tagIds)]);
	const savedKeywordIds = savedKeywordRows.map((row) => row.id);
	const tagIds = tags.map((tag) => tag.id);
	let removedCount = 0;
	for (let i = 0; i < savedKeywordIds.length; i += DELETE_PAIR_CHUNK_SIZE) {
		const savedKeywordChunk = savedKeywordIds.slice(i, i + DELETE_PAIR_CHUNK_SIZE);
		for (let j = 0; j < tagIds.length; j += DELETE_PAIR_CHUNK_SIZE) {
			const tagChunk = tagIds.slice(j, j + DELETE_PAIR_CHUNK_SIZE);
			const deleted = await db.delete(savedKeywordTagAssignments).where(and(inArray(savedKeywordTagAssignments.savedKeywordId, savedKeywordChunk), inArray(savedKeywordTagAssignments.tagId, tagChunk))).returning({ tagId: savedKeywordTagAssignments.tagId });
			removedCount += deleted.length;
		}
	}
	return {
		removedCount,
		savedKeywordCount: savedKeywordRows.length,
		tags
	};
}
async function removeAllTagsFromSavedKeywords(params) {
	const savedKeywordRows = await listSavedKeywordRowsByIds(params.projectId, params.savedKeywordIds);
	let removedCount = 0;
	for (let i = 0; i < savedKeywordRows.length; i += QUERY_CHUNK_SIZE$1) {
		const chunk = savedKeywordRows.slice(i, i + QUERY_CHUNK_SIZE$1);
		const deleted = await db.delete(savedKeywordTagAssignments).where(inArray(savedKeywordTagAssignments.savedKeywordId, chunk.map((row) => row.id))).returning({ id: savedKeywordTagAssignments.savedKeywordId });
		removedCount += deleted.length;
	}
	return {
		removedCount,
		savedKeywordCount: savedKeywordRows.length
	};
}
async function upsertSavedKeywordTags(projectId, tagNames) {
	const normalizedTags = normalizeSavedKeywordTags(tagNames);
	if (normalizedTags.length === 0) return [];
	await runBatch((tx) => normalizedTags.map((tag) => tx.insert(savedKeywordTags).values({
		id: crypto.randomUUID(),
		projectId,
		name: tag.name,
		normalizedName: tag.normalizedName
	}).onConflictDoNothing()));
	return db.select().from(savedKeywordTags).where(and(eq(savedKeywordTags.projectId, projectId), inArray(savedKeywordTags.normalizedName, normalizedTags.map((tag) => tag.normalizedName)))).orderBy(asc(savedKeywordTags.normalizedName));
}
async function listSavedKeywordRowsByIds(projectId, savedKeywordIds) {
	const rows = [];
	for (let i = 0; i < savedKeywordIds.length; i += QUERY_CHUNK_SIZE$1) {
		const chunk = savedKeywordIds.slice(i, i + QUERY_CHUNK_SIZE$1);
		rows.push(...await db.select().from(savedKeywords).where(and(eq(savedKeywords.projectId, projectId), inArray(savedKeywords.id, chunk))));
	}
	return rows;
}
async function listSavedKeywordTagsByIds(projectId, tagIds) {
	if (tagIds.length === 0) return [];
	const rows = [];
	for (let i = 0; i < tagIds.length; i += QUERY_CHUNK_SIZE$1) {
		const chunk = tagIds.slice(i, i + QUERY_CHUNK_SIZE$1);
		rows.push(...await db.select().from(savedKeywordTags).where(and(eq(savedKeywordTags.projectId, projectId), inArray(savedKeywordTags.id, chunk))));
	}
	return rows;
}
async function updateSavedKeywordTag$1(params) {
	const updates = {};
	if (params.name !== void 0) {
		const normalizedTag = normalizeSavedKeywordTag(params.name);
		if (!normalizedTag) return null;
		updates.name = normalizedTag.name;
		updates.normalizedName = normalizedTag.normalizedName;
	}
	if (params.color !== void 0) updates.color = params.color;
	if (Object.keys(updates).length === 0) return null;
	const [updated] = await db.update(savedKeywordTags).set(updates).where(and(eq(savedKeywordTags.projectId, params.projectId), eq(savedKeywordTags.id, params.tagId))).returning();
	return updated ?? null;
}
async function deleteSavedKeywordTag$1(params) {
	const [tag] = await db.select({ id: savedKeywordTags.id }).from(savedKeywordTags).where(and(eq(savedKeywordTags.projectId, params.projectId), eq(savedKeywordTags.id, params.tagId)));
	if (!tag) return { status: "not_found" };
	const [{ value: assignmentCount } = { value: 0 }] = await db.select({ value: count() }).from(savedKeywordTagAssignments).where(eq(savedKeywordTagAssignments.tagId, params.tagId));
	if (assignmentCount > 0) return {
		status: "in_use",
		assignmentCount
	};
	return (await db.delete(savedKeywordTags).where(and(eq(savedKeywordTags.projectId, params.projectId), eq(savedKeywordTags.id, params.tagId))).returning({ id: savedKeywordTags.id })).length > 0 ? { status: "deleted" } : { status: "not_found" };
}
var SavedKeywordTagsRepository = {
	getTagFilterIds,
	listSavedKeywordTagsByProject,
	listTagsBySavedKeywordIds,
	addTagsToSavedKeywords,
	replaceTagsForSavedKeywords,
	removeTagsFromSavedKeywords,
	removeAllTagsFromSavedKeywords,
	updateSavedKeywordTag: updateSavedKeywordTag$1,
	deleteSavedKeywordTag: deleteSavedKeywordTag$1
};
//#endregion
//#region src/server/features/keywords/repositories/KeywordResearchRepository.ts
async function upsertKeywordMetric(params) {
	const fetchedAt = (/* @__PURE__ */ new Date()).toISOString();
	await db.insert(keywordMetrics).values({
		projectId: params.projectId,
		keyword: params.keyword,
		locationCode: params.locationCode,
		languageCode: params.languageCode,
		searchVolume: params.searchVolume,
		cpc: params.cpc,
		competition: params.competition,
		keywordDifficulty: params.keywordDifficulty,
		intent: params.intent,
		monthlySearches: params.monthlySearchesJson,
		fetchedAt
	}).onConflictDoUpdate({
		target: [
			keywordMetrics.projectId,
			keywordMetrics.keyword,
			keywordMetrics.locationCode,
			keywordMetrics.languageCode
		],
		set: {
			searchVolume: params.searchVolume,
			cpc: params.cpc,
			competition: params.competition,
			keywordDifficulty: params.keywordDifficulty,
			intent: params.intent,
			monthlySearches: params.monthlySearchesJson,
			fetchedAt
		}
	});
}
async function countSavedKeywords(projectId) {
	const [result] = await db.select({ value: count() }).from(savedKeywords).where(eq(savedKeywords.projectId, projectId));
	return result?.value ?? 0;
}
async function saveKeywordsToProject(params) {
	if (params.keywords.length === 0) return [];
	await runBatch((tx) => params.keywords.map((keyword) => tx.insert(savedKeywords).values({
		id: crypto.randomUUID(),
		projectId: params.projectId,
		keyword,
		locationCode: params.locationCode,
		languageCode: params.languageCode
	}).onConflictDoNothing()));
	return listSavedKeywordRowsByKeywords(params);
}
function escapeLike(value) {
	return value.replace(/[\\%_]/g, (char) => `\\${char}`);
}
function buildSavedKeywordWhere(params) {
	const clauses = [eq(savedKeywords.projectId, params.projectId)];
	const search = params.search?.trim();
	if (search) clauses.push(sql`lower(${savedKeywords.keyword}) like ${`%${escapeLike(search.toLocaleLowerCase())}%`} escape '\\'`);
	for (const term of params.includeTerms ?? []) {
		const trimmed = term.trim();
		if (!trimmed) continue;
		clauses.push(sql`lower(${savedKeywords.keyword}) like ${`%${escapeLike(trimmed.toLocaleLowerCase())}%`} escape '\\'`);
	}
	for (const term of params.excludeTerms ?? []) {
		const trimmed = term.trim();
		if (!trimmed) continue;
		clauses.push(sql`lower(${savedKeywords.keyword}) not like ${`%${escapeLike(trimmed.toLocaleLowerCase())}%`} escape '\\'`);
	}
	if (params.minVolume != null) clauses.push(gte(keywordMetrics.searchVolume, params.minVolume));
	if (params.maxVolume != null) clauses.push(lte(keywordMetrics.searchVolume, params.maxVolume));
	if (params.minCpc != null) clauses.push(gte(keywordMetrics.cpc, params.minCpc));
	if (params.maxCpc != null) clauses.push(lte(keywordMetrics.cpc, params.maxCpc));
	if (params.minDifficulty != null) clauses.push(gte(keywordMetrics.keywordDifficulty, params.minDifficulty));
	if (params.maxDifficulty != null) clauses.push(lte(keywordMetrics.keywordDifficulty, params.maxDifficulty));
	if (params.tagIds && params.tagIds.length > 0) clauses.push(sql`exists (
        select 1
        from ${savedKeywordTagAssignments}
        where ${savedKeywordTagAssignments.savedKeywordId} = ${savedKeywords.id}
        and ${inArray(savedKeywordTagAssignments.tagId, params.tagIds)}
      )`);
	return and(...clauses);
}
function buildSavedKeywordOrderBy(sort = "createdAt", order = "desc") {
	const direction = order === "asc" ? asc : desc;
	switch (sort) {
		case "keyword": return direction(savedKeywords.keyword);
		case "searchVolume": return direction(keywordMetrics.searchVolume);
		case "cpc": return direction(keywordMetrics.cpc);
		case "competition": return direction(keywordMetrics.competition);
		case "keywordDifficulty": return direction(keywordMetrics.keywordDifficulty);
		case "fetchedAt": return direction(keywordMetrics.fetchedAt);
		default: return direction(savedKeywords.createdAt);
	}
}
async function listSavedKeywordsByProject(params) {
	const [{ tagIds, emptyTagNameMatch }, tags] = await Promise.all([SavedKeywordTagsRepository.getTagFilterIds(params), SavedKeywordTagsRepository.listSavedKeywordTagsByProject(params.projectId)]);
	if (emptyTagNameMatch) return {
		rows: [],
		totalCount: 0,
		tags
	};
	const where = buildSavedKeywordWhere({
		projectId: params.projectId,
		search: params.search,
		includeTerms: params.includeTerms,
		excludeTerms: params.excludeTerms,
		minVolume: params.minVolume,
		maxVolume: params.maxVolume,
		minCpc: params.minCpc,
		maxCpc: params.maxCpc,
		minDifficulty: params.minDifficulty,
		maxDifficulty: params.maxDifficulty,
		tagIds
	});
	const metricJoin = and(eq(keywordMetrics.keyword, savedKeywords.keyword), eq(keywordMetrics.projectId, savedKeywords.projectId), eq(keywordMetrics.locationCode, savedKeywords.locationCode), eq(keywordMetrics.languageCode, savedKeywords.languageCode));
	const [{ value: totalCount } = { value: 0 }] = await db.select({ value: count() }).from(savedKeywords).leftJoin(keywordMetrics, metricJoin).where(where);
	const baseQuery = db.select({
		row: savedKeywords,
		metric: keywordMetrics
	}).from(savedKeywords).leftJoin(keywordMetrics, metricJoin).where(where).orderBy(buildSavedKeywordOrderBy(params.sort, params.order), asc(savedKeywords.id));
	const rows = params.pageSize == null ? await baseQuery : await baseQuery.limit(params.pageSize).offset(((params.page ?? 1) - 1) * params.pageSize);
	const tagsByKeywordId = await SavedKeywordTagsRepository.listTagsBySavedKeywordIds(params.projectId, rows.map(({ row }) => row.id));
	return {
		totalCount,
		tags,
		rows: rows.map(({ row, metric }) => ({
			row,
			metric,
			tags: tagsByKeywordId.get(row.id) ?? []
		}))
	};
}
async function countSavedKeywordsForOrganization(organizationId) {
	const [row] = await db.select({ value: count() }).from(savedKeywords).innerJoin(projects, eq(projects.id, savedKeywords.projectId)).where(eq(projects.organizationId, organizationId));
	return row?.value ?? 0;
}
async function listSavedKeywordRowsByKeywords(params) {
	const rows = [];
	for (let i = 0; i < params.keywords.length; i += QUERY_CHUNK_SIZE) {
		const chunk = params.keywords.slice(i, i + QUERY_CHUNK_SIZE);
		rows.push(...await db.select().from(savedKeywords).where(and(eq(savedKeywords.projectId, params.projectId), eq(savedKeywords.locationCode, params.locationCode), eq(savedKeywords.languageCode, params.languageCode), inArray(savedKeywords.keyword, chunk))));
	}
	return rows;
}
var QUERY_CHUNK_SIZE = 80;
var DELETE_CHUNK_SIZE = 90;
async function removeSavedKeywords$1(savedKeywordIds, projectId) {
	let deletedCount = 0;
	for (let i = 0; i < savedKeywordIds.length; i += DELETE_CHUNK_SIZE) {
		const chunk = savedKeywordIds.slice(i, i + DELETE_CHUNK_SIZE);
		const deleted = await db.delete(savedKeywords).where(and(inArray(savedKeywords.id, chunk), eq(savedKeywords.projectId, projectId))).returning({ id: savedKeywords.id });
		deletedCount += deleted.length;
	}
	return deletedCount;
}
var KeywordResearchRepository = {
	upsertKeywordMetric,
	countSavedKeywords,
	saveKeywordsToProject,
	countSavedKeywordsForOrganization,
	listSavedKeywordRowsByKeywords,
	listSavedKeywordsByProject,
	addTagsToSavedKeywords: SavedKeywordTagsRepository.addTagsToSavedKeywords,
	replaceTagsForSavedKeywords: SavedKeywordTagsRepository.replaceTagsForSavedKeywords,
	removeTagsFromSavedKeywords: SavedKeywordTagsRepository.removeTagsFromSavedKeywords,
	removeAllTagsFromSavedKeywords: SavedKeywordTagsRepository.removeAllTagsFromSavedKeywords,
	updateSavedKeywordTag: SavedKeywordTagsRepository.updateSavedKeywordTag,
	deleteSavedKeywordTag: SavedKeywordTagsRepository.deleteSavedKeywordTag,
	removeSavedKeywords: removeSavedKeywords$1
};
//#endregion
//#region src/server/features/keywords/services/research/selection.ts
function countNonSeedKeywords(rows, seedKeyword) {
	const normalizedSeed = seedKeyword.trim().toLowerCase();
	return rows.filter((row) => row.keyword !== normalizedSeed).length;
}
//#endregion
//#region src/server/features/keywords/services/research/research.ts
var cachedKeywordRowSchema = object({
	keyword: string(),
	searchVolume: number().nullable(),
	trend: array(object({
		year: number(),
		month: number(),
		searchVolume: number()
	})),
	cpc: number().nullable(),
	competition: number().nullable(),
	keywordDifficulty: number().nullable(),
	intent: _enum([
		"informational",
		"commercial",
		"transactional",
		"navigational",
		"unknown"
	])
});
var cachedResultSchema = object({
	rows: array(cachedKeywordRowSchema),
	source: _enum([
		"related",
		"suggestions",
		"ideas",
		"google_ads",
		"blended"
	]),
	usedFallback: boolean()
});
var CACHE_VERSION = 5;
async function fetchRowsFromSource(source, input, seedKeyword, billingCustomer, opts = {}) {
	return fetchResearchRowsBySource({
		source,
		seedKeyword,
		locationCode: input.locationCode,
		languageCode: input.languageCode,
		resultLimit: opts.resultLimit ?? input.resultLimit,
		includeClickstreamData: input.clickstream,
		ignoreSynonyms: !input.groupKeywords,
		filters: opts.filters,
		creditFeature: opts.creditFeature
	}, billingCustomer);
}
/**
* Auto blends phrase-match suggestions with category-level ideas, half the
* limit each. Neither works as a sole default: suggestions miss sibling head
* terms ("respite care" for "caregiving") and ideas drift toward generic
* category terms. The old related-first behavior is worse than both \u2014 its
* depth-3 "people also search for" graph is tiny for broad seeds and full of
* SERP-adjacency noise \u2014 so related is only a fallback for obscure seeds
* where the blend comes back thin.
*/
async function fetchAutoRows(input, seedKeyword, billingCustomer, creditFeature) {
	const blendOpts = {
		creditFeature,
		resultLimit: Math.ceil(input.resultLimit / 2)
	};
	const [suggestions, ideas] = await Promise.allSettled([fetchRowsFromSource("suggestions", input, seedKeyword, billingCustomer, blendOpts), fetchRowsFromSource("ideas", input, seedKeyword, billingCustomer, blendOpts)]);
	if (suggestions.status === "rejected") {
		if (ideas.status === "rejected") console.warn("keywords.research.ideas-leg failed:", ideas.reason);
		throw suggestions.reason;
	}
	if (ideas.status === "rejected") throw ideas.reason;
	const blended = interleaveRows(suggestions.value, ideas.value, input.resultLimit);
	if (countNonSeedKeywords(blended, seedKeyword) >= 5) return {
		rows: blended,
		source: "blended",
		usedFallback: false
	};
	return {
		rows: interleaveRows(blended, await fetchRowsFromSource("related", input, seedKeyword, billingCustomer, { creditFeature }), input.resultLimit),
		source: "blended",
		usedFallback: true
	};
}
/**
* "best * for dogs": suggestions (keywords containing a phrase) for the
* anchor "for dogs", filtered by DataForSEO before it applies the limit, so
* every row matches. A bare `%` at either end would let "seo" match "seoul",
* so the pattern is pinned to word boundaries with four `like` conditions.
*/
async function fetchWildcardRows(input, seedKeyword, billingCustomer, creditFeature) {
	const pattern = seedKeyword.replace(/\s+/g, " ").replace(/\*+/g, "*").split("*").map(escapeLikeTerm).join("%");
	const filters = joinClauses([
		pattern,
		`${pattern} %`,
		`% ${pattern}`,
		`% ${pattern} %`
	].map((value) => [
		"keyword",
		"like",
		value
	]), "or");
	return {
		rows: await fetchRowsFromSource("suggestions", input, wildcardAnchor(seedKeyword), billingCustomer, {
			creditFeature,
			filters
		}),
		source: "suggestions",
		usedFallback: false
	};
}
async function fetchGoogleAdsRows(input, seedKeyword, billingCustomer, creditFeature) {
	return {
		rows: await fetchGoogleAdsResearchRows({
			seedKeyword,
			locationCode: input.locationCode,
			languageCode: input.languageCode,
			resultLimit: input.resultLimit,
			creditFeature
		}, billingCustomer),
		source: "google_ads",
		usedFallback: false
	};
}
async function fetchManualRows(mode, input, seedKeyword, billingCustomer, creditFeature) {
	return {
		rows: await fetchRowsFromSource(mode, input, seedKeyword, billingCustomer, { creditFeature }),
		source: mode,
		usedFallback: false
	};
}
async function buildResearchCacheKey(input, normalizedKeywords, mode, billingCustomer) {
	return buildCacheKey("kw:research", {
		cacheVersion: CACHE_VERSION,
		organizationId: billingCustomer.organizationId,
		projectId: input.projectId,
		keywords: normalizedKeywords,
		locationCode: input.locationCode,
		languageCode: input.languageCode,
		resultLimit: input.resultLimit,
		mode,
		depth: 3,
		clickstream: input.clickstream,
		groupKeywords: input.groupKeywords,
		locationName: input.locationName
	});
}
function persistRows(input, rows) {
	return Promise.all(rows.map((row) => KeywordResearchRepository.upsertKeywordMetric({
		projectId: input.projectId,
		keyword: row.keyword,
		locationCode: input.locationCode,
		languageCode: input.languageCode,
		searchVolume: row.searchVolume,
		cpc: row.cpc,
		competition: row.competition,
		keywordDifficulty: row.keywordDifficulty,
		intent: row.intent,
		monthlySearchesJson: JSON.stringify(row.trend)
	}))).then(() => void 0, (error) => {
		console.error("keywords.research.persist-metrics failed:", error);
	});
}
async function research(input, billingCustomer, creditFeature) {
	const uniqueKeywords = [...new Set(input.keywords.map(normalizeKeyword))].filter((keyword) => keyword.length > 0);
	if (uniqueKeywords.length === 0) throw new AppError("VALIDATION_ERROR");
	const seedKeyword = uniqueKeywords[0];
	const wildcardError = keywordWildcardError(seedKeyword, input.locationCode);
	if (wildcardError) throw new AppError("VALIDATION_ERROR", wildcardError);
	const wildcard = hasKeywordWildcard(seedKeyword);
	const provider = getKeywordDataProvider(input.locationCode);
	const effectiveInput = provider === "google_ads" ? {
		...input,
		mode: "auto",
		clickstream: false,
		groupKeywords: false
	} : {
		...input,
		mode: wildcard ? "suggestions" : input.mode,
		clickstream: input.locationName ? false : input.clickstream
	};
	const mode = effectiveInput.mode ?? "auto";
	const cacheKey = await buildResearchCacheKey(effectiveInput, uniqueKeywords, mode, billingCustomer);
	const cachedRaw = await getCached(cacheKey);
	const cachedResult = cachedResultSchema.safeParse(cachedRaw);
	const cached = cachedResult.success ? cachedResult.data : null;
	if (cached && cached.rows.length > 0) return cached;
	const result = effectiveInput.locationName ? await researchLocal(effectiveInput, effectiveInput.locationName, billingCustomer, creditFeature) : wildcard ? await fetchWildcardRows(effectiveInput, seedKeyword, billingCustomer, creditFeature) : provider === "google_ads" ? await fetchGoogleAdsRows(effectiveInput, seedKeyword, billingCustomer, creditFeature) : mode === "auto" ? await fetchAutoRows(effectiveInput, seedKeyword, billingCustomer, creditFeature) : await fetchManualRows(mode, effectiveInput, seedKeyword, billingCustomer, creditFeature);
	await setCached(cacheKey, result, CACHE_TTL.researchResult);
	if (!effectiveInput.locationName) persistRows(effectiveInput, result.rows);
	return result;
}
/**
* Keyword ideas, difficulty, and intent come from the national research
* (cached and persisted as usual). One Google Ads call then replaces volume,
* CPC, and competition with numbers for the city, county, or region.
*/
async function researchLocal(input, locationName, billingCustomer, creditFeature) {
	await assertLocalResearchLocation(input.locationCode, locationName);
	const nationalInput = {
		...input,
		locationName: void 0
	};
	const national = await research(nationalInput, billingCustomer, creditFeature);
	await persistRows(nationalInput, national.rows);
	return {
		...national,
		rows: await localizeResearchRows(national.rows, {
			locationCode: input.locationCode,
			locationName,
			languageCode: input.languageCode,
			creditFeature
		}, billingCustomer)
	};
}
//#endregion
//#region src/server/features/keywords/services/research/serp.ts
var SERP_CACHE_TTL_SECONDS = 43200;
var serpResultItemSchema = object({
	rank: number().int(),
	title: string(),
	url: string(),
	domain: string(),
	description: string(),
	etv: number().nullable(),
	estimatedPaidTrafficCost: number().nullable(),
	referringDomains: number().nullable(),
	backlinks: number().nullable(),
	isNew: boolean(),
	rankChange: number().nullable()
});
var serpCacheSchema = object({
	requestedKeyword: string(),
	items: array(serpResultItemSchema),
	depth: number().int().default(10),
	reason: _enum(["no_organic_results"]).optional()
});
function mapOrganicSerpItems(items) {
	return items.filter((item) => item.type === "organic").map((item, index) => ({
		rank: index + 1,
		title: item.title ?? "",
		url: item.url ?? "",
		domain: item.domain ?? "",
		description: item.description ?? "",
		etv: item.etv ?? null,
		estimatedPaidTrafficCost: item.estimated_paid_traffic_cost ?? null,
		referringDomains: item.backlinks_info?.referring_domains ?? null,
		backlinks: item.backlinks_info?.backlinks ?? null,
		isNew: false,
		rankChange: null
	}));
}
async function getSerpLiveAnalysis(input, billingCustomer) {
	const keyword = normalizeKeyword(input.keyword);
	const { depth } = input;
	if (input.locationName) await assertLocalResearchLocation(input.locationCode, input.locationName);
	const cacheKey = await buildCacheKey("serp:analysis", {
		organizationId: billingCustomer.organizationId,
		projectId: input.projectId,
		keyword,
		locationCode: input.locationCode,
		languageCode: input.languageCode,
		locationName: input.locationName
	});
	const cachedRaw = await getCached(cacheKey);
	const cached = serpCacheSchema.safeParse(cachedRaw);
	if (cached.success && cached.data.depth >= depth) return cached.data;
	const [outcome] = await readMergedSerps(billingCustomer, [{
		query: {
			keyword,
			locationCode: input.locationCode,
			languageCode: input.languageCode,
			locationName: input.locationName,
			depth
		},
		receiptKey: await buildCacheKey("serp:analysis-reads", {
			organizationId: billingCustomer.organizationId,
			projectId: input.projectId,
			keyword,
			locationCode: input.locationCode,
			languageCode: input.languageCode,
			locationName: input.locationName,
			depth
		})
	}]);
	if (outcome.status === "failed") throw outcome.error;
	if (outcome.status === "processing") throw new AppError("UPSTREAM_UNAVAILABLE", "These search results are taking longer than usual.");
	const items = mapOrganicSerpItems(outcome.items);
	const result = {
		requestedKeyword: keyword,
		items,
		depth
	};
	if (items.length === 0) result.reason = "no_organic_results";
	if (items.length === 0 && cached.success && cached.data.items.length > 0) return result;
	waitUntil(setCached(cacheKey, result, SERP_CACHE_TTL_SECONDS).catch((error) => {
		console.error("keywords.serp.cache-write failed:", error);
	}));
	return result;
}
var getSerpAnalysis = getSerpLiveAnalysis;
//#endregion
//#region src/server/features/keywords/services/research/saved-keywords.ts
var monthlySearchSchema = object({
	year: number().int().positive(),
	month: number().int().min(1).max(12),
	searchVolume: number().int().nonnegative()
});
var monthlySearchesCodec = jsonCodec(array(monthlySearchSchema));
function parseMonthlySearches(payload) {
	if (!payload) return [];
	const result = monthlySearchesCodec.safeParse(payload);
	return result.success ? result.data : [];
}
var SAVED_KEYWORDS_MAX_PER_ORGANIZATION = 25e3;
var SAVE_RATE_LIMIT_PER_MINUTE = 3e3;
var KEYWORDS_PER_RATE_LIMIT_UNIT = 50;
async function assertCanSaveKeywords(input, keywords) {
	const rateLimit = env.SAVE_KEYWORDS_RATE_LIMIT;
	if (rateLimit) {
		const units = Math.ceil(keywords.length / KEYWORDS_PER_RATE_LIMIT_UNIT);
		if ((await Promise.all(Array.from({ length: units }, () => rateLimit.limit({ key: input.organizationId })))).some((outcome) => !outcome.success)) throw new AppError("RATE_LIMITED", `Saving keywords is limited to ${formatCount(SAVE_RATE_LIMIT_PER_MINUTE)} a minute per workspace. Nothing was saved from this request. Wait a minute, then save the rest in smaller batches.`);
	}
	if (!await isHostedServerAuthMode()) return;
	const total = await KeywordResearchRepository.countSavedKeywordsForOrganization(input.organizationId);
	if (total + keywords.length <= SAVED_KEYWORDS_MAX_PER_ORGANIZATION) return;
	const existing = await KeywordResearchRepository.listSavedKeywordRowsByKeywords({
		...input,
		keywords
	});
	if (total + (keywords.length - existing.length) <= SAVED_KEYWORDS_MAX_PER_ORGANIZATION) return;
	throw new AppError("VALIDATION_ERROR", `This workspace has ${formatCount(total)} saved keywords across its projects, and the limit is ${formatCount(SAVED_KEYWORDS_MAX_PER_ORGANIZATION)}. Nothing was saved. Remove saved keywords you no longer need, then try again.`);
}
async function saveKeywords(input) {
	const normalizedKeywords = [...new Set(input.keywords.map(normalizeKeyword).filter((kw) => kw.length > 0))];
	await assertCanSaveKeywords(input, normalizedKeywords);
	const metricByKeyword = new Map((input.metrics ?? []).map((metric) => {
		const keyword = normalizeKeyword(metric.keyword);
		if (!keyword || !normalizedKeywords.includes(keyword)) return null;
		return [keyword, metric];
	}).filter((entry) => entry != null));
	if (metricByKeyword.size > 0) await Promise.all(normalizedKeywords.map(async (keyword) => {
		const metric = metricByKeyword.get(keyword);
		if (!metric) return;
		await KeywordResearchRepository.upsertKeywordMetric({
			projectId: input.projectId,
			keyword,
			locationCode: input.locationCode,
			languageCode: input.languageCode,
			searchVolume: metric.searchVolume ?? null,
			cpc: metric.cpc ?? null,
			competition: metric.competition ?? null,
			keywordDifficulty: metric.keywordDifficulty ?? null,
			intent: metric.intent ?? null,
			monthlySearchesJson: JSON.stringify(metric.monthlySearches ?? [])
		});
	}));
	const savedKeywordIds = (await KeywordResearchRepository.saveKeywordsToProject({
		projectId: input.projectId,
		keywords: normalizedKeywords,
		locationCode: input.locationCode,
		languageCode: input.languageCode
	})).map((row) => row.id);
	if (input.tagMode === "replace") {
		const replacementTags = input.tags ?? [];
		if (replacementTags.length === 0) throw new AppError("VALIDATION_ERROR", "Replacement tags are required when tagMode is replace.");
		await KeywordResearchRepository.replaceTagsForSavedKeywords({
			projectId: input.projectId,
			savedKeywordIds,
			tagNames: replacementTags
		});
	} else if ((input.tags?.length ?? 0) > 0) await KeywordResearchRepository.addTagsToSavedKeywords({
		projectId: input.projectId,
		savedKeywordIds,
		tagNames: input.tags ?? []
	});
	return {
		success: true,
		savedKeywordIds
	};
}
async function getSavedKeywords(input) {
	const result = await KeywordResearchRepository.listSavedKeywordsByProject({
		projectId: input.projectId,
		search: input.search,
		includeTerms: input.includeTerms,
		excludeTerms: input.excludeTerms,
		minVolume: input.minVolume,
		maxVolume: input.maxVolume,
		minCpc: input.minCpc,
		maxCpc: input.maxCpc,
		minDifficulty: input.minDifficulty,
		maxDifficulty: input.maxDifficulty,
		tagIds: input.tagIds,
		tagNames: input.tagNames,
		page: input.page,
		pageSize: input.pageSize,
		sort: input.sort,
		order: input.order
	});
	return {
		rows: mapSavedKeywordRows(result.rows),
		totalCount: result.totalCount,
		tags: mapSavedKeywordTags(result.tags)
	};
}
async function exportSavedKeywords(input) {
	return { rows: mapSavedKeywordRows((await KeywordResearchRepository.listSavedKeywordsByProject({
		projectId: input.projectId,
		search: input.search,
		includeTerms: input.includeTerms,
		excludeTerms: input.excludeTerms,
		minVolume: input.minVolume,
		maxVolume: input.maxVolume,
		minCpc: input.minCpc,
		maxCpc: input.maxCpc,
		minDifficulty: input.minDifficulty,
		maxDifficulty: input.maxDifficulty,
		tagIds: input.tagIds,
		tagNames: input.tagNames,
		sort: input.sort,
		order: input.order
	})).rows) };
}
async function updateSavedKeywordTags(input) {
	const addResult = (input.addTags?.length ?? 0) > 0 ? await KeywordResearchRepository.addTagsToSavedKeywords({
		projectId: input.projectId,
		savedKeywordIds: input.savedKeywordIds,
		tagNames: input.addTags ?? []
	}) : {
		savedKeywordCount: 0,
		tags: []
	};
	const removeResult = (input.removeTagIds?.length ?? 0) > 0 ? await KeywordResearchRepository.removeTagsFromSavedKeywords({
		projectId: input.projectId,
		savedKeywordIds: input.savedKeywordIds,
		tagIds: input.removeTagIds ?? []
	}) : {
		removedCount: 0,
		savedKeywordCount: 0,
		tags: []
	};
	return {
		success: true,
		taggedCount: Math.max(addResult.savedKeywordCount, removeResult.savedKeywordCount),
		addedTags: addResult.tags.map((tag) => ({
			id: tag.id,
			name: tag.name,
			normalizedName: tag.normalizedName,
			color: tag.color ?? null
		})),
		removedTagIds: removeResult.tags.map((tag) => tag.id),
		removedAssignments: removeResult.removedCount
	};
}
function mapSavedKeywordRows(rows) {
	return rows.map(({ row, metric, tags }) => ({
		id: row.id,
		projectId: row.projectId,
		keyword: row.keyword,
		locationCode: row.locationCode,
		languageCode: row.languageCode,
		createdAt: row.createdAt,
		searchVolume: metric?.searchVolume ?? null,
		cpc: metric?.cpc ?? null,
		competition: metric?.competition ?? null,
		keywordDifficulty: metric?.keywordDifficulty ?? null,
		intent: metric?.intent ?? null,
		monthlySearches: parseMonthlySearches(metric?.monthlySearches ?? null),
		fetchedAt: metric?.fetchedAt ?? null,
		tags: tags.map((tag) => ({
			id: tag.id,
			name: tag.name,
			normalizedName: tag.normalizedName,
			color: tag.color ?? null
		}))
	}));
}
function mapSavedKeywordTags(tags) {
	return tags.map((tag) => ({
		id: tag.id,
		name: tag.name,
		normalizedName: tag.normalizedName,
		color: tag.color ?? null,
		keywordCount: tag.keywordCount
	}));
}
async function updateSavedKeywordTag(input) {
	const updated = await KeywordResearchRepository.updateSavedKeywordTag({
		projectId: input.projectId,
		tagId: input.tagId,
		name: input.name,
		color: input.color
	});
	if (!updated) return { success: false };
	return {
		success: true,
		tag: {
			id: updated.id,
			name: updated.name,
			normalizedName: updated.normalizedName,
			color: updated.color ?? null
		}
	};
}
async function deleteSavedKeywordTag(input) {
	const result = await KeywordResearchRepository.deleteSavedKeywordTag({
		projectId: input.projectId,
		tagId: input.tagId
	});
	if (result.status === "in_use") throw new TagInUseError(result.assignmentCount);
	return { success: result.status === "deleted" };
}
var TagInUseError = class extends Error {
	assignmentCount;
	code = "TAG_IN_USE";
	constructor(assignmentCount) {
		super(`Tag is attached to ${assignmentCount} keyword${assignmentCount === 1 ? "" : "s"}. Remove the tag from those keywords first.`);
		this.assignmentCount = assignmentCount;
		this.name = "TagInUseError";
	}
};
async function removeSavedKeywords(projectId, input) {
	return {
		success: true,
		deletedCount: await KeywordResearchRepository.removeSavedKeywords(input.savedKeywordIds, projectId)
	};
}
//#endregion
//#region src/server/features/keywords/services/research/refresh-metrics.ts
var REFRESH_UPSERT_BATCH_SIZE = 100;
async function refreshSavedKeywordMetrics(input, billingCustomer) {
	const { rows: allRows } = await KeywordResearchRepository.listSavedKeywordsByProject({ projectId: input.projectId });
	const onlyIds = input.savedKeywordIds && new Set(input.savedKeywordIds);
	const rows = onlyIds ? allRows.filter((r) => onlyIds.has(r.row.id)) : allRows;
	if (rows.length === 0) return { updated: 0 };
	const client = createDataforseoClient(billingCustomer);
	let updated = 0;
	const groups = /* @__PURE__ */ new Map();
	for (const row of rows) {
		const key = `${row.row.locationCode}:${row.row.languageCode}`;
		const group = groups.get(key) ?? [];
		group.push(row);
		groups.set(key, group);
	}
	for (const groupRows of groups.values()) {
		const { locationCode, languageCode } = groupRows[0].row;
		const metrics = await fetchKeywordMetricsForList(client, {
			keywords: groupRows.map((r) => r.row.keyword),
			locationCode,
			languageCode,
			creditFeature: "keyword_research"
		});
		const byKeyword = new Map(metrics.map((metric) => [metric.keyword.toLowerCase(), metric]));
		for (let i = 0; i < groupRows.length; i += REFRESH_UPSERT_BATCH_SIZE) {
			const chunk = groupRows.slice(i, i + REFRESH_UPSERT_BATCH_SIZE);
			await Promise.all(chunk.map((r) => {
				const metric = byKeyword.get(r.row.keyword.toLowerCase());
				if (!metric) return Promise.resolve();
				return KeywordResearchRepository.upsertKeywordMetric({
					projectId: input.projectId,
					keyword: r.row.keyword,
					locationCode,
					languageCode,
					searchVolume: metric.searchVolume,
					cpc: metric.cpc,
					competition: metric.competition,
					keywordDifficulty: metric.keywordDifficulty,
					intent: normalizeIntent(metric.intent),
					monthlySearchesJson: JSON.stringify(metric.monthlySearches)
				});
			}));
		}
		updated += byKeyword.size;
	}
	return { updated };
}
//#endregion
//#region src/server/features/keywords/services/KeywordResearchService.ts
var KeywordResearchService = {
	research,
	getSerpAnalysis,
	saveKeywords,
	getSavedKeywords,
	exportSavedKeywords,
	updateSavedKeywordTags,
	updateSavedKeywordTag,
	deleteSavedKeywordTag,
	removeSavedKeywords,
	refreshSavedKeywordMetrics
};
//#endregion
//#region src/server/features/keywords/services/KeywordSuggestionService.ts
var MAX_SUGGESTIONS = 10;
var MAX_SEED_WORDS = 3;
var SEARCH_CONSOLE_BANDS = [{
	reason: KeywordSuggestionReason.CloseToTopThree,
	first: 4,
	last: 6
}, {
	reason: KeywordSuggestionReason.CloseToPageOne,
	first: 11,
	last: 20
}];
var MAX_PER_SEARCH_CONSOLE_BAND = 3;
var QUERY_PAGE_ROW_LIMIT = 1e3;
function isSeedPhrase(keyword) {
	return keyword.trim().split(/\s+/).length <= MAX_SEED_WORDS;
}
/** Short searches the site ranks for just below the top 3 or on page 2, or
*  null without a working Search Console connection. */
async function listSearchConsoleSuggestions(projectId) {
	try {
		const { rows } = await GscService.getPerformance({
			projectId,
			...resolveDateRange({ dateRange: "last_28_days" }),
			type: "web",
			dimensions: ["query", "page"],
			rowLimit: QUERY_PAGE_ROW_LIMIT
		});
		const searches = t(bestPagePerQuery(rows).filter((row) => isSeedPhrase(row.query)), [(row) => row.impressions, "desc"]);
		return SEARCH_CONSOLE_BANDS.flatMap(({ reason, first, last }) => searches.filter((row) => {
			const rank = Math.round(row.position);
			return rank >= first && rank <= last;
		}).slice(0, MAX_PER_SEARCH_CONSOLE_BAND).map((row) => ({
			keyword: row.query,
			reason
		})));
	} catch (error) {
		if (error instanceof GscNotConnectedError || isExpectedGrantFailure(error)) return null;
		throw error;
	}
}
async function getSuggestions(project) {
	const [searchConsoleSuggestions, topics] = await Promise.all([listSearchConsoleSuggestions(project.id), AiVisibilityRepository.listResearchKeywords(project.id)]);
	const suggested = /* @__PURE__ */ new Set();
	return {
		suggestions: [...searchConsoleSuggestions ?? [], ...topics.filter(isSeedPhrase).map((keyword) => ({
			keyword,
			reason: KeywordSuggestionReason.FromYourSite
		}))].map((suggestion) => ({
			...suggestion,
			keyword: normalizeKeyword(suggestion.keyword)
		})).filter(({ keyword }) => {
			if (suggested.has(keyword)) return false;
			suggested.add(keyword);
			return true;
		}).slice(0, MAX_SUGGESTIONS),
		canGenerate: Boolean(project.domain) && topics.length === 0,
		searchConsoleConnected: searchConsoleSuggestions !== null
	};
}
/**
* Saves topics for a project that has none, from the same website research
* AI visibility setup runs, without competitors. They go in the same Prompt
* Research keywords, so setup later reuses them. Nothing here touches AI
* visibility setup or creates a tracker, so nothing recurring is billed.
*/
async function generate(project, customer) {
	if (!project.domain) throw new AppError("VALIDATION_ERROR", "Add your website in project settings to get suggestions.");
	if ((await AiVisibilityRepository.listResearchKeywords(project.id)).length) return;
	if (await isHostedServerAuthMode() && (await checkUsageCreditsDepleted(customer)).depleted) throw new AppError("INSUFFICIENT_CREDITS", "You need usage credits to generate suggestions.");
	const work = researchWebsite(project.domain, project, {
		...customer,
		projectId: project.id
	}, { skipCompetitors: true }).then((research) => runBatch((tx) => writeResearchKeywords(tx, project.id, [...research.suggestedTopics.map((topic) => topic.name), ...research.suggestedKeywords])));
	waitUntil(work.catch(() => void 0));
	await work;
}
var KeywordSuggestionService = {
	getSuggestions,
	generate
};
//#endregion
export { assertLocalResearchLocation as i, KeywordResearchService as n, readMergedSerps as r, KeywordSuggestionService as t };
