import { B as GoogleAccountService } from "./resolve-DrNDcpX6.js";
//#region src/server/features/google/googleDataRetention.ts
var UNUSED_GRANT_GRACE_MS = 864e5;
var PURGE_TIME_BUDGET_MS = 48e4;
/**
* Daily cron body: drops Google grants no project uses any more, as the
* privacy policy promises. Cached Google reports expire on their own: the
* bucket's `dataforseo-cache/` lifecycle rule deletes them after 7 days.
*/
async function purgeUnusedGoogleData(now = /* @__PURE__ */ new Date()) {
	return { googleGrants: await GoogleAccountService.purgeUnusedGrants(/* @__PURE__ */ new Date(now.getTime() - UNUSED_GRANT_GRACE_MS), now.getTime() + PURGE_TIME_BUDGET_MS) };
}
//#endregion
export { purgeUnusedGoogleData };
