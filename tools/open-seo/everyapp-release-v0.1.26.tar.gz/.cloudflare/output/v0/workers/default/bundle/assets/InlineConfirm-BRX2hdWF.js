import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as Trash2 } from "./trash-2-B7Pu83CI.js";
//#region src/client/components/InlineConfirm.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
/**
* Two-step delete for a list row: the trash icon swaps to an explicit
* Remove/Cancel pair, so a stray click can't destroy anything and no dialog
* is needed. With `triggerLabel`, the trash icon becomes a text button.
*/
function InlineConfirm({ label, triggerLabel, confirmLabel = "Remove", pending, disabled = false, onConfirm }) {
	const [confirming, setConfirming] = (0, import_react.useState)(false);
	const size = triggerLabel ? "sm" : "xs";
	if (confirming) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "destructive",
		size,
		disabled: pending || disabled,
		onClick: () => {
			setConfirming(false);
			onConfirm();
		},
		children: confirmLabel
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "ghost",
		size,
		onClick: () => setConfirming(false),
		children: "Cancel"
	})] });
	if (triggerLabel) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "destructive",
		size,
		disabled: pending || disabled,
		onClick: () => setConfirming(true),
		children: triggerLabel
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "ghost",
		size: "icon-xs",
		className: "text-destructive hover:text-destructive",
		"aria-label": label,
		disabled: pending || disabled,
		onClick: () => setConfirming(true),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" })
	});
}
//#endregion
export { InlineConfirm as t };
