import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { t as projectsQueryOptions } from "./projectQueries-CUURHKzv.js";
//#region src/client/features/projects/useProjectMarket.ts
/** The project's default market, or undefined until the projects query resolves. */
function useProjectMarket(projectId) {
	return useQuery(projectsQueryOptions()).data?.find((project) => project.id === projectId);
}
//#endregion
export { useProjectMarket as t };
