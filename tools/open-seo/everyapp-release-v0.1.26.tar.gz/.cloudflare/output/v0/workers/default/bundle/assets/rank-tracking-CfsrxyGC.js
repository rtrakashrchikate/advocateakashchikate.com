import { I as roundUsdForBilling, N as creditsForProviderUsd, k as applyBillingMarkupUsd } from "./onboarding-drip-B7bIbv_6.js";
//#region src/shared/rank-tracking.ts
/** DataForSEO task queue (standard priority): cost of first page (10 results) */
var QUEUED_BASE_PAGE_COST_USD = 6e-4;
/** DataForSEO task queue (standard priority): cost of each additional page (75% of base) */
var QUEUED_EXTRA_PAGE_COST_USD = 45e-5;
/** How long a check takes, shown before and during one. */
var RANK_CHECK_DURATION_COPY = "Usually takes about an hour, up to 2 hours.";
/** Soft application limit for keywords per rank tracking config */
var MAX_KEYWORDS_PER_CONFIG = 1e3;
var rankCheckCostApprovalError = (costCredits, maxCostCredits) => {
	return `The current rank check costs ${costCredits} credits, above the approved maximum of ${maxCostCredits}. Call estimate_rank_tracker_cost again and ask the user to approve the updated amount.`;
};
/** DataForSEO cost for a single standard-queue SERP read at the given depth. */
function costPerSerpAtDepth(depth) {
	return QUEUED_BASE_PAGE_COST_USD + (depth / 10 - 1) * QUEUED_EXTRA_PAGE_COST_USD;
}
function pagesToDepth(pages) {
	return pages * 10;
}
var SERP_OPERATOR_KEYWORD = /(allinanchor|allintext|allintitle|allinurl|cache|define|definition|filetype|id|inanchor|info|intext|intitle|inurl|link|site):/i;
function serpKeywordCostMultiplier(keyword) {
	return SERP_OPERATOR_KEYWORD.test(keyword) ? 5 : 1;
}
/**
* The most one rank check can cost: MAX_READS_PER_CHECK queued reads of every
* keyword/device pair.
*/
function estimateRankCheckCredits(keywords, devices, depth) {
	const read = meteredCost(keywords.flatMap((keyword) => Array(devicesCount(devices)).fill(serpKeywordCostMultiplier(keyword))), depth);
	return {
		costUsd: roundUsdForBilling(6 * read.costUsd),
		costCredits: 6 * read.costCredits
	};
}
function meteredCost(checkMultipliers, depth) {
	let costUsd = 0;
	let costCredits = 0;
	for (let offset = 0; offset < checkMultipliers.length; offset += 100) {
		const callRawUsd = checkMultipliers.slice(offset, offset + 100).reduce((sum, multiplier) => sum + multiplier, 0) * costPerSerpAtDepth(depth);
		costUsd += applyBillingMarkupUsd(callRawUsd);
		costCredits += creditsForProviderUsd(callRawUsd);
	}
	return {
		costUsd,
		costCredits
	};
}
function estimateScheduledRankCheckCredits(keywords, devices, depth, scheduleInterval) {
	const { costUsd, costCredits } = estimateRankCheckCredits(keywords, devices, depth);
	const checksPerMonth = scheduledChecksPerMonth(scheduleInterval);
	return {
		scheduleInterval,
		costUsd,
		costCredits,
		checksPerMonth,
		monthlyCostUsd: costUsd * checksPerMonth,
		monthlyCostCredits: costCredits * checksPerMonth
	};
}
/** Planning figure for monthly cost estimates, not a calendar count. */
function scheduledChecksPerMonth(scheduleInterval) {
	return scheduleInterval === "daily" ? 30 : scheduleInterval === "weekly" ? 4 : 1;
}
function isScheduledRankTrackingInterval(interval) {
	return interval !== "manual";
}
/**
* Monthly checks run on the last day of the month where the user is. That day
* can fall on a neighbouring UTC date, so the anchor sits `dayShift` days from
* the UTC month end: -1, 0, or +1.
*/
function monthEndWithTime(year, month, dayShift, time) {
	return new Date(Date.UTC(year, month + 1, dayShift, time.hour, time.minute));
}
/**
* Read the day shift back off a stored monthly anchor, so advancing it keeps
* the same relation to the month end without a column for it. Months have at
* least 28 days, so the 1st, the last day, and the day before never collide.
*/
function monthlyAnchorDayShift(anchor) {
	if (anchor.getUTCDate() === 1) return 1;
	const lastDay = new Date(Date.UTC(anchor.getUTCFullYear(), anchor.getUTCMonth() + 1, 0)).getUTCDate();
	return anchor.getUTCDate() === lastDay - 1 ? -1 : 0;
}
/**
* Shift a chosen time from its timezone to UTC, weekday included. Uses the
* zone's offset right now: the anchor is fixed in UTC afterwards anyway, so a
* pick made just before a clock change is an hour off from its first run on.
*/
function scheduleTimeInUtc(scheduleTime, now) {
	if (!scheduleTime.timeZone) return {
		...scheduleTime,
		dayShift: 0
	};
	const parts = new Intl.DateTimeFormat("en-US", {
		timeZone: scheduleTime.timeZone,
		hourCycle: "h23",
		year: "numeric",
		month: "numeric",
		day: "numeric",
		hour: "numeric",
		minute: "numeric"
	}).formatToParts(now);
	const part = (type) => Number(parts.find((p) => p.type === type)?.value);
	const offsetMinutes = (Date.UTC(part("year"), part("month") - 1, part("day"), part("hour"), part("minute")) - now + now % 6e4) / 6e4;
	const utcMinutes = scheduleTime.hour * 60 + scheduleTime.minute - offsetMinutes;
	const dayShift = Math.floor(utcMinutes / 1440);
	const minutesOfDay = utcMinutes - dayShift * 1440;
	return {
		weekday: scheduleTime.weekday === void 0 ? void 0 : (scheduleTime.weekday + dayShift + 7) % 7,
		hour: Math.floor(minutesOfDay / 60),
		minute: minutesOfDay % 60,
		dayShift
	};
}
/**
* Compute the next check time for a scheduled config.
*
* If `previousNextCheckAt` is provided, advances from that anchor by the
* interval until the result is in the future. This prevents schedule drift
* when runs are delayed (e.g., a weekly config due Monday that fires on
* Wednesday will still schedule the next check for the following Monday).
*
* Otherwise the first check lands on `chosenTime` when the user chose one, or
* on a random hour (04\u201309 UTC) and minute. The random default spreads load
* across the scheduler's ticks.
*/
function computeNextCheckAt(interval, previousNextCheckAt, chosenTime) {
	const now = Date.now();
	const scheduleTime = chosenTime && scheduleTimeInUtc(chosenTime, now);
	if (interval === "monthly") {
		if (previousNextCheckAt) {
			const anchor = new Date(previousNextCheckAt);
			const year = anchor.getUTCFullYear();
			const dayShift = monthlyAnchorDayShift(anchor);
			const time = {
				hour: anchor.getUTCHours(),
				minute: anchor.getUTCMinutes()
			};
			let month = anchor.getUTCMonth() + (dayShift === 1 ? 0 : 1);
			let nextDate = monthEndWithTime(year, month, dayShift, time);
			while (nextDate.getTime() <= now) {
				month += 1;
				nextDate = monthEndWithTime(year, month, dayShift, time);
			}
			return nextDate.toISOString();
		}
		const time = {
			hour: scheduleTime?.hour ?? 4 + Math.floor(Math.random() * 6),
			minute: scheduleTime?.minute ?? Math.floor(Math.random() * 60)
		};
		const dayShift = scheduleTime?.dayShift ?? 0;
		const today = new Date(now);
		const year = today.getUTCFullYear();
		let month = today.getUTCMonth() - 1;
		let nextDate = monthEndWithTime(year, month, dayShift, time);
		while (nextDate.getTime() <= now) {
			month += 1;
			nextDate = monthEndWithTime(year, month, dayShift, time);
		}
		return nextDate.toISOString();
	}
	const daysAhead = interval === "daily" ? 1 : 7;
	if (previousNextCheckAt) {
		const anchor = new Date(previousNextCheckAt).getTime();
		const intervalMs = daysAhead * 864e5;
		const steps = Math.floor(Math.max(0, now - anchor) / intervalMs) + 1;
		return new Date(anchor + steps * intervalMs).toISOString();
	}
	if (scheduleTime) {
		const nextDate = new Date(now);
		nextDate.setUTCHours(scheduleTime.hour, scheduleTime.minute, 0, 0);
		const weekday = interval === "weekly" ? scheduleTime.weekday : void 0;
		if (weekday !== void 0) {
			const daysUntilWeekday = (weekday - nextDate.getUTCDay() + 7) % 7;
			nextDate.setUTCDate(nextDate.getUTCDate() + daysUntilWeekday);
		}
		if (nextDate.getTime() <= now) nextDate.setUTCDate(nextDate.getUTCDate() + (weekday === void 0 ? 1 : 7));
		return nextDate.toISOString();
	}
	const nextDate = /* @__PURE__ */ new Date();
	nextDate.setUTCDate(nextDate.getUTCDate() + daysAhead);
	const hour = 4 + Math.floor(Math.random() * 6);
	const minute = Math.floor(Math.random() * 60);
	nextDate.setUTCHours(hour, minute, 0, 0);
	return nextDate.toISOString();
}
function devicesLabel(devices) {
	if (devices === "both") return "Desktop + Mobile";
	return devices === "desktop" ? "Desktop" : "Mobile";
}
function scheduleLabel(interval) {
	if (interval === "daily") return "Daily";
	if (interval === "weekly") return "Weekly";
	if (interval === "monthly") return "Monthly";
	return "Manual";
}
/** Older failed runs stored "AppError: Insufficient credits for rank check". */
function isOutOfCreditsRunError(errorMessage) {
	return /insufficient.credits/i.test(errorMessage ?? "");
}
function devicesCount(devices) {
	return devices === "both" ? 2 : 1;
}
//#endregion
export { devicesCount as a, estimateScheduledRankCheckCredits as c, pagesToDepth as d, rankCheckCostApprovalError as f, serpKeywordCostMultiplier as h, costPerSerpAtDepth as i, isOutOfCreditsRunError as l, scheduledChecksPerMonth as m, RANK_CHECK_DURATION_COPY as n, devicesLabel as o, scheduleLabel as p, computeNextCheckAt as r, estimateRankCheckCredits as s, MAX_KEYWORDS_PER_CONFIG as t, isScheduledRankTrackingInterval as u };
