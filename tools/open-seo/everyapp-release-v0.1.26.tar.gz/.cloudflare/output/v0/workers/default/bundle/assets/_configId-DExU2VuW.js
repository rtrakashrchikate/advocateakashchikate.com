import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { O as SUBSCRIBE_ROUTE } from "./onboarding-drip-B7bIbv_6.js";
import { t as t$1 } from "./purry-DMI_Uzu-.js";
import { s as t$2 } from "./r2-cache-DRcgqCM_.js";
import { t as t$3 } from "./reverse-B56BbfY4.js";
import { t as t$4 } from "./sort-CLx_CHCb.js";
import { a as devicesCount, l as isOutOfCreditsRunError, n as RANK_CHECK_DURATION_COPY, o as devicesLabel, p as scheduleLabel, u as isScheduledRankTrackingInterval } from "./rank-tracking-CfsrxyGC.js";
import { o as formatLocationLabel, r as LOCATIONS } from "./keyword-locations-4GfvBtRY.js";
import { t as googleSerpUrl } from "./google-serp-url-uC4XmGTB.js";
import { j as useQueryClient, t as useQuery, x as keepPreviousData } from "./useQuery-B93OR2NQ.js";
import { c as Skeleton, g as EmptyState, n as QueryState, r as SkeletonCard, t as QueryError, u as InsufficientCreditsError } from "./QueryState-Q8BZIblk.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { n as createLucideIcon } from "./dist-fVOGIv0D.js";
import { t as CalendarDays } from "./calendar-days-sCy4vHst.js";
import { t as Clock } from "./clock-Bs_cvs_u.js";
import { t as Copy } from "./copy-BCHMWRty.js";
import { t as Download } from "./download-B-49ilLV.js";
import { t as Ellipsis } from "./ellipsis-BmQZ40Fl.js";
import { t as ExternalLink } from "./external-link-HZIbqzY5.js";
import { t as FileDown } from "./file-down-B-r6h4bv.js";
import { n as Sheet, t as ExportMenu } from "./ExportMenu-j2MeLhMC.js";
import { V as clsx, r as Spinner, t as Button } from "./button-DrcZrdio.js";
import { t as Checkbox } from "./checkbox-CdxmE4wQ.js";
import { t as Monitor } from "./monitor-CSd9Rf9l.js";
import { t as Play } from "./play-xVUoeGNG.js";
import { t as Plus } from "./plus-C1Kukp-u.js";
import { i as RefreshCw, n as filterValuesToSearch, r as normalizeFilterValues, t as filterValuesFromSearch } from "./filterSearchParams-CGnyDHGe.js";
import { t as Settings } from "./settings-kAsZ1oNV.js";
import { t as SlidersHorizontal } from "./sliders-horizontal-DtJi2CKi.js";
import { t as Trash2 } from "./trash-2-B7Pu83CI.js";
import { t as TrendingUp } from "./trending-up-DYoGV4Y5.js";
import { t as TriangleAlert } from "./triangle-alert-C9SRPVjv.js";
import { r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { n as captureClientEvent } from "./posthog-BMFJOGWd.js";
import { t as Badge } from "./badge-B9fV075d.js";
import { t as Progress } from "./progress-DlqV_aCw.js";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-KTe7DEy8.js";
import { n as rankTrackingDetailSearchSchema, t as comparePeriodSchema } from "./rank-tracking-search-Btd98vnt.js";
import { t as Route } from "./_configId-DWh2-Bmm.js";
import { t as Label } from "./label-JSQAcpYi.js";
import { t as Textarea } from "./textarea-CsL-KvnQ.js";
import { a as TableHead, i as TableCell, n as TableBody, o as TableHeader, r as TableCard, s as TableRow, t as Table$1 } from "./table-CqwvrC02.js";
import { A as ZIndexLayer, D as CartesianLabelContextProvider, K as DefaultZIndexes, Kt as Layer, Mt as useAppSelector, Nt as resolveDefaultProps, O as CartesianLabelFromLabelProp, R as selectAxisScale, Vt as isNumOrStr, a as ChartTooltipContent, g as rectWithPoints, h as removeArea, i as ChartTooltip, jt as useAppDispatch, m as addArea, mt as useIsPanorama, p as useClipPathId, qt as svgPropertiesAndEvents, t as ChartContainer, tt as Rectangle } from "./chart-DyiPV1Ml.js";
import { n as ChartXAxis, r as ChartYAxis, t as ChartGrid } from "./ChartAxes-BMklxsO9.js";
import { n as Line, t as LineChart } from "./LineChart-3GknZd0x.js";
import { n as Area, t as AreaChart } from "./AreaChart-UWMC4fUK.js";
import { n as TooltipContent, r as TooltipTrigger, t as Tooltip } from "./tooltip-D5ss-ZNP.js";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C8cX1CPK.js";
import { t as ConfirmDialog } from "./ConfirmDialog-CI0zpKxJ.js";
import { i as DropdownMenuItem, l as DropdownMenuTrigger, n as DropdownMenuContent, t as DropdownMenu } from "./dropdown-menu-DubRfxrI.js";
import { r as useDataTable, t as DataTable } from "./DataTable-CF1_e923.js";
import { n as parseDbTimestamp, t as formatExportTimestamp } from "./db-timestamp-D5yyHS4V.js";
import { t as SegmentedToggle } from "./SegmentedToggle-TLo3swTI.js";
import { n as formatNextCheck } from "./ScheduleField-AOI31vZV.js";
import { n as TableBulkActionButton, r as TableBulkExportMenu, t as TableBulkActionBar } from "./TableBulkActionBar-D4kfSAB9.js";
import { t as useHostedPlanGate } from "./HostedPlanGate-DjbmgzY5.js";
import { r as buildCsv, t as exportRows } from "./exportRows-CUVUVoFx.js";
import { t as useDebouncedDraft } from "./useDebouncedDraft-Ixxzt3-2.js";
import { a as csvChange, i as DeviceRankCell, o as exportRankTracking, r as useRankTrackingColumns, t as PINNED_COLUMN_ID } from "./RankTrackingColumns-Dd9MWLUk.js";
import { a as getLatestRankRun, c as getRankPositionMatrix, f as refreshTrackingKeywordMetrics, h as triggerRankCheck, i as getLatestRankResults, m as setTrackingKeywordsPinned, o as getRankConfigTrend, p as removeTrackingKeywords, r as estimateRankCheckCost, s as getRankKeywordHistory, t as addTrackingKeywords, u as getRankTrackingConfigs } from "./rank-tracking-DwOdsORG.js";
import { c as countActiveFilters, i as EMPTY_FILTERS, o as applyFilters, r as FilterPanel, t as RankTrackingConfigModal, u as ScheduledChecksPausedAlert } from "./RankTrackingConfigModal-BCiTmDoJ.js";
//#region node_modules/.pnpm/remeda@2.33.6/node_modules/remeda/dist/clamp.js
function t(...t) {
	return t$1(n, t);
}
var n = (e, { min: t, max: n }) => t !== void 0 && e < t ? t : n !== void 0 && e > n ? n : e;
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var CircleSlash = createLucideIcon("circle-slash", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}], ["line", {
	x1: "9",
	x2: "15",
	y1: "15",
	y2: "9",
	key: "1dfufj"
}]]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Smartphone = createLucideIcon("smartphone", [["rect", {
	width: "14",
	height: "20",
	x: "5",
	y: "2",
	rx: "2",
	ry: "2",
	key: "1yt0o3"
}], ["path", {
	d: "M12 18h.01",
	key: "mhygvu"
}]]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Table = createLucideIcon("table", [
	["path", {
		d: "M12 3v18",
		key: "108xh3"
	}],
	["rect", {
		width: "18",
		height: "18",
		x: "3",
		y: "3",
		rx: "2",
		key: "afitv7"
	}],
	["path", {
		d: "M3 9h18",
		key: "1pudct"
	}],
	["path", {
		d: "M3 15h18",
		key: "5xshup"
	}]
]);
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/util/scale/CartesianScaleHelper.js
/**
* Groups X and Y scale functions together and provides helper methods.
*/
var CartesianScaleHelperImpl = class {
	constructor(_ref) {
		var { x, y } = _ref;
		this.xAxisScale = x;
		this.yAxisScale = y;
	}
	map(value, _ref2) {
		var _this$xAxisScale$map, _this$yAxisScale$map;
		var { position } = _ref2;
		return {
			x: (_this$xAxisScale$map = this.xAxisScale.map(value.x, { position })) !== null && _this$xAxisScale$map !== void 0 ? _this$xAxisScale$map : 0,
			y: (_this$yAxisScale$map = this.yAxisScale.map(value.y, { position })) !== null && _this$yAxisScale$map !== void 0 ? _this$yAxisScale$map : 0
		};
	}
	mapWithFallback(value, _ref3) {
		var _this$xAxisScale$map2, _this$yAxisScale$map2;
		var { position, fallback } = _ref3;
		var fallbackY, fallbackX;
		if (fallback === "rangeMin") fallbackY = this.yAxisScale.rangeMin();
		else if (fallback === "rangeMax") fallbackY = this.yAxisScale.rangeMax();
		else fallbackY = 0;
		if (fallback === "rangeMin") fallbackX = this.xAxisScale.rangeMin();
		else if (fallback === "rangeMax") fallbackX = this.xAxisScale.rangeMax();
		else fallbackX = 0;
		return {
			x: (_this$xAxisScale$map2 = this.xAxisScale.map(value.x, { position })) !== null && _this$xAxisScale$map2 !== void 0 ? _this$xAxisScale$map2 : fallbackX,
			y: (_this$yAxisScale$map2 = this.yAxisScale.map(value.y, { position })) !== null && _this$yAxisScale$map2 !== void 0 ? _this$yAxisScale$map2 : fallbackY
		};
	}
	isInRange(_ref4) {
		var { x, y } = _ref4;
		var xInRange = x == null || this.xAxisScale.isInRange(x);
		var yInRange = y == null || this.yAxisScale.isInRange(y);
		return xInRange && yInRange;
	}
};
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/cartesian/ReferenceArea.js
var import_react = /* @__PURE__ */ __toESM(require_react());
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty(e, r, t) {
	return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _extends() {
	return _extends = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends.apply(null, arguments);
}
var getRect = (hasX1, hasX2, hasY1, hasY2, xAxisScale, yAxisScale, props) => {
	var _xAxisScale$map, _yAxisScale$map, _xAxisScale$map2, _yAxisScale$map2;
	var { x1: xValue1, x2: xValue2, y1: yValue1, y2: yValue2 } = props;
	if (xAxisScale == null || yAxisScale == null) return null;
	var scales = new CartesianScaleHelperImpl({
		x: xAxisScale,
		y: yAxisScale
	});
	var p1 = {
		x: hasX1 ? (_xAxisScale$map = xAxisScale.map(xValue1, { position: "start" })) !== null && _xAxisScale$map !== void 0 ? _xAxisScale$map : null : xAxisScale.rangeMin(),
		y: hasY1 ? (_yAxisScale$map = yAxisScale.map(yValue1, { position: "start" })) !== null && _yAxisScale$map !== void 0 ? _yAxisScale$map : null : yAxisScale.rangeMin()
	};
	var p2 = {
		x: hasX2 ? (_xAxisScale$map2 = xAxisScale.map(xValue2, { position: "end" })) !== null && _xAxisScale$map2 !== void 0 ? _xAxisScale$map2 : null : xAxisScale.rangeMax(),
		y: hasY2 ? (_yAxisScale$map2 = yAxisScale.map(yValue2, { position: "end" })) !== null && _yAxisScale$map2 !== void 0 ? _yAxisScale$map2 : null : yAxisScale.rangeMax()
	};
	if (props.ifOverflow === "discard" && (!scales.isInRange(p1) || !scales.isInRange(p2))) return null;
	return rectWithPoints(p1, p2);
};
var renderRect = (option, props) => {
	var rect;
	if (/*#__PURE__*/ import_react.isValidElement(option)) rect = /*#__PURE__*/ import_react.cloneElement(option, props);
	else if (typeof option === "function") rect = option(props);
	else rect = /*#__PURE__*/ import_react.createElement(Rectangle, _extends({}, props, { className: "recharts-reference-area-rect" }));
	return rect;
};
function ReportReferenceArea(props) {
	var dispatch = useAppDispatch();
	(0, import_react.useEffect)(() => {
		dispatch(addArea(props));
		return () => {
			dispatch(removeArea(props));
		};
	});
	return null;
}
function ReferenceAreaImpl(props) {
	var { x1, x2, y1, y2, className, shape, xAxisId, yAxisId } = props;
	var clipPathId = useClipPathId();
	var isPanorama = useIsPanorama();
	var xAxisScale = useAppSelector((state) => selectAxisScale(state, "xAxis", xAxisId, isPanorama));
	var yAxisScale = useAppSelector((state) => selectAxisScale(state, "yAxis", yAxisId, isPanorama));
	if (xAxisScale == null || yAxisScale == null) return null;
	var hasX1 = isNumOrStr(x1);
	var hasX2 = isNumOrStr(x2);
	var hasY1 = isNumOrStr(y1);
	var hasY2 = isNumOrStr(y2);
	if (!hasX1 && !hasX2 && !hasY1 && !hasY2 && !shape) return null;
	var rect = getRect(hasX1, hasX2, hasY1, hasY2, xAxisScale, yAxisScale, props);
	if (!rect && !shape) return null;
	var clipPath = props.ifOverflow === "hidden" ? "url(#".concat(clipPathId, ")") : void 0;
	return /*#__PURE__*/ import_react.createElement(ZIndexLayer, { zIndex: props.zIndex }, /*#__PURE__*/ import_react.createElement(Layer, { className: clsx("recharts-reference-area", className) }, renderRect(shape, _objectSpread(_objectSpread({ clipPath }, svgPropertiesAndEvents(props)), rect)), rect != null && /*#__PURE__*/ import_react.createElement(CartesianLabelContextProvider, _extends({}, rect, {
		lowerWidth: rect.width,
		upperWidth: rect.width
	}), /*#__PURE__*/ import_react.createElement(CartesianLabelFromLabelProp, { label: props.label }), props.children)));
}
var referenceAreaDefaultProps = {
	ifOverflow: "discard",
	xAxisId: 0,
	yAxisId: 0,
	radius: 0,
	fill: "#ccc",
	label: false,
	fillOpacity: .5,
	stroke: "none",
	strokeWidth: 1,
	zIndex: DefaultZIndexes.area
};
/**
* Draws a rectangular area on the chart to highlight a specific range.
*
* This component, unlike {@link Rectangle} or {@link https://developer.mozilla.org/en-US/docs/Web/SVG/Reference/Element/rect rect}, is aware of the cartesian coordinate system,
* so you specify the area by using data coordinates instead of pixels.
*
* ReferenceArea will calculate the pixels based on the provided data coordinates.
*
* If you prefer to render rectangles using pixels rather than data coordinates,
* consider using the {@link Rectangle} component instead.
*
* @provides CartesianLabelContext
* @consumes CartesianChartContext
*/
function ReferenceArea(outsideProps) {
	var props = resolveDefaultProps(outsideProps, referenceAreaDefaultProps);
	return /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, /*#__PURE__*/ import_react.createElement(ReportReferenceArea, {
		yAxisId: props.yAxisId,
		xAxisId: props.xAxisId,
		ifOverflow: props.ifOverflow,
		x1: props.x1,
		x2: props.x2,
		y1: props.y1,
		y2: props.y2
	}), /*#__PURE__*/ import_react.createElement(ReferenceAreaImpl, props));
}
ReferenceArea.displayName = "ReferenceArea";
//#endregion
//#region src/client/features/rank-tracking/FreePlanAlert.tsx
var import_jsx_runtime = require_jsx_runtime();
function FreePlanAlert({ visible }) {
	if (!visible) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "warning",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, {
			className: "text-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"We only start to track keyword positions once you",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: SUBSCRIBE_ROUTE,
					search: { upgrade: true },
					className: "font-medium underline underline-offset-3",
					children: "upgrade to the paid plan"
				}),
				"."
			] })
		})]
	});
}
//#endregion
//#region src/client/features/rank-tracking/RankRunAlerts.tsx
function ReadWhatChangedLink() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: "https://openseo.so/blogs/state-of-rank-tracking-november-2026",
		target: "_blank",
		rel: "noopener noreferrer",
		className: "font-medium underline underline-offset-4",
		children: "Read what changed"
	});
}
/** The latest rank check's state: running, stale, failed, or incomplete. */
function RankRunAlerts({ run }) {
	if (!run) return null;
	if (run.maybeStale) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "warning",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, {
			className: "text-foreground",
			children: "This check stopped responding. You can start a new one to replace it."
		})]
	});
	if (run.status === "pending" || run.status === "running") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "info",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, {
			className: "text-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "This check takes about an hour"
				}),
				" ",
				"because Google's results have been unreliable lately. You can leave this page while it's running. ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadWhatChangedLink, {})
			] })
		})]
	});
	if (run.status === "failed" && isOutOfCreditsRunError(run.errorMessage)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsufficientCreditsError, { title: "Your last rank check didn't run" });
	if (run.status === "failed") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "warning",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, {
			className: "text-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "We couldn't finish your last check."
				}),
				" ",
				"Google's results have been unreliable for all rank trackers lately. Please try again later. ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadWhatChangedLink, {})
			] })
		})]
	});
	if (run.status === "completed" && run.errorMessage) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "warning",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, {
			className: "text-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium",
					children: "Some keywords couldn't be checked."
				}),
				" ",
				"Google's results have been unreliable for all rank trackers lately, so these show their last known position. ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReadWhatChangedLink, {})
			] })
		})]
	});
	return null;
}
//#endregion
//#region src/client/features/rank-tracking/RankTrackingDetailHeader.tsx
var COMPARE_ITEMS = [
	{
		value: "1d",
		label: "vs yesterday"
	},
	{
		value: "7d",
		label: "vs last week"
	},
	{
		value: "30d",
		label: "vs last month"
	},
	{
		value: "90d",
		label: "vs 90 days ago"
	}
];
function RankTrackingDetailHeader({ config, run, costEstimate, hasBothDevices, activeDevice, onActiveDeviceChange, comparePeriod, onComparePeriodChange, onEdit, onToggleAddKeywords }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col sm:flex-row sm:items-start justify-between gap-2 px-4 pt-4 pb-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-lg font-semibold",
			children: config.domain
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [
				config.locationName ? formatLocationLabel(config.locationName, 2) : LOCATIONS[config.locationCode] ?? "US",
				" ",
				"\u00B7",
				" ",
				config.devices === "desktop" ? devicesLabel(config.devices) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
					delay: 150,
					render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "cursor-help underline decoration-dotted underline-offset-2" }),
					children: devicesLabel(config.devices)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: "Mobile results often differ from desktop. Search Console averages both, so its positions may not match." })] }),
				" ",
				"\u00B7 ",
				scheduleLabel(config.scheduleInterval),
				config.scheduleInterval !== "manual" && config.nextCheckAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [" \u00B7 Next: ", formatNextCheck(config.nextCheckAt)] }),
				run?.lastCheckedAt && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					" ",
					"\u00B7 Last:",
					" ",
					parseDbTimestamp(run.lastCheckedAt).toLocaleDateString()
				] }),
				costEstimate && costEstimate.keywordCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					" \u00B7 up to $",
					costEstimate.costUsd.toFixed(2),
					"/check"
				] })
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				hasBothDevices && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegmentedToggle, {
					items: [{
						value: "desktop",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, { className: "size-3.5" }),
						label: "Desktop"
					}, {
						value: "mobile",
						icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Smartphone, { className: "size-3.5" }),
						label: "Mobile"
					}],
					value: activeDevice,
					onChange: onActiveDeviceChange
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					items: COMPARE_ITEMS,
					value: comparePeriod,
					onValueChange: (value) => {
						const parsed = comparePeriodSchema.safeParse(value);
						if (parsed.success) onComparePeriodChange(parsed.data);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						size: "sm",
						"aria-label": "Comparison period",
						title: "Comparison period",
						className: "text-xs",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: COMPARE_ITEMS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: item.value,
						children: item.label
					}, item.value)) })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden h-6 w-px bg-border sm:block" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: onEdit,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { "data-icon": "inline-start" }), "Configure"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: onToggleAddKeywords,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "data-icon": "inline-start" }), "Add Keywords"]
				})
			]
		})]
	});
}
//#endregion
//#region src/client/features/rank-tracking/RankTrackingTrendChart.tsx
/**
* Shared inverted-axis line chart for rank trends. Y-axis is reversed so #1 is
* pinned at the top and an improving line moves up. The very bottom of the
* plot (= serpDepth) is a muted "Not found" band; callers plot
* null positions at `serpDepth` so a drop reads as the line dipping into the
* band rather than a silent gap.
*/
function RankTrendChart({ data, series, serpDepth, valueFormatter, showBottomBand = false }) {
	const config = Object.fromEntries(series.map((s) => [s.dataKey, {
		label: s.name,
		color: s.color
	}]));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between text-[11px] text-muted-foreground",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Google position (1 = best)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-1",
				children: ["Better ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					"aria-hidden": true,
					children: "\u2191"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContainer, {
			config,
			className: "h-56",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
				data,
				margin: {
					top: 8,
					right: 8,
					bottom: 0,
					left: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartGrid, {}),
					showBottomBand && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceArea, {
						y1: serpDepth - .5,
						y2: serpDepth,
						fill: "currentColor",
						fillOpacity: .06,
						ifOverflow: "extendDomain"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartXAxis, { ...TIME_AXIS }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartYAxis, {
						reversed: true,
						domain: [1, serpDepth],
						allowDecimals: false,
						width: 32
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltipContent, {
						labelFormatter: formatDateLabel,
						valueFormatter
					}) }),
					series.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
						type: "monotone",
						dataKey: s.dataKey,
						stroke: `var(--color-${s.dataKey})`,
						strokeWidth: 2,
						strokeDasharray: s.strokeDasharray,
						dot: { r: 2 },
						activeDot: { r: 4 },
						connectNulls: false,
						isAnimationActive: false
					}, s.dataKey))
				]
			})
		})]
	});
}
/** X axis for charts keyed by a `checkedAt` timestamp in ms. */
var TIME_AXIS = {
	dataKey: "checkedAt",
	type: "number",
	scale: "time",
	domain: ["dataMin", "dataMax"],
	tickFormatter: formatDateTick
};
function formatDateTick(value) {
	return new Date(value).toLocaleDateString("en-US", {
		month: "short",
		day: "numeric"
	});
}
/** Tooltip label for a `checkedAt` timestamp: "Sep 28, 2026". */
function formatDateLabel(label) {
	return typeof label === "number" ? new Date(label).toLocaleDateString("en-US", {
		month: "short",
		day: "numeric",
		year: "numeric"
	}) : "";
}
/** 30d / 90d / All range toggle shared by the modal and overview charts. */
var TREND_RANGES = [
	{
		value: "30",
		icon: null,
		label: "30d"
	},
	{
		value: "90",
		icon: null,
		label: "90d"
	},
	{
		value: "730",
		icon: null,
		label: "All"
	}
];
function TrendRangeToggle({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegmentedToggle, {
		showLabels: true,
		items: TREND_RANGES,
		value: String(value),
		onChange: (next) => onChange(Number(next))
	});
}
/** Shown instead of a trend chart until there are two checks to connect. */
function TrendEmptyState({ checks }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: TrendingUp,
		size: "sm",
		title: checks === 0 ? "No history yet" : "Only 1 check so far",
		description: checks === 0 ? "Run a check to start tracking positions over time." : "The trend fills in after the next check."
	});
}
//#endregion
//#region src/client/features/rank-tracking/RankTrackingOverview.tsx
var BUCKETS = [
	{
		key: "top3",
		label: "Top 3",
		color: "#1e40af"
	},
	{
		key: "top4to10",
		label: "4\u201310",
		color: "#56b4e9"
	},
	{
		key: "top11to20",
		label: "11\u201320",
		color: "#e69f00"
	},
	{
		key: "notRanking",
		label: "Not in top 20",
		color: "#6b7280"
	},
	{
		key: "notChecked",
		label: "Not checked",
		color: "#d1d5db",
		hint: "No result from Google on this check."
	}
];
var chartConfig = Object.fromEntries(BUCKETS.map((b) => [b.key, {
	label: b.label,
	color: b.color
}]));
function RankTrackingOverview({ device, projectId, configId }) {
	const [sinceDays, setSinceDays] = (0, import_react.useState)(730);
	const trendQuery = useQuery({
		queryKey: [
			"rankConfigTrend",
			projectId,
			configId,
			device,
			sinceDays
		],
		queryFn: () => getRankConfigTrend({ data: {
			projectId,
			configId,
			device,
			sinceDays
		} })
	});
	const trend = trendQuery.data;
	const chartData = (0, import_react.useMemo)(() => (trend ?? []).map((p) => ({
		checkedAt: parseDbTimestamp(p.checkedAt).getTime(),
		top3: p.top3,
		top4to10: p.top4to10,
		top11to20: p.top11to20,
		notRanking: p.notRanking,
		notChecked: p.notChecked
	})), [trend]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 pt-4 pb-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-2 rounded-lg border border-border p-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm font-medium",
						children: "Position distribution"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendRangeToggle, {
						value: sinceDays,
						onChange: setSinceDays
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-x-3 gap-y-1",
					children: BUCKETS.map((b) => {
						const className = "inline-flex items-center gap-1 text-[11px] text-muted-foreground";
						const swatch = /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-2 rounded-sm",
							style: { backgroundColor: b.color }
						});
						return "hint" in b ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TooltipTrigger, {
							render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `${className} cursor-help` }),
							children: [swatch, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "underline decoration-dotted underline-offset-2",
								children: b.label
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: b.hint })] }, b.key) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className,
							children: [swatch, b.label]
						}, b.key);
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
					query: trendQuery,
					errorFallback: "Failed to load position history",
					loading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-[220px] w-full" }),
					children: () => chartData.length <= 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendEmptyState, { checks: chartData.length }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContainer, {
						config: chartConfig,
						className: "h-[220px]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
							data: chartData,
							margin: {
								top: 8,
								right: 8,
								bottom: 0,
								left: 0
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartGrid, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartXAxis, { ...TIME_AXIS }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartYAxis, {
									allowDecimals: false,
									width: 28
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltipContent, { labelFormatter: formatDateLabel }) }),
								BUCKETS.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
									type: "monotone",
									dataKey: b.key,
									stackId: "positions",
									stroke: `var(--color-${b.key})`,
									fill: `var(--color-${b.key})`,
									fillOpacity: .7,
									isAnimationActive: false
								}, b.key))
							]
						})
					})
				})
			]
		})
	});
}
//#endregion
//#region src/client/features/rank-tracking/useSetKeywordPinned.ts
/** Pins or unpins one keyword, and shows the change before the save ends. */
function useSetKeywordPinned(projectId, configId) {
	const queryClient = useQueryClient();
	const queryKey = [
		"rankTrackingResults",
		projectId,
		configId
	];
	const { mutate } = useMutation({
		mutationFn: (vars) => setTrackingKeywordsPinned({ data: {
			projectId,
			configId,
			keywordIds: [vars.trackingKeywordId],
			pinned: vars.pinned
		} }),
		onMutate: async ({ trackingKeywordId, pinned }) => {
			await queryClient.cancelQueries({ queryKey });
			queryClient.setQueriesData({ queryKey }, (old) => old ? {
				...old,
				rows: old.rows.map((row) => row.trackingKeywordId === trackingKeywordId ? {
					...row,
					pinned
				} : row)
			} : old);
		},
		onSettled: (_data, error) => {
			if (error) queryClient.invalidateQueries({ queryKey });
		}
	});
	return mutate;
}
//#endregion
//#region src/client/features/rank-tracking/KeywordTrendModal.tsx
var DEVICE_STYLE = {
	desktop: {
		label: "Desktop",
		color: "#2563eb"
	},
	mobile: {
		label: "Mobile",
		color: "#e69f00"
	}
};
function KeywordTrendModal({ target, projectId, configId, domain, locationCode, languageCode, locationName, serpDepth, onClose }) {
	const [sinceDays, setSinceDays] = (0, import_react.useState)(730);
	const historyQuery = useQuery({
		queryKey: [
			"rankKeywordHistory",
			projectId,
			configId,
			target.trackingKeywordId,
			sinceDays
		],
		queryFn: () => getRankKeywordHistory({ data: {
			projectId,
			configId,
			trackingKeywordId: target.trackingKeywordId,
			sinceDays
		} })
	});
	const history = historyQuery.data;
	const points = (0, import_react.useMemo)(() => history ?? [], [history]);
	const devices = (0, import_react.useMemo)(() => deriveDevices(points), [points]);
	const maxPerDevice = (0, import_react.useMemo)(() => devices.length === 0 ? 0 : Math.max(...devices.map((d) => points.filter((p) => p.device === d).length)), [points, devices]);
	const series = devices.map((device) => ({
		dataKey: device,
		name: DEVICE_STYLE[device].label,
		color: DEVICE_STYLE[device].color,
		strokeDasharray: "4 3"
	}));
	const chartData = (0, import_react.useMemo)(() => buildChartData(points, serpDepth), [points, serpDepth]);
	const bottomBandKeys = (0, import_react.useMemo)(() => {
		const keys = /* @__PURE__ */ new Set();
		for (const p of points) if (p.position === null) keys.add(`${parseDbTimestamp(p.checkedAt).getTime()}:${p.device}`);
		return keys;
	}, [points]);
	const historyRows = (0, import_react.useMemo)(() => buildHistoryRows(points), [points]);
	const handleCopy = () => {
		navigator.clipboard.writeText(buildCsv(HISTORY_HEADERS, historyRows.map(historyExportRow)));
		toast.success("Copied to clipboard");
		captureClientEvent("rank_tracking:keyword_trend_copy");
	};
	const handleExport = () => {
		exportRows({
			format: "csv",
			feature: "rank_tracking_keyword_trend",
			headers: HISTORY_HEADERS,
			rows: historyRows.map(historyExportRow),
			filename: `rank-history-${slugify(target.keyword)}`
		});
		captureClientEvent("rank_tracking:keyword_trend_export");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => {
			if (!open) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			showCloseButton: false,
			className: "sm:max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "flex-row items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: target.keyword }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, {
							className: "text-xs",
							children: [
								domain,
								" \u00B7",
								" ",
								locationName ? formatLocationLabel(locationName, 2) : LOCATIONS[locationCode] ?? "US",
								" ",
								"\u00B7 Position over time"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							nativeButton: false,
							title: "Search this keyword on Google with the tracked language, country, and city",
							render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: googleSerpUrl(target.keyword, {
									locationCode,
									languageCode,
									locationName
								}),
								target: "_blank",
								rel: "noopener noreferrer"
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { "data-icon": "inline-start" }), "Open on Google"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendRangeToggle, {
							value: sinceDays,
							onChange: setSinceDays
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
					query: historyQuery,
					errorFallback: "Failed to load keyword history",
					loading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-56 w-full" }),
					children: () => maxPerDevice <= 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendEmptyState, { checks: maxPerDevice }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrendChart, {
							data: chartData,
							series,
							serpDepth,
							showBottomBand: true,
							valueFormatter: (value, item) => {
								const row = item.payload;
								const checkedAt = typeof row === "object" && row !== null && "checkedAt" in row ? row.checkedAt : void 0;
								return typeof checkedAt === "number" && typeof item.dataKey === "string" && bottomBandKeys.has(`${checkedAt}:${item.dataKey}`) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-normal text-muted-foreground",
									children: "Not found"
								}) : String(value);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-end gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								size: "xs",
								onClick: handleCopy,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { "data-icon": "inline-start" }), "Copy"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "ghost",
								size: "xs",
								onClick: handleExport,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { "data-icon": "inline-start" }), "Export CSV"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-lg border border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table$1, {
								containerClassName: "max-h-64",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, {
									className: "sticky top-0 z-10 bg-popover",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Date" }),
										devices.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Device" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Position" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "\u0394 vs previous check" })
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: historyRows.map((r, idx) => {
									const noPrevious = r.position !== null && r.previousPosition === null;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-xs whitespace-nowrap",
											children: parseDbTimestamp(r.checkedAt).toLocaleDateString()
										}),
										devices.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
											className: "text-xs",
											children: DEVICE_STYLE[r.device].label
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: r.position === null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
											delay: 150,
											render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "cursor-help text-xs text-muted-foreground underline decoration-dotted underline-offset-2" }),
											children: "Not found"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: "Not ranking, or incomplete results" })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-mono text-sm",
											children: r.position
										}) }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: noPrevious ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "inline-flex items-center gap-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "w-6",
													"aria-hidden": true
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													"aria-hidden": true,
													className: "opacity-0",
													children: "\u2192"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "rounded bg-muted px-1.5 py-0.5 font-mono text-xs font-semibold text-muted-foreground",
													children: r.position
												})
											]
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceRankCell, { result: {
											position: r.position,
											previousPosition: r.previousPosition,
											rankingUrl: null,
											serpFeatures: [],
											checkedAt: r.checkedAt
										} }) })
									] }, `${r.device}-${r.checkedAt}-${idx}`);
								}) })]
							})
						})
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { showCloseButton: true })
			]
		})
	});
}
function deriveDevices(points) {
	const present = new Set(points.map((p) => p.device));
	return ["desktop", "mobile"].filter((d) => present.has(d));
}
/**
* Pivot flat rows into chart rows keyed by checkedAt (ms). A null position is
* plotted at `serpDepth` so it renders inside the muted bottom band and the
* line connects down to it (a drop), rather than leaving a silent gap.
*/
function buildChartData(points, serpDepth) {
	const byTime = /* @__PURE__ */ new Map();
	for (const p of points) {
		const ts = parseDbTimestamp(p.checkedAt).getTime();
		const row = byTime.get(ts) ?? { checkedAt: ts };
		row[p.device] = p.position === null ? serpDepth : p.position;
		byTime.set(ts, row);
	}
	return t$2([...byTime.values()], (row) => row.checkedAt);
}
/**
* One row per snapshot (newest first) with the previous-check position for the
* same device, so the \u0394 column can reuse DeviceRankCell's 4-case logic.
*/
function buildHistoryRows(points) {
	const prevByDevice = /* @__PURE__ */ new Map();
	const rows = [];
	for (const p of points) {
		const hadPrevious = prevByDevice.has(p.device);
		rows.push({
			device: p.device,
			checkedAt: p.checkedAt,
			position: p.position,
			previousPosition: hadPrevious ? prevByDevice.get(p.device) ?? null : null
		});
		prevByDevice.set(p.device, p.position);
	}
	return t$3(rows);
}
function slugify(value) {
	return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
var HISTORY_HEADERS = [
	"Date (UTC)",
	"Device",
	"Position",
	"Change vs previous"
];
function historyExportRow(row) {
	return [
		formatExportTimestamp(row.checkedAt),
		DEVICE_STYLE[row.device].label,
		row.position ?? "",
		csvChange(row.position, row.previousPosition)
	];
}
//#endregion
//#region src/client/features/rank-tracking/RankTrackingTable.tsx
function RankTrackingTable({ totalCount, rows, showDesktop, showMobile, sorting, onSortingChange, domain, configId, projectId, locationCode, languageCode, locationName, serpDepth, onAddKeywords, onClearFilters }) {
	const queryClient = useQueryClient();
	const [showConfirm, setShowConfirm] = (0, import_react.useState)(false);
	const [trendTarget, setTrendTarget] = (0, import_react.useState)(null);
	const selectAnchorRef = (0, import_react.useRef)(null);
	const handleKeywordClick = (0, import_react.useCallback)((row) => setTrendTarget({
		trackingKeywordId: row.trackingKeywordId,
		keyword: row.keyword
	}), []);
	const setKeywordPinned = useSetKeywordPinned(projectId, configId);
	const columns = useRankTrackingColumns({
		showDesktop,
		showMobile,
		domain,
		selectAnchorRef,
		onKeywordClick: handleKeywordClick,
		onSetPinned: setKeywordPinned,
		locationName
	});
	const tableSorting = (0, import_react.useMemo)(() => [{
		id: PINNED_COLUMN_ID,
		desc: false
	}, ...sorting], [sorting]);
	const table = useDataTable({
		data: rows,
		columns,
		state: {
			sorting: tableSorting,
			columnVisibility: { [PINNED_COLUMN_ID]: false }
		},
		onSortingChange: (updater) => onSortingChange((typeof updater === "function" ? updater(tableSorting) : updater).filter((sort) => sort.id !== PINNED_COLUMN_ID)),
		enableSortingRemoval: false,
		withSorting: true,
		getRowId: (row) => row.trackingKeywordId,
		enableRowSelection: true
	});
	const selectedRows = table.getSelectedRowModel().rows;
	const selectedCount = selectedRows.length;
	const selectedRankRows = selectedRows.map((row) => row.original);
	const exportSelection = (format) => exportRankTracking({
		format,
		rows: selectedRankRows,
		showDesktop,
		showMobile,
		domain,
		locationName,
		scope: "selection"
	});
	const removeMutation = useMutation({
		mutationFn: (keywordIds) => removeTrackingKeywords({ data: {
			projectId,
			configId,
			keywordIds
		} }),
		onSuccess: (result) => {
			table.resetRowSelection();
			setShowConfirm(false);
			queryClient.invalidateQueries({ queryKey: [
				"rankTrackingResults",
				projectId,
				configId
			] });
			queryClient.invalidateQueries({ queryKey: [
				"rankTrackingCostEstimate",
				projectId,
				configId
			] });
			toast.success(`${result.removed} keyword${result.removed !== 1 ? "s" : ""} removed`);
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBulkActionBar, {
			selectedCount,
			onClear: () => table.resetRowSelection(),
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center px-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBulkActionButton, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-3.5" }),
					onClick: () => setShowConfirm(true),
					variant: "danger",
					children: "Remove"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBulkExportMenu, { actions: [{
					label: "Export to Sheets",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, { className: "size-4" }),
					onClick: () => exportSelection("sheets")
				}, {
					label: "Export CSV",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileDown, { className: "size-4" }),
					onClick: () => exportSelection("csv")
				}] })]
			})
		}),
		showConfirm && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ConfirmDialog, {
			title: "Remove keywords?",
			confirmLabel: `Remove ${selectedCount} keyword${selectedCount !== 1 ? "s" : ""}`,
			destructive: true,
			pending: removeMutation.isPending,
			onConfirm: () => removeMutation.mutate(selectedRows.map((r) => r.id)),
			onClose: () => setShowConfirm(false),
			children: [
				"This will stop tracking ",
				selectedCount,
				" keyword",
				selectedCount !== 1 ? "s" : "",
				". Historical ranking data is preserved but won't appear in the table."
			]
		}),
		trendTarget && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeywordTrendModal, {
			target: trendTarget,
			projectId,
			configId,
			domain,
			locationCode,
			languageCode,
			locationName: locationName ?? void 0,
			serpDepth,
			onClose: () => setTrendTarget(null)
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
			table,
			isFiltered: totalCount > 0,
			onClearFilters,
			empty: {
				title: "No keywords yet",
				description: "Add the keywords you want to track for this domain.",
				action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: onAddKeywords,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "data-icon": "inline-start" }), "Add Keywords"]
				})
			},
			footer: rows.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "border-t border-border px-4 py-2 text-xs text-muted-foreground",
				children: [
					rows.length,
					" of ",
					totalCount,
					" keywords"
				]
			}) : null
		})
	] });
}
//#endregion
//#region src/client/features/rank-tracking/RankTrackingHistoryMatrix.tsx
/**
* "By date" view: keyword rows \u00d7 recent check columns, each cell the position
* on that date with its change vs the previous check. This is the pivoted
* history table users want for client reporting ("look \u2014 we won 5 positions").
*/
function RankTrackingHistoryMatrix({ cells, keywords, onClearFilters }) {
	const { runs, cellByKeyword } = (0, import_react.useMemo)(() => buildMatrix(cells), [cells]);
	if (keywords.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		kind: "filtered",
		title: "No keywords match these filters",
		description: "Change or clear the filters to see more keywords.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			size: "sm",
			onClick: onClearFilters,
			children: "Clear filters"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCard, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table$1, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
		className: "sticky left-0 z-10 w-full bg-card",
		children: "Keyword"
	}), runs.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
		className: "w-24 text-right",
		children: formatDate(r.checkedAt)
	}, r.runId))] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: keywords.map((kw) => {
		const byRun = cellByKeyword.get(kw.trackingKeywordId);
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "sticky left-0 z-10 bg-card font-medium whitespace-nowrap",
			children: kw.keyword
		}), runs.map((r, i) => {
			const cell = byRun?.get(r.runId);
			const notChecked = cell?.checked === false;
			const position = cell?.position ?? null;
			const previous = i > 0 ? byRun?.get(runs[i - 1].runId)?.position ?? null : void 0;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right",
				children: notChecked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotCheckedCell, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatrixCell, {
					position,
					previous
				})
			}, r.runId);
		})] }, kw.trackingKeywordId);
	}) })] }) });
}
function NotCheckedCell() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			"aria-label": "Not checked",
			className: "inline-flex cursor-help align-middle text-muted-foreground"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleSlash, {
			className: "size-3.5",
			"aria-hidden": true
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: "No result from Google on this check." })] });
}
function MatrixCell({ position, previous }) {
	if (position === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-muted-foreground",
		children: "\u2014"
	});
	const change = previous != null && previous !== void 0 ? previous - position : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center justify-end gap-1 font-mono text-xs",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: position }),
			change != null && change > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-success",
				children: ["\u25B2", change]
			}),
			change != null && change < 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-warning",
				children: ["\u25BC", -change]
			})
		]
	});
}
/** Distinct completed runs in a matrix payload (= history columns). */
function countMatrixRuns(cells) {
	return new Set(cells.map((c) => c.runId)).size;
}
function buildMatrix(cells) {
	const runMap = /* @__PURE__ */ new Map();
	const cellByKeyword = /* @__PURE__ */ new Map();
	for (const c of cells) {
		runMap.set(c.runId, c.checkedAt);
		let byRun = cellByKeyword.get(c.trackingKeywordId);
		if (!byRun) {
			byRun = /* @__PURE__ */ new Map();
			cellByKeyword.set(c.trackingKeywordId, byRun);
		}
		byRun.set(c.runId, c);
	}
	return {
		runs: t$4([...runMap.entries()].map(([runId, checkedAt]) => ({
			runId,
			checkedAt
		})), (a, b) => a.checkedAt.localeCompare(b.checkedAt)),
		cellByKeyword
	};
}
function formatDate(value) {
	return parseDbTimestamp(value).toLocaleDateString("en-US", {
		month: "short",
		day: "numeric"
	});
}
//#endregion
//#region src/client/features/rank-tracking/ToolbarMenus.tsx
function ItemText({ label, description }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs text-muted-foreground",
			children: description
		})]
	});
}
function MoreMenu({ onCheckNow, checkBusy, onRefreshMetrics, metricsRefreshing, trackedKeywordCount, hasData }) {
	const [confirmingRefresh, setConfirmingRefresh] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "icon-sm",
			"aria-label": "More actions",
			title: "More actions"
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, {})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "end",
		className: "w-60",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
			onClick: onCheckNow,
			disabled: checkBusy,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemText, {
				label: checkBusy ? "Running..." : "Check rankings",
				description: "Fetch current Google positions"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
			onClick: () => setConfirmingRefresh(true),
			disabled: metricsRefreshing || !hasData,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefreshCw, { className: metricsRefreshing ? "animate-spin" : "" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemText, {
				label: metricsRefreshing ? "Refreshing..." : "Update keyword stats",
				description: "Volume, difficulty & CPC \u2014 not rankings"
			})]
		})]
	})] }), confirmingRefresh ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ConfirmDialog, {
		title: "Update keyword stats?",
		confirmLabel: "Update stats",
		onConfirm: () => {
			setConfirmingRefresh(false);
			onRefreshMetrics();
		},
		onClose: () => setConfirmingRefresh(false),
		children: [
			"This fetches new volume, difficulty, and CPC for all",
			" ",
			trackedKeywordCount,
			" tracked keyword",
			trackedKeywordCount !== 1 ? "s" : "",
			". Each keyword uses credits. Rankings do not change."
		]
	}) : null] });
}
//#endregion
//#region src/client/features/rank-tracking/RankTrackingTableToolbar.tsx
var USUAL_CHECK_MS = 36e5;
/**
* An estimate, not a measure: the bar follows the time since the check started
* against how long one usually takes, and stops short of full for slower ones.
*/
function RankCheckProgress({ startedAt }) {
	const [now, setNow] = (0, import_react.useState)(() => Date.now());
	(0, import_react.useEffect)(() => {
		const timer = setInterval(() => setNow(Date.now()), 3e4);
		return () => clearInterval(timer);
	}, []);
	const elapsedMs = now - parseDbTimestamp(startedAt).getTime();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
		className: "ml-1 w-36",
		"aria-label": "Rank check progress",
		value: t(elapsedMs / USUAL_CHECK_MS, {
			min: .03,
			max: .95
		}),
		max: 1
	});
}
function RankTrackingTableToolbar({ showFilters, onToggleFilters, activeFilterCount, isRunning, latestRun, keywordCount, viewMode, onViewModeChange, historyAvailable, onExport, onCheckNow, onRefreshMetrics, metricsRefreshing, trackedKeywordCount, checkBusy, checkDisabled, hasData }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "shrink-0 flex flex-wrap items-center gap-2 px-4 py-2 border-y border-border",
		children: [
			historyAvailable && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegmentedToggle, {
				showLabels: true,
				items: [{
					value: "table",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Table, { className: "size-3.5" }),
					label: "Latest"
				}, {
					value: "history",
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarDays, { className: "size-3.5" }),
					label: "History"
				}],
				value: viewMode,
				onChange: onViewModeChange
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "outline",
				size: "sm",
				"aria-pressed": showFilters,
				className: "aria-pressed:bg-muted aria-pressed:text-foreground",
				onClick: onToggleFilters,
				title: "Toggle table filters",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { "data-icon": "inline-start" }),
					"Filters",
					activeFilterCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						size: "sm",
						children: activeFilterCount
					})
				]
			}),
			isRunning && latestRun ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "ml-2 flex items-center gap-2.5 text-sm font-medium text-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { className: "text-primary" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: latestRun.status === "pending" ? "Preparing..." : `Getting rankings for ${latestRun.keywordsTotal || "?"} keyword${latestRun.keywordsTotal !== 1 ? "s" : ""}...` }),
					latestRun.status === "running" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankCheckProgress, { startedAt: latestRun.startedAt })
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "text-sm text-muted-foreground",
				children: [keywordCount, " keywords"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportMenu, {
				actions: [
					"sheets",
					"csv",
					"copy-list"
				],
				copyListLabel: "Copy keywords",
				onExport,
				disabled: !hasData
			}),
			!checkDisabled && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreMenu, {
				onCheckNow,
				checkBusy,
				onRefreshMetrics,
				metricsRefreshing,
				trackedKeywordCount,
				hasData
			})
		]
	});
}
//#endregion
//#region src/client/features/rank-tracking/AddKeywordsPanel.tsx
function AddKeywordsPanel({ configId, projectId, onSuccess, onCancel }) {
	const matchCaseId = (0, import_react.useId)();
	const [keywordInput, setKeywordInput] = (0, import_react.useState)("");
	const [matchCase, setMatchCase] = (0, import_react.useState)(false);
	const mutation = useMutation({
		mutationFn: (kws) => addTrackingKeywords({ data: {
			projectId,
			configId,
			keywords: kws,
			matchCase
		} }),
		onSuccess: (result) => {
			setKeywordInput("");
			onSuccess(result);
		}
	});
	const isPending = mutation.isPending;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-end gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-1 flex-col gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				rows: 3,
				className: "min-w-0",
				"aria-label": "Keywords to add",
				placeholder: "Enter keywords, one per line",
				value: keywordInput,
				onChange: (e) => setKeywordInput(e.target.value)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex w-fit items-center gap-2",
				title: "Track these keywords exactly as typed instead of lowercasing them. Google can return different results for a capitalized brand name.",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
					id: matchCaseId,
					checked: matchCase,
					onCheckedChange: (checked) => setMatchCase(checked)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: matchCaseId,
					className: "text-xs font-normal",
					children: "Match case"
				})]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				pending: isPending,
				onClick: () => {
					const lines = keywordInput.split("\n").map((l) => l.trim()).filter(Boolean);
					if (lines.some((l) => l.length > 200)) {
						toast.error(`Keywords must be 200 characters or fewer.`);
						return;
					}
					if (lines.length > 0) mutation.mutate(lines);
				},
				disabled: !keywordInput.trim(),
				children: "Add"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				onClick: onCancel,
				children: "Cancel"
			})]
		})]
	});
}
//#endregion
//#region src/client/features/rank-tracking/CheckConfirmModal.tsx
function CheckConfirmModal({ keywordCount, devices, costUsd, isScheduled, isPending, onRunNow, onCancel }) {
	const dc = devicesCount(devices);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
		title: `Check ${keywordCount} keyword${keywordCount !== 1 ? "s" : ""}?`,
		confirmLabel: "Start check",
		pending: isPending,
		onConfirm: onRunNow,
		onClose: onCancel,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex flex-col gap-1",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					keywordCount,
					" keyword",
					keywordCount !== 1 ? "s" : "",
					" \u00D7 ",
					dc,
					" ",
					"device",
					dc !== 1 ? "s" : ""
				] }),
				costUsd != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
					"Costs up to",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono font-semibold text-foreground",
						children: ["$", costUsd.toFixed(2)]
					})
				] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [RANK_CHECK_DURATION_COPY, isScheduled ? " Your scheduled tracking won't change." : null] })
			]
		})
	});
}
//#endregion
//#region src/client/features/rank-tracking/useMetricsRefresh.ts
function useMetricsRefresh(projectId, configId) {
	const queryClient = useQueryClient();
	const mutation = useMutation({
		mutationFn: () => refreshTrackingKeywordMetrics({ data: {
			projectId,
			configId
		} }),
		onSuccess: (result) => {
			queryClient.invalidateQueries({ queryKey: [
				"rankTrackingResults",
				projectId,
				configId
			] });
			toast.success(`Metrics updated for ${result.updated} keywords`);
		}
	});
	return {
		refresh: mutation.mutate,
		isRefreshing: mutation.isPending
	};
}
//#endregion
//#region src/client/features/rank-tracking/useRankCheckTrigger.ts
function useRankCheckTrigger({ configId, isRunning, projectId, onSuccess }) {
	const queryClient = useQueryClient();
	const triggerMutation = useMutation({
		mutationFn: (opts) => triggerRankCheck({ data: {
			projectId,
			configId,
			keywordIds: opts.keywordIds
		} }),
		onSuccess: (result) => {
			onSuccess();
			queryClient.invalidateQueries({ queryKey: [
				"rankTrackingLatestRun",
				projectId,
				configId
			] });
			if (!result.ok) {
				toast.info("A rank check is already running");
				return;
			}
			captureClientEvent("rank_tracking:check_trigger");
			toast.success("Rank check started");
		}
	});
	const startCheck = (opts) => {
		if (triggerMutation.isPending || isRunning) return;
		triggerMutation.mutate(opts);
	};
	return {
		startCheck,
		/** True while the trigger request is in-flight */
		isPending: triggerMutation.isPending,
		/** True when any check activity is happening (running, starting, or pending) */
		isBusy: isRunning || triggerMutation.isPending
	};
}
//#endregion
//#region src/client/features/rank-tracking/useRankRunPolling.ts
/**
* Polls the latest rank check run for a config, auto-refreshing results
* and history when it observes a completed or failed run.
*/
function useRankRunPolling(projectId, configId) {
	const queryClient = useQueryClient();
	const lastTerminalRunRef = (0, import_react.useRef)(void 0);
	const { data: latestRun } = useQuery({
		queryKey: [
			"rankTrackingLatestRun",
			projectId,
			configId
		],
		queryFn: () => getLatestRankRun({ data: {
			projectId,
			configId
		} }),
		refetchInterval: (query) => {
			const run = query.state.data;
			const isTerminal = run?.status === "completed" || run?.status === "failed";
			const terminalRunKey = `${projectId}:${configId}:${run?.id}:${run?.status}`;
			if (isTerminal && lastTerminalRunRef.current !== terminalRunKey) {
				lastTerminalRunRef.current = terminalRunKey;
				queryClient.invalidateQueries({ queryKey: [
					"rankTrackingResults",
					projectId,
					configId
				] });
				queryClient.invalidateQueries({ queryKey: [
					"rankConfigTrend",
					projectId,
					configId
				] });
				queryClient.invalidateQueries({ queryKey: [
					"rankPositionMatrix",
					projectId,
					configId
				] });
				queryClient.invalidateQueries({ queryKey: [
					"rankKeywordHistory",
					projectId,
					configId
				] });
			}
			if ((run?.status === "pending" || run?.status === "running") && !run.maybeStale) return 3e3;
			return 3e4;
		}
	});
	return latestRun;
}
//#endregion
//#region src/client/features/rank-tracking/RankTrackingDomainDetail.tsx
function deviceVisibility(devices, activeDevice) {
	if (devices === "both") return {
		showDesktop: activeDevice === "desktop",
		showMobile: activeDevice === "mobile"
	};
	return {
		showDesktop: devices !== "mobile",
		showMobile: devices !== "desktop"
	};
}
function defaultComparePeriod(interval) {
	if (interval === "daily") return "1d";
	if (interval === "monthly") return "30d";
	return "7d";
}
function RankTrackingDomainDetail({ config, projectId, search, onSearchChange, onEdit }) {
	const planStatus = useHostedPlanGate();
	const queryClient = useQueryClient();
	const [showAddKeywords, setShowAddKeywords] = (0, import_react.useState)(false);
	const [showFilters, setShowFilters] = (0, import_react.useState)(false);
	const filters = (0, import_react.useMemo)(() => filterValuesFromSearch(search, EMPTY_FILTERS), [search]);
	const setFilters = (next) => onSearchChange(filterValuesToSearch(next));
	const [filterDraft, setFilterDraft] = useDebouncedDraft(filters, setFilters, (values) => normalizeFilterValues(values, EMPTY_FILTERS));
	const comparePeriod = search.compare ?? defaultComparePeriod(config.scheduleInterval);
	const activeDevice = config.devices === "both" ? search.device ?? "desktop" : config.devices;
	const viewMode = search.view ?? "table";
	const resultsQuery = useQuery({
		queryKey: [
			"rankTrackingResults",
			projectId,
			config.id,
			comparePeriod
		],
		queryFn: () => getLatestRankResults({ data: {
			projectId,
			configId: config.id,
			comparePeriod
		} }),
		placeholderData: keepPreviousData
	});
	const resultsData = resultsQuery.data;
	const latestRun = useRankRunPolling(projectId, config.id);
	const { data: matrixCells } = useQuery({
		queryKey: [
			"rankPositionMatrix",
			projectId,
			config.id,
			activeDevice
		],
		queryFn: () => getRankPositionMatrix({ data: {
			projectId,
			configId: config.id,
			device: activeDevice
		} })
	});
	const historyAvailable = countMatrixRuns(matrixCells ?? []) >= 2;
	const { data: costEstimate } = useQuery({
		queryKey: [
			"rankTrackingCostEstimate",
			projectId,
			config.id
		],
		queryFn: () => estimateRankCheckCost({ data: {
			projectId,
			configId: config.id
		} })
	});
	const [pendingCheck, setPendingCheck] = (0, import_react.useState)(null);
	const handleKeywordsAdded = (result) => {
		queryClient.invalidateQueries({ queryKey: [
			"rankTrackingCostEstimate",
			projectId,
			config.id
		] });
		queryClient.invalidateQueries({ queryKey: [
			"rankTrackingResults",
			projectId,
			config.id
		] });
		queryClient.invalidateQueries({ queryKey: [
			"rankTrackingLatestRun",
			projectId,
			config.id
		] });
		setShowAddKeywords(false);
		captureClientEvent("rank_tracking:keywords_add");
		toast.success(`${result.added} keyword${result.added !== 1 ? "s" : ""} added`);
		if (result.checkScheduledSoon) toast.info("The scheduled check within the hour covers these keywords");
		else if (!result.checkTriggered && result.added > 0 && planStatus === "paid") toast.info("Use 'Check rankings' to check these keywords");
	};
	const isRunning = (latestRun?.status === "pending" || latestRun?.status === "running") && !latestRun?.maybeStale;
	const { startCheck, isBusy, isPending } = useRankCheckTrigger({
		configId: config.id,
		isRunning,
		projectId,
		onSuccess: () => setPendingCheck(null)
	});
	const { refresh: refreshMetrics, isRefreshing: metricsRefreshing } = useMetricsRefresh(projectId, config.id);
	const requestCheck = (count, keywordIds) => {
		if (isBusy) return;
		setPendingCheck({
			count,
			keywordIds
		});
	};
	const rows = resultsData?.rows;
	const run = resultsData?.run;
	const trackedKeywordCount = costEstimate?.keywordCount ?? rows?.length ?? 0;
	const hasBothDevices = config.devices === "both";
	const { showDesktop, showMobile } = deviceVisibility(config.devices, activeDevice);
	const filtered = (0, import_react.useMemo)(() => applyFilters(rows ?? [], filters), [rows, filters]);
	const activeFilterCount = countActiveFilters(filters);
	const defaultSortId = showDesktop ? "desktopPosition" : "mobilePosition";
	const sortId = search.sort === "desktopPosition" && !showDesktop || search.sort === "mobilePosition" && !showMobile ? void 0 : search.sort;
	const effectiveViewMode = historyAvailable ? viewMode : "table";
	const exportFiltered = (format) => exportRankTracking({
		format,
		rows: filtered,
		showDesktop,
		showMobile,
		domain: config.domain,
		locationName: config.locationName
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankRunAlerts, { run: latestRun }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FreePlanAlert, { visible: planStatus === "free" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScheduledChecksPausedAlert, { hasScheduledCheck: isScheduledRankTrackingInterval(config.scheduleInterval) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-w-0 flex-1 flex-col overflow-hidden rounded-xl border border-border bg-card shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrackingDetailHeader, {
						config,
						run,
						costEstimate,
						hasBothDevices,
						activeDevice,
						onActiveDeviceChange: (device) => onSearchChange({
							device,
							sort: void 0,
							order: void 0
						}),
						comparePeriod,
						onComparePeriodChange: (compare) => onSearchChange({ compare }),
						onEdit,
						onToggleAddKeywords: () => setShowAddKeywords((c) => !c)
					}),
					showAddKeywords && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-4 pb-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddKeywordsPanel, {
							configId: config.id,
							projectId,
							onSuccess: handleKeywordsAdded,
							onCancel: () => setShowAddKeywords(false)
						})
					}),
					(rows?.length ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrackingOverview, {
						device: activeDevice,
						projectId,
						configId: config.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrackingTableToolbar, {
						showFilters,
						onToggleFilters: () => setShowFilters((c) => !c),
						activeFilterCount,
						isRunning,
						latestRun,
						keywordCount: filtered.length,
						viewMode: effectiveViewMode,
						onViewModeChange: (view) => onSearchChange({ view: view === "history" ? view : void 0 }),
						historyAvailable,
						onExport: (action) => {
							if (action !== "copy-list") return exportFiltered(action);
							navigator.clipboard.writeText(filtered.map((r) => r.keyword).join("\n"));
							toast.success("Keywords copied to clipboard");
						},
						onCheckNow: () => {
							if (trackedKeywordCount > 0) requestCheck(trackedKeywordCount);
						},
						onRefreshMetrics: refreshMetrics,
						metricsRefreshing,
						trackedKeywordCount,
						checkBusy: isBusy,
						checkDisabled: planStatus !== "paid",
						hasData: filtered.length > 0
					}),
					showFilters && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterPanel, {
						draft: filterDraft,
						setDraft: setFilterDraft,
						activeFilterCount,
						onReset: () => setFilters(EMPTY_FILTERS)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-4",
						children: effectiveViewMode === "history" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrackingHistoryMatrix, {
							cells: matrixCells ?? [],
							keywords: filtered.map((r) => ({
								trackingKeywordId: r.trackingKeywordId,
								keyword: r.keyword
							})),
							onClearFilters: () => setFilters(EMPTY_FILTERS)
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
							query: resultsQuery,
							errorFallback: "Failed to load rank data",
							loading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonCard, {}),
							children: (results) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrackingTable, {
								totalCount: results.rows.length,
								rows: filtered,
								showDesktop,
								showMobile,
								sorting: sortId ? [{
									id: sortId,
									desc: search.order === "desc"
								}] : [{
									id: defaultSortId,
									desc: false
								}],
								onSortingChange: (sorting) => {
									onSearchChange({
										sort: rankTrackingDetailSearchSchema.shape.sort.parse(sorting[0]?.id),
										order: sorting[0]?.desc ? "desc" : void 0
									});
								},
								domain: config.domain,
								configId: config.id,
								projectId,
								locationCode: config.locationCode,
								languageCode: config.languageCode,
								locationName: config.locationName,
								serpDepth: config.serpDepth,
								onAddKeywords: () => setShowAddKeywords(true),
								onClearFilters: () => setFilters(EMPTY_FILTERS)
							}, defaultSortId)
						})
					})
				]
			}),
			pendingCheck && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckConfirmModal, {
				keywordCount: pendingCheck.count,
				devices: config.devices,
				costUsd: costEstimate?.costUsd,
				isScheduled: isScheduledRankTrackingInterval(config.scheduleInterval),
				isPending,
				onRunNow: () => startCheck({ keywordIds: pendingCheck.keywordIds }),
				onCancel: () => setPendingCheck(null)
			})
		]
	});
}
//#endregion
//#region src/routes/_app/p/$projectId/rank-tracking/$configId.tsx?tsr-split=component
function RankTrackingConfigRoute() {
	const { projectId, configId } = Route.useParams();
	const navigate = useNavigate();
	const search = Route.useSearch();
	const queryClient = useQueryClient();
	const [showConfigModal, setShowConfigModal] = (0, import_react.useState)(false);
	const configsQuery = useQuery({
		queryKey: ["rankTrackingConfigs", projectId],
		queryFn: () => getRankTrackingConfigs({ data: { projectId } })
	});
	const config = configsQuery.data?.find((c) => c.id === configId) ?? null;
	const invalidateConfigs = () => {
		queryClient.invalidateQueries({ queryKey: ["rankTrackingConfigs", projectId] });
		queryClient.invalidateQueries({ queryKey: ["rankTrackingConfigSummaries", projectId] });
	};
	const handleBack = () => {
		navigate({
			to: "/p/$projectId/rank-tracking",
			params: { projectId }
		});
	};
	if (configsQuery.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonCard, {});
	if (!configsQuery.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
		error: configsQuery.error,
		fallback: "Failed to load domain configuration",
		onRetry: () => void configsQuery.refetch(),
		isRetrying: configsQuery.isFetching
	});
	if (!config) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		kind: "no-data",
		title: "Domain configuration not found",
		description: "This domain was archived or does not exist in this project.",
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			size: "sm",
			onClick: handleBack,
			children: "Back to domains"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrackingDomainDetail, {
		config,
		projectId,
		search,
		onSearchChange: (update) => {
			navigate({
				from: Route.fullPath,
				search: (prev) => ({
					...prev,
					...update
				}),
				replace: true
			});
		},
		onEdit: () => setShowConfigModal(true)
	}, config.id), showConfigModal && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RankTrackingConfigModal, {
		projectId,
		existingConfig: config,
		onClose: () => setShowConfigModal(false),
		onSaved: () => {
			setShowConfigModal(false);
			invalidateConfigs();
		}
	})] });
}
//#endregion
export { RankTrackingConfigRoute as component };
