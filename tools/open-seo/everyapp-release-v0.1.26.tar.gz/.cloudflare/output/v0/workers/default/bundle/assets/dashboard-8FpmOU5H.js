import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { Fn as object, Jn as string, Lt as boolean, Nt as array, Pn as number } from "./schemas-BPIpYT5n.js";
import { st as DashboardCacheService, y as ActivationRepository } from "./resolve-DrNDcpX6.js";
import { U as AppError } from "./onboarding-drip-B7bIbv_6.js";
import { t } from "./sort-CLx_CHCb.js";
import { t as ProjectRepository } from "./ProjectRepository-Cqc4MnZX.js";
import { t as AuditRepository } from "./AuditRepository-BtGPAfyq.js";
import { n as getIssueTypePageCountsForAudit } from "./auditSummaryQueries-DnYUL0DN.js";
import { t as safeHostname } from "./safe-url-B9MOXbhl.js";
import { t as createDataforseoClient } from "./client-D7Glrscv.js";
import { N as backlinksItemSchema, z as referringDomainItemSchema } from "./pricing-CjqMqwbe.js";
import { t as normalizeBacklinksTarget } from "./dataforseoBacklinksTarget-BlQuGr8N.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { a as dashboardStepDismissalSchema, n as dashboardProjectInputSchema, t as dashboardBacklinksInputSchema } from "./dashboard-wnLMhnEo.js";
import { n as mapBacklinksRows } from "./backlinksRowMappers-BmwL1Rci.js";
import { t as Ga4ConnectionRepository } from "./Ga4ConnectionRepository-CWfgy1XG.js";
import { f as GscNotConnectedError, l as resolveDateRange, n as isExpectedGrantFailure, r as GscConnectionRepository, t as GscService } from "./GscService-BMp-LMRy.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/server/features/dashboard/services/DashboardSiteService.ts
var querySchema = object({
	query: string(),
	clicks: number(),
	impressions: number(),
	position: number()
});
var queriesSchema = object({
	connected: boolean(),
	hasSearchData: boolean(),
	rows: array(querySchema),
	startDate: string(),
	endDate: string(),
	baselineStartDate: string()
});
async function getBacklinks(input, billingCustomer) {
	const result = await DashboardCacheService.readThrough({
		namespace: "dashboard:links:v2",
		organizationId: billingCustomer.organizationId,
		params: input,
		schema: array(backlinksItemSchema),
		maxAgeMs: 864e5,
		load: async () => {
			const target = normalizeBacklinksTarget(input.domain, { scope: "subdomains" });
			const from = (/* @__PURE__ */ new Date(Date.now() - 6048e5)).toISOString().slice(0, 10);
			return (await createDataforseoClient(billingCustomer).backlinks.rows({
				target: target.apiTarget,
				includeSubdomains: true,
				limit: 25,
				mode: "one_per_domain",
				status: input.kind === "lost" ? "lost" : "live",
				orderBy: [input.kind === "lost" ? "last_seen,desc" : "first_seen,desc"],
				filters: input.kind === "all" ? void 0 : [[
					input.kind === "lost" ? "last_seen" : "first_seen",
					">=",
					`${from} 00:00:00 +00:00`
				]]
			})).items;
		}
	});
	return {
		...result,
		value: mapBacklinksRows(result.value)
	};
}
async function getKeywords(projectId, organizationId) {
	const { startDate, endDate } = resolveDateRange({ dateRange: "last_28_days" });
	const connection = await GscConnectionRepository.getByProjectId(projectId);
	if (!connection) return {
		value: {
			connected: false,
			rows: [],
			startDate,
			endDate
		},
		fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
		stale: false,
		refreshError: null
	};
	return DashboardCacheService.readThrough({
		namespace: DashboardCacheService.gscNamespace(projectId, "keywords"),
		organizationId,
		params: {
			projectId,
			siteUrl: connection.siteUrl,
			accountId: connection.gscAccountId,
			updatedAt: connection.updatedAt
		},
		schema: object({
			connected: boolean(),
			rows: array(querySchema),
			startDate: string(),
			endDate: string()
		}),
		maxAgeMs: 864e5,
		shouldCache: (value) => value.connected,
		load: async () => {
			try {
				return {
					connected: true,
					rows: (await GscService.getPerformance({
						projectId,
						startDate,
						endDate,
						dimensions: ["query"],
						rowLimit: 25e3,
						dataState: "final"
					})).rows.filter((row) => row.keys?.[0]).map((row) => ({
						query: row.keys[0],
						clicks: row.clicks,
						impressions: row.impressions,
						position: row.position
					})),
					startDate,
					endDate
				};
			} catch (error) {
				if (error instanceof GscNotConnectedError || isExpectedGrantFailure(error)) return {
					connected: false,
					rows: [],
					startDate,
					endDate
				};
				throw error;
			}
		}
	});
}
async function getEmergingQueries(projectId, organizationId) {
	const { startDate, endDate } = resolveDateRange({ dateRange: "last_7_days" });
	const baselineEndDate = (/* @__PURE__ */ new Date(Date.parse(startDate) - 864e5)).toISOString().slice(0, 10);
	const baselineStartDate = (/* @__PURE__ */ new Date(Date.parse(startDate) - 24192e5)).toISOString().slice(0, 10);
	const connection = await GscConnectionRepository.getByProjectId(projectId);
	if (!connection) return {
		value: {
			connected: false,
			hasSearchData: false,
			rows: [],
			startDate,
			endDate,
			baselineStartDate
		},
		fetchedAt: (/* @__PURE__ */ new Date()).toISOString(),
		stale: false,
		refreshError: null
	};
	return DashboardCacheService.readThrough({
		namespace: DashboardCacheService.gscNamespace(projectId, "emerging-queries"),
		organizationId,
		params: {
			projectId,
			siteUrl: connection.siteUrl,
			accountId: connection.gscAccountId,
			updatedAt: connection.updatedAt,
			comparison: "verified-v3"
		},
		schema: queriesSchema,
		maxAgeMs: 864e5,
		shouldCache: (value) => value.connected,
		load: async () => {
			try {
				const [recent, baseline] = await Promise.all([GscService.getPerformance({
					projectId,
					startDate,
					endDate,
					dimensions: ["query"],
					rowLimit: 25e3,
					dataState: "final"
				}), GscService.getPerformance({
					projectId,
					startDate: baselineStartDate,
					endDate: baselineEndDate,
					dimensions: ["query"],
					rowLimit: 25e3,
					dataState: "final"
				})]);
				const seen = new Set(baseline.rows.map((row) => row.keys?.[0]));
				const observed = recent.rows.filter((row) => row.keys?.[0] && row.impressions >= 10 && !seen.has(row.keys[0])).map((row) => ({
					query: row.keys[0],
					clicks: row.clicks,
					impressions: row.impressions,
					position: row.position
				}));
				const rows = t(observed, (a, b) => b.impressions - a.impressions).slice(0, 25);
				const verified = [];
				if (baseline.rows.length === 25e3) for (let offset = 0; offset < rows.length; offset += 5) {
					const batch = rows.slice(offset, offset + 5);
					const history = await Promise.all(batch.map((row) => GscService.getPerformance({
						projectId,
						startDate: baselineStartDate,
						endDate: baselineEndDate,
						dimensions: ["query"],
						filters: [{
							dimension: "query",
							operator: "equals",
							expression: row.query
						}],
						rowLimit: 1,
						dataState: "final"
					})));
					batch.forEach((row, index) => {
						if (!history[index].rows.some((previous) => previous.impressions > 0)) verified.push(row);
					});
				}
				else verified.push(...rows);
				return {
					connected: true,
					hasSearchData: recent.rows.length > 0,
					rows: verified,
					startDate,
					endDate,
					baselineStartDate
				};
			} catch (error) {
				if (error instanceof GscNotConnectedError || isExpectedGrantFailure(error)) return {
					connected: false,
					hasSearchData: false,
					rows: [],
					startDate,
					endDate,
					baselineStartDate
				};
				throw error;
			}
		}
	});
}
async function getLinkActivity(domain, billingCustomer) {
	const target = normalizeBacklinksTarget(domain, { scope: "subdomains" }).apiTarget;
	const domains = await DashboardCacheService.readThrough({
		namespace: "dashboard:new-domains:v2",
		organizationId: billingCustomer.organizationId,
		params: { target },
		schema: array(referringDomainItemSchema),
		maxAgeMs: 864e5,
		load: async () => {
			const from = (/* @__PURE__ */ new Date(Date.now() - 6048e5)).toISOString().slice(0, 10);
			return (await createDataforseoClient(billingCustomer).backlinks.referringDomains({
				target,
				includeSubdomains: true,
				limit: 25,
				orderBy: ["first_seen,desc"],
				filters: [[
					"first_seen",
					">=",
					`${from} 00:00:00 +00:00`
				]]
			})).items;
		}
	});
	if (domains.value.length || domains.stale) return {
		...domains,
		value: domains.value.map((row) => ({
			domain: row.domain ?? null,
			backlinks: row.backlinks ?? null,
			firstSeen: row.first_seen ?? null
		})),
		kind: "domains",
		links: []
	};
	const links = await getBacklinks({
		domain,
		kind: "new"
	}, billingCustomer);
	return {
		...links,
		value: [],
		kind: "links",
		links: links.value
	};
}
var DashboardSiteService = {
	getKeywords,
	getBacklinks,
	getEmergingQueries,
	getLinkActivity
};
//#endregion
//#region src/server/features/dashboard/services/DashboardService.ts
async function getActivation(input) {
	const [ga4, gsc, orgActivation, projectActivation, projectCount, hasTeammate, dismissals, research, hasAudit] = await Promise.all([
		Ga4ConnectionRepository.getByProjectId(input.projectId),
		GscConnectionRepository.getByProjectId(input.projectId),
		ActivationRepository.getOrganizationActivation(input.organizationId),
		ActivationRepository.getProjectActivation(input.projectId),
		ProjectRepository.countProjects(input.organizationId),
		ActivationRepository.hasTeammate(input.organizationId),
		ActivationRepository.getDismissals(input),
		ActivationRepository.getWorkspaceResearch(input.organizationId),
		AuditRepository.hasAuditInOrganization(input.organizationId)
	]);
	return {
		domain: input.domain,
		hasMultipleProjects: projectCount > 1,
		hasTeammate,
		dismissedSteps: dismissals.skippedSteps,
		ga4: {
			connected: ga4 !== null,
			propertyDisplayName: ga4?.propertyDisplayName ?? null,
			cardDismissedAt: projectActivation?.ga4CardDismissedAt ?? null
		},
		gsc: {
			connected: gsc !== null,
			siteUrl: gsc?.siteUrl ?? null
		},
		mcp: {
			authorizedAt: orgActivation?.firstMcpAuthorizedAt ?? null,
			firstToolCallAt: orgActivation?.firstMcpToolCallAt ?? null,
			cardDismissed: dismissals.agentCardDismissed
		},
		competitorResearchedAt: research.competitorResearchedAt,
		keywordsResearchedAt: research.keywordResearchedAt,
		hasAudit
	};
}
async function getOverview(input) {
	return { audit: await getAuditSummary(input.projectId, input.domain) };
}
async function getAuditSummary(projectId, domain) {
	const hostname = domain ? safeHostname(`https://${domain}`) : null;
	if (!hostname) return null;
	const audit = (await AuditRepository.getAuditsByProject(projectId)).find((candidate) => safeHostname(candidate.startUrl) === hostname);
	if (!audit) return null;
	const typeRows = await getIssueTypePageCountsForAudit(audit.id);
	const severityRank = {
		critical: 0,
		warning: 1,
		info: 2
	};
	const sorted = t(typeRows.map((row) => ({
		issueType: row.issueType,
		severity: row.severity,
		count: row.pages
	})), (a, b) => severityRank[a.severity] - severityRank[b.severity] || b.count - a.count);
	return {
		id: audit.id,
		status: audit.status,
		pagesCrawled: audit.pagesCrawled,
		pagesTotal: audit.pagesTotal,
		currentPhase: audit.currentPhase,
		lighthouseCompleted: audit.lighthouseCompleted,
		lighthouseFailed: audit.lighthouseFailed,
		lighthouseTotal: audit.lighthouseTotal,
		startedAt: audit.startedAt,
		topIssues: sorted.slice(0, 3)
	};
}
var DashboardService = {
	setStepDismissed: ActivationRepository.setStepDismissed,
	getActivation,
	getOverview
};
//#endregion
//#region src/serverFunctions/dashboard.ts?tss-serverfn-split
var getDashboardActivation_createServerFn_handler = createServerRpc({
	id: "a966ba8dbd2e5e2548b12a6c770c26da924f90ee327285fecd7df1d7afeafe95",
	name: "getDashboardActivation",
	filename: "src/serverFunctions/dashboard.ts"
}, (opts) => getDashboardActivation.__executeServer(opts));
var getDashboardActivation = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(dashboardProjectInputSchema).handler(getDashboardActivation_createServerFn_handler, ({ context }) => DashboardService.getActivation({
	userId: context.userId,
	projectId: context.projectId,
	organizationId: context.organizationId,
	domain: context.project.domain
}));
var getDashboardOverview_createServerFn_handler = createServerRpc({
	id: "bf7707a336fe5f1a810d29eb9ddb4ccee4b8a2f0ce88e94d04a295456d7e71d1",
	name: "getDashboardOverview",
	filename: "src/serverFunctions/dashboard.ts"
}, (opts) => getDashboardOverview.__executeServer(opts));
var getDashboardOverview = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(dashboardProjectInputSchema).handler(getDashboardOverview_createServerFn_handler, ({ context }) => DashboardService.getOverview({
	projectId: context.projectId,
	domain: context.project.domain
}));
var dismissDashboardGa4Card_createServerFn_handler = createServerRpc({
	id: "39b646e1b210269ed692e316a1456d18b70794e8f2dd13b038ab141fc56de0c7",
	name: "dismissDashboardGa4Card",
	filename: "src/serverFunctions/dashboard.ts"
}, (opts) => dismissDashboardGa4Card.__executeServer(opts));
var dismissDashboardGa4Card = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(dashboardProjectInputSchema).handler(dismissDashboardGa4Card_createServerFn_handler, async ({ context }) => {
	await ActivationRepository.markGa4CardDismissed(context.projectId);
	return { ok: true };
});
var dismissDashboardAgentCard_createServerFn_handler = createServerRpc({
	id: "034df6b5fe778cbf6b972ce7f118196a4c5fd2a688f0f8d77023db66f9fc87d6",
	name: "dismissDashboardAgentCard",
	filename: "src/serverFunctions/dashboard.ts"
}, (opts) => dismissDashboardAgentCard.__executeServer(opts));
var dismissDashboardAgentCard = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(dashboardProjectInputSchema).handler(dismissDashboardAgentCard_createServerFn_handler, async ({ context }) => {
	await ActivationRepository.dismissAgentCard(context.userId, context.projectId);
	return { ok: true };
});
var setDashboardStepDismissed_createServerFn_handler = createServerRpc({
	id: "78f0a49990970b9cd9471f61034b671a1e71e3748c2f0cee639871f1ea324f89",
	name: "setDashboardStepDismissed",
	filename: "src/serverFunctions/dashboard.ts"
}, (opts) => setDashboardStepDismissed.__executeServer(opts));
var setDashboardStepDismissed = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(dashboardStepDismissalSchema).handler(setDashboardStepDismissed_createServerFn_handler, async ({ context, data }) => {
	await DashboardService.setStepDismissed({
		userId: context.userId,
		organizationId: context.organizationId,
		projectId: context.projectId,
		step: data.step,
		dismissed: data.dismissed
	});
	return { ok: true };
});
var getDashboardKeywords_createServerFn_handler = createServerRpc({
	id: "1655604aeefb1a34826090cdafb075f5cfd8924bb0f1f875779156c2df17ca4d",
	name: "getDashboardKeywords",
	filename: "src/serverFunctions/dashboard.ts"
}, (opts) => getDashboardKeywords.__executeServer(opts));
var getDashboardKeywords = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(dashboardProjectInputSchema).handler(getDashboardKeywords_createServerFn_handler, ({ context }) => DashboardSiteService.getKeywords(context.projectId, context.organizationId));
var getDashboardBacklinks_createServerFn_handler = createServerRpc({
	id: "220c6035bb5b3c7fd8343bef9e256cab776763369fc507f45ae0676199e59f07",
	name: "getDashboardBacklinks",
	filename: "src/serverFunctions/dashboard.ts"
}, (opts) => getDashboardBacklinks.__executeServer(opts));
var getDashboardBacklinks = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(dashboardBacklinksInputSchema).handler(getDashboardBacklinks_createServerFn_handler, ({ context, data }) => {
	if (!context.project.domain) throw new AppError("VALIDATION_ERROR", "Add your website in project settings first.");
	return DashboardSiteService.getBacklinks({
		domain: context.project.domain,
		kind: data.kind
	}, context);
});
var getDashboardEmergingQueries_createServerFn_handler = createServerRpc({
	id: "12cf2e90eb0e8dcafea37c63e5def7f535d4297b38130174b35113263fe01dd7",
	name: "getDashboardEmergingQueries",
	filename: "src/serverFunctions/dashboard.ts"
}, (opts) => getDashboardEmergingQueries.__executeServer(opts));
var getDashboardEmergingQueries = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(dashboardProjectInputSchema).handler(getDashboardEmergingQueries_createServerFn_handler, ({ context }) => DashboardSiteService.getEmergingQueries(context.projectId, context.organizationId));
var getDashboardLinkActivity_createServerFn_handler = createServerRpc({
	id: "1cca473f59402f4054b6e320d74b9ae77c462e3fa05628707233ab1d90112bff",
	name: "getDashboardLinkActivity",
	filename: "src/serverFunctions/dashboard.ts"
}, (opts) => getDashboardLinkActivity.__executeServer(opts));
var getDashboardLinkActivity = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(dashboardProjectInputSchema).handler(getDashboardLinkActivity_createServerFn_handler, ({ context }) => {
	if (!context.project.domain) throw new AppError("VALIDATION_ERROR", "Add your website first.");
	return DashboardSiteService.getLinkActivity(context.project.domain, context);
});
//#endregion
export { dismissDashboardAgentCard_createServerFn_handler, dismissDashboardGa4Card_createServerFn_handler, getDashboardActivation_createServerFn_handler, getDashboardBacklinks_createServerFn_handler, getDashboardEmergingQueries_createServerFn_handler, getDashboardKeywords_createServerFn_handler, getDashboardLinkActivity_createServerFn_handler, getDashboardOverview_createServerFn_handler, setDashboardStepDismissed_createServerFn_handler };
