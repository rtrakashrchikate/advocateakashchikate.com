import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { t as pageHead } from "./pageHead-BfhwMlwa.js";
import { i as brandLookupSearchSchema } from "./ai-search-BKw5OSiv.js";
//#region src/routes/_app/p/$projectId/brand-lookup.tsx
var $$splitComponentImporter = () => import("./brand-lookup-Bp7Erb6L.js");
var Route = createFileRoute("/_app/p/$projectId/brand-lookup")({
	head: () => pageHead("Brand Lookup"),
	validateSearch: brandLookupSearchSchema,
	remountDeps: ({ params }) => params.projectId,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
