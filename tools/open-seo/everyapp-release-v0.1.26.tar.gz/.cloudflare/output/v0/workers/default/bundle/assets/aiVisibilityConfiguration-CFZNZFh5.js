import { t } from "./sort-CLx_CHCb.js";
import { r as computeNextCheckAt } from "./rank-tracking-CfsrxyGC.js";
import { _ as resolveMarket, m as isSupportedLocationCode, t as DEFAULT_LOCATION_CODE, u as getLanguageOptions } from "./keyword-locations-4GfvBtRY.js";
import { l as aiEnginesWithoutLocation, m as ownBrandName, n as AI_ENGINE_LABELS, s as aiCountryLabel } from "./ai-visibility-b7Nyzqt-.js";
import { n as AiVisibilityError } from "./aiVisibilityErrors-CNlymTjF.js";
//#region src/server/features/ai-visibility/services/aiVisibilityMarket.ts
/** Resolve and validate the tracker's market after its engines are set. */
function applyMarket(rows, patch, created, engines) {
	let market = resolveMarket(patch, rows.tracker);
	let error = marketError(engines, market);
	if (error && created && patch.locationCode === void 0 && patch.languageCode === void 0) {
		market = {
			locationCode: DEFAULT_LOCATION_CODE,
			languageCode: "en"
		};
		error = null;
	}
	if (error) throw new AiVisibilityError("UNSUPPORTED_MARKET", error);
	rows.tracker.locationCode = market.locationCode;
	rows.tracker.languageCode = market.languageCode;
}
function marketError(engines, market) {
	if (!isSupportedLocationCode(market.locationCode)) return "Choose a locationCode from the project market country list, such as 2840 for the United States.";
	const country = aiCountryLabel(market.locationCode);
	const languages = getLanguageOptions(market.locationCode);
	if (!languages.some((l) => l.code === market.languageCode)) return `${country} supports languageCode ${languages.map((l) => l.code).join(" or ")}. Omit languageCode to use the country's default language.`;
	const unsupported = aiEnginesWithoutLocation(engines, market.locationCode);
	if (unsupported.length) return `${unsupported.map((e) => AI_ENGINE_LABELS[e]).join(" and ")} cannot collect answers in ${country}. Choose another country or remove the engine.`;
	return null;
}
//#endregion
//#region src/server/features/ai-visibility/services/aiVisibilityConfiguration.ts
var PROMPT_LIMIT = 100;
var TOPIC_LIMIT = 30;
function trackerEngines(tracker) {
	return [
		...tracker.chatgpt ? ["chatgpt"] : [],
		...tracker.gemini ? ["gemini"] : [],
		...tracker.googleAiOverview ? ["google_ai_overview"] : [],
		...tracker.claude ? ["claude"] : [],
		...tracker.perplexity ? ["perplexity"] : []
	];
}
function engineColumns(engines) {
	return {
		chatgpt: engines.includes("chatgpt"),
		gemini: engines.includes("gemini"),
		googleAiOverview: engines.includes("google_ai_overview"),
		claude: engines.includes("claude"),
		perplexity: engines.includes("perplexity")
	};
}
function activeAiPrompts(config) {
	return config.prompts.filter((p) => !p.paused && !p.archived);
}
/** Topics of unarchived prompts, in name order. */
function aiTopics(config) {
	return t([...new Set(config.prompts.filter((p) => !p.archived).map((p) => p.topic))], (a, b) => a.localeCompare(b));
}
/** The prompts and engines a check collects: every answer it pays for. */
function aiScope(config, promptIds) {
	const active = activeAiPrompts(config);
	if (promptIds?.some((id) => !active.some((p) => p.id === id))) throw new AiVisibilityError("INVALID_PROMPT_SELECTION", "Choose active prompt IDs from this tracker. Archived or paused prompts cannot be checked.");
	return {
		prompts: promptIds ? active.filter((p) => promptIds.includes(p.id)) : active,
		engines: trackerEngines(config.tracker)
	};
}
/** The project's own brand, then its competitors, from shared project context. */
function aiBrands(project, competitors) {
	if (!project.domain) return [];
	const brands = /* @__PURE__ */ new Map([[project.domain, {
		name: ownBrandName(project),
		domain: project.domain,
		own: true
	}]]);
	for (const c of competitors) if (!brands.has(c.domain)) brands.set(c.domain, {
		name: c.name || c.domain,
		domain: c.domain,
		own: false
	});
	return [...brands.values()];
}
/**
* A new tracker's first check, at least a full week out. The shared weekly
* slot is seven calendar days ahead at 04:00\u201310:00 UTC, which lands short of
* a week for trackers created later in the UTC day.
*/
function firstWeeklyCheckAt() {
	const next = new Date(computeNextCheckAt("weekly"));
	if (next.getTime() < Date.now() + 6048e5) next.setUTCDate(next.getUTCDate() + 1);
	return next.toISOString();
}
function projectAiConfiguration(input) {
	const { previous, patch, now } = input;
	const rows = previous ? structuredClone(previous) : {
		tracker: {
			id: crypto.randomUUID(),
			projectId: input.projectId,
			enabled: true,
			...engineColumns(["chatgpt", "gemini"]),
			...input.projectMarket,
			scheduleInterval: "weekly",
			nextCheckAt: firstWeeklyCheckAt(),
			lastSkipReason: null,
			createdAt: now
		},
		prompts: []
	};
	if (patch.engines) Object.assign(rows.tracker, engineColumns([...new Set(patch.engines)]));
	applyMarket(rows, patch, !previous, trackerEngines(rows.tracker));
	const counts = applyPrompts(rows, patch, now);
	const unarchived = rows.prompts.filter((p) => !p.archived);
	if (unarchived.length > PROMPT_LIMIT) throw new AiVisibilityError("PROMPT_LIMIT", "Tracking supports up to 100 unarchived prompts per project. Archive unused prompts first.");
	if (new Set(unarchived.map((p) => p.topic)).size > TOPIC_LIMIT) throw new AiVisibilityError("TOPIC_LIMIT", "Tracking supports up to 30 topics per project. Archive the prompts of an unused topic first.");
	return {
		rows,
		...counts
	};
}
/**
* Prompt text never changes in place. New text archives the edited prompt and
* adds the text as a prompt of its own, restoring an archived prompt with the
* same text so its history continues.
*/
function applyPrompts(rows, patch, now) {
	const trackerId = rows.tracker.id;
	let created = 0, updated = 0, skipped = 0;
	const touched = /* @__PURE__ */ new Set();
	for (const prompt of patch.prompts ?? []) {
		const existing = prompt.id ? rows.prompts.find((p) => p.id === prompt.id) : void 0;
		if (prompt.id && !existing) throw new AiVisibilityError("INVALID_PROMPT", "A supplied prompt ID is not part of this tracker. Read the tracker and retry with its IDs.");
		if (existing && touched.has(existing.id)) throw new AiVisibilityError("DUPLICATE_PROMPT_EDIT", "A prompt may be edited only once in a bulk patch.");
		if (existing) touched.add(existing.id);
		const text = prompt.text.trim();
		const topic = prompt.topic?.trim() || existing?.topic || "General";
		const paused = prompt.paused ?? existing?.paused ?? false;
		if (existing && existing.text === text) {
			Object.assign(existing, {
				topic,
				paused
			});
			updated++;
			continue;
		}
		if (rows.prompts.some((p) => p.text === text && !p.archived)) {
			if (existing) throw new AiVisibilityError("DUPLICATE_PROMPT", "This edit duplicates another active prompt's exact text.");
			skipped++;
			continue;
		}
		if (existing) {
			existing.archived = true;
			updated++;
		}
		const archived = rows.prompts.find((p) => p.archived && p.text === text);
		if (archived) {
			Object.assign(archived, {
				archived: false,
				topic,
				paused
			});
			touched.add(archived.id);
		} else {
			const id = crypto.randomUUID();
			touched.add(id);
			rows.prompts.push({
				id,
				trackerId,
				topic,
				text,
				paused,
				archived: false,
				createdAt: now
			});
		}
		created++;
	}
	for (const id of patch.archivePromptIds ?? []) {
		const prompt = rows.prompts.find((p) => p.id === id);
		if (!prompt) throw new AiVisibilityError("INVALID_PROMPT", "An archive ID does not belong to this tracker.");
		if (!prompt.archived) {
			prompt.archived = true;
			updated++;
		}
	}
	return {
		created,
		updated,
		skipped
	};
}
//#endregion
export { projectAiConfiguration as a, aiTopics as i, aiBrands as n, trackerEngines as o, aiScope as r, activeAiPrompts as t };
