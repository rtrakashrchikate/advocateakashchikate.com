import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { o as isEveryAppClientAuthMode } from "./auth-mode-DhGCw2Bx.js";
import "./projectContext--4-tA_3n.js";
import { n as researchProjectWebsiteSchema, r as saveProjectWebsiteSetupSchema } from "./projectWebsite-Co6Tcq0K.js";
import { j as useQueryClient, t as useQuery } from "./useQuery-B93OR2NQ.js";
import { a as SkeletonPageContent, t as QueryError, u as InsufficientCreditsError } from "./QueryState-Q8BZIblk.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { n as getErrorCode } from "./error-messages-D7nntGF_.js";
import { n as createLucideIcon } from "./dist-fVOGIv0D.js";
import { t as Check } from "./check-RTl8hsAC.js";
import { t as CircleCheck } from "./circle-check-BGTFRkka.js";
import { t as KeyRound } from "./key-round-D0hbOD4h.js";
import { H as LoaderCircle, t as Button } from "./button-DrcZrdio.js";
import { t as Pencil } from "./pencil-MnOzbXDL.js";
import { t as Plus } from "./plus-C1Kukp-u.js";
import { t as Sparkles } from "./sparkles-BtdH_814.js";
import { t as Trash2 } from "./trash-2-B7Pu83CI.js";
import { r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { r as CardContent, t as Card } from "./card-CqQO-5bL.js";
import { t as createSsrRpc } from "./createSsrRpc-Vp3C13VD.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { d as aiResearchSetupQueryOptions, f as aiRunResultsQueryOptions, h as aiVisibilityKey, k as startAiResearchSetup, p as aiTrackerQueryOptions, r as AiQueryError, u as aiResearchKeywordsQueryOptions } from "./shared-BW7GMYqD.js";
import { t as Input } from "./input-B1cALAbz.js";
import { a as FieldLabel, r as FieldDescription, t as Field } from "./field-CjRT_5Cr.js";
import { t as Textarea } from "./textarea-CsL-KvnQ.js";
import { a as TableHead, i as TableCell, n as TableBody, o as TableHeader, s as TableRow, t as Table } from "./table-CqwvrC02.js";
import { t as projectsQueryOptions } from "./projectQueries-CUURHKzv.js";
import { t as GateCard } from "./GateCard-BqUFeaDc.js";
import { t as useSamAccess } from "./useSamAccess-CvSdXA9X.js";
import { t as DomainFavicon } from "./DomainFavicon-C8RD5CUv.js";
import { n as updateProjectContext, t as getProjectContext } from "./projectContext-GLpIFuxX.js";
import { i as projectContextQueryKey } from "./shared-CdYhxQK9.js";
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Circle = createLucideIcon("circle", [["circle", {
	cx: "12",
	cy: "12",
	r: "10",
	key: "1mglay"
}]]);
//#endregion
//#region src/client/features/projects/WebsiteResearchProgress.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var STEP_MS = 15e3;
/** Research fills only missing context, so only those steps are listed. */
function WebsiteResearchProgress({ missingOverview, missingCompetitors, note }) {
	const steps = [
		...missingOverview ? ["Researching your website"] : [],
		...missingCompetitors ? ["Finding competitors"] : [],
		"Preparing topics and prompts"
	];
	const [current, setCurrent] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const interval = window.setInterval(() => setCurrent((index) => Math.min(index + 1, steps.length - 1)), STEP_MS);
		return () => window.clearInterval(interval);
	}, [steps.length]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-5 py-12 text-center",
		children: [
			steps.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				role: "status",
				"aria-atomic": "true",
				className: "text-xs font-medium text-muted-foreground",
				children: [
					"Step ",
					current + 1,
					" of ",
					steps.length,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "sr-only",
						children: [": ", steps[current]]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "space-y-3 text-left",
				children: steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					"aria-current": index === current ? "step" : void 0,
					className: `flex items-center gap-3 text-sm ${index > current ? "text-muted-foreground" : ""}`,
					children: [index < current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, {
						className: "size-4 text-success",
						"aria-hidden": true
					}) : index === current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, {
						className: "size-4 animate-spin",
						"aria-hidden": true
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, {
						className: "size-4 opacity-40",
						"aria-hidden": true
					}), step]
				}, step))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "max-w-sm text-xs text-muted-foreground",
				children: ["This can take up to a minute.", note ? ` ${note}` : ""]
			})
		]
	});
}
//#endregion
//#region src/client/features/ai-visibility/OpenRouterKeyGate.tsx
/**
* AI visibility setup researches the brand and suggests prompts through
* OpenRouter, so a self-hosted install without a key would only fail after
* the user starts research. Ask for the key first (hosted always has one).
*/
function OpenRouterKeyGate({ projectId, children }) {
	const access = useSamAccess(projectId);
	if (access.status === "ready") return children;
	if (access.status === "checking") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonPageContent, {});
	if (access.status === "error") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
		error: access.error,
		fallback: "Could not check the OpenRouter API key.",
		onRetry: access.onRetry,
		isRetrying: access.isRetrying
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-[calc(100dvh-8rem)] place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GateCard, {
			className: "max-w-2xl",
			icon: KeyRound,
			tone: "warning",
			title: "Add an OpenRouter API key",
			description: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "AI visibility uses OpenRouter to research your brand and suggest the prompts worth tracking, so you don't have to write them yourself. The tracking results, what ChatGPT and other AI engines actually answer, come from your DataForSEO account." }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"Create a key on OpenRouter, set it as",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "OPENROUTER_API_KEY" }),
				", restart OpenSEO, then confirm here. The",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: "underline underline-offset-2 hover:text-foreground",
					to: "/help/openrouter-api-key",
					children: "OpenRouter API key setup guide"
				}),
				" ",
				"has the steps for each deployment."
			] })] }),
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				pending: access.isRefetching,
				onClick: access.onRetry,
				children: "Confirm API Key"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "lg",
				variant: "outline",
				nativeButton: false,
				render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://openrouter.ai/settings/keys",
					target: "_blank",
					rel: "noreferrer"
				}),
				children: "Open OpenRouter Keys"
			})] })
		})
	});
}
//#endregion
//#region src/client/features/projects/WebsiteCompetitorRow.tsx
function WebsiteCompetitorRow({ competitor, index, editing, onChange, onEdit, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DomainFavicon, { domain: competitor.domain }), editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				autoFocus: true,
				"aria-label": `Competitor ${index + 1} name`,
				placeholder: "Competitor name",
				required: true,
				maxLength: 120,
				value: competitor.name,
				onChange: (event) => onChange({
					...competitor,
					name: event.target.value
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium",
				children: competitor.name
			})]
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			"aria-label": `Competitor ${index + 1} website`,
			placeholder: "example.com",
			required: true,
			maxLength: 255,
			value: competitor.domain,
			onChange: (event) => onChange({
				...competitor,
				domain: event.target.value,
				notes: ""
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: competitor.domain
		}) }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "w-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-end gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon-sm",
					"aria-label": editing ? "Done editing competitor" : `Edit ${competitor.name}`,
					disabled: editing && (!competitor.name.trim() || !competitor.domain.trim()),
					onClick: onEdit,
					children: editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, { className: "size-4" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "ghost",
					size: "icon-sm",
					"aria-label": `Remove ${competitor.name || `competitor ${index + 1}`}`,
					onClick: onRemove,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
				})]
			})
		})
	] });
}
//#endregion
//#region src/client/features/projects/WebsiteSetupReview.tsx
function WebsiteSetupReview({ projectId, research, saving, error, onSave, onBack }) {
	const [brandName, setBrandName] = (0, import_react.useState)(research.name);
	const [competitors, setCompetitors] = (0, import_react.useState)(research.competitors.map(({ name, domain, notes }) => ({
		id: crypto.randomUUID(),
		name,
		domain,
		notes
	})));
	const [editing, setEditing] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "w-full max-w-3xl py-6 md:py-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "px-6 md:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-6",
				onSubmit: (event) => {
					event.preventDefault();
					onSave({
						name: brandName.trim(),
						domain: research.domain,
						overview: research.overview,
						suggestedTopics: research.suggestedTopics,
						suggestedKeywords: research.suggestedKeywords,
						competitors: competitors.map(({ name, domain, notes }) => ({
							name,
							domain,
							notes
						}))
					});
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-semibold tracking-tight",
					children: research.preserveCompetitors ? "Complete project setup" : "Edit your brand and competitors"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted-foreground",
					children: [
						"You can edit your",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/p/$projectId/context",
							params: { projectId },
							className: "text-foreground underline underline-offset-4",
							children: "project context"
						}),
						" ",
						"at any time."
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
					disabled: saving,
					className: "min-w-0 space-y-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
								htmlFor: "setup-brand-name",
								children: "Brand name"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "setup-brand-name",
								value: brandName,
								onChange: (event) => setBrandName(event.target.value),
								maxLength: 120,
								required: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: "We look for this name in AI answers." })
						] }),
						research.preserveCompetitors ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "We\u2019ll use the competitors already saved in your project context."
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-lg border border-border",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Name" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Website" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "sr-only",
									children: "Actions"
								}) })
							] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableBody, { children: [competitors.map((competitor, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebsiteCompetitorRow, {
								competitor,
								index,
								editing: editing === competitor.id,
								onChange: (changed) => setCompetitors(competitors.map((row) => row.id === changed.id ? changed : row)),
								onEdit: () => setEditing(editing === competitor.id ? null : competitor.id),
								onRemove: () => setCompetitors(competitors.filter((row) => row.id !== competitor.id))
							}, competitor.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRow, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
								colSpan: 3,
								className: "text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									type: "button",
									variant: "ghost",
									size: "sm",
									disabled: competitors.length >= 100,
									onClick: () => {
										const id = crypto.randomUUID();
										setCompetitors([...competitors, {
											id,
											name: "",
											domain: "",
											notes: ""
										}]);
										setEditing(id);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), " Add competitor"]
								})
							}) })] })] })
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
							variant: "destructive",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "We couldn\u2019t save your project. Check the competitor names and websites, then try again." })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [onBack ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "outline",
								onClick: onBack,
								children: "Back"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								type: "submit",
								disabled: !brandName.trim() || competitors.some((row) => !row.name.trim() || !row.domain.trim()),
								children: [
									saving && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "size-4 animate-spin" }),
									" ",
									"Continue"
								]
							})]
						})
					]
				})]
			})
		})
	});
}
//#endregion
//#region src/serverFunctions/projectWebsite.ts
var researchProjectWebsite = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(researchProjectWebsiteSchema).handler(createSsrRpc("c0d5e5c1596b1dc41fa32ed6200a9dbbe633ef4199e220331621e3971f30acac"));
var saveProjectWebsiteSetup = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(saveProjectWebsiteSetupSchema).handler(createSsrRpc("fa7c2597b8b61de5f30f270445da8576902f377aea987bee964b0ae3ac137791"));
//#endregion
//#region src/client/features/ai-visibility/AiResearchSetupGate.tsx
/**
* AI visibility needs a tracker. A project with a website but none confirms
* the spend here, then the server runs setup once: website research and the
* onboarding competitor review when the overview or competitors are missing,
* otherwise one keyword and prompt generation, reusing keywords already saved.
* The run lives on the server, so leaving or reloading the page finds it
* again. Both paths end on the page that started setup.
*/
function AiResearchSetupGate({ projectId, children }) {
	const queryClient = useQueryClient();
	const setupOptions = aiResearchSetupQueryOptions(projectId);
	const setup = useQuery(setupOptions);
	const refresh = () => Promise.all([
		queryClient.invalidateQueries({ queryKey: aiVisibilityKey(projectId) }),
		queryClient.invalidateQueries({ queryKey: ["projectContext", projectId] }),
		queryClient.invalidateQueries({ queryKey: projectsQueryOptions().queryKey })
	]);
	const start = useMutation({
		mutationFn: () => startAiResearchSetup({ data: { projectId } }),
		onSuccess: (data) => queryClient.setQueryData(setupOptions.queryKey, data)
	});
	const [overview, setOverview] = (0, import_react.useState)("");
	const saveOverview = useMutation({
		mutationFn: () => updateProjectContext({ data: {
			projectId,
			updates: [{
				section: "business_overview",
				content: overview.trim()
			}]
		} }),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["projectContext", projectId] });
			start.mutate();
		}
	});
	const loadSetupResults = async () => {
		const tracker = aiTrackerQueryOptions(projectId);
		const keywords = aiResearchKeywordsQueryOptions(projectId);
		await Promise.all([queryClient.fetchQuery({
			...tracker,
			staleTime: 0
		}).then(({ recentRuns }) => {
			const runId = recentRuns[0]?.id;
			if (runId) return queryClient.prefetchQuery(aiRunResultsQueryOptions(projectId, runId));
		}, () => queryClient.removeQueries({ queryKey: tracker.queryKey })), queryClient.fetchQuery({
			...keywords,
			staleTime: 0
		}).catch(() => queryClient.removeQueries({ queryKey: keywords.queryKey }))]);
		await refresh();
	};
	const save = useMutation({
		mutationFn: (accepted) => saveProjectWebsiteSetup({ data: {
			...accepted,
			projectId
		} }),
		onSuccess: loadSetupResults
	});
	const status = setup.data?.status;
	const [lastStatus, setLastStatus] = (0, import_react.useState)(status);
	const [finishing, setFinishing] = (0, import_react.useState)(false);
	if (status !== lastStatus) {
		setLastStatus(status);
		if (lastStatus && lastStatus !== "ready" && status === "ready" && !save.isPending) setFinishing(true);
	}
	(0, import_react.useEffect)(() => {
		if (finishing) loadSetupResults().finally(() => setFinishing(false));
	}, [finishing]);
	if (setup.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonPageContent, {});
	if (setup.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiQueryError, {
		error: setup.error,
		retry: () => {
			setup.refetch();
		}
	});
	if (status === "ready" && !finishing) return children;
	const data = setup.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OpenRouterKeyGate, {
		projectId,
		children: renderSetup()
	});
	function renderSetup() {
		if (data.review) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid min-h-[calc(100dvh-8rem)] place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebsiteSetupReview, {
				projectId,
				research: data.review,
				saving: save.isPending,
				error: save.isError,
				onSave: (accepted) => save.mutate(accepted)
			})
		});
		if (status === "running" || start.isPending || finishing) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid min-h-[calc(100dvh-8rem)] place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebsiteResearchProgress, {
				missingOverview: data.missingOverview,
				missingCompetitors: data.missingCompetitors,
				note: "You can leave this page; setup keeps running."
			})
		});
		const failed = status === "failed" || start.isError;
		const unreadable = !start.isError && data.failure === "website_unreadable";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid min-h-[calc(100dvh-8rem)] place-items-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "w-full max-w-2xl py-6 md:py-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-6 px-6 md:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-4 flex size-10 items-center justify-center rounded-lg border border-border bg-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-semibold tracking-tight",
								children: "Set up AI visibility"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm leading-relaxed text-muted-foreground",
								children: "We\u2019ll research your brand and find the most relevant topics to monitor."
							})
						] }),
						getErrorCode(start.error) === "INSUFFICIENT_CREDITS" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsufficientCreditsError, { title: "We couldn\u2019t set up AI visibility" }) : failed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
							variant: "destructive",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: unreadable ? "We couldn\u2019t read this website. Its bot protection may be blocking us. Describe your business below and try again, or check the URL in project settings." : !start.isError && data.failure === "subrequest_limit" ? "Setup needs more outgoing requests than Cloudflare Workers Free allows (50). Upgrade to Workers Paid or run the Docker edition, then try again." : isEveryAppClientAuthMode() ? "We couldn\u2019t finish setting up AI visibility. It needs DataForSEO and OpenRouter on your Every App gateway: if they aren\u2019t set up yet, an owner or admin runs pnpm everyapp secret set DATAFORSEO_API_KEY OPENROUTER_API_KEY. Then try again." : "We couldn\u2019t finish setting up AI visibility. Try again." })
						}),
						unreadable && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
								htmlFor: "business-overview",
								children: "What you sell, who buys it, and where"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								id: "business-overview",
								value: overview,
								onChange: (event) => setOverview(event.target.value),
								maxLength: 4e3,
								rows: 4
							}),
							saveOverview.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-destructive",
								children: "We couldn\u2019t save your description. Try again."
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								className: "w-full",
								pending: saveOverview.isPending,
								onClick: () => overview.trim() ? saveOverview.mutate() : start.mutate(),
								children: failed ? "Try again" : "Start research"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs leading-relaxed text-muted-foreground",
								children: isEveryAppClientAuthMode() ? "Research and a first run of your prompts use the DataForSEO and OpenRouter keys on your Every App gateway." : "Research and a first run of your prompts use a small amount of usage credits."
							})]
						})
					]
				})
			})
		});
	}
}
//#endregion
//#region src/client/features/projects/ProjectWebsiteSetup.tsx
function ProjectWebsiteSetup({ projectId }) {
	const queryClient = useQueryClient();
	const [website, setWebsite] = (0, import_react.useState)("");
	const [research, setResearch] = (0, import_react.useState)(null);
	const context = useQuery({
		queryKey: projectContextQueryKey(projectId),
		queryFn: () => getProjectContext({ data: { projectId } })
	});
	const researchMutation = useMutation({
		mutationFn: () => researchProjectWebsite({ data: {
			projectId,
			website
		} }),
		onSuccess: setResearch
	});
	const saveMutation = useMutation({
		mutationFn: (accepted) => saveProjectWebsiteSetup({ data: {
			...accepted,
			projectId
		} }),
		onSuccess: async () => {
			await Promise.all([
				queryClient.invalidateQueries({ queryKey: projectsQueryOptions().queryKey }),
				queryClient.invalidateQueries({ queryKey: ["projectAccess", projectId] }),
				queryClient.invalidateQueries({ queryKey: ["projectContext", projectId] }),
				queryClient.invalidateQueries({ queryKey: ["aiVisibility", projectId] })
			]);
			toast.success("Project context saved");
		}
	});
	if (research) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebsiteSetupReview, {
		projectId,
		research,
		saving: saveMutation.isPending,
		error: saveMutation.isError,
		onSave: (accepted) => saveMutation.mutate(accepted),
		onBack: () => {
			setResearch(null);
			saveMutation.reset();
		}
	});
	if (researchMutation.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WebsiteResearchProgress, {
		missingOverview: !context.data?.sections.some((section) => section.key === "business_overview"),
		missingCompetitors: !context.data?.competitors.length
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
		className: "w-full max-w-2xl py-6 md:py-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "px-6 md:px-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "space-y-6",
				onSubmit: (event) => {
					event.preventDefault();
					researchMutation.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-4 flex size-10 items-center justify-center rounded-lg border border-border bg-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-5" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-semibold tracking-tight",
							children: "Set up AI visibility"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm leading-relaxed text-muted-foreground",
							children: "We\u2019ll research your brand and find the most relevant topics to monitor."
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
						htmlFor: "project-website",
						children: "Website URL"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "project-website",
						inputMode: "url",
						autoComplete: "url",
						placeholder: "Enter your website URL",
						value: website,
						onChange: (event) => setWebsite(event.target.value),
						required: true
					})] }),
					getErrorCode(researchMutation.error) === "INSUFFICIENT_CREDITS" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsufficientCreditsError, { title: "We couldn\u2019t research this website" }) : researchMutation.isError && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
						variant: "destructive",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "We couldn\u2019t research this website. Check the URL and provider settings, then try again." })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							size: "lg",
							disabled: !website.trim(),
							className: "w-full",
							children: "Start research"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs leading-relaxed text-muted-foreground",
							children: isEveryAppClientAuthMode() ? "Research and a first run of your prompts use the DataForSEO and OpenRouter keys on your Every App gateway." : "Research and a first run of your prompts use a small amount of usage credits."
						})]
					})
				]
			})
		})
	});
}
//#endregion
//#region src/client/features/projects/ProjectWebsiteGate.tsx
function ProjectWebsiteGate({ projectId, children }) {
	const query = useQuery(projectsQueryOptions());
	if (query.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonPageContent, {});
	if (query.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
		fallback: "Couldn't load your project.",
		error: query.error,
		onRetry: () => void query.refetch(),
		isRetrying: query.isFetching
	});
	const project = query.data.find((row) => row.id === projectId);
	if (!project) return null;
	if (project.domain) return children;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-[calc(100dvh-8rem)] place-items-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectWebsiteSetup, { projectId })
	});
}
//#endregion
export { AiResearchSetupGate as n, ProjectWebsiteGate as t };
