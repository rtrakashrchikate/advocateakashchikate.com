import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { g as EmptyState, n as QueryState } from "./QueryState-Q8BZIblk.js";
import { t as FileText } from "./file-text-D3JyNNBV.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as Trash2 } from "./trash-2-B7Pu83CI.js";
import { t as formatRelativeTime } from "./relative-time-C7DmX3yX.js";
import { t as Route } from "./reports-XwgODRNF.js";
import { r as PageHeader } from "./PageHeader-a3_4WaC8.js";
import { a as TableHead, i as TableCell, n as TableBody, o as TableHeader, r as TableCard, s as TableRow, t as Table } from "./table-CqwvrC02.js";
import { i as DropdownMenuItem } from "./dropdown-menu-DubRfxrI.js";
import { t as RowActionsMenu } from "./RowActionsMenu-zl2TiODR.js";
import { l as listReports, o as reportsQueryKey, r as formatCreatedBy, s as useDeleteReport, t as DeleteReportModal } from "./shared-Ch5KnON8.js";
//#region src/client/features/reports/ReportsList.tsx
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ReportsList({ projectId, reports, onDelete }) {
	if (reports.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: FileText,
		title: "No reports yet",
		description: "Run an OpenSEO skill such as seo-audit from Claude Code or Codex and the report will appear here."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCard, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Title" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Created by" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Type" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Updated" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {})
		] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: reports.map((report) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "max-w-[420px]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/p/$projectId/reports/$reportId",
					params: {
						projectId,
						reportId: report.id
					},
					className: "font-medium hover:underline",
					children: report.title
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-muted-foreground",
				children: formatCreatedBy(report)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-muted-foreground",
				children: report.templateName ?? report.skill ?? "\u2014"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap text-muted-foreground",
				children: formatRelativeTime(report.updatedAt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "w-10 text-right",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowActionsMenu, {
					label: `Actions for ${report.title}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
						variant: "destructive",
						onClick: () => onDelete(report),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Delete"]
					})
				})
			})
		] }, report.id)) })] }) }), reports.length === 100 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs text-muted-foreground",
			children: [
				"Showing the ",
				100,
				" most recent reports."
			]
		}) : null]
	});
}
//#endregion
//#region src/routes/_app/p/$projectId/reports/index.tsx?tsr-split=component
function ReportsPage() {
	const { projectId } = Route.useParams();
	const [pendingDelete, setPendingDelete] = (0, import_react.useState)(null);
	const reportsQuery = useQuery({
		queryKey: reportsQueryKey(projectId),
		queryFn: () => listReports({ data: {
			projectId,
			limit: 100
		} }),
		staleTime: 0
	});
	const deleteMutation = useDeleteReport(projectId, () => setPendingDelete(null));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-auto px-4 py-4 pb-24 md:px-6 md:py-6 md:pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Reports",
				description: "HTML reports your agents saved to this project.",
				actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					nativeButton: false,
					render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/p/$projectId/reports/templates",
						params: { projectId }
					}),
					children: "Templates"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
				query: reportsQuery,
				errorFallback: "Failed to load reports",
				children: (data) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportsList, {
					projectId,
					reports: data.reports,
					onDelete: setPendingDelete
				})
			})]
		}), pendingDelete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteReportModal, {
			title: pendingDelete.title,
			isPending: deleteMutation.isPending,
			onClose: () => setPendingDelete(null),
			onConfirm: () => deleteMutation.mutate(pendingDelete.id)
		}) : null]
	});
}
//#endregion
export { ReportsPage as component };
