import { G as eq, H as asc, Q as isNull, U as desc, W as and, X as inArray, nt as ne, t as db, tt as lte } from "./db-DhHkpZWI.js";
import { P as projectCompetitors, R as projects, a as aiPrompts, c as aiTrackers, i as aiObservations, o as aiRuns, r as aiMatches, s as aiSources } from "./schema-Cn_vcAkd.js";
import { n as runBatch } from "./runBatch-CENJH-Sm.js";
import { t } from "./chunk-CYiqfj-i.js";
import { t as normalizeAiSuggestion } from "./ai-prompt-suggestions-BlfcqfCk.js";
//#region src/server/features/ai-visibility/repositories/aiVisibilityConfigurationRepository.ts
async function getTracker(projectId) {
	return (await db.select().from(aiTrackers).where(eq(aiTrackers.projectId, projectId)).limit(1))[0] ?? null;
}
async function getConfiguration(projectId) {
	const tracker = await getTracker(projectId);
	if (!tracker) return null;
	return {
		tracker,
		prompts: await db.select().from(aiPrompts).where(eq(aiPrompts.trackerId, tracker.id)).orderBy(asc(aiPrompts.createdAt), asc(aiPrompts.id))
	};
}
async function saveConfiguration(rows) {
	await runBatch((tx) => writeConfiguration(tx, rows));
}
/** Upserts the tracker's collection settings and every prompt. */
function writeConfiguration(tx, rows) {
	const { tracker } = rows;
	return [tx.insert(aiTrackers).values(tracker).onConflictDoUpdate({
		target: aiTrackers.id,
		set: {
			chatgpt: tracker.chatgpt,
			gemini: tracker.gemini,
			googleAiOverview: tracker.googleAiOverview,
			claude: tracker.claude,
			perplexity: tracker.perplexity,
			locationCode: tracker.locationCode,
			languageCode: tracker.languageCode
		}
	}), ...rows.prompts.map((prompt) => tx.insert(aiPrompts).values(prompt).onConflictDoUpdate({
		target: aiPrompts.id,
		set: {
			topic: prompt.topic,
			paused: prompt.paused,
			archived: prompt.archived
		}
	}))];
}
/** Fills a project's missing Prompt Research keywords, in the given order. */
function writeResearchKeywords(tx, projectId, names) {
	const keywords = [...new Map(names.map((name) => [normalizeAiSuggestion(name), name.replace(/\s+/g, " ").trim()])).values()].filter(Boolean);
	return [tx.update(projects).set({ aiResearchKeywords: keywords.join("\n") || null }).where(and(eq(projects.id, projectId), isNull(projects.aiResearchKeywords)))];
}
//#endregion
//#region src/server/features/ai-visibility/repositories/AiVisibilityRepository.ts
var ACTIVE_RUN_STATUSES = ["queued", "running"];
/** One atomic batch; the one-active-run index rejects a second active run. */
async function createRun(run, observations) {
	await runBatch((tx) => [tx.insert(aiRuns).values(run), ...observations.map((observation) => tx.insert(aiObservations).values(observation))]);
}
async function getRun(projectId, runId) {
	return (await db.select().from(aiRuns).where(and(eq(aiRuns.projectId, projectId), eq(aiRuns.id, runId))).limit(1))[0] ?? null;
}
async function getRunInternal(runId) {
	return (await db.select().from(aiRuns).where(eq(aiRuns.id, runId)).limit(1))[0] ?? null;
}
async function listRuns(projectId, limit = 20) {
	return db.select().from(aiRuns).where(eq(aiRuns.projectId, projectId)).orderBy(desc(aiRuns.createdAt), desc(aiRuns.id)).limit(limit);
}
async function getActiveRun(trackerId) {
	return (await db.select().from(aiRuns).where(and(eq(aiRuns.trackerId, trackerId), inArray(aiRuns.status, ACTIVE_RUN_STATUSES))).limit(1))[0] ?? null;
}
var observationColumns = {
	id: aiObservations.id,
	runId: aiObservations.runId,
	promptId: aiObservations.promptId,
	engine: aiObservations.engine,
	branded: aiObservations.branded,
	status: aiObservations.status,
	collectedAt: aiObservations.collectedAt,
	answerMarkdown: aiObservations.answerMarkdown,
	error: aiObservations.error,
	prompt: aiPrompts.text,
	topic: aiPrompts.topic
};
/** Answers with their prompt's exact text and current topic. */
async function getObservations(runIds, promptId) {
	if (!runIds.length) return [];
	return db.select(observationColumns).from(aiObservations).innerJoin(aiPrompts, eq(aiPrompts.id, aiObservations.promptId)).where(and(inArray(aiObservations.runId, runIds), promptId ? eq(aiObservations.promptId, promptId) : void 0)).orderBy(asc(aiPrompts.topic), asc(aiPrompts.text), asc(aiObservations.engine));
}
async function getObservation(id) {
	return (await db.select(observationColumns).from(aiObservations).innerJoin(aiPrompts, eq(aiPrompts.id, aiObservations.promptId)).where(eq(aiObservations.id, id)).limit(1))[0] ?? null;
}
async function getEvidence(observationIds) {
	const sources = [];
	const matches = [];
	for (let offset = 0; offset < observationIds.length; offset += 80) {
		const ids = observationIds.slice(offset, offset + 80);
		const [s, m] = await Promise.all([db.select().from(aiSources).where(inArray(aiSources.observationId, ids)).orderBy(asc(aiSources.position)), db.select().from(aiMatches).where(inArray(aiMatches.observationId, ids))]);
		sources.push(...s);
		matches.push(...m);
	}
	return {
		sources,
		matches
	};
}
/**
* Prompts with at least one collected answer, in any run. A completed
* collection with no answer text (no AI Overview shown) does not count.
*/
async function listAnsweredPromptIds(trackerId) {
	return (await db.selectDistinct({ promptId: aiObservations.promptId }).from(aiObservations).innerJoin(aiPrompts, eq(aiPrompts.id, aiObservations.promptId)).where(and(eq(aiPrompts.trackerId, trackerId), eq(aiObservations.status, "completed"), ne(aiObservations.answerMarkdown, "")))).map((row) => row.promptId);
}
/** Replaces an answer's evidence, so a retried collect step stays idempotent. */
async function persistAnswer(input) {
	await runBatch((tx) => [
		tx.delete(aiSources).where(eq(aiSources.observationId, input.observationId)),
		tx.delete(aiMatches).where(eq(aiMatches.observationId, input.observationId)),
		...t(input.sources, 16).map((rows) => tx.insert(aiSources).values(rows)),
		...t(input.matches, 12).map((rows) => tx.insert(aiMatches).values(rows)),
		tx.update(aiObservations).set(input.values).where(eq(aiObservations.id, input.observationId))
	]);
}
/** Fails the given answers, or every unfinished answer in the run. */
async function failPendingObservations(runId, error, ids) {
	await db.update(aiObservations).set({
		status: "failed",
		error
	}).where(and(eq(aiObservations.runId, runId), eq(aiObservations.status, "pending"), ids ? inArray(aiObservations.id, ids) : void 0));
}
/** Advances a due tracker only if no one else has since, like claimDueConfig. */
async function claimDueTracker(input) {
	return (await db.update(aiTrackers).set(input.values).where(and(eq(aiTrackers.id, input.trackerId), eq(aiTrackers.enabled, true), eq(aiTrackers.nextCheckAt, input.observedNextCheckAt))).returning({ id: aiTrackers.id })).length > 0;
}
var AiVisibilityRepository = {
	listResearchKeywords: async (projectId) => ((await db.select({ keywords: projects.aiResearchKeywords }).from(projects).where(eq(projects.id, projectId)))[0]?.keywords ?? "").split("\n").filter(Boolean),
	getTracker,
	getConfiguration,
	saveConfiguration,
	updateTracker: (id, values) => db.update(aiTrackers).set(values).where(eq(aiTrackers.id, id)),
	claimDueTracker,
	/** Oldest due first; every processed tracker advances its next check. */
	listDue: (now) => db.select({
		tracker: aiTrackers,
		organizationId: projects.organizationId
	}).from(aiTrackers).innerJoin(projects, eq(projects.id, aiTrackers.projectId)).where(and(eq(aiTrackers.enabled, true), lte(aiTrackers.nextCheckAt, now), isNull(projects.archivedAt))).orderBy(asc(aiTrackers.nextCheckAt)).limit(50),
	createRun,
	getRun,
	getRunInternal,
	listRuns,
	getActiveRun,
	getLatestScheduledRun: async (projectId) => (await db.select().from(aiRuns).where(and(eq(aiRuns.projectId, projectId), ne(aiRuns.trigger, "manual"))).orderBy(desc(aiRuns.createdAt), desc(aiRuns.id)).limit(1))[0] ?? null,
	updateRun: (id, values) => db.update(aiRuns).set(values).where(eq(aiRuns.id, id)),
	/**
	* Updates a run only while it is queued or running, and reports whether it
	* did, so a failed run can't be restarted by a workflow that read it first.
	*/
	updateActiveRun: async (id, values) => (await db.update(aiRuns).set(values).where(and(eq(aiRuns.id, id), inArray(aiRuns.status, ACTIVE_RUN_STATUSES))).returning({ id: aiRuns.id })).length > 0,
	getObservations,
	getObservation,
	listAnsweredPromptIds,
	getObservationStatuses: (runIds) => runIds.length ? db.select({
		runId: aiObservations.runId,
		status: aiObservations.status,
		error: aiObservations.error
	}).from(aiObservations).where(inArray(aiObservations.runId, runIds)) : Promise.resolve([]),
	listPendingObservationIds: async (runId) => (await db.select({ id: aiObservations.id }).from(aiObservations).where(and(eq(aiObservations.runId, runId), eq(aiObservations.status, "pending")))).map((row) => row.id),
	listFailedObservationIds: async (runId, error) => (await db.select({ id: aiObservations.id }).from(aiObservations).where(and(eq(aiObservations.runId, runId), eq(aiObservations.status, "failed"), eq(aiObservations.error, error)))).map((row) => row.id),
	getEvidence,
	persistAnswer,
	failPendingObservations,
	getProject: async (projectId) => (await db.select().from(projects).where(eq(projects.id, projectId)).limit(1))[0] ?? null,
	listCompetitors: (projectId) => db.select().from(projectCompetitors).where(eq(projectCompetitors.projectId, projectId))
};
//#endregion
export { writeConfiguration as n, writeResearchKeywords as r, AiVisibilityRepository as t };
