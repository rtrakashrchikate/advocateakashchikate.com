//#region src/shared/serp-location-search.ts
/**
* Region abbreviations users write after a city name, per country. Keyed by
* ISO country so "Rio de Janeiro" in Brazil never reads "de" as Delaware.
*/
var REGION_ABBREVIATIONS = {
	us: {
		al: "Alabama",
		ak: "Alaska",
		az: "Arizona",
		ar: "Arkansas",
		ca: "California",
		co: "Colorado",
		ct: "Connecticut",
		de: "Delaware",
		fl: "Florida",
		ga: "Georgia",
		hi: "Hawaii",
		id: "Idaho",
		il: "Illinois",
		in: "Indiana",
		ia: "Iowa",
		ks: "Kansas",
		ky: "Kentucky",
		la: "Louisiana",
		me: "Maine",
		md: "Maryland",
		ma: "Massachusetts",
		mi: "Michigan",
		mn: "Minnesota",
		ms: "Mississippi",
		mo: "Missouri",
		mt: "Montana",
		ne: "Nebraska",
		nv: "Nevada",
		nh: "New Hampshire",
		nj: "New Jersey",
		nm: "New Mexico",
		ny: "New York",
		nc: "North Carolina",
		nd: "North Dakota",
		oh: "Ohio",
		ok: "Oklahoma",
		or: "Oregon",
		pa: "Pennsylvania",
		ri: "Rhode Island",
		sc: "South Carolina",
		sd: "South Dakota",
		tn: "Tennessee",
		tx: "Texas",
		ut: "Utah",
		vt: "Vermont",
		va: "Virginia",
		wa: "Washington",
		wv: "West Virginia",
		wi: "Wisconsin",
		wy: "Wyoming",
		dc: "District of Columbia"
	},
	ca: {
		ab: "Alberta",
		bc: "British Columbia",
		mb: "Manitoba",
		nb: "New Brunswick",
		nl: "Newfoundland and Labrador",
		ns: "Nova Scotia",
		nt: "Northwest Territories",
		nu: "Nunavut",
		on: "Ontario",
		pe: "Prince Edward Island",
		qc: "Quebec",
		sk: "Saskatchewan",
		yt: "Yukon"
	},
	au: {
		nsw: "New South Wales",
		vic: "Victoria",
		qld: "Queensland",
		sa: "South Australia",
		tas: "Tasmania",
		act: "Australian Capital Territory"
	}
};
/**
* Registry rows a user could plausibly mean by a place name, most specific
* first. Postal codes, airports and universities are absent on purpose: they
* are never what "City, ST" means.
*/
var LOCATION_TYPE_RANK = {
	City: 0,
	Municipality: 1,
	"City Region": 2,
	Borough: 2,
	County: 3,
	State: 4,
	Province: 4,
	Region: 4,
	Country: 5,
	"DMA Region": 6,
	Neighborhood: 7,
	District: 7
};
/** Lowercase, strip accents, collapse whitespace. */
function foldLocationText(value) {
	return value.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase().replace(/\s+/g, " ").trim();
}
/**
* "Portland OR" \u2192 ["portland", "oregon"]. Abbreviations expand only for the
* given country and never on the first token: "La Crosse" and "De Pere" are
* place names, not states.
*/
function tokenize(query, countryCode) {
	const tokens = foldLocationText(query).split(/[\s,]+/).filter(Boolean);
	const abbreviations = REGION_ABBREVIATIONS[countryCode?.toLowerCase() ?? ""];
	if (!abbreviations) return tokens;
	return tokens.map((token, index) => {
		const region = index > 0 ? abbreviations[token] : void 0;
		return region ? foldLocationText(region) : token;
	});
}
function rankSerpLocations(query, locations, countryCode) {
	const tokens = tokenize(query, countryCode);
	if (tokens.length === 0) return [];
	const phrase = tokens.join(" ");
	const head = tokens[0];
	const scored = [];
	for (const location of locations) {
		const folded = foldLocationText(location.locationName);
		if (!tokens.every((token) => folded.includes(token))) continue;
		const comma = folded.indexOf(",");
		const place = comma < 0 ? folded : folded.slice(0, comma).trim();
		const score = place === phrase ? 0 : place === head ? 1 : place.startsWith(head) ? 2 : 3;
		scored.push({
			location,
			score,
			folded
		});
	}
	scored.sort((a, b) => a.score - b.score || (LOCATION_TYPE_RANK[a.location.locationType] ?? 9) - (LOCATION_TYPE_RANK[b.location.locationType] ?? 9) || (a.folded < b.folded ? -1 : a.folded > b.folded ? 1 : 0));
	return scored.slice(0, 50).map((entry) => entry.location);
}
//#endregion
export { rankSerpLocations as t };
