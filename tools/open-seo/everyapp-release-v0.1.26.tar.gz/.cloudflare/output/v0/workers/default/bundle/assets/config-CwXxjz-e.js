import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { r as hasDataforseoAccess } from "./provider-access-Db4kVS7r.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/serverFunctions/config.ts?tss-serverfn-split
var getSeoApiKeyStatus_createServerFn_handler = createServerRpc({
	id: "b5858986f4b26fbc7f2cea62479e3b4d97d5c4af0a61b218af88501443a3939c",
	name: "getSeoApiKeyStatus",
	filename: "src/serverFunctions/config.ts"
}, (opts) => getSeoApiKeyStatus.__executeServer(opts));
var getSeoApiKeyStatus = createServerFn({ method: "GET" }).middleware(requireAuthenticatedContext).handler(getSeoApiKeyStatus_createServerFn_handler, async () => {
	return { configured: await hasDataforseoAccess() };
});
//#endregion
export { getSeoApiKeyStatus_createServerFn_handler };
