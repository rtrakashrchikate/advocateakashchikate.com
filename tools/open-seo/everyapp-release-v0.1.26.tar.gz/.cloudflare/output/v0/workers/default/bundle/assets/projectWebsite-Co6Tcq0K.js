import { Fn as object, Jn as string, Lt as boolean, Nt as array } from "./schemas-BPIpYT5n.js";
import { i as suggestedAiTopicSchema } from "./aiPromptSuggestions-C0K_PsL0.js";
import { a as PROSE_MAX_CHARS } from "./projectContext--4-tA_3n.js";
//#region src/types/schemas/projectWebsite.ts
var domain = string().trim().min(1).max(255);
var WEBSITE_UNREADABLE_MESSAGE = "We couldn't read this website. Check the URL and try again.";
var researchKeywordSchema = string().trim().min(1).max(100).regex(/^\S+(?:\s+\S+){0,4}$/, "Keywords must contain five words or fewer.");
var websiteCompetitorSchema = object({
	name: string().trim().min(1).max(120),
	domain,
	notes: string().trim().min(1).max(500),
	sourceUrl: string().url()
});
var websiteResearchSchema = object({
	name: string().trim().min(1).max(120),
	domain,
	overview: string().trim().min(1).max(PROSE_MAX_CHARS),
	competitors: array(websiteCompetitorSchema).max(5),
	preserveCompetitors: boolean(),
	suggestedTopics: array(suggestedAiTopicSchema).max(5),
	suggestedKeywords: array(researchKeywordSchema).max(15)
});
var researchProjectWebsiteSchema = object({
	projectId: string().uuid(),
	website: string().trim().min(1).max(2e3)
});
var saveProjectWebsiteSetupSchema = websiteResearchSchema.omit({
	suggestedTopics: true,
	suggestedKeywords: true,
	preserveCompetitors: true
}).extend({
	projectId: string().uuid(),
	suggestedTopics: array(suggestedAiTopicSchema).max(5).optional(),
	suggestedKeywords: websiteResearchSchema.shape.suggestedKeywords.optional(),
	competitors: array(websiteCompetitorSchema.omit({ sourceUrl: true }).extend({ notes: string().trim().max(500).default("") })).max(100)
});
//#endregion
export { websiteResearchSchema as i, researchProjectWebsiteSchema as n, saveProjectWebsiteSetupSchema as r, WEBSITE_UNREADABLE_MESSAGE as t };
