import { a as __toESM, t as __commonJSMin } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { V as clsx } from "./button-DrcZrdio.js";
import { Gt as roundTemplateLiteral, It as Symbols, Kt as Layer, Nt as resolveDefaultProps, Rt as interpolate, at as Curve, et as Sector, it as getTransitionVal, nt as useAnimationId, qt as svgPropertiesAndEvents, rt as JavascriptAnimate, tt as Rectangle } from "./chart-DyiPV1Ml.js";
//#region node_modules/.pnpm/es-toolkit@1.44.0/node_modules/es-toolkit/dist/compat/predicate/isPlainObject.js
var require_isPlainObject$1 = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
	function isPlainObject(object) {
		if (typeof object !== "object") return false;
		if (object == null) return false;
		if (Object.getPrototypeOf(object) === null) return true;
		if (Object.prototype.toString.call(object) !== "[object Object]") {
			const tag = object[Symbol.toStringTag];
			if (tag == null) return false;
			if (!Object.getOwnPropertyDescriptor(object, Symbol.toStringTag)?.writable) return false;
			return object.toString() === `[object ${tag}]`;
		}
		let proto = object;
		while (Object.getPrototypeOf(proto) !== null) proto = Object.getPrototypeOf(proto);
		return Object.getPrototypeOf(object) === proto;
	}
	exports.isPlainObject = isPlainObject;
}));
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/shape/Trapezoid.js
var import_isPlainObject = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_isPlainObject$1().isPlainObject;
})))());
var import_react = /* @__PURE__ */ __toESM(require_react());
var _templateObject;
var _templateObject2;
var _templateObject3;
var _templateObject4;
var _templateObject5;
function ownKeys$1(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$1(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$1(Object(t), !0).forEach(function(r) {
			_defineProperty$1(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$1(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$1(e, r, t) {
	return (r = _toPropertyKey$1(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey$1(t) {
	var i = _toPrimitive$1(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive$1(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _extends() {
	return _extends = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends.apply(null, arguments);
}
function _taggedTemplateLiteral(e, t) {
	return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, { raw: { value: Object.freeze(t) } }));
}
var getTrapezoidPath = (x, y, upperWidth, lowerWidth, height) => {
	var widthGap = upperWidth - lowerWidth;
	var path = roundTemplateLiteral(_templateObject || (_templateObject = _taggedTemplateLiteral([
		"M ",
		",",
		""
	])), x, y);
	path += roundTemplateLiteral(_templateObject2 || (_templateObject2 = _taggedTemplateLiteral([
		"L ",
		",",
		""
	])), x + upperWidth, y);
	path += roundTemplateLiteral(_templateObject3 || (_templateObject3 = _taggedTemplateLiteral([
		"L ",
		",",
		""
	])), x + upperWidth - widthGap / 2, y + height);
	path += roundTemplateLiteral(_templateObject4 || (_templateObject4 = _taggedTemplateLiteral([
		"L ",
		",",
		""
	])), x + upperWidth - widthGap / 2 - lowerWidth, y + height);
	path += roundTemplateLiteral(_templateObject5 || (_templateObject5 = _taggedTemplateLiteral([
		"L ",
		",",
		" Z"
	])), x, y);
	return path;
};
var defaultTrapezoidProps = {
	x: 0,
	y: 0,
	upperWidth: 0,
	lowerWidth: 0,
	height: 0,
	isUpdateAnimationActive: false,
	animationBegin: 0,
	animationDuration: 1500,
	animationEasing: "ease"
};
var Trapezoid = (outsideProps) => {
	var trapezoidProps = resolveDefaultProps(outsideProps, defaultTrapezoidProps);
	var { x, y, upperWidth, lowerWidth, height, className } = trapezoidProps;
	var { animationEasing, animationDuration, animationBegin, isUpdateAnimationActive } = trapezoidProps;
	var pathRef = (0, import_react.useRef)(null);
	var [totalLength, setTotalLength] = (0, import_react.useState)(-1);
	var prevUpperWidthRef = (0, import_react.useRef)(upperWidth);
	var prevLowerWidthRef = (0, import_react.useRef)(lowerWidth);
	var prevHeightRef = (0, import_react.useRef)(height);
	var prevXRef = (0, import_react.useRef)(x);
	var prevYRef = (0, import_react.useRef)(y);
	var animationId = useAnimationId(outsideProps, "trapezoid-");
	(0, import_react.useEffect)(() => {
		if (pathRef.current && pathRef.current.getTotalLength) try {
			var pathTotalLength = pathRef.current.getTotalLength();
			if (pathTotalLength) setTotalLength(pathTotalLength);
		} catch (_unused) {}
	}, []);
	if (x !== +x || y !== +y || upperWidth !== +upperWidth || lowerWidth !== +lowerWidth || height !== +height || upperWidth === 0 && lowerWidth === 0 || height === 0) return null;
	var layerClass = clsx("recharts-trapezoid", className);
	if (!isUpdateAnimationActive) return /*#__PURE__*/ import_react.createElement("g", null, /*#__PURE__*/ import_react.createElement("path", _extends({}, svgPropertiesAndEvents(trapezoidProps), {
		className: layerClass,
		d: getTrapezoidPath(x, y, upperWidth, lowerWidth, height)
	})));
	var prevUpperWidth = prevUpperWidthRef.current;
	var prevLowerWidth = prevLowerWidthRef.current;
	var prevHeight = prevHeightRef.current;
	var prevX = prevXRef.current;
	var prevY = prevYRef.current;
	var from = "0px ".concat(totalLength === -1 ? 1 : totalLength, "px");
	var to = "".concat(totalLength, "px ").concat(totalLength, "px");
	var transition = getTransitionVal(["strokeDasharray"], animationDuration, animationEasing);
	return /*#__PURE__*/ import_react.createElement(JavascriptAnimate, {
		animationId,
		key: animationId,
		canBegin: totalLength > 0,
		duration: animationDuration,
		easing: animationEasing,
		isActive: isUpdateAnimationActive,
		begin: animationBegin
	}, (t) => {
		var currUpperWidth = interpolate(prevUpperWidth, upperWidth, t);
		var currLowerWidth = interpolate(prevLowerWidth, lowerWidth, t);
		var currHeight = interpolate(prevHeight, height, t);
		var currX = interpolate(prevX, x, t);
		var currY = interpolate(prevY, y, t);
		if (pathRef.current) {
			prevUpperWidthRef.current = currUpperWidth;
			prevLowerWidthRef.current = currLowerWidth;
			prevHeightRef.current = currHeight;
			prevXRef.current = currX;
			prevYRef.current = currY;
		}
		var animationStyle = t > 0 ? {
			transition,
			strokeDasharray: to
		} : { strokeDasharray: from };
		return /*#__PURE__*/ import_react.createElement("path", _extends({}, svgPropertiesAndEvents(trapezoidProps), {
			className: layerClass,
			d: getTrapezoidPath(currX, currY, currUpperWidth, currLowerWidth, currHeight),
			ref: pathRef,
			style: _objectSpread$1(_objectSpread$1({}, animationStyle), trapezoidProps.style)
		}));
	});
};
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/util/ActiveShapeUtils.js
var _excluded$1 = [
	"option",
	"shapeType",
	"activeClassName",
	"inActiveClassName"
];
function _objectWithoutProperties$1(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose$1(e, t);
	if (Object.getOwnPropertySymbols) {
		var n = Object.getOwnPropertySymbols(e);
		for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
function _objectWithoutPropertiesLoose$1(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty(e, r, t) {
	return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
/**
* This is an abstraction for rendering a user defined prop for a customized shape in several forms.
*
* <Shape /> is the root and will handle taking in:
*  - an object of svg properties
*  - a boolean
*  - a render prop(inline function that returns jsx)
*  - a React element
*
* <ShapeSelector /> is a subcomponent of <Shape /> and used to match a component
* to the value of props.shapeType that is passed to the root.
*
*/
function defaultPropTransformer(option, props) {
	return _objectSpread(_objectSpread({}, props), option);
}
function isSymbolsProps(shapeType, _elementProps) {
	return shapeType === "symbols";
}
function ShapeSelector(_ref) {
	var { shapeType, elementProps } = _ref;
	switch (shapeType) {
		case "rectangle": return /*#__PURE__*/ import_react.createElement(Rectangle, elementProps);
		case "trapezoid": return /*#__PURE__*/ import_react.createElement(Trapezoid, elementProps);
		case "sector": return /*#__PURE__*/ import_react.createElement(Sector, elementProps);
		case "symbols":
			if (isSymbolsProps(shapeType, elementProps)) return /*#__PURE__*/ import_react.createElement(Symbols, elementProps);
			break;
		case "curve": return /*#__PURE__*/ import_react.createElement(Curve, elementProps);
		default: return null;
	}
}
function getPropsFromShapeOption(option) {
	if (/*#__PURE__*/ (0, import_react.isValidElement)(option)) return option.props;
	return option;
}
function Shape(_ref2) {
	var { option, shapeType, activeClassName = "recharts-active-shape", inActiveClassName = "recharts-shape" } = _ref2, props = _objectWithoutProperties$1(_ref2, _excluded$1);
	var shape;
	if (/*#__PURE__*/ (0, import_react.isValidElement)(option)) shape = /*#__PURE__*/ (0, import_react.cloneElement)(option, _objectSpread(_objectSpread({}, props), getPropsFromShapeOption(option)));
	else if (typeof option === "function") shape = option(props, props.index);
	else if ((0, import_isPlainObject.default)(option) && typeof option !== "boolean") {
		var nextProps = defaultPropTransformer(option, props);
		shape = /*#__PURE__*/ import_react.createElement(ShapeSelector, {
			shapeType,
			elementProps: nextProps
		});
	} else {
		var elementProps = props;
		shape = /*#__PURE__*/ import_react.createElement(ShapeSelector, {
			shapeType,
			elementProps
		});
	}
	if (props.isActive) return /*#__PURE__*/ import_react.createElement(Layer, { className: activeClassName }, shape);
	return /*#__PURE__*/ import_react.createElement(Layer, { className: inActiveClassName }, shape);
}
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/context/ErrorBarContext.js
var _excluded = ["children"];
function _objectWithoutProperties(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose(e, t);
	if (Object.getOwnPropertySymbols) {
		var n = Object.getOwnPropertySymbols(e);
		for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
function _objectWithoutPropertiesLoose(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
var ErrorBarContext = /*#__PURE__*/ (0, import_react.createContext)({
	data: [],
	xAxisId: "xAxis-0",
	yAxisId: "yAxis-0",
	dataPointFormatter: () => ({
		x: 0,
		y: 0,
		value: 0
	}),
	errorBarOffset: 0
});
function SetErrorBarContext(props) {
	var { children } = props, rest = _objectWithoutProperties(props, _excluded);
	return /*#__PURE__*/ import_react.createElement(ErrorBarContext.Provider, { value: rest }, children);
}
//#endregion
export { Shape as n, SetErrorBarContext as t };
