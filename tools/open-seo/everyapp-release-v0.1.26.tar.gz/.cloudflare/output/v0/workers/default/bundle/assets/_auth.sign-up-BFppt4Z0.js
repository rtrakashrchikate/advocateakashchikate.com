import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
import { c as getVerifyEmailSearch, d as toAuthCallbackURL, s as getSignInSearch } from "./auth-redirect-Dnh6pyWf.js";
import { t as authClient } from "./auth-client-DstRenkx.js";
import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { t as Button } from "./button-DrcZrdio.js";
import { n as captureClientEvent } from "./posthog-BMFJOGWd.js";
import { a as authInputClassName, c as useAuthPageState, i as TermsAgreementNotice, n as AuthPageCard, s as authSubmitClassName, t as AuthMethodChooser } from "./AuthPage-Bxu7AMPh.js";
import { t as Route } from "./_auth.sign-up-CGhiZeKi.js";
import { t as PageLoading } from "./Spinner-NR-t-8YM.js";
import { t as useAppForm } from "./useAppForm-DjX0VDRv.js";
import { r as getFormError } from "./forms-t3Wjw9fZ.js";
import { n as signUpStatusQueryOptions, t as useGoogleAuth } from "./useGoogleAuth-CrBbDIVC.js";
import { n as useTurnstileCaptcha, t as TurnstileWidget } from "./TurnstileWidget-bl7Vnlz9.js";
import { t as passwordSchema } from "./passwordSchema-DUYZJwlE.js";
//#region src/routes/_auth.sign-up.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var UTM_PARAMS = [
	"utm_source",
	"utm_medium",
	"utm_campaign",
	"utm_content"
];
var signUpSchema = object({
	email: string().trim().email("Enter a valid email address."),
	password: passwordSchema,
	confirmPassword: string()
}).refine((value) => value.password === value.confirmPassword, {
	message: "Passwords do not match.",
	path: ["confirmPassword"]
});
function SignUpPage() {
	const search = Route.useSearch();
	const navigate = useNavigate();
	const { redirectTo, isHostedMode, isBetterAuthMode } = useAuthPageState(search.redirect);
	const onboardingSearch = new URLSearchParams();
	if (search.domain) onboardingSearch.set("domain", search.domain);
	for (const name of UTM_PARAMS) {
		const value = search[name];
		if (value) onboardingSearch.set(name, value);
	}
	const postSignupRedirect = redirectTo !== "/" ? redirectTo : onboardingSearch.size > 0 ? `/onboarding?${onboardingSearch.toString()}` : "/onboarding";
	const [showEmailForm, setShowEmailForm] = (0, import_react.useState)(search.method === "email");
	const google = useGoogleAuth({
		redirectTo,
		postSignupRedirect
	});
	const startedGoogle = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (search.method !== "google" || !isHostedMode || startedGoogle.current) return;
		startedGoogle.current = true;
		navigate({
			to: "/sign-up",
			search: {
				...search,
				method: void 0
			},
			replace: true
		});
		google.start();
	}, [
		google,
		isHostedMode,
		navigate,
		search
	]);
	const standalone = isBetterAuthMode && !isHostedMode;
	const invited = redirectTo.startsWith("/accept-invitation/");
	const signUpStatus = useQuery({
		...signUpStatusQueryOptions(),
		enabled: standalone
	});
	const firstAccount = signUpStatus.data?.firstAccount === true;
	const emailFormVisible = showEmailForm || standalone;
	const isTurnstileEnabled = isHostedMode && Boolean(void 0);
	const captcha = useTurnstileCaptcha();
	const form = useAppForm({
		defaultValues: {
			email: "",
			password: "",
			confirmPassword: ""
		},
		validators: { onSubmit: signUpSchema },
		onSubmit: async ({ formApi, value }) => {
			const captchaToken = captcha.tokenRef.current;
			try {
				const email = value.email.trim();
				captureClientEvent("auth:sign_up_submit", { redirect_to: redirectTo });
				const verificationCallbackURL = new URL("/verify-email", window.location.origin);
				const verificationSearch = getVerifyEmailSearch(void 0, postSignupRedirect);
				if (verificationSearch.redirect) verificationCallbackURL.searchParams.set("redirect", verificationSearch.redirect);
				const result = await authClient.signUp.email({
					name: email.split("@")[0] || "OpenSEO User",
					email,
					password: value.password,
					callbackURL: verificationCallbackURL.toString(),
					...isTurnstileEnabled && captchaToken ? { fetchOptions: { headers: { "x-captcha-response": captchaToken } } } : {}
				});
				if (result.error) {
					if (isTurnstileEnabled) captcha.reset();
					formApi.setErrorMap({ onSubmit: {
						form: result.error.message || "Unable to create account.",
						fields: {}
					} });
					return;
				}
				captureClientEvent("auth:sign_up_success", { redirect_to: redirectTo });
				if (standalone) {
					const signedIn = await authClient.signIn.email({
						email,
						password: value.password,
						callbackURL: toAuthCallbackURL(redirectTo)
					});
					if (signedIn.error) formApi.setErrorMap({ onSubmit: {
						form: signedIn.error.message || "Account created. Sign in to continue.",
						fields: {}
					} });
					return;
				}
				navigate({
					to: "/verify-email",
					search: getVerifyEmailSearch(email, postSignupRedirect),
					replace: true
				});
			} catch {
				if (isTurnstileEnabled) captcha.reset();
				formApi.setErrorMap({ onSubmit: {
					form: "Unable to create account right now. Please try again.",
					fields: {}
				} });
			}
		}
	});
	if (standalone && !firstAccount && !invited) {
		if (signUpStatus.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageLoading, {});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPageCard, {
			title: "Registration is closed",
			helperText: "Ask an administrator for an invitation.",
			footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/sign-in",
					search: getSignInSearch(redirectTo),
					className: "text-muted-foreground hover:text-foreground transition-colors",
					children: "Back to sign in"
				})
			}),
			children: null
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPageCard, {
		title: firstAccount ? "Create the admin account" : "Create your account",
		helperText: firstAccount ? "This installation has no accounts yet. The first one becomes the administrator." : invited ? "Use the email address that received the invitation." : void 0,
		footer: standalone ? firstAccount ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm text-foreground/50",
			children: [
				"Already have an account?",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/sign-in",
					search: getSignInSearch(redirectTo),
					className: "text-foreground underline underline-offset-2 hover:text-foreground/80 transition-colors",
					children: "Sign in"
				})
			]
		}) : isHostedMode ? showEmailForm ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "text-sm text-foreground underline underline-offset-2 hover:text-foreground/80 transition-colors",
			onClick: () => {
				setShowEmailForm(false);
				google.clearError();
			},
			children: "Back to signup"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-foreground/50",
				children: [
					"Already have an account?",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/sign-in",
						search: getSignInSearch(redirectTo),
						className: "text-foreground underline underline-offset-2 hover:text-foreground/80 transition-colors",
						children: "Sign in"
					})
				]
			})
		}) : null,
		children: !emailFormVisible ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthMethodChooser, {
				googleLabel: "Continue with Google",
				disabled: !isHostedMode,
				isBusy: google.isStarting,
				onContinueWithGoogle: () => {
					google.start();
				},
				onContinueWithEmail: () => {
					setShowEmailForm(true);
					google.clearError();
				}
			}),
			isHostedMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TermsAgreementNotice, { action: "By continuing" }) : null,
			google.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-destructive",
				children: google.error
			}) : null
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.AppForm, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(form.Form, {
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.AppField, {
					name: "email",
					children: (field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(field.TextField, {
						label: "Email address",
						hideLabel: true,
						className: authInputClassName,
						type: "email",
						placeholder: "Email address...",
						autoComplete: "email",
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.AppField, {
					name: "password",
					children: (field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(field.TextField, {
						label: "Password",
						hideLabel: true,
						className: authInputClassName,
						type: "password",
						placeholder: "Password...",
						autoComplete: "new-password",
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.AppField, {
					name: "confirmPassword",
					children: (field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(field.TextField, {
						label: "Confirm password",
						hideLabel: true,
						className: authInputClassName,
						type: "password",
						placeholder: "Confirm password...",
						autoComplete: "new-password",
						required: true
					})
				}),
				isTurnstileEnabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TurnstileWidget, {
					onToken: captcha.onToken,
					resetNonce: captcha.resetNonce
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.Subscribe, {
					selector: (state) => ({
						submitError: state.errorMap.onSubmit,
						isSubmitting: state.isSubmitting
					}),
					children: ({ submitError, isSubmitting }) => {
						const errorMessage = getFormError(submitError);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							errorMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-destructive",
								children: errorMessage
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: "secondary",
								className: authSubmitClassName,
								pending: isSubmitting,
								disabled: isTurnstileEnabled && !captcha.hasToken,
								children: isSubmitting ? "Creating account..." : "Create account"
							}),
							isHostedMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TermsAgreementNotice, { action: "By creating an account" }) : null
						] });
					}
				})
			]
		}) })
	});
}
//#endregion
export { SignUpPage as component };
