import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { n as getRequest } from "./server-DEvo1k0f.js";
import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
import { U as AppError } from "./onboarding-drip-B7bIbv_6.js";
import { o as isHostedServerAuthMode } from "./runtime-env-eoXh4Ywz.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
import { AccountDeletionService } from "./AccountDeletionService-B5XgnzBr.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/serverFunctions/account-deletion.ts?tss-serverfn-split
async function requireHosted() {
	if (!await isHostedServerAuthMode()) throw new AppError("NOT_FOUND");
}
var getAccountDeletionStatus_createServerFn_handler = createServerRpc({
	id: "1166d95317aec17ef180de12f84493aa962df45035a16135f0a4ed81f7b8a834",
	name: "getAccountDeletionStatus",
	filename: "src/serverFunctions/account-deletion.ts"
}, (opts) => getAccountDeletionStatus.__executeServer(opts));
var getAccountDeletionStatus = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).handler(getAccountDeletionStatus_createServerFn_handler, async ({ context }) => {
	await requireHosted();
	return AccountDeletionService.getStatus({
		userId: context.userId,
		headers: getRequest().headers
	});
});
var requestAccountDeletion_createServerFn_handler = createServerRpc({
	id: "18dd16e01eb78552f527d11670fb1a36f78c7b1e6c94df5e63902f0ec18e649c",
	name: "requestAccountDeletion",
	filename: "src/serverFunctions/account-deletion.ts"
}, (opts) => requestAccountDeletion.__executeServer(opts));
var requestAccountDeletion = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(object({ confirmEmail: string().max(320) })).handler(requestAccountDeletion_createServerFn_handler, async ({ data, context }) => {
	await requireHosted();
	return AccountDeletionService.requestDeletion({
		userId: context.userId,
		userEmail: context.userEmail,
		confirmEmail: data.confirmEmail,
		headers: getRequest().headers
	});
});
//#endregion
export { getAccountDeletionStatus_createServerFn_handler, requestAccountDeletion_createServerFn_handler };
