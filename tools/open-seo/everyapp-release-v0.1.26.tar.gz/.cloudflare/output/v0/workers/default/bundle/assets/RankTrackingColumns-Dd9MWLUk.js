import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { o as formatLocationLabel } from "./keyword-locations-4GfvBtRY.js";
import { n as isGoogleRedirect } from "./google-serp-url-uC4XmGTB.js";
import { t as SortableHeader } from "./SortableHeader-DDZ6s-pV.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as Sparkles } from "./sparkles-BtdH_814.js";
import { t as Star } from "./star-BlVSEAbs.js";
import { n as captureClientEvent } from "./posthog-BMFJOGWd.js";
import { t as Badge } from "./badge-B9fV075d.js";
import { n as TooltipContent, r as TooltipTrigger, t as Tooltip } from "./tooltip-D5ss-ZNP.js";
import { n as makeSelectionColumn } from "./DataTable-CF1_e923.js";
import { t as formatExportTimestamp } from "./db-timestamp-D5yyHS4V.js";
import { t as exportRows } from "./exportRows-CUVUVoFx.js";
import { t as ScoreBadge } from "./ScoreBadge-_VY6qR99.js";
//#region src/client/features/rank-tracking/RankTrackingTableParts.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var FEATURE_SHORT_LABELS = {
	featured_snippet: "FS",
	people_also_ask: "PAA",
	ai_overview: "AI",
	local_pack: "Local",
	knowledge_panel: "KP",
	video: "Video",
	images: "Img",
	shopping: "Shop",
	top_stories: "News"
};
var FEATURE_TOOLTIPS = {
	featured_snippet: "Featured Snippet \u2014 highlighted answer box at top of results",
	people_also_ask: "People Also Ask \u2014 expandable related questions",
	ai_overview: "AI Overview \u2014 AI-generated summary at top of search",
	local_pack: "Local Pack \u2014 map with local business listings",
	knowledge_panel: "Knowledge Panel \u2014 info box about an entity",
	video: "Video \u2014 video results shown in the SERP",
	images: "Images \u2014 image results shown in the SERP",
	shopping: "Shopping \u2014 product listings with prices",
	top_stories: "Top Stories \u2014 news articles carousel"
};
function SerpFeatureTags({ features }) {
	const notable = features.filter((f) => f in FEATURE_SHORT_LABELS);
	if (notable.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1 flex-wrap",
		children: notable.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
			variant: "secondary",
			size: "sm",
			className: "cursor-help",
			title: FEATURE_TOOLTIPS[f] ?? f,
			children: [f === "ai_overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), FEATURE_SHORT_LABELS[f]]
		}, f))
	});
}
function DeviceRankCell({ result }) {
	const { position, previousPosition } = result;
	if (position === null && previousPosition === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-muted-foreground",
		children: "-"
	});
	if (position === null && previousPosition !== null) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-6 text-right font-mono text-xs text-muted-foreground",
				children: previousPosition
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground/60",
				children: "\u2192"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-mono rounded px-1.5 py-0.5 text-xs font-semibold bg-destructive/15 text-destructive",
				children: "lost"
			})
		]
	});
	if (previousPosition === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-mono",
		children: position
	});
	const change = previousPosition - position;
	let badgeClass = "bg-muted text-foreground";
	if (change > 0) badgeClass = "bg-success/20 text-success";
	if (change < 0) badgeClass = "bg-warning/20 text-warning";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-1.5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-6 text-right font-mono text-xs text-muted-foreground",
				children: previousPosition
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-muted-foreground/60",
				children: "\u2192"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `font-mono rounded px-1.5 py-0.5 text-xs font-semibold ${badgeClass}`,
				children: position
			})
		]
	});
}
function DeviceUrlCell({ result, domain }) {
	if (!result.rankingUrl) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-xs text-muted-foreground",
		children: "-"
	});
	const href = toFullUrl(result.rankingUrl, domain);
	if (isGoogleRedirect(result.rankingUrl)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href,
			target: "_blank",
			rel: "noopener noreferrer",
			className: "block w-fit text-xs underline"
		}),
		children: "View page"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: "Google hid this page's address." })] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href,
		target: "_blank",
		rel: "noopener noreferrer",
		className: "block truncate text-xs hover:underline",
		title: result.rankingUrl,
		children: toPath(result.rankingUrl)
	});
}
var compactFormatter = new Intl.NumberFormat("en-US", {
	notation: "compact",
	maximumFractionDigits: 1
});
function VolumeCell({ value }) {
	if (value == null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-muted-foreground",
		children: "-"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "font-mono text-sm",
		children: compactFormatter.format(value)
	});
}
function CpcCell({ value }) {
	if (value == null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-muted-foreground",
		children: "-"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "font-mono text-sm",
		children: ["$", value.toFixed(2)]
	});
}
/** Numeric change for CSV export \u2014 numbers bypass the CSV formula-injection sanitizer */
function csvChange(current, previous) {
	if (previous === null) return current !== null ? "new" : "";
	if (current === null) return "lost";
	return previous - current;
}
function buildRankTrackingExport(sorted, showDesktop, showMobile, locationName) {
	return {
		headers: [
			"Keyword",
			locationName ? `Local volume (${formatLocationLabel(locationName, 2)})` : "Volume",
			"KD",
			"CPC",
			...showDesktop ? [
				"Desktop Position",
				"Desktop Change",
				"Desktop URL",
				"Desktop SERP Features",
				"Desktop Checked At (UTC)"
			] : [],
			...showMobile ? [
				"Mobile Position",
				"Mobile Change",
				"Mobile URL",
				"Mobile SERP Features",
				"Mobile Checked At (UTC)"
			] : []
		],
		rows: sorted.map((row) => [
			row.keyword,
			row.searchVolume ?? "",
			row.keywordDifficulty ?? "",
			row.cpc ?? "",
			...showDesktop ? [
				row.desktop.position ?? "",
				csvChange(row.desktop.position, row.desktop.previousPosition),
				row.desktop.rankingUrl ?? "",
				row.desktop.serpFeatures.join(", "),
				row.desktop.checkedAt ? formatExportTimestamp(row.desktop.checkedAt) : ""
			] : [],
			...showMobile ? [
				row.mobile.position ?? "",
				csvChange(row.mobile.position, row.mobile.previousPosition),
				row.mobile.rankingUrl ?? "",
				row.mobile.serpFeatures.join(", "),
				row.mobile.checkedAt ? formatExportTimestamp(row.mobile.checkedAt) : ""
			] : []
		])
	};
}
function exportRankTracking(args) {
	const { format, scope } = args;
	const { headers, rows } = buildRankTrackingExport(args.rows, args.showDesktop, args.showMobile, args.locationName);
	const exportedRows = format === "csv" ? rows.map((row) => row.map((cell, idx) => idx === 3 && typeof cell === "number" ? cell.toFixed(2) : cell)) : rows;
	exportRows({
		format,
		feature: "rank_tracking",
		headers,
		rows: exportedRows,
		filename: `rank-tracking-${args.domain}${scope ? "-selected" : ""}`,
		scope
	});
	if (format === "csv" && rows.length > 0) captureClientEvent("rank_tracking:export_csv", scope ? { scope } : {});
}
function toPath(url) {
	try {
		return new URL(url).pathname;
	} catch {
		return url;
	}
}
function toFullUrl(url, domain) {
	if (url.startsWith("http")) return url;
	return `https://${domain}${url}`;
}
//#endregion
//#region src/client/features/rank-tracking/RankTrackingColumns.tsx
var RANK_TRACKING_HEADER_CLASS = "text-xs uppercase tracking-wide text-muted-foreground";
var HEADER_TOOLTIPS = {
	keyword: "The search term being tracked in Google",
	volume: "Estimated monthly search volume from Google",
	kd: "Keyword difficulty score (0-100) \u2014 higher means harder to rank",
	cpc: "Average cost per click in Google Ads (USD)",
	desktopPosition: "Current Google ranking position, showing change from the comparison period",
	mobilePosition: "Current Google ranking position, showing change from the comparison period",
	url: "The page on your site that ranks for this keyword",
	serp: "Special result features appearing on the search results page (e.g. AI Overview, People Also Ask)"
};
function makeVolumeColumn(locationLabel) {
	return {
		id: "volume",
		accessorFn: (row) => row.searchVolume ?? void 0,
		header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
			column,
			label: locationLabel ? "Local volume" : "Volume",
			title: locationLabel ? `Estimated monthly searches in ${locationLabel} from Google Ads` : HEADER_TOOLTIPS.volume,
			className: RANK_TRACKING_HEADER_CLASS
		}),
		size: 90,
		cell: ({ getValue }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeCell, { value: getValue() ?? null }),
		sortUndefined: "last"
	};
}
var kdColumn = {
	id: "kd",
	accessorFn: (row) => row.keywordDifficulty ?? void 0,
	header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
		column,
		label: "KD",
		title: HEADER_TOOLTIPS.kd,
		className: RANK_TRACKING_HEADER_CLASS
	}),
	size: 70,
	cell: ({ getValue }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreBadge, { value: getValue() ?? null }),
	sortUndefined: "last"
};
var cpcColumn = {
	id: "cpc",
	accessorFn: (row) => row.cpc ?? void 0,
	header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
		column,
		label: "CPC",
		title: HEADER_TOOLTIPS.cpc,
		className: RANK_TRACKING_HEADER_CLASS
	}),
	size: 80,
	cell: ({ getValue }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CpcCell, { value: getValue() ?? null }),
	sortUndefined: "last"
};
var PINNED_COLUMN_ID = "pinned";
var pinnedColumn = {
	id: PINNED_COLUMN_ID,
	accessorFn: (row) => row.pinned ? 0 : 1
};
function makeKeywordColumn(onKeywordClick, onSetPinned) {
	return {
		id: "keyword",
		accessorKey: "keyword",
		header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
			column,
			label: "Keyword",
			title: HEADER_TOOLTIPS.keyword,
			className: RANK_TRACKING_HEADER_CLASS
		}),
		cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-1.5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PinButton, {
					pinned: row.original.pinned,
					onClick: () => onSetPinned({
						trackingKeywordId: row.original.trackingKeywordId,
						pinned: !row.original.pinned
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "text-left font-medium decoration-dotted underline-offset-2 hover:underline",
					onClick: () => onKeywordClick(row.original),
					title: "View position history",
					children: row.original.keyword
				}),
				row.original.matchCase && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "secondary",
					size: "sm",
					className: "cursor-help",
					title: "Tracked exactly as typed, not lowercased",
					children: "Aa"
				})
			]
		}),
		sortingFn: "alphanumeric"
	};
}
function PinButton({ pinned, onClick }) {
	const label = pinned ? "Unpin keyword" : "Pin keyword to top";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "ghost",
		size: "icon-xs",
		onClick,
		"aria-label": label,
		"aria-pressed": pinned,
		title: label,
		className: pinned ? "text-amber-500 hover:text-amber-600" : "text-muted-foreground",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: pinned ? "fill-current" : void 0 })
	});
}
function makeDeviceColumn(device) {
	const id = device === "desktop" ? "desktopPosition" : "mobilePosition";
	return {
		id,
		accessorFn: (row) => row[device].position ?? void 0,
		header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
			column,
			label: "Position",
			title: HEADER_TOOLTIPS[id],
			className: RANK_TRACKING_HEADER_CLASS
		}),
		size: 120,
		maxSize: 140,
		cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceRankCell, { result: row.original[device] }),
		sortUndefined: "last"
	};
}
function makeUrlColumn(device, domain) {
	return {
		id: device === "desktop" ? "desktopUrl" : "mobileUrl",
		enableSorting: false,
		header: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "cursor-help text-xs font-medium tracking-wide uppercase text-muted-foreground",
			title: HEADER_TOOLTIPS.url,
			children: "URL"
		}),
		size: 240,
		cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeviceUrlCell, {
			result: row.original[device],
			domain
		})
	};
}
function makeSerpColumn(device) {
	return {
		id: device === "desktop" ? "desktopSerp" : "mobileSerp",
		enableSorting: false,
		header: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "cursor-help text-xs font-medium tracking-wide uppercase text-muted-foreground",
			title: HEADER_TOOLTIPS.serp,
			children: "SERP Features"
		}),
		cell: ({ row }) => {
			const features = row.original[device].serpFeatures;
			if (features.length === 0) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SerpFeatureTags, { features });
		}
	};
}
function useRankTrackingColumns(options) {
	const { showDesktop, showMobile, domain, selectAnchorRef, onKeywordClick, onSetPinned, locationName } = options;
	const locationLabel = locationName ? formatLocationLabel(locationName, 2) : void 0;
	return (0, import_react.useMemo)(() => {
		const cols = [
			pinnedColumn,
			makeSelectionColumn(selectAnchorRef),
			makeKeywordColumn(onKeywordClick, onSetPinned)
		];
		if (showDesktop) {
			cols.push(makeDeviceColumn("desktop"));
			cols.push(makeUrlColumn("desktop", domain));
		}
		if (showMobile) {
			cols.push(makeDeviceColumn("mobile"));
			cols.push(makeUrlColumn("mobile", domain));
		}
		cols.push(makeVolumeColumn(locationLabel), kdColumn, cpcColumn);
		if (showDesktop) cols.push(makeSerpColumn("desktop"));
		if (showMobile) cols.push(makeSerpColumn("mobile"));
		return cols;
	}, [
		showDesktop,
		showMobile,
		domain,
		selectAnchorRef,
		onKeywordClick,
		onSetPinned,
		locationLabel
	]);
}
//#endregion
export { csvChange as a, DeviceRankCell as i, RANK_TRACKING_HEADER_CLASS as n, exportRankTracking as o, useRankTrackingColumns as r, PINNED_COLUMN_ID as t };
