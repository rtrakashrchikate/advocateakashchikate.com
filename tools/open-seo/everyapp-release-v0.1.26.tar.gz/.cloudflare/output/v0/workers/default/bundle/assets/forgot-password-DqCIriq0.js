import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
import { c as isHostedClientAuthMode, f as usesBetterAuthClient } from "./auth-mode-DhGCw2Bx.js";
import { s as getSignInSearch, u as normalizeAuthRedirect } from "./auth-redirect-Dnh6pyWf.js";
import { t as authClient } from "./auth-client-DstRenkx.js";
import { t as Button } from "./button-DrcZrdio.js";
import { r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { n as AuthPageCard, r as AuthPageShell } from "./AuthPage-Bxu7AMPh.js";
import { t as Route } from "./forgot-password-DQ3HAYLX.js";
import { t as useAppForm } from "./useAppForm-DjX0VDRv.js";
import { r as getFormError } from "./forms-t3Wjw9fZ.js";
//#region src/routes/forgot-password.tsx?tsr-split=component
var import_jsx_runtime = require_jsx_runtime();
var forgotPasswordSchema = object({ email: string().trim().email("Enter a valid email address.") });
function ForgotPasswordPage() {
	const search = Route.useSearch();
	const redirectTo = normalizeAuthRedirect(search.redirect);
	const isHostedMode = isHostedClientAuthMode();
	const isOperatorReset = !isHostedMode && usesBetterAuthClient();
	const form = useAppForm({
		defaultValues: { email: "" },
		validators: { onSubmit: forgotPasswordSchema },
		onSubmit: async ({ formApi, value }) => {
			try {
				const redirectUrl = new URL("/reset-password", window.location.origin);
				if (redirectTo !== "/") redirectUrl.searchParams.set("redirect", redirectTo);
				const result = await authClient.requestPasswordReset({
					email: value.email.trim(),
					redirectTo: redirectUrl.toString()
				});
				if (result.error) {
					formApi.setErrorMap({ onSubmit: {
						form: result.error.message || "We couldn't send the reset email.",
						fields: {}
					} });
					return;
				}
			} catch {
				formApi.setErrorMap({ onSubmit: {
					form: "We couldn't send the reset email right now. Please try again.",
					fields: {}
				} });
			}
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPageShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.Subscribe, {
		selector: (state) => ({
			isSuccess: state.isSubmitSuccessful && !state.errorMap.onSubmit,
			submittedEmail: state.values.email,
			submitError: state.errorMap.onSubmit,
			isSubmitting: state.isSubmitting
		}),
		children: ({ isSuccess, submittedEmail, submitError, isSubmitting }) => {
			const errorMessage = getFormError(submitError);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPageCard, {
				title: isSuccess ? "Check your email" : "Forgot password",
				helperText: isSuccess ? void 0 : isHostedMode ? "Enter your email and we'll send you a password reset link." : isOperatorReset ? "Ask your server administrator to reset your password." : "Password reset isn't available right now.",
				footer: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/sign-in",
						search: getSignInSearch(redirectTo),
						className: "text-muted-foreground hover:text-foreground transition-colors",
						children: "Back to sign in"
					})
				}),
				children: isSuccess ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
					variant: "success",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, { children: [
						"If an account exists for ",
						submittedEmail,
						", you'll receive password reset instructions shortly."
					] })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.AppForm, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(form.Form, {
					className: "space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.AppField, {
							name: "email",
							children: (field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(field.TextField, {
								label: "Email address",
								type: "email",
								placeholder: "Email address...",
								autoComplete: "email",
								disabled: !isHostedMode,
								required: true
							})
						}),
						errorMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
							variant: "destructive",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: errorMessage })
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							variant: "secondary",
							className: "w-full",
							pending: isSubmitting,
							disabled: !isHostedMode,
							children: isSubmitting ? "Sending reset link..." : "Send reset link"
						})
					]
				}) })
			});
		}
	}) });
}
//#endregion
export { ForgotPasswordPage as component };
