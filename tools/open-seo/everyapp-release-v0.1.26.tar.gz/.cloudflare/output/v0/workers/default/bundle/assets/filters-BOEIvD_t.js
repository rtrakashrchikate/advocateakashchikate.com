import { U as AppError } from "./onboarding-drip-B7bIbv_6.js";
//#region src/server/lib/dataforseo/filters.ts
function escapeLikeTerm(term) {
	return term.replace(/[\\%_]/g, (match) => `\\${match}`);
}
/** Splits a comma/plus separated terms string into trimmed lowercase terms. */
function parseFilterTerms(value) {
	if (!value) return [];
	return value.toLowerCase().split(/[,+]/).map((term) => term.trim()).filter(Boolean);
}
function collectNumericRange(out, field, min, max) {
	if (typeof min === "number" && Number.isFinite(min)) out.push([
		field,
		">=",
		min
	]);
	if (typeof max === "number" && Number.isFinite(max)) out.push([
		field,
		"<=",
		max
	]);
}
/**
* One ilike condition per include term, joined with "or" into a single nested
* group (match-any semantics). Returns the group clause plus how many of the
* DataForSEO condition budget it consumes.
*/
function buildIncludeOrGroup(field, include) {
	const conditions = parseFilterTerms(include).map((term) => [
		field,
		"ilike",
		`%${escapeLikeTerm(term)}%`
	]);
	if (conditions.length === 0) return null;
	const first = conditions[0];
	if (conditions.length === 1 && first) return {
		clause: first,
		conditionCount: 1
	};
	return {
		clause: joinClauses(conditions, "or"),
		conditionCount: conditions.length
	};
}
/**
* DataForSEO accepts up to 8 filter conditions per request. The clients
* surface the same condition count and disable Apply when over budget, so
* reaching the cap here indicates a misbehaving client \u2014 we throw rather
* than silently truncate.
*/
function assertFilterConditionBudget(conditionCount) {
	if (conditionCount > 8) throw new AppError("VALIDATION_ERROR", `Too many filter conditions (${conditionCount} of 8 max).`);
}
function joinClauses(clauses, operator) {
	const expressions = [];
	for (const clause of clauses) {
		if (expressions.length > 0) expressions.push(operator);
		expressions.push(clause);
	}
	return expressions;
}
//#endregion
export { joinClauses as a, escapeLikeTerm as i, buildIncludeOrGroup as n, parseFilterTerms as o, collectNumericRange as r, assertFilterConditionBudget as t };
