import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { n as useRouter } from "./useSelector-CMqnGyuQ.js";
import { r as linkOptions, t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { n as Outlet } from "./Match-Djim5BGq.js";
import "./useMatch-BB4BMDVC.js";
import { t as useParams } from "./useParams-4qBmna-E.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { n as useMatchRoute } from "./Matches-maQTmZAu.js";
import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { I as BASE_PLAN_OFFER } from "./resolve-DrNDcpX6.js";
import { C as BILLING_ROUTE, O as SUBSCRIBE_ROUTE } from "./onboarding-drip-B7bIbv_6.js";
import { c as isHostedClientAuthMode, i as isEmailVerificationBypassed, o as isEveryAppClientAuthMode } from "./auth-mode-DhGCw2Bx.js";
import { f as CURRENT_TERMS_EFFECTIVE_DATE, h as TERMS_URL, m as PRIVACY_URL, r as getCurrentAuthRedirectFromHref } from "./auth-redirect-Dnh6pyWf.js";
import { n as signOutAndRedirect, r as useSession } from "./auth-client-DstRenkx.js";
import { a as samSessionsQueryOptions, c as t, i as invalidateSamSessions, n as useSamBetaOptIn, o as archiveSamSession, r as useSamSessions, s as Brain } from "./samBetaOptIn-4V1wHsrX.js";
import { r as LOCATIONS } from "./keyword-locations-4GfvBtRY.js";
import { j as useQueryClient, t as useQuery } from "./useQuery-B93OR2NQ.js";
import { c as Skeleton, d as useCreditBalance, n as QueryState, p as prefetchBillingAccount } from "./QueryState-Q8BZIblk.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { r as getStandardErrorMessage } from "./error-messages-D7nntGF_.js";
import { n as createLucideIcon, t as cn } from "./dist-fVOGIv0D.js";
import { t as Archive } from "./archive-CtdwYGhq.js";
import { n as Bot, t as ClipboardCheck } from "./clipboard-check-o2Icx6WY.js";
import { p as ChartLine, r as getGscGrantStatus } from "./gsc-D2zBtNni.js";
import { t as Check } from "./check-RTl8hsAC.js";
import { t as ChevronLeft } from "./chevron-left-C2BycBKd.js";
import { t as ExternalLink } from "./external-link-HZIbqzY5.js";
import { t as FileText } from "./file-text-D3JyNNBV.js";
import { t as Globe } from "./globe-CcyiZQla.js";
import { t as Link2 } from "./link-2-BzRVDXzK.js";
import { B as cva, g as mergeProps, t as Button } from "./button-DrcZrdio.js";
import { t as MapPin } from "./map-pin-BzsQS5Ua.js";
import { t as MessageSquare } from "./message-square-C0Mxfw3u.js";
import { n as ThemePreferenceRadio } from "./ThemePreferenceMenuItems-DB5ujp3U.js";
import { t as Plus } from "./plus-C1Kukp-u.js";
import { t as Search } from "./search-8b-KxN4Z.js";
import { t as Settings } from "./settings-kAsZ1oNV.js";
import { t as TrendingUp } from "./trending-up-DYoGV4Y5.js";
import { t as TriangleAlert } from "./triangle-alert-C9SRPVjv.js";
import { t as User } from "./user-BEwQJRp7.js";
import { t as X } from "./x-CPPij64W.js";
import { r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { n as captureClientEvent } from "./posthog-BMFJOGWd.js";
import { t as createSsrRpc } from "./createSsrRpc-Vp3C13VD.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
import { t as everyAppAccountQueryOptions } from "./everyAppAccountQueries-C9mjQ_j3.js";
import { i as switchOrganization } from "./organization-BUUwiNQd.js";
import { n as useCanManageBilling, t as organizationContextQueryOptions } from "./organizationQueries-BMLHGNAs.js";
import { i as dismissGscNudge, r as onboardingAnswersQueryOptions } from "./onboardingModel-Bf6Ae2yw.js";
import { t as PageLoading } from "./Spinner-NR-t-8YM.js";
import { n as useRender, t as Badge } from "./badge-B9fV075d.js";
import { t as Separator } from "./separator-Br1Gsn9Z.js";
import { t as projectsQueryOptions } from "./projectQueries-CUURHKzv.js";
import { n as getLastProjectId, r as setLastProjectId, t as clearLastProjectId } from "./active-project-CjOtfLST.js";
import { i as GoogleGlyphMuted, r as GoogleGlyph, t as startGoogleLink } from "./startGoogleLink-DWcDLWuI.js";
import { n as TooltipContent, r as TooltipTrigger, t as Tooltip } from "./tooltip-D5ss-ZNP.js";
import { a as DialogDescription, i as DialogPopup, o as DialogClose, r as DialogPortal, s as DialogBackdrop, t as DialogTitle } from "./DialogTitle-COljoqFw.js";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle$1, r as DialogDescription$1, s as DialogRoot, t as Dialog } from "./dialog-C8cX1CPK.js";
import { f as ComboboxList, l as ComboboxInput, o as ComboboxContent, p as ComboboxTrigger, s as ComboboxEmpty, t as Combobox, u as ComboboxItem } from "./combobox-BYdKkOBU.js";
import { a as DropdownMenuLabel, c as DropdownMenuSeparator, i as DropdownMenuItem, l as DropdownMenuTrigger, n as DropdownMenuContent, r as DropdownMenuGroup, t as DropdownMenu } from "./dropdown-menu-DubRfxrI.js";
import { t as CreateProjectModal } from "./CreateProjectModal-BjNKE_1P.js";
import { t as useHostedAuthRouteGuard } from "./useHostedAuthRouteGuard-CrzAilsp.js";
//#region node_modules/.pnpm/@tanstack+react-router@1.170.41_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@tanstack/react-router/dist/esm/useLocation.js
/**
* Read the current location from the router state with optional selection.
* Useful for subscribing to just the pieces of location you care about.
*
* Options:
* - `select`: Project the `location` object to a derived value
* - `structuralSharing`: Enable structural sharing for stable references
*
* @returns The current location (or selected value).
* @link https://tanstack.com/router/latest/docs/framework/react/api/router/useLocationHook
*/
function useLocation(opts) {
	const router = useRouter();
	{
		const location = router.stores.location.get();
		return opts?.select ? opts.select(location) : location;
	}
}
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ArrowLeftRight = createLucideIcon("arrow-left-right", [
	["path", {
		d: "M8 3 4 7l4 4",
		key: "9rb6wj"
	}],
	["path", {
		d: "M4 7h16",
		key: "6tx8e3"
	}],
	["path", {
		d: "m16 21 4-4-4-4",
		key: "siv7j2"
	}],
	["path", {
		d: "M20 17H4",
		key: "h6l3hr"
	}]
]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Bookmark = createLucideIcon("bookmark", [["path", {
	d: "m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z",
	key: "1fy3hk"
}]]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var CircleQuestionMark = createLucideIcon("circle-question-mark", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "10",
		key: "1mglay"
	}],
	["path", {
		d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3",
		key: "1u773s"
	}],
	["path", {
		d: "M12 17h.01",
		key: "p32p05"
	}]
]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var CreditCard = createLucideIcon("credit-card", [["rect", {
	width: "20",
	height: "14",
	x: "2",
	y: "5",
	rx: "2",
	key: "ynyp8z"
}], ["line", {
	x1: "2",
	x2: "22",
	y1: "10",
	y2: "10",
	key: "1b3vmo"
}]]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var FolderCog = createLucideIcon("folder-cog", [
	["path", {
		d: "M10.3 20H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.98a2 2 0 0 1 1.69.9l.66 1.2A2 2 0 0 0 12 6h8a2 2 0 0 1 2 2v3.3",
		key: "128dxu"
	}],
	["path", {
		d: "m14.305 19.53.923-.382",
		key: "3m78fa"
	}],
	["path", {
		d: "m15.228 16.852-.923-.383",
		key: "npixar"
	}],
	["path", {
		d: "m16.852 15.228-.383-.923",
		key: "5xggr7"
	}],
	["path", {
		d: "m16.852 20.772-.383.924",
		key: "dpfhf9"
	}],
	["path", {
		d: "m19.148 15.228.383-.923",
		key: "1reyyz"
	}],
	["path", {
		d: "m19.53 21.696-.382-.924",
		key: "1goivc"
	}],
	["path", {
		d: "m20.772 16.852.924-.383",
		key: "htqkph"
	}],
	["path", {
		d: "m20.772 19.148.924.383",
		key: "9w9pjp"
	}],
	["circle", {
		cx: "18",
		cy: "18",
		r: "3",
		key: "1xkwt0"
	}]
]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var LayoutDashboard = createLucideIcon("layout-dashboard", [
	["rect", {
		width: "7",
		height: "9",
		x: "3",
		y: "3",
		rx: "1",
		key: "10lvy0"
	}],
	["rect", {
		width: "7",
		height: "5",
		x: "14",
		y: "3",
		rx: "1",
		key: "16une8"
	}],
	["rect", {
		width: "7",
		height: "9",
		x: "14",
		y: "12",
		rx: "1",
		key: "1hutg5"
	}],
	["rect", {
		width: "7",
		height: "5",
		x: "3",
		y: "16",
		rx: "1",
		key: "ldoo1y"
	}]
]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var LogOut = createLucideIcon("log-out", [
	["path", {
		d: "m16 17 5-5-5-5",
		key: "1bji2h"
	}],
	["path", {
		d: "M21 12H9",
		key: "dn1m92"
	}],
	["path", {
		d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",
		key: "1uf3rs"
	}]
]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var PanelLeft = createLucideIcon("panel-left", [["rect", {
	width: "18",
	height: "18",
	x: "3",
	y: "3",
	rx: "2",
	key: "afitv7"
}], ["path", {
	d: "M9 3v18",
	key: "fh3hqa"
}]]);
//#endregion
//#region src/client/layout/AppBanner.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function AppBanner({ variant, icon, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant,
		banner: true,
		className: "shrink-0",
		children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, {
			className: "text-foreground",
			children
		})]
	});
}
//#endregion
//#region src/client/features/billing/FreePlanBanner.tsx
function FreePlanBanner() {
	const { accountQuery, isFreePlan, isOutOfCredits, isLowCredits, refillDate, autoReload, autoReloadState, isPausedByBudget } = useCreditBalance();
	const canManageBilling = useCanManageBilling();
	const showsOutOfCredits = Boolean(accountQuery.data) && isOutOfCredits;
	(0, import_react.useEffect)(() => {
		if (showsOutOfCredits) captureClientEvent("billing:out_of_credits_shown", { surface: "banner" });
	}, [showsOutOfCredits]);
	if (!accountQuery.data) return null;
	if (isPausedByBudget && autoReload) {
		const until = refillDate ? ` until ${refillDate}` : "";
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBanner, {
			variant: "warning",
			children: canManageBilling ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				"You\u2019ve hit your $",
				autoReload.monthlyLimitUsd,
				" monthly auto-reload budget, so credits are paused",
				until,
				".",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: BILLING_ROUTE,
					className: "font-medium text-primary underline-offset-4 hover:underline",
					children: "Raise your budget"
				}),
				" ",
				"to keep going."
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				"Your organization hit its monthly auto-reload budget, so credits are paused",
				until,
				". Ask the owner to raise it."
			] })
		});
	}
	if (!isFreePlan && isOutOfCredits && autoReloadState === "on" && autoReload) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppBanner, {
		variant: "info",
		children: [
			"You\u2019re out of credits. Auto-reload is adding $",
			autoReload.amountUsd,
			" now."
		]
	});
	if (!canManageBilling && (isOutOfCredits || isLowCredits)) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppBanner, {
		variant: isOutOfCredits ? "destructive" : "warning",
		children: [
			isOutOfCredits ? autoReloadState === "card_failed" ? "Your organization is out of credits and its card was declined." : "Your organization has used its credits." : "Your organization is running low on credits.",
			" ",
			"Ask your organization owner to",
			" ",
			autoReloadState === "card_failed" ? "update it" : "add more",
			"."
		]
	});
	const creditsActionLink = isFreePlan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: SUBSCRIBE_ROUTE,
		search: { upgrade: true },
		className: "font-medium text-primary underline-offset-4 hover:underline",
		children: "Upgrade your plan"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: BILLING_ROUTE,
		className: "font-medium text-primary underline-offset-4 hover:underline",
		children: "Buy more credits"
	});
	if (isOutOfCredits) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBanner, {
		variant: "destructive",
		children: isFreePlan ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			"You\u2019ve used your free credits. ",
			creditsActionLink,
			" to get $",
			BASE_PLAN_OFFER.monthlyCreditsUsd,
			" of credits every month."
		] }) : autoReloadState === "card_failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			"You\u2019re out of credits and auto-reload couldn\u2019t charge your card.",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: BILLING_ROUTE,
				className: "font-medium text-primary underline-offset-4 hover:underline",
				children: "Update your card"
			}),
			" ",
			"to keep going."
		] }) : autoReloadState === "failed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			"You\u2019re out of credits and auto-reload couldn\u2019t buy more.",
			" ",
			creditsActionLink,
			" to keep going."
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			"You\u2019ve used this month\u2019s credits. ",
			creditsActionLink,
			" to keep going",
			refillDate ? `, or wait for them to refill on ${refillDate}` : "",
			"."
		] })
	});
	if (isLowCredits) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppBanner, {
		variant: "warning",
		children: [
			"You\u2019re running low on credits. ",
			creditsActionLink,
			" to keep using OpenSEO."
		]
	});
	if (isFreePlan) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppBanner, {
		variant: "info",
		children: [
			"We hope you\u2019re enjoying OpenSEO!",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: SUBSCRIBE_ROUTE,
				search: { upgrade: true },
				className: "font-medium text-primary underline-offset-4 hover:underline",
				children: "Upgrade anytime"
			}),
			" ",
			"or",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/support",
				className: "font-medium text-primary underline-offset-4 hover:underline",
				children: "reach out with questions"
			}),
			"."
		]
	});
	return null;
}
//#endregion
//#region src/serverFunctions/terms.ts
var acceptTermsUpdate = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).handler(createSsrRpc("3d7f65dfdb19058c1c6e4e20c55a56e9a9dd4247087215febdb7d1a40508edfe"));
//#endregion
//#region src/client/features/auth/TermsUpdateBanner.tsx
function TermsUpdateBanner() {
	const { data: session, refetch } = useSession();
	const acceptMutation = useMutation({
		mutationFn: () => acceptTermsUpdate(),
		onSuccess: () => refetch({ query: { disableCookieCache: true } }),
		onError: () => toast.error("We couldn't record your acceptance.")
	});
	if (!session || session.user.termsAcceptedVersion === "2026-11") return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBanner, {
		variant: "info",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
				"We\u2019ve updated our",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: TERMS_URL,
					target: "_blank",
					rel: "noreferrer",
					children: "Terms"
				}),
				" ",
				"and",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: PRIVACY_URL,
					target: "_blank",
					rel: "noreferrer",
					children: "Privacy Policy"
				}),
				" ",
				"(effective ",
				CURRENT_TERMS_EFFECTIVE_DATE,
				"). Please review and accept."
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				pending: acceptMutation.isPending,
				onClick: () => acceptMutation.mutate(),
				children: "Accept"
			})]
		})
	});
}
//#endregion
//#region src/client/navigation/items.ts
var projectNavItems = [
	{
		to: "/p/$projectId",
		label: "Dashboard",
		icon: LayoutDashboard,
		activeOptions: {
			exact: true,
			includeSearch: false
		}
	},
	{
		to: "/p/$projectId/keywords",
		label: "Keyword Research",
		icon: Search
	},
	{
		to: "/p/$projectId/saved",
		label: "Saved Keywords",
		icon: Bookmark
	},
	{
		to: "/p/$projectId/rank-tracking",
		label: "Rank Tracking",
		icon: TrendingUp
	},
	{
		to: "/p/$projectId/local-seo",
		label: "Local SEO",
		icon: MapPin
	},
	{
		to: "/p/$projectId/search-performance",
		label: "GSC Insights",
		icon: GoogleGlyphMuted
	},
	{
		to: "/p/$projectId/domain",
		label: "Domain Overview",
		icon: Globe
	},
	{
		to: "/p/$projectId/backlinks",
		label: "Backlinks",
		icon: Link2
	},
	{
		to: "/p/$projectId/audit",
		label: "Site Audit",
		icon: ClipboardCheck
	},
	{
		to: "/p/$projectId/ai-visibility",
		label: "Prompt Tracking",
		icon: ChartLine,
		activeOptions: {
			exact: true,
			includeSearch: false
		}
	},
	{
		to: "/p/$projectId/ai-visibility/research",
		label: "Prompt Research",
		icon: Search
	},
	{
		to: "/p/$projectId/prompt-explorer",
		label: "Prompt Explorer",
		icon: MessageSquare
	},
	{
		to: "/p/$projectId/reports",
		label: "Reports",
		icon: FileText
	},
	{
		to: "/p/$projectId/context",
		label: "Context",
		icon: Brain
	}
];
var aiNavItem = linkOptions({
	to: "/ai",
	label: "Agent setup",
	icon: Bot
});
var connectNavGroup = {
	label: "AI Tools",
	items: [aiNavItem]
};
function getProjectNavItems(projectId) {
	return linkOptions(projectNavItems.map((item) => ({
		...item,
		params: { projectId },
		search: {}
	})));
}
function getProjectNavGroups(projectId) {
	const all = getProjectNavItems(projectId);
	const byPath = (path) => all.find((i) => i.to === path);
	return [
		{
			label: "Overview",
			items: [byPath("/p/$projectId")]
		},
		{
			label: "Research",
			items: [
				byPath("/p/$projectId/keywords"),
				byPath("/p/$projectId/domain"),
				byPath("/p/$projectId/backlinks")
			]
		},
		{
			label: "AI Visibility",
			items: [
				byPath("/p/$projectId/ai-visibility/research"),
				byPath("/p/$projectId/prompt-explorer"),
				byPath("/p/$projectId/ai-visibility")
			]
		},
		{
			label: "My Site",
			items: [
				byPath("/p/$projectId/search-performance"),
				byPath("/p/$projectId/rank-tracking"),
				byPath("/p/$projectId/local-seo"),
				byPath("/p/$projectId/saved"),
				byPath("/p/$projectId/audit")
			]
		},
		{
			label: "AI Tools",
			items: [
				byPath("/p/$projectId/reports"),
				byPath("/p/$projectId/context"),
				aiNavItem
			]
		}
	];
}
var dataforseoHelpLinkOptions = linkOptions({ to: "/help/dataforseo-api-key" });
//#endregion
//#region src/client/layout/AppShellParts.tsx
function SeoApiStatusBanners({ shouldShowSeoApiWarning, seoApiKeyStatusError }) {
	const icon = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-4 shrink-0" });
	const helpLink = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		...dataforseoHelpLinkOptions,
		className: "font-medium text-primary underline-offset-4 hover:underline",
		children: "help page"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [shouldShowSeoApiWarning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppBanner, {
		variant: "warning",
		icon,
		children: isEveryAppClientAuthMode() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			"DataForSEO isn't set up on your Every App gateway yet. An owner or admin sets it with",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "pnpm everyapp secret set DATAFORSEO_API_KEY" }),
			". Steps on the ",
			helpLink,
			"."
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			"Setup needed: add your DataForSEO API key to use OpenSEO features. See the quick steps on the ",
			helpLink,
			"."
		] })
	}) : null, seoApiKeyStatusError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppBanner, {
		variant: "info",
		icon,
		children: [
			"We could not verify your DataForSEO setup. If features are not working, check the setup steps on the ",
			helpLink,
			"."
		]
	}) : null] });
}
var DOCKER_MOVE_DISMISSED_KEY = "openseo:docker-move-dismissed";
function LegacyDockerBanner() {
	const [dismissed, setDismissed] = (0, import_react.useState)(() => localStorage.getItem(DOCKER_MOVE_DISMISSED_KEY) === "1");
	return null;
}
function MissingSeoSetupModal({ onClose }) {
	const everyApp = isEveryAppClientAuthMode();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => !open && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
				className: "flex-row items-start gap-3 text-left",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-full bg-warning/20 p-2 text-warning",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "size-5" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, { children: everyApp ? "DataForSEO isn't set up yet" : "One quick setup step" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, { children: everyApp ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"Keyword, domain, backlink and rank data comes from DataForSEO through your Every App gateway. An owner or admin sets it once for every app with",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "pnpm everyapp secret set DATAFORSEO_API_KEY" }),
						"; the setup guide has the steps."
					] }) : "Add your DataForSEO API key to start using OpenSEO." })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: onClose,
				children: "Dismiss"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				nativeButton: false,
				render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					...dataforseoHelpLinkOptions,
					onClick: onClose
				}),
				children: ["Open setup guide", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-4" })]
			})] })]
		})
	});
}
//#endregion
//#region src/client/features/gsc/GscReEngagementModal.tsx
/**
* One-time prompt nudging users who finished onboarding without the Search
* Console step (legacy users, and users onboarded by an agent) to connect GSC. Hosted-only because this is
* a hosted onboarding re-engagement nudge. Shows once \u2014 server-persisted
* dismissal means it never reappears after the user connects or dismisses, on
* any device.
*
* `suppressed` lets the layout hide this when another modal (e.g. the missing
* DataForSEO key prompt) is already showing so the two never stack.
*/
function GscReEngagementModal({ projectId, suppressed }) {
	const hosted = isHostedClientAuthMode();
	const queryClient = useQueryClient();
	const [closed, setClosed] = import_react.useState(false);
	const shownRef = import_react.useRef(false);
	const connectRef = import_react.useRef(null);
	const onboardingQuery = useQuery({
		...onboardingAnswersQueryOptions(),
		enabled: hosted
	});
	const grantQuery = useQuery({
		queryKey: ["gscGrantStatus"],
		queryFn: () => getGscGrantStatus(),
		enabled: hosted
	});
	const dismissMutation = useMutation({
		mutationFn: () => dismissGscNudge(),
		onSettled: () => {
			queryClient.invalidateQueries({ queryKey: ["onboardingAnswers"] });
		}
	});
	const eligible = hosted && !suppressed && !closed && onboardingQuery.isSuccess && grantQuery.isSuccess && Boolean(onboardingQuery.data?.completedAt) && !onboardingQuery.data?.gscNudgeDismissedAt && !grantQuery.data?.connected;
	import_react.useEffect(() => {
		if (eligible && !shownRef.current) {
			shownRef.current = true;
			captureClientEvent("gsc:nudge_shown");
		}
	}, [eligible]);
	if (!eligible) return null;
	function persistDismiss() {
		setClosed(true);
		dismissMutation.mutate();
	}
	function handleDismiss() {
		captureClientEvent("gsc:nudge_dismissed");
		persistDismiss();
	}
	function handleConnect() {
		captureClientEvent("gsc:nudge_connect_clicked");
		persistDismiss();
		const callbackURL = projectId ? `${window.location.origin}/p/${projectId}/settings/integrations` : window.location.href;
		startGoogleLink("gsc", callbackURL);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => {
			if (!open) handleDismiss();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-lg",
			initialFocus: connectRef,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
				className: "text-lg",
				children: "Connect Google Search Console"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, { children: "Bring your real clicks, impressions, and rankings into OpenSEO and query them from Claude or Codex over MCP. It never uses credits." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "px-2 text-sm text-muted-foreground outline-none hover:text-foreground focus-visible:underline",
				onClick: handleDismiss,
				children: "Maybe later"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				ref: connectRef,
				onClick: handleConnect,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex size-6 items-center justify-center rounded bg-white",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleGlyph, { className: "size-[16px]" })
				}), "Connect with Google"]
			})] })]
		})
	});
}
//#endregion
//#region src/client/features/projects/ProjectSwitcher.tsx
var SEARCH_THRESHOLD = 8;
function matchesProject(project, query) {
	const needle = query.trim().toLowerCase();
	return project.name.toLowerCase().includes(needle) || Boolean(project.domain?.toLowerCase().includes(needle));
}
function sharesDomainAcrossCountries(project, projects) {
	return project.domain !== null && projects.some((other) => other.domain === project.domain && other.locationCode !== project.locationCode);
}
function ProjectSwitcher({ activeProjectId, ready, onCloseDrawer }) {
	const router = useRouter();
	const [creating, setCreating] = import_react.useState(false);
	const [open, setOpen] = import_react.useState(false);
	const projectsQuery = useQuery({
		...projectsQueryOptions(),
		enabled: ready
	});
	const projects = projectsQuery.data ?? [];
	const activeProject = projects.find((project) => project.id === activeProjectId) ?? null;
	if (projectsQuery.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-stretch rounded-lg border border-sidebar-border bg-card",
		"aria-busy": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex min-w-0 flex-1 flex-col px-3 py-1.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex h-5 items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3.5 w-28" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex h-4 items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-20" })
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-12 border-l border-sidebar-border" })]
	});
	const handleSelect = (project) => {
		setOpen(false);
		onCloseDrawer?.();
		if (project.id === activeProjectId) return;
		setLastProjectId(project.id);
		const template = t(router.state.matches, (match) => match.fullPath.includes("$projectId") && match.fullPath.split("/").every((segment) => !segment.startsWith("$") || segment === "$projectId"))?.fullPath ?? "/p/$projectId";
		router.navigate({ href: template.split("$projectId").join(project.id).replace(/\/$/, "") });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Combobox, {
		items: projects,
		value: activeProject,
		itemToStringLabel: (project) => project.name,
		isItemEqualToValue: (project, value) => project.id === value.id,
		filter: projects.length >= SEARCH_THRESHOLD ? matchesProject : null,
		autoHighlight: true,
		open,
		onOpenChange: setOpen,
		onValueChange: (project) => {
			if (project) handleSelect(project);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-stretch rounded-lg border border-sidebar-border bg-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxTrigger, {
				"aria-label": "Switch project",
				className: "flex min-w-0 flex-1 items-center justify-between gap-2 rounded-l-lg px-3 py-1.5 text-left hover:bg-accent",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex min-w-0 flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-sm font-medium",
						children: activeProject?.name ?? "Select project"
					}), activeProject?.domain ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate text-xs text-muted-foreground",
						children: activeProject.domain
					}) : null]
				})
			}), activeProject ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				nativeButton: false,
				render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/p/$projectId/settings",
					params: { projectId: activeProject.id },
					"aria-label": "Project settings",
					title: "Project settings",
					onClick: () => {
						setOpen(false);
						onCloseDrawer?.();
					}
				}),
				variant: "ghost",
				className: "h-auto self-stretch rounded-l-none border-0 border-l border-sidebar-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" })
			}) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxContent, {
			className: "w-(--anchor-width)",
			children: [
				projects.length >= SEARCH_THRESHOLD ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxInput, {
					className: "w-auto",
					placeholder: "Find project\u2026",
					"aria-label": "Filter projects",
					showTrigger: false
				}) : null,
				projects.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxEmpty, { children: "No projects match." }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxList, {
					className: "max-h-[min(60vh,21rem)]",
					children: (project) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxItem, {
						value: project,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex min-w-0 flex-col",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate",
								children: project.name
							}), project.domain ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "truncate text-xs text-muted-foreground",
								children: project.domain
							}) : null]
						}), sharesDomainAcrossCountries(project, projects) && LOCATIONS[project.locationCode] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-auto shrink-0 text-xs text-muted-foreground",
							children: LOCATIONS[project.locationCode]
						}) : null]
					}, project.id)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-0.5 p-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						className: "justify-start",
						onClick: () => {
							setOpen(false);
							setCreating(true);
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-4" }), "New project"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						nativeButton: false,
						render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/projects",
							onClick: () => {
								setOpen(false);
								onCloseDrawer?.();
							}
						}),
						variant: "ghost",
						className: "justify-start",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderCog, { className: "size-4" }), "Manage projects"]
					})]
				})
			]
		})]
	}), creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateProjectModal, { onClose: () => {
		setCreating(false);
		onCloseDrawer?.();
	} }) : null] });
}
//#endregion
//#region src/client/hooks/use-mobile.ts
var MOBILE_BREAKPOINT = 768;
function useIsMobile() {
	const [isMobile, setIsMobile] = import_react.useState(void 0);
	import_react.useEffect(() => {
		const mql = window.matchMedia(`(max-width: 767px)`);
		const onChange = () => {
			setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
		};
		mql.addEventListener("change", onChange);
		setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
		return () => mql.removeEventListener("change", onChange);
	}, []);
	return !!isMobile;
}
//#endregion
//#region src/client/components/ui/sheet.tsx
function Sheet({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogRoot, {
		"data-slot": "sheet",
		...props
	});
}
function SheetPortal({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogPortal, {
		"data-slot": "sheet-portal",
		...props
	});
}
function SheetOverlay({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogBackdrop, {
		"data-slot": "sheet-overlay",
		className: cn("fixed inset-0 z-50 bg-black/10 transition-opacity duration-150 data-ending-style:opacity-0 data-starting-style:opacity-0 supports-backdrop-filter:backdrop-blur-xs", className),
		...props
	});
}
function SheetContent({ className, children, side = "right", showCloseButton = true, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPopup, {
		"data-slot": "sheet-content",
		"data-side": side,
		className: cn("fixed z-50 flex flex-col gap-4 bg-popover bg-clip-padding text-sm text-popover-foreground shadow-lg transition duration-200 ease-in-out data-ending-style:opacity-0 data-starting-style:opacity-0 data-[side=bottom]:inset-x-0 data-[side=bottom]:bottom-0 data-[side=bottom]:h-auto data-[side=bottom]:border-t data-[side=bottom]:data-ending-style:translate-y-[2.5rem] data-[side=bottom]:data-starting-style:translate-y-[2.5rem] data-[side=left]:inset-y-0 data-[side=left]:left-0 data-[side=left]:h-full data-[side=left]:w-3/4 data-[side=left]:border-r data-[side=left]:data-ending-style:translate-x-[-2.5rem] data-[side=left]:data-starting-style:translate-x-[-2.5rem] data-[side=right]:inset-y-0 data-[side=right]:right-0 data-[side=right]:h-full data-[side=right]:w-3/4 data-[side=right]:border-l data-[side=right]:data-ending-style:translate-x-[2.5rem] data-[side=right]:data-starting-style:translate-x-[2.5rem] data-[side=top]:inset-x-0 data-[side=top]:top-0 data-[side=top]:h-auto data-[side=top]:border-b data-[side=top]:data-ending-style:translate-y-[-2.5rem] data-[side=top]:data-starting-style:translate-y-[-2.5rem] data-[side=left]:sm:max-w-sm data-[side=right]:sm:max-w-sm", className),
		...props,
		children: [children, showCloseButton && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
			"data-slot": "sheet-close",
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				className: "absolute top-3 right-3",
				size: "icon-sm"
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Close"
			})]
		})]
	})] });
}
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "sheet-header",
		className: cn("flex flex-col gap-0.5 p-4", className),
		...props
	});
}
function SheetTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
		"data-slot": "sheet-title",
		className: cn("text-base font-medium text-foreground", className),
		...props
	});
}
function SheetDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
		"data-slot": "sheet-description",
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
//#endregion
//#region src/client/components/ui/sidebar.tsx
var SIDEBAR_COOKIE_NAME = "sidebar_state";
var SIDEBAR_COOKIE_MAX_AGE = 604800;
var SIDEBAR_WIDTH = "15rem";
var SIDEBAR_WIDTH_MOBILE = "15rem";
var SIDEBAR_WIDTH_ICON = "3rem";
var SIDEBAR_KEYBOARD_SHORTCUT = "b";
var SidebarContext = import_react.createContext(null);
function useSidebar() {
	const context = import_react.useContext(SidebarContext);
	if (!context) throw new Error("useSidebar must be used within a SidebarProvider.");
	return context;
}
function SidebarProvider({ defaultOpen = true, open: openProp, onOpenChange: setOpenProp, className, style, children, ...props }) {
	const isMobile = useIsMobile();
	const [openMobile, setOpenMobile] = import_react.useState(false);
	const [_open, _setOpen] = import_react.useState(defaultOpen);
	const open = openProp ?? _open;
	const setOpen = import_react.useCallback((value) => {
		const openState = typeof value === "function" ? value(open) : value;
		if (setOpenProp) setOpenProp(openState);
		else _setOpen(openState);
		document.cookie = `${SIDEBAR_COOKIE_NAME}=${openState}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}`;
	}, [setOpenProp, open]);
	const toggleSidebar = import_react.useCallback(() => {
		return isMobile ? setOpenMobile((current) => !current) : setOpen((current) => !current);
	}, [
		isMobile,
		setOpen,
		setOpenMobile
	]);
	import_react.useEffect(() => {
		const handleKeyDown = (event) => {
			if (isMobile && event.key === SIDEBAR_KEYBOARD_SHORTCUT && (event.metaKey || event.ctrlKey)) {
				event.preventDefault();
				toggleSidebar();
			}
		};
		window.addEventListener("keydown", handleKeyDown);
		return () => window.removeEventListener("keydown", handleKeyDown);
	}, [isMobile, toggleSidebar]);
	const state = open ? "expanded" : "collapsed";
	const contextValue = import_react.useMemo(() => ({
		state,
		open,
		setOpen,
		isMobile,
		openMobile,
		setOpenMobile,
		toggleSidebar
	}), [
		state,
		open,
		setOpen,
		isMobile,
		openMobile,
		setOpenMobile,
		toggleSidebar
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarContext.Provider, {
		value: contextValue,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"data-slot": "sidebar-wrapper",
			style: {
				"--sidebar-width": SIDEBAR_WIDTH,
				"--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
				...style
			},
			className: cn("group/sidebar-wrapper flex min-h-svh w-full has-data-[variant=inset]:bg-sidebar", className),
			...props,
			children
		})
	});
}
function Sidebar$1({ side = "left", variant = "sidebar", collapsible = "offcanvas", className, children, dir, ...props }) {
	const { isMobile, state, openMobile, setOpenMobile } = useSidebar();
	if (collapsible === "none") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "sidebar",
		className: cn("flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground", className),
		...props,
		children
	});
	if (isMobile) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
		open: openMobile,
		onOpenChange: setOpenMobile,
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			dir,
			"data-sidebar": "sidebar",
			"data-slot": "sidebar",
			"data-mobile": "true",
			className: "w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground",
			style: {
				"--sidebar-width": SIDEBAR_WIDTH_MOBILE,
				width: SIDEBAR_WIDTH_MOBILE
			},
			side,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetHeader, {
				className: "sr-only",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Sidebar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetDescription, { children: "Displays the mobile sidebar." })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex h-full w-full flex-col",
				children
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "group peer hidden text-sidebar-foreground md:block",
		"data-state": state,
		"data-collapsible": state === "collapsed" ? collapsible : "",
		"data-variant": variant,
		"data-side": side,
		"data-slot": "sidebar",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"data-slot": "sidebar-gap",
			className: cn("relative w-(--sidebar-width) bg-transparent transition-[width] duration-200 ease-linear", "group-data-[collapsible=offcanvas]:w-0", "group-data-[side=right]:rotate-180", variant === "floating" || variant === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4)))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)")
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			"data-slot": "sidebar-container",
			"data-side": side,
			className: cn("fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) transition-[left,right,width] duration-200 ease-linear data-[side=left]:left-0 data-[side=left]:group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)] data-[side=right]:right-0 data-[side=right]:group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)] md:flex", variant === "floating" || variant === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4))+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l", className),
			...props,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				"data-sidebar": "sidebar",
				"data-slot": "sidebar-inner",
				className: "flex size-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:shadow-sm group-data-[variant=floating]:ring-1 group-data-[variant=floating]:ring-sidebar-border",
				children
			})
		})]
	});
}
function SidebarTrigger({ className, onClick, ...props }) {
	const { toggleSidebar } = useSidebar();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		"data-sidebar": "trigger",
		"data-slot": "sidebar-trigger",
		variant: "ghost",
		size: "icon-sm",
		className: cn(className),
		onClick: (event) => {
			onClick?.(event);
			toggleSidebar();
		},
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PanelLeft, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Toggle Sidebar"
		})]
	});
}
function SidebarInset({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		"data-slot": "sidebar-inset",
		className: cn("relative flex w-full flex-1 flex-col bg-background md:peer-data-[variant=inset]:m-2 md:peer-data-[variant=inset]:ml-0 md:peer-data-[variant=inset]:rounded-xl md:peer-data-[variant=inset]:shadow-sm md:peer-data-[variant=inset]:peer-data-[state=collapsed]:ml-2", className),
		...props
	});
}
function SidebarHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "sidebar-header",
		"data-sidebar": "header",
		className: cn("flex flex-col gap-2 p-2", className),
		...props
	});
}
function SidebarFooter({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "sidebar-footer",
		"data-sidebar": "footer",
		className: cn("flex flex-col gap-2 p-2", className),
		...props
	});
}
function SidebarContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "sidebar-content",
		"data-sidebar": "content",
		className: cn("no-scrollbar flex min-h-0 flex-1 flex-col gap-0 overflow-auto group-data-[collapsible=icon]:overflow-hidden", className),
		...props
	});
}
function SidebarGroup({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "sidebar-group",
		"data-sidebar": "group",
		className: cn("relative flex w-full min-w-0 flex-col p-2", className),
		...props
	});
}
function SidebarGroupLabel({ className, render, ...props }) {
	return useRender({
		defaultTagName: "div",
		props: mergeProps({ className: cn("flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 ring-sidebar-ring outline-hidden transition-[margin,opacity] duration-200 ease-linear group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0 focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0", className) }, props),
		render,
		state: {
			slot: "sidebar-group-label",
			sidebar: "group-label"
		}
	});
}
function SidebarGroupContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"data-slot": "sidebar-group-content",
		"data-sidebar": "group-content",
		className: cn("w-full text-sm", className),
		...props
	});
}
function SidebarMenu({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		"data-slot": "sidebar-menu",
		"data-sidebar": "menu",
		className: cn("flex w-full min-w-0 flex-col gap-0", className),
		...props
	});
}
function SidebarMenuItem({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		"data-slot": "sidebar-menu-item",
		"data-sidebar": "menu-item",
		className: cn("group/menu-item relative", className),
		...props
	});
}
var sidebarMenuButtonVariants = cva("peer/menu-button group/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm ring-sidebar-ring outline-hidden transition-[width,height,padding] group-has-data-[sidebar=menu-action]/menu-item:pr-8 group-data-[collapsible=icon]:size-8! group-data-[collapsible=icon]:p-2! hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-open:hover:bg-sidebar-accent data-open:hover:text-sidebar-accent-foreground data-active:bg-sidebar-accent data-active:font-medium data-active:text-sidebar-accent-foreground [&_svg]:size-4 [&_svg]:shrink-0 [&>span:last-child]:truncate", {
	variants: {
		variant: {
			default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
			outline: "bg-background shadow-[0_0_0_1px_var(--sidebar-border)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]"
		},
		size: {
			default: "h-8 text-sm",
			sm: "h-7 text-xs",
			lg: "h-12 text-sm group-data-[collapsible=icon]:p-0!"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function SidebarMenuButton({ render, isActive = false, variant = "default", size = "default", tooltip, className, ...props }) {
	const { isMobile, state } = useSidebar();
	const comp = useRender({
		defaultTagName: "button",
		props: mergeProps({ className: cn(sidebarMenuButtonVariants({
			variant,
			size
		}), className) }, props),
		render: !tooltip ? render : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, { render }),
		state: {
			slot: "sidebar-menu-button",
			sidebar: "menu-button",
			size,
			active: isActive
		}
	});
	if (!tooltip) return comp;
	if (typeof tooltip === "string") tooltip = { children: tooltip };
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [comp, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
		side: "right",
		align: "center",
		hidden: state !== "collapsed" || isMobile,
		...tooltip
	})] });
}
function SidebarMenuSkeleton({ className, showIcon = false, ...props }) {
	const [width] = import_react.useState(() => {
		return `${Math.floor(Math.random() * 40) + 50}%`;
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"data-slot": "sidebar-menu-skeleton",
		"data-sidebar": "menu-skeleton",
		className: cn("flex h-8 items-center gap-2 rounded-md px-2", className),
		...props,
		children: [showIcon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			className: "size-4 rounded-md",
			"data-sidebar": "menu-skeleton-icon"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, {
			className: "h-4 max-w-(--skeleton-width) flex-1",
			"data-sidebar": "menu-skeleton-text",
			style: { "--skeleton-width": width }
		})]
	});
}
//#endregion
//#region src/client/features/sam/SamSidebarPanel.tsx
var BETA_NOTICE_DISMISSED_KEY = "sam-beta-notice-dismissed";
function BetaNotice() {
	const [dismissed, setDismissed] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		setDismissed(localStorage.getItem(BETA_NOTICE_DISMISSED_KEY) === "1");
	}, []);
	if (dismissed) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-2 mb-2 rounded-lg border border-border bg-card p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: "Beta" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					size: "icon-xs",
					"aria-label": "Dismiss",
					className: "text-muted-foreground",
					onClick: () => {
						localStorage.setItem(BETA_NOTICE_DISMISSED_KEY, "1");
						setDismissed(true);
					},
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1.5 text-xs text-muted-foreground",
				children: "For more powerful AI workflows, use the OpenSEO MCP with your own agent like Claude Code or Hermes."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/ai",
				className: "mt-1.5 inline-block text-xs text-primary underline-offset-4 hover:underline",
				children: "Set up the MCP \u2192"
			})
		]
	});
}
function ageLabel(timestamp) {
	const iso = timestamp.includes("T") ? timestamp : `${timestamp}Z`;
	const then = new Date(iso.replace(" ", "T")).getTime();
	if (Number.isNaN(then)) return "";
	const minutes = Math.max(0, Math.floor((Date.now() - then) / 6e4));
	if (minutes < 60) return `${minutes}m`;
	const hours = Math.floor(minutes / 60);
	if (hours < 24) return `${hours}h`;
	return `${Math.floor(hours / 24)}d`;
}
/** The chat list's rows while the chats load. */
function SamChatListSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenu, {
		"aria-busy": true,
		children: Array.from({ length: 4 }, (_, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSkeleton, {}, index))
	});
}
/**
* The sidebar while the SAM route is open: the active project's chat history
* plus a new-chat button. Selecting (or creating) a session navigates to the
* SAM route; the conversation itself renders in the main content panel.
*/
function SamSidebarPanel({ projectId, onNavigate }) {
	const queryClient = useQueryClient();
	const activeSessionId = useLocation().search.s;
	const optedIn = useSamBetaOptIn();
	const { sessionsQuery, goToSession, createSession } = useSamSessions(projectId, { onNavigate });
	const archiveSession = useMutation({
		mutationFn: (sessionId) => archiveSamSession({ data: { sessionId } }),
		onSuccess: (_result, sessionId) => {
			queryClient.setQueryData(samSessionsQueryOptions(projectId).queryKey, (current) => current?.filter((session) => session.id !== sessionId));
			invalidateSamSessions(projectId);
			if (sessionId === activeSessionId) goToSession();
		}
	});
	if (!optedIn) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "px-4 py-6 text-center text-xs text-muted-foreground",
		children: "Your chats will show here once you opt in to the beta."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-0 flex-1 flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-2 pb-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					className: "w-full justify-start gap-2 font-normal text-muted-foreground",
					pending: createSession.isPending,
					onClick: () => createSession.mutate(),
					children: [createSession.isPending ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "New chat"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "min-h-0 flex-1 overflow-y-auto px-2 py-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
					query: sessionsQuery,
					errorFallback: "Failed to load chats.",
					loading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SamChatListSkeleton, {}),
					children: (loadedSessions) => loadedSessions.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-2 py-6 text-center text-xs text-muted-foreground",
						children: "No chats yet. Start a new one."
					}) : loadedSessions.map((session) => {
						const isActive = session.id === activeSessionId;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: `group flex items-center gap-1 rounded-md px-1 ${isActive ? "bg-sidebar-accent" : "hover:bg-sidebar-accent/50"}`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => goToSession(session.id),
								className: "min-w-0 flex-1 truncate px-2 py-1.5 text-left text-sm text-sidebar-foreground/80",
								children: session.title
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid shrink-0 place-items-center *:col-start-1 *:row-start-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "pointer-events-none text-xs text-muted-foreground/75 transition-opacity group-hover:opacity-0 group-focus-within:opacity-0 pointer-coarse:opacity-0",
									children: ageLabel(session.updatedAt)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon-xs",
									"aria-label": "Archive chat",
									className: "text-muted-foreground reveal-on-hover",
									disabled: archiveSession.isPending,
									onClick: () => archiveSession.mutate(session.id),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Archive, {})
								})]
							})]
						}, session.id);
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BetaNotice, {})
		]
	});
}
//#endregion
//#region src/client/components/Sidebar.tsx
var navButtonClass = "relative text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground data-active:bg-sidebar-accent data-active:text-sidebar-accent-foreground data-active:before:absolute data-active:before:inset-y-1 data-active:before:left-0 data-active:before:w-[3px] data-active:before:rounded-r-full data-active:before:bg-primary";
function SidebarNavLink({ icon: Icon, label, linkProps, placeholder = false }) {
	const { setOpenMobile } = useSidebar();
	const matchRoute = useMatchRoute();
	const isPromptHistory = linkProps.to === "/p/$projectId/ai-visibility" && Boolean(matchRoute({
		to: "/p/$projectId/ai-visibility/prompts/$promptId",
		fuzzy: true
	}));
	const row = (isActive) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenuButton, {
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
		isActive,
		"aria-disabled": placeholder || void 0,
		className: navButtonClass,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuItem, { children: placeholder ? row(false) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		...linkProps,
		activeOptions: {
			exact: false,
			includeSearch: false,
			...linkProps.activeOptions
		},
		onClick: () => setOpenMobile(false),
		inactiveProps: isPromptHistory ? { "aria-current": "page" } : void 0,
		children: ({ isActive }) => row(isActive || isPromptHistory)
	}) });
}
function Sidebar({ projectId, projectPending, ready }) {
	const navPlaceholder = projectId === null && projectPending;
	const navGroups = projectId !== null || navPlaceholder ? getProjectNavGroups(projectId ?? "") : [connectNavGroup];
	const { pathname } = useLocation();
	const { setOpenMobile } = useSidebar();
	const onSamRoute = pathname.includes("/sam");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sidebar$1, {
		variant: "inset",
		collapsible: "offcanvas",
		className: "md:!p-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarHeader, {
				className: cn("gap-0 px-3 pb-1", everyApp ? "pt-2" : "pt-3"),
				children: [
					everyApp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EveryAppLink, {}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						onClick: () => setOpenMobile(false),
						className: "px-1 pb-2 text-base font-semibold text-sidebar-foreground",
						children: "OpenSEO"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectSwitcher, {
						activeProjectId: projectId,
						ready,
						onCloseDrawer: () => setOpenMobile(false)
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarContent, { children: onSamRoute && projectId ? ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SamSidebarPanel, {
				projectId,
				onNavigate: () => setOpenMobile(false)
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "px-2 py-1",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SamChatListSkeleton, {})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				"aria-label": "Main navigation",
				"aria-busy": navPlaceholder || void 0,
				children: navGroups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarGroup, {
					className: "py-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarGroupLabel, {
						className: "h-7 uppercase tracking-wider text-sidebar-foreground/40",
						children: group.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarGroupContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenu, { children: group.items.map((item) => {
						const { icon, label, ...linkProps } = item;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarNavLink, {
							icon,
							label,
							linkProps,
							placeholder: navPlaceholder
						}, linkProps.to);
					}) }) })]
				}, group.label))
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccountFooter, { ready })
		]
	});
}
var everyApp = isEveryAppClientAuthMode();
/**
* The way back up, first in the sidebar as in every Every App app. The row
* keeps its height while the gateway's URL loads so the header doesn't jump.
*/
function EveryAppLink() {
	const accountQuery = useQuery(everyAppAccountQueryOptions());
	const gatewayUrl = accountQuery.data?.gatewayUrl;
	if (!accountQuery.isPending && !gatewayUrl) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
		href: gatewayUrl ?? void 0,
		"aria-label": "Back to Every App",
		className: cn("mb-1 inline-flex h-7 w-fit items-center gap-0.5 rounded-md pl-0.5 pr-2 text-sm text-sidebar-foreground/60 transition-colors hover:text-sidebar-foreground", accountQuery.isPending && "invisible"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {
			className: "size-4",
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Every App" })]
	});
}
function AccountFooter({ ready }) {
	const { data: session } = useSession();
	const { setOpenMobile } = useSidebar();
	const everyAppAccountQuery = useQuery({
		...everyAppAccountQueryOptions(),
		enabled: everyApp
	});
	const email = everyApp ? everyAppAccountQuery.data?.email : session?.user?.email;
	const [isSwitching, setIsSwitching] = (0, import_react.useState)(false);
	const orgContextQuery = useQuery({
		...organizationContextQueryOptions(),
		enabled: Boolean(email) && !everyApp
	});
	const organizations = everyApp ? [] : orgContextQuery.data?.organizations ?? [];
	const activeOrganizationId = orgContextQuery.data?.organizationId;
	async function handleSwitchOrganization(organizationId) {
		if (isSwitching || organizationId === activeOrganizationId) return;
		setIsSwitching(true);
		try {
			await switchOrganization({ data: { organizationId } });
			clearLastProjectId();
			window.location.assign("/");
		} catch (error) {
			toast.error(getStandardErrorMessage(error));
			setIsSwitching(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarFooter, {
		className: "gap-0 border-t border-sidebar-border pb-safe",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarNavLink, {
			icon: CircleQuestionMark,
			label: "Help & Community",
			linkProps: { to: "/support" }
		}), everyApp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarNavLink, {
			icon: Settings,
			label: "Settings",
			linkProps: { to: "/settings" }
		}) : email ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuTrigger, {
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuButton, {
				className: navButtonClass,
				"aria-label": "Open account menu"
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate",
				"data-ph-mask": true,
				children: email
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
			side: "top",
			className: "w-56",
			children: [
				organizations.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuLabel, {
					className: "flex items-center gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeftRight, { className: "size-3" }), "Organization"]
				}), organizations.map((organization) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					disabled: isSwitching,
					onClick: () => void handleSwitchOrganization(organization.organizationId),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: organization.organizationName
					}), organization.organizationId === activeOrganizationId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "ml-auto size-4" }) : null]
				}, organization.organizationId))] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {})] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/settings",
						onClick: () => setOpenMobile(false)
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Settings, { className: "size-4" }), "Settings"]
				}),
				isHostedClientAuthMode() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: BILLING_ROUTE,
						onClick: () => setOpenMobile(false)
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditCard, { className: "size-4" }), "Billing"]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "Theme" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-1 pb-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemePreferenceRadio, {})
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
					variant: "destructive",
					onClick: () => signOutAndRedirect(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "size-4" }), "Sign out"]
				})
			]
		})] }) }) : ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarNavLink, {
			icon: Settings,
			label: "Settings",
			linkProps: { to: "/settings" }
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuItem, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarMenuSkeleton, { showIcon: true }) })] })
	});
}
//#endregion
//#region src/serverFunctions/config.ts
var getSeoApiKeyStatus = createServerFn({ method: "GET" }).middleware(requireAuthenticatedContext).handler(createSsrRpc("b5858986f4b26fbc7f2cea62479e3b4d97d5c4af0a61b218af88501443a3939c"));
//#endregion
//#region src/client/layout/AppShell.tsx
function AuthenticatedAppLayout({ children, projectId, ready, banner }) {
	const location = useLocation();
	const [showMissingSeoApiKeyModal, setShowMissingSeoApiKeyModal] = import_react.useState(false);
	const projectsQuery = useQuery({
		...projectsQueryOptions(),
		enabled: ready && !projectId
	});
	const rememberedProjectId = getLastProjectId();
	const fallbackProjects = projectsQuery.data ?? [];
	const fallbackProjectId = fallbackProjects.find((project) => project.id === rememberedProjectId)?.id ?? fallbackProjects[0]?.id ?? null;
	const sidebarProjectId = projectId ?? fallbackProjectId ?? rememberedProjectId;
	const sidebarProjectPending = sidebarProjectId === null && projectsQuery.isPending;
	const shouldCheckSeoApiKeyStatus = location.pathname !== "/billing" && location.pathname !== dataforseoHelpLinkOptions.to;
	const seoApiKeyStatusQuery = useQuery({
		queryKey: ["seoApiKeyStatus"],
		queryFn: () => getSeoApiKeyStatus(),
		enabled: ready && shouldCheckSeoApiKeyStatus
	});
	const isSeoApiKeyConfigured = shouldCheckSeoApiKeyStatus ? seoApiKeyStatusQuery.data?.configured ?? null : null;
	const seoApiKeyStatusError = shouldCheckSeoApiKeyStatus && seoApiKeyStatusQuery.isError;
	import_react.useEffect(() => {
		if (!shouldCheckSeoApiKeyStatus) {
			setShowMissingSeoApiKeyModal(false);
			return;
		}
		if (seoApiKeyStatusQuery.isError) {
			setShowMissingSeoApiKeyModal(false);
			return;
		}
		if (!seoApiKeyStatusQuery.isSuccess) return;
		setShowMissingSeoApiKeyModal(!seoApiKeyStatusQuery.data.configured);
	}, [
		location.pathname,
		seoApiKeyStatusQuery.data,
		seoApiKeyStatusQuery.isError,
		seoApiKeyStatusQuery.isSuccess,
		shouldCheckSeoApiKeyStatus
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarProvider, {
		className: "h-[100dvh] min-h-0 overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {
				projectId: sidebarProjectId,
				projectPending: sidebarProjectPending,
				ready
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SidebarInset, {
				className: "min-h-0 overflow-hidden md:!m-0 md:!mt-2 md:!rounded-none md:!rounded-tl-lg md:border-l md:border-t md:border-sidebar-border md:!shadow-none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MobileTopBar, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeoApiStatusBanners, {
						shouldShowSeoApiWarning: !seoApiKeyStatusError && isSeoApiKeyConfigured === false && !showMissingSeoApiKeyModal,
						seoApiKeyStatusError
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LegacyDockerBanner, {}),
					banner,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "min-h-0 flex-1 overflow-auto",
						children
					})
				]
			}),
			showMissingSeoApiKeyModal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MissingSeoSetupModal, { onClose: () => setShowMissingSeoApiKeyModal(false) }) : null,
			ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GscReEngagementModal, {
				projectId: sidebarProjectId,
				suppressed: showMissingSeoApiKeyModal
			}) : null
		]
	});
}
function MobileTopBar() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex shrink-0 items-center gap-1 border-b border-border bg-card px-2 py-1.5 md:hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SidebarTrigger, { "aria-label": "Toggle sidebar" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/",
			className: "ml-1 font-semibold text-foreground",
			children: "OpenSEO"
		})]
	});
}
//#endregion
//#region src/client/features/onboarding/useOnboardingRedirect.ts
function useOnboardingRedirect() {
	const navigate = useNavigate();
	const { data: session } = useSession();
	const isHostedMode = isHostedClientAuthMode();
	const isEmailVerified = session?.user?.emailVerified === true || isEmailVerificationBypassed();
	const onboardingQuery = useQuery({
		...onboardingAnswersQueryOptions(),
		enabled: isHostedMode && Boolean(session?.user?.id) && isEmailVerified
	});
	(0, import_react.useEffect)(() => {
		if (!isHostedMode || !session?.user?.id || !isEmailVerified || onboardingQuery.isLoading || onboardingQuery.isError || onboardingQuery.data?.completedAt || window.location.pathname === "/onboarding") return;
		const redirect = getCurrentAuthRedirectFromHref(window.location.href);
		navigate({
			to: "/onboarding",
			search: {
				step: 0,
				redirect: redirect === "/" ? void 0 : redirect
			},
			replace: true
		});
	}, [
		isHostedMode,
		navigate,
		onboardingQuery.data?.completedAt,
		onboardingQuery.isError,
		onboardingQuery.isLoading,
		isEmailVerified,
		session?.user?.id
	]);
	return !isHostedMode || onboardingQuery.isError || Boolean(onboardingQuery.data?.completedAt);
}
//#endregion
//#region src/routes/_app/route.tsx?tsr-split=component
function AppRouteLayout() {
	const authGate = useHostedAuthRouteGuard();
	const isOnboarded = useOnboardingRedirect();
	const { projectId } = useParams({ strict: false });
	const ready = authGate.canRenderAuthenticatedContent;
	(0, import_react.useEffect)(() => {
		prefetchBillingAccount();
	}, []);
	if (!isOnboarded && !getLastProjectId()) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageLoading, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthenticatedAppLayout, {
		projectId,
		ready,
		banner: authGate.isHostedMode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TermsUpdateBanner, {}), projectId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FreePlanBanner, {}) : null] }) : void 0,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
	});
}
//#endregion
export { AppRouteLayout as component };
