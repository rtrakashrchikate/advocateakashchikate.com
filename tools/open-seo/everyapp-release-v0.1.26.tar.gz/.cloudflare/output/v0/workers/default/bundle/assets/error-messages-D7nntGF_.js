import { q as isErrorCode } from "./onboarding-drip-B7bIbv_6.js";
import { c as isHostedClientAuthMode, o as isEveryAppClientAuthMode } from "./auth-mode-DhGCw2Bx.js";
import { r as GATEWAY_RENDERING_NOT_SET_UP_MESSAGE } from "./audit-rendering-DCHsGIuV.js";
//#region src/client/lib/error-messages.ts
/**
* Copy for an error we did not expect. Hosted users cannot read our logs, so
* they get support; a self-hoster runs the server and can.
*/
var UNEXPECTED_ERROR_MESSAGE = isHostedClientAuthMode() ? "Something went wrong on our end. Please try again, and contact support if it keeps happening." : "Something went wrong. Please try again, or check the server logs for details.";
var STANDARD_MESSAGES = {
	UNAUTHENTICATED: "Please sign in and try again.",
	AUTH_CONFIG_MISSING: isEveryAppClientAuthMode() ? "OpenSEO can't reach your Every App gateway for this right now. An owner or admin can check its setup with pnpm everyapp status." : "OpenSEO auth is not configured. Follow the README setup steps for Cloudflare Access.",
	PAYMENT_REQUIRED: "An active hosted subscription is required before you can use OpenSEO.",
	INSUFFICIENT_CREDITS: "You don't have enough credits for this. Upgrade your plan or buy more credits to keep going.",
	PAYMENT_METHOD_REQUIRED: "We couldn't charge a card on file. Add or update your card in the billing portal, then try again.",
	PAYMENT_ACTION_REQUIRED: "Your bank needs more time or a confirmation for this charge. Check your balance in a minute; if nothing arrived, buy your first top-up with the Buy credits button, then turn on auto-reload.",
	AUDIT_RENDERING_UNAVAILABLE: isEveryAppClientAuthMode() ? GATEWAY_RENDERING_NOT_SET_UP_MESSAGE : "JavaScript rendering is not configured on this deployment. Ask your administrator to enable a renderer.",
	FORBIDDEN: "You do not have access to this resource.",
	NOT_FOUND: "The requested resource was not found.",
	AUDIT_CAPACITY_REACHED: "You've reached audit capacity for your account. Delete old audits from your projects to start a new one.",
	AUDIT_PAGE_LIMIT_EXCEEDED: `Free plan audits are limited to 50 pages. Upgrade to run larger audits.`,
	AUDIT_ALREADY_RUNNING: "You've reached the limit of audits running at once. Wait for one to finish or delete it before starting another.",
	VALIDATION_ERROR: "Please check your input and try again.",
	UNKNOWN_LOCATION: "We couldn't find that city, county, or region. Pick a location from the list, or clear the field to search the whole country.",
	CRAWL_TARGET_BLOCKED: "This crawl target is blocked by security policy.",
	BACKLINKS_BILLING_ISSUE: "The connected DataForSEO account has a billing or balance issue.",
	AI_SEARCH_BILLING_ISSUE: "The connected DataForSEO account has a billing or balance issue.",
	AI_VISIBILITY_ERROR: "The AI visibility request could not be completed. Review the tracking settings and try again.",
	DATAFORSEO_AUTH_FAILED: isEveryAppClientAuthMode() ? "DataForSEO isn't set up on your Every App gateway yet, or rejected the key it holds. An owner or admin sets it with pnpm everyapp secret set DATAFORSEO_API_KEY." : "DataForSEO rejected the credentials. Check that DATAFORSEO_API_KEY is the base64 of your DataForSEO login:password, and that the DataForSEO account is verified and has API access.",
	RATE_LIMITED: "Too many requests. Please wait and try again.",
	UPSTREAM_UNAVAILABLE: "The data provider is temporarily unavailable. Please retry in a moment.",
	CONFLICT: "This request conflicts with existing data.",
	INTERNAL_ERROR: UNEXPECTED_ERROR_MESSAGE
};
function getStandardErrorMessage(error, fallback = STANDARD_MESSAGES.INTERNAL_ERROR) {
	if (!(error instanceof Error)) return fallback;
	if (isErrorCode(error.message)) return STANDARD_MESSAGES[error.message];
	if (error.message) return error.message;
	return fallback;
}
function getErrorCode(error) {
	if (!(error instanceof Error)) return null;
	return isErrorCode(error.message) ? error.message : null;
}
//#endregion
export { getErrorCode as n, getStandardErrorMessage as r, UNEXPECTED_ERROR_MESSAGE as t };
