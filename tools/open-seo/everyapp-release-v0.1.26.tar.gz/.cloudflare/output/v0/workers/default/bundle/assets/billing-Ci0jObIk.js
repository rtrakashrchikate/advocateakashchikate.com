import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { I as BASE_PLAN_OFFER } from "./resolve-DrNDcpX6.js";
import { C as BILLING_ROUTE, O as SUBSCRIBE_ROUTE, P as isAutoReloadBudgetSpent, l as AUTO_RELOAD_DEFAULTS, u as AUTO_RELOAD_MAX_MONTHLY_USD, w as BILLING_TABS } from "./onboarding-drip-B7bIbv_6.js";
import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { _ as CircleAlert, c as Skeleton, d as useCreditBalance, f as billingAccountQueryOptions, g as EmptyState, h as ErrorState, m as queryClient, n as QueryState, t as QueryError } from "./QueryState-Q8BZIblk.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { t as queryOptions } from "./queryOptions-Dji4xsRu.js";
import { n as getErrorCode, r as getStandardErrorMessage } from "./error-messages-D7nntGF_.js";
import { n as createLucideIcon } from "./dist-fVOGIv0D.js";
import { t as ChartColumn } from "./chart-column-zsrwJRiD.js";
import { t as Download } from "./download-B-49ilLV.js";
import { t as Info } from "./info-DgK-a8-X.js";
import { V as clsx, n as buttonVariants, t as Button } from "./button-DrcZrdio.js";
import { t as TriangleAlert } from "./triangle-alert-C9SRPVjv.js";
import { r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { o as CardHeader, r as CardContent, s as CardTitle, t as Card } from "./card-CqQO-5bL.js";
import { i as createTopUpCheckout, l as setAutoReload, n as createBillingPortalSession, o as listBillingInvoices, u as setInvoiceEmails } from "./billing-DpyxgZWI.js";
import { n as useBillingUsage, t as Route } from "./billing-DXZZaR__.js";
import { n as useCanManageBilling } from "./organizationQueries-BMLHGNAs.js";
import { t as Progress } from "./progress-DlqV_aCw.js";
import { i as TabsTrigger } from "./tabs-Dm1Fimx3.js";
import { a as DataTableTabs } from "./DataTableToolbar-H0nNW-WC.js";
import { r as PageHeader } from "./PageHeader-a3_4WaC8.js";
import { a as FieldLabel, i as FieldError, r as FieldDescription, t as Field } from "./field-CjRT_5Cr.js";
import { i as InputGroupInput, n as InputGroupAddon, t as InputGroup } from "./input-group-CmFmGa25.js";
import { i as UpdateCardButton, r as AutoReloadNotice, t as ChangePlanButton } from "./PlanChange-Bb_KYLtj.js";
import { a as TableHead, i as TableCell, n as TableBody, o as TableHeader, r as TableCard, s as TableRow, t as Table } from "./table-CqwvrC02.js";
import { t as Switch } from "./switch-BumBbmWp.js";
import { A as ZIndexLayer, At as createSelector, B as selectCartesianAxisSize, Bt as isNullish, C as findAllByType, Dt as truncateByDomain, E as LabelListFromLabelProp, F as setActiveClickItemIndex, Ft as adaptEventsOfChild, G as getStackSeriesIdentifier, H as selectTicksOfGraphicalItem, Ht as isNumber, I as setActiveMouseOverItemIndex, J as selectBarGap, K as DefaultZIndexes, Kt as Layer, Lt as getPercentValue, M as selectActiveTooltipDataKey, Mt as useAppSelector, N as selectActiveTooltipIndex, Nt as resolveDefaultProps, P as mouseLeaveItem, Q as selectChartDataWithIndexesIfNotInPanoramaPosition3, Rt as interpolate, S as SetTooltipEntrySettings, St as getNormalizedStackId, T as CartesianLabelListContextProvider, Tt as getValueByDataKey, U as selectUnfilteredCartesianItems, Ut as mathSign, V as selectStackGroups, W as isStacked, Wt as noop, X as selectRootBarSize, Xt as svgPropertiesNoEventsFromUnknown, Yt as svgPropertiesNoEvents, Z as selectRootMaxBarSize, _t as getBandSizeOfAxis, a as ChartTooltipContent, b as RegisterGraphicalItemId, gt as selectChartOffsetInternal, ht as selectAxisViewBox, i as ChartTooltip, jt as useAppDispatch, k as arrayTooltipSearcher, kt as isWellBehavedNumber, l as GraphicalItemClipPath, mt as useIsPanorama, nt as useAnimationId, o as CartesianChart, ot as propsAreEqual, q as selectBarCategoryGap, rt as JavascriptAnimate, st as selectChartLayout, t as ChartContainer, u as useNeedsClip, ut as useChartLayout, vt as getBaseValueOfBar, wt as getTooltipNameProp, x as SetLegendPayload, y as SetCartesianGraphicalItem, yt as getCateCoordinateOfBar, z as selectAxisWithScale, zt as isNan } from "./chart-DyiPV1Ml.js";
import { n as Shape, t as SetErrorBarContext } from "./ErrorBarContext-DjgQ2nB3.js";
import { n as ChartXAxis, r as ChartYAxis, t as ChartGrid } from "./ChartAxes-BMklxsO9.js";
import { n as selectYAxisIdFromGraphicalItemId, t as selectXAxisIdFromGraphicalItemId } from "./graphicalItemSelectors-C-k0GNKy.js";
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ReceiptText = createLucideIcon("receipt-text", [
	["path", {
		d: "M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z",
		key: "q3az6g"
	}],
	["path", {
		d: "M14 8H8",
		key: "1l3xfs"
	}],
	["path", {
		d: "M16 12H8",
		key: "1fr5h0"
	}],
	["path", {
		d: "M13 16H8",
		key: "wsln4y"
	}]
]);
//#endregion
//#region src/client/features/billing/BillingRow.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
/**
* One setting in the billing card: its name over what is set now, and the
* action that changes it on the right. A form opened by the action goes in
* `children`, under the row, so the card stays short until someone edits.
*/
function BillingRow({ label, summary, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4 p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 space-y-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-medium",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-sm text-muted-foreground",
					children: summary
				})]
			}), action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "shrink-0",
				children: action
			}) : null]
		}), children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-w-0 flex-col gap-3 empty:hidden",
			children
		}) : null]
	});
}
//#endregion
//#region src/client/features/billing/HostedBillingContentUtils.ts
/** A whole-dollar amount typed into a billing field, within [min, max].
*  `parsed` falls back to `fallback` while the field is invalid so a pending
*  checkout link always has a usable amount. */
function parseUsdAmount(value, { min = 10, max = 99, fallback = 20 } = {}) {
	const trimmed = value.trim();
	if (!/^\d+$/.test(trimmed)) return {
		isValid: false,
		parsed: fallback
	};
	const parsed = Number(trimmed);
	const isValid = Number.isInteger(parsed) && parsed >= min && parsed <= max;
	return {
		isValid,
		parsed: isValid ? parsed : fallback
	};
}
function parseTopUpAmount(value) {
	return parseUsdAmount(value);
}
//#endregion
//#region src/client/features/billing/AutoReloadSettings.tsx
/**
* The auto-reload row of the billing summary. Collapsed, it says what is set
* and offers Turn on or Edit; the amounts open only when asked for. Turning
* on can charge the first reload right away (the server buys it before
* enabling); the button says so. A failed reload or a spent budget shows a
* notice even while collapsed, the latter with a one-click raise.
* Owner-only at the call site, as the server enforces.
*/
function AutoReloadSettings() {
	const { topUpRemaining, refillDate, autoReload: saved, autoReloadState, autoReloadPrimesOnEnable: chargesNow } = useCreditBalance();
	const on = saved?.enabled ? saved : null;
	const savedFields = () => ({
		amountUsd: String(saved?.amountUsd ?? AUTO_RELOAD_DEFAULTS.amountUsd),
		monthlyLimitUsd: String(saved?.monthlyLimitUsd ?? AUTO_RELOAD_DEFAULTS.monthlyLimitUsd)
	});
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [fields, setFields] = (0, import_react.useState)(savedFields);
	const amount = parseUsdAmount(fields.amountUsd, { fallback: saved?.amountUsd ?? AUTO_RELOAD_DEFAULTS.amountUsd });
	const budget = parseUsdAmount(fields.monthlyLimitUsd, {
		min: amount.parsed,
		max: AUTO_RELOAD_MAX_MONTHLY_USD,
		fallback: saved?.monthlyLimitUsd ?? AUTO_RELOAD_DEFAULTS.monthlyLimitUsd
	});
	const values = {
		amountUsd: amount.parsed,
		monthlyLimitUsd: budget.parsed
	};
	const isValid = amount.isValid && budget.isValid;
	const isDirty = !on || on.amountUsd !== values.amountUsd || on.monthlyLimitUsd !== values.monthlyLimitUsd;
	const budgetUnderSpend = isBudgetUnderSpend(saved, values.monthlyLimitUsd);
	const canSubmit = isValid && !budgetUnderSpend;
	const hint = hintCopy({
		saved,
		on,
		values,
		isValid,
		chargesNow,
		topUpRemaining
	});
	const mutation = useMutation({
		mutationFn: (input) => setAutoReload({ data: input }),
		meta: { errorToast: false },
		onSuccess: (_, input) => {
			queryClient.invalidateQueries({ queryKey: billingAccountQueryOptions().queryKey });
			setEditing(false);
			toast.success(input.enabled ? "Auto-reload is on" : "Auto-reload is off");
		}
	});
	const saving = mutation.isPending && Boolean(mutation.variables?.enabled);
	const turningOff = mutation.isPending && !saving;
	const save = (next) => {
		setFields({
			amountUsd: String(next.amountUsd),
			monthlyLimitUsd: String(next.monthlyLimitUsd)
		});
		mutation.mutate({
			enabled: true,
			...next
		});
	};
	const openForm = () => {
		setFields(savedFields());
		mutation.reset();
		setEditing(true);
	};
	const saveLabel = chargesNow ? `${on ? "Retry" : "Turn on"} and buy $${values.amountUsd} now` : on ? "Save" : "Turn on auto-reload";
	const notice = saved ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AutoReloadNotice, {
		saved,
		state: autoReloadState,
		canRetry: chargesNow,
		resetDate: refillDate,
		onRaise: on && !chargesNow ? (monthlyLimitUsd) => save({
			amountUsd: on.amountUsd,
			monthlyLimitUsd
		}) : void 0,
		pending: mutation.isPending
	}) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BillingRow, {
		label: "Auto-reload",
		summary: on ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "font-medium text-foreground",
				children: "On"
			}),
			" \u00B7 Adds $",
			on.amountUsd,
			" when top-ups drop to $",
			5,
			" \u00B7 $",
			on.spentUsd.toFixed(2),
			" of $",
			on.monthlyLimitUsd,
			" monthly budget used",
			refillDate ? `, resets ${refillDate}` : ""
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Off \u00B7 Buy more automatically when top-ups drop to $", 5] }),
		action: editing ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			size: "sm",
			onClick: openForm,
			children: !on ? "Turn on" : chargesNow ? "Retry" : "Edit"
		}),
		children: [notice, editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-xl space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmountField, {
						id: "auto-reload-amount",
						label: "Add each time",
						value: fields.amountUsd,
						error: amount.isValid ? void 0 : `Enter between $10\u2013$99.`,
						onChange: (value) => setFields((prev) => ({
							...prev,
							amountUsd: value
						}))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AmountField, {
						id: "auto-reload-budget",
						label: "Monthly budget",
						value: fields.monthlyLimitUsd,
						error: budget.isValid ? void 0 : `Enter between $${amount.parsed}\u2013$${AUTO_RELOAD_MAX_MONTHLY_USD}.`,
						onChange: (value) => setFields((prev) => ({
							...prev,
							monthlyLimitUsd: value
						}))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "The budget caps what you spend on top-up credits each month, including ones you buy yourself."
				}),
				hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-amber-600",
					children: hint
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							pending: saving,
							disabled: mutation.isPending || !canSubmit,
							onClick: () => isDirty || chargesNow ? save(values) : setEditing(false),
							children: saveLabel
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							disabled: mutation.isPending,
							onClick: () => setEditing(false),
							children: "Cancel"
						}),
						on ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							className: "ml-auto text-muted-foreground",
							pending: turningOff,
							disabled: mutation.isPending,
							onClick: () => mutation.mutate({ enabled: false }),
							children: "Turn off auto-reload"
						}) : null
					]
				}),
				mutation.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: getStandardErrorMessage(mutation.error, "We couldn't save auto-reload. Please try again.")
					}), getErrorCode(mutation.error) === "PAYMENT_METHOD_REQUIRED" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpdateCardButton, {}) : null]
				}) : null
			]
		}) : null]
	});
}
function isBudgetUnderSpend(saved, monthlyLimitUsd) {
	return saved !== null && saved.spentUsd > 0 && isAutoReloadBudgetSpent(saved.spentUsd, monthlyLimitUsd);
}
/** The amber line under the fields: a budget the spend has reached (unless
*  the notice above already says it), else what saving charges now. */
function hintCopy({ saved, on, values, isValid, chargesNow, topUpRemaining }) {
	if (saved && isBudgetUnderSpend(saved, values.monthlyLimitUsd) && (!on || values.monthlyLimitUsd !== on.monthlyLimitUsd)) return `You've already spent $${saved.spentUsd.toFixed(2)} on top-up credits this month. Set a budget of at least $${Math.ceil(saved.spentUsd + 5)} to keep going.`;
	if (!chargesNow || !isValid) return null;
	if (on) return `Retrying charges your card $${values.amountUsd} now.`;
	if (topUpRemaining > 0) return `Your top-up credits are already at $${topUpRemaining.toFixed(2)}, so turning this on buys $${values.amountUsd} now.`;
	return `You have no top-up credits yet, so turning this on buys $${values.amountUsd} now. They're used after your monthly credits run out.`;
}
function AmountField({ id, label, value, error, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
		"data-invalid": error !== void 0,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
				htmlFor: id,
				className: "text-xs",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InputGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, { children: "$" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupInput, {
				id,
				type: "number",
				step: 1,
				inputMode: "numeric",
				"aria-invalid": error !== void 0,
				value,
				onChange: (event) => onChange(event.target.value)
			})] }),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: error }) : null
		]
	});
}
//#endregion
//#region src/client/features/billing/BillingInvoices.tsx
var dateFormat = {
	day: "numeric",
	month: "short",
	year: "numeric"
};
function formatDate(epochMs) {
	return new Date(epochMs).toLocaleDateString(void 0, dateFormat);
}
function formatAmount(total, currency) {
	return new Intl.NumberFormat(void 0, {
		style: "currency",
		currency: currency.toUpperCase()
	}).format(total);
}
var invoicesQueryOptions = queryOptions({
	queryKey: ["billing", "invoices"],
	queryFn: () => listBillingInvoices()
});
/** Invoice emails and the newest invoices, the billing Invoices tab.
*  Owner-only at the call site, as the server enforces: invoices show the
*  billing address. */
function BillingInvoices({ invoiceEmailsEnabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceEmailsToggle, { invoiceEmailsEnabled }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InvoiceTable, {})]
	});
}
function InvoiceEmailsToggle({ invoiceEmailsEnabled }) {
	const mutation = useMutation({
		mutationFn: (enabled) => setInvoiceEmails({ data: { enabled } }),
		meta: { errorToast: false },
		onSuccess: (_, enabled) => {
			queryClient.setQueryData(billingAccountQueryOptions().queryKey, (prev) => prev ? {
				...prev,
				invoiceEmailsEnabled: enabled
			} : prev);
		}
	});
	const checked = mutation.isPending ? mutation.variables : invoiceEmailsEnabled;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
				id: "billing-invoice-emails",
				checked,
				disabled: mutation.isPending,
				onCheckedChange: (enabled) => mutation.mutate(enabled)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
				htmlFor: "billing-invoice-emails",
				children: "Email me a receipt for each invoice"
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: "Stripe sends the receipt to the billing email on your account after each payment." }),
		mutation.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			role: "alert",
			className: "text-sm text-destructive",
			children: getStandardErrorMessage(mutation.error, "We couldn't save this setting. Please try again.")
		}) : null
	] });
}
function InvoiceTable() {
	const invoicesQuery = useQuery(invoicesQueryOptions);
	if (invoicesQuery.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-busy": true,
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-full" })
		]
	});
	if (invoicesQuery.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
		error: invoicesQuery.error,
		fallback: "We couldn't load your invoices. Please try again.",
		onRetry: () => void invoicesQuery.refetch(),
		isRetrying: invoicesQuery.isFetching
	});
	const { invoices, hasMore } = invoicesQuery.data;
	if (invoices.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		variant: "plain",
		icon: ReceiptText,
		title: "No invoices yet",
		description: "Invoices for your plan and credit purchases show up here."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Invoice" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Date" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Billing period" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Amount" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Download"
			}) })
		] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: invoices.map((invoice) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "font-medium",
				children: invoice.number ?? "\u2014"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: formatDate(invoice.createdAt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "whitespace-nowrap",
				children: invoice.periodStart !== null && invoice.periodEnd !== null ? `${formatDate(invoice.periodStart)} \u2013 ${formatDate(invoice.periodEnd)}` : "\u2014"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "tabular-nums",
				children: formatAmount(invoice.total, invoice.currency)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "capitalize",
				children: invoice.status
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-right",
				children: invoice.pdfUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: invoice.pdfUrl,
					target: "_blank",
					rel: "noreferrer",
					className: buttonVariants({
						variant: "outline",
						size: "sm"
					}),
					"aria-label": `Download ${invoice.number ?? "invoice"} PDF`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "PDF"]
				}) : null
			})
		] }, invoice.id)) })] }), hasMore ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted-foreground",
			children: "Showing your newest invoices. Find older invoices under Manage subscription."
		}) : null]
	});
}
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/component/Cell.js
/**
* Cell component used to define colors and styles of chart elements.
*
* This component is now deprecated and will be removed in Recharts 4.0.
*
* Please use the `shape` prop or `content` prop on the respective chart components
* to customize the rendering of chart elements instead of using `Cell`.
*
* @see {@link https://recharts.github.io/en-US/guide/cell/ Guide: Migrate from Cell component to shape prop}
*
* @deprecated
* @consumes CellReader
*/
var Cell = (_props) => null;
Cell.displayName = "Cell";
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/context/tooltipContext.js
/**
* Some graphical items choose to provide more information to the tooltip
* and some do not.
*/
var useMouseEnterItemDispatch = (onMouseEnterFromProps, dataKey, graphicalItemId) => {
	var dispatch = useAppDispatch();
	return (data, index) => (event) => {
		onMouseEnterFromProps === null || onMouseEnterFromProps === void 0 || onMouseEnterFromProps(data, index, event);
		dispatch(setActiveMouseOverItemIndex({
			activeIndex: String(index),
			activeDataKey: dataKey,
			activeCoordinate: data.tooltipPosition,
			activeGraphicalItemId: graphicalItemId
		}));
	};
};
var useMouseLeaveItemDispatch = (onMouseLeaveFromProps) => {
	var dispatch = useAppDispatch();
	return (data, index) => (event) => {
		onMouseLeaveFromProps === null || onMouseLeaveFromProps === void 0 || onMouseLeaveFromProps(data, index, event);
		dispatch(mouseLeaveItem());
	};
};
var useMouseClickItemDispatch = (onMouseClickFromProps, dataKey, graphicalItemId) => {
	var dispatch = useAppDispatch();
	return (data, index) => (event) => {
		onMouseClickFromProps === null || onMouseClickFromProps === void 0 || onMouseClickFromProps(data, index, event);
		dispatch(setActiveClickItemIndex({
			activeIndex: String(index),
			activeDataKey: dataKey,
			activeCoordinate: data.tooltipPosition,
			activeGraphicalItemId: graphicalItemId
		}));
	};
};
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/state/selectors/combiners/combineBarSizeList.js
var getBarSize = (globalSize, totalSize, selfSize) => {
	var barSize = selfSize !== null && selfSize !== void 0 ? selfSize : globalSize;
	if (isNullish(barSize)) return;
	return getPercentValue(barSize, totalSize, 0);
};
var combineBarSizeList = (allBars, globalSize, totalSize) => {
	var initialValue = {};
	var stackedBars = allBars.filter(isStacked);
	var unstackedBars = allBars.filter((b) => b.stackId == null);
	var groupByStack = stackedBars.reduce((acc, bar) => {
		var s = acc[bar.stackId];
		if (s == null) s = [];
		s.push(bar);
		acc[bar.stackId] = s;
		return acc;
	}, initialValue);
	var stackedSizeList = Object.entries(groupByStack).map((_ref) => {
		var _bars$;
		var [stackId, bars] = _ref;
		return {
			stackId,
			dataKeys: bars.map((b) => b.dataKey),
			barSize: getBarSize(globalSize, totalSize, (_bars$ = bars[0]) === null || _bars$ === void 0 ? void 0 : _bars$.barSize)
		};
	});
	var unstackedSizeList = unstackedBars.map((b) => {
		return {
			stackId: void 0,
			dataKeys: [b.dataKey].filter((dk) => dk != null),
			barSize: getBarSize(globalSize, totalSize, b.barSize)
		};
	});
	return [...stackedSizeList, ...unstackedSizeList];
};
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/state/selectors/combiners/combineAllBarPositions.js
function ownKeys$1(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread$1(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys$1(Object(t), !0).forEach(function(r) {
			_defineProperty$1(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys$1(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty$1(e, r, t) {
	return (r = _toPropertyKey$1(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey$1(t) {
	var i = _toPrimitive$1(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive$1(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function getBarPositions(barGap, barCategoryGap, bandSize, sizeList, maxBarSize) {
	var _sizeList$;
	var len = sizeList.length;
	if (len < 1) return;
	var realBarGap = getPercentValue(barGap, bandSize, 0, true);
	var result;
	var initialValue = [];
	if (isWellBehavedNumber((_sizeList$ = sizeList[0]) === null || _sizeList$ === void 0 ? void 0 : _sizeList$.barSize)) {
		var useFull = false;
		var fullBarSize = bandSize / len;
		var sum = sizeList.reduce((res, entry) => res + (entry.barSize || 0), 0);
		sum += (len - 1) * realBarGap;
		if (sum >= bandSize) {
			sum -= (len - 1) * realBarGap;
			realBarGap = 0;
		}
		if (sum >= bandSize && fullBarSize > 0) {
			useFull = true;
			fullBarSize *= .9;
			sum = len * fullBarSize;
		}
		var prev = {
			offset: ((bandSize - sum) / 2 >> 0) - realBarGap,
			size: 0
		};
		result = sizeList.reduce((res, entry) => {
			var _entry$barSize;
			var newPosition = {
				stackId: entry.stackId,
				dataKeys: entry.dataKeys,
				position: {
					offset: prev.offset + prev.size + realBarGap,
					size: useFull ? fullBarSize : (_entry$barSize = entry.barSize) !== null && _entry$barSize !== void 0 ? _entry$barSize : 0
				}
			};
			var newRes = [...res, newPosition];
			prev = newPosition.position;
			return newRes;
		}, initialValue);
	} else {
		var _offset = getPercentValue(barCategoryGap, bandSize, 0, true);
		if (bandSize - 2 * _offset - (len - 1) * realBarGap <= 0) realBarGap = 0;
		var originalSize = (bandSize - 2 * _offset - (len - 1) * realBarGap) / len;
		if (originalSize > 1) originalSize >>= 0;
		var size = isWellBehavedNumber(maxBarSize) ? Math.min(originalSize, maxBarSize) : originalSize;
		result = sizeList.reduce((res, entry, i) => [...res, {
			stackId: entry.stackId,
			dataKeys: entry.dataKeys,
			position: {
				offset: _offset + (originalSize + realBarGap) * i + (originalSize - size) / 2,
				size
			}
		}], initialValue);
	}
	return result;
}
var combineAllBarPositions = (sizeList, globalMaxBarSize, barGap, barCategoryGap, barBandSize, bandSize, childMaxBarSize) => {
	var maxBarSize = isNullish(childMaxBarSize) ? globalMaxBarSize : childMaxBarSize;
	var allBarPositions = getBarPositions(barGap, barCategoryGap, barBandSize !== bandSize ? barBandSize : bandSize, sizeList, maxBarSize);
	if (barBandSize !== bandSize && allBarPositions != null) allBarPositions = allBarPositions.map((pos) => _objectSpread$1(_objectSpread$1({}, pos), {}, { position: _objectSpread$1(_objectSpread$1({}, pos.position), {}, { offset: pos.position.offset - barBandSize / 2 }) }));
	return allBarPositions;
};
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/state/selectors/combiners/combineStackedData.js
var combineStackedData = (stackGroups, barSettings) => {
	var stackSeriesIdentifier = getStackSeriesIdentifier(barSettings);
	if (!stackGroups || stackSeriesIdentifier == null || barSettings == null) return;
	var { stackId } = barSettings;
	if (stackId == null) return;
	var stackGroup = stackGroups[stackId];
	if (!stackGroup) return;
	var { stackedData } = stackGroup;
	if (!stackedData) return;
	return stackedData.find((sd) => sd.key === stackSeriesIdentifier);
};
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/state/selectors/combiners/combineBarPosition.js
var combineBarPosition = (allBarPositions, barSettings) => {
	if (allBarPositions == null || barSettings == null) return;
	var position = allBarPositions.find((p) => p.stackId === barSettings.stackId && barSettings.dataKey != null && p.dataKeys.includes(barSettings.dataKey));
	if (position == null) return;
	return position.position;
};
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/zIndex/getZIndexFromUnknown.js
function getZIndexFromUnknown(input, defaultZIndex) {
	if (input && typeof input === "object" && "zIndex" in input && typeof input.zIndex === "number" && isWellBehavedNumber(input.zIndex)) return input.zIndex;
	return defaultZIndex;
}
//#endregion
//#region node_modules/.pnpm/tiny-invariant@1.3.3/node_modules/tiny-invariant/dist/esm/tiny-invariant.js
var prefix = "Invariant failed";
function invariant(condition, message) {
	if (condition) return;
	throw new Error(prefix);
}
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/util/BarUtils.js
function _extends$2() {
	return _extends$2 = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends$2.apply(null, arguments);
}
function BarRectangle(props) {
	return /*#__PURE__*/ import_react.createElement(Shape, _extends$2({
		shapeType: "rectangle",
		activeClassName: "recharts-active-bar",
		inActiveClassName: "recharts-inactive-bar"
	}, props));
}
/**
* Safely gets minPointSize from the minPointSize prop if it is a function
* @param minPointSize minPointSize as passed to the Bar component
* @param defaultValue default minPointSize
* @returns minPointSize
*/
var minPointSizeCallback = function minPointSizeCallback(minPointSize) {
	var defaultValue = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
	return (value, index) => {
		if (isNumber(minPointSize)) return minPointSize;
		var isValueNumberOrNil = isNumber(value) || isNullish(value);
		if (isValueNumberOrNil) return minPointSize(value, index);
		!isValueNumberOrNil && invariant(false, "minPointSize callback function received a value with type of ".concat(typeof value, ". Currently only numbers or null/undefined are supported."));
		return defaultValue;
	};
};
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/state/selectors/barSelectors.js
var pickIsPanorama = (_state, _id, isPanorama) => isPanorama;
var pickBarId = (_state, id) => id;
var selectSynchronisedBarSettings = createSelector([selectUnfilteredCartesianItems, pickBarId], (graphicalItems, id) => graphicalItems.filter((item) => item.type === "bar").find((item) => item.id === id));
var selectMaxBarSize = createSelector([selectSynchronisedBarSettings], (barSettings) => barSettings === null || barSettings === void 0 ? void 0 : barSettings.maxBarSize);
var pickCells = (_state, _id, _isPanorama, cells) => cells;
var selectAllVisibleBars = createSelector([
	selectChartLayout,
	selectUnfilteredCartesianItems,
	selectXAxisIdFromGraphicalItemId,
	selectYAxisIdFromGraphicalItemId,
	pickIsPanorama
], (layout, allItems, xAxisId, yAxisId, isPanorama) => allItems.filter((i) => {
	if (layout === "horizontal") return i.xAxisId === xAxisId;
	return i.yAxisId === yAxisId;
}).filter((i) => i.isPanorama === isPanorama).filter((i) => i.hide === false).filter((i) => i.type === "bar"));
var selectBarStackGroups = (state, id, isPanorama) => {
	var layout = selectChartLayout(state);
	var xAxisId = selectXAxisIdFromGraphicalItemId(state, id);
	var yAxisId = selectYAxisIdFromGraphicalItemId(state, id);
	if (xAxisId == null || yAxisId == null) return;
	if (layout === "horizontal") return selectStackGroups(state, "yAxis", yAxisId, isPanorama);
	return selectStackGroups(state, "xAxis", xAxisId, isPanorama);
};
var selectBarCartesianAxisSize = (state, id) => {
	var layout = selectChartLayout(state);
	var xAxisId = selectXAxisIdFromGraphicalItemId(state, id);
	var yAxisId = selectYAxisIdFromGraphicalItemId(state, id);
	if (xAxisId == null || yAxisId == null) return;
	if (layout === "horizontal") return selectCartesianAxisSize(state, "xAxis", xAxisId);
	return selectCartesianAxisSize(state, "yAxis", yAxisId);
};
var selectBarSizeList = createSelector([
	selectAllVisibleBars,
	selectRootBarSize,
	selectBarCartesianAxisSize
], combineBarSizeList);
var selectBarBandSize = (state, id, isPanorama) => {
	var _ref, _getBandSizeOfAxis;
	var barSettings = selectSynchronisedBarSettings(state, id);
	if (barSettings == null) return 0;
	var xAxisId = selectXAxisIdFromGraphicalItemId(state, id);
	var yAxisId = selectYAxisIdFromGraphicalItemId(state, id);
	if (xAxisId == null || yAxisId == null) return 0;
	var layout = selectChartLayout(state);
	var globalMaxBarSize = selectRootMaxBarSize(state);
	var { maxBarSize: childMaxBarSize } = barSettings;
	var maxBarSize = isNullish(childMaxBarSize) ? globalMaxBarSize : childMaxBarSize;
	var axis, ticks;
	if (layout === "horizontal") {
		axis = selectAxisWithScale(state, "xAxis", xAxisId, isPanorama);
		ticks = selectTicksOfGraphicalItem(state, "xAxis", xAxisId, isPanorama);
	} else {
		axis = selectAxisWithScale(state, "yAxis", yAxisId, isPanorama);
		ticks = selectTicksOfGraphicalItem(state, "yAxis", yAxisId, isPanorama);
	}
	return (_ref = (_getBandSizeOfAxis = getBandSizeOfAxis(axis, ticks, true)) !== null && _getBandSizeOfAxis !== void 0 ? _getBandSizeOfAxis : maxBarSize) !== null && _ref !== void 0 ? _ref : 0;
};
var selectAxisBandSize = (state, id, isPanorama) => {
	var layout = selectChartLayout(state);
	var xAxisId = selectXAxisIdFromGraphicalItemId(state, id);
	var yAxisId = selectYAxisIdFromGraphicalItemId(state, id);
	if (xAxisId == null || yAxisId == null) return;
	var axis, ticks;
	if (layout === "horizontal") {
		axis = selectAxisWithScale(state, "xAxis", xAxisId, isPanorama);
		ticks = selectTicksOfGraphicalItem(state, "xAxis", xAxisId, isPanorama);
	} else {
		axis = selectAxisWithScale(state, "yAxis", yAxisId, isPanorama);
		ticks = selectTicksOfGraphicalItem(state, "yAxis", yAxisId, isPanorama);
	}
	return getBandSizeOfAxis(axis, ticks);
};
var selectAllBarPositions = createSelector([
	selectBarSizeList,
	selectRootMaxBarSize,
	selectBarGap,
	selectBarCategoryGap,
	selectBarBandSize,
	selectAxisBandSize,
	selectMaxBarSize
], combineAllBarPositions);
var selectXAxisWithScale = (state, id, isPanorama) => {
	var xAxisId = selectXAxisIdFromGraphicalItemId(state, id);
	if (xAxisId == null) return;
	return selectAxisWithScale(state, "xAxis", xAxisId, isPanorama);
};
var selectYAxisWithScale = (state, id, isPanorama) => {
	var yAxisId = selectYAxisIdFromGraphicalItemId(state, id);
	if (yAxisId == null) return;
	return selectAxisWithScale(state, "yAxis", yAxisId, isPanorama);
};
var selectXAxisTicks = (state, id, isPanorama) => {
	var xAxisId = selectXAxisIdFromGraphicalItemId(state, id);
	if (xAxisId == null) return;
	return selectTicksOfGraphicalItem(state, "xAxis", xAxisId, isPanorama);
};
var selectYAxisTicks = (state, id, isPanorama) => {
	var yAxisId = selectYAxisIdFromGraphicalItemId(state, id);
	if (yAxisId == null) return;
	return selectTicksOfGraphicalItem(state, "yAxis", yAxisId, isPanorama);
};
var selectBarPosition = createSelector([selectAllBarPositions, selectSynchronisedBarSettings], combineBarPosition);
var selectStackedDataOfItem = createSelector([selectBarStackGroups, selectSynchronisedBarSettings], combineStackedData);
var selectBarRectangles = createSelector([
	selectChartOffsetInternal,
	selectAxisViewBox,
	selectXAxisWithScale,
	selectYAxisWithScale,
	selectXAxisTicks,
	selectYAxisTicks,
	selectBarPosition,
	selectChartLayout,
	selectChartDataWithIndexesIfNotInPanoramaPosition3,
	selectAxisBandSize,
	selectStackedDataOfItem,
	selectSynchronisedBarSettings,
	pickCells
], (offset, axisViewBox, xAxis, yAxis, xAxisTicks, yAxisTicks, pos, layout, _ref2, bandSize, stackedData, barSettings, cells) => {
	var { chartData, dataStartIndex, dataEndIndex } = _ref2;
	if (barSettings == null || pos == null || axisViewBox == null || layout !== "horizontal" && layout !== "vertical" || xAxis == null || yAxis == null || xAxisTicks == null || yAxisTicks == null || bandSize == null) return;
	var { data } = barSettings;
	var displayedData;
	if (data != null && data.length > 0) displayedData = data;
	else displayedData = chartData === null || chartData === void 0 ? void 0 : chartData.slice(dataStartIndex, dataEndIndex + 1);
	if (displayedData == null) return;
	return computeBarRectangles({
		layout,
		barSettings,
		pos,
		parentViewBox: axisViewBox,
		bandSize,
		xAxis,
		yAxis,
		xAxisTicks,
		yAxisTicks,
		stackedData,
		displayedData,
		offset,
		cells,
		dataStartIndex
	});
});
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/cartesian/BarStack.js
var _excluded$1 = ["index"];
function _extends$1() {
	return _extends$1 = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends$1.apply(null, arguments);
}
function _objectWithoutProperties$1(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose$1(e, t);
	if (Object.getOwnPropertySymbols) {
		var n = Object.getOwnPropertySymbols(e);
		for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
function _objectWithoutPropertiesLoose$1(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
var BarStackContext = /*#__PURE__*/ (0, import_react.createContext)(void 0);
/**
* Hook to resolve the stack ID for a Bar component.
* If a stack ID is provided via props, it is used directly.
* Otherwise, this will read stack ID from BarStack context if available.
* If both are undefined, it returns undefined.
* @param childStackId
*/
var useStackId = (childStackId) => {
	var stackSettings = (0, import_react.useContext)(BarStackContext);
	if (stackSettings != null) return stackSettings.stackId;
	if (childStackId == null) return;
	return getNormalizedStackId(childStackId);
};
var getClipPathId = (stackId, index) => {
	return "recharts-bar-stack-clip-path-".concat(stackId, "-").concat(index);
};
var useBarStackClipPathUrl = (index) => {
	var barStackContext = (0, import_react.useContext)(BarStackContext);
	if (barStackContext == null) return;
	var { stackId } = barStackContext;
	return "url(#".concat(getClipPathId(stackId, index), ")");
};
var BarStackClipLayer = (_ref) => {
	var { index } = _ref, rest = _objectWithoutProperties$1(_ref, _excluded$1);
	var clipPathUrl = useBarStackClipPathUrl(index);
	return /*#__PURE__*/ import_react.createElement(Layer, _extends$1({
		className: "recharts-bar-stack-layer",
		clipPath: clipPathUrl
	}, rest));
};
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/cartesian/Bar.js
var _excluded = [
	"onMouseEnter",
	"onMouseLeave",
	"onClick"
];
var _excluded2 = [
	"value",
	"background",
	"tooltipPosition"
];
var _excluded3 = ["id"];
var _excluded4 = [
	"onMouseEnter",
	"onClick",
	"onMouseLeave"
];
function _extends() {
	return _extends = Object.assign ? Object.assign.bind() : function(n) {
		for (var e = 1; e < arguments.length; e++) {
			var t = arguments[e];
			for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
		}
		return n;
	}, _extends.apply(null, arguments);
}
function ownKeys(e, r) {
	var t = Object.keys(e);
	if (Object.getOwnPropertySymbols) {
		var o = Object.getOwnPropertySymbols(e);
		r && (o = o.filter(function(r) {
			return Object.getOwnPropertyDescriptor(e, r).enumerable;
		})), t.push.apply(t, o);
	}
	return t;
}
function _objectSpread(e) {
	for (var r = 1; r < arguments.length; r++) {
		var t = null != arguments[r] ? arguments[r] : {};
		r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
			_defineProperty(e, r, t[r]);
		}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
			Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
		});
	}
	return e;
}
function _defineProperty(e, r, t) {
	return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
		value: t,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}) : e[r] = t, e;
}
function _toPropertyKey(t) {
	var i = _toPrimitive(t, "string");
	return "symbol" == typeof i ? i : i + "";
}
function _toPrimitive(t, r) {
	if ("object" != typeof t || !t) return t;
	var e = t[Symbol.toPrimitive];
	if (void 0 !== e) {
		var i = e.call(t, r || "default");
		if ("object" != typeof i) return i;
		throw new TypeError("@@toPrimitive must return a primitive value.");
	}
	return ("string" === r ? String : Number)(t);
}
function _objectWithoutProperties(e, t) {
	if (null == e) return {};
	var o, r, i = _objectWithoutPropertiesLoose(e, t);
	if (Object.getOwnPropertySymbols) {
		var n = Object.getOwnPropertySymbols(e);
		for (r = 0; r < n.length; r++) o = n[r], -1 === t.indexOf(o) && {}.propertyIsEnumerable.call(e, o) && (i[o] = e[o]);
	}
	return i;
}
function _objectWithoutPropertiesLoose(r, e) {
	if (null == r) return {};
	var t = {};
	for (var n in r) if ({}.hasOwnProperty.call(r, n)) {
		if (-1 !== e.indexOf(n)) continue;
		t[n] = r[n];
	}
	return t;
}
var computeLegendPayloadFromBarData = (props) => {
	var { dataKey, name, fill, legendType, hide } = props;
	return [{
		inactive: hide,
		dataKey,
		type: legendType,
		color: fill,
		value: getTooltipNameProp(name, dataKey),
		payload: props
	}];
};
var SetBarTooltipEntrySettings = /*#__PURE__*/ import_react.memo((_ref) => {
	var { dataKey, stroke, strokeWidth, fill, name, hide, unit, tooltipType, id } = _ref;
	var tooltipEntrySettings = {
		dataDefinedOnItem: void 0,
		getPosition: noop,
		settings: {
			stroke,
			strokeWidth,
			fill,
			dataKey,
			nameKey: void 0,
			name: getTooltipNameProp(name, dataKey),
			hide,
			type: tooltipType,
			color: fill,
			unit,
			graphicalItemId: id
		}
	};
	return /*#__PURE__*/ import_react.createElement(SetTooltipEntrySettings, { tooltipEntrySettings });
});
function BarBackground(props) {
	var activeIndex = useAppSelector(selectActiveTooltipIndex);
	var { data, dataKey, background: backgroundFromProps, allOtherBarProps } = props;
	var { onMouseEnter: onMouseEnterFromProps, onMouseLeave: onMouseLeaveFromProps, onClick: onItemClickFromProps } = allOtherBarProps, restOfAllOtherProps = _objectWithoutProperties(allOtherBarProps, _excluded);
	var onMouseEnterFromContext = useMouseEnterItemDispatch(onMouseEnterFromProps, dataKey, allOtherBarProps.id);
	var onMouseLeaveFromContext = useMouseLeaveItemDispatch(onMouseLeaveFromProps);
	var onClickFromContext = useMouseClickItemDispatch(onItemClickFromProps, dataKey, allOtherBarProps.id);
	if (!backgroundFromProps || data == null) return null;
	var backgroundProps = svgPropertiesNoEventsFromUnknown(backgroundFromProps);
	return /*#__PURE__*/ import_react.createElement(ZIndexLayer, { zIndex: getZIndexFromUnknown(backgroundFromProps, DefaultZIndexes.barBackground) }, data.map((entry, i) => {
		var { value, background: backgroundFromDataEntry, tooltipPosition } = entry, rest = _objectWithoutProperties(entry, _excluded2);
		if (!backgroundFromDataEntry) return null;
		var onMouseEnter = onMouseEnterFromContext(entry, i);
		var onMouseLeave = onMouseLeaveFromContext(entry, i);
		var onClick = onClickFromContext(entry, i);
		var barRectangleProps = _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({
			option: backgroundFromProps,
			isActive: String(i) === activeIndex
		}, rest), {}, { fill: "#eee" }, backgroundFromDataEntry), backgroundProps), adaptEventsOfChild(restOfAllOtherProps, entry, i)), {}, {
			onMouseEnter,
			onMouseLeave,
			onClick,
			dataKey,
			index: i,
			className: "recharts-bar-background-rectangle"
		});
		return /*#__PURE__*/ import_react.createElement(BarRectangle, _extends({ key: "background-bar-".concat(i) }, barRectangleProps));
	}));
}
function BarLabelListProvider(_ref2) {
	var { showLabels, children, rects } = _ref2;
	var labelListEntries = rects === null || rects === void 0 ? void 0 : rects.map((entry) => {
		var viewBox = {
			x: entry.x,
			y: entry.y,
			width: entry.width,
			lowerWidth: entry.width,
			upperWidth: entry.width,
			height: entry.height
		};
		return _objectSpread(_objectSpread({}, viewBox), {}, {
			value: entry.value,
			payload: entry.payload,
			parentViewBox: entry.parentViewBox,
			viewBox,
			fill: entry.fill
		});
	});
	return /*#__PURE__*/ import_react.createElement(CartesianLabelListContextProvider, { value: showLabels ? labelListEntries : void 0 }, children);
}
function BarRectangleWithActiveState(props) {
	var { shape, activeBar, baseProps, entry, index, dataKey } = props;
	var activeIndex = useAppSelector(selectActiveTooltipIndex);
	var activeDataKey = useAppSelector(selectActiveTooltipDataKey);
	var isActive = activeBar && String(entry.originalDataIndex) === activeIndex && (activeDataKey == null || dataKey === activeDataKey);
	var [stayInLayer, setStayInLayer] = (0, import_react.useState)(false);
	var [hasMountedActive, setHasMountedActive] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		var rafId;
		if (isActive) {
			setStayInLayer(true);
			rafId = requestAnimationFrame(() => {
				setHasMountedActive(true);
			});
		} else setHasMountedActive(false);
		return () => {
			cancelAnimationFrame(rafId);
		};
	}, [isActive]);
	var handleTransitionEnd = (0, import_react.useCallback)(() => {
		if (!isActive) setStayInLayer(false);
	}, [isActive]);
	var isVisuallyActive = isActive && hasMountedActive;
	var shouldRenderInLayer = isActive || stayInLayer;
	var option;
	if (isActive) {
		if (activeBar === true) option = shape;
		else option = activeBar;
	} else option = shape;
	var content = /*#__PURE__*/ import_react.createElement(BarRectangle, _extends({}, baseProps, { name: String(baseProps.name) }, entry, {
		isActive: isVisuallyActive,
		option,
		index,
		dataKey,
		onTransitionEnd: handleTransitionEnd
	}));
	if (shouldRenderInLayer) return /*#__PURE__*/ import_react.createElement(ZIndexLayer, { zIndex: DefaultZIndexes.activeBar }, /*#__PURE__*/ import_react.createElement(BarStackClipLayer, { index: entry.originalDataIndex }, content));
	return content;
}
function BarRectangleNeverActive(props) {
	var { shape, baseProps, entry, index, dataKey } = props;
	return /*#__PURE__*/ import_react.createElement(BarRectangle, _extends({}, baseProps, { name: String(baseProps.name) }, entry, {
		isActive: false,
		option: shape,
		index,
		dataKey
	}));
}
function BarRectangles(_ref3) {
	var _svgPropertiesNoEvent;
	var { data, props } = _ref3;
	var _ref4 = (_svgPropertiesNoEvent = svgPropertiesNoEvents(props)) !== null && _svgPropertiesNoEvent !== void 0 ? _svgPropertiesNoEvent : {}, { id } = _ref4, baseProps = _objectWithoutProperties(_ref4, _excluded3);
	var { shape, dataKey, activeBar } = props;
	var { onMouseEnter: onMouseEnterFromProps, onClick: onItemClickFromProps, onMouseLeave: onMouseLeaveFromProps } = props, restOfAllOtherProps = _objectWithoutProperties(props, _excluded4);
	var onMouseEnterFromContext = useMouseEnterItemDispatch(onMouseEnterFromProps, dataKey, id);
	var onMouseLeaveFromContext = useMouseLeaveItemDispatch(onMouseLeaveFromProps);
	var onClickFromContext = useMouseClickItemDispatch(onItemClickFromProps, dataKey, id);
	if (!data) return null;
	return /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, data.map((entry, i) => {
		return /*#__PURE__*/ import_react.createElement(BarStackClipLayer, _extends({
			index: entry.originalDataIndex,
			key: "rectangle-".concat(entry === null || entry === void 0 ? void 0 : entry.x, "-").concat(entry === null || entry === void 0 ? void 0 : entry.y, "-").concat(entry === null || entry === void 0 ? void 0 : entry.value, "-").concat(i),
			className: "recharts-bar-rectangle"
		}, adaptEventsOfChild(restOfAllOtherProps, entry, i), {
			onMouseEnter: onMouseEnterFromContext(entry, i),
			onMouseLeave: onMouseLeaveFromContext(entry, i),
			onClick: onClickFromContext(entry, i)
		}), activeBar ? /*#__PURE__*/ import_react.createElement(BarRectangleWithActiveState, {
			shape,
			activeBar,
			baseProps,
			entry,
			index: i,
			dataKey
		}) : /*#__PURE__*/ import_react.createElement(BarRectangleNeverActive, {
			shape,
			baseProps,
			entry,
			index: i,
			dataKey
		}));
	}));
}
function RectanglesWithAnimation(_ref5) {
	var { props, previousRectanglesRef } = _ref5;
	var { data, layout, isAnimationActive, animationBegin, animationDuration, animationEasing, onAnimationEnd, onAnimationStart } = props;
	var prevData = previousRectanglesRef.current;
	var animationId = useAnimationId(props, "recharts-bar-");
	var [isAnimating, setIsAnimating] = (0, import_react.useState)(false);
	var showLabels = !isAnimating;
	var handleAnimationEnd = (0, import_react.useCallback)(() => {
		if (typeof onAnimationEnd === "function") onAnimationEnd();
		setIsAnimating(false);
	}, [onAnimationEnd]);
	var handleAnimationStart = (0, import_react.useCallback)(() => {
		if (typeof onAnimationStart === "function") onAnimationStart();
		setIsAnimating(true);
	}, [onAnimationStart]);
	return /*#__PURE__*/ import_react.createElement(BarLabelListProvider, {
		showLabels,
		rects: data
	}, /*#__PURE__*/ import_react.createElement(JavascriptAnimate, {
		animationId,
		begin: animationBegin,
		duration: animationDuration,
		isActive: isAnimationActive,
		easing: animationEasing,
		onAnimationEnd: handleAnimationEnd,
		onAnimationStart: handleAnimationStart,
		key: animationId
	}, (t) => {
		var stepData = t === 1 ? data : data === null || data === void 0 ? void 0 : data.map((entry, index) => {
			var prev = prevData && prevData[index];
			if (prev) return _objectSpread(_objectSpread({}, entry), {}, {
				x: interpolate(prev.x, entry.x, t),
				y: interpolate(prev.y, entry.y, t),
				width: interpolate(prev.width, entry.width, t),
				height: interpolate(prev.height, entry.height, t)
			});
			if (layout === "horizontal") {
				var height = interpolate(0, entry.height, t);
				var y = interpolate(entry.stackedBarStart, entry.y, t);
				return _objectSpread(_objectSpread({}, entry), {}, {
					y,
					height
				});
			}
			var w = interpolate(0, entry.width, t);
			var x = interpolate(entry.stackedBarStart, entry.x, t);
			return _objectSpread(_objectSpread({}, entry), {}, {
				width: w,
				x
			});
		});
		if (t > 0) previousRectanglesRef.current = stepData !== null && stepData !== void 0 ? stepData : null;
		if (stepData == null) return null;
		return /*#__PURE__*/ import_react.createElement(Layer, null, /*#__PURE__*/ import_react.createElement(BarRectangles, {
			props,
			data: stepData
		}));
	}), /*#__PURE__*/ import_react.createElement(LabelListFromLabelProp, { label: props.label }), props.children);
}
function RenderRectangles(props) {
	var previousRectanglesRef = (0, import_react.useRef)(null);
	return /*#__PURE__*/ import_react.createElement(RectanglesWithAnimation, {
		previousRectanglesRef,
		props
	});
}
var defaultMinPointSize = 0;
var errorBarDataPointFormatter = (dataPoint, dataKey) => {
	/**
	* if the value coming from `selectBarRectangles` is an array then this is a stacked bar chart.
	* arr[1] represents end value of the bar since the data is in the form of [startValue, endValue].
	* */
	var value = Array.isArray(dataPoint.value) ? dataPoint.value[1] : dataPoint.value;
	return {
		x: dataPoint.x,
		y: dataPoint.y,
		value,
		errorVal: getValueByDataKey(dataPoint, dataKey)
	};
};
var BarWithState = class extends import_react.PureComponent {
	render() {
		var { hide, data, dataKey, className, xAxisId, yAxisId, needClip, background, id } = this.props;
		if (hide || data == null) return null;
		var layerClass = clsx("recharts-bar", className);
		var clipPathId = id;
		return /*#__PURE__*/ import_react.createElement(Layer, {
			className: layerClass,
			id
		}, needClip && /*#__PURE__*/ import_react.createElement("defs", null, /*#__PURE__*/ import_react.createElement(GraphicalItemClipPath, {
			clipPathId,
			xAxisId,
			yAxisId
		})), /*#__PURE__*/ import_react.createElement(Layer, {
			className: "recharts-bar-rectangles",
			clipPath: needClip ? "url(#clipPath-".concat(clipPathId, ")") : void 0
		}, /*#__PURE__*/ import_react.createElement(BarBackground, {
			data,
			dataKey,
			background,
			allOtherBarProps: this.props
		}), /*#__PURE__*/ import_react.createElement(RenderRectangles, this.props)));
	}
};
var defaultBarProps = {
	activeBar: false,
	animationBegin: 0,
	animationDuration: 400,
	animationEasing: "ease",
	background: false,
	hide: false,
	isAnimationActive: "auto",
	label: false,
	legendType: "rect",
	minPointSize: defaultMinPointSize,
	xAxisId: 0,
	yAxisId: 0,
	zIndex: DefaultZIndexes.bar
};
function BarImpl(props) {
	var { xAxisId, yAxisId, hide, legendType, minPointSize, activeBar, animationBegin, animationDuration, animationEasing, isAnimationActive } = props;
	var { needClip } = useNeedsClip(xAxisId, yAxisId);
	var layout = useChartLayout();
	var isPanorama = useIsPanorama();
	var cells = findAllByType(props.children, Cell);
	var rects = useAppSelector((state) => selectBarRectangles(state, props.id, isPanorama, cells));
	if (layout !== "vertical" && layout !== "horizontal") return null;
	var errorBarOffset;
	var firstDataPoint = rects === null || rects === void 0 ? void 0 : rects[0];
	if (firstDataPoint == null || firstDataPoint.height == null || firstDataPoint.width == null) errorBarOffset = 0;
	else errorBarOffset = layout === "vertical" ? firstDataPoint.height / 2 : firstDataPoint.width / 2;
	return /*#__PURE__*/ import_react.createElement(SetErrorBarContext, {
		xAxisId,
		yAxisId,
		data: rects,
		dataPointFormatter: errorBarDataPointFormatter,
		errorBarOffset
	}, /*#__PURE__*/ import_react.createElement(BarWithState, _extends({}, props, {
		layout,
		needClip,
		data: rects,
		xAxisId,
		yAxisId,
		hide,
		legendType,
		minPointSize,
		activeBar,
		animationBegin,
		animationDuration,
		animationEasing,
		isAnimationActive
	})));
}
function computeBarRectangles(_ref6) {
	var { layout, barSettings: { dataKey, minPointSize: minPointSizeProp, hasCustomShape }, pos, bandSize, xAxis, yAxis, xAxisTicks, yAxisTicks, stackedData, displayedData, offset, cells, parentViewBox, dataStartIndex } = _ref6;
	var numericAxis = layout === "horizontal" ? yAxis : xAxis;
	var stackedDomain = stackedData ? numericAxis.scale.domain() : null;
	var baseValue = getBaseValueOfBar({ numericAxis });
	var stackedBarStart = numericAxis.scale.map(baseValue);
	return displayedData.map((entry, index) => {
		var value, x, y, width, height, background;
		if (stackedData) {
			var untruncatedValue = stackedData[index + dataStartIndex];
			if (untruncatedValue == null) return null;
			value = truncateByDomain(untruncatedValue, stackedDomain);
		} else {
			value = getValueByDataKey(entry, dataKey);
			if (!Array.isArray(value)) value = [baseValue, value];
		}
		var minPointSize = minPointSizeCallback(minPointSizeProp, defaultMinPointSize)(value[1], index);
		if (layout === "horizontal") {
			var _ref7;
			var baseValueScale = yAxis.scale.map(value[0]);
			var currentValueScale = yAxis.scale.map(value[1]);
			if (baseValueScale == null || currentValueScale == null) return null;
			x = getCateCoordinateOfBar({
				axis: xAxis,
				ticks: xAxisTicks,
				bandSize,
				offset: pos.offset,
				entry,
				index
			});
			y = (_ref7 = currentValueScale !== null && currentValueScale !== void 0 ? currentValueScale : baseValueScale) !== null && _ref7 !== void 0 ? _ref7 : void 0;
			width = pos.size;
			var computedHeight = baseValueScale - currentValueScale;
			height = isNan(computedHeight) ? 0 : computedHeight;
			background = {
				x,
				y: offset.top,
				width,
				height: offset.height
			};
			if (Math.abs(minPointSize) > 0 && Math.abs(height) < Math.abs(minPointSize)) {
				var delta = mathSign(height || minPointSize) * (Math.abs(minPointSize) - Math.abs(height));
				y -= delta;
				height += delta;
			}
		} else {
			var _baseValueScale = xAxis.scale.map(value[0]);
			var _currentValueScale = xAxis.scale.map(value[1]);
			if (_baseValueScale == null || _currentValueScale == null) return null;
			x = _baseValueScale;
			y = getCateCoordinateOfBar({
				axis: yAxis,
				ticks: yAxisTicks,
				bandSize,
				offset: pos.offset,
				entry,
				index
			});
			width = _currentValueScale - _baseValueScale;
			height = pos.size;
			background = {
				x: offset.left,
				y,
				width: offset.width,
				height
			};
			if (Math.abs(minPointSize) > 0 && Math.abs(width) < Math.abs(minPointSize)) {
				var _delta = mathSign(width || minPointSize) * (Math.abs(minPointSize) - Math.abs(width));
				width += _delta;
			}
		}
		if (x == null || y == null || width == null || height == null || !hasCustomShape && (width === 0 || height === 0)) return null;
		return _objectSpread(_objectSpread({}, entry), {}, {
			stackedBarStart,
			x,
			y,
			width,
			height,
			value: stackedData ? value : value[1],
			payload: entry,
			background,
			tooltipPosition: {
				x: x + width / 2,
				y: y + height / 2
			},
			parentViewBox,
			originalDataIndex: index
		}, cells && cells[index] && cells[index].props);
	}).filter(Boolean);
}
function BarFn(outsideProps) {
	var props = resolveDefaultProps(outsideProps, defaultBarProps);
	var stackId = useStackId(props.stackId);
	var isPanorama = useIsPanorama();
	return /*#__PURE__*/ import_react.createElement(RegisterGraphicalItemId, {
		id: props.id,
		type: "bar"
	}, (id) => /*#__PURE__*/ import_react.createElement(import_react.Fragment, null, /*#__PURE__*/ import_react.createElement(SetLegendPayload, { legendPayload: computeLegendPayloadFromBarData(props) }), /*#__PURE__*/ import_react.createElement(SetBarTooltipEntrySettings, {
		dataKey: props.dataKey,
		stroke: props.stroke,
		strokeWidth: props.strokeWidth,
		fill: props.fill,
		name: props.name,
		hide: props.hide,
		unit: props.unit,
		tooltipType: props.tooltipType,
		id
	}), /*#__PURE__*/ import_react.createElement(SetCartesianGraphicalItem, {
		type: "bar",
		id,
		data: void 0,
		xAxisId: props.xAxisId,
		yAxisId: props.yAxisId,
		zAxisId: 0,
		dataKey: props.dataKey,
		stackId,
		hide: props.hide,
		barSize: props.barSize,
		minPointSize: props.minPointSize,
		maxBarSize: props.maxBarSize,
		isPanorama,
		hasCustomShape: props.shape != null
	}), /*#__PURE__*/ import_react.createElement(ZIndexLayer, { zIndex: props.zIndex }, /*#__PURE__*/ import_react.createElement(BarImpl, _extends({}, props, { id })))));
}
/**
* @provides ErrorBarContext
* @provides LabelListContext
* @provides CellReader
* @consumes CartesianChartContext
* @consumes BarStackContext
*/
var Bar = /*#__PURE__*/ import_react.memo(BarFn, propsAreEqual);
Bar.displayName = "Bar";
//#endregion
//#region node_modules/.pnpm/recharts@3.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react-is@19.2.6_react@19.2.4_redux@5.0.1/node_modules/recharts/es6/chart/BarChart.js
var allowedTooltipTypes = ["axis", "item"];
/**
* @consumes ResponsiveContainerContext
* @provides CartesianViewBoxContext
* @provides CartesianChartContext
*/
var BarChart = /*#__PURE__*/ (0, import_react.forwardRef)((props, ref) => {
	return /*#__PURE__*/ import_react.createElement(CartesianChart, {
		chartName: "BarChart",
		defaultTooltipEventType: "axis",
		validateTooltipEventTypes: allowedTooltipTypes,
		tooltipPayloadSearcher: arrayTooltipSearcher,
		categoricalChartProps: props,
		ref
	});
});
//#endregion
//#region src/client/features/billing/BillingUsage.tsx
var PROJECT_USAGE_COMPLETE_AT = Date.parse("2026-12-02T00:00:00Z");
var chartConfig = { usd: {
	label: "Usage",
	color: "var(--chart-1)"
} };
/** The billing Usage tab: the last 30 days by day, feature and project. */
function BillingUsage() {
	const usageQuery = useBillingUsage();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
		query: usageQuery,
		errorFallback: "Failed to load usage",
		loading: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsageSkeleton, {}),
		children: (usage) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsageReport, { usage })
	});
}
function UsageReport({ usage }) {
	const totalUsd = usage.days.reduce((sum, day) => sum + day.usd, 0);
	if (totalUsd === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		variant: "plain",
		icon: ChartColumn,
		title: "No usage recorded yet",
		description: "What you spend over the last 30 days shows up here, by day, feature and project."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: "Spent in the last 30 days"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-2xl font-semibold tracking-tight tabular-nums",
					children: ["$", totalUsd.toFixed(2)]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UsageChart, { days: usage.days })]
			}),
			Date.now() < PROJECT_USAGE_COMPLETE_AT ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "Project tracking started Nov 1, so earlier usage shows as Workspace." })] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-8 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Breakdown, {
					title: "Usage by feature",
					rows: usage.features
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Breakdown, {
					title: "Usage by project",
					rows: usage.projects
				})]
			})
		]
	});
}
function UsageChart({ days }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "h-40 w-full min-w-0",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartContainer, {
			config: chartConfig,
			className: "h-full",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
				data: days,
				margin: {
					top: 4,
					right: 0,
					bottom: 0,
					left: 0
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartGrid, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartXAxis, {
						dataKey: "date",
						tickFormatter: formatShortDate,
						minTickGap: 40
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartYAxis, { tickFormatter: formatUsdAxis }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltip, { content: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartTooltipContent, {
						labelFormatter: (label) => typeof label === "number" ? formatShortDate(label) : "",
						valueFormatter: (value) => `$${Number(value).toFixed(2)}`
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
						dataKey: "usd",
						fill: "var(--color-usd)",
						radius: [
							2,
							2,
							0,
							0
						],
						maxBarSize: 12
					})
				]
			})
		})
	});
}
function Breakdown({ title, rows }) {
	const total = rows.reduce((sum, row) => sum + row.usd, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-sm font-medium",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-3",
			children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-4 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "min-w-0 truncate",
						children: row.label
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted-foreground tabular-nums",
						children: ["$", row.usd.toFixed(2)]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1.5 w-full overflow-hidden rounded-full bg-muted",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-chart-1",
						style: { width: `${row.usd / total * 100}%` }
					})
				})]
			}, row.label))
		})]
	});
}
function UsageSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		"aria-busy": true,
		className: "space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-32" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-7 w-20" })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-40 w-full" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-8 md:grid-cols-2",
			children: [0, 1].map((column) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: [
					0,
					1,
					2,
					3
				].map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-full" }, row))
			}, column))
		})]
	});
}
function formatShortDate(timestamp) {
	return new Date(timestamp).toLocaleDateString("en-US", {
		month: "short",
		day: "numeric"
	});
}
function formatUsdAxis(value) {
	return `$${value % 1 === 0 ? value : value.toFixed(2)}`;
}
//#endregion
//#region src/client/features/billing/BillingTabs.tsx
/**
* Usage and, for owners, invoices in one card with a tab row. Members see
* usage alone: invoices follow the billing permission.
*/
function BillingTabs({ tab, onTabChange, invoiceEmailsEnabled }) {
	const showInvoices = invoiceEmailsEnabled !== null && tab === "invoices";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCard, { children: [invoiceEmailsEnabled !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableTabs, {
		value: tab,
		onValueChange: (value) => {
			const next = BILLING_TABS.find((item) => item.value === value);
			if (next) onTabChange(next.value);
		},
		children: BILLING_TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
			value: item.value,
			children: item.label
		}, item.value))
	}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-4",
		children: showInvoices ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillingInvoices, { invoiceEmailsEnabled }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillingUsage, {})
	})] });
}
//#endregion
//#region src/client/features/billing/CreditsCard.tsx
/** What is left to spend: the total first, then the monthly credits against
*  the plan's allowance and the top-up credits. The ways to get more credits
*  (`children`, BillingRows) sit under it in the same card. */
function CreditsCard({ children }) {
	const { accountQuery, isFreePlan, monthlyRemaining, topUpRemaining, totalRemaining, isOutOfCredits, isLowCredits, refillDate } = useCreditBalance();
	const monthlyCreditsUsd = accountQuery.data?.monthlyCreditsUsd ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "gap-0 pb-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Credits" }) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-x-12 gap-y-5 pt-4 pb-4 md:grid-cols-2 md:items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex items-baseline gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-3xl font-semibold tracking-tight tabular-nums",
							children: ["$", totalRemaining.toFixed(2)]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm text-muted-foreground",
							children: "remaining"
						})]
					}), isOutOfCredits ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex gap-1.5 text-sm text-red-700 dark:text-destructive",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {
							"aria-hidden": true,
							className: "mt-0.5 size-4 shrink-0"
						}), isFreePlan ? "You\u2019ve used your free credits. Upgrade your plan to continue." : `You\u2019ve used this month\u2019s credits. Buy more below to keep going${refillDate ? `, or wait for them to refill on ${refillDate}` : ""}.`]
					}) : isLowCredits ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "flex gap-1.5 text-sm text-amber-700 dark:text-amber-500",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
							"aria-hidden": true,
							className: "mt-0.5 size-4 shrink-0"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"You\u2019re running low on credits.",
							" ",
							isFreePlan ? `Upgrade to get $${BASE_PLAN_OFFER.monthlyCreditsUsd}/month.` : "Buy more credits below."
						] })]
					}) : isFreePlan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Your free credits don\u2019t refill."
					}) : null]
				}), isFreePlan ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BalanceLine, {
								label: "Monthly",
								children: [
									"$",
									monthlyRemaining.toFixed(2),
									monthlyCreditsUsd > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted-foreground",
										children: [
											" ",
											"of $",
											monthlyCreditsUsd.toFixed(2)
										]
									}) : null
								]
							}),
							monthlyCreditsUsd > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
								"aria-label": "Monthly credits left",
								value: Math.min(monthlyRemaining / monthlyCreditsUsd, 1) * 100
							}) : null,
							refillDate ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted-foreground",
								children: ["Refills ", refillDate]
							}) : null
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BalanceLine, {
						label: "Top-ups",
						children: ["$", topUpRemaining.toFixed(2)]
					})]
				})]
			}),
			children ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "divide-y divide-border border-t border-border",
				children
			}) : null
		]
	});
}
function BalanceLine({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "flex items-baseline justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums",
			children
		})]
	});
}
//#endregion
//#region src/routes/_app/billing.tsx?tsr-split=component
function BillingPage() {
	const { tab } = Route.useSearch();
	const navigate = useNavigate();
	const [topUpAmount, setTopUpAmount] = (0, import_react.useState)("20");
	const [buyingCredits, setBuyingCredits] = (0, import_react.useState)(false);
	const [pendingAction, setPendingAction] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const { accountQuery, isFreePlan, autoReloadState } = useCreditBalance();
	const account = accountQuery.data;
	const budgetSpent = autoReloadState === "budget_spent";
	const canManageBilling = useCanManageBilling();
	const { isValid: isValidTopUp, parsed: parsedTopUpAmount } = parseTopUpAmount(topUpAmount);
	const showTopUpError = topUpAmount.trim() !== "" && !isValidTopUp;
	async function runAction(action, callback, fallbackMessage) {
		setError(null);
		setPendingAction(action);
		try {
			await callback();
		} catch (err) {
			setError({
				action,
				message: getStandardErrorMessage(err, fallbackMessage)
			});
			setPendingAction(null);
		}
	}
	async function startTopUpCheckout() {
		window.location.assign(await createTopUpCheckout({ data: { amountUsd: parsedTopUpAmount } }));
	}
	async function openPortal() {
		window.location.assign(await createBillingPortalSession({ data: { returnTo: BILLING_ROUTE } }));
	}
	function actionError(action) {
		return error?.action === action ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, { message: error.message }) : null;
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto box-content max-w-7xl space-y-6 px-4 py-4 pb-24 md:px-6 md:py-6 md:pb-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { title: "Billing" }),
			accountQuery.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillingSummarySkeleton, {}) : !account ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
				cause: accountQuery.error,
				fallback: "We couldn't load your billing details right now. Please try again.",
				onRetry: () => void accountQuery.refetch(),
				isRetrying: accountQuery.isFetching
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				accountQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
					cause: accountQuery.error,
					fallback: "Failed to refresh billing details",
					onRetry: () => void accountQuery.refetch(),
					isRetrying: accountQuery.isFetching
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Plan" }) }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl font-semibold tracking-tight",
								children: account.paidPlanId ? account.paidPlanName : "Free Plan"
							}), account.paidPlanId ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: [
									"$",
									account.monthlyCreditsUsd.toFixed(2),
									" of credits each month"
								]
							}) : canManageBilling ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted-foreground",
								children: "Upgrade to access every feature and more credits each month"
							}) : null]
						}), !canManageBilling ? null : isFreePlan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							nativeButton: false,
							render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: SUBSCRIBE_ROUTE,
								search: { upgrade: true }
							}),
							children: "Upgrade Plan"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChangePlanButton, { planId: account.paidPlanId }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								pending: pendingAction === "plan",
								disabled: pendingAction !== null,
								onClick: () => void runAction("plan", openPortal, "We couldn't open the billing portal. Please try again."),
								children: pendingAction === "plan" ? "Redirecting to Stripe..." : "Manage subscription"
							})]
						})]
					}), !canManageBilling ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground",
						children: "Only the organization owner can change the plan or buy credits. Ask them if you need more."
					}) : actionError("plan")]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreditsCard, { children: canManageBilling ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillingRow, {
					label: "Top-up credits",
					summary: isFreePlan ? "Need more than your monthly credits? On a paid plan, buy as many as you need. They never expire." : "Never expire and are used after your monthly credits.",
					action: isFreePlan || buyingCredits ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => setBuyingCredits(true),
						children: "Buy credits"
					}),
					children: !isFreePlan && buyingCredits ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap items-start gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										"data-invalid": showTopUpError,
										className: "w-36",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InputGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, { children: "$" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupInput, {
											type: "number",
											min: 10,
											max: 99,
											step: 1,
											inputMode: "numeric",
											"aria-label": "Top-up amount in USD",
											"aria-invalid": showTopUpError,
											autoFocus: true,
											value: topUpAmount,
											onChange: (e) => setTopUpAmount(e.target.value)
										})] })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "h-10",
										pending: pendingAction === "topUp",
										disabled: !isValidTopUp || pendingAction !== null || budgetSpent,
										onClick: () => void runAction("topUp", startTopUpCheckout, "We couldn't start the checkout. Please try again."),
										children: pendingAction === "topUp" ? "Redirecting to Stripe..." : `Buy $${parsedTopUpAmount} of credits`
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										variant: "ghost",
										className: "h-10",
										disabled: pendingAction !== null,
										onClick: () => {
											setBuyingCredits(false);
											setError((e) => e?.action === "topUp" ? null : e);
										},
										children: "Cancel"
									})
								]
							}),
							showTopUpError ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-destructive",
								children: [
									"Enter between $",
									10,
									"\u2013$",
									99,
									"."
								]
							}) : null,
							budgetSpent ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "You\u2019ve hit your monthly auto-reload budget. Raise it below to buy more."
							}) : null,
							actionError("topUp")
						]
					}) : null
				}), !isFreePlan || account.autoReload?.enabled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AutoReloadSettings, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillingRow, {
					label: "Auto-reload",
					summary: "On a paid plan, buy more automatically when you run low, up to a monthly budget you set."
				})] }) : null })
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BillingTabs, {
				tab: tab ?? "usage",
				onTabChange: (next) => void navigate({
					to: BILLING_ROUTE,
					replace: true,
					search: { tab: next === "usage" ? void 0 : next }
				}),
				invoiceEmailsEnabled: canManageBilling && account ? account.invoiceEmailsEnabled : null
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Billing is powered by Stripe."
			})
		]
	});
}
/** The Plan and Credits cards' shape while the billing account loads. */
function BillingSummarySkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"aria-busy": true,
		className: "space-y-6",
		children: [0, 1].map((index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-5 w-16" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "space-y-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-7 w-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-56" })]
		})] }, index))
	});
}
//#endregion
export { BillingPage as component };
