import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { i as LOCATION_OPTIONS, s as getIsoCountryCode } from "./keyword-locations-4GfvBtRY.js";
import { t as cn } from "./dist-fVOGIv0D.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as Search } from "./search-8b-KxN4Z.js";
import { n as InputGroupAddon } from "./input-group-CmFmGa25.js";
import { a as ComboboxCollection, c as ComboboxGroup, d as ComboboxLabel, f as ComboboxList, l as ComboboxInput, o as ComboboxContent, p as ComboboxTrigger, s as ComboboxEmpty, t as Combobox, u as ComboboxItem } from "./combobox-BYdKkOBU.js";
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AC.svg?url&no-inline
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var AC_default = "/assets/AC-CbDoWO2L.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AD.svg?url&no-inline
var AD_default = "/assets/AD-BaaLS114.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AE.svg?url&no-inline
var AE_default = "/assets/AE-DAc3Pgjp.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AF.svg?url&no-inline
var AF_default = "/assets/AF-DTCubFaC.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AG.svg?url&no-inline
var AG_default = "/assets/AG-CFZa5Qpf.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AI.svg?url&no-inline
var AI_default = "/assets/AI-BHc81k_k.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AL.svg?url&no-inline
var AL_default = "/assets/AL-GFecpKXO.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AM.svg?url&no-inline
var AM_default = "/assets/AM-DMXLRZQx.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AO.svg?url&no-inline
var AO_default = "/assets/AO-y8TFCIkS.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AQ.svg?url&no-inline
var AQ_default = "/assets/AQ-Y3KBn8n0.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AR.svg?url&no-inline
var AR_default = "/assets/AR-D92xKO1C.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AS.svg?url&no-inline
var AS_default = "/assets/AS-BCPa-NWv.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AT.svg?url&no-inline
var AT_default = "/assets/AT-BTcBtZRa.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AU.svg?url&no-inline
var AU_default = "/assets/AU-BtdspSCa.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AW.svg?url&no-inline
var AW_default = "/assets/AW-CG7A83yd.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AX.svg?url&no-inline
var AX_default = "/assets/AX-D_dPyKCV.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/AZ.svg?url&no-inline
var AZ_default = "/assets/AZ-B2iUPzkN.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BA.svg?url&no-inline
var BA_default = "/assets/BA-BuB4izN7.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BB.svg?url&no-inline
var BB_default = "/assets/BB-BNSOdrk0.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BD.svg?url&no-inline
var BD_default = "/assets/BD-DMzlhzR3.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BE.svg?url&no-inline
var BE_default = "/assets/BE-BdBzwLCI.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BF.svg?url&no-inline
var BF_default = "/assets/BF-BbBRJf5D.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BG.svg?url&no-inline
var BG_default = "/assets/BG-D9pynSdd.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BH.svg?url&no-inline
var BH_default = "/assets/BH-C35bVPOu.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BI.svg?url&no-inline
var BI_default = "/assets/BI-BMMCUFva.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BJ.svg?url&no-inline
var BJ_default = "/assets/BJ-DlHv6b6r.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BL.svg?url&no-inline
var BL_default = "/assets/BL-M6s7sAry.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BM.svg?url&no-inline
var BM_default = "/assets/BM-aVS7ORZq.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BN.svg?url&no-inline
var BN_default = "/assets/BN-BZvqH72Q.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BO.svg?url&no-inline
var BO_default = "/assets/BO-Dlzoc258.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BQ-BO.svg?url&no-inline
var BQ_BO_default = "/assets/BQ-BO-CyMlFHc4.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BQ-SA.svg?url&no-inline
var BQ_SA_default = "/assets/BQ-SA-Cy2F38Sb.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BQ-SE.svg?url&no-inline
var BQ_SE_default = "/assets/BQ-SE-C6xey4BT.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BQ.svg?url&no-inline
var BQ_default = "/assets/BQ-ChyDnXAR.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BR.svg?url&no-inline
var BR_default = "/assets/BR-C2dVdLM3.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BS.svg?url&no-inline
var BS_default = "/assets/BS-BJbp8F4X.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BT.svg?url&no-inline
var BT_default = "/assets/BT-BBXKuEvL.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BV.svg?url&no-inline
var BV_default = "/assets/BV-DwZce1Cx.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BW.svg?url&no-inline
var BW_default = "/assets/BW-CRYDLjBw.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BY.svg?url&no-inline
var BY_default = "/assets/BY-DH2NQIl5.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/BZ.svg?url&no-inline
var BZ_default = "/assets/BZ-Cw6ocuLs.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CA.svg?url&no-inline
var CA_default = "/assets/CA-DklJnmyJ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CC.svg?url&no-inline
var CC_default = "/assets/CC-sukc3h6Z.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CD.svg?url&no-inline
var CD_default = "/assets/CD-DZ59dmLw.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CF.svg?url&no-inline
var CF_default = "/assets/CF-D97uEb0w.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CG.svg?url&no-inline
var CG_default = "/assets/CG-Coxft0xk.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CH.svg?url&no-inline
var CH_default = "/assets/CH-CehVzdfL.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CI.svg?url&no-inline
var CI_default = "/assets/CI-9dgoh42c.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CK.svg?url&no-inline
var CK_default = "/assets/CK-CaEORPIb.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CL.svg?url&no-inline
var CL_default = "/assets/CL-u7ZEQZuW.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CM.svg?url&no-inline
var CM_default = "/assets/CM-Bk_pm0y2.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CN.svg?url&no-inline
var CN_default = "/assets/CN-DBLsokkJ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CO.svg?url&no-inline
var CO_default = "/assets/CO-Bo3QHEIL.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CR.svg?url&no-inline
var CR_default = "/assets/CR-4sdN3mxx.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CU.svg?url&no-inline
var CU_default = "/assets/CU-B7Op8eFo.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CV.svg?url&no-inline
var CV_default = "/assets/CV-DfWxaNcp.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CW.svg?url&no-inline
var CW_default = "/assets/CW-nViQ5Mv_.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CX.svg?url&no-inline
var CX_default = "/assets/CX-5o-yVL75.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CY.svg?url&no-inline
var CY_default = "/assets/CY-VCX5A5Il.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/CZ.svg?url&no-inline
var CZ_default = "/assets/CZ-CdRBVRkM.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/DE.svg?url&no-inline
var DE_default = "/assets/DE-BQirBgdw.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/DJ.svg?url&no-inline
var DJ_default = "/assets/DJ-7NEPNGNo.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/DK.svg?url&no-inline
var DK_default = "/assets/DK-CrRuMohQ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/DM.svg?url&no-inline
var DM_default = "/assets/DM-B6P4PoZ8.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/DO.svg?url&no-inline
var DO_default = "/assets/DO-lbTWxNHJ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/DZ.svg?url&no-inline
var DZ_default = "/assets/DZ-mKWX67NU.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/EC.svg?url&no-inline
var EC_default = "/assets/EC-DowmFUJ5.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/EE.svg?url&no-inline
var EE_default = "/assets/EE-DQgUf_93.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/EG.svg?url&no-inline
var EG_default = "/assets/EG-41Yx58NV.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/EH.svg?url&no-inline
var EH_default = "/assets/EH-18eIox9n.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ER.svg?url&no-inline
var ER_default = "/assets/ER-sdu8Q1Mj.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ES-CT.svg?url&no-inline
var ES_CT_default = "/assets/ES-CT-CQLSDWWY.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ES.svg?url&no-inline
var ES_default = "/assets/ES-DmBAttra.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ET.svg?url&no-inline
var ET_default = "/assets/ET-CYXO9sLP.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/EU.svg?url&no-inline
var EU_default = "/assets/EU-Ccnj57vu.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/FI.svg?url&no-inline
var FI_default = "/assets/FI-DDmPKegl.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/FJ.svg?url&no-inline
var FJ_default = "/assets/FJ-NsiPkgR1.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/FK.svg?url&no-inline
var FK_default = "/assets/FK-MvrypsK3.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/FM.svg?url&no-inline
var FM_default = "/assets/FM-CESdhCl9.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/FO.svg?url&no-inline
var FO_default = "/assets/FO-DGtO3nhZ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/FR.svg?url&no-inline
var FR_default = "/assets/FR-j9aZRM7P.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GA.svg?url&no-inline
var GA_default = "/assets/GA-D9mUZ6i_.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GB-ENG.svg?url&no-inline
var GB_ENG_default = "/assets/GB-ENG-ULRFBxu4.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GB-NIR.svg?url&no-inline
var GB_NIR_default = "/assets/GB-NIR-BCATY9G7.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GB-SCT.svg?url&no-inline
var GB_SCT_default = "/assets/GB-SCT-B76XsfTw.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GB-WLS.svg?url&no-inline
var GB_WLS_default = "/assets/GB-WLS-DnnuT4B9.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GB.svg?url&no-inline
var GB_default = "/assets/GB-CrMUL81c.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GD.svg?url&no-inline
var GD_default = "/assets/GD-DaBm_vHM.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GE.svg?url&no-inline
var GE_default = "/assets/GE-Bipp1HMj.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GF.svg?url&no-inline
var GF_default = "/assets/GF-C8qEhaeq.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GG.svg?url&no-inline
var GG_default = "/assets/GG-DPmbHgs0.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GH.svg?url&no-inline
var GH_default = "/assets/GH-BrfwLKz5.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GI.svg?url&no-inline
var GI_default = "/assets/GI-CTp4hbX0.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GL.svg?url&no-inline
var GL_default = "/assets/GL-D1mX0C9K.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GM.svg?url&no-inline
var GM_default = "/assets/GM-DJ48jgsP.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GN.svg?url&no-inline
var GN_default = "/assets/GN-BjumvHhF.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GP.svg?url&no-inline
var GP_default = "/assets/FR-j9aZRM7P.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GQ.svg?url&no-inline
var GQ_default = "/assets/GQ-Cs8L_DkX.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GR.svg?url&no-inline
var GR_default = "/assets/GR-CHXTsY7H.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GS.svg?url&no-inline
var GS_default = "/assets/GS-CoAoagE7.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GT.svg?url&no-inline
var GT_default = "/assets/GT-DJQNa0We.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GU.svg?url&no-inline
var GU_default = "/assets/GU-C8Vq93sU.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GW.svg?url&no-inline
var GW_default = "/assets/GW-CpCQmm3X.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/GY.svg?url&no-inline
var GY_default = "/assets/GY-jCbUhRiZ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/HK.svg?url&no-inline
var HK_default = "/assets/HK-Djp6w5Tb.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/HM.svg?url&no-inline
var HM_default = "/assets/HM-B_i1vuU8.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/HN.svg?url&no-inline
var HN_default = "/assets/HN-CHokYOxB.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/HR.svg?url&no-inline
var HR_default = "/assets/HR-C27a-wF2.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/HT.svg?url&no-inline
var HT_default = "/assets/HT-D7iA4Km-.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/HU.svg?url&no-inline
var HU_default = "/assets/HU-C-ompw3N.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/IC.svg?url&no-inline
var IC_default = "/assets/IC-BoyqLG8O.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ID.svg?url&no-inline
var ID_default = "/assets/ID-3gIyEjUv.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/IE.svg?url&no-inline
var IE_default = "/assets/IE-BaatewIy.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/IL.svg?url&no-inline
var IL_default = "/assets/IL-C6dphAu1.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/IM.svg?url&no-inline
var IM_default = "/assets/IM-B4MwfjKD.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/IN.svg?url&no-inline
var IN_default = "/assets/IN-jNvSSbTP.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/IO.svg?url&no-inline
var IO_default = "/assets/IO-DJlXpxBF.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/IQ.svg?url&no-inline
var IQ_default = "/assets/IQ-BMFU5isZ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/IR.svg?url&no-inline
var IR_default = "/assets/IR-xa1Tl-kt.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/IS.svg?url&no-inline
var IS_default = "/assets/IS-BPrDjuNU.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/IT.svg?url&no-inline
var IT_default = "/assets/IT-b7utlsit.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/JE.svg?url&no-inline
var JE_default = "/assets/JE-D-u8PSq2.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/JM.svg?url&no-inline
var JM_default = "/assets/JM-0jjk-0N8.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/JO.svg?url&no-inline
var JO_default = "/assets/JO-BjqSqGuF.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/JP.svg?url&no-inline
var JP_default = "/assets/JP-C0yKneLk.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KE.svg?url&no-inline
var KE_default = "/assets/KE-UqP4CzWI.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KG.svg?url&no-inline
var KG_default = "/assets/KG-CJDExopv.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KH.svg?url&no-inline
var KH_default = "/assets/KH-4gVsc0Fa.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KI.svg?url&no-inline
var KI_default = "/assets/KI-B7BY6LVy.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KM.svg?url&no-inline
var KM_default = "/assets/KM-Dm-gT4bY.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KN.svg?url&no-inline
var KN_default = "/assets/KN-Dx8bDS8L.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KP.svg?url&no-inline
var KP_default = "/assets/KP-DQpC6JRH.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KR.svg?url&no-inline
var KR_default = "/assets/KR-Cs_xXpym.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KW.svg?url&no-inline
var KW_default = "/assets/KW-NKE6dt_l.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KY.svg?url&no-inline
var KY_default = "/assets/KY-CS3jl4Uy.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/KZ.svg?url&no-inline
var KZ_default = "/assets/KZ-DN1U3jxs.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LA.svg?url&no-inline
var LA_default = "/assets/LA-BbfpTPPr.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LB.svg?url&no-inline
var LB_default = "/assets/LB-DzzThBld.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LC.svg?url&no-inline
var LC_default = "/assets/LC-ceJfki0C.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LI.svg?url&no-inline
var LI_default = "/assets/LI-Bh_MLgNx.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LK.svg?url&no-inline
var LK_default = "/assets/LK-DUnwxZ7b.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LR.svg?url&no-inline
var LR_default = "/assets/LR-BnXimMS5.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LS.svg?url&no-inline
var LS_default = "/assets/LS-CN83OvGu.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LT.svg?url&no-inline
var LT_default = "/assets/LT-CBqMBezS.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LU.svg?url&no-inline
var LU_default = "/assets/LU-BM4T76sU.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LV.svg?url&no-inline
var LV_default = "/assets/LV-BnaZkZg_.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/LY.svg?url&no-inline
var LY_default = "/assets/LY-BaYkukVn.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MA.svg?url&no-inline
var MA_default = "/assets/MA-ni3UXduh.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MC.svg?url&no-inline
var MC_default = "/assets/MC-BK9Xf3-F.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MD.svg?url&no-inline
var MD_default = "/assets/MD-Dv6V_oy5.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ME.svg?url&no-inline
var ME_default = "/assets/ME-CjoXwsnb.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MF.svg?url&no-inline
var MF_default = "/assets/MF-B6KIuKF8.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MG.svg?url&no-inline
var MG_default = "/assets/MG-DLZ190mC.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MH.svg?url&no-inline
var MH_default = "/assets/MH-B-r1TqHi.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MK.svg?url&no-inline
var MK_default = "/assets/MK-BVXG-OkW.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ML.svg?url&no-inline
var ML_default = "/assets/ML-DJ4AlfRN.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MM.svg?url&no-inline
var MM_default = "/assets/MM-CGqBZT8O.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MN.svg?url&no-inline
var MN_default = "/assets/MN-C8bX1n5M.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MO.svg?url&no-inline
var MO_default = "/assets/MO-e0MPLtRu.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MP.svg?url&no-inline
var MP_default = "/assets/MP-D9T838Fx.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MQ.svg?url&no-inline
var MQ_default = "/assets/MQ-Me2xZymk.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MR.svg?url&no-inline
var MR_default = "/assets/MR-C2B4rVvL.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MS.svg?url&no-inline
var MS_default = "/assets/MS-B0hBL5bT.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MT.svg?url&no-inline
var MT_default = "/assets/MT-TW2QlA9T.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MU.svg?url&no-inline
var MU_default = "/assets/MU-C5KZOmCL.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MV.svg?url&no-inline
var MV_default = "/assets/MV-Bg3Nrp1q.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MW.svg?url&no-inline
var MW_default = "/assets/MW-V_bgO6z9.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MX.svg?url&no-inline
var MX_default = "/assets/MX-DMQatkBl.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MY.svg?url&no-inline
var MY_default = "/assets/MY-B8V72yYL.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/MZ.svg?url&no-inline
var MZ_default = "/assets/MZ-CUJ-7VWb.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NA.svg?url&no-inline
var NA_default = "/assets/NA-DiEJ_hUm.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NC.svg?url&no-inline
var NC_default = "/assets/NC-j47qOf6u.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NE.svg?url&no-inline
var NE_default = "/assets/NE-Cg8NsPBb.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NF.svg?url&no-inline
var NF_default = "/assets/NF-D6shRrhU.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NG.svg?url&no-inline
var NG_default = "/assets/NG-BdMJwnfV.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NI.svg?url&no-inline
var NI_default = "/assets/NI-BgX0BHec.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NL.svg?url&no-inline
var NL_default = "/assets/NL-CuL5juzU.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NO.svg?url&no-inline
var NO_default = "/assets/NO-DKxfZv60.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NP.svg?url&no-inline
var NP_default = "/assets/NP-bS1U8k96.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NR.svg?url&no-inline
var NR_default = "/assets/NR-CunmpZSc.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NU.svg?url&no-inline
var NU_default = "/assets/NU-C5S1FNaB.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/NZ.svg?url&no-inline
var NZ_default = "/assets/NZ-5fucgQmH.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/OM.svg?url&no-inline
var OM_default = "/assets/OM-F0ozI9u1.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PA.svg?url&no-inline
var PA_default = "/assets/PA-CCbT5I8a.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PE.svg?url&no-inline
var PE_default = "/assets/PE-HQKkFwxo.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PF.svg?url&no-inline
var PF_default = "/assets/PF-DWVGC3vM.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PG.svg?url&no-inline
var PG_default = "/assets/PG-BsTxVXf1.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PH.svg?url&no-inline
var PH_default = "/assets/PH-BArMaj_z.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PK.svg?url&no-inline
var PK_default = "/assets/PK-DXxNLk1x.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PL.svg?url&no-inline
var PL_default = "/assets/PL-NhbGgqOk.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PM.svg?url&no-inline
var PM_default = "/assets/FR-j9aZRM7P.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PN.svg?url&no-inline
var PN_default = "/assets/PN-BKTvtfst.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PR.svg?url&no-inline
var PR_default = "/assets/PR-ASSRB5Ek.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PS.svg?url&no-inline
var PS_default = "/assets/PS-arLDN2FQ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PT.svg?url&no-inline
var PT_default = "/assets/PT-CqUmj-XK.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PW.svg?url&no-inline
var PW_default = "/assets/PW-BTsqZQnz.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/PY.svg?url&no-inline
var PY_default = "/assets/PY-Dskflyxv.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/QA.svg?url&no-inline
var QA_default = "/assets/QA-Bjx_ueRG.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/RE.svg?url&no-inline
var RE_default = "/assets/FR-j9aZRM7P.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/RO.svg?url&no-inline
var RO_default = "/assets/RO-D_OokVGr.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/RS.svg?url&no-inline
var RS_default = "/assets/RS-jhhxEpH4.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/RU.svg?url&no-inline
var RU_default = "/assets/RU-DYN_WS5I.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/RW.svg?url&no-inline
var RW_default = "/assets/RW-BE1o4PTn.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SA.svg?url&no-inline
var SA_default = "/assets/SA-BqehXYjU.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SB.svg?url&no-inline
var SB_default = "/assets/SB-Bbwow3nc.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SC.svg?url&no-inline
var SC_default = "/assets/SC-5aJPViNH.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SD.svg?url&no-inline
var SD_default = "/assets/SD-k9zzJooq.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SE.svg?url&no-inline
var SE_default = "/assets/SE-BcPcIk11.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SG.svg?url&no-inline
var SG_default = "/assets/SG-CU9IbJNg.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SH.svg?url&no-inline
var SH_default = "/assets/SH-BxFwlWZm.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SI.svg?url&no-inline
var SI_default = "/assets/SI-DaSlA1bv.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SJ.svg?url&no-inline
var SJ_default = "/assets/SJ-C4JndhCh.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SK.svg?url&no-inline
var SK_default = "/assets/SK-C8cjeN8-.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SL.svg?url&no-inline
var SL_default = "/assets/SL-ElETo3AR.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SM.svg?url&no-inline
var SM_default = "/assets/SM-EnwtV5Fr.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SN.svg?url&no-inline
var SN_default = "/assets/SN-DJlpsJgs.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SO.svg?url&no-inline
var SO_default = "/assets/SO-BgOD84ko.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SR.svg?url&no-inline
var SR_default = "/assets/SR-CLn9gz9P.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SS.svg?url&no-inline
var SS_default = "/assets/SS-DHLtEkbm.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ST.svg?url&no-inline
var ST_default = "/assets/ST-CkY9_4P9.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SV.svg?url&no-inline
var SV_default = "/assets/SV-BqZia_S8.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SX.svg?url&no-inline
var SX_default = "/assets/SX-DQqIM-eb.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SY.svg?url&no-inline
var SY_default = "/assets/SY-DJvE_7M_.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/SZ.svg?url&no-inline
var SZ_default = "/assets/SZ-Bp_eiJxi.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TA.svg?url&no-inline
var TA_default = "/assets/TA-COL5s0Sv.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TC.svg?url&no-inline
var TC_default = "/assets/TC-Dupawuwe.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TD.svg?url&no-inline
var TD_default = "/assets/TD-CpWzcDUw.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TF.svg?url&no-inline
var TF_default = "/assets/TF-DZ-oDjbf.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TG.svg?url&no-inline
var TG_default = "/assets/TG-BPvTHpLT.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TH.svg?url&no-inline
var TH_default = "/assets/TH-YZoF4b7C.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TJ.svg?url&no-inline
var TJ_default = "/assets/TJ-C09s1VRE.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TK.svg?url&no-inline
var TK_default = "/assets/TK-C_U8zMMZ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TL.svg?url&no-inline
var TL_default = "/assets/TL-C5MW8vrQ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TM.svg?url&no-inline
var TM_default = "/assets/TM-BwDTlVf_.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TN.svg?url&no-inline
var TN_default = "/assets/TN-Q1dtTdwg.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TO.svg?url&no-inline
var TO_default = "/assets/TO-CgBF75-h.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TR.svg?url&no-inline
var TR_default = "/assets/TR-BKlhJa-L.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TT.svg?url&no-inline
var TT_default = "/assets/TT-DQ87mMC3.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TV.svg?url&no-inline
var TV_default = "/assets/TV-qyi-T3Gj.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TW.svg?url&no-inline
var TW_default = "/assets/TW-CrTr0OWW.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/TZ.svg?url&no-inline
var TZ_default = "/assets/TZ-9A2z22an.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/UA.svg?url&no-inline
var UA_default = "/assets/UA-J3AnuLTT.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/UG.svg?url&no-inline
var UG_default = "/assets/UG-Dbwpy4iJ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/UM.svg?url&no-inline
var UM_default = "/assets/UM-_O7C4DfC.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/US.svg?url&no-inline
var US_default = "/assets/US-BptdSU8n.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/UY.svg?url&no-inline
var UY_default = "/assets/UY-Wlc1UF5b.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/UZ.svg?url&no-inline
var UZ_default = "/assets/UZ-C3cCRBFJ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/VA.svg?url&no-inline
var VA_default = "/assets/VA-BzG2jjDf.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/VC.svg?url&no-inline
var VC_default = "/assets/VC-B7-V-JuB.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/VE.svg?url&no-inline
var VE_default = "/assets/VE-CjWjXJ5c.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/VG.svg?url&no-inline
var VG_default = "/assets/VG-ehta7BKA.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/VI.svg?url&no-inline
var VI_default = "/assets/VI-Fh0iADBh.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/VN.svg?url&no-inline
var VN_default = "/assets/VN-BFLXt-n3.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/VU.svg?url&no-inline
var VU_default = "/assets/VU-C--R-VzK.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/WF.svg?url&no-inline
var WF_default = "/assets/WF-DB9NC6ht.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/WS.svg?url&no-inline
var WS_default = "/assets/WS-PFcjY5Kp.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/XA.svg?url&no-inline
var XA_default = "/assets/XA-COBdXmqB.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/XC.svg?url&no-inline
var XC_default = "/assets/XC-d9GautOX.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/XK.svg?url&no-inline
var XK_default = "/assets/XK-Dfi4kr9K.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/XO.svg?url&no-inline
var XO_default = "/assets/XO-D4E8MD66.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/YE.svg?url&no-inline
var YE_default = "/assets/YE-DjkP7lp7.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/YT.svg?url&no-inline
var YT_default = "/assets/YT-Daouu41A.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ZA.svg?url&no-inline
var ZA_default = "/assets/ZA-CkD9noJJ.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ZM.svg?url&no-inline
var ZM_default = "/assets/ZM-D0uetwuT.svg";
//#endregion
//#region node_modules/.pnpm/country-flag-icons@1.6.20/node_modules/country-flag-icons/1x1/ZW.svg?url&no-inline
var ZW_default = "/assets/ZW-B4D35AIa.svg";
//#endregion
//#region src/client/components/CountryFlag.tsx
var import_jsx_runtime = require_jsx_runtime();
var FLAG_URLS = /* #__PURE__ */ Object.assign({
	"/node_modules/country-flag-icons/1x1/AC.svg": AC_default,
	"/node_modules/country-flag-icons/1x1/AD.svg": AD_default,
	"/node_modules/country-flag-icons/1x1/AE.svg": AE_default,
	"/node_modules/country-flag-icons/1x1/AF.svg": AF_default,
	"/node_modules/country-flag-icons/1x1/AG.svg": AG_default,
	"/node_modules/country-flag-icons/1x1/AI.svg": AI_default,
	"/node_modules/country-flag-icons/1x1/AL.svg": AL_default,
	"/node_modules/country-flag-icons/1x1/AM.svg": AM_default,
	"/node_modules/country-flag-icons/1x1/AO.svg": AO_default,
	"/node_modules/country-flag-icons/1x1/AQ.svg": AQ_default,
	"/node_modules/country-flag-icons/1x1/AR.svg": AR_default,
	"/node_modules/country-flag-icons/1x1/AS.svg": AS_default,
	"/node_modules/country-flag-icons/1x1/AT.svg": AT_default,
	"/node_modules/country-flag-icons/1x1/AU.svg": AU_default,
	"/node_modules/country-flag-icons/1x1/AW.svg": AW_default,
	"/node_modules/country-flag-icons/1x1/AX.svg": AX_default,
	"/node_modules/country-flag-icons/1x1/AZ.svg": AZ_default,
	"/node_modules/country-flag-icons/1x1/BA.svg": BA_default,
	"/node_modules/country-flag-icons/1x1/BB.svg": BB_default,
	"/node_modules/country-flag-icons/1x1/BD.svg": BD_default,
	"/node_modules/country-flag-icons/1x1/BE.svg": BE_default,
	"/node_modules/country-flag-icons/1x1/BF.svg": BF_default,
	"/node_modules/country-flag-icons/1x1/BG.svg": BG_default,
	"/node_modules/country-flag-icons/1x1/BH.svg": BH_default,
	"/node_modules/country-flag-icons/1x1/BI.svg": BI_default,
	"/node_modules/country-flag-icons/1x1/BJ.svg": BJ_default,
	"/node_modules/country-flag-icons/1x1/BL.svg": BL_default,
	"/node_modules/country-flag-icons/1x1/BM.svg": BM_default,
	"/node_modules/country-flag-icons/1x1/BN.svg": BN_default,
	"/node_modules/country-flag-icons/1x1/BO.svg": BO_default,
	"/node_modules/country-flag-icons/1x1/BQ-BO.svg": BQ_BO_default,
	"/node_modules/country-flag-icons/1x1/BQ-SA.svg": BQ_SA_default,
	"/node_modules/country-flag-icons/1x1/BQ-SE.svg": BQ_SE_default,
	"/node_modules/country-flag-icons/1x1/BQ.svg": BQ_default,
	"/node_modules/country-flag-icons/1x1/BR.svg": BR_default,
	"/node_modules/country-flag-icons/1x1/BS.svg": BS_default,
	"/node_modules/country-flag-icons/1x1/BT.svg": BT_default,
	"/node_modules/country-flag-icons/1x1/BV.svg": BV_default,
	"/node_modules/country-flag-icons/1x1/BW.svg": BW_default,
	"/node_modules/country-flag-icons/1x1/BY.svg": BY_default,
	"/node_modules/country-flag-icons/1x1/BZ.svg": BZ_default,
	"/node_modules/country-flag-icons/1x1/CA.svg": CA_default,
	"/node_modules/country-flag-icons/1x1/CC.svg": CC_default,
	"/node_modules/country-flag-icons/1x1/CD.svg": CD_default,
	"/node_modules/country-flag-icons/1x1/CF.svg": CF_default,
	"/node_modules/country-flag-icons/1x1/CG.svg": CG_default,
	"/node_modules/country-flag-icons/1x1/CH.svg": CH_default,
	"/node_modules/country-flag-icons/1x1/CI.svg": CI_default,
	"/node_modules/country-flag-icons/1x1/CK.svg": CK_default,
	"/node_modules/country-flag-icons/1x1/CL.svg": CL_default,
	"/node_modules/country-flag-icons/1x1/CM.svg": CM_default,
	"/node_modules/country-flag-icons/1x1/CN.svg": CN_default,
	"/node_modules/country-flag-icons/1x1/CO.svg": CO_default,
	"/node_modules/country-flag-icons/1x1/CR.svg": CR_default,
	"/node_modules/country-flag-icons/1x1/CU.svg": CU_default,
	"/node_modules/country-flag-icons/1x1/CV.svg": CV_default,
	"/node_modules/country-flag-icons/1x1/CW.svg": CW_default,
	"/node_modules/country-flag-icons/1x1/CX.svg": CX_default,
	"/node_modules/country-flag-icons/1x1/CY.svg": CY_default,
	"/node_modules/country-flag-icons/1x1/CZ.svg": CZ_default,
	"/node_modules/country-flag-icons/1x1/DE.svg": DE_default,
	"/node_modules/country-flag-icons/1x1/DJ.svg": DJ_default,
	"/node_modules/country-flag-icons/1x1/DK.svg": DK_default,
	"/node_modules/country-flag-icons/1x1/DM.svg": DM_default,
	"/node_modules/country-flag-icons/1x1/DO.svg": DO_default,
	"/node_modules/country-flag-icons/1x1/DZ.svg": DZ_default,
	"/node_modules/country-flag-icons/1x1/EC.svg": EC_default,
	"/node_modules/country-flag-icons/1x1/EE.svg": EE_default,
	"/node_modules/country-flag-icons/1x1/EG.svg": EG_default,
	"/node_modules/country-flag-icons/1x1/EH.svg": EH_default,
	"/node_modules/country-flag-icons/1x1/ER.svg": ER_default,
	"/node_modules/country-flag-icons/1x1/ES-CT.svg": ES_CT_default,
	"/node_modules/country-flag-icons/1x1/ES.svg": ES_default,
	"/node_modules/country-flag-icons/1x1/ET.svg": ET_default,
	"/node_modules/country-flag-icons/1x1/EU.svg": EU_default,
	"/node_modules/country-flag-icons/1x1/FI.svg": FI_default,
	"/node_modules/country-flag-icons/1x1/FJ.svg": FJ_default,
	"/node_modules/country-flag-icons/1x1/FK.svg": FK_default,
	"/node_modules/country-flag-icons/1x1/FM.svg": FM_default,
	"/node_modules/country-flag-icons/1x1/FO.svg": FO_default,
	"/node_modules/country-flag-icons/1x1/FR.svg": FR_default,
	"/node_modules/country-flag-icons/1x1/GA.svg": GA_default,
	"/node_modules/country-flag-icons/1x1/GB-ENG.svg": GB_ENG_default,
	"/node_modules/country-flag-icons/1x1/GB-NIR.svg": GB_NIR_default,
	"/node_modules/country-flag-icons/1x1/GB-SCT.svg": GB_SCT_default,
	"/node_modules/country-flag-icons/1x1/GB-WLS.svg": GB_WLS_default,
	"/node_modules/country-flag-icons/1x1/GB.svg": GB_default,
	"/node_modules/country-flag-icons/1x1/GD.svg": GD_default,
	"/node_modules/country-flag-icons/1x1/GE.svg": GE_default,
	"/node_modules/country-flag-icons/1x1/GF.svg": GF_default,
	"/node_modules/country-flag-icons/1x1/GG.svg": GG_default,
	"/node_modules/country-flag-icons/1x1/GH.svg": GH_default,
	"/node_modules/country-flag-icons/1x1/GI.svg": GI_default,
	"/node_modules/country-flag-icons/1x1/GL.svg": GL_default,
	"/node_modules/country-flag-icons/1x1/GM.svg": GM_default,
	"/node_modules/country-flag-icons/1x1/GN.svg": GN_default,
	"/node_modules/country-flag-icons/1x1/GP.svg": GP_default,
	"/node_modules/country-flag-icons/1x1/GQ.svg": GQ_default,
	"/node_modules/country-flag-icons/1x1/GR.svg": GR_default,
	"/node_modules/country-flag-icons/1x1/GS.svg": GS_default,
	"/node_modules/country-flag-icons/1x1/GT.svg": GT_default,
	"/node_modules/country-flag-icons/1x1/GU.svg": GU_default,
	"/node_modules/country-flag-icons/1x1/GW.svg": GW_default,
	"/node_modules/country-flag-icons/1x1/GY.svg": GY_default,
	"/node_modules/country-flag-icons/1x1/HK.svg": HK_default,
	"/node_modules/country-flag-icons/1x1/HM.svg": HM_default,
	"/node_modules/country-flag-icons/1x1/HN.svg": HN_default,
	"/node_modules/country-flag-icons/1x1/HR.svg": HR_default,
	"/node_modules/country-flag-icons/1x1/HT.svg": HT_default,
	"/node_modules/country-flag-icons/1x1/HU.svg": HU_default,
	"/node_modules/country-flag-icons/1x1/IC.svg": IC_default,
	"/node_modules/country-flag-icons/1x1/ID.svg": ID_default,
	"/node_modules/country-flag-icons/1x1/IE.svg": IE_default,
	"/node_modules/country-flag-icons/1x1/IL.svg": IL_default,
	"/node_modules/country-flag-icons/1x1/IM.svg": IM_default,
	"/node_modules/country-flag-icons/1x1/IN.svg": IN_default,
	"/node_modules/country-flag-icons/1x1/IO.svg": IO_default,
	"/node_modules/country-flag-icons/1x1/IQ.svg": IQ_default,
	"/node_modules/country-flag-icons/1x1/IR.svg": IR_default,
	"/node_modules/country-flag-icons/1x1/IS.svg": IS_default,
	"/node_modules/country-flag-icons/1x1/IT.svg": IT_default,
	"/node_modules/country-flag-icons/1x1/JE.svg": JE_default,
	"/node_modules/country-flag-icons/1x1/JM.svg": JM_default,
	"/node_modules/country-flag-icons/1x1/JO.svg": JO_default,
	"/node_modules/country-flag-icons/1x1/JP.svg": JP_default,
	"/node_modules/country-flag-icons/1x1/KE.svg": KE_default,
	"/node_modules/country-flag-icons/1x1/KG.svg": KG_default,
	"/node_modules/country-flag-icons/1x1/KH.svg": KH_default,
	"/node_modules/country-flag-icons/1x1/KI.svg": KI_default,
	"/node_modules/country-flag-icons/1x1/KM.svg": KM_default,
	"/node_modules/country-flag-icons/1x1/KN.svg": KN_default,
	"/node_modules/country-flag-icons/1x1/KP.svg": KP_default,
	"/node_modules/country-flag-icons/1x1/KR.svg": KR_default,
	"/node_modules/country-flag-icons/1x1/KW.svg": KW_default,
	"/node_modules/country-flag-icons/1x1/KY.svg": KY_default,
	"/node_modules/country-flag-icons/1x1/KZ.svg": KZ_default,
	"/node_modules/country-flag-icons/1x1/LA.svg": LA_default,
	"/node_modules/country-flag-icons/1x1/LB.svg": LB_default,
	"/node_modules/country-flag-icons/1x1/LC.svg": LC_default,
	"/node_modules/country-flag-icons/1x1/LI.svg": LI_default,
	"/node_modules/country-flag-icons/1x1/LK.svg": LK_default,
	"/node_modules/country-flag-icons/1x1/LR.svg": LR_default,
	"/node_modules/country-flag-icons/1x1/LS.svg": LS_default,
	"/node_modules/country-flag-icons/1x1/LT.svg": LT_default,
	"/node_modules/country-flag-icons/1x1/LU.svg": LU_default,
	"/node_modules/country-flag-icons/1x1/LV.svg": LV_default,
	"/node_modules/country-flag-icons/1x1/LY.svg": LY_default,
	"/node_modules/country-flag-icons/1x1/MA.svg": MA_default,
	"/node_modules/country-flag-icons/1x1/MC.svg": MC_default,
	"/node_modules/country-flag-icons/1x1/MD.svg": MD_default,
	"/node_modules/country-flag-icons/1x1/ME.svg": ME_default,
	"/node_modules/country-flag-icons/1x1/MF.svg": MF_default,
	"/node_modules/country-flag-icons/1x1/MG.svg": MG_default,
	"/node_modules/country-flag-icons/1x1/MH.svg": MH_default,
	"/node_modules/country-flag-icons/1x1/MK.svg": MK_default,
	"/node_modules/country-flag-icons/1x1/ML.svg": ML_default,
	"/node_modules/country-flag-icons/1x1/MM.svg": MM_default,
	"/node_modules/country-flag-icons/1x1/MN.svg": MN_default,
	"/node_modules/country-flag-icons/1x1/MO.svg": MO_default,
	"/node_modules/country-flag-icons/1x1/MP.svg": MP_default,
	"/node_modules/country-flag-icons/1x1/MQ.svg": MQ_default,
	"/node_modules/country-flag-icons/1x1/MR.svg": MR_default,
	"/node_modules/country-flag-icons/1x1/MS.svg": MS_default,
	"/node_modules/country-flag-icons/1x1/MT.svg": MT_default,
	"/node_modules/country-flag-icons/1x1/MU.svg": MU_default,
	"/node_modules/country-flag-icons/1x1/MV.svg": MV_default,
	"/node_modules/country-flag-icons/1x1/MW.svg": MW_default,
	"/node_modules/country-flag-icons/1x1/MX.svg": MX_default,
	"/node_modules/country-flag-icons/1x1/MY.svg": MY_default,
	"/node_modules/country-flag-icons/1x1/MZ.svg": MZ_default,
	"/node_modules/country-flag-icons/1x1/NA.svg": NA_default,
	"/node_modules/country-flag-icons/1x1/NC.svg": NC_default,
	"/node_modules/country-flag-icons/1x1/NE.svg": NE_default,
	"/node_modules/country-flag-icons/1x1/NF.svg": NF_default,
	"/node_modules/country-flag-icons/1x1/NG.svg": NG_default,
	"/node_modules/country-flag-icons/1x1/NI.svg": NI_default,
	"/node_modules/country-flag-icons/1x1/NL.svg": NL_default,
	"/node_modules/country-flag-icons/1x1/NO.svg": NO_default,
	"/node_modules/country-flag-icons/1x1/NP.svg": NP_default,
	"/node_modules/country-flag-icons/1x1/NR.svg": NR_default,
	"/node_modules/country-flag-icons/1x1/NU.svg": NU_default,
	"/node_modules/country-flag-icons/1x1/NZ.svg": NZ_default,
	"/node_modules/country-flag-icons/1x1/OM.svg": OM_default,
	"/node_modules/country-flag-icons/1x1/PA.svg": PA_default,
	"/node_modules/country-flag-icons/1x1/PE.svg": PE_default,
	"/node_modules/country-flag-icons/1x1/PF.svg": PF_default,
	"/node_modules/country-flag-icons/1x1/PG.svg": PG_default,
	"/node_modules/country-flag-icons/1x1/PH.svg": PH_default,
	"/node_modules/country-flag-icons/1x1/PK.svg": PK_default,
	"/node_modules/country-flag-icons/1x1/PL.svg": PL_default,
	"/node_modules/country-flag-icons/1x1/PM.svg": PM_default,
	"/node_modules/country-flag-icons/1x1/PN.svg": PN_default,
	"/node_modules/country-flag-icons/1x1/PR.svg": PR_default,
	"/node_modules/country-flag-icons/1x1/PS.svg": PS_default,
	"/node_modules/country-flag-icons/1x1/PT.svg": PT_default,
	"/node_modules/country-flag-icons/1x1/PW.svg": PW_default,
	"/node_modules/country-flag-icons/1x1/PY.svg": PY_default,
	"/node_modules/country-flag-icons/1x1/QA.svg": QA_default,
	"/node_modules/country-flag-icons/1x1/RE.svg": RE_default,
	"/node_modules/country-flag-icons/1x1/RO.svg": RO_default,
	"/node_modules/country-flag-icons/1x1/RS.svg": RS_default,
	"/node_modules/country-flag-icons/1x1/RU.svg": RU_default,
	"/node_modules/country-flag-icons/1x1/RW.svg": RW_default,
	"/node_modules/country-flag-icons/1x1/SA.svg": SA_default,
	"/node_modules/country-flag-icons/1x1/SB.svg": SB_default,
	"/node_modules/country-flag-icons/1x1/SC.svg": SC_default,
	"/node_modules/country-flag-icons/1x1/SD.svg": SD_default,
	"/node_modules/country-flag-icons/1x1/SE.svg": SE_default,
	"/node_modules/country-flag-icons/1x1/SG.svg": SG_default,
	"/node_modules/country-flag-icons/1x1/SH.svg": SH_default,
	"/node_modules/country-flag-icons/1x1/SI.svg": SI_default,
	"/node_modules/country-flag-icons/1x1/SJ.svg": SJ_default,
	"/node_modules/country-flag-icons/1x1/SK.svg": SK_default,
	"/node_modules/country-flag-icons/1x1/SL.svg": SL_default,
	"/node_modules/country-flag-icons/1x1/SM.svg": SM_default,
	"/node_modules/country-flag-icons/1x1/SN.svg": SN_default,
	"/node_modules/country-flag-icons/1x1/SO.svg": SO_default,
	"/node_modules/country-flag-icons/1x1/SR.svg": SR_default,
	"/node_modules/country-flag-icons/1x1/SS.svg": SS_default,
	"/node_modules/country-flag-icons/1x1/ST.svg": ST_default,
	"/node_modules/country-flag-icons/1x1/SV.svg": SV_default,
	"/node_modules/country-flag-icons/1x1/SX.svg": SX_default,
	"/node_modules/country-flag-icons/1x1/SY.svg": SY_default,
	"/node_modules/country-flag-icons/1x1/SZ.svg": SZ_default,
	"/node_modules/country-flag-icons/1x1/TA.svg": TA_default,
	"/node_modules/country-flag-icons/1x1/TC.svg": TC_default,
	"/node_modules/country-flag-icons/1x1/TD.svg": TD_default,
	"/node_modules/country-flag-icons/1x1/TF.svg": TF_default,
	"/node_modules/country-flag-icons/1x1/TG.svg": TG_default,
	"/node_modules/country-flag-icons/1x1/TH.svg": TH_default,
	"/node_modules/country-flag-icons/1x1/TJ.svg": TJ_default,
	"/node_modules/country-flag-icons/1x1/TK.svg": TK_default,
	"/node_modules/country-flag-icons/1x1/TL.svg": TL_default,
	"/node_modules/country-flag-icons/1x1/TM.svg": TM_default,
	"/node_modules/country-flag-icons/1x1/TN.svg": TN_default,
	"/node_modules/country-flag-icons/1x1/TO.svg": TO_default,
	"/node_modules/country-flag-icons/1x1/TR.svg": TR_default,
	"/node_modules/country-flag-icons/1x1/TT.svg": TT_default,
	"/node_modules/country-flag-icons/1x1/TV.svg": TV_default,
	"/node_modules/country-flag-icons/1x1/TW.svg": TW_default,
	"/node_modules/country-flag-icons/1x1/TZ.svg": TZ_default,
	"/node_modules/country-flag-icons/1x1/UA.svg": UA_default,
	"/node_modules/country-flag-icons/1x1/UG.svg": UG_default,
	"/node_modules/country-flag-icons/1x1/UM.svg": UM_default,
	"/node_modules/country-flag-icons/1x1/US.svg": US_default,
	"/node_modules/country-flag-icons/1x1/UY.svg": UY_default,
	"/node_modules/country-flag-icons/1x1/UZ.svg": UZ_default,
	"/node_modules/country-flag-icons/1x1/VA.svg": VA_default,
	"/node_modules/country-flag-icons/1x1/VC.svg": VC_default,
	"/node_modules/country-flag-icons/1x1/VE.svg": VE_default,
	"/node_modules/country-flag-icons/1x1/VG.svg": VG_default,
	"/node_modules/country-flag-icons/1x1/VI.svg": VI_default,
	"/node_modules/country-flag-icons/1x1/VN.svg": VN_default,
	"/node_modules/country-flag-icons/1x1/VU.svg": VU_default,
	"/node_modules/country-flag-icons/1x1/WF.svg": WF_default,
	"/node_modules/country-flag-icons/1x1/WS.svg": WS_default,
	"/node_modules/country-flag-icons/1x1/XA.svg": XA_default,
	"/node_modules/country-flag-icons/1x1/XC.svg": XC_default,
	"/node_modules/country-flag-icons/1x1/XK.svg": XK_default,
	"/node_modules/country-flag-icons/1x1/XO.svg": XO_default,
	"/node_modules/country-flag-icons/1x1/YE.svg": YE_default,
	"/node_modules/country-flag-icons/1x1/YT.svg": YT_default,
	"/node_modules/country-flag-icons/1x1/ZA.svg": ZA_default,
	"/node_modules/country-flag-icons/1x1/ZM.svg": ZM_default,
	"/node_modules/country-flag-icons/1x1/ZW.svg": ZW_default
});
/** A round country flag. Decorative: put the country's name beside it. */
function CountryFlag({ locationCode, className }) {
	const isoCode = getIsoCountryCode(locationCode).toUpperCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: FLAG_URLS[`/node_modules/country-flag-icons/1x1/${isoCode}.svg`],
		alt: "",
		width: 16,
		height: 16,
		loading: "lazy",
		className: cn("size-4 shrink-0 rounded-full ring-1 ring-foreground/10", className)
	});
}
//#endregion
//#region src/client/components/LocationSelect.tsx
var POPULAR_LOCATION_CODES = /* @__PURE__ */ new Set([
	2036,
	2076,
	2124,
	2250,
	2276,
	2356,
	2528,
	2724,
	2826,
	2840
]);
function matches(option, query) {
	const needle = query.trim().toLowerCase();
	if (!needle) return true;
	return option.label.toLowerCase().includes(needle) || option.shortLabel.toLowerCase().includes(needle);
}
/** Searchable country picker: type to filter the country list. */
function LocationSelect({ value, onChange, options = LOCATION_OPTIONS, className = "w-full" }) {
	const selected = options.find((option) => option.code === value) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Combobox, {
		items: options,
		value: selected,
		itemToStringLabel: (option) => option.label,
		autoHighlight: true,
		filter: matches,
		onValueChange: (option) => {
			if (option) onChange(option.code);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxInput, {
			className,
			placeholder: "Select country",
			"aria-label": "Country"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxEmpty, { children: "No countries match." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxList, { children: (option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxItem, {
			value: option,
			children: option.label
		}, option.code) })] })]
	});
}
function groupLocationOptions(selected) {
	const rest = LOCATION_OPTIONS.filter((option) => option !== selected);
	return [
		{
			value: "",
			items: selected ? [selected] : []
		},
		{
			value: "Popular",
			items: rest.filter((option) => POPULAR_LOCATION_CODES.has(option.code))
		},
		{
			value: "All countries",
			items: rest.filter((option) => !POPULAR_LOCATION_CODES.has(option.code))
		}
	].filter((group) => group.items.length > 0);
}
/** `LocationSelect` as a compact button, with its search inside the list. */
function LocationChipSelect({ value, onChange }) {
	const selected = LOCATION_OPTIONS.find((option) => option.code === value) ?? null;
	const groups = (0, import_react.useMemo)(() => groupLocationOptions(selected), [selected]);
	const label = selected?.label ?? "Select country";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Combobox, {
		items: groups,
		value: selected,
		itemToStringLabel: (option) => option.label,
		autoHighlight: true,
		filter: matches,
		onValueChange: (option) => {
			if (option) onChange(option.code);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxTrigger, {
			"aria-label": `Country: ${label}`,
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				className: "font-normal"
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountryFlag, { locationCode: value }), label]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxContent, {
			className: "w-64",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxInput, {
					showTrigger: false,
					placeholder: "Search",
					"aria-label": "Search countries",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {}) })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxEmpty, { children: "No countries match." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxList, { children: (group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxGroup, {
					items: group.items,
					children: [group.value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxLabel, { children: group.value }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxCollection, { children: (option) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxItem, {
						value: option,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CountryFlag, { locationCode: option.code }), option.label]
					}, option.code) })]
				}, group.value) })
			]
		})]
	});
}
//#endregion
export { LocationSelect as n, CountryFlag as r, LocationChipSelect as t };
