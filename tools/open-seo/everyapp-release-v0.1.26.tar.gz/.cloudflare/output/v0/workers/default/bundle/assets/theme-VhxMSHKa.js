import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { o as isEveryAppClientAuthMode } from "./auth-mode-DhGCw2Bx.js";
import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { t as everyAppAccountQueryOptions } from "./everyAppAccountQueries-C9mjQ_j3.js";
//#region src/client/lib/themeCookie.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var THEME_COOKIE_PATTERN = /(?:^|;\s*)everyapp-theme=(system|light|dark)(?:;|$)/;
/** The pick in a `document.cookie` string, or null when there is none. */
function readThemeCookie(cookie) {
	const value = THEME_COOKIE_PATTERN.exec(cookie)?.[1];
	return value === "system" || value === "light" || value === "dark" ? value : null;
}
/**
* The cookie's Domain: the gateway's hostname, when the page is on it or on
* one of its subdomains. Null otherwise (a custom hostname, or no gateway),
* and the pick then stays in localStorage.
*/
function themeCookieDomain(pageHostname, gatewayUrl) {
	if (!gatewayUrl) return null;
	const gateway = new URL(gatewayUrl).hostname.toLowerCase();
	const page = pageHostname.toLowerCase();
	if (page === gateway || page.endsWith(`.${gateway}`)) return gateway;
	return null;
}
/** The `document.cookie` assignment that stores a pick. */
function themeCookieString(themePreference, domain, secure) {
	return [
		`everyapp-theme=${themePreference}`,
		...domain.includes(".") ? [`Domain=${domain}`] : [],
		"Path=/",
		"Max-Age=31536000",
		"SameSite=Lax",
		...secure ? ["Secure"] : []
	].join("; ");
}
//#endregion
//#region src/client/lib/theme.ts
var LIGHT_THEME_NAME = "openseo";
var DARK_THEME_NAME = "openseo-dark";
var THEME_STORAGE_KEY = "theme-preference";
var THEME_CHANGE_EVENT = "theme-preference-change";
var unsavedThemePreference = null;
var everyApp = isEveryAppClientAuthMode();
/** The shared cookie, then this app's own copy, then the OS. */
function readThemePreference() {
	if (typeof window === "undefined") return "system";
	const shared = readThemeCookie(document.cookie);
	if (shared) return shared;
	if (unsavedThemePreference) return unsavedThemePreference;
	try {
		const stored = window.localStorage.getItem(THEME_STORAGE_KEY);
		if (stored === "light" || stored === "dark") return stored;
		return "system";
	} catch {
		return "system";
	}
}
/** Sets the shared cookie when this page is on the gateway host or under it. */
function writeThemeCookie(themePreference, gatewayUrl) {
	const domain = themeCookieDomain(window.location.hostname, gatewayUrl);
	if (!domain) return;
	document.cookie = themeCookieString(themePreference, domain, window.location.protocol === "https:");
}
function writeThemePreference(themePreference, gatewayUrl) {
	writeThemeCookie(themePreference, gatewayUrl);
	try {
		if (themePreference === "system") window.localStorage.removeItem(THEME_STORAGE_KEY);
		else window.localStorage.setItem(THEME_STORAGE_KEY, themePreference);
		unsavedThemePreference = null;
	} catch {
		unsavedThemePreference = themePreference;
	}
}
function resolveThemeName(themePreference) {
	if (themePreference === "light") return LIGHT_THEME_NAME;
	if (themePreference === "dark") return DARK_THEME_NAME;
	if (typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches) return DARK_THEME_NAME;
	return LIGHT_THEME_NAME;
}
function applyThemePreference(themePreference) {
	if (typeof document === "undefined") return;
	document.documentElement.setAttribute("data-theme", resolveThemeName(themePreference));
}
function subscribeToThemePreference(onStoreChange) {
	if (typeof window === "undefined") return () => {};
	const handleThemeChange = () => {
		onStoreChange();
	};
	const handleStorage = (event) => {
		if (event.key && event.key !== THEME_STORAGE_KEY) return;
		onStoreChange();
	};
	const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
	const handleMediaChange = () => {
		applyThemePreference(readThemePreference());
		onStoreChange();
	};
	const handleVisibility = () => {
		if (document.visibilityState === "visible") onStoreChange();
	};
	window.addEventListener(THEME_CHANGE_EVENT, handleThemeChange);
	window.addEventListener("storage", handleStorage);
	mediaQuery.addEventListener("change", handleMediaChange);
	document.addEventListener("visibilitychange", handleVisibility);
	return () => {
		window.removeEventListener(THEME_CHANGE_EVENT, handleThemeChange);
		window.removeEventListener("storage", handleStorage);
		mediaQuery.removeEventListener("change", handleMediaChange);
		document.removeEventListener("visibilitychange", handleVisibility);
	};
}
function useThemePreference() {
	const themePreference = import_react.useSyncExternalStore(subscribeToThemePreference, readThemePreference, () => "system");
	const gatewayUrl = useQuery({
		...everyAppAccountQueryOptions(),
		enabled: everyApp
	}).data?.gatewayUrl;
	import_react.useEffect(() => {
		applyThemePreference(themePreference);
	}, [themePreference]);
	import_react.useEffect(() => {
		if (THEME_COOKIE_PATTERN.test(document.cookie)) return;
		const own = readThemePreference();
		if (own !== "system") writeThemeCookie(own, gatewayUrl);
	}, [gatewayUrl]);
	return {
		themePreference,
		setThemePreference: import_react.useCallback((nextThemePreference) => {
			writeThemePreference(nextThemePreference, gatewayUrl);
			applyThemePreference(nextThemePreference);
			window.dispatchEvent(new Event(THEME_CHANGE_EVENT));
		}, [gatewayUrl])
	};
}
var themePreferenceInitScript = `(() => {
  try {
    var m = ${THEME_COOKIE_PATTERN.toString()}.exec(document.cookie);
    var p = m ? m[1] : window.localStorage.getItem(${JSON.stringify(THEME_STORAGE_KEY)});
    var t;
    if (p === "light") t = ${JSON.stringify(LIGHT_THEME_NAME)};
    else if (p === "dark") t = ${JSON.stringify(DARK_THEME_NAME)};
    else t = window.matchMedia("(prefers-color-scheme: dark)").matches ? ${JSON.stringify(DARK_THEME_NAME)} : ${JSON.stringify(LIGHT_THEME_NAME)};
    document.documentElement.setAttribute("data-theme", t);
  } catch {
    document.documentElement.setAttribute("data-theme", ${JSON.stringify(LIGHT_THEME_NAME)});
  }
})();`;
//#endregion
export { useThemePreference as n, themePreferenceInitScript as t };
