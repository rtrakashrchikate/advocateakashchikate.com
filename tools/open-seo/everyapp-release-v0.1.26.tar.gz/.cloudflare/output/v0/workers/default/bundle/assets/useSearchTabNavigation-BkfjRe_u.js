import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { Fn as object, Jn as string, Lt as boolean, Nt as array, xn as literal } from "./schemas-BPIpYT5n.js";
import { s as t } from "./r2-cache-DRcgqCM_.js";
import { t as e } from "./identity-41c0vDC1.js";
import { p as researchScopeSchema } from "./researchScope-DHudUdg3.js";
import { f as referringDomainsPageRequestSchema, h as topPagesPageRequestSchema, i as backlinksOverviewInputSchema, s as backlinksRowsPageRequestSchema } from "./backlinks-S5589jFF.js";
import { o as formatLocationLabel, r as LOCATIONS } from "./keyword-locations-4GfvBtRY.js";
import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { r as getStandardErrorMessage } from "./error-messages-D7nntGF_.js";
import { r as explorePrompt } from "./useLocalHistoryStore-h4ZxP0MM.js";
import { r as Spinner } from "./button-DrcZrdio.js";
import { t as X } from "./x-CPPij64W.js";
import { n as captureClientEvent } from "./posthog-BMFJOGWd.js";
import { t as createSsrRpc } from "./createSsrRpc-Vp3C13VD.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { c as promptExplorerModelSchema, d as webSearchCountrySelectionSchema } from "./ai-search-BKw5OSiv.js";
import { a as parseKeywordInput } from "./keywordControllerActions-CAEuADf3.js";
import { l as researchKeywords } from "./keywords-C2EkWdz5.js";
import { r as getDomainOverview } from "./domain-Dq_XJCyt.js";
//#region src/client/features/keywords/hooks/useKeywordResearchData.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var KEYWORD_RESEARCH_STALE_TIME_MS = 864e5;
function buildKeywordResearchRequest(input) {
	const keywords = parseKeywordInput(input.keywordInput);
	const seedKeyword = keywords[0] ?? "";
	if (!seedKeyword) return null;
	return {
		projectId: input.projectId,
		keywords,
		seedKeyword,
		locationCode: input.locationCode,
		locationName: input.locationName,
		resultLimit: input.resultLimit,
		mode: input.mode,
		clickstream: input.clickstream,
		groupKeywords: input.groupKeywords
	};
}
function buildKeywordResearchQueryKey(request) {
	return request ? [
		"keywordResearch",
		request.projectId,
		request.keywords,
		request.locationCode,
		request.locationName,
		request.resultLimit,
		request.mode,
		request.clickstream,
		request.groupKeywords
	] : ["keywordResearch", "idle"];
}
function keywordResearchQueryFn(request) {
	return researchKeywords({ data: {
		projectId: request.projectId,
		keywords: request.keywords,
		locationCode: request.locationCode,
		locationName: request.locationName,
		resultLimit: request.resultLimit,
		mode: request.mode,
		clickstream: request.clickstream,
		groupKeywords: request.groupKeywords
	} });
}
function useKeywordResearchData(input, addSearch) {
	const { clickstream, groupKeywords, displayedLocationCode, keywordInput, locationCode, locationName, mode, projectId, resultLimit } = input;
	const request = (0, import_react.useMemo)(() => buildKeywordResearchRequest({
		keywordInput,
		locationCode,
		locationName,
		mode,
		projectId,
		resultLimit,
		clickstream,
		groupKeywords
	}), [
		clickstream,
		groupKeywords,
		keywordInput,
		locationCode,
		locationName,
		mode,
		projectId,
		resultLimit
	]);
	const queryKey = (0, import_react.useMemo)(() => buildKeywordResearchQueryKey(request), [request]);
	const queryKeyString = JSON.stringify(queryKey);
	const researchQuery = useQuery({
		queryKey,
		queryFn: () => {
			if (!request) throw new Error("Keyword research query ran without request params");
			return keywordResearchQueryFn(request);
		},
		enabled: request !== null,
		staleTime: KEYWORD_RESEARCH_STALE_TIME_MS,
		gcTime: KEYWORD_RESEARCH_STALE_TIME_MS,
		retry: false,
		refetchOnReconnect: false,
		refetchOnWindowFocus: false
	});
	const handledSuccessKeyRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		if (!request || !researchQuery.isSuccess || !researchQuery.data) return;
		if (handledSuccessKeyRef.current === queryKeyString) return;
		handledSuccessKeyRef.current = queryKeyString;
		captureClientEvent("keyword_research:search_complete", {
			location_code: displayedLocationCode,
			search_mode: request.mode,
			clickstream: request.clickstream,
			local: request.locationName !== void 0,
			result_count: researchQuery.data.rows.length
		});
		addSearch(request.seedKeyword, displayedLocationCode, request.locationName ? formatLocationLabel(request.locationName) : LOCATIONS[displayedLocationCode] || "Unknown", request.locationName);
	}, [
		addSearch,
		displayedLocationCode,
		queryKeyString,
		request,
		researchQuery.data,
		researchQuery.isSuccess
	]);
	const hasSearched = parseKeywordInput(keywordInput).length > 0;
	const rows = hasSearched ? researchQuery.data?.rows ?? [] : [];
	const researchError = hasSearched && researchQuery.isError ? getStandardErrorMessage(researchQuery.error, "Research failed.") : null;
	return {
		rows,
		hasSearched,
		lastSearchError: hasSearched && researchQuery.isError,
		lastSearchKeyword: request?.seedKeyword ?? "",
		lastSearchLocationCode: displayedLocationCode,
		researchError,
		researchMutationError: researchQuery.error,
		searchedKeyword: request?.seedKeyword ?? "",
		isLoading: hasSearched && researchQuery.isPending,
		researchQuery,
		retryResearch: researchQuery.refetch
	};
}
//#endregion
//#region src/client/features/ai-search/promptExplorerQuery.ts
var PROMPT_EXPLORER_STALE_TIME_MS = 864e5;
function buildPromptExplorerQueryKey(projectId, search) {
	return [
		"prompt-explorer",
		projectId,
		search.prompt.trim(),
		t(search.models, e()).join(","),
		search.webSearch,
		search.webSearchCountryCode,
		search.highlightBrand.trim()
	];
}
function promptExplorerQueryFn(projectId, search) {
	return explorePrompt({ data: {
		projectId,
		prompt: search.prompt.trim(),
		models: search.models,
		highlightBrand: search.highlightBrand.trim() || void 0,
		webSearch: search.webSearch,
		webSearchCountryCode: search.webSearchCountryCode === "default" ? void 0 : search.webSearchCountryCode
	} });
}
//#endregion
//#region src/serverFunctions/backlinks.ts
var getBacklinksOverview = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(backlinksOverviewInputSchema).handler(createSsrRpc("a49c4261f3f65e415401c7162c49edf3e6134bc3554b0b96f1230779dcdebd9b"));
var getBacklinksRows = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(backlinksRowsPageRequestSchema).handler(createSsrRpc("a4a9247a2916093ffa4adf9b4628e1d7f55af8b119ae1f0147a8b5ef5fd08691"));
var getBacklinksReferringDomains = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(referringDomainsPageRequestSchema).handler(createSsrRpc("0c268077775b1f812d23756142e5d64fff541f1240b6328a92da446160513af2"));
var getBacklinksTopPages = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(topPagesPageRequestSchema).handler(createSsrRpc("47f4e168632e9bfd56794677badebb717fc5ce10103810690f0c3bdc5d098227"));
//#endregion
//#region src/client/features/search-tabs/SearchTabStrip.tsx
var import_jsx_runtime = require_jsx_runtime();
function SearchTabStrip({ activeTabId, projectId, tabs, onSelect, onClose, onViewed, embedded = false }) {
	if (tabs.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: embedded ? "border-t border-border pt-3" : "rounded-xl border border-border bg-card p-1",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			role: "tablist",
			"aria-label": "Search tabs",
			className: "flex min-w-0 items-stretch gap-1 overflow-x-auto",
			children: tabs.map((tab) => {
				const active = tab.id === activeTabId;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					"data-search-tab-id": tab.id,
					className: `group flex shrink-0 items-stretch overflow-hidden rounded-md text-sm transition ${active ? "bg-muted text-foreground shadow-sm" : "text-muted-foreground hover:bg-foreground/5 hover:text-foreground"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						role: "tab",
						"data-search-tab-id": tab.id,
						"aria-selected": active,
						className: "flex min-w-0 items-center gap-1.5 px-2.5 py-1.5 text-left",
						onClick: () => onSelect(tab),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchTabStatus, {
							tab,
							projectId,
							active,
							onViewed
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "max-w-[10rem] truncate font-medium",
							title: tab.label,
							children: tab.label
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"data-search-tab-id": tab.id,
						className: "flex items-center px-1.5 text-muted-foreground opacity-60 transition hover:bg-foreground/10 hover:text-foreground hover:opacity-100 group-hover:opacity-100",
						onClick: () => onClose(tab.id),
						"aria-label": `Close ${tab.label} tab`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
					})]
				}, tab.id);
			})
		})
	});
}
function SearchTabStatus({ tab, projectId, active, onViewed }) {
	const config = getSearchTabQueryConfig(projectId, tab);
	const query = useQuery({
		queryKey: config.queryKey,
		queryFn: config.queryFn,
		enabled: false,
		select: () => null,
		notifyOnChangeProps: [
			"dataUpdatedAt",
			"fetchStatus",
			"status"
		],
		staleTime: config.staleTime,
		gcTime: config.gcTime
	});
	const isLoading = query.fetchStatus === "fetching";
	const hasResult = query.dataUpdatedAt > 0;
	const hasError = query.status === "error";
	const unviewed = !active && hasResult && (tab.viewedAt === null || tab.viewedAt < query.dataUpdatedAt);
	(0, import_react.useEffect)(() => {
		if (!active) return;
		if (!hasResult) return;
		if (tab.viewedAt !== null && tab.viewedAt >= query.dataUpdatedAt) return;
		onViewed(tab.id, query.dataUpdatedAt);
	}, [
		active,
		hasResult,
		onViewed,
		query.dataUpdatedAt,
		tab.id,
		tab.viewedAt
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchTabStatusIndicator, { status: isLoading ? "loading" : hasError ? "error" : unviewed ? "unviewed" : "idle" });
}
function SearchTabStatusIndicator({ status }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex w-3.5 shrink-0 items-center justify-center",
		"aria-hidden": true,
		children: status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { className: "size-3 text-muted-foreground" }) : status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-destructive" }) : status === "unviewed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-primary" }) : null
	});
}
function getSearchTabQueryConfig(projectId, tab) {
	if (tab.input.type === "backlinks") {
		const input = tab.input;
		return {
			queryKey: [
				"backlinksOverview",
				projectId,
				input.scope,
				input.target
			],
			queryFn: () => getBacklinksOverview({ data: {
				projectId,
				target: input.target,
				scope: input.scope
			} })
		};
	}
	if (tab.input.type === "prompt") {
		const input = tab.input;
		return {
			queryKey: buildPromptExplorerQueryKey(projectId, input),
			queryFn: () => promptExplorerQueryFn(projectId, input),
			staleTime: PROMPT_EXPLORER_STALE_TIME_MS,
			gcTime: PROMPT_EXPLORER_STALE_TIME_MS
		};
	}
	if (tab.input.type === "domain") {
		const input = tab.input;
		const trimmedDomain = input.domain.trim();
		return {
			queryKey: [
				"domain-overview",
				projectId,
				trimmedDomain,
				input.scope,
				input.locationCode
			],
			queryFn: () => getDomainOverview({ data: {
				projectId,
				domain: trimmedDomain,
				scope: input.scope,
				locationCode: input.locationCode
			} }),
			staleTime: 3e5
		};
	}
	const input = tab.input;
	const request = buildKeywordResearchRequest({
		projectId,
		keywordInput: input.keyword,
		locationCode: input.locationCode,
		locationName: input.locationName,
		resultLimit: input.resultLimit,
		mode: input.mode,
		clickstream: input.clickstream,
		groupKeywords: input.groupKeywords
	});
	return {
		queryKey: buildKeywordResearchQueryKey(request),
		queryFn: () => {
			if (!request) throw new Error("Tab is missing a research request");
			return keywordResearchQueryFn(request);
		},
		staleTime: KEYWORD_RESEARCH_STALE_TIME_MS,
		gcTime: KEYWORD_RESEARCH_STALE_TIME_MS
	};
}
//#endregion
//#region src/client/features/search-tabs/useSearchTabs.ts
var EMPTY_STATE = {
	tabs: [],
	activeTabId: null
};
var CHANGE_EVENT = "search-tabs-change";
var stateCache = /* @__PURE__ */ new Map();
var SEARCH_TABS_LIMIT = 20;
var promptTabInputSchema = object({
	type: literal("prompt"),
	prompt: string().min(1),
	highlightBrand: string(),
	models: array(promptExplorerModelSchema).min(1),
	webSearch: boolean(),
	webSearchCountryCode: webSearchCountrySelectionSchema
});
function isRecord(value) {
	return typeof value === "object" && value !== null;
}
function toResearchScope(value) {
	const parsed = researchScopeSchema.safeParse(value);
	return parsed.success ? parsed.data : null;
}
function parseTabInput(value) {
	if (!isRecord(value)) return null;
	if (value.type === "backlinks") {
		if (typeof value.target !== "string" || value.target === "") return null;
		const scope = value.scope === "page" ? "exact_url" : toResearchScope(value.scope);
		if (!scope) return null;
		return {
			type: "backlinks",
			target: value.target,
			scope
		};
	}
	if (value.type === "domain") {
		if (typeof value.domain !== "string" || value.domain === "") return null;
		if (value.locationCode !== void 0 && typeof value.locationCode !== "number") return null;
		const scope = toResearchScope(value.scope) ?? (typeof value.subdomains === "boolean" ? value.subdomains ? "subdomains" : "domain" : null);
		if (!scope) return null;
		return {
			type: "domain",
			domain: value.domain,
			scope,
			locationCode: typeof value.locationCode === "number" ? value.locationCode : void 0
		};
	}
	if (value.type === "keyword") {
		if (typeof value.keyword !== "string" || value.keyword === "") return null;
		if (value.locationCode !== void 0 && typeof value.locationCode !== "number") return null;
		if (value.resultLimit !== 150 && value.resultLimit !== 300 && value.resultLimit !== 500) return null;
		if (value.mode !== "auto" && value.mode !== "related" && value.mode !== "suggestions" && value.mode !== "ideas") return null;
		return {
			type: "keyword",
			keyword: value.keyword,
			locationCode: typeof value.locationCode === "number" ? value.locationCode : void 0,
			locationName: typeof value.locationName === "string" ? value.locationName : void 0,
			resultLimit: value.resultLimit,
			mode: value.mode,
			clickstream: value.clickstream === true,
			groupKeywords: value.groupKeywords === true
		};
	}
	if (value.type === "prompt") return promptTabInputSchema.safeParse(value).data ?? null;
	return null;
}
function storageKey(key) {
	return `search-tabs:${key}`;
}
function tabInputKey$1(value) {
	return JSON.stringify(value);
}
function parseStoredState(value) {
	if (!isRecord(value)) return EMPTY_STATE;
	if (!Array.isArray(value.tabs)) return EMPTY_STATE;
	const tabs = value.tabs.flatMap((tab) => {
		if (!isRecord(tab)) return [];
		if (typeof tab.id !== "string" || tab.id === "") return [];
		if (typeof tab.label !== "string" || tab.label === "") return [];
		if (typeof tab.createdAt !== "number") return [];
		const input = parseTabInput(tab.input);
		if (!input) return [];
		return [{
			id: tab.id,
			label: tab.label,
			input,
			createdAt: tab.createdAt,
			viewedAt: tab.viewedAt === null ? null : typeof tab.viewedAt === "number" ? tab.viewedAt : null
		}];
	}).slice(-20);
	return {
		tabs,
		activeTabId: typeof value.activeTabId === "string" && tabs.some((tab) => tab.id === value.activeTabId) ? value.activeTabId : null
	};
}
function loadState(key) {
	if (typeof window === "undefined") return EMPTY_STATE;
	try {
		const raw = window.sessionStorage.getItem(storageKey(key));
		if (!raw) return EMPTY_STATE;
		return parseStoredState(JSON.parse(raw));
	} catch {
		return EMPTY_STATE;
	}
}
function getSearchTabsSnapshot(key) {
	let state = stateCache.get(key);
	if (!state) {
		state = loadState(key);
		stateCache.set(key, state);
	}
	return state;
}
function persist(key, state) {
	if (typeof window === "undefined") return;
	try {
		window.sessionStorage.setItem(storageKey(key), JSON.stringify(state));
	} catch {}
}
function notify() {
	if (typeof window === "undefined") return;
	window.dispatchEvent(new Event(CHANGE_EVENT));
}
function update(key, updater) {
	const current = getSearchTabsSnapshot(key);
	const next = updater(current);
	if (next === current) return;
	stateCache.set(key, next);
	persist(key, next);
	notify();
}
function subscribe(onChange) {
	if (typeof window === "undefined") return () => {};
	window.addEventListener(CHANGE_EVENT, onChange);
	return () => window.removeEventListener(CHANGE_EVENT, onChange);
}
function appendTabWithEviction(tabs, next) {
	return [...tabs.slice(Math.max(0, tabs.length - SEARCH_TABS_LIMIT + 1)), next];
}
function generateTabId() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `tab_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}
function useSearchTabs(key) {
	const state = (0, import_react.useSyncExternalStore)(subscribe, () => getSearchTabsSnapshot(key), () => EMPTY_STATE);
	const openTab = (0, import_react.useCallback)(({ label, input }) => {
		update(key, (current) => {
			const inputKey = tabInputKey$1(input);
			const existing = current.tabs.find((tab) => tabInputKey$1(tab.input) === inputKey);
			if (existing) return {
				...current,
				activeTabId: existing.id
			};
			const next = {
				id: generateTabId(),
				label,
				input,
				createdAt: Date.now(),
				viewedAt: null
			};
			return {
				tabs: appendTabWithEviction(current.tabs, next),
				activeTabId: next.id
			};
		});
	}, [key]);
	const setActiveTab = (0, import_react.useCallback)((tabId) => {
		update(key, (current) => {
			if (current.activeTabId === tabId) return current;
			if (tabId !== null && !current.tabs.some((tab) => tab.id === tabId)) return current;
			return {
				...current,
				activeTabId: tabId
			};
		});
	}, [key]);
	const closeTab = (0, import_react.useCallback)((tabId) => {
		let nextActiveTab = null;
		let closedActive = false;
		update(key, (current) => {
			const index = current.tabs.findIndex((tab) => tab.id === tabId);
			if (index === -1) return current;
			const tabs = current.tabs.filter((tab) => tab.id !== tabId);
			let activeTabId = current.activeTabId;
			if (current.activeTabId === tabId) {
				closedActive = true;
				const neighbor = tabs[index] ?? tabs[index - 1] ?? null;
				activeTabId = neighbor?.id ?? null;
				nextActiveTab = neighbor;
			}
			return {
				tabs,
				activeTabId
			};
		});
		return {
			closedActive,
			nextActiveTab
		};
	}, [key]);
	const markTabViewed = (0, import_react.useCallback)((tabId, when = Date.now()) => {
		update(key, (current) => {
			let changed = false;
			const tabs = current.tabs.map((tab) => {
				if (tab.id !== tabId) return tab;
				if (tab.viewedAt !== null && tab.viewedAt >= when) return tab;
				changed = true;
				return {
					...tab,
					viewedAt: when
				};
			});
			if (!changed) return current;
			return {
				...current,
				tabs
			};
		});
	}, [key]);
	const findMatchingTab = (0, import_react.useCallback)((input) => {
		const inputKey = tabInputKey$1(input);
		return state.tabs.find((tab) => tabInputKey$1(tab.input) === inputKey) ?? null;
	}, [state.tabs]);
	return {
		activeTab: (0, import_react.useMemo)(() => state.tabs.find((tab) => tab.id === state.activeTabId) ?? null, [state.activeTabId, state.tabs]),
		activeTabId: state.activeTabId,
		tabs: state.tabs,
		closeTab,
		findMatchingTab,
		markTabViewed,
		openTab,
		setActiveTab
	};
}
//#endregion
//#region src/client/features/search-tabs/useSearchTabNavigation.ts
function tabInputKey(input) {
	return input ? JSON.stringify(input) : "";
}
function useSearchTabNavigation({ storageKey, urlInput, getLabel, navigateToInput }) {
	const closedInputKeysRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const tabs = useSearchTabs(storageKey);
	const { activeTabId, closeTab, findMatchingTab, markTabViewed, openTab, setActiveTab } = tabs;
	(0, import_react.useEffect)(() => {
		const urlKey = tabInputKey(urlInput);
		if (closedInputKeysRef.current.has(urlKey)) return;
		closedInputKeysRef.current.clear();
		if (!urlInput) {
			setActiveTab(null);
			return;
		}
		const existing = findMatchingTab(urlInput);
		if (existing) {
			if (activeTabId !== existing.id) setActiveTab(existing.id);
			return;
		}
		openTab({
			label: getLabel(urlInput),
			input: urlInput
		});
	}, [
		activeTabId,
		findMatchingTab,
		getLabel,
		openTab,
		setActiveTab,
		urlInput
	]);
	const selectTab = (0, import_react.useCallback)((tab) => {
		closedInputKeysRef.current.delete(tabInputKey(tab.input));
		setActiveTab(tab.id);
		navigateToInput(tab.input);
	}, [navigateToInput, setActiveTab]);
	const closeSearchTab = (0, import_react.useCallback)((tabId) => {
		const closingTab = tabs.tabs.find((tab) => tab.id === tabId) ?? null;
		if (closingTab) closedInputKeysRef.current.add(tabInputKey(closingTab.input));
		const result = closeTab(tabId);
		if (result.closedActive) navigateToInput(result.nextActiveTab?.input ?? null);
	}, [
		closeTab,
		navigateToInput,
		tabs.tabs
	]);
	const openSearchTab = (0, import_react.useCallback)((input) => {
		closedInputKeysRef.current.delete(tabInputKey(input));
		openTab({
			label: getLabel(input),
			input
		});
	}, [getLabel, openTab]);
	const visibleTabs = (0, import_react.useMemo)(() => tabs.tabs.filter((tab) => !closedInputKeysRef.current.has(tabInputKey(tab.input))), [tabs.tabs]);
	return {
		activeTabId: tabs.activeTabId,
		tabs: visibleTabs,
		closeTab: closeSearchTab,
		markTabViewed,
		openTab: openSearchTab,
		selectTab,
		setActiveTab
	};
}
//#endregion
export { getBacklinksReferringDomains as a, PROMPT_EXPLORER_STALE_TIME_MS as c, useKeywordResearchData as d, getBacklinksOverview as i, buildPromptExplorerQueryKey as l, useSearchTabNavigation as n, getBacklinksRows as o, SearchTabStrip as r, getBacklinksTopPages as s, tabInputKey as t, promptExplorerQueryFn as u };
