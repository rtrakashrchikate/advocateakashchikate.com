import { ct as sql, lt as Column, ut as is } from "./db-DhHkpZWI.js";
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sql/functions/aggregate.js
function count(expression) {
	return sql`count(${expression || sql.raw("*")})`.mapWith(Number);
}
function countDistinct(expression) {
	return sql`count(distinct ${expression})`.mapWith(Number);
}
function sum(expression) {
	return sql`sum(${expression})`.mapWith(String);
}
function max(expression) {
	return sql`max(${expression})`.mapWith(is(expression, Column) ? expression : String);
}
function min(expression) {
	return sql`min(${expression})`.mapWith(is(expression, Column) ? expression : String);
}
//#endregion
export { sum as a, min as i, countDistinct as n, max as r, count as t };
