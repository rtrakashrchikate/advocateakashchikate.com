import { Fn as object, Jn as string, Pn as number } from "./schemas-BPIpYT5n.js";
import { U as AppError } from "./onboarding-drip-B7bIbv_6.js";
import { o as isHostedServerAuthMode } from "./runtime-env-eoXh4Ywz.js";
import { n as toRankTrackingTimestamp, t as RankTrackingRepository } from "./RankTrackingRepository-JQXdgQbb.js";
import { r as reconcileActiveRankCheckRun, t as beginRankCheckRun } from "./rankCheckRunGuards-Dh6BcznM.js";
import { n as customerHasPaidPlan } from "./subscription-DYEizD5D.js";
import { a as devicesCount, c as estimateScheduledRankCheckCredits, f as rankCheckCostApprovalError, r as computeNextCheckAt, s as estimateRankCheckCredits, t as MAX_KEYWORDS_PER_CONFIG, u as isScheduledRankTrackingInterval } from "./rank-tracking-CfsrxyGC.js";
import { t as createDataforseoClient } from "./client-D7Glrscv.js";
import { l as invalidFieldName, n as dataforseoPost } from "./core-CaMSzKx_.js";
import { _ as resolveMarket, h as resolveKeywordDataLanguage, s as getIsoCountryCode } from "./keyword-locations-4GfvBtRY.js";
import { n as fetchKeywordMetricsForList } from "./keyword-metrics-Dws_fIDn.js";
import { env } from "cloudflare:workers";
//#region src/server/lib/dataforseo/serp-location-validate.ts
var DATAFORSEO_SANDBOX_URL = "https://sandbox.dataforseo.com";
var SANDBOX_TIMEOUT_MS = 1e4;
var sandboxTaskSchema = object({
	status_code: number(),
	status_message: string()
});
/**
* Ask the DataForSEO sandbox whether a SERP task with this location and
* language would be accepted. The sandbox returns canned results but validates
* request fields exactly like production and costs nothing, so a 20000 here
* means the live endpoint will take the name too.
*/
function probeSerpLocation(locationName, languageCode, options = {}) {
	return dataforseoPost("/v3/serp/google/organic/live/advanced", [{
		keyword: "pizza",
		location_name: locationName,
		language_code: languageCode,
		depth: 10
	}], {
		baseUrl: DATAFORSEO_SANDBOX_URL,
		signal: options.signal
	}).then((response) => sandboxTaskSchema.parse(response?.tasks?.[0]));
}
/**
* Reject a non-canonical `location_name` at save time instead of at check
* time. DataForSEO matches `location_name` verbatim, so "Catonsville, MD"
* fails every run with task status 40501 and the tracker silently records no
* snapshots.
*
* Fails open: a sandbox outage must not block saving a tracker, and the worst
* case is the pre-existing behaviour for that one config.
*/
async function assertSerpLocationNameAccepted(input) {
	let task;
	try {
		task = await probeSerpLocation(input.locationName, input.languageCode, { signal: AbortSignal.timeout(SANDBOX_TIMEOUT_MS) });
	} catch (error) {
		console.warn("[serp-location-validate] sandbox unavailable, skipping", { error: error instanceof Error ? error.message : String(error) });
		return;
	}
	if (task.status_code === 2e4) return;
	if (task.status_code < 4e4 || task.status_code >= 5e4) {
		console.warn("[serp-location-validate] sandbox unavailable, skipping", task);
		return;
	}
	if (invalidFieldName(task.status_message) !== "location_name") throw new AppError("VALIDATION_ERROR", `DataForSEO rejected this tracker: ${task.status_message}`);
	throw new AppError("VALIDATION_ERROR", `"${input.locationName}" is not a Google location name. Call search_serp_locations({ query: "${input.locationName.split(",")[0].trim()}"${input.countryCode ? `, countryCode: "${input.countryCode}"` : ""} }) and pass the returned locationName exactly.`);
}
//#endregion
//#region src/server/features/rank-tracking/services/configSchedule.ts
function resolveNextCheckAt(scheduleInterval, scheduleTime) {
	if (isScheduledRankTrackingInterval(scheduleInterval)) {
		if (scheduleInterval === "weekly" && scheduleTime && scheduleTime.weekday === void 0) throw new AppError("VALIDATION_ERROR", "A weekly schedule time needs a weekday");
		return computeNextCheckAt(scheduleInterval, null, scheduleTime);
	}
	if (scheduleTime) throw new AppError("VALIDATION_ERROR", "A schedule time needs a daily, weekly, or monthly schedule");
	return null;
}
//#endregion
//#region src/server/features/rank-tracking/services/rankTrackingResults.ts
var PERIOD_DAYS = {
	"1d": 1,
	"7d": 7,
	"30d": 30,
	"90d": 90
};
async function getLatestResults(configId, projectId, comparePeriod = "7d") {
	const days = PERIOD_DAYS[comparePeriod];
	const targetDate = toRankTrackingTimestamp(/* @__PURE__ */ new Date(Date.now() - days * 24 * 60 * 60 * 1e3));
	const [config, activeKeywords, currentSnapshots, comparisonSnapshots, latestRun] = await Promise.all([
		RankTrackingRepository.getConfigById({
			configId,
			projectId
		}),
		RankTrackingRepository.getKeywordsForConfig(configId),
		RankTrackingRepository.getLatestSnapshotsForKeywords(configId),
		RankTrackingRepository.getSnapshotsBeforeDate(configId, targetDate),
		RankTrackingRepository.getLatestRunForConfig(configId)
	]);
	if (!config) throw new AppError("INTERNAL_ERROR", "Rank tracking config not found");
	const previousPositions = /* @__PURE__ */ new Map();
	for (const snap of comparisonSnapshots) previousPositions.set(`${snap.trackingKeywordId}:${snap.device}`, snap.position);
	const missingKeywordIds = [];
	for (const snap of currentSnapshots) {
		const key = `${snap.trackingKeywordId}:${snap.device}`;
		if (!previousPositions.has(key)) missingKeywordIds.push(snap.trackingKeywordId);
	}
	if (missingKeywordIds.length > 0) {
		const uniqueMissingIds = [...new Set(missingKeywordIds)];
		const earliestSnapshots = await RankTrackingRepository.getEarliestSnapshotsForKeywords(configId, uniqueMissingIds);
		for (const snap of earliestSnapshots) {
			const key = `${snap.trackingKeywordId}:${snap.device}`;
			if (!previousPositions.has(key)) previousPositions.set(key, snap.position);
		}
	}
	const rows = new Map(activeKeywords.map((keyword) => [keyword.id, {
		trackingKeywordId: keyword.id,
		keyword: keyword.keyword,
		matchCase: keyword.matchCase,
		pinned: keyword.pinnedAt !== null,
		searchVolume: keyword.searchVolume,
		keywordDifficulty: keyword.keywordDifficulty,
		cpc: keyword.cpc,
		desktop: createEmptyDeviceResult(previousPositions.get(`${keyword.id}:desktop`) ?? null),
		mobile: createEmptyDeviceResult(previousPositions.get(`${keyword.id}:mobile`) ?? null)
	}]));
	let latestStartedAt = null;
	for (const snapshot of currentSnapshots) {
		const row = rows.get(snapshot.trackingKeywordId);
		if (!row) continue;
		row[snapshot.device] = toDeviceResult(snapshot, previousPositions.get(`${snapshot.trackingKeywordId}:${snapshot.device}`) ?? null);
		if (!latestStartedAt || snapshot.checkedAt > latestStartedAt) latestStartedAt = snapshot.checkedAt;
	}
	return {
		rows: [...rows.values()],
		run: latestRun ? {
			id: latestRun.id,
			lastCheckedAt: latestStartedAt,
			completedAt: latestRun.completedAt,
			status: latestRun.status,
			errorMessage: latestRun.status === "completed" || latestRun.status === "failed" ? latestRun.errorMessage : null
		} : null
	};
}
function parseSerpFeatures(raw) {
	if (!raw) return [];
	try {
		const parsed = JSON.parse(raw);
		if (Array.isArray(parsed)) return parsed.filter((item) => typeof item === "string");
	} catch {}
	return [];
}
function createEmptyDeviceResult(previousPosition) {
	return {
		position: null,
		previousPosition,
		rankingUrl: null,
		serpFeatures: [],
		checkedAt: null
	};
}
function toDeviceResult(snapshot, previousPosition) {
	return {
		position: snapshot.position,
		previousPosition,
		rankingUrl: snapshot.url,
		serpFeatures: parseSerpFeatures(snapshot.serpFeatures),
		checkedAt: snapshot.checkedAt
	};
}
//#endregion
//#region src/server/features/rank-tracking/services/RankTrackingKeywordService.ts
async function addKeywords(configId, projectId, keywords, approval, matchCase = false) {
	const config = await getValidatedConfig$1(configId, projectId);
	const existing = await RankTrackingRepository.getKeywordsForConfig(configId);
	if (existing.length >= 1e3) throw new AppError("INTERNAL_ERROR", `Maximum ${MAX_KEYWORDS_PER_CONFIG} keywords per domain. Currently tracking ${existing.length}.`);
	const existingKeywords = new Set(existing.map((kw) => kw.keyword));
	const available = MAX_KEYWORDS_PER_CONFIG - existing.length;
	const seen = /* @__PURE__ */ new Set();
	const rows = [];
	for (const raw of keywords) {
		if (rows.length >= available) break;
		const trimmed = raw.trim();
		const normalized = matchCase ? trimmed : trimmed.toLocaleLowerCase(config.languageCode);
		if (normalized && !seen.has(normalized) && !existingKeywords.has(normalized) && (matchCase || !existingKeywords.has(trimmed.toLowerCase()))) {
			seen.add(normalized);
			rows.push({
				id: crypto.randomUUID(),
				configId,
				keyword: normalized,
				matchCase
			});
		}
	}
	const scheduleInterval = isScheduledRankTrackingInterval(config.scheduleInterval) ? config.scheduleInterval : null;
	let scheduledEstimate;
	if (rows.length > 0 && scheduleInterval) {
		scheduledEstimate = estimateScheduledRankCheckCredits([...existing, ...rows].map((kw) => kw.keyword), config.devices, config.serpDepth, scheduleInterval);
		if (approval.kind === "credit_ceiling" && (approval.maxEstimatedScheduledCheckCredits == null || scheduledEstimate.costCredits > approval.maxEstimatedScheduledCheckCredits)) throw scheduledApprovalError(scheduleInterval, scheduledEstimate);
	}
	const addedIds = rows.length > 0 ? await RankTrackingRepository.addKeywordsToConfig(rows) : [];
	if (scheduledEstimate && scheduleInterval && addedIds.length > 0 && approval.kind === "credit_ceiling") {
		const persisted = await RankTrackingRepository.getKeywordsForConfig(configId);
		scheduledEstimate = estimateScheduledRankCheckCredits(persisted.map((kw) => kw.keyword), config.devices, config.serpDepth, scheduleInterval);
		if (approval.maxEstimatedScheduledCheckCredits == null || scheduledEstimate.costCredits > approval.maxEstimatedScheduledCheckCredits) {
			await RankTrackingRepository.removeKeywordsFromConfig(addedIds, configId);
			throw scheduledApprovalError(scheduleInterval, scheduledEstimate);
		}
	}
	return {
		added: addedIds.length,
		addedIds,
		scheduledEstimate
	};
}
async function removeKeywords(configId, projectId, keywordIds) {
	await getValidatedConfig$1(configId, projectId);
	const uniqueIds = [...new Set(keywordIds)];
	const removedIds = await RankTrackingRepository.removeKeywordsFromConfig(uniqueIds, configId);
	return {
		removed: removedIds.length,
		removedIds
	};
}
async function setKeywordsPinned(configId, projectId, keywordIds, pinned) {
	await getValidatedConfig$1(configId, projectId);
	const updatedIds = await RankTrackingRepository.setKeywordsPinned([...new Set(keywordIds)], configId, pinned);
	return {
		updated: updatedIds.length,
		updatedIds
	};
}
async function estimateCost(configId, projectId, additionalKeywords = []) {
	const config = await getValidatedConfig$1(configId, projectId);
	const existing = await RankTrackingRepository.getKeywordsForConfig(configId);
	const existingKeywordCount = existing.length;
	const keywords = [...existing.map((kw) => kw.keyword), ...additionalKeywords].slice(0, Math.max(existingKeywordCount, MAX_KEYWORDS_PER_CONFIG));
	const keywordCount = keywords.length;
	const { costUsd, costCredits } = estimateRankCheckCredits(keywords, config.devices, config.serpDepth);
	const scheduleInterval = isScheduledRankTrackingInterval(config.scheduleInterval) ? config.scheduleInterval : null;
	return {
		costUsd,
		costCredits,
		keywordCount,
		devicesCount: devicesCount(config.devices),
		totalChecks: keywordCount * devicesCount(config.devices),
		existingKeywordCount,
		additionalKeywordCount: keywordCount - existingKeywordCount,
		scheduledEstimate: scheduleInterval ? estimateScheduledRankCheckCredits(keywords, config.devices, config.serpDepth, scheduleInterval) : void 0
	};
}
async function getValidatedConfig$1(configId, projectId) {
	const config = await RankTrackingRepository.getConfigById({
		configId,
		projectId
	});
	if (!config) throw new AppError("NOT_FOUND", "Rank tracking config not found");
	return config;
}
function scheduledApprovalError(scheduleInterval, estimate) {
	return new AppError("VALIDATION_ERROR", `Adding these keywords would make each ${scheduleInterval} scheduled check cost up to ${estimate.costCredits} credits including retries (~$${estimate.costUsd.toFixed(4)} per check; up to ~${estimate.monthlyCostCredits} credits/month). Call estimate_rank_tracker_cost with additionalKeywords, show the recurring estimate to the user, then retry with maxEstimatedScheduledCheckCredits set to the approved per-check estimate.`);
}
var RankTrackingKeywordService = {
	addKeywords,
	removeKeywords,
	setKeywordsPinned,
	estimateCost
};
//#endregion
//#region src/server/features/rank-tracking/services/RankTrackingService.ts
async function createConfig(input) {
	const normalizedDomain = normalizeDomain(input.domain);
	const { locationCode, languageCode } = resolveMarket(input, input.projectMarket);
	const scheduleInterval = input.scheduleInterval ?? "weekly";
	const nextCheckAt = resolveNextCheckAt(scheduleInterval, input.scheduleTime);
	const locationName = input.locationName ?? null;
	if (locationName) await assertSerpLocationNameAccepted({
		locationName,
		languageCode,
		countryCode: getIsoCountryCode(locationCode)
	});
	const existing = await RankTrackingRepository.getConfigByProjectDomainMarket(input.projectId, normalizedDomain, locationCode, languageCode, locationName);
	if (existing?.isActive) throw new AppError("VALIDATION_ERROR", locationName ? "This domain + city + language combination is already being tracked" : "This domain + country + language combination is already being tracked");
	if ((await RankTrackingRepository.getConfigsForProject(input.projectId)).length >= 500) throw new AppError("VALIDATION_ERROR", `Maximum 500 tracked domains per project`);
	if (existing) {
		await RankTrackingRepository.updateConfig(existing.id, input.projectId, {
			isActive: true,
			devices: input.devices ?? "both",
			serpDepth: input.serpDepth,
			scheduleInterval,
			nextCheckAt,
			lastSkipReason: null
		});
		return getValidatedConfig(existing.id, input.projectId);
	}
	const config = {
		id: crypto.randomUUID(),
		projectId: input.projectId,
		domain: normalizedDomain,
		locationCode,
		languageCode,
		locationName,
		devices: input.devices ?? "both",
		serpDepth: input.serpDepth,
		scheduleInterval,
		nextCheckAt,
		isActive: true,
		lastCheckedAt: null,
		lastSkipReason: null,
		createdAt: toRankTrackingTimestamp(/* @__PURE__ */ new Date())
	};
	await RankTrackingRepository.createConfig(config);
	return config;
}
async function updateConfig(configId, projectId, input) {
	const { scheduleTime, ...fields } = input;
	const updates = {};
	const existing = await getValidatedConfig(configId, projectId);
	if (input.locationName !== void 0 || input.locationCode !== void 0 || input.languageCode !== void 0) {
		const locationName = input.locationName === void 0 ? existing.locationName : input.locationName;
		if (locationName) await assertSerpLocationNameAccepted({
			locationName,
			languageCode: input.languageCode ?? existing.languageCode,
			countryCode: getIsoCountryCode(input.locationCode ?? existing.locationCode)
		});
	}
	if (input.domain !== void 0) updates.domain = normalizeDomain(input.domain);
	if (input.locationCode !== void 0) updates.locationCode = input.locationCode;
	if (input.languageCode !== void 0) updates.languageCode = input.languageCode;
	if (input.locationName !== void 0) updates.locationName = input.locationName;
	if (input.devices !== void 0) updates.devices = input.devices;
	if (input.serpDepth !== void 0) updates.serpDepth = input.serpDepth;
	if (input.isActive !== void 0) updates.isActive = input.isActive;
	const scheduleInterval = input.scheduleInterval ?? existing.scheduleInterval;
	if (scheduleTime || scheduleInterval !== existing.scheduleInterval || scheduleInterval !== "manual" && !existing.nextCheckAt) {
		updates.scheduleInterval = scheduleInterval;
		updates.nextCheckAt = resolveNextCheckAt(scheduleInterval, scheduleTime);
	}
	await RankTrackingRepository.updateConfig(configId, projectId, updates);
}
async function triggerCheck(input) {
	const config = await getValidatedConfig(input.configId, input.projectId);
	await requireRankCheckAccess(input.billingCustomer.organizationId);
	const keywords = await RankTrackingRepository.getKeywordsForConfig(config.id);
	if (keywords.length === 0) throw new AppError("INTERNAL_ERROR", "No keywords to track. Add keywords to this domain first.");
	if (input.maxCostCredits != null) {
		const { costCredits } = estimateRankCheckCredits(keywords.map((kw) => kw.keyword), config.devices, config.serpDepth);
		if (costCredits > input.maxCostCredits) throw new AppError("VALIDATION_ERROR", rankCheckCostApprovalError(costCredits, input.maxCostCredits));
	}
	return beginRankCheckRun({
		workflow: env.RANK_CHECK_WORKFLOW,
		config,
		projectId: input.projectId,
		billingCustomer: {
			userId: input.billingCustomer.userId,
			userEmail: input.billingCustomer.userEmail,
			organizationId: input.billingCustomer.organizationId,
			projectId: input.billingCustomer.projectId
		},
		keywordsTotal: input.keywordIds ? input.keywordIds.length : keywords.length,
		keywordIds: input.keywordIds,
		maxCostCredits: input.maxCostCredits,
		trigger: "manual",
		workflowStartErrorMessage: "Failed to start rank check workflow"
	});
}
var AUTO_CHECK_SCHEDULE_WINDOW_MS = 36e5;
async function triggerAutoCheck(input) {
	const config = await getValidatedConfig(input.configId, input.projectId);
	if ((config.nextCheckAt ? new Date(config.nextCheckAt).getTime() - Date.now() : Infinity) <= AUTO_CHECK_SCHEDULE_WINDOW_MS) {
		await requireRankCheckAccess(input.billingCustomer.organizationId);
		return {
			ok: false,
			reason: "scheduled_soon"
		};
	}
	if (!(await RankTrackingRepository.getKeywordCountsForConfigs([config.id])).get(config.id)) return {
		ok: false,
		reason: "no_keywords"
	};
	return triggerCheck(input);
}
async function getLatestRun(configId, projectId) {
	await getValidatedConfig(configId, projectId);
	const run = await RankTrackingRepository.getLatestRunForConfig(configId);
	if (!run) return null;
	const reconciliation = await reconcileActiveRankCheckRun(run);
	if (reconciliation) return formatRun(run, {
		maybeStale: true,
		staleReason: reconciliation.errorMessage
	});
	return formatRun(run);
}
async function refreshKeywordMetrics(configId, projectId, billingCustomer) {
	const config = await getValidatedConfig(configId, projectId);
	await requireRankCheckAccess(billingCustomer.organizationId);
	const keywords = await RankTrackingRepository.getKeywordsForConfig(configId);
	if (keywords.length === 0) return { updated: 0 };
	const client = createDataforseoClient(billingCustomer);
	const lower = (text) => text.toLocaleLowerCase(config.languageCode);
	const metrics = await fetchKeywordMetricsForList(client, {
		keywords: [...new Set(keywords.map((kw) => lower(kw.keyword)))],
		locationCode: config.locationCode,
		languageCode: resolveKeywordDataLanguage(config.locationCode, config.languageCode),
		locationName: config.locationName ?? void 0,
		creditFeature: "rank_tracking"
	});
	const byKeyword = new Map(metrics.map((metric) => [lower(metric.keyword), metric]));
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const updates = keywords.map((kw) => {
		const metric = byKeyword.get(lower(kw.keyword));
		if (!metric) return null;
		return {
			id: kw.id,
			searchVolume: metric.searchVolume,
			keywordDifficulty: metric.keywordDifficulty,
			cpc: metric.cpc,
			metricsFetchedAt: now
		};
	}).filter((u) => u !== null);
	if (updates.length === 0) return { updated: 0 };
	await RankTrackingRepository.updateKeywordMetrics(updates);
	return { updated: updates.length };
}
async function getConfigs(projectId) {
	return RankTrackingRepository.getConfigsForProject(projectId);
}
async function getTracker(configId, projectId) {
	return {
		config: await getValidatedConfig(configId, projectId),
		results: await getLatestResults(configId, projectId)
	};
}
/**
* Position history for one device over a tracker's last `runLimit` completed
* full runs, plus the keywords it currently tracks so callers can name rows.
*/
async function getPositionHistory(input) {
	const config = await getValidatedConfig(input.configId, input.projectId);
	const device = input.device ?? (config.devices === "mobile" ? "mobile" : "desktop");
	if (config.devices !== "both" && config.devices !== device) throw new AppError("VALIDATION_ERROR", `This tracker only checks ${config.devices}.`);
	const [keywords, cells] = await Promise.all([RankTrackingRepository.getKeywordsForConfig(input.configId), RankTrackingRepository.getPositionMatrix(input.configId, device, input.runLimit)]);
	return {
		config,
		device,
		keywords,
		cells
	};
}
async function requireRankCheckAccess(organizationId) {
	if (!await isHostedServerAuthMode()) return;
	if (await customerHasPaidPlan(organizationId)) return;
	throw new AppError("PAYMENT_REQUIRED", "Upgrade to the paid plan to run rank checks");
}
async function getValidatedConfig(configId, projectId) {
	const config = await RankTrackingRepository.getConfigById({
		configId,
		projectId
	});
	if (!config) throw new AppError("NOT_FOUND", "Rank tracking config not found");
	return config;
}
function normalizeDomain(domain) {
	let d = domain.trim().toLowerCase();
	d = d.replace(/^https?:\/\//, "");
	d = d.replace(/[/?#].*$/, "");
	d = d.replace(/\/+$/, "");
	d = d.replace(/^www\./, "");
	if (!d) throw new AppError("INTERNAL_ERROR", "Invalid domain");
	return d;
}
function formatRun(run, stale) {
	return {
		id: run.id,
		status: run.status,
		keywordsTotal: run.keywordsTotal,
		keywordsChecked: run.keywordsChecked,
		isSubsetRun: run.isSubsetRun,
		errorMessage: run.errorMessage,
		startedAt: run.startedAt,
		completedAt: run.completedAt,
		maybeStale: stale?.maybeStale ?? false,
		staleReason: stale?.staleReason ?? null
	};
}
var RankTrackingService = {
	createConfig,
	updateConfig,
	addKeywords: RankTrackingKeywordService.addKeywords,
	removeKeywords: RankTrackingKeywordService.removeKeywords,
	triggerCheck,
	triggerAutoCheck,
	getLatestRun,
	estimateCost: RankTrackingKeywordService.estimateCost,
	refreshKeywordMetrics,
	getConfigs,
	getTracker,
	getPositionHistory,
	requireRankCheckAccess
};
//#endregion
export { RankTrackingKeywordService as n, getLatestResults as r, RankTrackingService as t };
