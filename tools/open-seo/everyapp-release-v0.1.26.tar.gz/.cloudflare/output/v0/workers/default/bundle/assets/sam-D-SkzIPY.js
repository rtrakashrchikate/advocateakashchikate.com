import { a as __toESM, t as __commonJSMin } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { C as _classPrivateFieldSet2, D as isInternalJsStubProp, E as camelCaseToKebabCase, S as _classPrivateFieldInitSpec, _ as buildSubAgentPathUnchecked, d as nanoid, f as CAPNWEB_TRANSPORT_QUERY, h as capnWebTransportUrl, l as RpcTarget, m as CAPNWEB_TRANSPORT_VALUE, n as STREAM_RESUME_NONE_REASONS, p as CAPNWEB_TRANSPORT_SEND, r as StreamAccumulator, u as newWebSocketRpcSession, x as _classPrivateFieldGet2 } from "./protocol-eXeJxhgu-BRDmnGMn.js";
import { Ar as toJSONSchema, Er as safeParseAsync, Et as _enum, Fn as object$1, Jn as string, Kt as custom, Lt as boolean, Nt as array$1, Ot as _instanceof, Pn as number, Un as record, Yt as discriminatedUnion, bn as lazy, kt as _null, or as union, qn as strictObject, sr as unknown, xn as literal } from "./schemas-BPIpYT5n.js";
import { _ as TypeValidationError, a as getToolName, g as JSONParseError, h as InvalidArgumentError, m as AISDKError, p as ZodFirstPartyTypeKind, s as isToolUIPart$1, v as EventSourceParserStream } from "./dist-COSss0lT.js";
import { o as isEveryAppClientAuthMode } from "./auth-mode-DhGCw2Bx.js";
import { c as t, i as invalidateSamSessions, n as useSamBetaOptIn, r as useSamSessions, s as Brain, t as optInToSamBeta } from "./samBetaOptIn-4V1wHsrX.js";
import { n as Markdown } from "./Markdown-kD1IlFSX.js";
import { h as ErrorState, t as QueryError } from "./QueryState-Q8BZIblk.js";
import { n as createLucideIcon } from "./dist-fVOGIv0D.js";
import { t as ArrowUp } from "./arrow-up-zHO4rX22.js";
import { t as Check } from "./check-RTl8hsAC.js";
import { t as ChevronRight } from "./chevron-right-CMQSolKd.js";
import { r as Spinner, t as Button } from "./button-DrcZrdio.js";
import { t as Pencil } from "./pencil-MnOzbXDL.js";
import { t as ShieldAlert } from "./shield-alert-C6TCVoOy.js";
import { t as Sparkles } from "./sparkles-BtdH_814.js";
import { t as TriangleAlert } from "./triangle-alert-C9SRPVjv.js";
import { r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { n as captureClientEvent } from "./posthog-BMFJOGWd.js";
import { t as Badge } from "./badge-B9fV075d.js";
import { t as Route } from "./sam-CQ8492y9.js";
import { t as CopyButton } from "./CopyButton-BPiDtx7F.js";
import { t as Textarea } from "./textarea-CsL-KvnQ.js";
import { a as InputGroupTextarea, n as InputGroupAddon, r as InputGroupButton, t as InputGroup } from "./input-group-CmFmGa25.js";
import { n as CollapsibleContent, r as CollapsibleTrigger, t as Collapsible } from "./collapsible-C81XyjKp.js";
import { t as StatusScreen } from "./StatusScreen-amfvL7o2.js";
import { t as GateCard } from "./GateCard-BqUFeaDc.js";
import { t as useSamAccess } from "./useSamAccess-CvSdXA9X.js";
//#region node_modules/.pnpm/agents@0.28.1_@ai-sdk+provider@4.0.4_@ai-sdk+react@3.0.211_react@19.2.4_zod@4.6.7__@bab_539d04cddbcc3adc73174759dfaafa16/node_modules/agents/dist/broadcast-state-CEyI4uAK.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function textOf(parts) {
	let text = "";
	for (const part of parts) if (part.type === "text") text += part.text;
	return text;
}
/**
* Whether `messages` already holds a copy of the observed message whose text
* the accumulator does not extend. A healthy live accumulator is always the
* stored copy plus more; one that diverges holds interleaved or duplicated
* chunks (#2166), so the stored copy must win or the corruption never heals.
*/
function observedDivergesFrom(accumulator, messages) {
	const existing = messages.find((m) => m.id === accumulator.messageId);
	if (!existing) return false;
	return !textOf(accumulator.parts).startsWith(textOf(existing.parts));
}
function transition(state, event) {
	switch (event.type) {
		case "clear": return {
			state: { status: "idle" },
			isStreaming: false
		};
		case "resume-fallback": {
			const accumulator = new StreamAccumulator({ messageId: event.messageId });
			return {
				state: {
					status: "observing",
					streamId: event.streamId,
					accumulator
				},
				isStreaming: true
			};
		}
		case "response": {
			let accumulator;
			const isReplayedStart = event.replay === true && event.chunkData?.type === "start";
			if (state.status === "idle" || state.streamId !== event.streamId || isReplayedStart) accumulator = new StreamAccumulator({
				messageId: event.messageId,
				continuation: event.continuation
			});
			else accumulator = state.accumulator;
			if (event.chunkData) accumulator.applyChunk(event.chunkData);
			let messagesUpdate;
			const mergeUnlessDiverged = (prev) => observedDivergesFrom(accumulator, prev) ? prev : accumulator.mergeInto(prev);
			if (event.done) return {
				state: { status: "idle" },
				messagesUpdate: mergeUnlessDiverged,
				isStreaming: false
			};
			if (event.chunkData && !event.replay) messagesUpdate = mergeUnlessDiverged;
			else if (event.replayComplete) messagesUpdate = (prev) => accumulator.mergeInto(prev);
			return {
				state: {
					status: "observing",
					streamId: event.streamId,
					accumulator
				},
				messagesUpdate,
				isStreaming: true
			};
		}
	}
}
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Square = createLucideIcon("square", [["rect", {
	width: "18",
	height: "18",
	x: "3",
	y: "3",
	rx: "2",
	key: "afitv7"
}]]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Undo2 = createLucideIcon("undo-2", [["path", {
	d: "M9 14 4 9l5-5",
	key: "102s5s"
}], ["path", {
	d: "M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11",
	key: "f3b9sd"
}]]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Wrench = createLucideIcon("wrench", [["path", {
	d: "M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z",
	key: "1ngwbx"
}]]);
//#endregion
//#region src/client/features/sam/SamBetaGate.tsx
/**
* Shown on the chat route until the user opts into Sam. Sam is the OpenSEO
* MCP plus skills wrapped in an in-app chat; the agents people already use
* run that same toolset with a more mature harness, so the primary action
* points there and Sam is the explicit fallback.
*/
function SamBetaGate({ onContinue }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GateCard, {
		icon: Sparkles,
		title: "Sam is in beta",
		description: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Sam is the OpenSEO MCP and skills wrapped in a chat window. The agent you already use, like Claude Code, ChatGPT, Grok Bot, or Hermes, runs that same toolset on a much more capable harness. We recommend using OpenSEO there." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You can still use Sam, but it is early and has rough edges." })] }),
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			nativeButton: false,
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, { to: "/ai" }),
			children: "Set up your agent"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			variant: "ghost",
			onClick: onContinue,
			children: "Use Sam anyway"
		})] })
	});
}
//#endregion
//#region src/client/features/sam/SamSetupGate.tsx
function SamSetupGate({ errorMessage, isRefetching, onRetry }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GateCard, {
		icon: Wrench,
		tone: "warning",
		title: "Enable AI Features",
		description: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [isEveryAppClientAuthMode() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			"SAM, OpenSEO's in-app AI agent, uses OpenRouter through your Every App gateway. An admin creates a key on OpenRouter and sets it on the gateway with",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "pnpm everyapp secret set OPENROUTER_API_KEY" }),
			", then confirm here."
		] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
			"SAM, OpenSEO's in-app AI agent, needs an OpenRouter API key. Create a key on OpenRouter, set it as the",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "OPENROUTER_API_KEY" }),
			" environment variable, restart OpenSEO, then confirm here."
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-xs",
			children: [
				"Step-by-step instructions for every deployment are in the",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					className: "underline underline-offset-2 hover:text-foreground",
					to: "/help/openrouter-api-key",
					children: "OpenRouter API key setup guide"
				}),
				"."
			]
		})] }),
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			pending: isRefetching,
			onClick: onRetry,
			children: "Confirm API Key"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "lg",
			variant: "outline",
			nativeButton: false,
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "https://openrouter.ai/settings/keys",
				target: "_blank",
				rel: "noreferrer"
			}),
			children: "Open OpenRouter Keys"
		})] }),
		children: errorMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
			variant: "warning",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, {
				className: "text-foreground",
				children: errorMessage
			})]
		}) : null
	});
}
//#endregion
//#region node_modules/.pnpm/partysocket@1.3.0_react@19.2.4/node_modules/partysocket/dist/ws.js
if (!globalThis.EventTarget || !globalThis.Event) console.error(`
  PartySocket requires a global 'EventTarget' class to be available!
  You can polyfill this global by adding this to your code before any partysocket imports: 
  
  \`\`\`
  import 'partysocket/event-target-polyfill';
  \`\`\`
  Please file an issue at https://github.com/partykit/partykit if you're still having trouble.
`);
var ErrorEvent = class extends Event {
	message;
	error;
	constructor(error, target) {
		super("error", target);
		this.message = error.message;
		this.error = error;
	}
};
var CloseEvent$1 = class extends Event {
	code;
	reason;
	wasClean = true;
	constructor(code = 1e3, reason = "", target) {
		super("close", target);
		this.code = code;
		this.reason = reason;
	}
};
var Events = {
	Event,
	ErrorEvent,
	CloseEvent: CloseEvent$1
};
function assert(condition, msg) {
	if (!condition) throw new Error(msg);
}
function cloneEventBrowser(e) {
	return new e.constructor(e.type, e);
}
function cloneEventNode(e) {
	if ("data" in e) return new MessageEvent(e.type, e);
	if ("code" in e || "reason" in e) return new CloseEvent$1(e.code || 1999, e.reason || "unknown reason", e);
	if ("error" in e) return new ErrorEvent(e.error, e);
	return new Event(e.type, e);
}
var isNode = typeof process !== "undefined" && typeof process.versions?.node !== "undefined";
var isReactNative = typeof navigator !== "undefined" && navigator.product === "ReactNative";
var cloneEvent = isNode || isReactNative ? cloneEventNode : cloneEventBrowser;
var DEFAULT = {
	maxReconnectionDelay: 1e4,
	minReconnectionDelay: 3e3,
	minUptime: 5e3,
	reconnectionDelayGrowFactor: 1.3,
	connectionTimeout: 4e3,
	maxRetries: Number.POSITIVE_INFINITY,
	maxEnqueuedMessages: Number.POSITIVE_INFINITY,
	startClosed: false,
	debug: false
};
var didWarnAboutMissingWebSocket = false;
function absorbError() {}
var ReconnectingWebSocket = class ReconnectingWebSocket extends EventTarget {
	_ws;
	_retryCount = -1;
	_uptimeTimeout;
	_connectTimeout;
	_shouldReconnect = true;
	_connectLock = false;
	_binaryType = "blob";
	_closeCalled = false;
	_didWarnAboutClosedSend = false;
	_messageQueue = [];
	_debugLogger = console.log.bind(console);
	_url;
	_protocols;
	_options;
	constructor(url, protocols, options = {}) {
		super();
		this._url = url;
		this._protocols = protocols;
		this._options = options;
		if (this._options.startClosed) this._shouldReconnect = false;
		if (this._options.debugLogger) this._debugLogger = this._options.debugLogger;
		this._connect();
	}
	static get CONNECTING() {
		return 0;
	}
	static get OPEN() {
		return 1;
	}
	static get CLOSING() {
		return 2;
	}
	static get CLOSED() {
		return 3;
	}
	get CONNECTING() {
		return ReconnectingWebSocket.CONNECTING;
	}
	get OPEN() {
		return ReconnectingWebSocket.OPEN;
	}
	get CLOSING() {
		return ReconnectingWebSocket.CLOSING;
	}
	get CLOSED() {
		return ReconnectingWebSocket.CLOSED;
	}
	get binaryType() {
		return this._ws ? this._ws.binaryType : this._binaryType;
	}
	set binaryType(value) {
		this._binaryType = value;
		if (this._ws) this._ws.binaryType = value;
	}
	/**
	* Returns the number or connection retries
	*/
	get retryCount() {
		return Math.max(this._retryCount, 0);
	}
	/**
	* The number of bytes of data that have been queued using calls to send() but not yet
	* transmitted to the network. This value resets to zero once all queued data has been sent.
	* This value does not reset to zero when the connection is closed; if you keep calling send(),
	* this will continue to climb. Read only
	*/
	get bufferedAmount() {
		return this._messageQueue.reduce((acc, message) => {
			if (typeof message === "string") acc += message.length;
			else if (message instanceof Blob) acc += message.size;
			else acc += message.byteLength;
			return acc;
		}, 0) + (this._ws ? this._ws.bufferedAmount : 0);
	}
	/**
	* The extensions selected by the server. This is currently only the empty string or a list of
	* extensions as negotiated by the connection
	*/
	get extensions() {
		return this._ws ? this._ws.extensions : "";
	}
	/**
	* A string indicating the name of the sub-protocol the server selected;
	* this will be one of the strings specified in the protocols parameter when creating the
	* WebSocket object
	*/
	get protocol() {
		return this._ws ? this._ws.protocol : "";
	}
	/**
	* The current state of the connection; this is one of the Ready state constants
	*/
	get readyState() {
		if (this._closeCalled) return ReconnectingWebSocket.CLOSED;
		if (this._ws) return this._ws.readyState;
		return this._options.startClosed ? ReconnectingWebSocket.CLOSED : ReconnectingWebSocket.CONNECTING;
	}
	/**
	* The URL as resolved by the constructor
	*/
	get url() {
		return this._ws ? this._ws.url : "";
	}
	/**
	* Whether the websocket object is now in reconnectable state
	*/
	get shouldReconnect() {
		return this._shouldReconnect;
	}
	/**
	* An event listener to be called when the WebSocket connection's readyState changes to CLOSED
	*/
	onclose = null;
	/**
	* An event listener to be called when an error occurs
	*/
	onerror = null;
	/**
	* An event listener to be called when a message is received from the server
	*/
	onmessage = null;
	/**
	* An event listener to be called when the WebSocket connection's readyState changes to OPEN;
	* this indicates that the connection is ready to send and receive data
	*/
	onopen = null;
	/**
	* Closes the WebSocket connection or connection attempt, if any. If the connection is already
	* CLOSED or CLOSING, this method does nothing.
	*
	* The `close` event is dispatched synchronously (mirroring how
	* `reconnect()` dispatches its synthetic close). This guarantees
	* consumers observe a terminal event for every explicit close, even
	* if their listeners are detached right after this call \u2014 previously
	* the real (asynchronous) browser close event could fire after
	* listeners were removed and go unobserved entirely.
	*/
	close(code = 1e3, reason) {
		this._closeCalled = true;
		this._shouldReconnect = false;
		this._clearTimeouts();
		if (!this._ws) {
			this._debug("close enqueued: no ws instance");
			return;
		}
		if (this._ws.readyState === this.CLOSED || this._ws.readyState === this.CLOSING) {
			this._debug("close: already closing or closed");
			return;
		}
		this._disconnect(code, reason);
	}
	/**
	* Closes the WebSocket connection or connection attempt and connects again.
	* Resets retry counter;
	*/
	reconnect(code, reason) {
		this._shouldReconnect = true;
		this._closeCalled = false;
		this._didWarnAboutClosedSend = false;
		this._retryCount = -1;
		if (!this._ws || this._ws.readyState === this.CLOSED || this._ws.readyState === this.CLOSING) this._connect();
		else {
			this._disconnect(code, reason);
			this._connect();
		}
	}
	/**
	* Enqueue specified data to be transmitted to the server over the WebSocket connection.
	*
	* @returns `true` if the message was transmitted immediately over an open
	* connection; `false` if it was buffered (sent when the connection next
	* opens \u2014 the buffer is always flushed before the `open` event is
	* dispatched) or dropped because `maxEnqueuedMessages` was reached.
	*/
	send(data) {
		if (this._ws && this._ws.readyState === this.OPEN) {
			this._debug("send", data);
			this._ws.send(data);
			return true;
		}
		if (this._closeCalled && !this._didWarnAboutClosedSend) {
			this._didWarnAboutClosedSend = true;
			console.warn("ReconnectingWebSocket: send() was called after close(). The message has been buffered, but it will only be delivered if reconnect() is called on this socket. If this socket has been discarded, the message is lost \u2014 this usually means a stale socket reference is being used.");
		}
		const { maxEnqueuedMessages = DEFAULT.maxEnqueuedMessages } = this._options;
		if (this._messageQueue.length < maxEnqueuedMessages) {
			this._debug("enqueue", data);
			this._messageQueue.push(data);
		}
		return false;
	}
	/**
	* Removes and returns all messages that were passed to send() but never
	* transmitted (they were buffered while the connection wasn't open).
	*
	* Useful when a socket is being discarded and replaced (e.g. the React
	* hooks recreate the socket when connection options change): the
	* replacement socket can re-send these messages, instead of them being
	* silently lost with the old instance.
	*/
	drainQueuedMessages() {
		const queue = this._messageQueue;
		this._messageQueue = [];
		return queue;
	}
	_debug(...args) {
		if (this._options.debug) this._debugLogger("RWS>", ...args);
	}
	_getNextDelay() {
		const { reconnectionDelayGrowFactor = DEFAULT.reconnectionDelayGrowFactor, minReconnectionDelay = DEFAULT.minReconnectionDelay, maxReconnectionDelay = DEFAULT.maxReconnectionDelay } = this._options;
		let delay = 0;
		if (this._retryCount > 0) {
			delay = minReconnectionDelay * reconnectionDelayGrowFactor ** (this._retryCount - 1);
			if (delay > maxReconnectionDelay) delay = maxReconnectionDelay;
		}
		this._debug("next delay", delay);
		return delay;
	}
	_wait() {
		return new Promise((resolve) => {
			setTimeout(resolve, this._getNextDelay());
		});
	}
	_getNextProtocols(protocolsProvider) {
		if (!protocolsProvider) return Promise.resolve(null);
		if (typeof protocolsProvider === "string" || Array.isArray(protocolsProvider)) return Promise.resolve(protocolsProvider);
		if (typeof protocolsProvider === "function") {
			const protocols = protocolsProvider();
			if (!protocols) return Promise.resolve(null);
			if (typeof protocols === "string" || Array.isArray(protocols)) return Promise.resolve(protocols);
			if (protocols.then) return protocols;
		}
		throw Error("Invalid protocols");
	}
	_getNextUrl(urlProvider) {
		if (typeof urlProvider === "string") return Promise.resolve(urlProvider);
		if (typeof urlProvider === "function") {
			const url = urlProvider();
			if (typeof url === "string") return Promise.resolve(url);
			if (url.then) return url;
		}
		throw Error("Invalid URL");
	}
	_connect() {
		if (this._connectLock || !this._shouldReconnect) return;
		this._connectLock = true;
		const { maxRetries = DEFAULT.maxRetries, connectionTimeout = DEFAULT.connectionTimeout } = this._options;
		if (this._retryCount >= maxRetries) {
			this._debug("max retries reached", this._retryCount, ">=", maxRetries);
			this._connectLock = false;
			return;
		}
		this._retryCount++;
		this._debug("connect", this._retryCount);
		this._removeListeners();
		this._wait().then(() => Promise.all([this._getNextUrl(this._url), this._getNextProtocols(this._protocols || null)])).then(([url, protocols]) => {
			if (this._closeCalled) {
				this._connectLock = false;
				return;
			}
			if (!this._options.WebSocket && typeof WebSocket === "undefined" && !didWarnAboutMissingWebSocket) {
				console.error(`\u203C\uFE0F No WebSocket implementation available. You should define options.WebSocket. 

For example, if you're using node.js, run \`npm install ws\`, and then in your code:

import PartySocket from 'partysocket';
import WS from 'ws';

const partysocket = new PartySocket({
  host: "127.0.0.1:1999",
  room: "test-room",
  WebSocket: WS
});

`);
				didWarnAboutMissingWebSocket = true;
			}
			const WS = this._options.WebSocket || WebSocket;
			this._debug("connect", {
				url,
				protocols
			});
			this._ws = protocols ? new WS(url, protocols) : new WS(url);
			this._ws.binaryType = this._binaryType;
			this._connectLock = false;
			this._addListeners();
			this._connectTimeout = setTimeout(() => this._handleTimeout(), connectionTimeout);
		}).catch((err) => {
			this._connectLock = false;
			this._handleError(new Events.ErrorEvent(Error(err.message), this));
		});
	}
	_handleTimeout() {
		this._debug("timeout event");
		this._handleError(new Events.ErrorEvent(Error("TIMEOUT"), this));
	}
	_disconnect(code = 1e3, reason) {
		this._clearTimeouts();
		if (!this._ws) return;
		this._removeListeners();
		try {
			if (this._ws.readyState === this.OPEN || this._ws.readyState === this.CONNECTING) this._ws.close(code, reason);
			this._handleClose(new Events.CloseEvent(code, reason, this));
		} catch (_error) {}
	}
	_acceptOpen() {
		this._debug("accept open");
		this._retryCount = 0;
	}
	_handleOpen = (event) => {
		this._debug("open event");
		const { minUptime = DEFAULT.minUptime } = this._options;
		clearTimeout(this._connectTimeout);
		this._uptimeTimeout = setTimeout(() => this._acceptOpen(), minUptime);
		assert(this._ws, "WebSocket is not defined");
		this._ws.binaryType = this._binaryType;
		this._messageQueue.forEach((message) => {
			this._ws?.send(message);
		});
		this._messageQueue = [];
		if (this.onopen) this.onopen(event);
		this.dispatchEvent(cloneEvent(event));
	};
	_handleMessage = (event) => {
		this._debug("message event");
		if (this.onmessage) this.onmessage(event);
		this.dispatchEvent(cloneEvent(event));
	};
	_handleError = (event) => {
		this._debug("error event", event.message);
		this._disconnect(void 0, event.message === "TIMEOUT" ? "timeout" : void 0);
		if (this.onerror) this.onerror(event);
		this._debug("exec error listeners");
		this.dispatchEvent(cloneEvent(event));
		this._connect();
	};
	_handleClose = (event) => {
		this._debug("close event");
		this._clearTimeouts();
		if (this._options.shouldReconnectOnClose && !this._options.shouldReconnectOnClose(event)) this._shouldReconnect = false;
		if (this._shouldReconnect) this._connect();
		if (this.onclose) this.onclose(event);
		this.dispatchEvent(cloneEvent(event));
	};
	_removeListeners() {
		if (!this._ws) return;
		this._debug("removeListeners");
		this._ws.removeEventListener("open", this._handleOpen);
		this._ws.removeEventListener("close", this._handleClose);
		this._ws.removeEventListener("message", this._handleMessage);
		this._ws.removeEventListener("error", this._handleError);
		this._ws.addEventListener("error", absorbError);
	}
	_addListeners() {
		if (!this._ws) return;
		this._debug("addListeners");
		this._ws.addEventListener("open", this._handleOpen);
		this._ws.addEventListener("close", this._handleClose);
		this._ws.addEventListener("message", this._handleMessage);
		this._ws.addEventListener("error", this._handleError);
	}
	_clearTimeouts() {
		clearTimeout(this._connectTimeout);
		clearTimeout(this._uptimeTimeout);
	}
};
//#endregion
//#region node_modules/.pnpm/partysocket@1.3.0_react@19.2.4/node_modules/partysocket/dist/index.js
var valueIsNotNil = (keyValuePair) => keyValuePair[1] !== null && keyValuePair[1] !== void 0;
function generateUUID() {
	if (crypto?.randomUUID) return crypto.randomUUID();
	let d = Date.now();
	let d2 = performance?.now && performance.now() * 1e3 || 0;
	return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
		let r = Math.random() * 16;
		if (d > 0) {
			r = (d + r) % 16 | 0;
			d = Math.floor(d / 16);
		} else {
			r = (d2 + r) % 16 | 0;
			d2 = Math.floor(d2 / 16);
		}
		return (c === "x" ? r : r & 3 | 8).toString(16);
	});
}
function getPartyInfo(partySocketOptions, defaultProtocol, defaultParams = {}) {
	const { host: rawHost, path: rawPath, protocol: rawProtocol, room, party, basePath, prefix, query } = partySocketOptions;
	let host = rawHost.replace(/^(http|https|ws|wss):\/\//, "");
	if (host.endsWith("/")) host = host.slice(0, -1);
	if (rawPath?.startsWith("/")) throw new Error("path must not start with a slash");
	const name = party ?? "main";
	const path = rawPath ? `/${rawPath}` : "";
	const protocol = rawProtocol || (host.startsWith("localhost:") || host.startsWith("127.0.0.1:") || host.startsWith("192.168.") || host.startsWith("10.") || host.startsWith("172.") && host.split(".")[1] >= "16" && host.split(".")[1] <= "31" || host.startsWith("[::ffff:7f00:1]:") ? defaultProtocol : `${defaultProtocol}s`);
	const baseUrl = `${protocol}://${host}/${basePath || `${prefix || "parties"}/${name}/${room}`}${path}`;
	const makeUrl = (query = {}) => `${baseUrl}?${new URLSearchParams([...Object.entries(defaultParams), ...Object.entries(query).filter(valueIsNotNil)])}`;
	const urlProvider = typeof query === "function" ? async () => makeUrl(await query()) : makeUrl(query);
	return {
		host,
		path,
		room,
		name,
		protocol,
		partyUrl: baseUrl,
		urlProvider
	};
}
var PartySocket = class extends ReconnectingWebSocket {
	_pk;
	_pkurl;
	name;
	room;
	host;
	path;
	basePath;
	constructor(partySocketOptions) {
		const wsOptions = getWSOptions(partySocketOptions);
		super(wsOptions.urlProvider, wsOptions.protocols, wsOptions.socketOptions);
		this.partySocketOptions = partySocketOptions;
		this.setWSProperties(wsOptions);
		if (!partySocketOptions.startClosed && !this.room && !this.basePath) {
			this.close();
			throw new Error("Either room or basePath must be provided to connect. Use startClosed: true to create a socket and set them via updateProperties before calling reconnect().");
		}
		if (!partySocketOptions.disableNameValidation) {
			if (partySocketOptions.party?.includes("/")) console.warn(`PartySocket: party name "${partySocketOptions.party}" contains forward slash which may cause routing issues. Consider using a name without forward slashes or set disableNameValidation: true to bypass this warning.`);
			if (partySocketOptions.room?.includes("/")) console.warn(`PartySocket: room name "${partySocketOptions.room}" contains forward slash which may cause routing issues. Consider using a name without forward slashes or set disableNameValidation: true to bypass this warning.`);
		}
	}
	updateProperties(partySocketOptions) {
		const wsOptions = getWSOptions({
			...this.partySocketOptions,
			...partySocketOptions,
			host: partySocketOptions.host ?? this.host,
			room: partySocketOptions.room ?? this.room,
			path: partySocketOptions.path ?? this.path,
			basePath: partySocketOptions.basePath ?? this.basePath
		});
		this._url = wsOptions.urlProvider;
		this._protocols = wsOptions.protocols;
		this._options = wsOptions.socketOptions;
		this.setWSProperties(wsOptions);
	}
	setWSProperties(wsOptions) {
		const { _pk, _pkurl, name, room, host, path, basePath } = wsOptions;
		this._pk = _pk;
		this._pkurl = _pkurl;
		this.name = name;
		this.room = room;
		this.host = host;
		this.path = path;
		this.basePath = basePath;
	}
	reconnect(code, reason) {
		if (!this.host) throw new Error("The host must be set before connecting, use `updateProperties` method to set it or pass it to the constructor.");
		if (!this.room && !this.basePath) throw new Error("The room (or basePath) must be set before connecting, use `updateProperties` method to set it or pass it to the constructor.");
		super.reconnect(code, reason);
	}
	get id() {
		return this._pk;
	}
	/**
	* Exposes the static PartyKit room URL without applying query parameters.
	* To access the currently connected WebSocket url, use PartySocket#url.
	*/
	get roomUrl() {
		return this._pkurl;
	}
	static async fetch(options, init) {
		const party = getPartyInfo(options, "http");
		const url = typeof party.urlProvider === "string" ? party.urlProvider : await party.urlProvider();
		return (options.fetch ?? fetch)(url, init);
	}
};
function getWSOptions(partySocketOptions) {
	const { id, host: _host, path: _path, party: _party, room: _room, protocol: _protocol, query: _query, protocols, ...socketOptions } = partySocketOptions;
	const _pk = id || generateUUID();
	const party = getPartyInfo(partySocketOptions, "ws", { _pk });
	return {
		_pk,
		_pkurl: party.partyUrl,
		name: party.name,
		room: party.room,
		host: party.host,
		path: party.path,
		basePath: partySocketOptions.basePath,
		protocols,
		socketOptions,
		urlProvider: party.urlProvider
	};
}
//#endregion
//#region node_modules/.pnpm/agents@0.28.1_@ai-sdk+provider@4.0.4_@ai-sdk+react@3.0.211_react@19.2.4_zod@4.6.7__@bab_539d04cddbcc3adc73174759dfaafa16/node_modules/agents/dist/client-4OlMIJx-.js
/** Local root the host calls to deliver frames. */
var Inbox = class extends RpcTarget {
	constructor(socket) {
		super();
		this.socket = socket;
	}
	message(value) {
		this.socket.dispatchEvent(new MessageEvent("message", { data: value }));
	}
};
var _socket = /* @__PURE__ */ new WeakMap();
var _root = /* @__PURE__ */ new WeakMap();
/**
* A WebSocket-shaped client for the Cap'n Web connection transport.
*
* It has the constructor, `readyState`, `send()`, `close()`, and events of
* a `WebSocket`, so PartySocket (and therefore `useAgent` and
* `AgentClient`) can drive it as a drop-in socket implementation and keep
* owning reconnection, buffering, and backoff. Frames sent here travel
* through the host's pipe method; frames from the host arrive as
* `message` events.
*
* @experimental The transport is experimental.
*/
var CapnWebSocket = class CapnWebSocket extends EventTarget {
	constructor(url, protocols) {
		super();
		this.CONNECTING = 0;
		this.OPEN = 1;
		this.CLOSING = 2;
		this.CLOSED = 3;
		this.readyState = CapnWebSocket.CONNECTING;
		this.binaryType = "arraybuffer";
		this.bufferedAmount = 0;
		this.extensions = "";
		this.protocol = "";
		this.onopen = null;
		this.onmessage = null;
		this.onclose = null;
		this.onerror = null;
		_classPrivateFieldInitSpec(this, _socket, void 0);
		_classPrivateFieldInitSpec(this, _root, void 0);
		this.url = capnWebTransportUrl(url);
		_classPrivateFieldSet2(_socket, this, protocols ? new WebSocket(this.url, protocols) : new WebSocket(this.url));
		_classPrivateFieldSet2(_root, this, newWebSocketRpcSession(_classPrivateFieldGet2(_socket, this), new Inbox(this)));
		_classPrivateFieldGet2(_socket, this).addEventListener("open", () => {
			this.readyState = CapnWebSocket.OPEN;
			this.protocol = _classPrivateFieldGet2(_socket, this).protocol;
			this.dispatchEvent(new Event("open"));
		});
		_classPrivateFieldGet2(_socket, this).addEventListener("close", (event) => {
			this.readyState = CapnWebSocket.CLOSED;
			this.dispatchEvent(new CloseEvent("close", {
				code: event.code,
				reason: event.reason,
				wasClean: event.wasClean
			}));
		});
		_classPrivateFieldGet2(_socket, this).addEventListener("error", () => {
			this.dispatchEvent(new Event("error"));
		});
	}
	dispatchEvent(event) {
		const handler = Reflect.get(this, `on${event.type}`);
		if (typeof handler === "function") Reflect.apply(handler, this, [event]);
		return super.dispatchEvent(event);
	}
	/**
	* Invoke one of the host's native callables on the session root. The
	* result keeps Cap'n Web semantics: an `RpcTarget` arrives as a live
	* stub, a `ReadableStream` streams, and chained calls pipeline.
	*/
	invoke(method, args) {
		if (this.readyState !== CapnWebSocket.OPEN) return Promise.reject(/* @__PURE__ */ new Error("Connection closed"));
		const root = _classPrivateFieldGet2(_root, this);
		return Promise.resolve(root[method](...args));
	}
	send(data) {
		if (this.readyState !== CapnWebSocket.OPEN) throw new DOMException("WebSocket is not open", "InvalidStateError");
		_classPrivateFieldGet2(_root, this)[CAPNWEB_TRANSPORT_SEND](data).catch(() => {
			this.dispatchEvent(new Event("error"));
		});
	}
	close(code, reason) {
		if (this.readyState >= CapnWebSocket.CLOSING) return;
		this.readyState = CapnWebSocket.CLOSING;
		try {
			_classPrivateFieldGet2(_root, this)[Symbol.dispose]();
		} catch {}
		_classPrivateFieldGet2(_socket, this).close(code, reason);
	}
};
CapnWebSocket.CONNECTING = 0;
CapnWebSocket.OPEN = 1;
CapnWebSocket.CLOSING = 2;
CapnWebSocket.CLOSED = 3;
/**
* A `CapnWebSocket` subclass that reports each instance it constructs.
* PartySocket instantiates the class it is given; this is how a client
* gets hold of the live socket to call `invoke()` without reaching into
* PartySocket internals.
*/
function boundCapnWebSocket(onCreate) {
	return class BoundCapnWebSocket extends CapnWebSocket {
		constructor(url, protocols) {
			super(url, protocols);
			onCreate(this);
		}
	};
}
var AgentConnectionError = class extends Error {
	constructor(event) {
		const reason = event.reason || `WebSocket closed with code ${event.code}`;
		super(`Agent connection closed: ${reason}`);
		this.name = "AgentConnectionError";
		this.code = event.code;
		this.reason = event.reason;
		this.wasClean = event.wasClean;
	}
};
function isTerminalCloseEvent(event) {
	return event.code === 1008 || event.code >= 4e3 && event.code <= 4999;
}
/**
* PartySocket's `shouldReconnectOnClose`, plus a record of whether that
* decision ended reconnection so the close can surface a connection error.
*
* Reconnection ends on a terminal close code, when the caller's
* `shouldReconnectOnClose` declines, or when `maxRetries` is spent (a
* failed handshake never reaches the server's close codes, so it only
* stops this way). An explicit `close()` has already cleared
* `shouldReconnect` by the time PartySocket asks, and is not an error.
* PartySocket asks before it schedules the next attempt, so `retryCount`
* still counts the attempt that just closed.
* @internal
*/
function createCloseClassifier(options) {
	let finalClose = false;
	return {
		shouldReconnectOnClose(event) {
			const reconnect = (options.shouldReconnectOnClose()?.(event) ?? true) && !isTerminalCloseEvent(event);
			const socket = options.socket();
			if (socket?.shouldReconnect === false) finalClose = false;
			else if (!reconnect) finalClose = true;
			else {
				const maxRetries = options.maxRetries() ?? Number.POSITIVE_INFINITY;
				finalClose = (socket?.retryCount ?? 0) >= maxRetries;
			}
			return reconnect;
		},
		takeFinalClose() {
			const final = finalClose;
			finalClose = false;
			return final;
		}
	};
}
/**
* Normalize `call()` options. The legacy shape is the stream callbacks
* themselves (`{ onChunk, onDone, onError }`); the current shape nests
* them under `stream` beside `timeout`.
*/
function splitCallOptions(options) {
	return options !== void 0 && ("onChunk" in options || "onDone" in options || "onError" in options) ? {
		stream: options,
		timeout: void 0
	} : {
		stream: options?.stream,
		timeout: options?.timeout
	};
}
/**
* One native call on the Cap'n Web transport, with the timeout and
* stream-callback contract `call()` has on the JSON wire. The timeout
* covers the whole call, draining included: on expiry the stream reader is
* cancelled and the promise rejects once. A `ReadableStream` result is
* drained into the stream callbacks when they are given; any other value,
* live stubs included, passes straight through.
*/
async function nativeCall(socket, method, args, options, defaultTimeout) {
	const { stream, timeout } = splitCallOptions(options);
	const effectiveTimeout = timeout !== void 0 ? timeout : stream ? void 0 : defaultTimeout;
	let reader;
	let timer;
	const work = (async () => {
		const result = await socket.invoke(method, args);
		if (stream && result instanceof ReadableStream) {
			reader = result.getReader();
			for (;;) {
				const { done, value } = await reader.read();
				if (done) break;
				stream.onChunk?.(value);
			}
			stream.onDone?.(void 0);
			return;
		}
		return result;
	})();
	const expiry = effectiveTimeout ? new Promise((_, reject) => {
		timer = setTimeout(() => {
			reader?.cancel().catch(() => {});
			reject(/* @__PURE__ */ new Error(`RPC call to ${method} timed out after ${effectiveTimeout}ms`));
		}, effectiveTimeout);
	}) : void 0;
	try {
		return await (expiry ? Promise.race([work, expiry]) : work);
	} catch (error) {
		work.catch(() => {});
		stream?.onError?.(error instanceof Error ? error.message : String(error));
		throw error;
	} finally {
		if (timer) clearTimeout(timer);
	}
}
var _pending = /* @__PURE__ */ new WeakMap();
/**
* Native calls issued while the Cap'n Web socket is still connecting or
* between reconnects. They must not fall back to JSON frames \u2014 that would
* change which methods are reachable and lose return-by-reference \u2014 so
* they wait here and run on the next open socket, or reject when the
* connection ends for good. Their timeout starts when they are issued.
*/
var NativeCallQueue = class {
	constructor() {
		_classPrivateFieldInitSpec(this, _pending, []);
	}
	enqueue(method, args, options, defaultTimeout) {
		return new Promise((resolve, reject) => {
			const { stream, timeout } = splitCallOptions(options);
			const effectiveTimeout = timeout !== void 0 ? timeout : stream ? void 0 : defaultTimeout;
			const startedAt = Date.now();
			const entry = {
				run: (socket) => {
					const remaining = effectiveTimeout === void 0 ? void 0 : Math.max(1, effectiveTimeout - (Date.now() - startedAt));
					nativeCall(socket, method, args, remaining === void 0 ? options : {
						stream,
						timeout: remaining
					}, defaultTimeout).then(resolve, reject);
				},
				reject: (error) => {
					stream?.onError?.(error.message);
					reject(error);
				}
			};
			_classPrivateFieldGet2(_pending, this).push(entry);
			if (effectiveTimeout) setTimeout(() => {
				const index = _classPrivateFieldGet2(_pending, this).indexOf(entry);
				if (index === -1) return;
				_classPrivateFieldGet2(_pending, this).splice(index, 1);
				entry.reject(/* @__PURE__ */ new Error(`RPC call to ${method} timed out after ${effectiveTimeout}ms`));
			}, effectiveTimeout);
		});
	}
	/** Run everything queued on a socket that just opened. */
	flush(socket) {
		const pending = _classPrivateFieldGet2(_pending, this);
		_classPrivateFieldSet2(_pending, this, []);
		for (const entry of pending) entry.run(socket);
	}
	/** Reject everything queued; the connection will not come back. */
	rejectAll(reason) {
		const pending = _classPrivateFieldGet2(_pending, this);
		_classPrivateFieldSet2(_pending, this, []);
		const error = new Error(reason);
		for (const entry of pending) entry.reject(error);
	}
};
/**
* Creates a proxy that wraps RPC method calls.
* Internal JS methods (toJSON, then, etc.) return undefined to avoid
* triggering RPC calls during serialization (e.g., console.log)
*/
function createStubProxy(call) {
	return new Proxy({}, { get: (_target, method) => {
		if (isInternalJsStubProp(method)) return;
		return (...args) => call(method, args);
	} });
}
//#endregion
//#region node_modules/.pnpm/agents@0.28.1_@ai-sdk+provider@4.0.4_@ai-sdk+react@3.0.211_react@19.2.4_zod@4.6.7__@bab_539d04cddbcc3adc73174759dfaafa16/node_modules/agents/dist/socket-address.js
/**
* Set by `useAgent` on the socket it returns: `true` while the hook's options
* address a different agent than the socket it is still holding.
* `usePartySocket` replaces the socket in an effect, so for at least one
* render after `name` (or the host, path, or sub-agent chain) changes the
* returned socket still points at the previous agent, with the previous
* credentials in its URL.
*
* A registered symbol, so a separately bundled `useAgentChat` still sees it.
*/
var SOCKET_ADDRESS_PENDING = Symbol.for("cloudflare.agents.socketAddressPending");
function isSocketAddressPending(socket) {
	return socket[SOCKET_ADDRESS_PENDING] === true;
}
//#endregion
//#region node_modules/.pnpm/partysocket@1.3.0_react@19.2.4/node_modules/partysocket/dist/use-ws-CYFjFIcF.js
/** Attaches event handlers to a WebSocket in a React Lifecycle-friendly way */
var useAttachWebSocketEventHandlers = (socket, options) => {
	const handlersRef = (0, import_react.useRef)(options);
	handlersRef.current = options;
	(0, import_react.useEffect)(() => {
		const onOpen = (event) => handlersRef.current?.onOpen?.(event);
		const onMessage = (event) => handlersRef.current?.onMessage?.(event);
		const onClose = (event) => handlersRef.current?.onClose?.(event);
		const onError = (event) => handlersRef.current?.onError?.(event);
		socket.addEventListener("open", onOpen);
		socket.addEventListener("close", onClose);
		socket.addEventListener("error", onError);
		socket.addEventListener("message", onMessage);
		return () => {
			socket.removeEventListener("open", onOpen);
			socket.removeEventListener("close", onClose);
			socket.removeEventListener("error", onError);
			socket.removeEventListener("message", onMessage);
		};
	}, [socket]);
};
/** When any of the option values are changed, we should reinitialize the socket */
var getOptionsThatShouldCauseRestartWhenChanged = (options) => [
	options.startClosed,
	options.minUptime,
	options.maxRetries,
	options.connectionTimeout,
	options.maxEnqueuedMessages,
	options.maxReconnectionDelay,
	options.minReconnectionDelay,
	options.reconnectionDelayGrowFactor,
	options.debug
];
/**
* Initializes a PartySocket (or WebSocket) and keeps it stable across renders,
* but reconnects and updates the reference when any of the connection args change.
*/
function useStableSocket({ options, createSocket, createSocketMemoKey: createOptionsMemoKey, createSocketDestinationKey }) {
	const { enabled = true } = options;
	const socketOptions = (0, import_react.useMemo)(() => {
		return options;
	}, [createOptionsMemoKey(options)]);
	const [socket, setSocket] = (0, import_react.useState)(() => createSocket({
		...socketOptions,
		startClosed: true
	}));
	const socketInitializedRef = (0, import_react.useRef)(null);
	const createSocketRef = (0, import_react.useRef)(createSocket);
	createSocketRef.current = createSocket;
	const prevEnabledRef = (0, import_react.useRef)(enabled);
	const prevSocketOptionsRef = (0, import_react.useRef)(socketOptions);
	const optionsChangedWhileDisabledRef = (0, import_react.useRef)(false);
	const socketCreatedWithOptionsRef = (0, import_react.useRef)(socketOptions);
	const createReplacementSocket = (oldSocket) => {
		const newSocket = createSocketRef.current({
			...socketOptions,
			startClosed: true
		});
		const queued = oldSocket.drainQueuedMessages();
		if (queued.length > 0) {
			const sameDestination = createSocketDestinationKey ? createSocketDestinationKey(socketCreatedWithOptionsRef.current) === createSocketDestinationKey(socketOptions) : false;
			if (socketOptions.transferEnqueuedMessages ?? sameDestination) for (const message of queued) newSocket.send(message);
			else console.warn(`PartySocket: discarded ${queued.length} buffered message(s) while replacing the socket, because the connection destination changed. Pass transferEnqueuedMessages: true to deliver buffered messages to the new destination instead.`);
		}
		socketCreatedWithOptionsRef.current = socketOptions;
		return newSocket;
	};
	const createReplacementSocketRef = (0, import_react.useRef)(createReplacementSocket);
	createReplacementSocketRef.current = createReplacementSocket;
	(0, import_react.useEffect)(() => {
		const optionsChanged = prevSocketOptionsRef.current !== socketOptions;
		prevSocketOptionsRef.current = socketOptions;
		if (!enabled) {
			socket.close();
			prevEnabledRef.current = enabled;
			if (optionsChanged) optionsChangedWhileDisabledRef.current = true;
			return () => {
				socket.close();
			};
		}
		if (!prevEnabledRef.current && enabled) {
			prevEnabledRef.current = enabled;
			const needsNewSocket = optionsChanged || optionsChangedWhileDisabledRef.current;
			optionsChangedWhileDisabledRef.current = false;
			if (!needsNewSocket) {
				socket.reconnect();
				return () => {
					socket.close();
				};
			}
			const newSocket = createReplacementSocketRef.current(socket);
			setSocket(newSocket);
			return () => {
				newSocket.close();
			};
		}
		prevEnabledRef.current = enabled;
		if (socketInitializedRef.current === socket) if (optionsChanged) {
			const newSocket = createReplacementSocketRef.current(socket);
			setSocket(newSocket);
			return () => {
				newSocket.close();
			};
		} else {
			if (socketOptions.startClosed !== true) socket.reconnect();
			return () => {
				socket.close();
			};
		}
		else {
			if (!socketInitializedRef.current) {
				if (socketOptions.startClosed !== true) socket.reconnect();
			} else if (socketInitializedRef.current !== socket) socket.reconnect();
			socketInitializedRef.current = socket;
			return () => {
				socket.close();
			};
		}
	}, [
		socket,
		socketOptions,
		enabled
	]);
	return socket;
}
//#endregion
//#region node_modules/.pnpm/partysocket@1.3.0_react@19.2.4/node_modules/partysocket/dist/react.js
function usePartySocket(options) {
	const { host, ...otherOptions } = options;
	const socket = useStableSocket({
		options: {
			host: host || (typeof window !== "undefined" ? window.location.host : "dummy-domain.com"),
			...otherOptions
		},
		createSocket: (options) => new PartySocket(options),
		createSocketMemoKey: (options) => JSON.stringify([
			options.query,
			options.id,
			options.host,
			options.room,
			options.party,
			options.path,
			options.protocol,
			options.protocols,
			options.basePath,
			options.prefix,
			...getOptionsThatShouldCauseRestartWhenChanged(options)
		]),
		createSocketDestinationKey: (options) => JSON.stringify([
			options.host,
			options.room,
			options.party,
			options.path,
			options.protocol,
			options.protocols,
			options.basePath,
			options.prefix
		])
	});
	useAttachWebSocketEventHandlers(socket, options);
	return socket;
}
//#endregion
//#region node_modules/.pnpm/agents@0.28.1_@ai-sdk+provider@4.0.4_@ai-sdk+react@3.0.211_react@19.2.4_zod@4.6.7__@bab_539d04cddbcc3adc73174759dfaafa16/node_modules/agents/dist/react.js
var queryCache = /* @__PURE__ */ new Map();
function socketDestinationKey(options) {
	return JSON.stringify([
		options.host ?? null,
		options.basePath ?? null,
		options.party ?? null,
		options.prefix ?? null,
		options.room ?? null,
		options.path ?? null,
		options.protocol ?? null,
		options.protocols ?? null
	]);
}
function createReadyEntry() {
	let resolvePromise;
	const entry = {
		promise: new Promise((r) => {
			resolvePromise = r;
		}),
		resolved: false,
		resolve: () => {
			entry.resolved = true;
			resolvePromise();
		}
	};
	return entry;
}
/** The host `usePartySocket` connects to when none is given. */
function defaultSocketHost() {
	return typeof window !== "undefined" ? window.location.host : "dummy-domain.com";
}
function createCacheKey(agentNamespace, name, subChainOrDeps, deps) {
	if (deps === void 0) return JSON.stringify([
		agentNamespace,
		name || "default",
		...subChainOrDeps
	]);
	const subChain = subChainOrDeps;
	if (subChain.length === 0) return JSON.stringify([
		agentNamespace,
		name || "default",
		...deps
	]);
	return JSON.stringify([
		agentNamespace,
		name || "default",
		subChain.map((s) => [s.agent, s.name]),
		...deps
	]);
}
/** Build a URL path tail `/sub/{agent-kebab}/{name}/...` from a sub chain. */
function buildSubPath(subChain, extraPath) {
	return buildSubAgentPathUnchecked(subChain.map((step) => ({
		className: step.agent,
		name: step.name
	})), extraPath);
}
function getCacheEntry(key) {
	const entry = queryCache.get(key);
	if (!entry) return void 0;
	if (Date.now() >= entry.expiresAt) {
		queryCache.delete(key);
		return;
	}
	return entry;
}
function setCacheEntry(key, promise, cacheTtl) {
	const entry = {
		promise,
		expiresAt: Date.now() + cacheTtl
	};
	queryCache.set(key, entry);
	return entry;
}
function deleteCacheEntry(key) {
	queryCache.delete(key);
}
function useAgent(options) {
	const agentNamespace = camelCaseToKebabCase(options.agent);
	const { query, queryDeps, cacheTtl, sub: subOption, path: userPath, defaultCallTimeout, onConnectionError, shouldReconnectOnClose, transport = "cf-websocket", ...restOptions } = options;
	const capnWebRef = (0, import_react.useRef)(null);
	const transportRef = (0, import_react.useRef)(transport);
	transportRef.current = transport;
	const nativeQueueRef = (0, import_react.useRef)(new NativeCallQueue());
	const socketClass = (0, import_react.useMemo)(() => transport === "capnweb" ? { WebSocket: boundCapnWebSocket((socket) => {
		capnWebRef.current = socket;
	}) } : {}, [transport]);
	const subChain = (0, import_react.useMemo)(() => (subOption ?? []).map((s) => ({
		agent: s.agent,
		name: s.name
	})), [JSON.stringify(subOption ?? [])]);
	const leafAgent = subChain.length > 0 ? subChain[subChain.length - 1].agent : options.agent;
	const leafName = subChain.length > 0 ? subChain[subChain.length - 1].name : options.name || "default";
	const fullPath = (0, import_react.useMemo)(() => [{
		agent: options.agent,
		name: options.name || "default"
	}, ...subChain], [
		options.agent,
		options.name,
		subChain
	]);
	const pendingCallsRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const socketRef = (0, import_react.useRef)(null);
	const defaultCallTimeoutRef = (0, import_react.useRef)(defaultCallTimeout ?? 3e4);
	defaultCallTimeoutRef.current = defaultCallTimeout ?? 3e4;
	/** Reject (and remove) every pending call transmitted on `socket`. */
	const rejectCallsSentOn = (socket, reason) => {
		const error = new Error(reason);
		for (const [id, pending] of pendingCallsRef.current) if (pending.sentOn === socket) {
			if (pending.timeoutId) clearTimeout(pending.timeoutId);
			pendingCallsRef.current.delete(id);
			pending.reject(error);
			pending.stream?.onError?.(reason);
		}
	};
	/** Transmit queued (never-sent) calls if the live socket is open. */
	const flushQueuedCalls = () => {
		const socket = socketRef.current;
		if (!socket || socket.readyState !== socket.OPEN) return;
		for (const pending of pendingCallsRef.current.values()) if (pending.sentOn === null) {
			socket.send(pending.request);
			pending.sentOn = socket;
		}
		const native = transportRef.current === "capnweb" ? capnWebRef.current : null;
		if (native) nativeQueueRef.current.flush(native);
	};
	/** Reject (and remove) every still-queued (never transmitted) call. */
	const rejectQueuedCalls = (reason) => {
		nativeQueueRef.current.rejectAll(reason);
		const error = new Error(reason);
		for (const [id, pending] of pendingCallsRef.current) if (pending.sentOn === null) {
			if (pending.timeoutId) clearTimeout(pending.timeoutId);
			pendingCallsRef.current.delete(id);
			pending.reject(error);
			pending.stream?.onError?.(reason);
		}
	};
	const cacheKey = (0, import_react.useMemo)(() => createCacheKey(agentNamespace, options.name, subChain, queryDeps || []), [
		agentNamespace,
		options.name,
		subChain,
		queryDeps
	]);
	const cacheKeyRef = (0, import_react.useRef)(cacheKey);
	cacheKeyRef.current = cacheKey;
	const ttl = cacheTtl ?? 3e5;
	const [cacheInvalidatedAt, setCacheInvalidatedAt] = (0, import_react.useState)(0);
	const isAsyncQuery = query && typeof query === "function";
	const [awaitingQueryRefresh, setAwaitingQueryRefresh] = (0, import_react.useState)(false);
	const queryPromise = (0, import_react.useMemo)(() => {
		if (!query || typeof query !== "function") return null;
		const cached = getCacheEntry(cacheKey);
		if (cached) return cached.promise;
		const promise = query().catch((error) => {
			console.error(`[useAgent] Query failed for agent "${options.agent}":`, error);
			deleteCacheEntry(cacheKey);
			throw error;
		});
		setCacheEntry(cacheKey, promise, ttl);
		return promise;
	}, [
		cacheKey,
		query,
		options.agent,
		ttl,
		cacheInvalidatedAt
	]);
	(0, import_react.useEffect)(() => {
		if (!queryPromise || ttl <= 0) return;
		const entry = getCacheEntry(cacheKey);
		if (!entry) return;
		const timeUntilExpiry = entry.expiresAt - Date.now();
		const timer = setTimeout(() => {
			deleteCacheEntry(cacheKey);
			setCacheInvalidatedAt(Date.now());
		}, Math.max(0, timeUntilExpiry));
		return () => clearTimeout(timer);
	}, [
		cacheKey,
		queryPromise,
		ttl
	]);
	let resolvedQuery;
	if (query) if (typeof query === "function") {
		const queryResult = (0, import_react.use)(queryPromise);
		if (queryResult) {
			for (const [key, value] of Object.entries(queryResult)) if (value !== null && value !== void 0 && typeof value !== "string" && typeof value !== "number" && typeof value !== "boolean") console.warn(`[useAgent] Query parameter "${key}" is an object and will be converted to "[object Object]". Query parameters should be string, number, boolean, or null.`);
			resolvedQuery = queryResult;
		}
	} else resolvedQuery = query;
	(0, import_react.useEffect)(() => {
		if (awaitingQueryRefresh && resolvedQuery !== void 0) setAwaitingQueryRefresh(false);
	}, [awaitingQueryRefresh, resolvedQuery]);
	const [agentState, setAgentState] = (0, import_react.useState)(void 0);
	const [connectionError, setConnectionError] = (0, import_react.useState)(null);
	const connectionErrorRef = (0, import_react.useRef)(null);
	const connectionErrorAddressKeyRef = (0, import_react.useRef)(null);
	const shouldReconnectOnCloseRef = (0, import_react.useRef)(shouldReconnectOnClose);
	shouldReconnectOnCloseRef.current = shouldReconnectOnClose;
	const maxRetriesRef = (0, import_react.useRef)(restOptions.maxRetries);
	maxRetriesRef.current = restOptions.maxRetries;
	const [closeClassifier] = (0, import_react.useState)(() => createCloseClassifier({
		socket: () => socketRef.current,
		shouldReconnectOnClose: () => shouldReconnectOnCloseRef.current,
		maxRetries: () => maxRetriesRef.current
	}));
	const classifyReconnect = closeClassifier.shouldReconnectOnClose;
	const [identity, setIdentity] = (0, import_react.useState)(() => ({
		name: leafName,
		agent: camelCaseToKebabCase(leafAgent),
		identified: false,
		destination: null
	}));
	const previousIdentityRef = (0, import_react.useRef)({
		name: null,
		agent: null
	});
	const readyRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const readyFor = (destination) => {
		let entry = readyRef.current.get(destination);
		if (!entry) {
			entry = createReadyEntry();
			readyRef.current.set(destination, entry);
		}
		return entry;
	};
	const resetReady = (destination) => {
		if (readyRef.current.get(destination)?.resolved !== false) readyRef.current.set(destination, createReadyEntry());
	};
	const mutableAgentRef = (0, import_react.useRef)(null);
	const combinedPath = (0, import_react.useMemo)(() => buildSubPath(subChain, userPath), [subChain, userPath]);
	const socketQuery = transport === "capnweb" ? {
		...resolvedQuery,
		[CAPNWEB_TRANSPORT_QUERY]: CAPNWEB_TRANSPORT_VALUE
	} : resolvedQuery;
	const socketOptions = options.basePath ? {
		basePath: options.basePath,
		path: combinedPath || void 0,
		query: socketQuery,
		...restOptions,
		...socketClass,
		shouldReconnectOnClose: classifyReconnect
	} : {
		party: agentNamespace,
		prefix: "agents",
		room: options.name || "default",
		path: combinedPath || void 0,
		query: socketQuery,
		...restOptions,
		...socketClass,
		shouldReconnectOnClose: classifyReconnect
	};
	const socketEnabled = !awaitingQueryRefresh && (restOptions.enabled ?? true);
	const addressKey = JSON.stringify([
		options.host ?? null,
		options.basePath ?? null,
		agentNamespace,
		options.name || "default",
		combinedPath || null,
		transport
	]);
	const destination = socketDestinationKey({
		...socketOptions,
		host: socketOptions.host || defaultSocketHost()
	});
	const seedDestinationRef = (0, import_react.useRef)(destination);
	const visibleConnectionError = connectionErrorAddressKeyRef.current === addressKey ? connectionError : null;
	connectionErrorRef.current = visibleConnectionError;
	const connectProgressRef = (0, import_react.useRef)(/* @__PURE__ */ new WeakMap());
	const connectProgress = (socket) => {
		if (!socket) return {
			stateSeen: false,
			pendingIdentity: null
		};
		let progress = connectProgressRef.current.get(socket);
		if (!progress) {
			progress = {
				stateSeen: false,
				pendingIdentity: null
			};
			connectProgressRef.current.set(socket, progress);
		}
		return progress;
	};
	const applyIdentity = (newName, newAgent, identifiedSocket) => {
		const oldName = previousIdentityRef.current.name;
		const oldAgent = previousIdentityRef.current.agent;
		const currentAgent = mutableAgentRef.current;
		if (currentAgent) {
			currentAgent.name = newName;
			currentAgent.agent = newAgent;
			currentAgent.identified = true;
		}
		const identifiedDestination = identifiedSocket ? socketDestinationKey(identifiedSocket.partySocketOptions) : null;
		setIdentity({
			name: newName,
			agent: newAgent,
			identified: true,
			destination: identifiedDestination
		});
		if (identifiedDestination !== null) readyFor(identifiedDestination).resolve();
		if (oldName !== null && oldAgent !== null && (oldName !== newName || oldAgent !== newAgent)) if (options.onIdentityChange) options.onIdentityChange(oldName, newName, oldAgent, newAgent);
		else {
			const agentChanged = oldAgent !== newAgent;
			const nameChanged = oldName !== newName;
			let changeDescription = "";
			if (agentChanged && nameChanged) changeDescription = `agent "${oldAgent}" \u2192 "${newAgent}", instance "${oldName}" \u2192 "${newName}"`;
			else if (agentChanged) changeDescription = `agent "${oldAgent}" \u2192 "${newAgent}"`;
			else changeDescription = `instance "${oldName}" \u2192 "${newName}"`;
			console.warn(`[agents] Identity changed on reconnect: ${changeDescription}. This can happen with server-side routing (e.g., basePath with getAgentByName) where the instance is determined by auth/session. Provide onIdentityChange callback to handle this explicitly, or ignore if this is expected for your routing pattern.`);
		}
		previousIdentityRef.current = {
			name: newName,
			agent: newAgent
		};
		options.onIdentity?.(newName, newAgent);
	};
	const agent = usePartySocket({
		...socketOptions,
		enabled: socketEnabled,
		onOpen: (event) => {
			connectionErrorAddressKeyRef.current = null;
			setConnectionError(null);
			flushQueuedCalls();
			options.onOpen?.(event);
		},
		onMessage: (message) => {
			if (typeof message.data === "string") {
				let parsedMessage;
				try {
					parsedMessage = JSON.parse(message.data);
				} catch (_error) {
					return options.onMessage?.(message);
				}
				if (parsedMessage.type === "cf_agent_identity") {
					const identifiedSocket = message.target ?? socketRef.current;
					const newName = parsedMessage.name;
					const newAgent = parsedMessage.agent;
					const progress = connectProgress(identifiedSocket);
					if (parsedMessage.stateFollows === true && !progress.stateSeen) {
						progress.pendingIdentity = [newName, newAgent];
						return;
					}
					applyIdentity(newName, newAgent, identifiedSocket);
					return;
				}
				if (parsedMessage.type === "cf_agent_state") {
					setAgentState(parsedMessage.state);
					if (mutableAgentRef.current) mutableAgentRef.current.state = parsedMessage.state;
					const stateSocket = message.target ?? socketRef.current;
					try {
						options.onStateUpdate?.(parsedMessage.state, "server");
					} finally {
						const progress = connectProgress(stateSocket);
						progress.stateSeen = true;
						const pending = progress.pendingIdentity;
						if (pending) {
							progress.pendingIdentity = null;
							applyIdentity(pending[0], pending[1], stateSocket);
						}
					}
					return;
				}
				if (parsedMessage.type === "cf_agent_state_error") {
					options.onStateUpdateError?.(parsedMessage.error);
					return;
				}
				if (parsedMessage.type === "cf_agent_mcp_servers") {
					options.onMcpUpdate?.(parsedMessage.mcp);
					return;
				}
				if (parsedMessage.type === "rpc") {
					const response = parsedMessage;
					const pending = pendingCallsRef.current.get(response.id);
					if (!pending) {
						console.warn(`[useAgent] Discarded an RPC response with no matching pending call (id "${response.id}"). The call likely timed out or was rejected when its connection closed before the response arrived.`);
						return;
					}
					if (!response.success) {
						if (pending.timeoutId) clearTimeout(pending.timeoutId);
						pending.reject(new Error(response.error));
						pendingCallsRef.current.delete(response.id);
						pending.stream?.onError?.(response.error);
						return;
					}
					if ("done" in response) if (response.done) {
						if (pending.timeoutId) clearTimeout(pending.timeoutId);
						pending.resolve(response.result);
						pendingCallsRef.current.delete(response.id);
						pending.stream?.onDone?.(response.result);
					} else pending.stream?.onChunk?.(response.result);
					else {
						if (pending.timeoutId) clearTimeout(pending.timeoutId);
						pending.resolve(response.result);
						pendingCallsRef.current.delete(response.id);
					}
					return;
				}
			}
			options.onMessage?.(message);
		},
		onClose: (event) => {
			const closedSocket = event.target ?? socketRef.current;
			const isCurrentSocket = closedSocket === socketRef.current;
			const finalClose = closeClassifier.takeFinalClose();
			if (closedSocket) connectProgressRef.current.delete(closedSocket);
			const reconnecting = !!closedSocket?.shouldReconnect && !finalClose;
			if (closedSocket) {
				rejectCallsSentOn(closedSocket, "Connection closed");
				if (isCurrentSocket && !reconnecting) rejectQueuedCalls("Connection closed");
			}
			if (isCurrentSocket) {
				if (closedSocket) resetReady(socketDestinationKey(closedSocket.partySocketOptions));
				if (mutableAgentRef.current) mutableAgentRef.current.identified = false;
				setIdentity((prev) => ({
					...prev,
					identified: false
				}));
				if (reconnecting) {
					if (isAsyncQuery) setAwaitingQueryRefresh(true);
					deleteCacheEntry(cacheKeyRef.current);
					setCacheInvalidatedAt(Date.now());
				}
				if (finalClose) {
					const error = new AgentConnectionError(event);
					connectionErrorAddressKeyRef.current = addressKey;
					setConnectionError(error);
					onConnectionError?.(error);
				}
			}
			options.onClose?.(event);
		}
	});
	socketRef.current = agent;
	const socketAddressPending = socketDestinationKey(agent.partySocketOptions) !== destination;
	const prevSocketRef = (0, import_react.useRef)(null);
	const prevAddressKeyRef = (0, import_react.useRef)(addressKey);
	const prevDestinationRef = (0, import_react.useRef)(destination);
	(0, import_react.useEffect)(() => {
		const prev = prevSocketRef.current;
		prevSocketRef.current = agent;
		const prevAddress = prevAddressKeyRef.current;
		prevAddressKeyRef.current = addressKey;
		const prevDestination = prevDestinationRef.current;
		prevDestinationRef.current = destination;
		if (prevDestination !== destination) previousIdentityRef.current = {
			name: null,
			agent: null
		};
		if (prevAddress !== addressKey) {
			connectionErrorAddressKeyRef.current = null;
			setConnectionError(null);
			rejectQueuedCalls("Call discarded: the agent address changed before the request could be sent");
		}
		for (const [key, entry] of readyRef.current) if (key !== destination && entry.resolved) readyRef.current.delete(key);
		if (prev && prev !== agent) {
			rejectCallsSentOn(prev, "Connection closed");
			resetReady(socketDestinationKey(agent.partySocketOptions));
			if (mutableAgentRef.current) mutableAgentRef.current.identified = false;
			setIdentity((current) => current.identified ? {
				...current,
				identified: false
			} : current);
		}
	}, [
		agent,
		addressKey,
		destination
	]);
	const call = (0, import_react.useCallback)((method, args = [], options) => {
		if (transportRef.current === "capnweb") {
			const native = capnWebRef.current;
			const socket = socketRef.current;
			if (native && socket?.readyState === WebSocket.OPEN) return nativeCall(native, method, args, options, defaultCallTimeoutRef.current);
			if (socket && connectionErrorRef.current && socket.readyState === socket.CLOSED) return Promise.reject(/* @__PURE__ */ new Error("Connection closed"));
			return nativeQueueRef.current.enqueue(method, args, options, defaultCallTimeoutRef.current);
		}
		return new Promise((resolve, reject) => {
			const socket = socketRef.current;
			if (socket && connectionErrorRef.current && socket.readyState === socket.CLOSED) {
				reject(/* @__PURE__ */ new Error("Connection closed"));
				return;
			}
			const id = crypto.randomUUID();
			let timeoutId;
			const { stream: streamOptions, timeout } = splitCallOptions(options);
			const effectiveTimeout = timeout !== void 0 ? timeout : streamOptions ? void 0 : defaultCallTimeoutRef.current;
			if (effectiveTimeout) timeoutId = setTimeout(() => {
				const pending = pendingCallsRef.current.get(id);
				pendingCallsRef.current.delete(id);
				const errorMessage = `RPC call to ${method} timed out after ${effectiveTimeout}ms`;
				pending?.stream?.onError?.(errorMessage);
				reject(new Error(errorMessage));
			}, effectiveTimeout);
			const request = JSON.stringify({
				args,
				id,
				method,
				type: "rpc"
			});
			pendingCallsRef.current.set(id, {
				reject,
				resolve,
				stream: streamOptions,
				timeoutId,
				request,
				sentOn: null
			});
			if (socket && socket.readyState === socket.OPEN) {
				socket.send(request);
				const pending = pendingCallsRef.current.get(id);
				if (pending) pending.sentOn = socket;
			}
		});
	}, []);
	agent.setState = (newState) => {
		(socketRef.current ?? agent).send(JSON.stringify({
			state: newState,
			type: "cf_agent_state"
		}));
		if (mutableAgentRef.current) mutableAgentRef.current.state = newState;
		setAgentState(newState);
		options.onStateUpdate?.(newState, "client");
	};
	agent.call = call;
	const identityIsCurrent = !!options.basePath || (identity.destination ?? seedDestinationRef.current) === destination;
	agent.agent = identityIsCurrent ? identity.agent : camelCaseToKebabCase(leafAgent);
	agent.name = identityIsCurrent ? identity.name : leafName;
	agent.path = fullPath;
	agent.identified = identityIsCurrent && identity.identified;
	agent.ready = readyFor(destination).promise;
	agent.state = agentState;
	agent.connectionError = visibleConnectionError;
	mutableAgentRef.current = agent;
	agent.stub = (0, import_react.useMemo)(() => createStubProxy(call), [call]);
	agent[SOCKET_ADDRESS_PENDING] = socketAddressPending;
	agent.getHttpUrl = () => {
		if (socketAddressPending) return "";
		return (agent._url || agent._pkurl || "").replace("ws://", "http://").replace("wss://", "https://");
	};
	if (identity.agent !== identity.agent.toLowerCase()) console.warn("Agent name: " + identity.agent + " should probably be in lowercase. Received: " + identity.agent);
	return agent;
}
//#endregion
//#region node_modules/.pnpm/agents@0.28.1_@ai-sdk+provider@4.0.4_@ai-sdk+react@3.0.211_react@19.2.4_zod@4.6.7__@bab_539d04cddbcc3adc73174759dfaafa16/node_modules/agents/dist/ws-chat-transport-cqMKq3IY.js
/**
* Batches chunks replayed during stream resume.
*
* Replaying every chunk separately can exceed React's update limit. Adjacent
* deltas for the same message part are merged until the replay pauses or ends.
*/
var ReplayChunkBatch = class {
	constructor(controller, closeWindow = (flush) => {
		const timer = setTimeout(flush, 0);
		return () => clearTimeout(timer);
	}) {
		this.controller = controller;
		this.closeWindow = closeWindow;
		this.chunks = [];
		this.tailMergeKey = null;
	}
	get bufferedStartMessageId() {
		return this.startMessageId;
	}
	get isEmpty() {
		return this.chunks.length === 0;
	}
	push(chunk) {
		const key = mergeKeyOf(chunk);
		const tail = this.chunks[this.chunks.length - 1];
		if (tail !== void 0 && key !== null && key === this.tailMergeKey) {
			appendDeltaText(tail, chunk);
			return;
		}
		if (this.chunks.length === 0) this.cancelWindow = this.closeWindow(() => {
			this.cancelWindow = void 0;
			this.flush();
		});
		if (chunk.type === "start") this.startMessageId = chunk.messageId;
		this.chunks.push(chunk);
		this.tailMergeKey = key;
	}
	discard() {
		this.cancelWindow?.();
		this.cancelWindow = void 0;
		this.chunks = [];
		this.tailMergeKey = null;
		this.startMessageId = void 0;
	}
	flush() {
		this.cancelWindow?.();
		this.cancelWindow = void 0;
		if (this.chunks.length === 0) return;
		const batch = this.chunks;
		this.chunks = [];
		this.tailMergeKey = null;
		this.startMessageId = void 0;
		try {
			for (const chunk of batch) this.controller.enqueue(chunk);
		} catch {}
	}
	enqueueNow(chunk) {
		this.controller.enqueue(chunk);
	}
	closeNow() {
		this.controller.close();
	}
	errorNow(error) {
		this.controller.error(error);
	}
};
/** Buffers replay chunks and flushes them before live or boundary frames. */
function applyChatResponseFrame(batch, frame) {
	const endsReplayBurst = frame.replay !== true || frame.done === true || frame.replayComplete === true;
	const body = frame.body?.trim();
	if (!body) {
		if (endsReplayBurst) batch.flush();
		return;
	}
	let chunk;
	try {
		chunk = JSON.parse(body);
	} catch {
		if (endsReplayBurst) batch.flush();
		return;
	}
	if (endsReplayBurst) {
		batch.flush();
		batch.enqueueNow(chunk);
		return;
	}
	if (supersedesBufferedPass(batch, chunk, frame)) batch.discard();
	batch.push(chunk);
}
function supersedesBufferedPass(batch, chunk, frame) {
	return chunk.type === "start" && frame.continuation !== true && chunk.messageId !== void 0 && chunk.messageId === batch.bufferedStartMessageId;
}
/**
* Reports an error after buffered content. `controller.error()` would discard
* chunks that have not reached the consumer.
*/
function failChatStream(batch, message) {
	if (batch.isEmpty) {
		batch.errorNow(new Error(message));
		return;
	}
	batch.flush();
	batch.enqueueNow({
		errorText: message,
		type: "error"
	});
	batch.closeNow();
}
function mergeKeyOf(chunk) {
	switch (chunk.type) {
		case "text-delta":
		case "reasoning-delta": return chunk.providerMetadata === void 0 ? `${chunk.type}\u0000${chunk.id}` : null;
		case "tool-input-delta": return `tool-input-delta\u0000${chunk.toolCallId}`;
		default: return null;
	}
}
function appendDeltaText(target, source) {
	if (target.type === "tool-input-delta" && source.type === "tool-input-delta") {
		target.inputTextDelta += source.inputTextDelta;
		return;
	}
	if ((target.type === "text-delta" || target.type === "reasoning-delta") && (source.type === "text-delta" || source.type === "reasoning-delta")) target.delta += source.delta;
}
/**
* Requests the ledger remembers. A request that finishes while the client is
* disconnected never delivers the terminal frame that would forget it.
*/
var MAX_TRACKED_REQUESTS = 32;
/** Highest chunk `seq` this client applied, per request id. */
var AppliedChunkLedger = class {
	constructor() {
		this.applied = /* @__PURE__ */ new Map();
	}
	record(requestId, seq) {
		if (seq === void 0) return;
		const applied = Math.max(seq, this.applied.get(requestId) ?? -1);
		this.applied.delete(requestId);
		this.applied.set(requestId, applied);
		if (this.applied.size > MAX_TRACKED_REQUESTS) {
			const oldest = this.applied.keys().next().value;
			if (oldest !== void 0) this.applied.delete(oldest);
		}
	}
	/** Whether `frame` replays a continuation chunk this client already applied. */
	isAppliedReplay(requestId, frame) {
		return frame.replay === true && frame.continuation === true && frame.seq !== void 0 && frame.seq <= (this.applied.get(requestId) ?? -1);
	}
	forget(requestId) {
		this.applied.delete(requestId);
	}
	clear() {
		this.applied.clear();
	}
};
/**
* Filters one resumed stream's frames for a consumer that needs every part
* opened before its deltas arrive (the AI SDK UI message stream). Applied
* replay chunks are dropped; a part that was still open when they end is
* re-opened with its original start chunk, so the new deltas have a part to
* land in. The re-opened part renders as a second, adjacent part until the
* server's final message replaces it.
*/
var ContinuationReplayFilter = class {
	constructor(ledger, requestId) {
		this.ledger = ledger;
		this.requestId = requestId;
		this.openParts = /* @__PURE__ */ new Map();
	}
	/** The frames to apply in place of `frame`. */
	frames(frame) {
		if (this.ledger.isAppliedReplay(this.requestId, frame)) {
			this.trackOpenPart(frame.body);
			return frame.body?.trim() ? [{
				...frame,
				body: ""
			}] : [frame];
		}
		this.ledger.record(this.requestId, frame.seq);
		if (this.openParts.size === 0 || !frame.body?.trim()) return [frame];
		const reopened = [...this.openParts.values()].map((body) => ({
			...frame,
			body,
			seq: void 0
		}));
		this.openParts.clear();
		return [...reopened, frame];
	}
	trackOpenPart(body) {
		let chunk;
		try {
			chunk = JSON.parse(body ?? "");
		} catch {
			return;
		}
		switch (chunk.type) {
			case "text-start":
			case "reasoning-start":
				this.openParts.set(`${chunk.type}:${chunk.id}`, body ?? "");
				break;
			case "text-end":
				this.openParts.delete(`text-start:${chunk.id}`);
				break;
			case "reasoning-end":
				this.openParts.delete(`reasoning-start:${chunk.id}`);
				break;
			case "tool-input-start":
				this.openParts.set(`tool:${chunk.toolCallId}`, body ?? "");
				break;
			case "tool-input-available":
			case "tool-input-error": this.openParts.delete(`tool:${chunk.toolCallId}`);
		}
	}
};
/**
* Short safety-net timeout for a resume probe when the server has said nothing.
* Under normal operation the server answers a `STREAM_RESUME_REQUEST` with
* `STREAM_RESUMING`, `STREAM_RESUME_NONE`, or `STREAM_PENDING` well before this.
*/
var RESUME_PROBE_TIMEOUT_MS = 5e3;
/**
* Extended backstop applied once the server says a turn is pending
* (`STREAM_PENDING`, #1784). The pre-stream window (queueing, MCP setup,
* debounce, model latency) can exceed the short probe timeout, and the server
* guarantees a follow-up `STREAM_RESUMING` or `STREAM_RESUME_NONE` \u2014 so we wait
* much longer (refreshed on every keep-waiting frame) but still cap it so a
* dropped follow-up degrades to a null resolve instead of hanging forever.
*/
var RESUME_PENDING_TIMEOUT_MS = 6e4;
var SOCKET_CLOSED_MID_STREAM = "WebSocket closed mid-stream";
/**
* Ends a stream whose socket closed before the terminal `done` frame, so the
* AI SDK reports an interrupted turn instead of a completed one (#2013).
* Uses an error chunk because `controller.error()` would discard chunks the
* consumer has not read yet.
*/
function interruptChatStream(controller, batch) {
	batch?.flush();
	controller.enqueue({
		type: "error",
		errorText: SOCKET_CLOSED_MID_STREAM
	});
	controller.close();
}
/**
* ChatTransport that sends messages over WebSocket and returns a
* ReadableStream<UIMessageChunk> that the AI SDK's useChat consumes directly.
*
* This low-level transport handles new and regenerated request streams plus
* cancellation. Higher-level protocol coordination such as automatic reconnect
* resume, cross-tab transcript synchronization, and client-tool continuations
* is provided by integrations such as `useAgentChat`.
*/
var WebSocketChatTransport = class {
	constructor(options) {
		this._resumeResolver = null;
		this.appliedChunks = new AppliedChunkLedger();
		this._resumeNoneResolver = null;
		this._onStreamPending = null;
		this._retryResumeProbe = null;
		this._expectToolContinuation = false;
		this._abortToolContinuation = null;
		this._activeServerTurnId = null;
		this._cancelAttachedStream = null;
		this._detachResumeStream = null;
		this.agent = options.agent;
		this.prepareBody = options.prepareBody;
		this.activeRequestIds = options.activeRequestIds;
		this.cancelOnClientAbort = options.cancelOnClientAbort ?? false;
		this.onRequestBuffered = options.onRequestBuffered;
	}
	/**
	* Point the singleton transport at a new Agent connection. A pending resolver
	* belongs to the old Chat/socket generation and must settle before messages
	* from the replacement connection can be consumed (#1914 review).
	*/
	setAgent(agent) {
		if (this.agent === agent) return;
		this.resetResumeState();
		this.agent = agent;
	}
	setCancelOnClientAbort(cancelOnClientAbort) {
		this.cancelOnClientAbort = cancelOnClientAbort;
	}
	/**
	* Explicitly cancel the active server turn, if any.
	* This is separate from generic client-side abort/cancel lifecycle so
	* clients can detach locally without stopping server work.
	*/
	cancelActiveServerTurn() {
		const requestId = this._activeServerTurnId;
		let cancelledRequest = false;
		if (requestId) {
			this.sendCancelFrame(requestId);
			this._cancelAttachedStream?.();
			this.clearActiveServerTurn(requestId);
			cancelledRequest = true;
		}
		const cancelledToolContinuation = this.abortActiveToolContinuation();
		return cancelledRequest || cancelledToolContinuation;
	}
	/**
	* The server turn this transport last attached to that has not reported a
	* terminal frame. A socket close ends the local stream but keeps this set,
	* since the server keeps running the turn.
	*/
	get activeServerTurnId() {
		return this._activeServerTurnId;
	}
	sendCancelFrame(requestId) {
		try {
			this.agent.send(JSON.stringify({
				id: requestId,
				type: "cf_agent_chat_request_cancel"
			}));
		} catch {}
	}
	setActiveServerTurn(requestId, cancelAttachedStream) {
		this._activeServerTurnId = requestId;
		this._cancelAttachedStream = cancelAttachedStream;
	}
	clearActiveServerTurn(requestId) {
		if (this._activeServerTurnId === requestId) {
			this._activeServerTurnId = null;
			this._cancelAttachedStream = null;
		}
	}
	/**
	* Mark that the next reconnectToStream() call should attach to a
	* server-initiated tool continuation rather than a page-load resume.
	*/
	expectToolContinuation() {
		this._expectToolContinuation = true;
	}
	/**
	* Abort the active client-side tool continuation stream, if one is attached
	* to a server request id.
	*/
	abortActiveToolContinuation() {
		return this._abortToolContinuation?.() ?? false;
	}
	/**
	* True when the transport is waiting for a resume handshake.
	*/
	isAwaitingResume() {
		return this._resumeResolver !== null || this._resumeNoneResolver !== null;
	}
	/**
	* Settle and detach the current handshake without interpreting it as a
	* server-idle response. Used when the owning hook/agent generation changes.
	*/
	cancelPendingResume() {
		const resolveNone = this._resumeNoneResolver;
		if (!resolveNone) return false;
		return resolveNone({});
	}
	/**
	* Invalidate all client-side resume state for an obsolete hook/agent
	* generation without cancelling its durable server turn.
	*/
	resetResumeState() {
		this._expectToolContinuation = false;
		this.cancelPendingResume();
		this._detachResumeStream?.();
	}
	/**
	* Re-send the active handshake request on the latest socket generation. This
	* preserves one AI SDK resume operation while recovering a request/reply lost
	* with the previous WebSocket.
	*/
	retryPendingResume() {
		const retry = this._retryResumeProbe;
		if (!retry) return false;
		retry();
		return true;
	}
	/**
	* Called by onAgentMessage when it receives CF_AGENT_STREAM_RESUMING.
	* If reconnectToStream is waiting, this handles the resume handshake
	* (ACK + stream creation) and returns true. Otherwise returns false
	* so the caller can use its own fallback path.
	*/
	handleStreamResuming(data) {
		if (!this._resumeResolver) return false;
		this._resumeResolver(data);
		return true;
	}
	/**
	* Called by onAgentMessage when it receives CF_AGENT_STREAM_RESUME_NONE.
	* If reconnectToStream is waiting, resolves the promise with null
	* immediately (no 5-second timeout). Returns true if handled.
	*/
	handleStreamResumeNone(data = {}) {
		if (!this._resumeNoneResolver) return false;
		return this._resumeNoneResolver(data);
	}
	/**
	* Called by onAgentMessage when it receives CF_AGENT_STREAM_PENDING (#1784):
	* the server accepted a turn but its stream has not started yet. If a resume
	* path is awaiting, extend its probe timeout (so it keeps waiting for the
	* eventual STREAM_RESUMING / STREAM_RESUME_NONE instead of resolving null
	* after the short window). Returns true if a waiting path consumed it.
	*/
	handleStreamPending() {
		if (!this._onStreamPending) return false;
		this._onStreamPending();
		return true;
	}
	/**
	* Called by the hook's shared message handler when a server turn finishes
	* outside the currently attached transport stream, such as after local-only
	* client cleanup.
	*/
	handleServerTurnCompleted(requestId) {
		this.clearActiveServerTurn(requestId);
	}
	/**
	* Register a server turn that is being rendered outside a transport-owned
	* stream, such as the hook's fallback cross-tab/resume observer path.
	*/
	observeServerTurn(requestId) {
		this.setActiveServerTurn(requestId, null);
	}
	async sendMessages(options) {
		const requestId = nanoid(8);
		const abortController = new AbortController();
		let completed = false;
		let requestSent = false;
		let extraBody = {};
		if (this.prepareBody) extraBody = await this.prepareBody({
			messages: options.messages,
			trigger: options.trigger,
			messageId: options.messageId
		});
		if (options.body) extraBody = {
			...extraBody,
			...options.body
		};
		const bodyPayload = JSON.stringify({
			messages: options.messages,
			trigger: options.trigger,
			...extraBody
		});
		this.activeRequestIds?.add(requestId);
		const agent = this.agent;
		const activeIds = this.activeRequestIds;
		const finish = (action, keepId = false, clearServerTurn = true) => {
			if (completed) return;
			completed = true;
			if (clearServerTurn) this.clearActiveServerTurn(requestId);
			try {
				action();
			} catch {}
			if (!keepId) activeIds?.delete(requestId);
			abortController.abort();
		};
		const abortError = /* @__PURE__ */ new Error("Aborted");
		abortError.name = "AbortError";
		const cancelActiveRequest = () => {
			if (completed) return false;
			finish(() => streamController.error(abortError), true);
			return true;
		};
		this.setActiveServerTurn(requestId, cancelActiveRequest);
		const onAbort = () => {
			if (completed) return;
			if (this.cancelOnClientAbort) {
				if (requestSent) this.sendCancelFrame(requestId);
				finish(() => streamController.error(abortError), requestSent);
			} else finish(() => streamController.error(abortError), false, !requestSent);
		};
		let streamController;
		const stream = new ReadableStream({
			start(controller) {
				streamController = controller;
				const onMessage = (event) => {
					try {
						const data = JSON.parse(event.data);
						if (data.type !== "cf_agent_use_chat_response") return;
						if (data.id !== requestId) return;
						if (data.error) {
							finish(() => controller.error(new Error(data.body || "Stream error")));
							return;
						}
						if (data.body?.trim()) try {
							const chunk = JSON.parse(data.body);
							controller.enqueue(chunk);
						} catch {}
						if (data.done) finish(() => controller.close());
					} catch {}
				};
				const onClose = () => {
					finish(() => interruptChatStream(controller), false, false);
				};
				agent.addEventListener("message", onMessage, { signal: abortController.signal });
				agent.addEventListener("close", onClose, { signal: abortController.signal });
			},
			cancel() {
				onAbort();
			}
		});
		if (options.abortSignal) {
			options.abortSignal.addEventListener("abort", onAbort, { once: true });
			if (options.abortSignal.aborted) onAbort();
		}
		if (completed) return stream;
		requestSent = true;
		if (agent.send(JSON.stringify({
			id: requestId,
			init: {
				method: "POST",
				body: bodyPayload
			},
			type: "cf_agent_use_chat_request"
		})) === false && options.trigger === "submit-message") {
			const lastUserMessage = [...options.messages].reverse().find((message) => message.role === "user");
			this.onRequestBuffered?.(lastUserMessage?.id);
		}
		return stream;
	}
	async reconnectToStream(_options) {
		if (this.isAwaitingResume()) return null;
		if (this._expectToolContinuation) {
			this._expectToolContinuation = false;
			return this._createToolContinuationStream();
		}
		const activeIds = this.activeRequestIds;
		const probeId = nanoid(8);
		return new Promise((resolve) => {
			let resolved = false;
			let timeout;
			let resumeResolver = null;
			let resumeNoneResolver = null;
			let onStreamPending = null;
			let retryResumeProbe = null;
			const clearOwnedCallbacks = () => {
				if (resumeResolver && this._resumeResolver === resumeResolver) this._resumeResolver = null;
				if (resumeNoneResolver && this._resumeNoneResolver === resumeNoneResolver) this._resumeNoneResolver = null;
				if (onStreamPending && this._onStreamPending === onStreamPending) this._onStreamPending = null;
				if (retryResumeProbe && this._retryResumeProbe === retryResumeProbe) this._retryResumeProbe = null;
			};
			const done = (value) => {
				if (resolved) return;
				resolved = true;
				clearOwnedCallbacks();
				if (timeout) clearTimeout(timeout);
				resolve(value);
			};
			const armTimeout = (delay) => {
				if (timeout) clearTimeout(timeout);
				timeout = setTimeout(() => done(null), delay);
			};
			onStreamPending = () => {
				if (resolved) return;
				armTimeout(RESUME_PENDING_TIMEOUT_MS);
			};
			resumeNoneResolver = (data) => {
				if (data.probeId && data.probeId !== probeId) return false;
				done(null);
				return true;
			};
			resumeResolver = (data) => {
				const requestId = data.id;
				activeIds?.add(requestId);
				const stream = this._createResumeStream(requestId);
				this.agent.send(JSON.stringify({
					type: "cf_agent_stream_resume_ack",
					id: requestId
				}));
				done(stream);
			};
			retryResumeProbe = () => {
				if (resolved) return;
				armTimeout(RESUME_PROBE_TIMEOUT_MS);
				try {
					this.agent.send(JSON.stringify({
						type: "cf_agent_stream_resume_request",
						probeId
					}));
				} catch {}
			};
			this._onStreamPending = onStreamPending;
			this._resumeNoneResolver = resumeNoneResolver;
			this._resumeResolver = resumeResolver;
			this._retryResumeProbe = retryResumeProbe;
			retryResumeProbe();
		});
	}
	/**
	* Creates a deferred ReadableStream for client-side tool continuations.
	* The stream is returned immediately so AI SDK status becomes "submitted"
	* right after addToolOutput()/addToolApprovalResponse(), then it waits for
	* the server to announce the continuation via STREAM_RESUMING.
	*/
	_createToolContinuationStream() {
		const agent = this.agent;
		const activeIds = this.activeRequestIds;
		const streamController = new AbortController();
		const abortError = /* @__PURE__ */ new Error("Aborted");
		abortError.name = "AbortError";
		let completed = false;
		let requestId = null;
		let readerController = null;
		let replayBatch = null;
		const probeId = nanoid(8);
		let onResumeRef = null;
		let onResumeNoneRef = null;
		let onStreamPendingRef = null;
		let retryResumeProbeRef = null;
		let abortToolContinuationRef = null;
		let detachResumeStreamRef = null;
		const clearOwnedHandshake = () => {
			if (onResumeRef && this._resumeResolver === onResumeRef) this._resumeResolver = null;
			if (onResumeNoneRef && this._resumeNoneResolver === onResumeNoneRef) this._resumeNoneResolver = null;
			if (onStreamPendingRef && this._onStreamPending === onStreamPendingRef) this._onStreamPending = null;
			if (retryResumeProbeRef && this._retryResumeProbe === retryResumeProbeRef) this._retryResumeProbe = null;
		};
		const finish = (action, keepRequestId = false) => {
			if (completed) return;
			completed = true;
			if (this._abortToolContinuation === abortToolContinuationRef) this._abortToolContinuation = null;
			if (this._detachResumeStream === detachResumeStreamRef) this._detachResumeStream = null;
			clearOwnedHandshake();
			try {
				action();
			} catch {}
			if (requestId && !keepRequestId) activeIds?.delete(requestId);
			streamController.abort();
		};
		const transport = this;
		abortToolContinuationRef = () => {
			if (completed) return false;
			if (requestId === null) {
				finish(() => readerController?.error(abortError));
				return true;
			}
			try {
				agent.send(JSON.stringify({
					type: "cf_agent_chat_request_cancel",
					id: requestId
				}));
			} catch {}
			finish(() => readerController?.error(abortError), true);
			return true;
		};
		this._abortToolContinuation = abortToolContinuationRef;
		detachResumeStreamRef = () => {
			if (completed) return false;
			finish(() => {
				replayBatch?.flush();
				readerController?.close();
			});
			return true;
		};
		this._detachResumeStream = detachResumeStreamRef;
		return new ReadableStream({
			start(controller) {
				readerController = controller;
				const batch = new ReplayChunkBatch(controller);
				replayBatch = batch;
				let replayFilter = null;
				let timeout;
				const armTimeout = (delay) => {
					if (timeout) clearTimeout(timeout);
					timeout = setTimeout(() => finish(() => controller.close()), delay);
				};
				const onResumeNone = (data) => {
					if (data.probeId && data.probeId !== probeId) return false;
					finish(() => controller.close());
					return true;
				};
				const onResume = (data) => {
					if (requestId) return;
					requestId = data.id;
					activeIds?.add(requestId);
					clearOwnedHandshake();
					if (timeout) clearTimeout(timeout);
					agent.send(JSON.stringify({
						type: "cf_agent_stream_resume_ack",
						id: requestId
					}));
				};
				const onStreamPending = () => {
					if (completed) return;
					armTimeout(RESUME_PENDING_TIMEOUT_MS);
				};
				const retryResumeProbe = () => {
					if (completed || requestId !== null) return;
					armTimeout(RESUME_PROBE_TIMEOUT_MS);
					try {
						transport.agent.send(JSON.stringify({
							type: "cf_agent_stream_resume_request",
							probeId
						}));
					} catch {}
				};
				onResumeRef = onResume;
				onResumeNoneRef = onResumeNone;
				onStreamPendingRef = onStreamPending;
				retryResumeProbeRef = retryResumeProbe;
				transport._resumeResolver = onResume;
				transport._resumeNoneResolver = onResumeNone;
				transport._onStreamPending = onStreamPending;
				transport._retryResumeProbe = retryResumeProbe;
				const onMessage = (event) => {
					try {
						const data = JSON.parse(event.data);
						if (data.type !== "cf_agent_use_chat_response" || requestId == null || data.id !== requestId) return;
						if (data.error) {
							transport.appliedChunks.forget(requestId);
							finish(() => failChatStream(batch, data.body || "Stream error"));
							return;
						}
						replayFilter ??= new ContinuationReplayFilter(transport.appliedChunks, requestId);
						for (const frame of replayFilter.frames(data)) applyChatResponseFrame(batch, frame);
						if (data.done) {
							transport.appliedChunks.forget(requestId);
							finish(() => controller.close());
						}
					} catch {}
				};
				const onClose = () => finish(() => requestId === null ? controller.close() : interruptChatStream(controller, batch));
				agent.addEventListener("message", onMessage, { signal: streamController.signal });
				agent.addEventListener("close", onClose, { signal: streamController.signal });
				retryResumeProbe();
			},
			cancel() {
				if (requestId && transport.cancelOnClientAbort) {
					transport.sendCancelFrame(requestId);
					finish(() => {}, true);
				} else finish(() => {});
			}
		});
	}
	/**
	* Creates a ReadableStream that receives resumed stream chunks
	* and forwards them to useChat as UIMessageChunk objects.
	*/
	_createResumeStream(requestId) {
		const agent = this.agent;
		const activeIds = this.activeRequestIds;
		const chunkController = new AbortController();
		const abortError = /* @__PURE__ */ new Error("Aborted");
		abortError.name = "AbortError";
		let completed = false;
		let detachResumeStream = null;
		const finish = (action, keepId = false, clearServerTurn = true) => {
			if (completed) return;
			completed = true;
			if (clearServerTurn) this.clearActiveServerTurn(requestId);
			if (this._detachResumeStream === detachResumeStream) this._detachResumeStream = null;
			try {
				action();
			} catch {}
			if (!keepId) activeIds?.delete(requestId);
			chunkController.abort();
		};
		let streamController = null;
		let replayBatch = null;
		const cancelActiveRequest = () => {
			if (completed) return false;
			finish(() => streamController?.error(abortError), true);
			return true;
		};
		this.setActiveServerTurn(requestId, cancelActiveRequest);
		const transport = this;
		detachResumeStream = () => {
			if (completed) return false;
			finish(() => {
				replayBatch?.flush();
				streamController?.close();
			});
			return true;
		};
		this._detachResumeStream = detachResumeStream;
		return new ReadableStream({
			start(controller) {
				streamController = controller;
				const batch = new ReplayChunkBatch(controller);
				replayBatch = batch;
				const replayFilter = new ContinuationReplayFilter(transport.appliedChunks, requestId);
				const onMessage = (event) => {
					try {
						const data = JSON.parse(event.data);
						if (data.type !== "cf_agent_use_chat_response") return;
						if (data.id !== requestId) return;
						if (data.error) {
							transport.appliedChunks.forget(requestId);
							finish(() => failChatStream(batch, data.body || "Stream error"));
							return;
						}
						for (const frame of replayFilter.frames(data)) applyChatResponseFrame(batch, frame);
						if (data.done) {
							transport.appliedChunks.forget(requestId);
							finish(() => controller.close());
						}
					} catch {}
				};
				const onClose = () => {
					finish(() => interruptChatStream(controller, batch), false, false);
				};
				agent.addEventListener("message", onMessage, { signal: chunkController.signal });
				agent.addEventListener("close", onClose, { signal: chunkController.signal });
			},
			cancel() {
				if (transport.cancelOnClientAbort) {
					transport.sendCancelFrame(requestId);
					finish(() => {}, true);
				} else finish(() => {}, false, false);
			}
		});
	}
};
//#endregion
//#region node_modules/.pnpm/@ai-sdk+provider-utils@4.0.30_zod@4.6.7/node_modules/@ai-sdk/provider-utils/dist/index.mjs
var { btoa, atob } = globalThis;
var createIdGenerator = ({ prefix, size = 16, alphabet = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", separator = "-" } = {}) => {
	const generator = () => {
		const alphabetLength = alphabet.length;
		const chars = new Array(size);
		for (let i = 0; i < size; i++) chars[i] = alphabet[Math.random() * alphabetLength | 0];
		return chars.join("");
	};
	if (prefix == null) return generator;
	if (alphabet.includes(separator)) throw new InvalidArgumentError({
		argument: "separator",
		message: `The separator "${separator}" must not be part of the alphabet "${alphabet}".`
	});
	return () => `${prefix}${separator}${generator()}`;
};
var generateId = createIdGenerator();
function normalizeHeaders(headers) {
	if (headers == null) return {};
	const normalized = {};
	if (headers instanceof Headers) headers.forEach((value, key) => {
		normalized[key.toLowerCase()] = value;
	});
	else {
		if (!Array.isArray(headers)) headers = Object.entries(headers);
		for (const [key, value] of headers) if (value != null) normalized[key.toLowerCase()] = value;
	}
	return normalized;
}
var suspectProtoRx = /"(?:_|\\u005[Ff])(?:_|\\u005[Ff])(?:p|\\u0070)(?:r|\\u0072)(?:o|\\u006[Ff])(?:t|\\u0074)(?:o|\\u006[Ff])(?:_|\\u005[Ff])(?:_|\\u005[Ff])"\s*:/;
var suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
function _parse(text) {
	const obj = JSON.parse(text);
	if (obj === null || typeof obj !== "object") return obj;
	if (suspectProtoRx.test(text) === false && suspectConstructorRx.test(text) === false) return obj;
	return filter(obj);
}
function filter(obj) {
	let next = [obj];
	while (next.length) {
		const nodes = next;
		next = [];
		for (const node of nodes) {
			if (Object.prototype.hasOwnProperty.call(node, "__proto__")) throw new SyntaxError("Object contains forbidden prototype property");
			if (Object.prototype.hasOwnProperty.call(node, "constructor") && node.constructor !== null && typeof node.constructor === "object" && Object.prototype.hasOwnProperty.call(node.constructor, "prototype")) throw new SyntaxError("Object contains forbidden prototype property");
			for (const key in node) {
				const value = node[key];
				if (value && typeof value === "object") next.push(value);
			}
		}
	}
	return obj;
}
function secureJsonParse(text) {
	const { stackTraceLimit } = Error;
	try {
		Error.stackTraceLimit = 0;
	} catch (e) {
		return _parse(text);
	}
	try {
		return _parse(text);
	} finally {
		Error.stackTraceLimit = stackTraceLimit;
	}
}
function addAdditionalPropertiesToJsonSchema(jsonSchema2) {
	if (jsonSchema2.type === "object" || Array.isArray(jsonSchema2.type) && jsonSchema2.type.includes("object")) {
		jsonSchema2.additionalProperties = false;
		const { properties } = jsonSchema2;
		if (properties != null) for (const key of Object.keys(properties)) properties[key] = visit(properties[key]);
	}
	if (jsonSchema2.items != null) jsonSchema2.items = Array.isArray(jsonSchema2.items) ? jsonSchema2.items.map(visit) : visit(jsonSchema2.items);
	if (jsonSchema2.anyOf != null) jsonSchema2.anyOf = jsonSchema2.anyOf.map(visit);
	if (jsonSchema2.allOf != null) jsonSchema2.allOf = jsonSchema2.allOf.map(visit);
	if (jsonSchema2.oneOf != null) jsonSchema2.oneOf = jsonSchema2.oneOf.map(visit);
	const { definitions } = jsonSchema2;
	if (definitions != null) for (const key of Object.keys(definitions)) definitions[key] = visit(definitions[key]);
	return jsonSchema2;
}
function visit(def) {
	if (typeof def === "boolean") return def;
	return addAdditionalPropertiesToJsonSchema(def);
}
var ignoreOverride = /* @__PURE__ */ Symbol("Let zodToJsonSchema decide on which parser to use");
var defaultOptions = {
	name: void 0,
	$refStrategy: "root",
	basePath: ["#"],
	effectStrategy: "input",
	pipeStrategy: "all",
	dateStrategy: "format:date-time",
	mapStrategy: "entries",
	removeAdditionalStrategy: "passthrough",
	allowedAdditionalProperties: true,
	rejectedAdditionalProperties: false,
	definitionPath: "definitions",
	strictUnions: false,
	definitions: {},
	errorMessages: false,
	patternStrategy: "escape",
	applyRegexFlags: false,
	emailStrategy: "format:email",
	base64Strategy: "contentEncoding:base64",
	nameStrategy: "ref"
};
var getDefaultOptions = (options) => typeof options === "string" ? {
	...defaultOptions,
	name: options
} : {
	...defaultOptions,
	...options
};
function parseAnyDef() {
	return {};
}
function parseArrayDef(def, refs) {
	var _a2, _b2, _c;
	const res = { type: "array" };
	if (((_a2 = def.type) == null ? void 0 : _a2._def) && ((_c = (_b2 = def.type) == null ? void 0 : _b2._def) == null ? void 0 : _c.typeName) !== ZodFirstPartyTypeKind.ZodAny) res.items = parseDef(def.type._def, {
		...refs,
		currentPath: [...refs.currentPath, "items"]
	});
	if (def.minLength) res.minItems = def.minLength.value;
	if (def.maxLength) res.maxItems = def.maxLength.value;
	if (def.exactLength) {
		res.minItems = def.exactLength.value;
		res.maxItems = def.exactLength.value;
	}
	return res;
}
function parseBigintDef(def) {
	const res = {
		type: "integer",
		format: "int64"
	};
	if (!def.checks) return res;
	for (const check of def.checks) switch (check.kind) {
		case "min":
			if (check.inclusive) res.minimum = check.value;
			else res.exclusiveMinimum = check.value;
			break;
		case "max":
			if (check.inclusive) res.maximum = check.value;
			else res.exclusiveMaximum = check.value;
			break;
		case "multipleOf": res.multipleOf = check.value;
	}
	return res;
}
function parseBooleanDef() {
	return { type: "boolean" };
}
function parseBrandedDef(_def, refs) {
	return parseDef(_def.type._def, refs);
}
var parseCatchDef = (def, refs) => {
	return parseDef(def.innerType._def, refs);
};
function parseDateDef(def, refs, overrideDateStrategy) {
	const strategy = overrideDateStrategy != null ? overrideDateStrategy : refs.dateStrategy;
	if (Array.isArray(strategy)) return { anyOf: strategy.map((item, i) => parseDateDef(def, refs, item)) };
	switch (strategy) {
		case "string":
		case "format:date-time": return {
			type: "string",
			format: "date-time"
		};
		case "format:date": return {
			type: "string",
			format: "date"
		};
		case "integer": return integerDateParser(def);
	}
}
var integerDateParser = (def) => {
	const res = {
		type: "integer",
		format: "unix-time"
	};
	for (const check of def.checks) switch (check.kind) {
		case "min":
			res.minimum = check.value;
			break;
		case "max": res.maximum = check.value;
	}
	return res;
};
function parseDefaultDef(_def, refs) {
	return {
		...parseDef(_def.innerType._def, refs),
		default: _def.defaultValue()
	};
}
function parseEffectsDef(_def, refs) {
	return refs.effectStrategy === "input" ? parseDef(_def.schema._def, refs) : parseAnyDef();
}
function parseEnumDef(def) {
	return {
		type: "string",
		enum: Array.from(def.values)
	};
}
var isJsonSchema7AllOfType = (type) => {
	if ("type" in type && type.type === "string") return false;
	return "allOf" in type;
};
function parseIntersectionDef(def, refs) {
	const allOf = [parseDef(def.left._def, {
		...refs,
		currentPath: [
			...refs.currentPath,
			"allOf",
			"0"
		]
	}), parseDef(def.right._def, {
		...refs,
		currentPath: [
			...refs.currentPath,
			"allOf",
			"1"
		]
	})].filter((x) => !!x);
	const mergedAllOf = [];
	allOf.forEach((schema) => {
		if (isJsonSchema7AllOfType(schema)) mergedAllOf.push(...schema.allOf);
		else {
			let nestedSchema = schema;
			if ("additionalProperties" in schema && schema.additionalProperties === false) {
				const { additionalProperties, ...rest } = schema;
				nestedSchema = rest;
			}
			mergedAllOf.push(nestedSchema);
		}
	});
	return mergedAllOf.length ? { allOf: mergedAllOf } : void 0;
}
function parseLiteralDef(def) {
	const parsedType = typeof def.value;
	if (parsedType !== "bigint" && parsedType !== "number" && parsedType !== "boolean" && parsedType !== "string") return { type: Array.isArray(def.value) ? "array" : "object" };
	return {
		type: parsedType === "bigint" ? "integer" : parsedType,
		const: def.value
	};
}
var emojiRegex = void 0;
var zodPatterns = {
	/**
	* `c` was changed to `[cC]` to replicate /i flag
	*/
	cuid: /^[cC][^\s-]{8,}$/,
	cuid2: /^[0-9a-z]+$/,
	ulid: /^[0-9A-HJKMNP-TV-Z]{26}$/,
	/**
	* `a-z` was added to replicate /i flag
	*/
	email: /^(?!\.)(?!.*\.\.)([a-zA-Z0-9_'+\-\.]*)[a-zA-Z0-9_+-]@([a-zA-Z0-9][a-zA-Z0-9\-]*\.)+[a-zA-Z]{2,}$/,
	/**
	* Constructed a valid Unicode RegExp
	*
	* Lazily instantiate since this type of regex isn't supported
	* in all envs (e.g. React Native).
	*
	* See:
	* https://github.com/colinhacks/zod/issues/2433
	* Fix in Zod:
	* https://github.com/colinhacks/zod/commit/9340fd51e48576a75adc919bff65dbc4a5d4c99b
	*/
	emoji: () => {
		if (emojiRegex === void 0) emojiRegex = RegExp("^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$", "u");
		return emojiRegex;
	},
	/**
	* Unused
	*/
	uuid: /^[0-9a-fA-F]{8}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{4}\b-[0-9a-fA-F]{12}$/,
	/**
	* Unused
	*/
	ipv4: /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/,
	ipv4Cidr: /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/(3[0-2]|[12]?[0-9])$/,
	/**
	* Unused
	*/
	ipv6: /^(([a-f0-9]{1,4}:){7}|::([a-f0-9]{1,4}:){0,6}|([a-f0-9]{1,4}:){1}:([a-f0-9]{1,4}:){0,5}|([a-f0-9]{1,4}:){2}:([a-f0-9]{1,4}:){0,4}|([a-f0-9]{1,4}:){3}:([a-f0-9]{1,4}:){0,3}|([a-f0-9]{1,4}:){4}:([a-f0-9]{1,4}:){0,2}|([a-f0-9]{1,4}:){5}:([a-f0-9]{1,4}:){0,1})([a-f0-9]{1,4}|(((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2}))\.){3}((25[0-5])|(2[0-4][0-9])|(1[0-9]{2})|([0-9]{1,2})))$/,
	ipv6Cidr: /^(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/,
	base64: /^([0-9a-zA-Z+/]{4})*(([0-9a-zA-Z+/]{2}==)|([0-9a-zA-Z+/]{3}=))?$/,
	base64url: /^([0-9a-zA-Z-_]{4})*(([0-9a-zA-Z-_]{2}(==)?)|([0-9a-zA-Z-_]{3}(=)?))?$/,
	nanoid: /^[a-zA-Z0-9_-]{21}$/,
	jwt: /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]*$/
};
function parseStringDef(def, refs) {
	const res = { type: "string" };
	if (def.checks) for (const check of def.checks) switch (check.kind) {
		case "min":
			res.minLength = typeof res.minLength === "number" ? Math.max(res.minLength, check.value) : check.value;
			break;
		case "max":
			res.maxLength = typeof res.maxLength === "number" ? Math.min(res.maxLength, check.value) : check.value;
			break;
		case "email":
			switch (refs.emailStrategy) {
				case "format:email":
					addFormat(res, "email", check.message, refs);
					break;
				case "format:idn-email":
					addFormat(res, "idn-email", check.message, refs);
					break;
				case "pattern:zod": addPattern(res, zodPatterns.email, check.message, refs);
			}
			break;
		case "url":
			addFormat(res, "uri", check.message, refs);
			break;
		case "uuid":
			addFormat(res, "uuid", check.message, refs);
			break;
		case "regex":
			addPattern(res, check.regex, check.message, refs);
			break;
		case "cuid":
			addPattern(res, zodPatterns.cuid, check.message, refs);
			break;
		case "cuid2":
			addPattern(res, zodPatterns.cuid2, check.message, refs);
			break;
		case "startsWith":
			addPattern(res, RegExp(`^${escapeLiteralCheckValue(check.value, refs)}`), check.message, refs);
			break;
		case "endsWith":
			addPattern(res, RegExp(`${escapeLiteralCheckValue(check.value, refs)}$`), check.message, refs);
			break;
		case "datetime":
			addFormat(res, "date-time", check.message, refs);
			break;
		case "date":
			addFormat(res, "date", check.message, refs);
			break;
		case "time":
			addFormat(res, "time", check.message, refs);
			break;
		case "duration":
			addFormat(res, "duration", check.message, refs);
			break;
		case "length":
			res.minLength = typeof res.minLength === "number" ? Math.max(res.minLength, check.value) : check.value;
			res.maxLength = typeof res.maxLength === "number" ? Math.min(res.maxLength, check.value) : check.value;
			break;
		case "includes":
			addPattern(res, RegExp(escapeLiteralCheckValue(check.value, refs)), check.message, refs);
			break;
		case "ip":
			if (check.version !== "v6") addFormat(res, "ipv4", check.message, refs);
			if (check.version !== "v4") addFormat(res, "ipv6", check.message, refs);
			break;
		case "base64url":
			addPattern(res, zodPatterns.base64url, check.message, refs);
			break;
		case "jwt":
			addPattern(res, zodPatterns.jwt, check.message, refs);
			break;
		case "cidr":
			if (check.version !== "v6") addPattern(res, zodPatterns.ipv4Cidr, check.message, refs);
			if (check.version !== "v4") addPattern(res, zodPatterns.ipv6Cidr, check.message, refs);
			break;
		case "emoji":
			addPattern(res, zodPatterns.emoji(), check.message, refs);
			break;
		case "ulid":
			addPattern(res, zodPatterns.ulid, check.message, refs);
			break;
		case "base64":
			switch (refs.base64Strategy) {
				case "format:binary":
					addFormat(res, "binary", check.message, refs);
					break;
				case "contentEncoding:base64":
					res.contentEncoding = "base64";
					break;
				case "pattern:zod": addPattern(res, zodPatterns.base64, check.message, refs);
			}
			break;
		case "nanoid": addPattern(res, zodPatterns.nanoid, check.message, refs);
	}
	return res;
}
function escapeLiteralCheckValue(literal, refs) {
	return refs.patternStrategy === "escape" ? escapeNonAlphaNumeric(literal) : literal;
}
var ALPHA_NUMERIC = /* @__PURE__ */ new Set("ABCDEFGHIJKLMNOPQRSTUVXYZabcdefghijklmnopqrstuvxyz0123456789");
function escapeNonAlphaNumeric(source) {
	let result = "";
	for (let i = 0; i < source.length; i++) {
		if (!ALPHA_NUMERIC.has(source[i])) result += "\\";
		result += source[i];
	}
	return result;
}
function addFormat(schema, value, message, refs) {
	var _a2;
	if (schema.format || ((_a2 = schema.anyOf) == null ? void 0 : _a2.some((x) => x.format))) {
		if (!schema.anyOf) schema.anyOf = [];
		if (schema.format) {
			schema.anyOf.push({ format: schema.format });
			delete schema.format;
		}
		schema.anyOf.push({
			format: value,
			...message && refs.errorMessages && { errorMessage: { format: message } }
		});
	} else schema.format = value;
}
function addPattern(schema, regex, message, refs) {
	var _a2;
	if (schema.pattern || ((_a2 = schema.allOf) == null ? void 0 : _a2.some((x) => x.pattern))) {
		if (!schema.allOf) schema.allOf = [];
		if (schema.pattern) {
			schema.allOf.push({ pattern: schema.pattern });
			delete schema.pattern;
		}
		schema.allOf.push({
			pattern: stringifyRegExpWithFlags(regex, refs),
			...message && refs.errorMessages && { errorMessage: { pattern: message } }
		});
	} else schema.pattern = stringifyRegExpWithFlags(regex, refs);
}
function stringifyRegExpWithFlags(regex, refs) {
	var _a2;
	if (!refs.applyRegexFlags || !regex.flags) return regex.source;
	const flags = {
		i: regex.flags.includes("i"),
		m: regex.flags.includes("m"),
		s: regex.flags.includes("s")
	};
	const source = flags.i ? regex.source.toLowerCase() : regex.source;
	let pattern = "";
	let isEscaped = false;
	let inCharGroup = false;
	let inCharRange = false;
	for (let i = 0; i < source.length; i++) {
		if (isEscaped) {
			pattern += source[i];
			isEscaped = false;
			continue;
		}
		if (flags.i) {
			if (inCharGroup) {
				if (source[i].match(/[a-z]/)) {
					if (inCharRange) {
						pattern += source[i];
						pattern += `${source[i - 2]}-${source[i]}`.toUpperCase();
						inCharRange = false;
					} else if (source[i + 1] === "-" && ((_a2 = source[i + 2]) == null ? void 0 : _a2.match(/[a-z]/))) {
						pattern += source[i];
						inCharRange = true;
					} else pattern += `${source[i]}${source[i].toUpperCase()}`;
					continue;
				}
			} else if (source[i].match(/[a-z]/)) {
				pattern += `[${source[i]}${source[i].toUpperCase()}]`;
				continue;
			}
		}
		if (flags.m) {
			if (source[i] === "^") {
				pattern += `(^|(?<=[\r
]))`;
				continue;
			} else if (source[i] === "$") {
				pattern += `($|(?=[\r
]))`;
				continue;
			}
		}
		if (flags.s && source[i] === ".") {
			pattern += inCharGroup ? `${source[i]}\r
` : `[${source[i]}\r
]`;
			continue;
		}
		pattern += source[i];
		if (source[i] === "\\") isEscaped = true;
		else if (inCharGroup && source[i] === "]") inCharGroup = false;
		else if (!inCharGroup && source[i] === "[") inCharGroup = true;
	}
	try {
		new RegExp(pattern);
	} catch (e) {
		console.warn(`Could not convert regex pattern at ${refs.currentPath.join("/")} to a flag-independent form! Falling back to the flag-ignorant source`);
		return regex.source;
	}
	return pattern;
}
function parseRecordDef(def, refs) {
	var _a2, _b2, _c, _d, _e, _f;
	const schema = {
		type: "object",
		additionalProperties: (_a2 = parseDef(def.valueType._def, {
			...refs,
			currentPath: [...refs.currentPath, "additionalProperties"]
		})) != null ? _a2 : refs.allowedAdditionalProperties
	};
	if (((_b2 = def.keyType) == null ? void 0 : _b2._def.typeName) === ZodFirstPartyTypeKind.ZodString && ((_c = def.keyType._def.checks) == null ? void 0 : _c.length)) {
		const { type, ...keyType } = parseStringDef(def.keyType._def, refs);
		return {
			...schema,
			propertyNames: keyType
		};
	} else if (((_d = def.keyType) == null ? void 0 : _d._def.typeName) === ZodFirstPartyTypeKind.ZodEnum) return {
		...schema,
		propertyNames: { enum: def.keyType._def.values }
	};
	else if (((_e = def.keyType) == null ? void 0 : _e._def.typeName) === ZodFirstPartyTypeKind.ZodBranded && def.keyType._def.type._def.typeName === ZodFirstPartyTypeKind.ZodString && ((_f = def.keyType._def.type._def.checks) == null ? void 0 : _f.length)) {
		const { type, ...keyType } = parseBrandedDef(def.keyType._def, refs);
		return {
			...schema,
			propertyNames: keyType
		};
	}
	return schema;
}
function parseMapDef(def, refs) {
	if (refs.mapStrategy === "record") return parseRecordDef(def, refs);
	return {
		type: "array",
		maxItems: 125,
		items: {
			type: "array",
			items: [parseDef(def.keyType._def, {
				...refs,
				currentPath: [
					...refs.currentPath,
					"items",
					"items",
					"0"
				]
			}) || parseAnyDef(), parseDef(def.valueType._def, {
				...refs,
				currentPath: [
					...refs.currentPath,
					"items",
					"items",
					"1"
				]
			}) || parseAnyDef()],
			minItems: 2,
			maxItems: 2
		}
	};
}
function parseNativeEnumDef(def) {
	const object = def.values;
	const actualValues = Object.keys(def.values).filter((key) => {
		return typeof object[object[key]] !== "number";
	}).map((key) => object[key]);
	const parsedTypes = Array.from(new Set(actualValues.map((values) => typeof values)));
	return {
		type: parsedTypes.length === 1 ? parsedTypes[0] === "string" ? "string" : "number" : ["string", "number"],
		enum: actualValues
	};
}
function parseNeverDef() {
	return { not: parseAnyDef() };
}
function parseNullDef() {
	return { type: "null" };
}
var primitiveMappings = {
	ZodString: "string",
	ZodNumber: "number",
	ZodBigInt: "integer",
	ZodBoolean: "boolean",
	ZodNull: "null"
};
function parseUnionDef(def, refs) {
	const options = def.options instanceof Map ? Array.from(def.options.values()) : def.options;
	if (options.every((x) => x._def.typeName in primitiveMappings && (!x._def.checks || !x._def.checks.length))) {
		const types = options.reduce((types2, x) => {
			const type = primitiveMappings[x._def.typeName];
			return type && !types2.includes(type) ? [...types2, type] : types2;
		}, []);
		return { type: types.length > 1 ? types : types[0] };
	} else if (options.every((x) => x._def.typeName === "ZodLiteral" && !x.description)) {
		const types = options.reduce((acc, x) => {
			const type = typeof x._def.value;
			switch (type) {
				case "string":
				case "number":
				case "boolean": return [...acc, type];
				case "bigint": return [...acc, "integer"];
				case "object": if (x._def.value === null) return [...acc, "null"];
				default: return acc;
			}
		}, []);
		if (types.length === options.length) {
			const uniqueTypes = types.filter((x, i, a) => a.indexOf(x) === i);
			return {
				type: uniqueTypes.length > 1 ? uniqueTypes : uniqueTypes[0],
				enum: options.reduce((acc, x) => {
					return acc.includes(x._def.value) ? acc : [...acc, x._def.value];
				}, [])
			};
		}
	} else if (options.every((x) => x._def.typeName === "ZodEnum")) return {
		type: "string",
		enum: options.reduce((acc, x) => [...acc, ...x._def.values.filter((x2) => !acc.includes(x2))], [])
	};
	return asAnyOf(def, refs);
}
var asAnyOf = (def, refs) => {
	const anyOf = (def.options instanceof Map ? Array.from(def.options.values()) : def.options).map((x, i) => parseDef(x._def, {
		...refs,
		currentPath: [
			...refs.currentPath,
			"anyOf",
			`${i}`
		]
	})).filter((x) => !!x && (!refs.strictUnions || typeof x === "object" && Object.keys(x).length > 0));
	return anyOf.length ? { anyOf } : void 0;
};
function parseNullableDef(def, refs) {
	if ([
		"ZodString",
		"ZodNumber",
		"ZodBigInt",
		"ZodBoolean",
		"ZodNull"
	].includes(def.innerType._def.typeName) && (!def.innerType._def.checks || !def.innerType._def.checks.length)) return { type: [primitiveMappings[def.innerType._def.typeName], "null"] };
	const base = parseDef(def.innerType._def, {
		...refs,
		currentPath: [
			...refs.currentPath,
			"anyOf",
			"0"
		]
	});
	return base && { anyOf: [base, { type: "null" }] };
}
function parseNumberDef(def) {
	const res = { type: "number" };
	if (!def.checks) return res;
	for (const check of def.checks) switch (check.kind) {
		case "int":
			res.type = "integer";
			break;
		case "min":
			if (check.inclusive) res.minimum = check.value;
			else res.exclusiveMinimum = check.value;
			break;
		case "max":
			if (check.inclusive) res.maximum = check.value;
			else res.exclusiveMaximum = check.value;
			break;
		case "multipleOf": res.multipleOf = check.value;
	}
	return res;
}
function parseObjectDef(def, refs) {
	const result = {
		type: "object",
		properties: {}
	};
	const required = [];
	const shape = def.shape();
	for (const propName in shape) {
		let propDef = shape[propName];
		if (propDef === void 0 || propDef._def === void 0) continue;
		const propOptional = safeIsOptional(propDef);
		const parsedDef = parseDef(propDef._def, {
			...refs,
			currentPath: [
				...refs.currentPath,
				"properties",
				propName
			],
			propertyPath: [
				...refs.currentPath,
				"properties",
				propName
			]
		});
		if (parsedDef === void 0) continue;
		result.properties[propName] = parsedDef;
		if (!propOptional) required.push(propName);
	}
	if (required.length) result.required = required;
	const additionalProperties = decideAdditionalProperties(def, refs);
	if (additionalProperties !== void 0) result.additionalProperties = additionalProperties;
	return result;
}
function decideAdditionalProperties(def, refs) {
	if (def.catchall._def.typeName !== "ZodNever") return parseDef(def.catchall._def, {
		...refs,
		currentPath: [...refs.currentPath, "additionalProperties"]
	});
	switch (def.unknownKeys) {
		case "passthrough": return refs.allowedAdditionalProperties;
		case "strict": return refs.rejectedAdditionalProperties;
		case "strip": return refs.removeAdditionalStrategy === "strict" ? refs.allowedAdditionalProperties : refs.rejectedAdditionalProperties;
	}
}
function safeIsOptional(schema) {
	try {
		return schema.isOptional();
	} catch (e) {
		return true;
	}
}
var parseOptionalDef = (def, refs) => {
	var _a2;
	if (refs.currentPath.toString() === ((_a2 = refs.propertyPath) == null ? void 0 : _a2.toString())) return parseDef(def.innerType._def, refs);
	const innerSchema = parseDef(def.innerType._def, {
		...refs,
		currentPath: [
			...refs.currentPath,
			"anyOf",
			"1"
		]
	});
	return innerSchema ? { anyOf: [{ not: parseAnyDef() }, innerSchema] } : parseAnyDef();
};
var parsePipelineDef = (def, refs) => {
	if (refs.pipeStrategy === "input") return parseDef(def.in._def, refs);
	else if (refs.pipeStrategy === "output") return parseDef(def.out._def, refs);
	const a = parseDef(def.in._def, {
		...refs,
		currentPath: [
			...refs.currentPath,
			"allOf",
			"0"
		]
	});
	return { allOf: [a, parseDef(def.out._def, {
		...refs,
		currentPath: [
			...refs.currentPath,
			"allOf",
			a ? "1" : "0"
		]
	})].filter((x) => x !== void 0) };
};
function parsePromiseDef(def, refs) {
	return parseDef(def.type._def, refs);
}
function parseSetDef(def, refs) {
	const schema = {
		type: "array",
		uniqueItems: true,
		items: parseDef(def.valueType._def, {
			...refs,
			currentPath: [...refs.currentPath, "items"]
		})
	};
	if (def.minSize) schema.minItems = def.minSize.value;
	if (def.maxSize) schema.maxItems = def.maxSize.value;
	return schema;
}
function parseTupleDef(def, refs) {
	if (def.rest) return {
		type: "array",
		minItems: def.items.length,
		items: def.items.map((x, i) => parseDef(x._def, {
			...refs,
			currentPath: [
				...refs.currentPath,
				"items",
				`${i}`
			]
		})).reduce((acc, x) => x === void 0 ? acc : [...acc, x], []),
		additionalItems: parseDef(def.rest._def, {
			...refs,
			currentPath: [...refs.currentPath, "additionalItems"]
		})
	};
	else return {
		type: "array",
		minItems: def.items.length,
		maxItems: def.items.length,
		items: def.items.map((x, i) => parseDef(x._def, {
			...refs,
			currentPath: [
				...refs.currentPath,
				"items",
				`${i}`
			]
		})).reduce((acc, x) => x === void 0 ? acc : [...acc, x], [])
	};
}
function parseUndefinedDef() {
	return { not: parseAnyDef() };
}
function parseUnknownDef() {
	return parseAnyDef();
}
var parseReadonlyDef = (def, refs) => {
	return parseDef(def.innerType._def, refs);
};
var selectParser = (def, typeName, refs) => {
	switch (typeName) {
		case ZodFirstPartyTypeKind.ZodString: return parseStringDef(def, refs);
		case ZodFirstPartyTypeKind.ZodNumber: return parseNumberDef(def);
		case ZodFirstPartyTypeKind.ZodObject: return parseObjectDef(def, refs);
		case ZodFirstPartyTypeKind.ZodBigInt: return parseBigintDef(def);
		case ZodFirstPartyTypeKind.ZodBoolean: return parseBooleanDef();
		case ZodFirstPartyTypeKind.ZodDate: return parseDateDef(def, refs);
		case ZodFirstPartyTypeKind.ZodUndefined: return parseUndefinedDef();
		case ZodFirstPartyTypeKind.ZodNull: return parseNullDef();
		case ZodFirstPartyTypeKind.ZodArray: return parseArrayDef(def, refs);
		case ZodFirstPartyTypeKind.ZodUnion:
		case ZodFirstPartyTypeKind.ZodDiscriminatedUnion: return parseUnionDef(def, refs);
		case ZodFirstPartyTypeKind.ZodIntersection: return parseIntersectionDef(def, refs);
		case ZodFirstPartyTypeKind.ZodTuple: return parseTupleDef(def, refs);
		case ZodFirstPartyTypeKind.ZodRecord: return parseRecordDef(def, refs);
		case ZodFirstPartyTypeKind.ZodLiteral: return parseLiteralDef(def);
		case ZodFirstPartyTypeKind.ZodEnum: return parseEnumDef(def);
		case ZodFirstPartyTypeKind.ZodNativeEnum: return parseNativeEnumDef(def);
		case ZodFirstPartyTypeKind.ZodNullable: return parseNullableDef(def, refs);
		case ZodFirstPartyTypeKind.ZodOptional: return parseOptionalDef(def, refs);
		case ZodFirstPartyTypeKind.ZodMap: return parseMapDef(def, refs);
		case ZodFirstPartyTypeKind.ZodSet: return parseSetDef(def, refs);
		case ZodFirstPartyTypeKind.ZodLazy: return () => def.getter()._def;
		case ZodFirstPartyTypeKind.ZodPromise: return parsePromiseDef(def, refs);
		case ZodFirstPartyTypeKind.ZodNaN:
		case ZodFirstPartyTypeKind.ZodNever: return parseNeverDef();
		case ZodFirstPartyTypeKind.ZodEffects: return parseEffectsDef(def, refs);
		case ZodFirstPartyTypeKind.ZodAny: return parseAnyDef();
		case ZodFirstPartyTypeKind.ZodUnknown: return parseUnknownDef();
		case ZodFirstPartyTypeKind.ZodDefault: return parseDefaultDef(def, refs);
		case ZodFirstPartyTypeKind.ZodBranded: return parseBrandedDef(def, refs);
		case ZodFirstPartyTypeKind.ZodReadonly: return parseReadonlyDef(def, refs);
		case ZodFirstPartyTypeKind.ZodCatch: return parseCatchDef(def, refs);
		case ZodFirstPartyTypeKind.ZodPipeline: return parsePipelineDef(def, refs);
		case ZodFirstPartyTypeKind.ZodFunction:
		case ZodFirstPartyTypeKind.ZodVoid:
		case ZodFirstPartyTypeKind.ZodSymbol: return;
		default: return /* @__PURE__ */ ((_) => void 0)(typeName);
	}
};
var getRelativePath = (pathA, pathB) => {
	let i = 0;
	for (; i < pathA.length && i < pathB.length; i++) if (pathA[i] !== pathB[i]) break;
	return [(pathA.length - i).toString(), ...pathB.slice(i)].join("/");
};
function parseDef(def, refs, forceResolution = false) {
	var _a2;
	const seenItem = refs.seen.get(def);
	if (refs.override) {
		const overrideResult = (_a2 = refs.override) == null ? void 0 : _a2.call(refs, def, refs, seenItem, forceResolution);
		if (overrideResult !== ignoreOverride) return overrideResult;
	}
	if (seenItem && !forceResolution) {
		const seenSchema = get$ref(seenItem, refs);
		if (seenSchema !== void 0) return seenSchema;
	}
	const newItem = {
		def,
		path: refs.currentPath,
		jsonSchema: void 0
	};
	refs.seen.set(def, newItem);
	const jsonSchemaOrGetter = selectParser(def, def.typeName, refs);
	const jsonSchema2 = typeof jsonSchemaOrGetter === "function" ? parseDef(jsonSchemaOrGetter(), refs) : jsonSchemaOrGetter;
	if (jsonSchema2) addMeta(def, refs, jsonSchema2);
	if (refs.postProcess) {
		const postProcessResult = refs.postProcess(jsonSchema2, def, refs);
		newItem.jsonSchema = jsonSchema2;
		return postProcessResult;
	}
	newItem.jsonSchema = jsonSchema2;
	return jsonSchema2;
}
var get$ref = (item, refs) => {
	switch (refs.$refStrategy) {
		case "root": return { $ref: item.path.join("/") };
		case "relative": return { $ref: getRelativePath(refs.currentPath, item.path) };
		case "none":
		case "seen":
			if (item.path.length < refs.currentPath.length && item.path.every((value, index) => refs.currentPath[index] === value)) {
				console.warn(`Recursive reference detected at ${refs.currentPath.join("/")}! Defaulting to any`);
				return parseAnyDef();
			}
			return refs.$refStrategy === "seen" ? parseAnyDef() : void 0;
	}
};
var addMeta = (def, refs, jsonSchema2) => {
	if (def.description) jsonSchema2.description = def.description;
	return jsonSchema2;
};
var getRefs = (options) => {
	const _options = getDefaultOptions(options);
	const currentPath = _options.name !== void 0 ? [
		..._options.basePath,
		_options.definitionPath,
		_options.name
	] : _options.basePath;
	return {
		..._options,
		currentPath,
		propertyPath: void 0,
		seen: new Map(Object.entries(_options.definitions).map(([name2, def]) => [def._def, {
			def: def._def,
			path: [
				..._options.basePath,
				_options.definitionPath,
				name2
			],
			jsonSchema: void 0
		}]))
	};
};
var zod3ToJsonSchema = (schema, options) => {
	var _a2;
	const refs = getRefs(options);
	let definitions = typeof options === "object" && options.definitions ? Object.entries(options.definitions).reduce((acc, [name3, schema2]) => {
		var _a3;
		return {
			...acc,
			[name3]: (_a3 = parseDef(schema2._def, {
				...refs,
				currentPath: [
					...refs.basePath,
					refs.definitionPath,
					name3
				]
			}, true)) != null ? _a3 : parseAnyDef()
		};
	}, {}) : void 0;
	const name2 = typeof options === "string" ? options : (options == null ? void 0 : options.nameStrategy) === "title" ? void 0 : options == null ? void 0 : options.name;
	const main = (_a2 = parseDef(schema._def, name2 === void 0 ? refs : {
		...refs,
		currentPath: [
			...refs.basePath,
			refs.definitionPath,
			name2
		]
	}, false)) != null ? _a2 : parseAnyDef();
	const title = typeof options === "object" && options.name !== void 0 && options.nameStrategy === "title" ? options.name : void 0;
	if (title !== void 0) main.title = title;
	const combined = name2 === void 0 ? definitions ? {
		...main,
		[refs.definitionPath]: definitions
	} : main : {
		$ref: [
			...refs.$refStrategy === "relative" ? [] : refs.basePath,
			refs.definitionPath,
			name2
		].join("/"),
		[refs.definitionPath]: {
			...definitions,
			[name2]: main
		}
	};
	combined.$schema = "http://json-schema.org/draft-07/schema#";
	return combined;
};
var schemaSymbol = /* @__PURE__ */ Symbol.for("vercel.ai.schema");
function lazySchema(createSchema) {
	let schema;
	return () => {
		if (schema == null) schema = createSchema();
		return schema;
	};
}
function jsonSchema(jsonSchema2, { validate } = {}) {
	return {
		[schemaSymbol]: true,
		_type: void 0,
		get jsonSchema() {
			if (typeof jsonSchema2 === "function") jsonSchema2 = jsonSchema2();
			return jsonSchema2;
		},
		validate
	};
}
function isSchema(value) {
	return typeof value === "object" && value !== null && schemaSymbol in value && value[schemaSymbol] === true && "jsonSchema" in value && "validate" in value;
}
function asSchema(schema) {
	return schema == null ? jsonSchema({
		properties: {},
		additionalProperties: false
	}) : isSchema(schema) ? schema : "~standard" in schema ? schema["~standard"].vendor === "zod" ? zodSchema(schema) : standardSchema(schema) : schema();
}
function standardSchema(standardSchema2) {
	return jsonSchema(() => addAdditionalPropertiesToJsonSchema(standardSchema2["~standard"].jsonSchema.input({ target: "draft-07" })), { validate: async (value) => {
		const result = await standardSchema2["~standard"].validate(value);
		return "value" in result ? {
			success: true,
			value: result.value
		} : {
			success: false,
			error: new TypeValidationError({
				value,
				cause: result.issues
			})
		};
	} });
}
function zod3Schema(zodSchema2, options) {
	var _a2;
	const useReferences = (_a2 = options == null ? void 0 : options.useReferences) != null ? _a2 : false;
	return jsonSchema(() => zod3ToJsonSchema(zodSchema2, { $refStrategy: useReferences ? "root" : "none" }), { validate: async (value) => {
		const result = await zodSchema2.safeParseAsync(value);
		return result.success ? {
			success: true,
			value: result.data
		} : {
			success: false,
			error: result.error
		};
	} });
}
function zod4Schema(zodSchema2, options) {
	var _a2;
	const useReferences = (_a2 = options == null ? void 0 : options.useReferences) != null ? _a2 : false;
	return jsonSchema(() => addAdditionalPropertiesToJsonSchema(toJSONSchema(zodSchema2, {
		target: "draft-7",
		io: "input",
		reused: useReferences ? "ref" : "inline"
	})), { validate: async (value) => {
		const result = await safeParseAsync(zodSchema2, value);
		return result.success ? {
			success: true,
			value: result.data
		} : {
			success: false,
			error: result.error
		};
	} });
}
function isZod4Schema(zodSchema2) {
	return "_zod" in zodSchema2;
}
function zodSchema(zodSchema2, options) {
	if (isZod4Schema(zodSchema2)) return zod4Schema(zodSchema2, options);
	else return zod3Schema(zodSchema2, options);
}
async function validateTypes({ value, schema, context }) {
	const result = await safeValidateTypes({
		value,
		schema,
		context
	});
	if (!result.success) throw TypeValidationError.wrap({
		value,
		cause: result.error,
		context
	});
	return result.value;
}
async function safeValidateTypes({ value, schema, context }) {
	const actualSchema = asSchema(schema);
	try {
		if (actualSchema.validate == null) return {
			success: true,
			value,
			rawValue: value
		};
		const result = await actualSchema.validate(value);
		if (result.success) return {
			success: true,
			value: result.value,
			rawValue: value
		};
		return {
			success: false,
			error: TypeValidationError.wrap({
				value,
				cause: result.error,
				context
			}),
			rawValue: value
		};
	} catch (error) {
		return {
			success: false,
			error: TypeValidationError.wrap({
				value,
				cause: error,
				context
			}),
			rawValue: value
		};
	}
}
async function safeParseJSON({ text, schema }) {
	try {
		const value = secureJsonParse(text);
		if (schema == null) return {
			success: true,
			value,
			rawValue: value
		};
		return await safeValidateTypes({
			value,
			schema
		});
	} catch (error) {
		return {
			success: false,
			error: JSONParseError.isInstance(error) ? error : new JSONParseError({
				text,
				cause: error
			}),
			rawValue: void 0
		};
	}
}
function parseJsonEventStream({ stream, schema }) {
	return stream.pipeThrough(new TextDecoderStream()).pipeThrough(new EventSourceParserStream()).pipeThrough(new TransformStream({ async transform({ data }, controller) {
		if (data === "[DONE]") return;
		controller.enqueue(await safeParseJSON({
			text: data,
			schema
		}));
	} }));
}
async function resolve(value) {
	if (typeof value === "function") value = value();
	return Promise.resolve(value);
}
//#endregion
//#region node_modules/.pnpm/ai@6.0.209_zod@4.6.7/node_modules/ai/dist/index.mjs
var __defProp = Object.defineProperty;
var __export = (target, all) => {
	for (var name22 in all) __defProp(target, name22, {
		get: all[name22],
		enumerable: true
	});
};
var name9 = "AI_NoObjectGeneratedError";
var marker9 = `vercel.ai.error.${name9}`;
var symbol9 = Symbol.for(marker9);
var _a9;
var NoObjectGeneratedError = class extends AISDKError {
	constructor({ message = "No object generated.", cause, text: text2, response, usage, finishReason }) {
		super({
			name: name9,
			message,
			cause
		});
		this[_a9] = true;
		this.text = text2;
		this.response = response;
		this.usage = usage;
		this.finishReason = finishReason;
	}
	static isInstance(error) {
		return AISDKError.hasMarker(error, marker9);
	}
};
_a9 = symbol9;
var name16 = "AI_UIMessageStreamError";
var marker16 = `vercel.ai.error.${name16}`;
var symbol16 = Symbol.for(marker16);
var _a16;
var UIMessageStreamError = class extends AISDKError {
	constructor({ chunkType, chunkId, message }) {
		super({
			name: name16,
			message
		});
		this[_a16] = true;
		this.chunkType = chunkType;
		this.chunkId = chunkId;
	}
	static isInstance(error) {
		return AISDKError.hasMarker(error, marker16);
	}
};
_a16 = symbol16;
var dataContentSchema = union([
	string(),
	_instanceof(Uint8Array),
	_instanceof(ArrayBuffer),
	custom((value) => {
		var _a22, _b;
		return (_b = (_a22 = globalThis.Buffer) == null ? void 0 : _a22.isBuffer(value)) != null ? _b : false;
	}, { message: "Must be a Buffer" })
]);
var jsonValueSchema = lazy(() => union([
	_null(),
	string(),
	number(),
	boolean(),
	record(string(), jsonValueSchema.optional()),
	array$1(jsonValueSchema)
]));
var providerMetadataSchema = record(string(), record(string(), jsonValueSchema.optional()));
var textPartSchema = object$1({
	type: literal("text"),
	text: string(),
	providerOptions: providerMetadataSchema.optional()
});
var imagePartSchema = object$1({
	type: literal("image"),
	image: union([dataContentSchema, _instanceof(URL)]),
	mediaType: string().optional(),
	providerOptions: providerMetadataSchema.optional()
});
var filePartSchema = object$1({
	type: literal("file"),
	data: union([dataContentSchema, _instanceof(URL)]),
	filename: string().optional(),
	mediaType: string(),
	providerOptions: providerMetadataSchema.optional()
});
var reasoningPartSchema = object$1({
	type: literal("reasoning"),
	text: string(),
	providerOptions: providerMetadataSchema.optional()
});
var toolCallPartSchema = object$1({
	type: literal("tool-call"),
	toolCallId: string(),
	toolName: string(),
	input: unknown(),
	providerOptions: providerMetadataSchema.optional(),
	providerExecuted: boolean().optional()
});
var outputSchema = discriminatedUnion("type", [
	object$1({
		type: literal("text"),
		value: string(),
		providerOptions: providerMetadataSchema.optional()
	}),
	object$1({
		type: literal("json"),
		value: jsonValueSchema,
		providerOptions: providerMetadataSchema.optional()
	}),
	object$1({
		type: literal("execution-denied"),
		reason: string().optional(),
		providerOptions: providerMetadataSchema.optional()
	}),
	object$1({
		type: literal("error-text"),
		value: string(),
		providerOptions: providerMetadataSchema.optional()
	}),
	object$1({
		type: literal("error-json"),
		value: jsonValueSchema,
		providerOptions: providerMetadataSchema.optional()
	}),
	object$1({
		type: literal("content"),
		value: array$1(union([
			object$1({
				type: literal("text"),
				text: string(),
				providerOptions: providerMetadataSchema.optional()
			}),
			object$1({
				type: literal("media"),
				data: string(),
				mediaType: string()
			}),
			object$1({
				type: literal("file-data"),
				data: string(),
				mediaType: string(),
				filename: string().optional(),
				providerOptions: providerMetadataSchema.optional()
			}),
			object$1({
				type: literal("file-url"),
				url: string(),
				providerOptions: providerMetadataSchema.optional()
			}),
			object$1({
				type: literal("file-id"),
				fileId: union([string(), record(string(), string())]),
				providerOptions: providerMetadataSchema.optional()
			}),
			object$1({
				type: literal("image-data"),
				data: string(),
				mediaType: string(),
				providerOptions: providerMetadataSchema.optional()
			}),
			object$1({
				type: literal("image-url"),
				url: string(),
				providerOptions: providerMetadataSchema.optional()
			}),
			object$1({
				type: literal("image-file-id"),
				fileId: union([string(), record(string(), string())]),
				providerOptions: providerMetadataSchema.optional()
			}),
			object$1({
				type: literal("custom"),
				providerOptions: providerMetadataSchema.optional()
			})
		]))
	})
]);
var toolResultPartSchema = object$1({
	type: literal("tool-result"),
	toolCallId: string(),
	toolName: string(),
	output: outputSchema,
	providerOptions: providerMetadataSchema.optional()
});
var toolApprovalRequestSchema = object$1({
	type: literal("tool-approval-request"),
	approvalId: string(),
	toolCallId: string()
});
var toolApprovalResponseSchema = object$1({
	type: literal("tool-approval-response"),
	approvalId: string(),
	approved: boolean(),
	reason: string().optional()
});
var systemModelMessageSchema = object$1({
	role: literal("system"),
	content: string(),
	providerOptions: providerMetadataSchema.optional()
});
var userModelMessageSchema = object$1({
	role: literal("user"),
	content: union([string(), array$1(union([
		textPartSchema,
		imagePartSchema,
		filePartSchema
	]))]),
	providerOptions: providerMetadataSchema.optional()
});
var assistantModelMessageSchema = object$1({
	role: literal("assistant"),
	content: union([string(), array$1(union([
		textPartSchema,
		filePartSchema,
		reasoningPartSchema,
		toolCallPartSchema,
		toolResultPartSchema,
		toolApprovalRequestSchema
	]))]),
	providerOptions: providerMetadataSchema.optional()
});
var toolModelMessageSchema = object$1({
	role: literal("tool"),
	content: array$1(union([toolResultPartSchema, toolApprovalResponseSchema])),
	providerOptions: providerMetadataSchema.optional()
});
union([
	systemModelMessageSchema,
	userModelMessageSchema,
	assistantModelMessageSchema,
	toolModelMessageSchema
]);
function mergeObjects(base, overrides) {
	if (base === void 0 && overrides === void 0) return;
	if (base === void 0) return overrides;
	if (overrides === void 0) return base;
	const result = { ...base };
	for (const key in overrides) {
		if (key === "__proto__" || key === "constructor" || key === "prototype") continue;
		if (Object.prototype.hasOwnProperty.call(overrides, key)) {
			const overridesValue = overrides[key];
			if (overridesValue === void 0) continue;
			const baseValue = key in base ? base[key] : void 0;
			const isSourceObject = overridesValue !== null && typeof overridesValue === "object" && !Array.isArray(overridesValue) && !(overridesValue instanceof Date) && !(overridesValue instanceof RegExp);
			const isTargetObject = baseValue !== null && baseValue !== void 0 && typeof baseValue === "object" && !Array.isArray(baseValue) && !(baseValue instanceof Date) && !(baseValue instanceof RegExp);
			if (isSourceObject && isTargetObject) result[key] = mergeObjects(baseValue, overridesValue);
			else result[key] = overridesValue;
		}
	}
	return result;
}
new TextEncoder();
__export({}, {
	array: () => array,
	choice: () => choice,
	json: () => json,
	object: () => object,
	text: () => text
});
function fixJson(input) {
	const stack = ["ROOT"];
	let lastValidIndex = -1;
	let literalStart = null;
	let unicodeEscapeDigits = 0;
	function isHexDigit(char) {
		return char >= "0" && char <= "9" || char >= "A" && char <= "F" || char >= "a" && char <= "f";
	}
	function processValueStart(char, i, swapState) {
		switch (char) {
			case "\"":
				lastValidIndex = i;
				stack.pop();
				stack.push(swapState);
				stack.push("INSIDE_STRING");
				break;
			case "f":
			case "t":
			case "n":
				lastValidIndex = i;
				literalStart = i;
				stack.pop();
				stack.push(swapState);
				stack.push("INSIDE_LITERAL");
				break;
			case "-":
				stack.pop();
				stack.push(swapState);
				stack.push("INSIDE_NUMBER");
				break;
			case "0":
			case "1":
			case "2":
			case "3":
			case "4":
			case "5":
			case "6":
			case "7":
			case "8":
			case "9":
				lastValidIndex = i;
				stack.pop();
				stack.push(swapState);
				stack.push("INSIDE_NUMBER");
				break;
			case "{":
				lastValidIndex = i;
				stack.pop();
				stack.push(swapState);
				stack.push("INSIDE_OBJECT_START");
				break;
			case "[":
				lastValidIndex = i;
				stack.pop();
				stack.push(swapState);
				stack.push("INSIDE_ARRAY_START");
		}
	}
	function processAfterObjectValue(char, i) {
		switch (char) {
			case ",":
				stack.pop();
				stack.push("INSIDE_OBJECT_AFTER_COMMA");
				break;
			case "}":
				lastValidIndex = i;
				stack.pop();
		}
	}
	function processAfterArrayValue(char, i) {
		switch (char) {
			case ",":
				stack.pop();
				stack.push("INSIDE_ARRAY_AFTER_COMMA");
				break;
			case "]":
				lastValidIndex = i;
				stack.pop();
		}
	}
	for (let i = 0; i < input.length; i++) {
		const char = input[i];
		switch (stack[stack.length - 1]) {
			case "ROOT":
				processValueStart(char, i, "FINISH");
				break;
			case "INSIDE_OBJECT_START":
				switch (char) {
					case "\"":
						stack.pop();
						stack.push("INSIDE_OBJECT_KEY");
						break;
					case "}":
						lastValidIndex = i;
						stack.pop();
				}
				break;
			case "INSIDE_OBJECT_AFTER_COMMA":
				switch (char) {
					case "\"":
						stack.pop();
						stack.push("INSIDE_OBJECT_KEY");
				}
				break;
			case "INSIDE_OBJECT_KEY":
				switch (char) {
					case "\"":
						stack.pop();
						stack.push("INSIDE_OBJECT_AFTER_KEY");
				}
				break;
			case "INSIDE_OBJECT_AFTER_KEY":
				switch (char) {
					case ":":
						stack.pop();
						stack.push("INSIDE_OBJECT_BEFORE_VALUE");
				}
				break;
			case "INSIDE_OBJECT_BEFORE_VALUE":
				processValueStart(char, i, "INSIDE_OBJECT_AFTER_VALUE");
				break;
			case "INSIDE_OBJECT_AFTER_VALUE":
				processAfterObjectValue(char, i);
				break;
			case "INSIDE_STRING":
				switch (char) {
					case "\"":
						stack.pop();
						lastValidIndex = i;
						break;
					case "\\":
						stack.push("INSIDE_STRING_ESCAPE");
						break;
					default: lastValidIndex = i;
				}
				break;
			case "INSIDE_ARRAY_START":
				switch (char) {
					case "]":
						lastValidIndex = i;
						stack.pop();
						break;
					default:
						lastValidIndex = i;
						processValueStart(char, i, "INSIDE_ARRAY_AFTER_VALUE");
				}
				break;
			case "INSIDE_ARRAY_AFTER_VALUE":
				switch (char) {
					case ",":
						stack.pop();
						stack.push("INSIDE_ARRAY_AFTER_COMMA");
						break;
					case "]":
						lastValidIndex = i;
						stack.pop();
						break;
					default: lastValidIndex = i;
				}
				break;
			case "INSIDE_ARRAY_AFTER_COMMA":
				processValueStart(char, i, "INSIDE_ARRAY_AFTER_VALUE");
				break;
			case "INSIDE_STRING_ESCAPE":
				stack.pop();
				if (char === "u") {
					unicodeEscapeDigits = 0;
					stack.push("INSIDE_STRING_UNICODE_ESCAPE");
				} else lastValidIndex = i;
				break;
			case "INSIDE_STRING_UNICODE_ESCAPE":
				if (isHexDigit(char)) {
					unicodeEscapeDigits++;
					if (unicodeEscapeDigits === 4) {
						stack.pop();
						lastValidIndex = i;
					}
				}
				break;
			case "INSIDE_NUMBER":
				switch (char) {
					case "0":
					case "1":
					case "2":
					case "3":
					case "4":
					case "5":
					case "6":
					case "7":
					case "8":
					case "9":
						lastValidIndex = i;
						break;
					case "e":
					case "E":
					case "-":
					case ".": break;
					case ",":
						stack.pop();
						if (stack[stack.length - 1] === "INSIDE_ARRAY_AFTER_VALUE") processAfterArrayValue(char, i);
						if (stack[stack.length - 1] === "INSIDE_OBJECT_AFTER_VALUE") processAfterObjectValue(char, i);
						break;
					case "}":
						stack.pop();
						if (stack[stack.length - 1] === "INSIDE_OBJECT_AFTER_VALUE") processAfterObjectValue(char, i);
						break;
					case "]":
						stack.pop();
						if (stack[stack.length - 1] === "INSIDE_ARRAY_AFTER_VALUE") processAfterArrayValue(char, i);
						break;
					default: stack.pop();
				}
				break;
			case "INSIDE_LITERAL": {
				const partialLiteral = input.substring(literalStart, i + 1);
				if (!"false".startsWith(partialLiteral) && !"true".startsWith(partialLiteral) && !"null".startsWith(partialLiteral)) {
					stack.pop();
					if (stack[stack.length - 1] === "INSIDE_OBJECT_AFTER_VALUE") processAfterObjectValue(char, i);
					else if (stack[stack.length - 1] === "INSIDE_ARRAY_AFTER_VALUE") processAfterArrayValue(char, i);
				} else lastValidIndex = i;
				break;
			}
		}
	}
	let result = input.slice(0, lastValidIndex + 1);
	for (let i = stack.length - 1; i >= 0; i--) switch (stack[i]) {
		case "INSIDE_STRING":
			result += "\"";
			break;
		case "INSIDE_OBJECT_KEY":
		case "INSIDE_OBJECT_AFTER_KEY":
		case "INSIDE_OBJECT_AFTER_COMMA":
		case "INSIDE_OBJECT_START":
		case "INSIDE_OBJECT_BEFORE_VALUE":
		case "INSIDE_OBJECT_AFTER_VALUE":
			result += "}";
			break;
		case "INSIDE_ARRAY_START":
		case "INSIDE_ARRAY_AFTER_COMMA":
		case "INSIDE_ARRAY_AFTER_VALUE":
			result += "]";
			break;
		case "INSIDE_LITERAL": {
			const partialLiteral = input.substring(literalStart, input.length);
			if ("true".startsWith(partialLiteral)) result += "true".slice(partialLiteral.length);
			else if ("false".startsWith(partialLiteral)) result += "false".slice(partialLiteral.length);
			else if ("null".startsWith(partialLiteral)) result += "null".slice(partialLiteral.length);
		}
	}
	return result;
}
async function parsePartialJson(jsonText) {
	if (jsonText === void 0) return {
		value: void 0,
		state: "undefined-input"
	};
	let result = await safeParseJSON({ text: jsonText });
	if (result.success) return {
		value: result.value,
		state: "successful-parse"
	};
	result = await safeParseJSON({ text: fixJson(jsonText) });
	if (result.success) return {
		value: result.value,
		state: "repaired-parse"
	};
	return {
		value: void 0,
		state: "failed-parse"
	};
}
var text = () => ({
	name: "text",
	responseFormat: Promise.resolve({ type: "text" }),
	async parseCompleteOutput({ text: text2 }) {
		return text2;
	},
	async parsePartialOutput({ text: text2 }) {
		return { partial: text2 };
	},
	createElementStreamTransform() {}
});
var object = ({ schema: inputSchema, name: name22, description }) => {
	const schema = asSchema(inputSchema);
	return {
		name: "object",
		responseFormat: resolve(schema.jsonSchema).then((jsonSchema2) => ({
			type: "json",
			schema: jsonSchema2,
			...name22 != null && { name: name22 },
			...description != null && { description }
		})),
		async parseCompleteOutput({ text: text2 }, context2) {
			const parseResult = await safeParseJSON({ text: text2 });
			if (!parseResult.success) throw new NoObjectGeneratedError({
				message: "No object generated: could not parse the response.",
				cause: parseResult.error,
				text: text2,
				response: context2.response,
				usage: context2.usage,
				finishReason: context2.finishReason
			});
			const validationResult = await safeValidateTypes({
				value: parseResult.value,
				schema
			});
			if (!validationResult.success) throw new NoObjectGeneratedError({
				message: "No object generated: response did not match schema.",
				cause: validationResult.error,
				text: text2,
				response: context2.response,
				usage: context2.usage,
				finishReason: context2.finishReason
			});
			return validationResult.value;
		},
		async parsePartialOutput({ text: text2 }) {
			const result = await parsePartialJson(text2);
			switch (result.state) {
				case "failed-parse":
				case "undefined-input": return;
				case "repaired-parse":
				case "successful-parse": return { partial: result.value };
			}
		},
		createElementStreamTransform() {}
	};
};
var array = ({ element: inputElementSchema, name: name22, description }) => {
	const elementSchema = asSchema(inputElementSchema);
	return {
		name: "array",
		responseFormat: resolve(elementSchema.jsonSchema).then((jsonSchema2) => {
			const { $schema, ...itemSchema } = jsonSchema2;
			return {
				type: "json",
				schema: {
					$schema: "http://json-schema.org/draft-07/schema#",
					type: "object",
					properties: { elements: {
						type: "array",
						items: itemSchema
					} },
					required: ["elements"],
					additionalProperties: false
				},
				...name22 != null && { name: name22 },
				...description != null && { description }
			};
		}),
		async parseCompleteOutput({ text: text2 }, context2) {
			const parseResult = await safeParseJSON({ text: text2 });
			if (!parseResult.success) throw new NoObjectGeneratedError({
				message: "No object generated: could not parse the response.",
				cause: parseResult.error,
				text: text2,
				response: context2.response,
				usage: context2.usage,
				finishReason: context2.finishReason
			});
			const outerValue = parseResult.value;
			if (outerValue == null || typeof outerValue !== "object" || !("elements" in outerValue) || !Array.isArray(outerValue.elements)) throw new NoObjectGeneratedError({
				message: "No object generated: response did not match schema.",
				cause: new TypeValidationError({
					value: outerValue,
					cause: "response must be an object with an elements array"
				}),
				text: text2,
				response: context2.response,
				usage: context2.usage,
				finishReason: context2.finishReason
			});
			for (const element of outerValue.elements) {
				const validationResult = await safeValidateTypes({
					value: element,
					schema: elementSchema
				});
				if (!validationResult.success) throw new NoObjectGeneratedError({
					message: "No object generated: response did not match schema.",
					cause: validationResult.error,
					text: text2,
					response: context2.response,
					usage: context2.usage,
					finishReason: context2.finishReason
				});
			}
			return outerValue.elements;
		},
		async parsePartialOutput({ text: text2 }) {
			const result = await parsePartialJson(text2);
			switch (result.state) {
				case "failed-parse":
				case "undefined-input": return;
				case "repaired-parse":
				case "successful-parse": {
					const outerValue = result.value;
					if (outerValue == null || typeof outerValue !== "object" || !("elements" in outerValue) || !Array.isArray(outerValue.elements)) return;
					const rawElements = result.state === "repaired-parse" && outerValue.elements.length > 0 ? outerValue.elements.slice(0, -1) : outerValue.elements;
					const parsedElements = [];
					for (const rawElement of rawElements) {
						const validationResult = await safeValidateTypes({
							value: rawElement,
							schema: elementSchema
						});
						if (validationResult.success) parsedElements.push(validationResult.value);
					}
					return { partial: parsedElements };
				}
			}
		},
		createElementStreamTransform() {
			let publishedElements = 0;
			return new TransformStream({ transform({ partialOutput }, controller) {
				if (partialOutput != null) for (; publishedElements < partialOutput.length; publishedElements++) controller.enqueue(partialOutput[publishedElements]);
			} });
		}
	};
};
var choice = ({ options: choiceOptions, name: name22, description }) => {
	return {
		name: "choice",
		responseFormat: Promise.resolve({
			type: "json",
			schema: {
				$schema: "http://json-schema.org/draft-07/schema#",
				type: "object",
				properties: { result: {
					type: "string",
					enum: choiceOptions
				} },
				required: ["result"],
				additionalProperties: false
			},
			...name22 != null && { name: name22 },
			...description != null && { description }
		}),
		async parseCompleteOutput({ text: text2 }, context2) {
			const parseResult = await safeParseJSON({ text: text2 });
			if (!parseResult.success) throw new NoObjectGeneratedError({
				message: "No object generated: could not parse the response.",
				cause: parseResult.error,
				text: text2,
				response: context2.response,
				usage: context2.usage,
				finishReason: context2.finishReason
			});
			const outerValue = parseResult.value;
			if (outerValue == null || typeof outerValue !== "object" || !("result" in outerValue) || typeof outerValue.result !== "string" || !choiceOptions.includes(outerValue.result)) throw new NoObjectGeneratedError({
				message: "No object generated: response did not match schema.",
				cause: new TypeValidationError({
					value: outerValue,
					cause: "response must be an object that contains a choice value."
				}),
				text: text2,
				response: context2.response,
				usage: context2.usage,
				finishReason: context2.finishReason
			});
			return outerValue.result;
		},
		async parsePartialOutput({ text: text2 }) {
			const result = await parsePartialJson(text2);
			switch (result.state) {
				case "failed-parse":
				case "undefined-input": return;
				case "repaired-parse":
				case "successful-parse": {
					const outerValue = result.value;
					if (outerValue == null || typeof outerValue !== "object" || !("result" in outerValue) || typeof outerValue.result !== "string") return;
					const potentialMatches = choiceOptions.filter((choiceOption) => choiceOption.startsWith(outerValue.result));
					if (result.state === "successful-parse") return potentialMatches.includes(outerValue.result) ? { partial: outerValue.result } : void 0;
					else return potentialMatches.length === 1 ? { partial: potentialMatches[0] } : void 0;
				}
			}
		},
		createElementStreamTransform() {}
	};
};
var json = ({ name: name22, description } = {}) => {
	return {
		name: "json",
		responseFormat: Promise.resolve({
			type: "json",
			...name22 != null && { name: name22 },
			...description != null && { description }
		}),
		async parseCompleteOutput({ text: text2 }, context2) {
			const parseResult = await safeParseJSON({ text: text2 });
			if (!parseResult.success) throw new NoObjectGeneratedError({
				message: "No object generated: could not parse the response.",
				cause: parseResult.error,
				text: text2,
				response: context2.response,
				usage: context2.usage,
				finishReason: context2.finishReason
			});
			return parseResult.value;
		},
		async parsePartialOutput({ text: text2 }) {
			const result = await parsePartialJson(text2);
			switch (result.state) {
				case "failed-parse":
				case "undefined-input": return;
				case "repaired-parse":
				case "successful-parse": return result.value === void 0 ? void 0 : { partial: result.value };
			}
		},
		createElementStreamTransform() {}
	};
};
createIdGenerator({
	prefix: "aitxt",
	size: 24
});
TransformStream;
var toolMetadataSchema = record(string(), jsonValueSchema.optional());
var uiMessageChunkSchema = lazySchema(() => zodSchema(union([
	strictObject({
		type: literal("text-start"),
		id: string(),
		providerMetadata: providerMetadataSchema.optional()
	}),
	strictObject({
		type: literal("text-delta"),
		id: string(),
		delta: string(),
		providerMetadata: providerMetadataSchema.optional()
	}),
	strictObject({
		type: literal("text-end"),
		id: string(),
		providerMetadata: providerMetadataSchema.optional()
	}),
	strictObject({
		type: literal("error"),
		errorText: string()
	}),
	strictObject({
		type: literal("tool-input-start"),
		toolCallId: string(),
		toolName: string(),
		providerExecuted: boolean().optional(),
		providerMetadata: providerMetadataSchema.optional(),
		toolMetadata: toolMetadataSchema.optional(),
		dynamic: boolean().optional(),
		title: string().optional()
	}),
	strictObject({
		type: literal("tool-input-delta"),
		toolCallId: string(),
		inputTextDelta: string()
	}),
	strictObject({
		type: literal("tool-input-available"),
		toolCallId: string(),
		toolName: string(),
		input: unknown(),
		providerExecuted: boolean().optional(),
		providerMetadata: providerMetadataSchema.optional(),
		toolMetadata: toolMetadataSchema.optional(),
		dynamic: boolean().optional(),
		title: string().optional()
	}),
	strictObject({
		type: literal("tool-input-error"),
		toolCallId: string(),
		toolName: string(),
		input: unknown(),
		providerExecuted: boolean().optional(),
		providerMetadata: providerMetadataSchema.optional(),
		toolMetadata: toolMetadataSchema.optional(),
		dynamic: boolean().optional(),
		errorText: string(),
		title: string().optional()
	}),
	strictObject({
		type: literal("tool-approval-request"),
		approvalId: string(),
		toolCallId: string(),
		signature: string().optional()
	}),
	strictObject({
		type: literal("tool-output-available"),
		toolCallId: string(),
		output: unknown(),
		providerExecuted: boolean().optional(),
		providerMetadata: providerMetadataSchema.optional(),
		toolMetadata: toolMetadataSchema.optional(),
		dynamic: boolean().optional(),
		preliminary: boolean().optional()
	}),
	strictObject({
		type: literal("tool-output-error"),
		toolCallId: string(),
		errorText: string(),
		providerExecuted: boolean().optional(),
		providerMetadata: providerMetadataSchema.optional(),
		toolMetadata: toolMetadataSchema.optional(),
		dynamic: boolean().optional()
	}),
	strictObject({
		type: literal("tool-output-denied"),
		toolCallId: string()
	}),
	strictObject({
		type: literal("reasoning-start"),
		id: string(),
		providerMetadata: providerMetadataSchema.optional()
	}),
	strictObject({
		type: literal("reasoning-delta"),
		id: string(),
		delta: string(),
		providerMetadata: providerMetadataSchema.optional()
	}),
	strictObject({
		type: literal("reasoning-end"),
		id: string(),
		providerMetadata: providerMetadataSchema.optional()
	}),
	strictObject({
		type: literal("source-url"),
		sourceId: string(),
		url: string(),
		title: string().optional(),
		providerMetadata: providerMetadataSchema.optional()
	}),
	strictObject({
		type: literal("source-document"),
		sourceId: string(),
		mediaType: string(),
		title: string(),
		filename: string().optional(),
		providerMetadata: providerMetadataSchema.optional()
	}),
	strictObject({
		type: literal("file"),
		url: string(),
		mediaType: string(),
		providerMetadata: providerMetadataSchema.optional()
	}),
	strictObject({
		type: custom((value) => typeof value === "string" && value.startsWith("data-"), { message: "Type must start with \"data-\"" }),
		id: string().optional(),
		data: unknown(),
		transient: boolean().optional()
	}),
	strictObject({ type: literal("start-step") }),
	strictObject({ type: literal("finish-step") }),
	strictObject({
		type: literal("start"),
		messageId: string().optional(),
		messageMetadata: unknown().optional()
	}),
	strictObject({
		type: literal("finish"),
		finishReason: _enum([
			"stop",
			"length",
			"content-filter",
			"tool-calls",
			"error",
			"other"
		]).optional(),
		messageMetadata: unknown().optional()
	}),
	strictObject({
		type: literal("abort"),
		reason: string().optional()
	}),
	strictObject({
		type: literal("message-metadata"),
		messageMetadata: unknown()
	})
])));
function isDataUIMessageChunk(chunk) {
	return chunk.type.startsWith("data-");
}
function createIdMap() {
	return /* @__PURE__ */ Object.create(null);
}
function isStaticToolUIPart(part) {
	return part.type.startsWith("tool-");
}
function isDynamicToolUIPart(part) {
	return part.type === "dynamic-tool";
}
function isToolUIPart(part) {
	return isStaticToolUIPart(part) || isDynamicToolUIPart(part);
}
function getStaticToolName(part) {
	return part.type.split("-").slice(1).join("-");
}
function createStreamingUIMessageState({ lastMessage, messageId }) {
	return {
		message: (lastMessage == null ? void 0 : lastMessage.role) === "assistant" ? lastMessage : {
			id: messageId,
			metadata: void 0,
			role: "assistant",
			parts: []
		},
		activeTextParts: createIdMap(),
		activeReasoningParts: createIdMap(),
		partialToolCalls: createIdMap()
	};
}
function processUIMessageStream({ stream, messageMetadataSchema, dataPartSchemas, runUpdateMessageJob, onError, onToolCall, onData }) {
	return stream.pipeThrough(new TransformStream({ async transform(chunk, controller) {
		await runUpdateMessageJob(async ({ state, write }) => {
			var _a22, _b, _c, _d;
			function getToolInvocation(toolCallId) {
				const toolInvocation = state.message.parts.filter(isToolUIPart).find((invocation) => invocation.toolCallId === toolCallId);
				if (toolInvocation == null) throw new UIMessageStreamError({
					chunkType: "tool-invocation",
					chunkId: toolCallId,
					message: `No tool invocation found for tool call ID "${toolCallId}".`
				});
				return toolInvocation;
			}
			function updateToolPart(options) {
				var _a23;
				const part = state.message.parts.find((part2) => isStaticToolUIPart(part2) && part2.toolCallId === options.toolCallId);
				const anyOptions = options;
				const anyPart = part;
				if (part != null) {
					part.state = options.state;
					anyPart.input = anyOptions.input;
					anyPart.output = anyOptions.output;
					anyPart.errorText = anyOptions.errorText;
					anyPart.rawInput = anyOptions.rawInput;
					anyPart.preliminary = anyOptions.preliminary;
					if (options.title !== void 0) anyPart.title = options.title;
					if (options.toolMetadata !== void 0) anyPart.toolMetadata = options.toolMetadata;
					anyPart.providerExecuted = (_a23 = anyOptions.providerExecuted) != null ? _a23 : part.providerExecuted;
					const providerMetadata = anyOptions.providerMetadata;
					if (providerMetadata != null) {
						if (options.state === "output-available" || options.state === "output-error") {
							const resultPart = part;
							resultPart.resultProviderMetadata = providerMetadata;
						} else part.callProviderMetadata = providerMetadata;
					}
				} else state.message.parts.push({
					type: `tool-${options.toolName}`,
					toolCallId: options.toolCallId,
					state: options.state,
					title: options.title,
					...options.toolMetadata !== void 0 ? { toolMetadata: options.toolMetadata } : {},
					input: anyOptions.input,
					output: anyOptions.output,
					rawInput: anyOptions.rawInput,
					errorText: anyOptions.errorText,
					providerExecuted: anyOptions.providerExecuted,
					preliminary: anyOptions.preliminary,
					...anyOptions.providerMetadata != null && (options.state === "output-available" || options.state === "output-error") ? { resultProviderMetadata: anyOptions.providerMetadata } : {},
					...anyOptions.providerMetadata != null && !(options.state === "output-available" || options.state === "output-error") ? { callProviderMetadata: anyOptions.providerMetadata } : {}
				});
			}
			function updateDynamicToolPart(options) {
				var _a23, _b2;
				const part = state.message.parts.find((part2) => part2.type === "dynamic-tool" && part2.toolCallId === options.toolCallId);
				const anyOptions = options;
				const anyPart = part;
				if (part != null) {
					part.state = options.state;
					anyPart.toolName = options.toolName;
					anyPart.input = anyOptions.input;
					anyPart.output = anyOptions.output;
					anyPart.errorText = anyOptions.errorText;
					anyPart.rawInput = (_a23 = anyOptions.rawInput) != null ? _a23 : anyPart.rawInput;
					anyPart.preliminary = anyOptions.preliminary;
					if (options.title !== void 0) anyPart.title = options.title;
					if (options.toolMetadata !== void 0) anyPart.toolMetadata = options.toolMetadata;
					anyPart.providerExecuted = (_b2 = anyOptions.providerExecuted) != null ? _b2 : part.providerExecuted;
					const providerMetadata = anyOptions.providerMetadata;
					if (providerMetadata != null) {
						if (options.state === "output-available" || options.state === "output-error") {
							const resultPart = part;
							resultPart.resultProviderMetadata = providerMetadata;
						} else part.callProviderMetadata = providerMetadata;
					}
				} else state.message.parts.push({
					type: "dynamic-tool",
					toolName: options.toolName,
					toolCallId: options.toolCallId,
					state: options.state,
					input: anyOptions.input,
					output: anyOptions.output,
					errorText: anyOptions.errorText,
					preliminary: anyOptions.preliminary,
					providerExecuted: anyOptions.providerExecuted,
					title: options.title,
					...options.toolMetadata !== void 0 ? { toolMetadata: options.toolMetadata } : {},
					...anyOptions.providerMetadata != null && (options.state === "output-available" || options.state === "output-error") ? { resultProviderMetadata: anyOptions.providerMetadata } : {},
					...anyOptions.providerMetadata != null && !(options.state === "output-available" || options.state === "output-error") ? { callProviderMetadata: anyOptions.providerMetadata } : {}
				});
			}
			async function updateMessageMetadata(metadata) {
				if (metadata != null) {
					const mergedMetadata = state.message.metadata != null ? mergeObjects(state.message.metadata, metadata) : metadata;
					if (messageMetadataSchema != null) await validateTypes({
						value: mergedMetadata,
						schema: messageMetadataSchema,
						context: {
							field: "message.metadata",
							entityId: state.message.id
						}
					});
					state.message.metadata = mergedMetadata;
				}
			}
			switch (chunk.type) {
				case "text-start": {
					const textPart = {
						type: "text",
						text: "",
						providerMetadata: chunk.providerMetadata,
						state: "streaming"
					};
					state.activeTextParts[chunk.id] = textPart;
					state.message.parts.push(textPart);
					write();
					break;
				}
				case "text-delta": {
					const textPart = state.activeTextParts[chunk.id];
					if (textPart == null) throw new UIMessageStreamError({
						chunkType: "text-delta",
						chunkId: chunk.id,
						message: `Received text-delta for missing text part with ID "${chunk.id}". Ensure a "text-start" chunk is sent before any "text-delta" chunks.`
					});
					textPart.text += chunk.delta;
					textPart.providerMetadata = (_a22 = chunk.providerMetadata) != null ? _a22 : textPart.providerMetadata;
					write();
					break;
				}
				case "text-end": {
					const textPart = state.activeTextParts[chunk.id];
					if (textPart == null) throw new UIMessageStreamError({
						chunkType: "text-end",
						chunkId: chunk.id,
						message: `Received text-end for missing text part with ID "${chunk.id}". Ensure a "text-start" chunk is sent before any "text-end" chunks.`
					});
					textPart.state = "done";
					textPart.providerMetadata = (_b = chunk.providerMetadata) != null ? _b : textPart.providerMetadata;
					delete state.activeTextParts[chunk.id];
					write();
					break;
				}
				case "reasoning-start": {
					const reasoningPart = {
						type: "reasoning",
						text: "",
						providerMetadata: chunk.providerMetadata,
						state: "streaming"
					};
					state.activeReasoningParts[chunk.id] = reasoningPart;
					state.message.parts.push(reasoningPart);
					write();
					break;
				}
				case "reasoning-delta": {
					const reasoningPart = state.activeReasoningParts[chunk.id];
					if (reasoningPart == null) throw new UIMessageStreamError({
						chunkType: "reasoning-delta",
						chunkId: chunk.id,
						message: `Received reasoning-delta for missing reasoning part with ID "${chunk.id}". Ensure a "reasoning-start" chunk is sent before any "reasoning-delta" chunks.`
					});
					reasoningPart.text += chunk.delta;
					reasoningPart.providerMetadata = (_c = chunk.providerMetadata) != null ? _c : reasoningPart.providerMetadata;
					write();
					break;
				}
				case "reasoning-end": {
					const reasoningPart = state.activeReasoningParts[chunk.id];
					if (reasoningPart == null) throw new UIMessageStreamError({
						chunkType: "reasoning-end",
						chunkId: chunk.id,
						message: `Received reasoning-end for missing reasoning part with ID "${chunk.id}". Ensure a "reasoning-start" chunk is sent before any "reasoning-end" chunks.`
					});
					reasoningPart.providerMetadata = (_d = chunk.providerMetadata) != null ? _d : reasoningPart.providerMetadata;
					reasoningPart.state = "done";
					delete state.activeReasoningParts[chunk.id];
					write();
					break;
				}
				case "file":
					state.message.parts.push({
						type: "file",
						mediaType: chunk.mediaType,
						url: chunk.url,
						...chunk.providerMetadata != null ? { providerMetadata: chunk.providerMetadata } : {}
					});
					write();
					break;
				case "source-url":
					state.message.parts.push({
						type: "source-url",
						sourceId: chunk.sourceId,
						url: chunk.url,
						title: chunk.title,
						providerMetadata: chunk.providerMetadata
					});
					write();
					break;
				case "source-document":
					state.message.parts.push({
						type: "source-document",
						sourceId: chunk.sourceId,
						mediaType: chunk.mediaType,
						title: chunk.title,
						filename: chunk.filename,
						providerMetadata: chunk.providerMetadata
					});
					write();
					break;
				case "tool-input-start": {
					const toolInvocations = state.message.parts.filter(isStaticToolUIPart);
					state.partialToolCalls[chunk.toolCallId] = {
						text: "",
						toolName: chunk.toolName,
						index: toolInvocations.length,
						dynamic: chunk.dynamic,
						title: chunk.title,
						toolMetadata: chunk.toolMetadata
					};
					if (chunk.dynamic) updateDynamicToolPart({
						toolCallId: chunk.toolCallId,
						toolName: chunk.toolName,
						state: "input-streaming",
						input: void 0,
						providerExecuted: chunk.providerExecuted,
						title: chunk.title,
						toolMetadata: chunk.toolMetadata,
						providerMetadata: chunk.providerMetadata
					});
					else updateToolPart({
						toolCallId: chunk.toolCallId,
						toolName: chunk.toolName,
						state: "input-streaming",
						input: void 0,
						providerExecuted: chunk.providerExecuted,
						title: chunk.title,
						toolMetadata: chunk.toolMetadata,
						providerMetadata: chunk.providerMetadata
					});
					write();
					break;
				}
				case "tool-input-delta": {
					const partialToolCall = state.partialToolCalls[chunk.toolCallId];
					if (partialToolCall == null) throw new UIMessageStreamError({
						chunkType: "tool-input-delta",
						chunkId: chunk.toolCallId,
						message: `Received tool-input-delta for missing tool call with ID "${chunk.toolCallId}". Ensure a "tool-input-start" chunk is sent before any "tool-input-delta" chunks.`
					});
					partialToolCall.text += chunk.inputTextDelta;
					const { value: partialArgs } = await parsePartialJson(partialToolCall.text);
					if (partialToolCall.dynamic) updateDynamicToolPart({
						toolCallId: chunk.toolCallId,
						toolName: partialToolCall.toolName,
						state: "input-streaming",
						input: partialArgs,
						title: partialToolCall.title,
						toolMetadata: partialToolCall.toolMetadata
					});
					else updateToolPart({
						toolCallId: chunk.toolCallId,
						toolName: partialToolCall.toolName,
						state: "input-streaming",
						input: partialArgs,
						title: partialToolCall.title,
						toolMetadata: partialToolCall.toolMetadata
					});
					write();
					break;
				}
				case "tool-input-available":
					if (chunk.dynamic) updateDynamicToolPart({
						toolCallId: chunk.toolCallId,
						toolName: chunk.toolName,
						state: "input-available",
						input: chunk.input,
						providerExecuted: chunk.providerExecuted,
						providerMetadata: chunk.providerMetadata,
						title: chunk.title,
						toolMetadata: chunk.toolMetadata
					});
					else updateToolPart({
						toolCallId: chunk.toolCallId,
						toolName: chunk.toolName,
						state: "input-available",
						input: chunk.input,
						providerExecuted: chunk.providerExecuted,
						providerMetadata: chunk.providerMetadata,
						title: chunk.title,
						toolMetadata: chunk.toolMetadata
					});
					write();
					if (onToolCall && !chunk.providerExecuted) await onToolCall({ toolCall: chunk });
					break;
				case "tool-input-error": {
					const existingPart = state.message.parts.filter(isToolUIPart).find((p) => p.toolCallId === chunk.toolCallId);
					if (existingPart != null ? existingPart.type === "dynamic-tool" : !!chunk.dynamic) updateDynamicToolPart({
						toolCallId: chunk.toolCallId,
						toolName: chunk.toolName,
						state: "output-error",
						input: chunk.input,
						errorText: chunk.errorText,
						providerExecuted: chunk.providerExecuted,
						providerMetadata: chunk.providerMetadata,
						toolMetadata: chunk.toolMetadata
					});
					else updateToolPart({
						toolCallId: chunk.toolCallId,
						toolName: chunk.toolName,
						state: "output-error",
						input: void 0,
						rawInput: chunk.input,
						errorText: chunk.errorText,
						providerExecuted: chunk.providerExecuted,
						providerMetadata: chunk.providerMetadata,
						toolMetadata: chunk.toolMetadata
					});
					write();
					break;
				}
				case "tool-approval-request": {
					const toolInvocation = getToolInvocation(chunk.toolCallId);
					toolInvocation.state = "approval-requested";
					toolInvocation.approval = {
						id: chunk.approvalId,
						...chunk.signature != null ? { signature: chunk.signature } : {}
					};
					write();
					break;
				}
				case "tool-output-denied": {
					const toolInvocation = getToolInvocation(chunk.toolCallId);
					toolInvocation.state = "output-denied";
					write();
					break;
				}
				case "tool-output-available": {
					const toolInvocation = getToolInvocation(chunk.toolCallId);
					if (toolInvocation.type === "dynamic-tool") updateDynamicToolPart({
						toolCallId: chunk.toolCallId,
						toolName: toolInvocation.toolName,
						state: "output-available",
						input: toolInvocation.input,
						output: chunk.output,
						preliminary: chunk.preliminary,
						providerExecuted: chunk.providerExecuted,
						providerMetadata: chunk.providerMetadata,
						title: toolInvocation.title,
						toolMetadata: toolInvocation.toolMetadata
					});
					else updateToolPart({
						toolCallId: chunk.toolCallId,
						toolName: getStaticToolName(toolInvocation),
						state: "output-available",
						input: toolInvocation.input,
						output: chunk.output,
						providerExecuted: chunk.providerExecuted,
						preliminary: chunk.preliminary,
						providerMetadata: chunk.providerMetadata,
						title: toolInvocation.title,
						toolMetadata: toolInvocation.toolMetadata
					});
					write();
					break;
				}
				case "tool-output-error": {
					const toolInvocation = getToolInvocation(chunk.toolCallId);
					if (toolInvocation.type === "dynamic-tool") updateDynamicToolPart({
						toolCallId: chunk.toolCallId,
						toolName: toolInvocation.toolName,
						state: "output-error",
						input: toolInvocation.input,
						errorText: chunk.errorText,
						providerExecuted: chunk.providerExecuted,
						providerMetadata: chunk.providerMetadata,
						title: toolInvocation.title,
						toolMetadata: toolInvocation.toolMetadata
					});
					else updateToolPart({
						toolCallId: chunk.toolCallId,
						toolName: getStaticToolName(toolInvocation),
						state: "output-error",
						input: toolInvocation.input,
						rawInput: toolInvocation.rawInput,
						errorText: chunk.errorText,
						providerExecuted: chunk.providerExecuted,
						providerMetadata: chunk.providerMetadata,
						title: toolInvocation.title,
						toolMetadata: toolInvocation.toolMetadata
					});
					write();
					break;
				}
				case "start-step":
					state.message.parts.push({ type: "step-start" });
					break;
				case "finish-step":
					state.activeTextParts = createIdMap();
					state.activeReasoningParts = createIdMap();
					break;
				case "start":
					if (chunk.messageId != null) state.message.id = chunk.messageId;
					await updateMessageMetadata(chunk.messageMetadata);
					if (chunk.messageId != null || chunk.messageMetadata != null) write();
					break;
				case "finish":
					if (chunk.finishReason != null) state.finishReason = chunk.finishReason;
					await updateMessageMetadata(chunk.messageMetadata);
					if (chunk.messageMetadata != null) write();
					break;
				case "message-metadata":
					await updateMessageMetadata(chunk.messageMetadata);
					if (chunk.messageMetadata != null) write();
					break;
				case "error":
					onError?.(new Error(chunk.errorText));
					break;
				default: if (isDataUIMessageChunk(chunk)) {
					if ((dataPartSchemas == null ? void 0 : dataPartSchemas[chunk.type]) != null) {
						const partIdx = state.message.parts.findIndex((p) => "id" in p && "data" in p && p.id === chunk.id && p.type === chunk.type);
						const actualPartIdx = partIdx >= 0 ? partIdx : state.message.parts.length;
						await validateTypes({
							value: chunk.data,
							schema: dataPartSchemas[chunk.type],
							context: {
								field: `message.parts[${actualPartIdx}].data`,
								entityName: chunk.type,
								entityId: chunk.id
							}
						});
					}
					const dataChunk = chunk;
					if (dataChunk.transient) {
						onData?.(dataChunk);
						break;
					}
					const existingUIPart = dataChunk.id != null ? state.message.parts.find((chunkArg) => dataChunk.type === chunkArg.type && dataChunk.id === chunkArg.id) : void 0;
					if (existingUIPart != null) existingUIPart.data = dataChunk.data;
					else state.message.parts.push(dataChunk);
					onData?.(dataChunk);
					write();
				}
			}
			controller.enqueue(chunk);
		});
	} }));
}
async function consumeStream({ stream, onError }) {
	const reader = stream.getReader();
	try {
		while (true) {
			const { done } = await reader.read();
			if (done) break;
		}
	} catch (error) {
		onError?.(error);
	} finally {
		reader.releaseLock();
	}
}
createIdGenerator({
	prefix: "aitxt",
	size: 24
});
record(string(), jsonValueSchema.optional());
createIdGenerator({
	prefix: "aiobj",
	size: 24
});
var SerialJobExecutor = class {
	constructor() {
		this.queue = [];
		this.isProcessing = false;
	}
	async processQueue() {
		if (this.isProcessing) return;
		this.isProcessing = true;
		while (this.queue.length > 0) {
			await this.queue[0]();
			this.queue.shift();
		}
		this.isProcessing = false;
	}
	async run(job) {
		return new Promise((resolve3, reject) => {
			this.queue.push(async () => {
				try {
					await job();
					resolve3();
				} catch (error) {
					reject(error);
				}
			});
			this.processQueue();
		});
	}
};
createIdGenerator({
	prefix: "aiobj",
	size: 24
});
async function convertFileListToFileUIParts(files) {
	if (files == null) return [];
	if (!globalThis.FileList || !(files instanceof globalThis.FileList)) throw new Error("FileList is not supported in the current environment");
	return Promise.all(Array.from(files).map(async (file) => {
		const { name: name22, type } = file;
		return {
			type: "file",
			mediaType: type,
			filename: name22,
			url: await new Promise((resolve3, reject) => {
				const reader = new FileReader();
				reader.onload = (readerEvent) => {
					var _a22;
					resolve3((_a22 = readerEvent.target) == null ? void 0 : _a22.result);
				};
				reader.onerror = (error) => reject(error);
				reader.readAsDataURL(file);
			})
		};
	}));
}
var HttpChatTransport = class {
	constructor({ api = "/api/chat", credentials, headers, body, fetch: fetch2, prepareSendMessagesRequest, prepareReconnectToStreamRequest }) {
		this.api = api;
		this.credentials = credentials;
		this.headers = headers;
		this.body = body;
		this.fetch = fetch2;
		this.prepareSendMessagesRequest = prepareSendMessagesRequest;
		this.prepareReconnectToStreamRequest = prepareReconnectToStreamRequest;
	}
	async sendMessages({ abortSignal, ...options }) {
		var _a22, _b, _c, _d, _e;
		const resolvedBody = await resolve(this.body);
		const resolvedHeaders = await resolve(this.headers);
		const resolvedCredentials = await resolve(this.credentials);
		const baseHeaders = {
			...normalizeHeaders(resolvedHeaders),
			...normalizeHeaders(options.headers)
		};
		const preparedRequest = await ((_a22 = this.prepareSendMessagesRequest) == null ? void 0 : _a22.call(this, {
			api: this.api,
			id: options.chatId,
			messages: options.messages,
			body: {
				...resolvedBody,
				...options.body
			},
			headers: baseHeaders,
			credentials: resolvedCredentials,
			requestMetadata: options.metadata,
			trigger: options.trigger,
			messageId: options.messageId
		}));
		const api = (_b = preparedRequest == null ? void 0 : preparedRequest.api) != null ? _b : this.api;
		const headers = (preparedRequest == null ? void 0 : preparedRequest.headers) !== void 0 ? normalizeHeaders(preparedRequest.headers) : baseHeaders;
		const body = (preparedRequest == null ? void 0 : preparedRequest.body) !== void 0 ? preparedRequest.body : {
			...resolvedBody,
			...options.body,
			id: options.chatId,
			messages: options.messages,
			trigger: options.trigger,
			messageId: options.messageId
		};
		const credentials = (_c = preparedRequest == null ? void 0 : preparedRequest.credentials) != null ? _c : resolvedCredentials;
		const response = await ((_d = this.fetch) != null ? _d : globalThis.fetch)(api, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				...headers
			},
			body: JSON.stringify(body),
			credentials,
			signal: abortSignal
		});
		if (!response.ok) throw new Error((_e = await response.text()) != null ? _e : "Failed to fetch the chat response.");
		if (!response.body) throw new Error("The response body is empty.");
		return this.processResponseStream(response.body);
	}
	async reconnectToStream(options) {
		var _a22, _b, _c, _d, _e;
		const resolvedBody = await resolve(this.body);
		const resolvedHeaders = await resolve(this.headers);
		const resolvedCredentials = await resolve(this.credentials);
		const baseHeaders = {
			...normalizeHeaders(resolvedHeaders),
			...normalizeHeaders(options.headers)
		};
		const preparedRequest = await ((_a22 = this.prepareReconnectToStreamRequest) == null ? void 0 : _a22.call(this, {
			api: this.api,
			id: options.chatId,
			body: {
				...resolvedBody,
				...options.body
			},
			headers: baseHeaders,
			credentials: resolvedCredentials,
			requestMetadata: options.metadata
		}));
		const api = (_b = preparedRequest == null ? void 0 : preparedRequest.api) != null ? _b : `${this.api}/${options.chatId}/stream`;
		const headers = (preparedRequest == null ? void 0 : preparedRequest.headers) !== void 0 ? normalizeHeaders(preparedRequest.headers) : baseHeaders;
		const credentials = (_c = preparedRequest == null ? void 0 : preparedRequest.credentials) != null ? _c : resolvedCredentials;
		const response = await ((_d = this.fetch) != null ? _d : globalThis.fetch)(api, {
			method: "GET",
			headers,
			credentials
		});
		if (response.status === 204) return null;
		if (!response.ok) throw new Error((_e = await response.text()) != null ? _e : "Failed to fetch the chat response.");
		if (!response.body) throw new Error("The response body is empty.");
		return this.processResponseStream(response.body);
	}
};
var DefaultChatTransport = class extends HttpChatTransport {
	constructor(options = {}) {
		super(options);
	}
	processResponseStream(stream) {
		return parseJsonEventStream({
			stream,
			schema: uiMessageChunkSchema
		}).pipeThrough(new TransformStream({ async transform(chunk, controller) {
			if (!chunk.success) throw chunk.error;
			controller.enqueue(chunk.value);
		} }));
	}
};
var AbstractChat = class {
	constructor({ generateId: generateId2 = generateId, id = generateId2(), transport = new DefaultChatTransport(), messageMetadataSchema, dataPartSchemas, state, onError, onToolCall, onFinish, onData, sendAutomaticallyWhen }) {
		this.activeResponse = void 0;
		this.jobExecutor = new SerialJobExecutor();
		/**
		* Appends or replaces a user message to the chat list. This triggers the API call to fetch
		* the assistant's response.
		*
		* If a messageId is provided, the message will be replaced.
		*/
		this.sendMessage = async (message, options) => {
			var _a22, _b, _c, _d;
			if (message == null) {
				await this.makeRequest({
					trigger: "submit-message",
					messageId: (_a22 = this.lastMessage) == null ? void 0 : _a22.id,
					...options
				});
				return;
			}
			let uiMessage;
			if ("text" in message || "files" in message) uiMessage = { parts: [...Array.isArray(message.files) ? message.files : await convertFileListToFileUIParts(message.files), ..."text" in message && message.text != null ? [{
				type: "text",
				text: message.text
			}] : []] };
			else uiMessage = message;
			if (message.messageId != null) {
				const messageIndex = this.state.messages.findIndex((m) => m.id === message.messageId);
				if (messageIndex === -1) throw new Error(`message with id ${message.messageId} not found`);
				if (this.state.messages[messageIndex].role !== "user") throw new Error(`message with id ${message.messageId} is not a user message`);
				this.state.messages = this.state.messages.slice(0, messageIndex + 1);
				this.state.replaceMessage(messageIndex, {
					...uiMessage,
					id: message.messageId,
					role: (_b = uiMessage.role) != null ? _b : "user",
					metadata: message.metadata
				});
			} else this.state.pushMessage({
				...uiMessage,
				id: (_c = uiMessage.id) != null ? _c : this.generateId(),
				role: (_d = uiMessage.role) != null ? _d : "user",
				metadata: message.metadata
			});
			await this.makeRequest({
				trigger: "submit-message",
				messageId: message.messageId,
				...options
			});
		};
		/**
		* Regenerate the assistant message with the provided message id.
		* If no message id is provided, the last assistant message will be regenerated.
		*/
		this.regenerate = async ({ messageId, ...options } = {}) => {
			const messageIndex = messageId == null ? this.state.messages.length - 1 : this.state.messages.findIndex((message) => message.id === messageId);
			if (messageIndex === -1) throw new Error(`message ${messageId} not found`);
			this.state.messages = this.state.messages.slice(0, this.messages[messageIndex].role === "assistant" ? messageIndex : messageIndex + 1);
			await this.makeRequest({
				trigger: "regenerate-message",
				messageId,
				...options
			});
		};
		/**
		* Attempt to resume an ongoing streaming response.
		*/
		this.resumeStream = async (options = {}) => {
			await this.makeRequest({
				trigger: "resume-stream",
				...options
			});
		};
		/**
		* Clear the error state and set the status to ready if the chat is in an error state.
		*/
		this.clearError = () => {
			if (this.status === "error") {
				this.state.error = void 0;
				this.setStatus({ status: "ready" });
			}
		};
		this.addToolApprovalResponse = async ({ id, approved, reason, options }) => this.jobExecutor.run(async () => {
			const messages = this.state.messages;
			const lastMessage = messages[messages.length - 1];
			const updatePart = (part) => isToolUIPart(part) && part.state === "approval-requested" && part.approval.id === id ? {
				...part,
				state: "approval-responded",
				approval: {
					id,
					approved,
					reason
				}
			} : part;
			this.state.replaceMessage(messages.length - 1, {
				...lastMessage,
				parts: lastMessage.parts.map(updatePart)
			});
			if (this.activeResponse) this.activeResponse.state.message.parts = this.activeResponse.state.message.parts.map(updatePart);
			if (this.status !== "streaming" && this.status !== "submitted" && this.sendAutomaticallyWhen) this.shouldSendAutomatically().then((shouldSend) => {
				var _a22;
				if (shouldSend) this.makeRequest({
					trigger: "submit-message",
					messageId: (_a22 = this.lastMessage) == null ? void 0 : _a22.id,
					...options
				});
			});
		});
		this.addToolOutput = async ({ state = "output-available", toolCallId, output, errorText, options }) => this.jobExecutor.run(async () => {
			const messages = this.state.messages;
			const lastMessage = messages[messages.length - 1];
			const updatePart = (part) => isToolUIPart(part) && part.toolCallId === toolCallId ? {
				...part,
				state,
				output,
				errorText
			} : part;
			this.state.replaceMessage(messages.length - 1, {
				...lastMessage,
				parts: lastMessage.parts.map(updatePart)
			});
			if (this.activeResponse) this.activeResponse.state.message.parts = this.activeResponse.state.message.parts.map(updatePart);
			if (this.status !== "streaming" && this.status !== "submitted" && this.sendAutomaticallyWhen) this.shouldSendAutomatically().then((shouldSend) => {
				var _a22;
				if (shouldSend) this.makeRequest({
					trigger: "submit-message",
					messageId: (_a22 = this.lastMessage) == null ? void 0 : _a22.id,
					...options
				});
			});
		});
		/** @deprecated Use addToolOutput */
		this.addToolResult = this.addToolOutput;
		/**
		* Abort the current request immediately, keep the generated tokens if any.
		*/
		this.stop = async () => {
			var _a22;
			if (this.status !== "streaming" && this.status !== "submitted") return;
			if ((_a22 = this.activeResponse) == null ? void 0 : _a22.abortController) this.activeResponse.abortController.abort();
		};
		this.id = id;
		this.transport = transport;
		this.generateId = generateId2;
		this.messageMetadataSchema = messageMetadataSchema;
		this.dataPartSchemas = dataPartSchemas;
		this.state = state;
		this.onError = onError;
		this.onToolCall = onToolCall;
		this.onFinish = onFinish;
		this.onData = onData;
		this.sendAutomaticallyWhen = sendAutomaticallyWhen;
	}
	/**
	* Hook status:
	*
	* - `submitted`: The message has been sent to the API and we're awaiting the start of the response stream.
	* - `streaming`: The response is actively streaming in from the API, receiving chunks of data.
	* - `ready`: The full response has been received and processed; a new user message can be submitted.
	* - `error`: An error occurred during the API request, preventing successful completion.
	*/
	get status() {
		return this.state.status;
	}
	setStatus({ status, error }) {
		if (this.status === status) return;
		this.state.status = status;
		this.state.error = error;
	}
	get error() {
		return this.state.error;
	}
	get messages() {
		return this.state.messages;
	}
	get lastMessage() {
		return this.state.messages[this.state.messages.length - 1];
	}
	set messages(messages) {
		this.state.messages = messages;
	}
	async shouldSendAutomatically() {
		if (!this.sendAutomaticallyWhen) return false;
		const result = this.sendAutomaticallyWhen({ messages: this.state.messages });
		if (result && typeof result === "object" && "then" in result) return await result;
		return result;
	}
	async makeRequest({ trigger, metadata, headers, body, messageId }) {
		var _a22, _b, _c;
		let resumeStream;
		if (trigger === "resume-stream") try {
			const reconnect = await this.transport.reconnectToStream({
				chatId: this.id,
				metadata,
				headers,
				body
			});
			if (reconnect == null) return;
			resumeStream = reconnect;
		} catch (err) {
			if (this.onError && err instanceof Error) this.onError(err);
			this.setStatus({
				status: "error",
				error: err
			});
			return;
		}
		this.setStatus({
			status: "submitted",
			error: void 0
		});
		const lastMessage = this.lastMessage;
		let isAbort = false;
		let isDisconnect = false;
		let isError = false;
		try {
			const activeResponse = {
				state: createStreamingUIMessageState({
					lastMessage: this.state.snapshot(lastMessage),
					messageId: this.generateId()
				}),
				abortController: new AbortController()
			};
			activeResponse.abortController.signal.addEventListener("abort", () => {
				isAbort = true;
			});
			this.activeResponse = activeResponse;
			let stream;
			if (trigger === "resume-stream") stream = resumeStream;
			else stream = await this.transport.sendMessages({
				chatId: this.id,
				messages: this.state.messages,
				abortSignal: activeResponse.abortController.signal,
				metadata,
				headers,
				body,
				trigger,
				messageId
			});
			const runUpdateMessageJob = (job) => this.jobExecutor.run(() => job({
				state: activeResponse.state,
				write: () => {
					var _a23;
					this.setStatus({ status: "streaming" });
					if (activeResponse.state.message.id === ((_a23 = this.lastMessage) == null ? void 0 : _a23.id)) this.state.replaceMessage(this.state.messages.length - 1, activeResponse.state.message);
					else this.state.pushMessage(activeResponse.state.message);
				}
			}));
			await consumeStream({
				stream: processUIMessageStream({
					stream,
					onToolCall: this.onToolCall,
					onData: this.onData,
					messageMetadataSchema: this.messageMetadataSchema,
					dataPartSchemas: this.dataPartSchemas,
					runUpdateMessageJob,
					onError: (error) => {
						throw error;
					}
				}),
				onError: (error) => {
					throw error;
				}
			});
			this.setStatus({ status: "ready" });
		} catch (err) {
			if (isAbort || err.name === "AbortError") {
				isAbort = true;
				this.setStatus({ status: "ready" });
				return null;
			}
			isError = true;
			if (err instanceof TypeError && (err.message.toLowerCase().includes("fetch") || err.message.toLowerCase().includes("network"))) isDisconnect = true;
			if (this.onError && err instanceof Error) this.onError(err);
			this.setStatus({
				status: "error",
				error: err
			});
		} finally {
			try {
				(_b = this.onFinish) == null || _b.call(this, {
					message: this.activeResponse.state.message,
					messages: this.state.messages,
					isAbort,
					isDisconnect,
					isError,
					finishReason: (_a22 = this.activeResponse) == null ? void 0 : _a22.state.finishReason
				});
			} catch (err) {
				console.error(err);
			}
			this.activeResponse = void 0;
		}
		if (!isError && await this.shouldSendAutomatically()) await this.makeRequest({
			trigger: "submit-message",
			messageId: (_c = this.lastMessage) == null ? void 0 : _c.id,
			metadata,
			headers,
			body
		});
	}
};
//#endregion
//#region node_modules/.pnpm/@ai-sdk+react@3.0.211_react@19.2.4_zod@4.6.7/node_modules/@ai-sdk/react/dist/index.mjs
var import_throttleit = /* @__PURE__ */ __toESM((/* @__PURE__ */ __commonJSMin(((exports, module) => {
	function throttle(function_, wait) {
		if (typeof function_ !== "function") throw new TypeError(`Expected the first argument to be a \`function\`, got \`${typeof function_}\`.`);
		let timeoutId;
		let lastCallTime = 0;
		return function throttled(...arguments_) {
			clearTimeout(timeoutId);
			const now = Date.now();
			const delayForNextCall = wait - (now - lastCallTime);
			if (delayForNextCall <= 0) {
				lastCallTime = now;
				function_.apply(this, arguments_);
			} else timeoutId = setTimeout(() => {
				lastCallTime = Date.now();
				function_.apply(this, arguments_);
			}, delayForNextCall);
		};
	}
	module.exports = throttle;
})))(), 1);
var __accessCheck = (obj, member, msg) => {
	if (!member.has(obj)) throw TypeError("Cannot " + msg);
};
var __privateGet = (obj, member, getter) => {
	__accessCheck(obj, member, "read from private field");
	return getter ? getter.call(obj) : member.get(obj);
};
var __privateAdd = (obj, member, value) => {
	if (member.has(obj)) throw TypeError("Cannot add the same private member more than once");
	member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
};
var __privateSet = (obj, member, value, setter) => {
	__accessCheck(obj, member, "write to private field");
	setter ? setter.call(obj, value) : member.set(obj, value);
	return value;
};
function throttle(fn, waitMs) {
	return waitMs != null ? (0, import_throttleit.default)(fn, waitMs) : fn;
}
var _messages;
var _status;
var _error;
var _messagesCallbacks;
var _statusCallbacks;
var _errorCallbacks;
var _callMessagesCallbacks;
var _callStatusCallbacks;
var _callErrorCallbacks;
var ReactChatState = class {
	constructor(initialMessages = []) {
		__privateAdd(this, _messages, void 0);
		__privateAdd(this, _status, "ready");
		__privateAdd(this, _error, void 0);
		__privateAdd(this, _messagesCallbacks, /* @__PURE__ */ new Set());
		__privateAdd(this, _statusCallbacks, /* @__PURE__ */ new Set());
		__privateAdd(this, _errorCallbacks, /* @__PURE__ */ new Set());
		this.pushMessage = (message) => {
			__privateSet(this, _messages, __privateGet(this, _messages).concat(message));
			__privateGet(this, _callMessagesCallbacks).call(this);
		};
		this.popMessage = () => {
			__privateSet(this, _messages, __privateGet(this, _messages).slice(0, -1));
			__privateGet(this, _callMessagesCallbacks).call(this);
		};
		this.replaceMessage = (index, message) => {
			__privateSet(this, _messages, [
				...__privateGet(this, _messages).slice(0, index),
				this.snapshot(message),
				...__privateGet(this, _messages).slice(index + 1)
			]);
			__privateGet(this, _callMessagesCallbacks).call(this);
		};
		this.snapshot = (value) => structuredClone(value);
		this["~registerMessagesCallback"] = (onChange, throttleWaitMs) => {
			const callback = throttleWaitMs ? throttle(onChange, throttleWaitMs) : onChange;
			__privateGet(this, _messagesCallbacks).add(callback);
			return () => {
				__privateGet(this, _messagesCallbacks).delete(callback);
			};
		};
		this["~registerStatusCallback"] = (onChange) => {
			__privateGet(this, _statusCallbacks).add(onChange);
			return () => {
				__privateGet(this, _statusCallbacks).delete(onChange);
			};
		};
		this["~registerErrorCallback"] = (onChange) => {
			__privateGet(this, _errorCallbacks).add(onChange);
			return () => {
				__privateGet(this, _errorCallbacks).delete(onChange);
			};
		};
		__privateAdd(this, _callMessagesCallbacks, () => {
			__privateGet(this, _messagesCallbacks).forEach((callback) => callback());
		});
		__privateAdd(this, _callStatusCallbacks, () => {
			__privateGet(this, _statusCallbacks).forEach((callback) => callback());
		});
		__privateAdd(this, _callErrorCallbacks, () => {
			__privateGet(this, _errorCallbacks).forEach((callback) => callback());
		});
		__privateSet(this, _messages, initialMessages);
	}
	get status() {
		return __privateGet(this, _status);
	}
	set status(newStatus) {
		__privateSet(this, _status, newStatus);
		__privateGet(this, _callStatusCallbacks).call(this);
	}
	get error() {
		return __privateGet(this, _error);
	}
	set error(newError) {
		__privateSet(this, _error, newError);
		__privateGet(this, _callErrorCallbacks).call(this);
	}
	get messages() {
		return __privateGet(this, _messages);
	}
	set messages(newMessages) {
		__privateSet(this, _messages, [...newMessages]);
		__privateGet(this, _callMessagesCallbacks).call(this);
	}
};
_messages = /* @__PURE__ */ new WeakMap();
_status = /* @__PURE__ */ new WeakMap();
_error = /* @__PURE__ */ new WeakMap();
_messagesCallbacks = /* @__PURE__ */ new WeakMap();
_statusCallbacks = /* @__PURE__ */ new WeakMap();
_errorCallbacks = /* @__PURE__ */ new WeakMap();
_callMessagesCallbacks = /* @__PURE__ */ new WeakMap();
_callStatusCallbacks = /* @__PURE__ */ new WeakMap();
_callErrorCallbacks = /* @__PURE__ */ new WeakMap();
var _state;
var Chat = class extends AbstractChat {
	constructor({ messages, ...init }) {
		const state = new ReactChatState(messages);
		super({
			...init,
			state
		});
		__privateAdd(this, _state, void 0);
		this["~registerMessagesCallback"] = (onChange, throttleWaitMs) => __privateGet(this, _state)["~registerMessagesCallback"](onChange, throttleWaitMs);
		this["~registerStatusCallback"] = (onChange) => __privateGet(this, _state)["~registerStatusCallback"](onChange);
		this["~registerErrorCallback"] = (onChange) => __privateGet(this, _state)["~registerErrorCallback"](onChange);
		__privateSet(this, _state, state);
	}
};
_state = /* @__PURE__ */ new WeakMap();
function useChat({ experimental_throttle: throttleWaitMs, resume = false, ...options } = {}) {
	const callbacksRef = (0, import_react.useRef)(!("chat" in options) ? {
		onToolCall: options.onToolCall,
		onData: options.onData,
		onFinish: options.onFinish,
		onError: options.onError,
		sendAutomaticallyWhen: options.sendAutomaticallyWhen
	} : {});
	if (!("chat" in options)) callbacksRef.current = {
		onToolCall: options.onToolCall,
		onData: options.onData,
		onFinish: options.onFinish,
		onError: options.onError,
		sendAutomaticallyWhen: options.sendAutomaticallyWhen
	};
	const optionsWithCallbacks = {
		...options,
		onToolCall: (arg) => {
			var _a, _b;
			return (_b = (_a = callbacksRef.current).onToolCall) == null ? void 0 : _b.call(_a, arg);
		},
		onData: (arg) => {
			var _a, _b;
			return (_b = (_a = callbacksRef.current).onData) == null ? void 0 : _b.call(_a, arg);
		},
		onFinish: (arg) => {
			var _a, _b;
			return (_b = (_a = callbacksRef.current).onFinish) == null ? void 0 : _b.call(_a, arg);
		},
		onError: (arg) => {
			var _a, _b;
			return (_b = (_a = callbacksRef.current).onError) == null ? void 0 : _b.call(_a, arg);
		},
		sendAutomaticallyWhen: (arg) => {
			var _a, _b, _c;
			return (_c = (_b = (_a = callbacksRef.current).sendAutomaticallyWhen) == null ? void 0 : _b.call(_a, arg)) != null ? _c : false;
		}
	};
	const chatRef = (0, import_react.useRef)("chat" in options ? options.chat : new Chat(optionsWithCallbacks));
	if ("chat" in options && options.chat !== chatRef.current || "id" in options && chatRef.current.id !== options.id) chatRef.current = "chat" in options ? options.chat : new Chat(optionsWithCallbacks);
	const subscribeToMessages = (0, import_react.useCallback)((update) => chatRef.current["~registerMessagesCallback"](update, throttleWaitMs), [throttleWaitMs, chatRef.current.id]);
	const messages = (0, import_react.useSyncExternalStore)(subscribeToMessages, () => chatRef.current.messages, () => chatRef.current.messages);
	const status = (0, import_react.useSyncExternalStore)(chatRef.current["~registerStatusCallback"], () => chatRef.current.status, () => chatRef.current.status);
	const error = (0, import_react.useSyncExternalStore)(chatRef.current["~registerErrorCallback"], () => chatRef.current.error, () => chatRef.current.error);
	const setMessages = (0, import_react.useCallback)((messagesParam) => {
		if (typeof messagesParam === "function") messagesParam = messagesParam(chatRef.current.messages);
		chatRef.current.messages = messagesParam;
	}, [chatRef]);
	(0, import_react.useEffect)(() => {
		if (resume) chatRef.current.resumeStream();
	}, [resume, chatRef]);
	return {
		id: chatRef.current.id,
		messages,
		setMessages,
		sendMessage: chatRef.current.sendMessage,
		regenerate: chatRef.current.regenerate,
		clearError: chatRef.current.clearError,
		stop: chatRef.current.stop,
		error,
		resumeStream: chatRef.current.resumeStream,
		status,
		/**
		* @deprecated Use `addToolOutput` instead.
		*/
		addToolResult: chatRef.current.addToolOutput,
		addToolOutput: chatRef.current.addToolOutput,
		addToolApprovalResponse: chatRef.current.addToolApprovalResponse
	};
}
//#endregion
//#region node_modules/.pnpm/agents@0.28.1_@ai-sdk+provider@4.0.4_@ai-sdk+react@3.0.211_react@19.2.4_zod@4.6.7__@bab_539d04cddbcc3adc73174759dfaafa16/node_modules/agents/dist/chat/react.js
/**
* Picks the throttle from an explicit caller value, the deprecated alias, or
* the default \u2014 in that order. `false` turns throttling off.
*/
function resolveChatThrottleMs(options) {
	if (options.throttle === false) return void 0;
	return options.throttle ?? options.experimental_throttle ?? 50;
}
/**
* The throttle spelled under both option names, or neither name when it is off.
*
* The two names are not interchangeable across the peer range. `@ai-sdk/react`
* v3 only reads `experimental_throttle`; v4 renamed it to `throttle` and reads
* `throttle ?? experimental_throttle`. Our peer range allows both majors, so
* sending one name would silently do nothing on the other. Unknown option keys
* are ignored by both, so sending both names is safe.
*
* Turning throttling off omits both names rather than inventing a numeric
* value. Both majors also treat an explicit `0` as unthrottled, so callers that
* pass `0` keep that value under both spellings.
*/
function chatThrottleOptions(options) {
	const ms = resolveChatThrottleMs(options);
	if (ms === void 0) return {};
	return {
		experimental_throttle: ms,
		throttle: ms
	};
}
/**
* One-shot deprecation warnings (warns once per key per session).
*/
var _deprecationWarnings = /* @__PURE__ */ new Set();
function warnDeprecated(id, message) {
	if (!_deprecationWarnings.has(id)) {
		_deprecationWarnings.add(id);
		console.warn(`[agents/chat] Deprecated: ${message}`);
	}
}
/**
* Extracts tool schemas from tools that have client-side execute functions.
* These schemas are automatically sent to the server with each request.
*
* Called internally by `useAgentChat` when `tools` are provided.
* Most apps do not need to call this directly.
*
* @param tools - Record of tool name to tool definition
* @returns Array of tool schemas to send to server, or undefined if none
*/
function extractClientToolSchemas(tools) {
	if (!tools) return void 0;
	const schemas = Object.entries(tools).filter(([_, tool]) => tool.execute).map(([name, tool]) => {
		if (tool.inputSchema && !tool.parameters) console.warn(`[useAgentChat] Tool "${name}" uses deprecated 'inputSchema'. Please migrate to 'parameters'.`);
		return {
			name,
			description: tool.description,
			parameters: tool.parameters ?? tool.inputSchema
		};
	});
	return schemas.length > 0 ? schemas : void 0;
}
/**
* Replays re-send only recent terminals, so duplicate suppression needs only
* a recent window of ended request ids.
*/
var MAX_REMEMBERED_ENDED_TURNS = 500;
/**
* Module-level cache for initial message fetches. Intentionally shared across
* all useAgentChat instances to deduplicate requests during React Strict Mode
* double-renders and re-renders. Cache keys include the agent URL, agent type,
* and thread name to prevent cross-agent collisions.
*/
var requestCache = /* @__PURE__ */ new Map();
function findLastAssistantMessage(messages) {
	for (let index = messages.length - 1; index >= 0; index--) {
		const message = messages[index];
		if (message.role === "assistant") return {
			index,
			message
		};
	}
	return null;
}
function moveMessageToEnd(messages, messageId) {
	const idx = messages.findIndex((m) => m.id === messageId);
	if (idx < 0 || idx === messages.length - 1) return messages;
	const result = [...messages];
	const [msg] = result.splice(idx, 1);
	if (!msg) return messages;
	result.push(msg);
	return result;
}
function prependMissingHydratedMessages(hydratedMessages, currentMessages) {
	if (currentMessages.length === 0) return hydratedMessages;
	const currentMessageIds = new Set(currentMessages.map((message) => message.id));
	const missingHydratedMessages = hydratedMessages.filter((message) => !currentMessageIds.has(message.id));
	if (missingHydratedMessages.length === 0) return currentMessages;
	return [...missingHydratedMessages, ...currentMessages];
}
function restoreBufferedSends(snapshot, local, bufferedIds) {
	if (bufferedIds.size === 0) return snapshot;
	const snapshotIds = new Set(snapshot.map((message) => message.id));
	const restored = local.filter((message) => bufferedIds.has(message.id) && !snapshotIds.has(message.id));
	return restored.length === 0 ? snapshot : [...snapshot, ...restored];
}
function useAgentChat$1(options) {
	const { agent, getInitialMessages, messages: optionsInitialMessages, onToolCall, onTurnEnd, onData, experimental_automaticToolResolution, tools, toolsRequiringConfirmation: manualToolsRequiringConfirmation, autoContinueAfterToolResult = true, autoSendAfterAllConfirmationsResolved = true, resume = true, cancelOnClientAbort = false, syncMessagesToServer = true, body: bodyOption, prepareSendMessagesRequest, throttle, experimental_throttle, ...rest } = options;
	if (manualToolsRequiringConfirmation) warnDeprecated("useAgentChat.toolsRequiringConfirmation", "The 'toolsRequiringConfirmation' option is deprecated. Use needsApproval on server-side tools instead. Will be removed in the next major version.");
	if (experimental_automaticToolResolution) warnDeprecated("useAgentChat.experimental_automaticToolResolution", "The 'experimental_automaticToolResolution' option is deprecated. Use the onToolCall callback instead. Will be removed in the next major version.");
	if (options.autoSendAfterAllConfirmationsResolved !== void 0) warnDeprecated("useAgentChat.autoSendAfterAllConfirmationsResolved", "The 'autoSendAfterAllConfirmationsResolved' option is deprecated. Use sendAutomaticallyWhen from AI SDK instead. Will be removed in the next major version.");
	const toolsRequiringConfirmation = (0, import_react.useMemo)(() => {
		if (manualToolsRequiringConfirmation) return manualToolsRequiringConfirmation;
		if (!tools) return [];
		return Object.entries(tools).filter(([_name, tool]) => !tool.execute).map(([name]) => name);
	}, [manualToolsRequiringConfirmation, tools]);
	const onToolCallRef = (0, import_react.useRef)(onToolCall);
	onToolCallRef.current = onToolCall;
	const onTurnEndRef = (0, import_react.useRef)(onTurnEnd);
	onTurnEndRef.current = onTurnEnd;
	const turnErrorsRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const endedTurnIdsRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const pendingTurnEndsRef = (0, import_react.useRef)([]);
	const onDataRef = (0, import_react.useRef)(onData);
	onDataRef.current = onData;
	const socketAddressPending = isSocketAddressPending(agent);
	const committedAddressRef = (0, import_react.useRef)(null);
	let address = committedAddressRef.current;
	if (!socketAddressPending || address === null) {
		const rawHttpUrl = agent.getHttpUrl();
		const url = rawHttpUrl ? new URL(rawHttpUrl) : null;
		url?.searchParams.delete("_pk");
		const route = agent.partySocketOptions;
		address = {
			urlString: url?.toString() ?? null,
			addressKey: JSON.stringify([Array.isArray(agent.path) ? agent.path.map((step) => [step.agent, step.name]) : [[agent.agent ?? "", agent.name ?? ""]], route ? [
				route.host ?? null,
				route.basePath ?? null,
				route.prefix ?? null,
				route.party ?? null,
				route.path ?? null
			] : null]),
			agent: agent.agent,
			name: agent.name
		};
		if (!socketAddressPending) committedAddressRef.current = address;
	}
	const agentUrl = address.urlString ? new URL(address.urlString) : null;
	const agentUrlString = address.urlString;
	const agentAddressKey = address.addressKey;
	const resolvedInitialMessagesCacheKey = agentUrl ? `${agentUrl.origin}${agentUrl.pathname}|${agentAddressKey}` : null;
	const initialMessagesCacheKey = agentAddressKey;
	const stableChatIdRef = (0, import_react.useRef)(null);
	const previousAgentRef = (0, import_react.useRef)(null);
	const previousAgentAddressKeyRef = (0, import_react.useRef)(null);
	const fallbackChatId = agentAddressKey;
	const agentPathChanged = Array.isArray(agent.path) && previousAgentAddressKeyRef.current !== null && previousAgentAddressKeyRef.current !== agentAddressKey;
	if (stableChatIdRef.current === null) stableChatIdRef.current = resolvedInitialMessagesCacheKey ?? fallbackChatId;
	else if (previousAgentRef.current !== agent || agentPathChanged) stableChatIdRef.current = resolvedInitialMessagesCacheKey ?? fallbackChatId;
	previousAgentRef.current = agent;
	previousAgentAddressKeyRef.current = agentAddressKey;
	const agentRef = (0, import_react.useRef)(agent);
	agentRef.current = agent;
	async function defaultGetInitialMessagesFetch({ url }) {
		if (!url) return [];
		const getMessagesUrl = new URL(url);
		getMessagesUrl.pathname += "/get-messages";
		const response = await fetch(getMessagesUrl.toString(), {
			credentials: options.credentials,
			headers: options.headers
		});
		if (!response.ok) {
			console.warn(`Failed to fetch initial messages: ${response.status} ${response.statusText}`);
			return [];
		}
		const text = await response.text();
		if (!text.trim()) return [];
		try {
			return JSON.parse(text);
		} catch (error) {
			console.warn("Failed to parse initial messages JSON:", error);
			return [];
		}
	}
	const getInitialMessagesFetch = getInitialMessages || defaultGetInitialMessagesFetch;
	function doGetInitialMessages(getInitialMessagesOptions, cacheKey) {
		if (requestCache.has(cacheKey)) return requestCache.get(cacheKey);
		const promise = getInitialMessagesFetch(getInitialMessagesOptions);
		requestCache.set(cacheKey, promise);
		return promise;
	}
	const initialMessagesPromise = !(getInitialMessages === null || committedAddressRef.current === null ? false : getInitialMessages ? true : !!agentUrlString) ? null : doGetInitialMessages({
		agent: address.agent,
		name: address.name,
		url: agentUrlString ?? void 0
	}, initialMessagesCacheKey);
	const initialMessages = initialMessagesPromise ? (0, import_react.use)(initialMessagesPromise) : optionsInitialMessages ?? [];
	(0, import_react.useEffect)(() => {
		if (!initialMessagesPromise) return;
		requestCache.set(initialMessagesCacheKey, initialMessagesPromise);
		return () => {
			if (requestCache.get(initialMessagesCacheKey) === initialMessagesPromise) requestCache.delete(initialMessagesCacheKey);
		};
	}, [initialMessagesCacheKey, initialMessagesPromise]);
	const toolsRef = (0, import_react.useRef)(tools);
	toolsRef.current = tools;
	const prepareSendMessagesRequestRef = (0, import_react.useRef)(prepareSendMessagesRequest);
	prepareSendMessagesRequestRef.current = prepareSendMessagesRequest;
	const bodyOptionRef = (0, import_react.useRef)(bodyOption);
	bodyOptionRef.current = bodyOption;
	/**
	* Tracks request IDs initiated by this tab via the transport.
	* Used by onAgentMessage to skip messages already handled by the transport.
	*/
	const localRequestIdsRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const pendingBufferedSendIdsRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const pendingReplayResumeRequestIdsRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const replayHydratedAssistantMessageIdsRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	/**
	* Request ids this socket already ACKed via the fallback resume path.
	* The server sends CF_AGENT_STREAM_RESUMING for the same request from
	* both onConnect and its CF_AGENT_STREAM_RESUME_REQUEST handler (#1733).
	* The transport-handled path dedupes the second notify via
	* localRequestIdsRef, but the fallback path used to ACK both \u2014 triggering
	* a second full-buffer replay that duplicated streamed parts. Entries are
	* dropped when the turn completes; the whole set resets when the socket
	* closes, since a new connection legitimately needs a fresh ACK+replay.
	*/
	const fallbackAckedResumeRequestIdsRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const customTransportRef = (0, import_react.useRef)(null);
	if (customTransportRef.current === null) customTransportRef.current = new WebSocketChatTransport({
		agent: agentRef.current,
		activeRequestIds: localRequestIdsRef.current,
		cancelOnClientAbort,
		onRequestBuffered: (messageId) => {
			if (messageId) pendingBufferedSendIdsRef.current.add(messageId);
		},
		prepareBody: async ({ messages: msgs, trigger, messageId }) => {
			let extraBody = {};
			const currentBody = bodyOptionRef.current;
			if (currentBody) extraBody = { ...typeof currentBody === "function" ? await currentBody() : currentBody };
			if (toolsRef.current) {
				const clientToolSchemas = extractClientToolSchemas(toolsRef.current);
				if (clientToolSchemas) extraBody.clientTools = clientToolSchemas;
			}
			if (prepareSendMessagesRequestRef.current) {
				const userResult = await prepareSendMessagesRequestRef.current({
					id: agentRef.current._pk,
					messages: msgs,
					trigger,
					messageId
				});
				if (userResult.body) Object.assign(extraBody, userResult.body);
			}
			return extraBody;
		}
	});
	customTransportRef.current.setAgent(agentRef.current);
	customTransportRef.current.setCancelOnClientAbort(cancelOnClientAbort);
	const customTransport = customTransportRef.current;
	const useChatHelpers = useChat({
		...rest,
		...chatThrottleOptions({
			experimental_throttle,
			throttle
		}),
		onData,
		messages: initialMessages,
		transport: customTransport,
		id: stableChatIdRef.current,
		resume: false
	});
	const { messages: chatMessages, setMessages, addToolResult, addToolApprovalResponse, sendMessage, resumeStream: rawResumeStream, status, stop } = useChatHelpers;
	const statusRef = (0, import_react.useRef)(status);
	statusRef.current = status;
	const resumeGenerationRef = (0, import_react.useRef)(0);
	const resumeOperationRef = (0, import_react.useRef)(null);
	const reconnectProbePendingRef = (0, import_react.useRef)(false);
	const reconnectProbeRunnerRef = (0, import_react.useRef)(null);
	const invalidateResumeGeneration = (0, import_react.useCallback)(() => {
		resumeGenerationRef.current++;
		resumeOperationRef.current = null;
	}, []);
	const resumeStream = (0, import_react.useCallback)((...args) => {
		const active = resumeOperationRef.current;
		if (active) return active.promise;
		const operation = {
			generation: resumeGenerationRef.current,
			promise: Promise.resolve()
		};
		resumeOperationRef.current = operation;
		operation.promise = rawResumeStream(...args).finally(() => {
			if (resumeOperationRef.current !== operation || resumeGenerationRef.current !== operation.generation) return;
			resumeOperationRef.current = null;
			reconnectProbeRunnerRef.current?.();
		});
		return operation.promise;
	}, [rawResumeStream]);
	const resumeStreamRef = (0, import_react.useRef)(resumeStream);
	resumeStreamRef.current = resumeStream;
	const resumingToolContinuationRef = (0, import_react.useRef)(false);
	const pendingToolContinuationRef = (0, import_react.useRef)(false);
	const observedToolContinuationRequestIdRef = (0, import_react.useRef)(null);
	const continuationLaunchTimerRef = (0, import_react.useRef)(null);
	const continuationGenerationRef = (0, import_react.useRef)(0);
	const [isToolContinuation, setIsToolContinuation] = (0, import_react.useState)(false);
	const resetToolContinuation = (0, import_react.useCallback)(() => {
		continuationGenerationRef.current++;
		pendingToolContinuationRef.current = false;
		resumingToolContinuationRef.current = false;
		observedToolContinuationRequestIdRef.current = null;
		if (continuationLaunchTimerRef.current) {
			clearTimeout(continuationLaunchTimerRef.current);
			continuationLaunchTimerRef.current = null;
		}
		setIsToolContinuation(false);
	}, []);
	const scheduleToolContinuationLaunch = (0, import_react.useCallback)(() => {
		if (!pendingToolContinuationRef.current || statusRef.current !== "ready" || continuationLaunchTimerRef.current) return;
		const timer = setTimeout(() => {
			(async () => {
				while (resumeOperationRef.current) await resumeOperationRef.current.promise.catch(() => {});
				if (continuationLaunchTimerRef.current === timer) continuationLaunchTimerRef.current = null;
				if (!pendingToolContinuationRef.current || statusRef.current !== "ready") return;
				pendingToolContinuationRef.current = false;
				const myGeneration = continuationGenerationRef.current;
				customTransport.expectToolContinuation();
				await resumeStream().catch((error) => {
					console.error("[useAgentChat] Tool continuation resume failed:", error);
				}).finally(() => {
					if (continuationGenerationRef.current !== myGeneration) return;
					resumingToolContinuationRef.current = false;
					setIsToolContinuation(false);
				});
			})();
		}, 0);
		continuationLaunchTimerRef.current = timer;
	}, [customTransport, resumeStream]);
	const startToolContinuation = (0, import_react.useCallback)(() => {
		if (!autoContinueAfterToolResult || resumingToolContinuationRef.current) return;
		++continuationGenerationRef.current;
		resumingToolContinuationRef.current = true;
		pendingToolContinuationRef.current = true;
		setIsToolContinuation(true);
		scheduleToolContinuationLaunch();
	}, [autoContinueAfterToolResult, scheduleToolContinuationLaunch]);
	(0, import_react.useEffect)(() => {
		if (status === "error" && pendingToolContinuationRef.current) {
			resetToolContinuation();
			return;
		}
		scheduleToolContinuationLaunch();
	}, [
		resetToolContinuation,
		scheduleToolContinuationLaunch,
		status
	]);
	const stopWithToolContinuationAbort = (0, import_react.useCallback)(async () => {
		try {
			customTransport.cancelActiveServerTurn();
			await stop();
		} finally {
			customTransport.abortActiveToolContinuation();
		}
	}, [stop, customTransport]);
	const processedToolCalls = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const isResolvingToolsRef = (0, import_react.useRef)(false);
	const [toolResolutionTrigger, setToolResolutionTrigger] = (0, import_react.useState)(0);
	const [clientToolResults, setClientToolResults] = (0, import_react.useState)(/* @__PURE__ */ new Map());
	const clientToolResultsRef = (0, import_react.useRef)(clientToolResults);
	clientToolResultsRef.current = clientToolResults;
	const initialMessagesRef = (0, import_react.useRef)(initialMessages);
	initialMessagesRef.current = initialMessages;
	const seededInitialMessagesKeyRef = (0, import_react.useRef)(null);
	const markInitialMessagesSeeded = (0, import_react.useCallback)(() => {
		seededInitialMessagesKeyRef.current = initialMessagesCacheKey;
	}, [initialMessagesCacheKey]);
	(0, import_react.useEffect)(() => {
		if (!initialMessagesPromise) return;
		if (seededInitialMessagesKeyRef.current === initialMessagesCacheKey) return;
		markInitialMessagesSeeded();
		setMessages((prevMessages) => prependMissingHydratedMessages(initialMessagesRef.current, prevMessages));
	}, [
		initialMessagesCacheKey,
		initialMessagesPromise,
		markInitialMessagesSeeded,
		setMessages
	]);
	const localResponseMessageIdsRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	const protectedStreamingAssistantRef = (0, import_react.useRef)(null);
	const preserveProtectedStreamingAssistant = (0, import_react.useCallback)((messages, currentMessages) => {
		const protection = protectedStreamingAssistantRef.current;
		if (!protection) return [...messages];
		const protectedIndex = messages.findIndex((message) => message.id === protection.assistantId);
		if (protectedIndex >= 0 && messages.slice(protectedIndex + 1).some((message) => message.role === "assistant")) {
			protectedStreamingAssistantRef.current = null;
			return [...messages];
		}
		const protectedAssistant = currentMessages.find((message) => message.id === protection.assistantId) ?? messages.find((message) => message.id === protection.assistantId);
		if (!protectedAssistant) return [...messages];
		return [...messages.filter((message) => message.id !== protection.assistantId), protectedAssistant];
	}, []);
	const protectStreamingAssistantTail = (0, import_react.useCallback)(() => {
		if (statusRef.current !== "streaming") return;
		setMessages((currentMessages) => {
			const assistantInfo = findLastAssistantMessage(currentMessages);
			if (!assistantInfo) return currentMessages;
			if (protectedStreamingAssistantRef.current?.assistantId !== assistantInfo.message.id) protectedStreamingAssistantRef.current = {
				assistantId: assistantInfo.message.id,
				anchorMessageId: currentMessages[assistantInfo.index - 1]?.id ?? null
			};
			return moveMessageToEnd(currentMessages, assistantInfo.message.id);
		});
	}, [setMessages]);
	const restoreProtectedStreamingAssistant = (0, import_react.useCallback)((assistantId) => {
		const protection = protectedStreamingAssistantRef.current;
		if (!protection || assistantId !== void 0 && protection.assistantId !== assistantId) return;
		protectedStreamingAssistantRef.current = null;
		setMessages((prevMessages) => {
			const sourceIdx = prevMessages.findIndex((m) => m.id === protection.assistantId);
			if (sourceIdx < 0) return prevMessages;
			const result = [...prevMessages];
			const [msg] = result.splice(sourceIdx, 1);
			if (!msg) return prevMessages;
			if (protection.anchorMessageId === null) result.unshift(msg);
			else {
				const anchorIdx = result.findIndex((m) => m.id === protection.anchorMessageId);
				result.splice(anchorIdx >= 0 ? anchorIdx + 1 : sourceIdx, 0, msg);
			}
			return result;
		});
	}, [setMessages]);
	const resetMatchingHydratedAssistantForReplay = (0, import_react.useCallback)((messageId) => {
		setMessages((prevMessages) => {
			const lastMessage = prevMessages[prevMessages.length - 1];
			if (!lastMessage || lastMessage.role !== "assistant" || lastMessage.id !== messageId) return prevMessages;
			replayHydratedAssistantMessageIdsRef.current.add(messageId);
			const next = [...prevMessages];
			next[next.length - 1] = {
				...lastMessage,
				parts: []
			};
			return next;
		});
	}, [setMessages]);
	const collapseHydratedReplayTextParts = (0, import_react.useCallback)((message) => {
		const parts = message.parts;
		const nextParts = parts.filter((part, index) => {
			if (part.type !== "text" || !("text" in part) || !part.text) return true;
			return !parts.some((candidate, candidateIndex) => {
				if (candidateIndex <= index) return false;
				if (candidate.type !== "text" || !("text" in candidate) || !candidate.text) return false;
				return candidate.text.startsWith(part.text);
			});
		});
		return nextParts.length === parts.length ? message : {
			...message,
			parts: nextParts
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (replayHydratedAssistantMessageIdsRef.current.size === 0) return;
		const idsToCollapse = new Set(chatMessages.filter((message) => replayHydratedAssistantMessageIdsRef.current.has(message.id) && message.role === "assistant" && collapseHydratedReplayTextParts(message) !== message).map((message) => message.id));
		if (idsToCollapse.size === 0) return;
		setMessages((prevMessages) => {
			let changed = false;
			const nextMessages = prevMessages.map((message) => {
				if (!idsToCollapse.has(message.id)) return message;
				const nextMessage = collapseHydratedReplayTextParts(message);
				if (nextMessage !== message) changed = true;
				return nextMessage;
			});
			return changed ? nextMessages : prevMessages;
		});
	}, [
		chatMessages,
		collapseHydratedReplayTextParts,
		setMessages
	]);
	const resetLocalChatState = (0, import_react.useCallback)(() => {
		markInitialMessagesSeeded();
		setMessages([]);
		setClientToolResults(/* @__PURE__ */ new Map());
		setPendingOnToolCallIds(/* @__PURE__ */ new Set());
		resetToolContinuation();
		processedToolCalls.current.clear();
		localResponseMessageIdsRef.current.clear();
		pendingReplayResumeRequestIdsRef.current.clear();
		fallbackAckedResumeRequestIdsRef.current.clear();
		replayHydratedAssistantMessageIdsRef.current.clear();
		protectedStreamingAssistantRef.current = null;
		pendingBufferedSendIdsRef.current.clear();
		customTransport.appliedChunks.clear();
		turnErrorsRef.current.clear();
		pendingTurnEndsRef.current = [];
	}, [
		markInitialMessagesSeeded,
		setMessages,
		resetToolContinuation,
		customTransport
	]);
	const sendMessageWithStreamingProtection = (0, import_react.useCallback)(async (message, options) => {
		const request = sendMessage(message, options);
		if (message !== void 0 && !(typeof message === "object" && message !== null && "messageId" in message && message.messageId != null)) protectStreamingAssistantTail();
		return request;
	}, [sendMessage, protectStreamingAssistantTail]);
	const lastMessage = chatMessages[chatMessages.length - 1];
	const pendingConfirmations = (() => {
		if (!lastMessage || lastMessage.role !== "assistant") return {
			messageId: void 0,
			toolCallIds: /* @__PURE__ */ new Set()
		};
		const pendingIds = /* @__PURE__ */ new Set();
		for (const part of lastMessage.parts ?? []) if (isToolUIPart$1(part) && part.state === "input-available" && toolsRequiringConfirmation.includes(getToolName(part))) pendingIds.add(part.toolCallId);
		return {
			messageId: lastMessage.id,
			toolCallIds: pendingIds
		};
	})();
	const pendingConfirmationsRef = (0, import_react.useRef)(pendingConfirmations);
	pendingConfirmationsRef.current = pendingConfirmations;
	const [pendingOnToolCallIds, setPendingOnToolCallIds] = (0, import_react.useState)(() => /* @__PURE__ */ new Set());
	const finishOnToolCall = (0, import_react.useCallback)((toolCallId) => {
		setPendingOnToolCallIds((prev) => {
			if (!prev.has(toolCallId)) return prev;
			const next = new Set(prev);
			next.delete(toolCallId);
			return next;
		});
	}, []);
	(0, import_react.useEffect)(() => {
		if (!experimental_automaticToolResolution) return;
		if (isResolvingToolsRef.current) return;
		const lastMsg = chatMessages[chatMessages.length - 1];
		if (!lastMsg || lastMsg.role !== "assistant") return;
		const toolCalls = lastMsg.parts.filter((part) => isToolUIPart$1(part) && part.state === "input-available" && !processedToolCalls.current.has(part.toolCallId));
		if (toolCalls.length > 0) {
			const currentTools = toolsRef.current;
			const toolCallsToResolve = toolCalls.filter((part) => isToolUIPart$1(part) && !toolsRequiringConfirmation.includes(getToolName(part)) && currentTools?.[getToolName(part)]?.execute);
			if (toolCallsToResolve.length > 0) {
				isResolvingToolsRef.current = true;
				(async () => {
					try {
						const toolResults = [];
						for (const part of toolCallsToResolve) if (isToolUIPart$1(part)) {
							let toolOutput = null;
							const toolName = getToolName(part);
							const tool = currentTools?.[toolName];
							if (tool?.execute && part.input !== void 0) try {
								toolOutput = await tool.execute(part.input);
							} catch (error) {
								toolOutput = `Error executing tool: ${error instanceof Error ? error.message : String(error)}`;
							}
							processedToolCalls.current.add(part.toolCallId);
							toolResults.push({
								toolCallId: part.toolCallId,
								toolName,
								output: toolOutput
							});
						}
						if (toolResults.length > 0) {
							const clientToolSchemas = extractClientToolSchemas(currentTools);
							for (const result of toolResults) agentRef.current.send(JSON.stringify({
								type: "cf_agent_tool_result",
								toolCallId: result.toolCallId,
								toolName: result.toolName,
								output: result.output,
								autoContinue: autoContinueAfterToolResult,
								clientTools: clientToolSchemas
							}));
							await Promise.all(toolResults.map((result) => addToolResult({
								tool: result.toolName,
								toolCallId: result.toolCallId,
								output: result.output
							})));
							setClientToolResults((prev) => {
								const newMap = new Map(prev);
								for (const result of toolResults) newMap.set(result.toolCallId, result.output);
								return newMap;
							});
							startToolContinuation();
						}
					} finally {
						isResolvingToolsRef.current = false;
						setToolResolutionTrigger((c) => c + 1);
					}
				})();
			}
		}
	}, [
		chatMessages,
		experimental_automaticToolResolution,
		addToolResult,
		toolsRequiringConfirmation,
		autoContinueAfterToolResult,
		startToolContinuation,
		toolResolutionTrigger
	]);
	const sendToolOutputToServer = (0, import_react.useCallback)((toolCallId, toolName, output, state, errorText) => {
		const shouldAutoContinue = state === "output-error" ? false : autoContinueAfterToolResult;
		agentRef.current.send(JSON.stringify({
			type: "cf_agent_tool_result",
			toolCallId,
			toolName,
			output,
			...state ? { state } : {},
			...errorText !== void 0 ? { errorText } : {},
			autoContinue: shouldAutoContinue,
			clientTools: toolsRef.current ? extractClientToolSchemas(toolsRef.current) : void 0
		}));
		if (state !== "output-error") setClientToolResults((prev) => new Map(prev).set(toolCallId, output));
		if (shouldAutoContinue) startToolContinuation();
	}, [autoContinueAfterToolResult, startToolContinuation]);
	const sendToolApprovalToServer = (0, import_react.useCallback)((toolCallId, approved) => {
		agentRef.current.send(JSON.stringify({
			type: "cf_agent_tool_approval",
			toolCallId,
			approved,
			autoContinue: autoContinueAfterToolResult
		}));
		if (autoContinueAfterToolResult) startToolContinuation();
	}, [autoContinueAfterToolResult, startToolContinuation]);
	const [isServerStreaming, setIsServerStreaming] = (0, import_react.useState)(false);
	const [unresolvedObservedRequestId, setUnresolvedObservedRequestId] = (0, import_react.useState)(null);
	const unresolvedObservedRequestIdRef = (0, import_react.useRef)(unresolvedObservedRequestId);
	unresolvedObservedRequestIdRef.current = unresolvedObservedRequestId;
	const [recoveringRequestId, setRecoveringRequestIdState] = (0, import_react.useState)(null);
	const recoveringRequestIdRef = (0, import_react.useRef)(null);
	const setRecoveringRequestId = (0, import_react.useCallback)((requestId) => {
		recoveringRequestIdRef.current = requestId;
		setRecoveringRequestIdState(requestId);
	}, []);
	(0, import_react.useEffect)(() => {
		if (status === "submitted") {
			setUnresolvedObservedRequestId(null);
			setRecoveringRequestId(null);
		}
	}, [status, setRecoveringRequestId]);
	(0, import_react.useEffect)(() => {
		if (status === "submitted" || status === "streaming") return;
		const events = pendingTurnEndsRef.current;
		if (events.length === 0) return;
		pendingTurnEndsRef.current = [];
		for (const event of events) onTurnEndRef.current?.(event);
	}, [status]);
	(0, import_react.useEffect)(() => {
		const currentOnToolCall = onToolCallRef.current;
		if (!currentOnToolCall) return;
		if (status === "streaming" || status === "submitted" || isServerStreaming || unresolvedObservedRequestId !== null || recoveringRequestId !== null) return;
		const lastMsg = chatMessages[chatMessages.length - 1];
		if (!lastMsg || lastMsg.role !== "assistant") return;
		const pendingToolCalls = lastMsg.parts.filter((part) => isToolUIPart$1(part) && part.state === "input-available" && !processedToolCalls.current.has(part.toolCallId));
		for (const part of pendingToolCalls) if (isToolUIPart$1(part)) {
			const toolCallId = part.toolCallId;
			const toolName = getToolName(part);
			processedToolCalls.current.add(toolCallId);
			setPendingOnToolCallIds((prev) => {
				if (prev.has(toolCallId)) return prev;
				const next = new Set(prev);
				next.add(toolCallId);
				return next;
			});
			const addToolOutput = (opts) => {
				sendToolOutputToServer(opts.toolCallId, toolName, opts.output, opts.state, opts.errorText);
				addToolResult({
					tool: toolName,
					toolCallId: opts.toolCallId,
					output: opts.state === "output-error" ? opts.errorText ?? "Tool execution denied by user" : opts.output
				});
			};
			let result;
			try {
				result = currentOnToolCall({
					toolCall: {
						toolCallId,
						toolName,
						input: part.input
					},
					addToolOutput
				});
			} catch (error) {
				finishOnToolCall(toolCallId);
				throw error;
			}
			Promise.resolve(result).finally(() => {
				finishOnToolCall(toolCallId);
			});
		}
	}, [
		chatMessages,
		status,
		isServerStreaming,
		unresolvedObservedRequestId,
		recoveringRequestId,
		sendToolOutputToServer,
		addToolResult,
		finishOnToolCall
	]);
	const streamStateRef = (0, import_react.useRef)({ status: "idle" });
	const [isRecovering, setIsRecovering] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const localResponseIds = localResponseMessageIdsRef.current;
		const turnErrors = turnErrorsRef.current;
		const endedTurnIds = endedTurnIdsRef.current;
		let idleProbeNeeded = false;
		let idleProbeId = null;
		let serverReportsRecovery = false;
		function reportTurnEnd(frame) {
			if (frame.error && !frame.done) {
				turnErrors.set(frame.id, frame.body);
				if (turnErrors.size > MAX_REMEMBERED_ENDED_TURNS) {
					const oldest = turnErrors.keys().next().value;
					if (oldest !== void 0) turnErrors.delete(oldest);
				}
				return;
			}
			if (!frame.done) return;
			const earlierError = turnErrors.get(frame.id);
			turnErrors.delete(frame.id);
			const outcome = frame.error ? "error" : frame.outcome ?? (earlierError !== void 0 ? "error" : "completed");
			if (outcome === "recovering" || endedTurnIds.has(frame.id)) return;
			endedTurnIds.add(frame.id);
			if (endedTurnIds.size > MAX_REMEMBERED_ENDED_TURNS) {
				const oldest = endedTurnIds.values().next().value;
				if (oldest !== void 0) endedTurnIds.delete(oldest);
			}
			const error = frame.error ? frame.body : earlierError;
			const event = {
				requestId: frame.id,
				...frame.messageIds ? { messageIds: frame.messageIds } : {},
				outcome,
				...outcome === "error" && error ? { error } : {},
				replay: frame.replay === true
			};
			if (localRequestIdsRef.current.has(frame.id) && (statusRef.current === "submitted" || statusRef.current === "streaming")) pendingTurnEndsRef.current.push(event);
			else onTurnEndRef.current?.(event);
		}
		/**
		* Unified message handler that parses JSON once and dispatches based on type.
		* Avoids duplicate parsing overhead from separate listeners.
		*/
		function onAgentMessage(event) {
			if (typeof event.data !== "string") return;
			let data;
			try {
				data = JSON.parse(event.data);
			} catch (_error) {
				return;
			}
			switch (data.type) {
				case "cf_agent_chat_clear":
					streamStateRef.current = transition(streamStateRef.current, { type: "clear" }).state;
					setIsServerStreaming(false);
					setUnresolvedObservedRequestId(null);
					setRecoveringRequestId(null);
					setIsRecovering(false);
					resetLocalChatState();
					break;
				case "cf_agent_chat_recovering":
					setIsRecovering(Boolean(data.recovering));
					serverReportsRecovery = Boolean(data.recovering);
					if (!data.recovering) setRecoveringRequestId(null);
					break;
				case "cf_agent_chat_messages": {
					const bufferedSendIds = data.connect ? new Set(pendingBufferedSendIdsRef.current) : /* @__PURE__ */ new Set();
					pendingBufferedSendIdsRef.current.clear();
					setMessages((currentMessages) => {
						let next = preserveProtectedStreamingAssistant(data.messages, currentMessages);
						const observed = streamStateRef.current;
						if (observed.status === "observing" && observed.accumulator.parts.length > 0) {
							const snapshotIdx = next.findIndex((m) => m.id === observed.accumulator.messageId);
							const snapshotParts = snapshotIdx >= 0 ? next[snapshotIdx].parts.length : 0;
							if (observed.accumulator.parts.length >= snapshotParts && !observedDivergesFrom(observed.accumulator, next)) next = observed.accumulator.mergeInto(next);
						}
						return restoreBufferedSends(next, currentMessages, bufferedSendIds);
					});
					break;
				}
				case "cf_agent_message_updated":
					setMessages((prevMessages) => {
						const updatedMessage = data.message;
						let idx = prevMessages.findIndex((m) => m.id === updatedMessage.id);
						if (idx < 0) {
							const updatedToolCallIds = new Set(updatedMessage.parts.filter((p) => "toolCallId" in p && p.toolCallId).map((p) => p.toolCallId));
							if (updatedToolCallIds.size > 0) idx = prevMessages.findIndex((m) => m.parts.some((p) => "toolCallId" in p && updatedToolCallIds.has(p.toolCallId)));
						}
						if (idx >= 0) {
							const updated = [...prevMessages];
							updated[idx] = {
								...updatedMessage,
								id: prevMessages[idx].id
							};
							return updated;
						}
						return prevMessages;
					});
					break;
				case "cf_agent_stream_resume_none": {
					const handled = customTransport.handleStreamResumeNone(data);
					const answersIdleProbe = idleProbeId !== null && data.probeId === idleProbeId;
					if (answersIdleProbe) idleProbeId = null;
					if ((handled || answersIdleProbe) && data.reason === STREAM_RESUME_NONE_REASONS.IDLE && typeof data.probeId === "string") {
						const result = transition(streamStateRef.current, { type: "clear" });
						streamStateRef.current = result.state;
						setIsServerStreaming(result.isStreaming);
						setUnresolvedObservedRequestId(null);
						if (!serverReportsRecovery) setRecoveringRequestId(null);
						if (observedToolContinuationRequestIdRef.current !== null) resetToolContinuation();
					}
					break;
				}
				case "cf_agent_stream_pending":
					customTransport.handleStreamPending();
					break;
				case "cf_agent_stream_resuming": {
					setUnresolvedObservedRequestId((current) => current === data.id ? current : null);
					if (data.probeId !== void 0 && data.probeId === idleProbeId) idleProbeId = null;
					const isEarlyToolContinuation = resumingToolContinuationRef.current && !customTransport.isAwaitingResume();
					if (!resume && !customTransport.isAwaitingResume()) {
						if (!isEarlyToolContinuation) {
							if (data.probeId === void 0) setUnresolvedObservedRequestId(data.id);
							if (recoveringRequestIdRef.current !== null && recoveringRequestIdRef.current !== data.id) setRecoveringRequestId(null);
							return;
						}
					}
					if (!resumingToolContinuationRef.current) pendingReplayResumeRequestIdsRef.current.add(data.id);
					if (customTransport.handleStreamResuming(data)) return;
					if (localRequestIdsRef.current.has(data.id)) return;
					if (fallbackAckedResumeRequestIdsRef.current.has(data.id)) return;
					if (isEarlyToolContinuation) {
						pendingToolContinuationRef.current = false;
						observedToolContinuationRequestIdRef.current = data.id;
						if (continuationLaunchTimerRef.current) {
							clearTimeout(continuationLaunchTimerRef.current);
							continuationLaunchTimerRef.current = null;
						}
					}
					streamStateRef.current = transition(streamStateRef.current, {
						type: "resume-fallback",
						streamId: data.id,
						messageId: nanoid()
					}).state;
					customTransport.observeServerTurn(data.id);
					setIsServerStreaming(true);
					if (recoveringRequestIdRef.current !== null && recoveringRequestIdRef.current !== data.id) setRecoveringRequestId(null);
					setIsRecovering(false);
					fallbackAckedResumeRequestIdsRef.current.add(data.id);
					agentRef.current.send(JSON.stringify({
						type: "cf_agent_stream_resume_ack",
						id: data.id
					}));
					break;
				}
				case "cf_agent_use_chat_response": {
					if (data.done || data.error) setUnresolvedObservedRequestId((current) => current === data.id ? null : current);
					if (data.done && data.outcome === "recovering") setRecoveringRequestId(data.id);
					else if (recoveringRequestIdRef.current !== null && recoveringRequestIdRef.current !== data.id && !data.replay && data.outcome !== "skipped") setRecoveringRequestId(null);
					reportTurnEnd(data);
					if (localRequestIdsRef.current.has(data.id)) {
						if (data.body?.trim()) try {
							const chunkData = JSON.parse(data.body);
							if (chunkData.type === "start" && typeof chunkData.messageId === "string") {
								const messageId = chunkData.messageId;
								localResponseIds.set(data.id, messageId);
								if (!data.continuation) {
									if (protectedStreamingAssistantRef.current?.assistantId !== messageId) setMessages((currentMessages) => {
										const idx = currentMessages.findIndex((message) => message.id === messageId);
										protectedStreamingAssistantRef.current = {
											assistantId: messageId,
											anchorMessageId: idx >= 0 ? currentMessages[idx - 1]?.id ?? null : currentMessages[currentMessages.length - 1]?.id ?? null
										};
										return currentMessages;
									});
								}
								if (data.replay && !data.continuation && !resumingToolContinuationRef.current && observedToolContinuationRequestIdRef.current !== data.id) {
									pendingReplayResumeRequestIdsRef.current.delete(data.id);
									resetMatchingHydratedAssistantForReplay(messageId);
								}
							}
						} catch {}
						if (data.done || data.error || data.replayComplete) pendingReplayResumeRequestIdsRef.current.delete(data.id);
						if (data.done || data.error) {
							if (streamStateRef.current.status === "observing" && streamStateRef.current.streamId === data.id) {
								streamStateRef.current = { status: "idle" };
								setIsServerStreaming(false);
							}
							customTransport.handleServerTurnCompleted(data.id);
							restoreProtectedStreamingAssistant(localResponseIds.get(data.id));
							localResponseIds.delete(data.id);
							localRequestIdsRef.current.delete(data.id);
							fallbackAckedResumeRequestIdsRef.current.delete(data.id);
							if (observedToolContinuationRequestIdRef.current === data.id) resetToolContinuation();
						}
						return;
					}
					let chunkData;
					if (data.replay && streamStateRef.current.status !== "observing" && !pendingReplayResumeRequestIdsRef.current.has(data.id)) return;
					if (data.done && !data.error && !(streamStateRef.current.status === "observing" && streamStateRef.current.streamId === data.id) && !pendingReplayResumeRequestIdsRef.current.has(data.id) && observedToolContinuationRequestIdRef.current !== data.id) {
						customTransport.appliedChunks.forget(data.id);
						customTransport.handleServerTurnCompleted(data.id);
						fallbackAckedResumeRequestIdsRef.current.delete(data.id);
						break;
					}
					if (data.error) {
						pendingReplayResumeRequestIdsRef.current.delete(data.id);
						customTransport.appliedChunks.forget(data.id);
						customTransport.handleServerTurnCompleted(data.id);
						fallbackAckedResumeRequestIdsRef.current.delete(data.id);
						setIsRecovering(false);
						if (streamStateRef.current.status === "idle" || streamStateRef.current.streamId === data.id) {
							const result = transition(streamStateRef.current, { type: "clear" });
							streamStateRef.current = result.state;
							setIsServerStreaming(result.isStreaming);
						}
						if (observedToolContinuationRequestIdRef.current === data.id) resetToolContinuation();
						break;
					}
					const appliedReplay = customTransport.appliedChunks.isAppliedReplay(data.id, data);
					if (data.body?.trim()) try {
						chunkData = JSON.parse(data.body);
						if (data.replay && !data.continuation && !resumingToolContinuationRef.current && observedToolContinuationRequestIdRef.current !== data.id && typeof chunkData.messageId === "string" && chunkData.type === "start") {
							pendingReplayResumeRequestIdsRef.current.delete(data.id);
							resetMatchingHydratedAssistantForReplay(chunkData.messageId);
						}
						if (typeof chunkData.type === "string" && chunkData.type.startsWith("data-") && !appliedReplay && onDataRef.current) onDataRef.current(chunkData);
					} catch (parseError) {
						console.warn("[useAgentChat] Failed to parse stream chunk:", parseError instanceof Error ? parseError.message : parseError, "body:", data.body?.slice(0, 100));
					}
					if (data.done || data.replayComplete) pendingReplayResumeRequestIdsRef.current.delete(data.id);
					if (data.done) {
						customTransport.handleServerTurnCompleted(data.id);
						fallbackAckedResumeRequestIdsRef.current.delete(data.id);
						if (data.outcome !== "recovering") setIsRecovering(false);
					}
					const completedObservedToolContinuation = data.done && observedToolContinuationRequestIdRef.current === data.id;
					const alreadyApplied = appliedReplay && chunkData?.type !== "start";
					if (data.done) customTransport.appliedChunks.forget(data.id);
					else if (!alreadyApplied) customTransport.appliedChunks.record(data.id, data.seq);
					const result = transition(streamStateRef.current, {
						type: "response",
						streamId: data.id,
						messageId: nanoid(),
						chunkData: alreadyApplied ? void 0 : chunkData,
						done: data.done,
						error: data.error,
						replay: data.replay,
						replayComplete: data.replayComplete,
						continuation: data.continuation
					});
					streamStateRef.current = result.state;
					if (result.messagesUpdate) setMessages(result.messagesUpdate);
					setIsServerStreaming(result.isStreaming);
					if (completedObservedToolContinuation) resetToolContinuation();
					break;
				}
			}
		}
		const fallbackAckedResumeRequestIds = fallbackAckedResumeRequestIdsRef.current;
		let socketIsOpen = false;
		let sawClose = false;
		let disposed = false;
		const clearFallbackObserver = () => {
			if (streamStateRef.current.status === "observing") setUnresolvedObservedRequestId(streamStateRef.current.streamId);
			const result = transition(streamStateRef.current, { type: "clear" });
			streamStateRef.current = result.state;
			setIsServerStreaming(result.isStreaming);
			if (observedToolContinuationRequestIdRef.current !== null) resetToolContinuation();
		};
		const tryPendingReconnectProbe = () => {
			if (disposed || !socketIsOpen || !reconnectProbePendingRef.current) return;
			if (!resume) {
				reconnectProbePendingRef.current = false;
				if (idleProbeNeeded) {
					idleProbeNeeded = false;
					idleProbeId = nanoid();
					agentRef.current.send(JSON.stringify({
						type: "cf_agent_stream_resume_request",
						probeId: idleProbeId
					}));
				}
				return;
			}
			if (customTransport.retryPendingResume()) {
				reconnectProbePendingRef.current = false;
				return;
			}
			const canReconcileObservedContinuation = observedToolContinuationRequestIdRef.current !== null;
			if (statusRef.current !== "ready" && statusRef.current !== "error" || resumingToolContinuationRef.current && !canReconcileObservedContinuation || resumeOperationRef.current !== null) return;
			reconnectProbePendingRef.current = false;
			resumeStreamRef.current().catch(() => {});
		};
		reconnectProbeRunnerRef.current = tryPendingReconnectProbe;
		function onAgentClose() {
			socketIsOpen = false;
			sawClose = true;
			serverReportsRecovery = false;
			fallbackAckedResumeRequestIds.clear();
			protectedStreamingAssistantRef.current = null;
			const unfinishedTurnId = customTransport.activeServerTurnId;
			if (unfinishedTurnId !== null) setUnresolvedObservedRequestId(unfinishedTurnId);
			if (!resume) {
				idleProbeNeeded ||= unfinishedTurnId !== null || streamStateRef.current.status === "observing" || unresolvedObservedRequestIdRef.current !== null || recoveringRequestIdRef.current !== null;
				clearFallbackObserver();
			}
		}
		function onAgentOpen() {
			socketIsOpen = true;
			if (!sawClose) return;
			sawClose = false;
			reconnectProbePendingRef.current = true;
			tryPendingReconnectProbe();
		}
		agent.addEventListener("message", onAgentMessage);
		agent.addEventListener("close", onAgentClose);
		agent.addEventListener("open", onAgentOpen);
		return () => {
			disposed = true;
			if (reconnectProbeRunnerRef.current === tryPendingReconnectProbe) reconnectProbeRunnerRef.current = null;
			reconnectProbePendingRef.current = false;
			agent.removeEventListener("message", onAgentMessage);
			agent.removeEventListener("close", onAgentClose);
			agent.removeEventListener("open", onAgentOpen);
			fallbackAckedResumeRequestIds.clear();
			streamStateRef.current = { status: "idle" };
			setIsServerStreaming(false);
			setUnresolvedObservedRequestId(null);
			setIsRecovering(false);
			protectedStreamingAssistantRef.current = null;
			localResponseIds.clear();
			customTransport.resetResumeState();
			invalidateResumeGeneration();
		};
	}, [
		agent,
		setMessages,
		resume,
		customTransport,
		preserveProtectedStreamingAssistant,
		resetToolContinuation,
		resetMatchingHydratedAssistantForReplay,
		restoreProtectedStreamingAssistant,
		resetLocalChatState,
		invalidateResumeGeneration,
		setRecoveringRequestId
	]);
	(0, import_react.useEffect)(() => {
		if (!resume) return;
		resumeStream().catch(() => {});
	}, [resume, resumeStream]);
	(0, import_react.useEffect)(() => {
		reconnectProbeRunnerRef.current?.();
	}, [isToolContinuation, status]);
	const addToolResultAndSendMessage = async (args) => {
		const { toolCallId } = args;
		const toolName = "tool" in args ? args.tool : "";
		const output = "output" in args ? args.output : void 0;
		agentRef.current.send(JSON.stringify({
			type: "cf_agent_tool_result",
			toolCallId,
			toolName,
			output,
			autoContinue: autoContinueAfterToolResult,
			clientTools: toolsRef.current ? extractClientToolSchemas(toolsRef.current) : void 0
		}));
		setClientToolResults((prev) => new Map(prev).set(toolCallId, output));
		addToolResult(args);
		if (autoContinueAfterToolResult) startToolContinuation();
		if (!autoContinueAfterToolResult) {
			if (!autoSendAfterAllConfirmationsResolved) {
				sendMessage();
				return;
			}
			const pending = pendingConfirmationsRef.current?.toolCallIds;
			if (!pending) {
				sendMessage();
				return;
			}
			const wasLast = pending.size === 1 && pending.has(toolCallId);
			if (pending.has(toolCallId)) pending.delete(toolCallId);
			if (wasLast || pending.size === 0) sendMessage();
		}
	};
	const addToolApprovalResponseAndNotifyServer = (args) => {
		const { id: approvalId, approved } = args;
		let toolCallId;
		setMessages((currentMessages) => {
			for (const msg of currentMessages) for (const part of msg.parts) if ("toolCallId" in part && "approval" in part && part.approval?.id === approvalId) {
				toolCallId = part.toolCallId;
				return currentMessages;
			}
			return currentMessages;
		});
		if (toolCallId) sendToolApprovalToServer(toolCallId, approved);
		else console.warn(`[useAgentChat] addToolApprovalResponse: Could not find toolCallId for approval ID "${approvalId}". Server will not be notified, which may cause duplicate messages.`);
		addToolApprovalResponse(args);
	};
	const messagesWithToolResults = (0, import_react.useMemo)(() => {
		if (clientToolResults.size === 0) return chatMessages;
		return chatMessages.map((msg) => ({
			...msg,
			parts: msg.parts.map((p) => {
				if (!("toolCallId" in p) || !("state" in p) || p.state !== "input-available" || !clientToolResults.has(p.toolCallId)) return p;
				return {
					...p,
					state: "output-available",
					output: clientToolResults.get(p.toolCallId)
				};
			})
		}));
	}, [chatMessages, clientToolResults]);
	(0, import_react.useEffect)(() => {
		const currentToolCallIds = /* @__PURE__ */ new Set();
		for (const msg of chatMessages) for (const part of msg.parts) if ("toolCallId" in part && part.toolCallId) currentToolCallIds.add(part.toolCallId);
		const isStale = (id) => !currentToolCallIds.has(id);
		if ([...clientToolResultsRef.current.keys()].some(isStale)) setClientToolResults((prev) => {
			const next = /* @__PURE__ */ new Map();
			for (const [id, output] of prev) if (!isStale(id)) next.set(id, output);
			return next.size === prev.size ? prev : next;
		});
		for (const toolCallId of processedToolCalls.current) if (!currentToolCallIds.has(toolCallId)) processedToolCalls.current.delete(toolCallId);
	}, [chatMessages]);
	const addToolOutput = (0, import_react.useCallback)((opts) => {
		const toolName = opts.toolName ?? "";
		sendToolOutputToServer(opts.toolCallId, toolName, opts.output, opts.state, opts.errorText);
		addToolResult({
			tool: toolName,
			toolCallId: opts.toolCallId,
			output: opts.state === "output-error" ? opts.errorText ?? "Tool execution denied by user" : opts.output
		});
	}, [sendToolOutputToServer, addToolResult]);
	const lastAssistantMessage = messagesWithToolResults[messagesWithToolResults.length - 1];
	const hasPendingClientToolCalls = (() => {
		if (pendingOnToolCallIds.size === 0 && !tools) return false;
		if (!lastAssistantMessage || lastAssistantMessage.role !== "assistant") return false;
		for (const part of lastAssistantMessage.parts) {
			if (!isToolUIPart$1(part)) continue;
			if (part.state !== "input-available") continue;
			const toolName = getToolName(part);
			if (toolsRequiringConfirmation.includes(toolName)) continue;
			if (pendingOnToolCallIds.has(part.toolCallId)) return true;
			if (tools?.[toolName]?.execute) return true;
		}
		return false;
	})();
	const effectiveIsServerStreaming = isServerStreaming || hasPendingClientToolCalls;
	const isStreaming = status === "streaming" || effectiveIsServerStreaming;
	return {
		...useChatHelpers,
		resumeStream,
		messages: messagesWithToolResults,
		isServerStreaming: effectiveIsServerStreaming,
		isStreaming,
		/**
		* True while a durable chat turn is being recovered (interrupted by a
		* deploy/eviction or a stream-stall watchdog abort and now resuming, #1620).
		* Distinct from `isStreaming` \u2014 a recovering turn isn't producing tokens
		* yet. Render a "recovering\u2026" hint; most UIs treat `isStreaming ||
		* isRecovering` as "busy". Cleared automatically on the next stream/terminal.
		*/
		isRecovering,
		isToolContinuation,
		connectionError: agent.connectionError ?? null,
		sendMessage: sendMessageWithStreamingProtection,
		stop: stopWithToolContinuationAbort,
		/**
		* Provide output for a tool call. Use this for tools that require user interaction
		* or client-side execution.
		*/
		addToolOutput,
		/**
		* @deprecated Use `addToolOutput` instead.
		*/
		addToolResult: addToolResultAndSendMessage,
		/**
		* Respond to a tool approval request. Use this for tools with `needsApproval`.
		* This wrapper notifies the server before updating local state, preventing
		* duplicate messages when sendMessage() is called afterward.
		*/
		addToolApprovalResponse: addToolApprovalResponseAndNotifyServer,
		clearHistory: () => {
			resetLocalChatState();
			agent.send(JSON.stringify({ type: "cf_agent_chat_clear" }));
		},
		setMessages: (messagesOrUpdater) => {
			setMessages((currentMessages) => {
				const resolvedMessages = typeof messagesOrUpdater === "function" ? messagesOrUpdater(currentMessages) : messagesOrUpdater;
				if (resolvedMessages.length === 0) markInitialMessagesSeeded();
				if (syncMessagesToServer) agent.send(JSON.stringify({
					messages: resolvedMessages,
					type: "cf_agent_chat_messages"
				}));
				return resolvedMessages;
			});
		}
	};
}
//#endregion
//#region node_modules/.pnpm/@cloudflare+think@0.19.0_@ai-sdk+provider@4.0.4_@ai-sdk+react@3.0.211_react@19.2.4_zod@_77fa1b71a9578cd84cc78d01d11cef3f/node_modules/@cloudflare/think/dist/react.js
var _thinkReactWarnings = /* @__PURE__ */ new Set();
function isProductionRuntime() {
	return true;
}
/**
* Think-facing chat hook.
*
* On Think, `setMessages` updates the local view only. It does not persist a
* client-pushed transcript because Think's Session tree is server-authoritative.
* Use `clearHistory()` for persisted clears.
*/
function useAgentChat(options) {
	const maybeSyncMessagesToServer = options.syncMessagesToServer;
	if (!isProductionRuntime() && maybeSyncMessagesToServer && !_thinkReactWarnings.has("syncMessagesToServer")) {
		_thinkReactWarnings.add("syncMessagesToServer");
		console.warn("[@cloudflare/think] `syncMessagesToServer` has no effect: Think ignores client-pushed transcripts. `setMessages` updates the local view only. Use `clearHistory()` for persisted clears.");
	}
	return useAgentChat$1({
		...options,
		syncMessagesToServer: false
	});
}
//#endregion
//#region src/client/features/sam/ChatComposer.tsx
function ChatComposer({ busy, onSend, onStop }) {
	const [value, setValue] = (0, import_react.useState)("");
	function submit() {
		const text = value.trim();
		if (!text || busy) return;
		onSend(text);
		setValue("");
	}
	function handleSubmit(event) {
		event.preventDefault();
		submit();
	}
	function handleKey(event) {
		if (event.key === "Enter" && !event.shiftKey) {
			event.preventDefault();
			submit();
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
		onSubmit: handleSubmit,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InputGroup, {
			className: "items-end rounded-xl bg-card has-disabled:bg-card has-disabled:opacity-100 dark:has-disabled:bg-input/30",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupTextarea, {
				value,
				onChange: (event) => setValue(event.target.value),
				onKeyDown: handleKey,
				rows: 1,
				placeholder: "Ask SAM to research, analyze, or track anything\u2026",
				className: "max-h-40 min-h-0 px-3 leading-relaxed"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, {
				align: "inline-end",
				children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupButton, {
					variant: "secondary",
					size: "icon-sm",
					className: "rounded-full",
					"aria-label": "Stop",
					onClick: onStop,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Square, { className: "size-3.5 fill-current" })
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupButton, {
					type: "submit",
					variant: "default",
					size: "icon-sm",
					className: "rounded-full",
					"aria-label": "Send message",
					disabled: !value.trim(),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, {})
				})
			})]
		})
	});
}
//#endregion
//#region src/client/components/chat/ChatMessage.tsx
function humanizeToolLabel(partType) {
	const name = partType.replace(/^tool-/, "").replace(/_/g, " ");
	return name.charAt(0).toUpperCase() + name.slice(1);
}
function skillNameFromPart(part) {
	if (part.type !== "tool-activate_skill" || !("input" in part)) return null;
	const input = part.input;
	return typeof input === "object" && input !== null && "name" in input && typeof input.name === "string" ? input.name : null;
}
function messageHasVisibleContent(message) {
	return message.parts.some((part) => part.type === "text" && part.text.trim().length > 0 || part.type === "reasoning" && part.text.trim().length > 0 || part.type.startsWith("tool-"));
}
function messageText(message) {
	return message.parts.filter((part) => part.type === "text").map((part) => part.text).join("\n").trim();
}
function MessageActions({ message, onUndo, onStartEdit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex gap-0.5 text-muted-foreground reveal-on-hover ${message.role === "user" ? "justify-end" : ""}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
				value: messageText(message),
				successMessage: "Message copied",
				label: "Copy message",
				variant: "ghost",
				size: "icon-xs"
			}),
			onStartEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon-xs",
				"aria-label": "Edit message",
				title: "Edit and resend",
				onClick: onStartEdit,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pencil, {})
			}) : null,
			onUndo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon-xs",
				"aria-label": "Undo from this message",
				title: "Undo \u2014 remove this message and everything after it",
				onClick: onUndo,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, {})
			}) : null
		]
	});
}
function ReasoningBlock({ part, live }) {
	const isStreaming = live && part.state === "streaming";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Collapsible, {
		className: "text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CollapsibleTrigger, {
			className: "group inline-flex items-center gap-1.5 rounded-sm text-xs outline-none hover:text-foreground focus-visible:ring-3 focus-visible:ring-ring/50",
			children: [isStreaming ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-3 transition-transform group-data-panel-open:rotate-90" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: isStreaming ? "Thinking\u2026" : "Thought process" })]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CollapsibleContent, {
			className: "mt-1.5 whitespace-pre-wrap border-l-2 border-border pl-3 text-xs",
			children: part.text
		})]
	});
}
function ToolBadge({ part, live }) {
	const label = humanizeToolLabel(part.type);
	const skillName = skillNameFromPart(part);
	const runningText = skillName ? `Activating ${skillName}` : label;
	const doneText = skillName ? `Skill: ${skillName}` : label;
	const state = "state" in part ? part.state : void 0;
	const isDone = state === "output-available";
	const isError = state === "output-error" || !isDone && !live;
	const isRunning = !isError && !isDone;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
		variant: isError ? "destructive" : "secondary",
		className: "h-6 px-2.5 font-normal",
		children: [isRunning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {}) : isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {}), isRunning ? `${runningText}\u2026` : doneText]
	});
}
/**
* One chat message bubble. User turns render as a right-aligned bubble;
* assistant turns render each part (reasoning, markdown text, tool badges) in
* document order, flush with the column.
*
* Every settled message gets a hover copy button. User messages additionally
* get undo (rewind the conversation to before this message) and edit (rewind,
* then resend the edited text) when the chat passes the handlers \u2014 both need
* server support, so chats opt in.
*/
function ChatMessage({ message, streaming, onUndo, onEdit }) {
	const [editing, setEditing] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)("");
	if (message.role === "user") {
		if (editing && onEdit) {
			const submit = () => {
				const text = draft.trim();
				setEditing(false);
				if (text && text !== messageText(message)) onEdit(text);
			};
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col items-end gap-1.5 pl-8 sm:pl-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					className: "max-h-36 max-w-xl",
					rows: Math.min(6, Math.max(2, draft.split("\n").length)),
					value: draft,
					autoFocus: true,
					onChange: (event) => setDraft(event.target.value),
					onKeyDown: (event) => {
						if (event.key === "Enter" && !event.shiftKey) {
							event.preventDefault();
							submit();
						}
						if (event.key === "Escape") setEditing(false);
					}
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "xs",
						onClick: () => setEditing(false),
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "xs",
						onClick: submit,
						children: "Save & resend"
					})]
				})]
			});
		}
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "group flex flex-col gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end pl-8 sm:pl-16",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rounded-xl rounded-br-sm bg-primary px-4 py-2.5 text-sm text-primary-foreground",
					children: message.parts.map((part, index) => part.type === "text" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "whitespace-pre-wrap",
						children: part.text
					}, index) : null)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageActions, {
				message,
				onUndo,
				onStartEdit: onEdit ? () => {
					setDraft(messageText(message));
					setEditing(true);
				} : void 0
			})]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "group flex flex-col gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "min-w-0 space-y-2 text-sm",
			children: message.parts.map((part, index) => {
				if (part.type === "reasoning") return part.text.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReasoningBlock, {
					part,
					live: Boolean(streaming)
				}, index) : null;
				if (part.type === "text") return part.text.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Markdown, { children: part.text }, index) : null;
				if (part.type.startsWith("tool-")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolBadge, {
					part,
					live: Boolean(streaming)
				}, index);
				return null;
			})
		}), streaming ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageActions, { message })]
	});
}
//#endregion
//#region src/client/components/chat/useStickToBottom.ts
var BOTTOM_THRESHOLD_PX = 64;
/**
* Keeps a chat scroll container pinned to the bottom while the user follows
* along, and stops pinning as soon as they scroll up \u2014 until they scroll back
* to the bottom, or `pinToBottom` is called because they sent a message.
*
* Pinned-ness is tracked from real scroll events rather than measured when
* `messages` changes: by the time the effect runs the new chunk is already in
* the DOM, so the distance to the bottom would look large and unpin mid-stream.
*/
function useStickToBottom(messages, status) {
	const scrollRef = (0, import_react.useRef)(null);
	const pinnedRef = (0, import_react.useRef)(true);
	(0, import_react.useLayoutEffect)(() => {
		const el = scrollRef.current;
		if (el && pinnedRef.current) el.scrollTop = el.scrollHeight;
	}, [messages, status]);
	const onScroll = () => {
		const el = scrollRef.current;
		if (!el) return;
		pinnedRef.current = el.scrollHeight - el.scrollTop - el.clientHeight <= BOTTOM_THRESHOLD_PX;
	};
	const pinToBottom = () => {
		pinnedRef.current = true;
		const el = scrollRef.current;
		if (el) el.scrollTop = el.scrollHeight;
	};
	return {
		scrollRef,
		onScroll,
		pinToBottom
	};
}
//#endregion
//#region src/client/features/sam/SamConversation.tsx
var SUGGESTIONS = [
	"What keywords should I focus on next?",
	"Who are my top SERP competitors?",
	"How is my Search Console traffic trending?",
	"Find quick-win keywords I already rank for"
];
function SamConversation({ projectId, sessionId }) {
	const agent = useAgent({
		agent: "sam-chat",
		name: sessionId
	});
	const { messages, sendMessage, setMessages, clearHistory, status, stop, isRecovering, connectionError } = useAgentChat({
		agent,
		experimental_throttle: 50
	});
	const isBusy = status === "submitted" || status === "streaming" || isRecovering;
	const { scrollRef, onScroll, pinToBottom } = useStickToBottom(messages, status);
	const sendText = (text, source = "composer") => {
		pinToBottom();
		captureClientEvent("sam:message_send", {
			session_id: sessionId,
			project_id: projectId,
			source,
			chars: text.length
		});
		sendMessage({ text });
	};
	(0, import_react.useEffect)(() => {
		if (status !== "error" && !connectionError) return;
		captureClientEvent("sam:client_error", {
			session_id: sessionId,
			project_id: projectId,
			kind: connectionError ? "connection" : "turn",
			code: connectionError?.code,
			reason: connectionError?.reason
		});
	}, [
		status,
		connectionError,
		sessionId,
		projectId
	]);
	const [hasConnected, setHasConnected] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (agent.identified) setHasConnected(true);
	}, [agent.identified]);
	const isReconnecting = hasConnected && !agent.identified && !connectionError;
	const rewindTo = async (messageId) => {
		if (!(await fetch(`/agents/sam-chat/${sessionId}/rewind`, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({ messageId })
		}).catch(() => null))?.ok) {
			toast.error("Couldn't change the conversation. Try again.");
			return false;
		}
		const fresh = await fetch(`/agents/sam-chat/${sessionId}/get-messages`).then((res) => res.ok ? res.json() : null);
		if (Array.isArray(fresh)) setMessages(fresh);
		return true;
	};
	const undoFrom = (messageId) => void rewindTo(messageId);
	const editAndResend = async (messageId, newText, source = "edit") => {
		if (await rewindTo(messageId)) sendText(newText, source);
	};
	const lastUserMessage = t(messages, (m) => m.role === "user");
	const retryLast = () => {
		if (!lastUserMessage) return;
		const text = lastUserMessage.parts.filter((part) => part.type === "text").map((part) => part.text).join("\n");
		editAndResend(lastUserMessage.id, text, "retry");
	};
	const wasBusyRef = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (isBusy) {
			wasBusyRef.current = true;
			return;
		}
		if (wasBusyRef.current) {
			wasBusyRef.current = false;
			invalidateSamSessions(projectId);
		}
	}, [isBusy, projectId]);
	const lastMessage = messages[messages.length - 1];
	const showTyping = isBusy && (lastMessage?.role !== "assistant" || !messageHasVisibleContent(lastMessage));
	const showSuggestions = messages.length === 0 && !isBusy;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-w-0 flex-1 flex-col",
		children: [
			null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: scrollRef,
				onScroll,
				className: "flex-1 overflow-y-auto px-5 py-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-2xl space-y-6",
					children: [
						messages.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 text-sm text-foreground/80",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Hey, I\u2019m SAM \u2014 your in-app SEO agent. I can research keywords, size up competitors, read your SERPs, backlinks, rank tracking and Search Console, and turn it into next steps for this project." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Ask me anything, or start with one of these:" })]
						}) : null,
						messages.map((message, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatMessage, {
							message,
							streaming: isBusy && index === messages.length - 1 && message.role === "assistant",
							onUndo: message.role === "user" ? () => undoFrom(message.id) : void 0,
							onEdit: message.role === "user" ? (newText) => void editAndResend(message.id, newText) : void 0
						}, message.id)),
						showTyping ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-2 pt-1 text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 animate-bounce rounded-full bg-current [animation-delay:-0.3s]" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 animate-bounce rounded-full bg-current [animation-delay:-0.15s]" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-1.5 animate-bounce rounded-full bg-current" })
								]
							})
						}) : null,
						isRecovering ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Saving the reply that got cut off\u2026"
						}) : null,
						status === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
							variant: "inline",
							message: "SAM stopped before finishing this reply.",
							onRetry: lastUserMessage ? retryLast : void 0,
							isRetrying: isBusy
						}) : null,
						showSuggestions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: SUGGESTIONS.map((question) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								className: "rounded-full text-xs text-muted-foreground",
								onClick: () => sendText(question, "suggestion"),
								children: question
							}, question))
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-shrink-0 border-t border-border px-5 py-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto w-full max-w-2xl",
					children: [connectionError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorState, {
							variant: "inline",
							message: "Lost the connection to SAM.",
							action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => agent.reconnect(),
								children: "Reconnect"
							})
						})
					}) : isReconnecting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-xs text-muted-foreground",
						children: "Reconnecting\u2026"
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChatComposer, {
						busy: isBusy,
						onSend: sendText,
						onStop: () => void stop()
					})]
				})
			})
		]
	});
}
//#endregion
//#region src/client/features/sam/SamChat.tsx
/**
* The SAM route's content: the active conversation, full-width. The chat
* history list lives in the app sidebar's Chat tab (SamSidebarPanel); this
* component gates on the beta opt-in, then lands the user in the most recent
* session, creating one when the project has none.
*/
function SamChat({ projectId, activeSessionId }) {
	const optedIn = useSamBetaOptIn();
	const access = useSamAccess(projectId);
	const creating = (0, import_react.useRef)(false);
	const [createError, setCreateError] = (0, import_react.useState)(null);
	const { sessionsQuery, sessions, goToSession, createSession } = useSamSessions(projectId, {
		replace: true,
		onCreateError: setCreateError,
		onCreateSettled: () => {
			creating.current = false;
		}
	});
	const { mutate: createSessionMutate } = createSession;
	const startChat = (0, import_react.useCallback)(() => {
		creating.current = true;
		setCreateError(null);
		createSessionMutate();
	}, [createSessionMutate]);
	const firstSessionId = sessions[0]?.id;
	(0, import_react.useEffect)(() => {
		if (activeSessionId || !optedIn || access.status !== "ready") return;
		if (firstSessionId) {
			goToSession(firstSessionId);
			return;
		}
		if (!sessionsQuery.isSuccess || creating.current) return;
		startChat();
	}, [
		activeSessionId,
		optedIn,
		access.status,
		firstSessionId,
		sessionsQuery.isSuccess,
		goToSession,
		startChat
	]);
	const activeSession = sessions.find((session) => session.id === activeSessionId);
	const isMissing = activeSessionId !== void 0 && !activeSession && sessionsQuery.data !== void 0;
	const [recheckedSessionId, setRecheckedSessionId] = (0, import_react.useState)();
	const { refetch: refetchSessions } = sessionsQuery;
	(0, import_react.useEffect)(() => {
		if (!isMissing || recheckedSessionId === activeSessionId) return;
		refetchSessions().finally(() => setRecheckedSessionId(activeSessionId));
	}, [
		isMissing,
		recheckedSessionId,
		activeSessionId,
		refetchSessions
	]);
	if (!optedIn) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SamBetaGate, { onContinue: optInToSamBeta }) });
	if (access.status === "checking") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, { pending: true });
	if (access.status === "error") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
		error: access.error,
		fallback: "Could not load AI agent setup status.",
		onRetry: access.onRetry,
		isRetrying: access.isRetrying
	}) });
	if (access.status === "setup") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, {
		size: "lg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SamSetupGate, {
			errorMessage: access.errorMessage,
			isRefetching: access.isRefetching,
			onRetry: access.onRetry
		})
	});
	if (!activeSessionId) {
		const loadFailed = sessionsQuery.isError && !sessionsQuery.data;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, {
			pending: !loadFailed && !createError,
			children: loadFailed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
				error: sessionsQuery.error,
				fallback: "Failed to load your chats.",
				onRetry: () => void sessionsQuery.refetch(),
				isRetrying: sessionsQuery.isFetching
			}) : createError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
				error: createError,
				fallback: "Failed to start a new chat.",
				onRetry: startChat
			}) : null
		});
	}
	if (!activeSession) {
		const confirmed = sessionsQuery.data !== void 0 && recheckedSessionId === activeSessionId;
		if (sessionsQuery.isFetching || !confirmed && !sessionsQuery.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, { pending: true });
		if (sessionsQuery.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
			error: sessionsQuery.error,
			fallback: "Failed to load your chats.",
			onRetry: () => void refetchSessions()
		}) });
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, {
			description: "This chat was archived or does not exist.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => goToSession(),
				children: "Go to your latest chat"
			})
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full min-h-0 flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3 border-b border-border px-5 py-3.5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate text-sm font-medium text-foreground/80",
				children: activeSession.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/p/$projectId/context",
				params: { projectId },
				className: "flex shrink-0 items-center gap-1.5 text-xs text-muted-foreground transition-colors hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brain, { className: "size-3.5" }), "Project memory"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex min-h-0 flex-1",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
				fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, { pending: true }),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SamConversation, {
					projectId,
					sessionId: activeSessionId
				}, activeSessionId)
			})
		})]
	});
}
//#endregion
//#region src/routes/_app/p/$projectId/sam.tsx?tsr-split=component
function SamRoute() {
	const { projectId } = Route.useParams();
	const { s } = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SamChat, {
		projectId,
		activeSessionId: s
	});
}
//#endregion
export { SamRoute as component };
