import { Fn as object, Jn as string, Nt as array } from "./schemas-BPIpYT5n.js";
//#region src/types/schemas/indexnow.ts
var indexNowUrlsSchema = array(string().max(2048)).min(1).max(1e4);
var indexNowProjectSchema = object({ projectId: string().min(1) });
var submitIndexNowUrlsSchema = object({
	projectId: string().min(1),
	urls: indexNowUrlsSchema
});
//#endregion
export { indexNowUrlsSchema as n, submitIndexNowUrlsSchema as r, indexNowProjectSchema as t };
