//#region package.json
var version = "0.1.26";
//#endregion
export { version as t };
