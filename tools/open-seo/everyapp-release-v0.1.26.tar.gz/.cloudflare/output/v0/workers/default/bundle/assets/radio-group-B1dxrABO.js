import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as cn } from "./dist-fVOGIv0D.js";
import { l as serializeValue } from "./resolveAriaLabelledBy-GDrxn-Sb.js";
import { _ as useIsoLayoutEffect, c as NOOP, d as useButton, f as dispatchClickWithModifiers, h as formatErrorMessage, i as useRenderElement, s as EMPTY_OBJECT, u as useMergedRefs, v as useStableCallback } from "./button-DrcZrdio.js";
import { n as useFieldItemContext } from "./checkbox-CdxmE4wQ.js";
import { A as contains, D as useControlled, M as useBaseUiId, t as createChangeEventDetails, y as none } from "./createBaseUIEventDetails-CaTwrmZM.js";
import { n as visuallyHiddenInput, t as visuallyHidden } from "./visuallyHidden-BYjdF74q.js";
import { i as useFormContext, l as DEFAULT_VALIDITY_STATE, n as useLabelableId, r as useLabelableContext, s as useFieldRootContext, t as useRegisterFieldControl, u as fieldValidityMapping } from "./useRegisterFieldControl-CzcA0uVK.js";
import { t as useAriaLabelledBy } from "./useAriaLabelledBy-YRlixE8y.js";
import { n as useOpenChangeComplete, s as transitionStatusMapping, t as useTransitionStatus } from "./useTransitionStatus-CPclyjTE.js";
import { t as useValueChanged } from "./useValueChanged-BHJoT30P.js";
import { n as ACTIVE_COMPOSITE_ITEM, t as CompositeRoot } from "./CompositeRoot-DhFt54fq.js";
import { c as SHIFT } from "./composite-DUeGVqZn.js";
import { t as CompositeItem } from "./CompositeItem-DehNJvwY.js";
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/fieldset/root/FieldsetRootContext.mjs
var import_jsx_runtime = require_jsx_runtime();
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var FieldsetRootContext = /*#__PURE__*/ import_react.createContext(void 0);
function useFieldsetRootContext(optional = false) {
	const context = import_react.useContext(FieldsetRootContext);
	if (!context && !optional) throw new Error(formatErrorMessage(86));
	return context;
}
Object.keys(DEFAULT_VALIDITY_STATE);
/**
* Whether an input participates in the surrounding Base UI Form. Inputs that are effectively
* disabled, or whose `form` attribute explicitly associates them with another form, are excluded.
* DOM position only matters when it associates the input with a different form. Otherwise, field
* registration is context-driven, so portaled inputs (for example inside a dialog) still belong to
* the form for both validation and values projected into `onFormSubmit`.
*/
function isEligibleInput(input, formElement) {
	if (input.matches(":disabled")) return false;
	if (!formElement || input.form === formElement) return true;
	return input.form === null && !input.hasAttribute("form");
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/radio/root/RadioRootDataAttributes.mjs
/**
* Present when the radio is checked.
*/
var checked = "data-checked";
/**
* Present when the radio is not checked.
*/
var unchecked = "data-unchecked";
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/radio/utils/stateAttributesMapping.mjs
var stateAttributesMapping = {
	checked(value) {
		if (value) return { [checked]: "" };
		return { [unchecked]: "" };
	},
	...transitionStatusMapping,
	...fieldValidityMapping
};
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/radio-group/RadioGroupContext.mjs
var RadioGroupContext = /*#__PURE__*/ import_react.createContext(void 0);
function useRadioGroupContext() {
	return import_react.useContext(RadioGroupContext);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/radio/root/RadioRootContext.mjs
var RadioRootContext = /*#__PURE__*/ import_react.createContext(void 0);
function useRadioRootContext() {
	const value = import_react.useContext(RadioRootContext);
	if (value === void 0) throw new Error(formatErrorMessage(52));
	return value;
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/radio/root/RadioRoot.mjs
/**
* Represents the radio button itself.
* Renders a `<span>` element and a hidden `<input>` beside.
*
* Documentation: [Base UI Radio](https://base-ui.com/react/components/radio)
*/
var RadioRoot = /*#__PURE__*/ import_react.forwardRef(function RadioRoot(componentProps, forwardedRef) {
	const { render, className, disabled: disabledProp = false, readOnly: readOnlyProp = false, required: requiredProp = false, "aria-labelledby": ariaLabelledByProp, value, inputRef: inputRefProp, nativeButton = false, id: idProp, style, ...elementProps } = componentProps;
	const groupContext = useRadioGroupContext();
	const { disabled: disabledGroup, readOnly: readOnlyGroup, required: requiredGroup, form: formGroup, checkedValue, touched = false, validation, name, setCheckedValue = NOOP, setTouched = NOOP, registerInputRef = NOOP } = groupContext ?? {};
	const { setTouched: setFieldTouched, setFilled, state: fieldState, disabled: fieldDisabled } = useFieldRootContext();
	const fieldItemContext = useFieldItemContext();
	const { labelId, getDescriptionProps } = useLabelableContext();
	const disabled = fieldDisabled || fieldItemContext.disabled || disabledGroup || disabledProp;
	const readOnly = readOnlyGroup || readOnlyProp;
	const required = requiredGroup || requiredProp;
	const form = formGroup;
	const checked = groupContext ? checkedValue === value : value === "";
	const radioRef = import_react.useRef(null);
	const inputRef = import_react.useRef(null);
	const registerFieldInput = validation?.registerInput;
	const registerInput = import_react.useCallback((element) => registerFieldInput?.(element, {
		controlRef: radioRef,
		value: void 0
	}), [registerFieldInput]);
	const mergedInputRef = useMergedRefs(inputRefProp, inputRef, registerInputRef, registerInput);
	useIsoLayoutEffect(() => {
		if (inputRef.current?.checked) setFilled(true);
	}, [setFilled]);
	useIsoLayoutEffect(() => {
		if (!inputRef.current) return;
		if (disabled && checked) {
			registerInputRef(null);
			return;
		}
		registerInputRef(inputRef.current);
	}, [
		checked,
		disabled,
		registerInputRef
	]);
	const id = useBaseUiId();
	const inputId = useLabelableId({ id: idProp });
	const hiddenInputId = nativeButton ? void 0 : inputId;
	const rootProps = {
		role: "radio",
		"aria-checked": checked,
		"aria-labelledby": useAriaLabelledBy(ariaLabelledByProp, labelId, inputRef, !nativeButton, hiddenInputId),
		[ACTIVE_COMPOSITE_ITEM]: checked ? "" : void 0,
		id: nativeButton ? inputId : id,
		onKeyDown(event) {
			if (event.key === "Enter") event.preventDefault();
		},
		onClick(event) {
			if (event.defaultPrevented || disabled || readOnly) return;
			event.preventDefault();
			const input = inputRef.current;
			if (!input) return;
			dispatchClickWithModifiers(input, event);
		},
		onFocus(event) {
			if (event.defaultPrevented || disabled || readOnly || !touched) return;
			inputRef.current?.click();
			setTouched(false);
		}
	};
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton,
		composite: false
	});
	const inputProps = {
		type: "radio",
		ref: mergedInputRef,
		form,
		id: hiddenInputId,
		name,
		tabIndex: -1,
		style: name ? visuallyHiddenInput : visuallyHidden,
		"aria-hidden": true,
		...value !== void 0 ? { value: serializeValue(value) } : EMPTY_OBJECT,
		disabled,
		checked,
		required,
		readOnly,
		onChange(event) {
			if (event.nativeEvent.defaultPrevented) return;
			if (disabled || readOnly || value === void 0) return;
			const details = createChangeEventDetails(none, event.nativeEvent);
			setCheckedValue(value, details);
			if (details.isCanceled) return;
			setFieldTouched(true);
		},
		onClick(event) {
			event.stopPropagation();
		},
		onFocus() {
			radioRef.current?.focus();
		}
	};
	const state = import_react.useMemo(() => ({
		...fieldState,
		required,
		disabled,
		readOnly,
		checked
	}), [
		fieldState,
		disabled,
		readOnly,
		checked,
		required
	]);
	const contextValue = state;
	const isRadioGroup = groupContext !== void 0;
	const refs = [
		forwardedRef,
		radioRef,
		buttonRef
	];
	const props = [
		rootProps,
		elementProps,
		getButtonProps,
		getDescriptionProps,
		validation ? (validationProps) => validation.getValidationProps(disabled, validationProps) : EMPTY_OBJECT
	];
	const element = useRenderElement("span", componentProps, {
		enabled: !isRadioGroup,
		state,
		ref: refs,
		props,
		stateAttributesMapping
	});
	return /*#__PURE__*/ (0, import_jsx_runtime.jsxs)(RadioRootContext.Provider, {
		value: contextValue,
		children: [isRadioGroup ? /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeItem, {
			tag: "span",
			render,
			className,
			style,
			state,
			refs,
			props,
			stateAttributesMapping
		}) : element, /*#__PURE__*/ (0, import_jsx_runtime.jsx)("input", {
			...inputProps,
			suppressHydrationWarning: true
		})]
	});
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/radio/indicator/RadioIndicator.mjs
/**
* Indicates whether the radio button is selected.
* Renders a `<span>` element.
*
* Documentation: [Base UI Radio](https://base-ui.com/react/components/radio)
*/
var RadioIndicator = /*#__PURE__*/ import_react.forwardRef(function RadioIndicator(componentProps, forwardedRef) {
	const { render, className, style, keepMounted = false, ...elementProps } = componentProps;
	const rootState = useRadioRootContext();
	const rendered = rootState.checked;
	const { mounted, transitionStatus, setMounted } = useTransitionStatus(rendered);
	const state = {
		...rootState,
		transitionStatus
	};
	const indicatorRef = import_react.useRef(null);
	const shouldRender = keepMounted || mounted;
	const element = useRenderElement("span", componentProps, {
		ref: [forwardedRef, indicatorRef],
		state,
		props: elementProps,
		stateAttributesMapping
	});
	useOpenChangeComplete({
		batch: true,
		enabled: !rendered,
		open: rendered,
		ref: indicatorRef,
		onComplete() {
			if (!rendered) setMounted(false);
		}
	});
	if (!shouldRender) return null;
	return element;
});
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/radio-group/RadioGroup.mjs
var MODIFIER_KEYS = [SHIFT];
/**
* Provides a shared state to a series of radio buttons.
* Renders a `<div>` element.
*
* Documentation: [Base UI Radio Group](https://base-ui.com/react/components/radio)
*/
var RadioGroup$1 = /*#__PURE__*/ import_react.forwardRef(function RadioGroup(componentProps, forwardedRef) {
	const { render, className, disabled: disabledProp, readOnly, required, onValueChange: onValueChangeProp, value: externalValue, defaultValue, form, name: nameProp, inputRef: inputRefProp, id: idProp, style, ...elementProps } = componentProps;
	const { setTouched: setFieldTouched, setFocused, validationMode, name: fieldName, disabled: fieldDisabled, state: fieldState, validation, setDirty, setFilled, validityData } = useFieldRootContext();
	const { labelId } = useLabelableContext();
	const { clearErrors, elementRef } = useFormContext();
	const fieldsetContext = useFieldsetRootContext(true);
	const disabled = fieldDisabled || disabledProp;
	const name = fieldName ?? nameProp;
	const id = useBaseUiId(idProp);
	const [checkedValue, setCheckedValueUnwrapped] = useControlled({
		controlled: externalValue,
		default: defaultValue,
		name: "RadioGroup",
		state: "value"
	});
	const [touched, setTouched] = import_react.useState(false);
	const setCheckedValue = useStableCallback((value, eventDetails) => {
		onValueChangeProp?.(value, eventDetails);
		if (eventDetails.isCanceled) return;
		setCheckedValueUnwrapped(value);
	});
	const getInputControl = validation.getInputControl;
	const controlRef = import_react.useMemo(() => ({ get current() {
		return getInputControl();
	} }), [getInputControl]);
	const groupInputRef = import_react.useRef(null);
	const firstEnabledInputRef = import_react.useRef(null);
	function setInputRef(hiddenInput) {
		let cleanup = void 0;
		if (inputRefProp) {
			if (typeof inputRefProp === "function") cleanup = inputRefProp(hiddenInput);
			else inputRefProp.current = hiddenInput;
		}
		groupInputRef.current = hiddenInput;
		return cleanup;
	}
	const registerInputRef = useStableCallback((input) => {
		if (!input || input.disabled) return;
		if (!firstEnabledInputRef.current) firstEnabledInputRef.current = input;
		const currentInput = groupInputRef.current;
		const cleanup = input.checked || currentInput == null || currentInput.disabled ? setInputRef(input) : void 0;
		return () => {
			if (firstEnabledInputRef.current === input) firstEnabledInputRef.current = null;
			if (groupInputRef.current === input) {
				if (cleanup) {
					cleanup();
					groupInputRef.current = null;
				} else setInputRef(null);
			} else cleanup?.();
		};
	});
	const getFormValue = useStableCallback(() => {
		const formElement = elementRef.current;
		if (!formElement) return checkedValue ?? null;
		for (const input of validation.registeredInputs.keys()) if (input.checked && isEligibleInput(input, formElement)) return checkedValue ?? null;
		return null;
	});
	useRegisterFieldControl(controlRef, id, checkedValue ?? null, getFormValue, !disabled, nameProp);
	useValueChanged(checkedValue, () => {
		clearErrors(name);
		setDirty(checkedValue !== validityData.initialValue);
		setFilled(checkedValue != null);
		validation.change(checkedValue);
		const fallbackInput = firstEnabledInputRef.current;
		if (checkedValue == null && fallbackInput && !fallbackInput.disabled) setInputRef(fallbackInput);
	});
	const ariaLabelledby = labelId ?? fieldsetContext?.legendId;
	const state = {
		...fieldState,
		disabled: disabled ?? false,
		required: required ?? false,
		readOnly: readOnly ?? false
	};
	const contextValue = import_react.useMemo(() => ({
		checkedValue,
		disabled,
		form,
		validation,
		name,
		readOnly,
		registerInputRef,
		required,
		setCheckedValue,
		setTouched,
		touched
	}), [
		checkedValue,
		disabled,
		form,
		validation,
		name,
		readOnly,
		registerInputRef,
		required,
		setCheckedValue,
		setTouched,
		touched
	]);
	const defaultProps = {
		id: idProp,
		role: "radiogroup",
		"aria-required": required || void 0,
		"aria-disabled": disabled || void 0,
		"aria-readonly": readOnly || void 0,
		"aria-labelledby": ariaLabelledby,
		onFocus() {
			setFocused(true);
		},
		onBlur(event) {
			if (!contains(event.currentTarget, event.relatedTarget)) {
				setFieldTouched(true);
				setFocused(false);
				if (validationMode === "onBlur") validation.commit(checkedValue);
			}
		},
		onKeyDownCapture(event) {
			if (event.key.startsWith("Arrow")) {
				setTouched(true);
				setFocused(true);
			}
		}
	};
	return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(RadioGroupContext.Provider, {
		value: contextValue,
		children: /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeRoot, {
			render,
			className,
			style,
			state,
			props: [
				defaultProps,
				elementProps,
				(props) => validation.getValidationProps(disabled ?? false, props)
			],
			refs: [forwardedRef],
			stateAttributesMapping: fieldValidityMapping,
			enableHomeAndEndKeys: false,
			modifierKeys: MODIFIER_KEYS
		})
	});
});
//#endregion
//#region src/client/components/ui/radio-group.tsx
function RadioGroup({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup$1, {
		"data-slot": "radio-group",
		className: cn("grid w-full gap-2", className),
		...props
	});
}
function RadioGroupItem({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioRoot, {
		"data-slot": "radio-group-item",
		className: cn("group/radio-group-item peer relative flex aspect-square size-4 shrink-0 rounded-full border border-input outline-none group-has-[:focus-visible]/field-label:ring-0 group-has-[:focus-visible]/field-label:not-data-checked:border-input after:absolute after:-inset-x-3 after:-inset-y-2 focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-3 aria-invalid:ring-destructive/20 aria-invalid:aria-checked:border-primary dark:bg-input/30 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40 data-checked:border-primary data-checked:bg-primary data-checked:text-primary-foreground group-has-[:focus-visible]/field-label:data-checked:border-primary dark:data-checked:bg-primary", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioIndicator, {
			"data-slot": "radio-group-indicator",
			className: "flex size-4 items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1/2 left-1/2 size-2 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary-foreground" })
		})
	});
}
//#endregion
export { RadioGroupItem as n, RadioGroup as t };
