import { A as gsc_schema_exports$1, B as better_auth_schema_exports$1, I as report_templates_schema_exports$1, L as reports_schema_exports$1, M as billing_schema_exports$1, N as sam_schema_exports$1, O as ai_visibility_schema_exports$1, P as audit_schema_exports$1, R as project_context_schema_exports$1, _ as app_schema_exports, c as telemetry_schema_exports, d as billing_schema_exports, dt as getDatabaseProvider, f as sam_schema_exports, g as project_context_schema_exports, h as reports_schema_exports, j as ga4_schema_exports$1, k as telemetry_schema_exports$1, l as gsc_schema_exports, m as report_templates_schema_exports, o as local_seo_schema_exports, p as audit_schema_exports, s as ai_visibility_schema_exports, u as ga4_schema_exports, v as better_auth_schema_exports, x as local_seo_schema_exports$1, z as app_schema_exports$1 } from "./db-DhHkpZWI.js";
var { userOnboardingAnswers, userSignupCampaigns, accountDeletionRequests, guestAccounts, projects, savedKeywords, savedKeywordTags, savedKeywordTagAssignments, keywordMetrics, rankTrackingConfigs, rankTrackingKeywords, rankCheckRuns, rankSnapshots, organizationActivationState, projectActivationState, dashboardStepDismissals, backlinkSnapshots, dataRefreshClaims, crawlerCredentials, projectContextSections, projectCompetitors, projectKeyPages, projectResearchLog, reports, reportTemplates, audits, auditPages, auditIssues, auditLighthouseResults, samSessions, user, session, account, apikey, verification, organization, member, invitation, billingCustomerStatus, ga4Connections, gscConnections, telemetryState, aiTrackers, aiPrompts, aiRuns, aiObservations, aiSources, aiMatches, localRankTrackers, localRankChecks, localRankKeywords, localRankScans, localRankPoints, localRankBusinesses, localRankResults } = getDatabaseProvider() === "postgres" ? {
	...app_schema_exports,
	...project_context_schema_exports,
	...reports_schema_exports,
	...report_templates_schema_exports,
	...audit_schema_exports,
	...sam_schema_exports,
	...better_auth_schema_exports,
	...billing_schema_exports,
	...ga4_schema_exports,
	...gsc_schema_exports,
	...telemetry_schema_exports,
	...ai_visibility_schema_exports,
	...local_seo_schema_exports
} : {
	...app_schema_exports$1,
	...project_context_schema_exports$1,
	...reports_schema_exports$1,
	...report_templates_schema_exports$1,
	...audit_schema_exports$1,
	...sam_schema_exports$1,
	...better_auth_schema_exports$1,
	...billing_schema_exports$1,
	...ga4_schema_exports$1,
	...gsc_schema_exports$1,
	...telemetry_schema_exports$1,
	...ai_visibility_schema_exports$1,
	...local_seo_schema_exports$1
};
//#endregion
export { userSignupCampaigns as $, member as A, rankSnapshots as B, localRankBusinesses as C, localRankResults as D, localRankPoints as E, projectContextSections as F, samSessions as G, rankTrackingKeywords as H, projectKeyPages as I, savedKeywords as J, savedKeywordTagAssignments as K, projectResearchLog as L, organizationActivationState as M, projectActivationState as N, localRankScans as O, projectCompetitors as P, userOnboardingAnswers as Q, projects as R, keywordMetrics as S, localRankKeywords as T, reportTemplates as U, rankTrackingConfigs as V, reports as W, telemetryState as X, session as Y, user as Z, dataRefreshClaims as _, aiPrompts as a, guestAccounts as b, aiTrackers as c, auditLighthouseResults as d, verification as et, auditPages as f, dashboardStepDismissals as g, crawlerCredentials as h, aiObservations as i, organization as j, localRankTrackers as k, apikey as l, billingCustomerStatus as m, accountDeletionRequests as n, aiRuns as o, audits as p, savedKeywordTags as q, aiMatches as r, aiSources as s, account as t, auditIssues as u, ga4Connections as v, localRankChecks as w, invitation as x, gscConnections as y, rankCheckRuns as z };
