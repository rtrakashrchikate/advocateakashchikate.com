import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { j as useQueryClient, t as useQuery } from "./useQuery-B93OR2NQ.js";
import { n as QueryState } from "./QueryState-Q8BZIblk.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { t as ChevronRight } from "./chevron-right-CMQSolKd.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as Plus } from "./plus-C1Kukp-u.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { t as Badge } from "./badge-B9fV075d.js";
import { i as SectionHeader, r as PageHeader } from "./PageHeader-a3_4WaC8.js";
import { i as getArchivedProjects, r as deleteArchivedProject, s as restoreProject } from "./projects-BLNM8KiA.js";
import { t as projectsQueryOptions } from "./projectQueries-CUURHKzv.js";
import { n as getLastProjectId } from "./active-project-CjOtfLST.js";
import { t as ConfirmDialog } from "./ConfirmDialog-CI0zpKxJ.js";
import { t as CreateProjectModal } from "./CreateProjectModal-BjNKE_1P.js";
//#region src/routes/_app/projects.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProjectsPage() {
	const [creating, setCreating] = import_react.useState(false);
	const [currentProjectId, setCurrentProjectId] = import_react.useState(null);
	import_react.useEffect(() => {
		setCurrentProjectId(getLastProjectId());
	}, []);
	const projectsQuery = useQuery(projectsQueryOptions());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "h-full overflow-auto px-4 py-4 pb-24 md:px-6 md:py-6 md:pb-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl space-y-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
					title: "Projects",
					description: "Each project has its own Search Console, rank tracking, and audits.",
					actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => setCreating(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { "data-icon": "inline-start" }), "New project"]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
					query: projectsQuery,
					errorFallback: "Failed to load projects",
					children: (data) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-border overflow-hidden rounded-lg border border-border bg-card",
						children: data.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/p/$projectId/settings",
							params: { projectId: project.id },
							className: "flex items-center justify-between gap-3 p-3 transition-colors hover:bg-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex min-w-0 flex-col",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "truncate font-medium",
										children: project.name
									}), project.id === currentProjectId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										size: "sm",
										children: "Current"
									}) : null]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-xs text-muted-foreground",
									children: project.domain ?? "No domain set"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 shrink-0 text-muted-foreground" })]
						}) }, project.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArchivedProjects, {})
			]
		}), creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CreateProjectModal, { onClose: () => setCreating(false) }) : null]
	});
}
function ArchivedProjects() {
	const queryClient = useQueryClient();
	const archived = useQuery({
		queryKey: ["projects", "archived"],
		queryFn: () => getArchivedProjects()
	}).data ?? [];
	const restoreMutation = useMutation({
		mutationFn: (projectId) => restoreProject({ data: { archivedProjectId: projectId } }),
		onSuccess: async () => {
			await queryClient.invalidateQueries({ queryKey: projectsQueryOptions().queryKey });
			toast.success("Project restored");
		}
	});
	const [deleting, setDeleting] = import_react.useState(null);
	const deleteMutation = useMutation({
		mutationFn: (projectId) => deleteArchivedProject({ data: { archivedProjectId: projectId } }),
		onSuccess: async () => {
			setDeleting(null);
			await queryClient.invalidateQueries({ queryKey: ["projects", "archived"] });
			toast.success("Project deleted");
		}
	});
	if (archived.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { title: "Archived" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border overflow-hidden rounded-lg border border-border bg-card",
				children: archived.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex min-w-0 flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate font-medium text-muted-foreground",
							children: project.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "truncate text-xs text-muted-foreground",
							children: project.domain ?? "No domain set"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex shrink-0 gap-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							onClick: () => restoreMutation.mutate(project.id),
							disabled: restoreMutation.isPending,
							children: "Restore"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							className: "text-destructive hover:text-destructive",
							onClick: () => setDeleting(project),
							children: "Delete"
						})]
					})]
				}, project.id))
			}),
			deleting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				title: `Permanently delete \u201c${deleting.name}\u201d?`,
				confirmLabel: "Delete permanently",
				destructive: true,
				pending: deleteMutation.isPending,
				onClose: () => setDeleting(null),
				onConfirm: () => deleteMutation.mutate(deleting.id),
				children: "This deletes the project and all of its data: audits, rank tracking, saved keywords, reports, AI visibility, and chats. It can't be undone."
			}) : null
		]
	});
}
//#endregion
export { ProjectsPage as component };
