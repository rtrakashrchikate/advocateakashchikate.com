import { Et as _enum } from "./schemas-BPIpYT5n.js";
import { n as parse } from "./es6-v60hw-Cv.js";
//#region src/shared/researchScope.ts
/**
* True when `host` resolves to a real registrable domain (public-suffix list),
* rejecting IPs and fake TLDs like `example.por` before they reach DataForSEO.
*/
function isValidDomainHost(host) {
	const parsed = parse(host, { allowPrivateDomains: true });
	return !parsed.isIp && !!parsed.publicSuffix && (parsed.isIcann === true || parsed.isPrivate === true);
}
/**
* Research scope for any URL/domain input:
* - exact_url:  one normalized page URL only
* - subfolder:  the selected path and its children (not similarly named siblings)
* - domain:     the selected hostname, excluding its subdomains
* - subdomains: the selected hostname and all of its subdomains
*/
var RESEARCH_SCOPES = [
	"exact_url",
	"subfolder",
	"domain",
	"subdomains"
];
var researchScopeSchema = _enum(RESEARCH_SCOPES);
var RESEARCH_SCOPE_LABELS = {
	exact_url: "Exact URL",
	subfolder: "Subfolder",
	domain: "Domain",
	subdomains: "Subdomains"
};
/** Base wording for MCP `scope` params; tools append their own caveats. */
var RESEARCH_SCOPE_PARAM_DESCRIPTION = "Research scope: 'domain' (hostname without subdomains), 'subdomains' (hostname plus all subdomains), 'subfolder' (path and its children), or 'exact_url' (one page). Defaults to 'subdomains' for root inputs and 'subfolder' when the input has a path.";
/** One-line explanations shown in the scope dropdown. */
var RESEARCH_SCOPE_DESCRIPTIONS = {
	exact_url: "One page only",
	subfolder: "The path and everything under it",
	domain: "The hostname, without subdomains",
	subdomains: "The domain plus all its subdomains"
};
/** Wildcard-style pattern examples shown under each scope option. */
var RESEARCH_SCOPE_EXAMPLES = {
	exact_url: "example.com/path",
	subfolder: "example.com/path/*",
	domain: "example.com/*",
	subdomains: "*.example.com/*"
};
function normalizePath(pathname) {
	if (pathname === "/") return "";
	const trimmed = pathname.replace(/\/+$/, "");
	return trimmed === "" ? "" : trimmed;
}
/** A subfolder needs a non-root path; every other scope works for any input. */
function isScopeAllowedForInput(scope, path) {
	return scope !== "subfolder" || path !== "";
}
/** Root inputs default to subdomains scope; inputs with a path to subfolder. */
function defaultScopeForPath(path) {
	return path === "" ? "subdomains" : "subfolder";
}
/** Scope implied by the input itself; unparseable input falls back to domain. */
function defaultScopeForInput(input) {
	const parsed = parseResearchTarget(input);
	return parsed.ok ? parsed.target.scope : "domain";
}
/**
* Scope as persisted in URLs and history: omitted when it matches the input's
* implied default, so shared links re-derive the same scope.
*/
function toScopeSearchParam(input, scope) {
	return scope === defaultScopeForInput(input) ? void 0 : scope;
}
function parseResearchTarget(input, requestedScope) {
	const trimmed = input.trim();
	if (!trimmed) return {
		ok: false,
		message: "Enter a domain or URL"
	};
	const withProtocol = /^[a-zA-Z][a-zA-Z\d+.-]*:\/\//.test(trimmed) ? trimmed : `https://${trimmed}`;
	let parsed;
	try {
		parsed = new URL(withProtocol);
	} catch {
		return {
			ok: false,
			message: "Enter a valid domain like example.com"
		};
	}
	if (parsed.username || parsed.password) return {
		ok: false,
		message: "URLs with embedded credentials are not supported"
	};
	const urlHostname = parsed.hostname.toLowerCase();
	const hostname = urlHostname.replace(/^www\./, "");
	if (!hostname || !hostname.includes(".") || !/^[a-z\d.-]+$/.test(hostname) || !isValidDomainHost(hostname)) return {
		ok: false,
		message: "Enter a valid domain like example.com"
	};
	const path = normalizePath(parsed.pathname);
	if (requestedScope === "subfolder" && path === "") return {
		ok: false,
		message: "Add a path to use Subfolder (e.g. example.com/blog)"
	};
	const scope = requestedScope ?? defaultScopeForPath(path);
	return {
		ok: true,
		target: {
			scope,
			hostname,
			urlHostname,
			path,
			display: scope === "exact_url" || scope === "subfolder" ? `${hostname}${path}` : hostname
		}
	};
}
/**
* Backlinks page lookups match the URL exactly, so a query string or fragment
* would target a different page than the one entered. Reject it instead of
* dropping it.
*/
function parseBacklinksTarget(input, requestedScope) {
	const parsed = parseResearchTarget(input, requestedScope);
	if (parsed.ok && parsed.target.scope === "exact_url" && /[?#]/.test(input)) return {
		ok: false,
		message: "Remove the query string or fragment (? or #) to look up an exact page"
	};
	return parsed;
}
/**
* How many of DataForSEO's 8 filter conditions each scope consumes on the
* Labs endpoints (see buildRankedKeywordsScopeFilter / buildRelevantPagesScopeFilter).
* The client uses this to shrink the user-facing filter budget.
*/
var RESEARCH_SCOPE_FILTER_SLOTS = {
	keywords: {
		exact_url: 4,
		subfolder: 4,
		domain: 1,
		subdomains: 0
	},
	pages: {
		exact_url: 4,
		subfolder: 4,
		domain: 2,
		subdomains: 0
	}
};
function hostMatches(candidateHost, target) {
	const host = candidateHost.toLowerCase().replace(/^www\./, "");
	if (target.scope === "subdomains") return host === target.hostname || host.endsWith(`.${target.hostname}`);
	return host === target.hostname;
}
/**
* Whether a result URL belongs to the research target. Used to post-filter
* provider rows that cannot be scoped provider-side. Subfolder matching
* includes the path and its children but excludes similarly named siblings
* (`/blog` matches `/blog/post`, not `/blogging`).
*/
function urlMatchesResearchTarget(url, target) {
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		return false;
	}
	if (!hostMatches(parsed.hostname, target)) return false;
	const path = normalizePath(parsed.pathname);
	switch (target.scope) {
		case "exact_url": return path === target.path;
		case "subfolder": return path === target.path || path.startsWith(`${target.path}/`);
		default: return true;
	}
}
//#endregion
export { RESEARCH_SCOPE_LABELS as a, defaultScopeForPath as c, parseBacklinksTarget as d, parseResearchTarget as f, urlMatchesResearchTarget as h, RESEARCH_SCOPE_FILTER_SLOTS as i, isScopeAllowedForInput as l, toScopeSearchParam as m, RESEARCH_SCOPE_DESCRIPTIONS as n, RESEARCH_SCOPE_PARAM_DESCRIPTION as o, researchScopeSchema as p, RESEARCH_SCOPE_EXAMPLES as r, defaultScopeForInput as s, RESEARCH_SCOPES as t, isValidDomainHost as u };
