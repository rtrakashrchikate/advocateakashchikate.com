import { r as __exportAll$1 } from "./rolldown-runtime-oLLnCvco.js";
//#region node_modules/.pnpm/@takumi-rs+helpers@2.13.7_preact@10.29.3_react@19.2.4/node_modules/@takumi-rs/helpers/dist/fonts-CBLz8Mte.mjs
var e = class {
	signal;
	constructor(e, t) {
		let n = e.timeout ?? 3e4, r = [
			e.signal,
			t,
			n <= 0 ? void 0 : AbortSignal.timeout(n)
		].filter((e) => e != null);
		this.signal = r.length ? AbortSignal.any(r) : void 0;
	}
	waitFor(e) {
		let t = this.signal;
		return t ? new Promise((n, r) => {
			function i() {
				t?.removeEventListener(`abort`, i), r(t?.reason);
			}
			t.addEventListener(`abort`, i, { once: !0 }), e.then((e) => {
				t.removeEventListener(`abort`, i), n(e);
			}, (e) => {
				t.removeEventListener(`abort`, i), r(e);
			}), t.aborted && i();
		}) : e;
	}
};
var t = /* @__PURE__ */ new Set([
	301,
	302,
	303,
	307,
	308
]);
var n$1 = /* @__PURE__ */ new Set([
	408,
	429,
	500,
	502,
	503,
	504
]);
async function i$1(e, t = {}) {
	return new a$1(e, t).send();
}
var a$1 = class r {
	url;
	allowUrl;
	fetchImpl;
	init;
	constructor(t, n) {
		if (n.allowUrl && !n.allowUrl(t)) throw Error(`URL blocked by allowUrl policy: ${t}`);
		this.url = t, this.allowUrl = n.allowUrl, this.fetchImpl = n.fetch ?? globalThis.fetch, this.init = {
			...n.init,
			signal: new e(n, n.init?.signal).signal
		};
	}
	async send() {
		let e = this.allowUrl ? await this.followRedirects(this.allowUrl) : await this.attempt(this.url, this.init);
		if (!e.ok) throw Error(`HTTP ${e.status} ${e.statusText} fetching ${this.url}`);
		return e;
	}
	async attempt(e, t) {
		let r = t.method?.toUpperCase() ?? `GET`, i = r === `GET` || r === `HEAD`;
		for (let r = 0;; r++) {
			t.signal?.throwIfAborted();
			let a = 100 * 2 ** r;
			try {
				let o = await this.fetchImpl.call(void 0, e, t);
				if (t.signal?.throwIfAborted(), !i || r === 2 || !n$1.has(o.status)) return o;
				let s = o.headers.get(`retry-after`);
				if (s !== null) {
					let e = Number(s), t = Number.isFinite(e) ? e * 1e3 : Date.parse(s) - Date.now();
					Number.isFinite(t) && (a = Math.max(a, t));
				}
				if (a > 1e3) return o;
				o.body?.cancel().catch(() => {});
			} catch (e) {
				if (t.signal?.throwIfAborted(), !i || r === 2 || !(e instanceof Error) || e.name !== `TypeError` && e.name !== `TimeoutError`) throw e;
			}
			await this.wait(a);
		}
	}
	wait(e) {
		let t = this.init.signal;
		return t?.throwIfAborted(), new Promise((n, r) => {
			let i = setTimeout(() => {
				t?.removeEventListener(`abort`, a), n();
			}, e);
			function a() {
				clearTimeout(i), r(t?.reason);
			}
			t?.addEventListener(`abort`, a, { once: !0 });
		});
	}
	async followRedirects(e) {
		let n = this.url, i = {
			...this.init,
			headers: new Headers(this.init.headers),
			redirect: `manual`
		};
		for (let a = 0; a < 5; a++) {
			let a = await this.attempt(n, i), o = a.headers.get(`location`);
			if (!t.has(a.status) || o === null) return a;
			await a.body?.cancel().catch(() => {});
			let s = new URL(o, n);
			if (!e(s.href)) throw Error(`URL blocked by allowUrl policy: ${s.href}`);
			if (s.protocol !== `https:` && s.protocol !== `http:` || s.username || s.password) throw Error(`Invalid redirect URL: ${s.href}`);
			i = r.redirectInit(i, a.status, n, s), n = s.href;
		}
		throw Error(`Too many redirects fetching ${this.url}`);
	}
	static redirectInit(e, t, n, r) {
		if (t !== 303 && e.body instanceof ReadableStream) throw Error(`Cannot replay a streamed request body after a redirect`);
		let i = new Headers(e.headers), a = e.method?.toUpperCase() ?? `GET`, o = (t === 301 || t === 302) && a === `POST` || t === 303 && a !== `GET` && a !== `HEAD`;
		if (o) for (let e of [
			`content-encoding`,
			`content-language`,
			`content-location`,
			`content-type`,
			`content-length`
		]) i.delete(e);
		if (new URL(n).origin !== r.origin) for (let e of [
			`authorization`,
			`proxy-authorization`,
			`cookie`,
			`cookie2`
		]) i.delete(e);
		return {
			...e,
			headers: i,
			method: o ? `GET` : e.method,
			body: o ? void 0 : e.body
		};
	}
};
async function o$1(e, t) {
	let n = Number(e.headers.get(`content-length`));
	if (Number.isFinite(n) && n > t) throw Error(`Response exceeds ${t} bytes (content-length ${n})`);
	let r = e.body;
	if (!r) return e.arrayBuffer();
	let i = r.getReader(), a = [], o = 0;
	for (;;) {
		let { done: e, value: n } = await i.read();
		if (e) break;
		if (o += n.byteLength, o > t) throw await i.cancel().catch(() => {}), Error(`Response exceeds ${t} bytes`);
		a.push(n);
	}
	let s = new Uint8Array(o), c = 0;
	for (let e of a) s.set(e, c), c += e.byteLength;
	return s.buffer;
}
function y(e) {
	let t = /* @__PURE__ */ new Set(), n = (e) => {
		for (let n of e) t.add(n.codePointAt(0));
	}, r = (e) => {
		typeof e == `string` ? n(e) : e.type === `text` ? n(e.text) : e.type === `container` && e.children?.forEach(r);
	};
	return Array.isArray(e) ? e.forEach(r) : r(e), t;
}
function b(e, t) {
	if (e.length === 0) return !0;
	for (let n of t) for (let [t, r] of e) if (n >= t && n <= r) return !0;
	return !1;
}
function x({ fonts: e, source: t }) {
	let n = y(t);
	return e.filter((e) => b(e.ranges ?? [], n));
}
function S(e, t = {}) {
	return {
		key: e,
		data: () => i$1(e, t).then((e) => o$1(e, t.maxBytes ?? 33554432))
	};
}
//#endregion
//#region node_modules/.pnpm/@takumi-rs+helpers@2.13.7_preact@10.29.3_react@19.2.4/node_modules/@takumi-rs/helpers/dist/renderer.mjs
function n(e) {
	return e instanceof Uint8Array || e instanceof ArrayBuffer || typeof Buffer < `u` && Buffer.isBuffer(e);
}
function r(e) {
	return e instanceof ArrayBuffer ? new Uint8Array(e) : e;
}
function i(e) {
	return n(e) ? e : typeof e.data == `function` ? e.data() : e.data;
}
function a(e) {
	return n(e) ? e : `key` in e && e.key ? e.key : typeof e.data == `function` ? `${e.name ?? ``}:${e.weight ?? ``}:${e.style ?? ``}` : e.data;
}
async function o(e) {
	let { sources: t = [], cache: n } = Array.isArray(e) ? { sources: e } : e, i = /* @__PURE__ */ new Map();
	for (let e of t) i.set(e.src, e);
	return Promise.all([...i.values()].map(async ({ src: e, data: t, cache: i }) => ({
		src: e,
		data: r(typeof t == `function` ? await t() : t),
		cache: i ?? n
	})));
}
var s = class {
	registerInner;
	byKey = /* @__PURE__ */ new Map();
	byData = /* @__PURE__ */ new WeakMap();
	constructor(e) {
		this.registerInner = e;
	}
	getFont(e) {
		return typeof e == `string` ? this.byKey.get(e) : this.byData.get(e);
	}
	setFont(e, t) {
		typeof e == `string` ? this.byKey.set(e, t) : this.byData.set(e, t);
	}
	deleteFont(e) {
		typeof e == `string` ? this.byKey.delete(e) : this.byData.delete(e);
	}
	async register(e) {
		let o = typeof e == `string` ? S(e) : e, s = a(o), c = this.getFont(s);
		if (c) return c;
		let l = i(o), u = Promise.resolve(l).then((e) => {
			let t = r(e);
			return this.registerInner(n(o) ? t : {
				...o,
				data: t
			});
		}).catch((e) => {
			throw this.deleteFont(s), e;
		});
		return this.setFont(s, u), u;
	}
	async prepareFonts(e) {
		if (!e) return;
		let t = await Promise.all(e.map((e) => this.register(e)));
		return [...new Set(t.flat().map((e) => e.name))];
	}
	async resolveResources(e, t, n) {
		let r = await this.prepareFonts(e);
		return {
			images: t ? await o(t) : void 0,
			fontFamilies: n ?? r
		};
	}
};
async function c(t, n, r) {
	let { fonts: i, fontFamilies: a, signal: o, images: s, ...c } = n;
	o?.throwIfAborted();
	let l = await i, u = await t.resolveResources(l && x({
		fonts: l,
		source: [...Array.isArray(r) ? r : [r], `\u2022\u25E6\u25A0\u25AA\u25B8\u25C2\u25BE 0123456789.-abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ`]
	}), s, a);
	return o?.throwIfAborted(), {
		options: {
			...c,
			...u
		},
		signal: o
	};
}
//#endregion
//#region node_modules/.pnpm/@takumi-rs+wasm@2.13.7_csstype@3.2.3_preact@10.29.3_react@19.2.4/node_modules/@takumi-rs/wasm/dist/export.mjs
var export_exports = /* @__PURE__ */ __exportAll$1({
	Renderer: () => Renderer,
	default: () => __wbg_init,
	initSync: () => initSync,
	setGlyphCacheMaxBytes: () => setGlyphCacheMaxBytes
});
/**
* The main renderer for Takumi image rendering engine.
*
* State lives behind a lock and every method takes `&self`, mirroring the
* napi bindings: a panic mid-call can't leave the wasm-bindgen borrow flag
* permanently set, which would otherwise fail all subsequent calls.
*/
var Renderer$1 = class {
	__destroy_into_raw() {
		const ptr = this.__wbg_ptr;
		this.__wbg_ptr = 0;
		RendererFinalization.unregister(this);
		return ptr;
	}
	free() {
		const ptr = this.__destroy_into_raw();
		wasm.__wbg_renderer_free(ptr, 0);
	}
	/**
	* Measures a node tree and returns layout information.
	* @param {Node} node
	* @param {RenderOptions | null} [options]
	* @returns {MeasuredNode}
	*/
	measure(node, options) {
		const ret = wasm.renderer_measure(this.__wbg_ptr, node, isLikeNone(options) ? 0 : addToExternrefTable0(options));
		if (ret[2]) throw takeFromExternrefTable0(ret[1]);
		return takeFromExternrefTable0(ret[0]);
	}
	/**
	* Creates a new Renderer instance.
	* @param {RendererOptions | null} [options]
	*/
	constructor(options) {
		const ret = wasm.renderer_new(isLikeNone(options) ? 0 : addToExternrefTable0(options));
		if (ret[2]) throw takeFromExternrefTable0(ret[1]);
		this.__wbg_ptr = ret[0];
		RendererFinalization.register(this, this.__wbg_ptr, this);
		return this;
	}
	/**
	* Registers fonts into the renderer, returning the families each font produced.
	* @param {Font} font
	* @returns {RegisteredFamily[]}
	*/
	registerFont(font) {
		const ret = wasm.renderer_registerFont(this.__wbg_ptr, font);
		if (ret[2]) throw takeFromExternrefTable0(ret[1]);
		return takeFromExternrefTable0(ret[0]);
	}
	/**
	* Renders a node tree into an image buffer.
	* @param {Node} node
	* @param {RenderOptions | null} [options]
	* @returns {Uint8Array<ArrayBuffer>}
	*/
	render(node, options) {
		const ret = wasm.renderer_render(this.__wbg_ptr, node, isLikeNone(options) ? 0 : addToExternrefTable0(options));
		if (ret[3]) throw takeFromExternrefTable0(ret[2]);
		var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
		wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
		return v1;
	}
	/**
	* Renders a sequential animation timeline into a buffer.
	* @param {RenderAnimationOptions} options
	* @returns {Uint8Array<ArrayBuffer>}
	*/
	renderAnimation(options) {
		const ret = wasm.renderer_renderAnimation(this.__wbg_ptr, options);
		if (ret[3]) throw takeFromExternrefTable0(ret[2]);
		var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
		wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
		return v1;
	}
	/**
	* Renders a node tree into a data URL.
	*
	* `raw` format is not supported for data URL.
	* @param {Node} node
	* @param {RenderOptions} options
	* @returns {string}
	*/
	renderAsDataUrl(node, options) {
		let deferred2_0;
		let deferred2_1;
		try {
			const ret = wasm.renderer_renderAsDataUrl(this.__wbg_ptr, node, options);
			var ptr1 = ret[0];
			var len1 = ret[1];
			if (ret[3]) {
				ptr1 = 0;
				len1 = 0;
				throw takeFromExternrefTable0(ret[2]);
			}
			deferred2_0 = ptr1;
			deferred2_1 = len1;
			return getStringFromWasm0(ptr1, len1);
		} finally {
			wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
		}
	}
	/**
	* Renders a node tree into an SVG document string.
	* @param {Node} node
	* @param {SvgRenderOptions | null} [options]
	* @returns {string}
	*/
	renderSvg(node, options) {
		let deferred2_0;
		let deferred2_1;
		try {
			const ret = wasm.renderer_renderSvg(this.__wbg_ptr, node, isLikeNone(options) ? 0 : addToExternrefTable0(options));
			var ptr1 = ret[0];
			var len1 = ret[1];
			if (ret[3]) {
				ptr1 = 0;
				len1 = 0;
				throw takeFromExternrefTable0(ret[2]);
			}
			deferred2_0 = ptr1;
			deferred2_1 = len1;
			return getStringFromWasm0(ptr1, len1);
		} finally {
			wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
		}
	}
};
if (Symbol.dispose) Renderer$1.prototype[Symbol.dispose] = Renderer$1.prototype.free;
/**
* Sets the byte budget shared by the resolved-glyph and glyph-mask caches;
* `0` stops caching. Defaults to 8 MiB.
*
* These caches live in the module, not in a `Renderer`, so this budget covers
* every renderer sharing the module instance. The value is read when a cache
* is first used, so call this before the first render.
*
* Raise it for scripts with large glyph sets: a CJK outline runs a few
* kilobytes, so the default holds around a thousand of them and a page of
* Chinese re-rasterizes glyphs it just evicted.
* @param {number} bytes
*/
function setGlyphCacheMaxBytes(bytes) {
	wasm.setGlyphCacheMaxBytes(bytes);
}
function __wbg_get_imports() {
	return {
		__proto__: null,
		"./takumi_wasm_bg.js": {
			__proto__: null,
			__wbg_Error_408e67f47ca7b58b: function(arg0, arg1) {
				return Error(getStringFromWasm0(arg0, arg1));
			},
			__wbg_Number_3890faa6d3ff057d: function(arg0) {
				return Number(arg0);
			},
			__wbg_String_8564e559799eccda: function(arg0, arg1) {
				const ptr1 = passStringToWasm0(String(arg1), wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
				const len1 = WASM_VECTOR_LEN;
				getDataViewMemory0().setInt32(arg0 + 4, len1, true);
				getDataViewMemory0().setInt32(arg0 + 0, ptr1, true);
			},
			__wbg___wbindgen_bigint_get_as_i64_c4ecf48528083721: function(arg0, arg1) {
				const v = arg1;
				const ret = typeof v === "bigint" ? v : void 0;
				getDataViewMemory0().setBigInt64(arg0 + 8, isLikeNone(ret) ? BigInt(0) : ret, true);
				getDataViewMemory0().setInt32(arg0 + 0, !isLikeNone(ret), true);
			},
			__wbg___wbindgen_boolean_get_c9c83ebd41b34df3: function(arg0) {
				const v = arg0;
				const ret = typeof v === "boolean" ? v : void 0;
				return isLikeNone(ret) ? 16777215 : ret ? 1 : 0;
			},
			__wbg___wbindgen_debug_string_a57024b9c6e4a48b: function(arg0, arg1) {
				const ptr1 = passStringToWasm0(debugString(arg1), wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
				const len1 = WASM_VECTOR_LEN;
				getDataViewMemory0().setInt32(arg0 + 4, len1, true);
				getDataViewMemory0().setInt32(arg0 + 0, ptr1, true);
			},
			__wbg___wbindgen_in_ac983077f137f2e6: function(arg0, arg1) {
				return arg0 in arg1;
			},
			__wbg___wbindgen_is_bigint_8ffbbef442139384: function(arg0) {
				return typeof arg0 === "bigint";
			},
			__wbg___wbindgen_is_function_5e4570eb24ffa122: function(arg0) {
				return typeof arg0 === "function";
			},
			__wbg___wbindgen_is_object_a2790eb24c211ea0: function(arg0) {
				const val = arg0;
				return typeof val === "object" && val !== null;
			},
			__wbg___wbindgen_is_string_e6f02f0ea5f20a32: function(arg0) {
				return typeof arg0 === "string";
			},
			__wbg___wbindgen_is_undefined_6cff064c44e0d823: function(arg0) {
				return arg0 === void 0;
			},
			__wbg___wbindgen_jsval_eq_0a18949a61670320: function(arg0, arg1) {
				return arg0 === arg1;
			},
			__wbg___wbindgen_jsval_loose_eq_acf2776254a8d832: function(arg0, arg1) {
				return arg0 == arg1;
			},
			__wbg___wbindgen_number_get_136b9679cab35cfb: function(arg0, arg1) {
				const obj = arg1;
				const ret = typeof obj === "number" ? obj : void 0;
				getDataViewMemory0().setFloat64(arg0 + 8, isLikeNone(ret) ? 0 : ret, true);
				getDataViewMemory0().setInt32(arg0 + 0, !isLikeNone(ret), true);
			},
			__wbg___wbindgen_string_get_d154f1e671052120: function(arg0, arg1) {
				const obj = arg1;
				const ret = typeof obj === "string" ? obj : void 0;
				var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
				var len1 = WASM_VECTOR_LEN;
				getDataViewMemory0().setInt32(arg0 + 4, len1, true);
				getDataViewMemory0().setInt32(arg0 + 0, ptr1, true);
			},
			__wbg___wbindgen_throw_bb96b2010945f0bc: function(arg0, arg1) {
				throw new Error(getStringFromWasm0(arg0, arg1));
			},
			__wbg_call_1c5886ab9c57d1c7: function() {
				return handleError(function(arg0, arg1) {
					return arg0.call(arg1);
				}, arguments);
			},
			__wbg_done_669171204c3dcae2: function(arg0) {
				return arg0.done;
			},
			__wbg_entries_7774d489e1da5f4f: function(arg0) {
				return Object.entries(arg0);
			},
			__wbg_get_c0c8f8d7da0c03dd: function(arg0, arg1) {
				return arg0[arg1 >>> 0];
			},
			__wbg_get_d173c0308df22d37: function() {
				return handleError(function(arg0, arg1) {
					return Reflect.get(arg0, arg1);
				}, arguments);
			},
			__wbg_get_unchecked_e20b893aeafc3fca: function(arg0, arg1) {
				return arg0[arg1 >>> 0];
			},
			__wbg_get_with_ref_key_6412cf3094599694: function(arg0, arg1) {
				return arg0[arg1];
			},
			__wbg_instanceof_ArrayBuffer_993d02d2d254cad1: function(arg0) {
				let result;
				try {
					result = arg0 instanceof ArrayBuffer;
				} catch (_) {
					result = false;
				}
				return result;
			},
			__wbg_instanceof_Map_9a4d6ead180ae3a9: function(arg0) {
				let result;
				try {
					result = arg0 instanceof Map;
				} catch (_) {
					result = false;
				}
				return result;
			},
			__wbg_instanceof_Uint8Array_f935dbb0aa7cdeed: function(arg0) {
				let result;
				try {
					result = arg0 instanceof Uint8Array;
				} catch (_) {
					result = false;
				}
				return result;
			},
			__wbg_isArray_6339f732981044bf: function(arg0) {
				return Array.isArray(arg0);
			},
			__wbg_isSafeInteger_f3d6cd19ccfe4512: function(arg0) {
				return Number.isSafeInteger(arg0);
			},
			__wbg_iterator_5cebbb86e33c6dd6: function() {
				return Symbol.iterator;
			},
			__wbg_length_36bd29c6848c2144: function(arg0) {
				return arg0.length;
			},
			__wbg_length_ecfa2c63d3d0d82c: function(arg0) {
				return arg0.length;
			},
			__wbg_new_116be93542d39019: function() {
				return new Array();
			},
			__wbg_new_358857d90afd5a2d: function(arg0, arg1) {
				return new Error(getStringFromWasm0(arg0, arg1));
			},
			__wbg_new_77cc4f4f472aeb81: function(arg0) {
				return new Uint8Array(arg0);
			},
			__wbg_new_ebe3e0f6837f0879: function() {
				return /* @__PURE__ */ new Object();
			},
			__wbg_next_42cf16ee0dafc9e2: function() {
				return handleError(function(arg0) {
					return arg0.next();
				}, arguments);
			},
			__wbg_next_8f26b64fa5e9f64b: function(arg0) {
				return arg0.next;
			},
			__wbg_prototypesetcall_de8e0d9553586985: function(arg0, arg1, arg2) {
				Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
			},
			__wbg_set_6be42768c690e380: function(arg0, arg1, arg2) {
				arg0[arg1] = arg2;
			},
			__wbg_set_a80955eb93b145c6: function(arg0, arg1, arg2) {
				arg0[arg1 >>> 0] = arg2;
			},
			__wbg_value_1e2369fab29b420e: function(arg0) {
				return arg0.value;
			},
			__wbindgen_cast_0000000000000001: function(arg0) {
				return arg0;
			},
			__wbindgen_cast_0000000000000002: function(arg0) {
				return arg0;
			},
			__wbindgen_cast_0000000000000003: function(arg0, arg1) {
				return getStringFromWasm0(arg0, arg1);
			},
			__wbindgen_cast_0000000000000004: function(arg0) {
				return BigInt.asUintN(64, arg0);
			},
			__wbindgen_init_externref_table: function() {
				const table = wasm.__wbindgen_externrefs;
				const offset = table.grow(4);
				table.set(0, void 0);
				table.set(offset + 0, void 0);
				table.set(offset + 1, null);
				table.set(offset + 2, true);
				table.set(offset + 3, false);
			}
		}
	};
}
var RendererFinalization = typeof FinalizationRegistry === "undefined" ? {
	register: () => {},
	unregister: () => {}
} : new FinalizationRegistry((ptr) => wasm.__wbg_renderer_free(ptr, 1));
function addToExternrefTable0(obj) {
	const idx = wasm.__externref_table_alloc();
	wasm.__wbindgen_externrefs.set(idx, obj);
	return idx;
}
function debugString(val) {
	const type = typeof val;
	if (type == "number" || type == "boolean" || val == null) return `${val}`;
	if (type == "string") return `"${val}"`;
	if (type == "symbol") {
		const description = val.description;
		if (description == null) return "Symbol";
		else return `Symbol(${description})`;
	}
	if (type == "function") {
		const name = val.name;
		if (typeof name == "string" && name.length > 0) return `Function(${name})`;
		else return "Function";
	}
	if (Array.isArray(val)) {
		const length = val.length;
		let debug = "[";
		if (length > 0) debug += debugString(val[0]);
		for (let i = 1; i < length; i++) debug += ", " + debugString(val[i]);
		debug += "]";
		return debug;
	}
	const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
	let className;
	if (builtInMatches && builtInMatches.length > 1) className = builtInMatches[1];
	else return toString.call(val);
	if (className == "Object") try {
		return "Object(" + JSON.stringify(val) + ")";
	} catch (_) {
		return "Object";
	}
	if (val instanceof Error) return `${val.name}: ${val.message}\n${val.stack}`;
	return className;
}
function getArrayU8FromWasm0(ptr, len) {
	ptr = ptr >>> 0;
	return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}
var cachedDataViewMemory0 = null;
function getDataViewMemory0() {
	if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || cachedDataViewMemory0.buffer.detached === void 0 && cachedDataViewMemory0.buffer !== wasm.memory.buffer) cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
	return cachedDataViewMemory0;
}
function getStringFromWasm0(ptr, len) {
	return decodeText(ptr >>> 0, len);
}
var cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
	if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
	return cachedUint8ArrayMemory0;
}
function handleError(f, args) {
	try {
		return f.apply(this, args);
	} catch (e) {
		const idx = addToExternrefTable0(e);
		wasm.__wbindgen_exn_store(idx);
	}
}
function isLikeNone(x) {
	return x === void 0 || x === null;
}
function passStringToWasm0(arg, malloc, realloc) {
	if (realloc === void 0) {
		const buf = cachedTextEncoder.encode(arg);
		const ptr = malloc(buf.length, 1) >>> 0;
		getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
		WASM_VECTOR_LEN = buf.length;
		return ptr;
	}
	let len = arg.length;
	let ptr = malloc(len, 1) >>> 0;
	const mem = getUint8ArrayMemory0();
	let offset = 0;
	for (; offset < len; offset++) {
		const code = arg.charCodeAt(offset);
		if (code > 127) break;
		mem[ptr + offset] = code;
	}
	if (offset !== len) {
		if (offset !== 0) arg = arg.slice(offset);
		ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
		const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
		const ret = cachedTextEncoder.encodeInto(arg, view);
		offset += ret.written;
		ptr = realloc(ptr, len, offset, 1) >>> 0;
	}
	WASM_VECTOR_LEN = offset;
	return ptr;
}
function takeFromExternrefTable0(idx) {
	const value = wasm.__wbindgen_externrefs.get(idx);
	wasm.__externref_table_dealloc(idx);
	return value;
}
var cachedTextDecoder = new TextDecoder("utf-8", {
	ignoreBOM: true,
	fatal: true
});
cachedTextDecoder.decode();
var MAX_SAFARI_DECODE_BYTES = 2146435072;
var numBytesDecoded = 0;
function decodeText(ptr, len) {
	numBytesDecoded += len;
	if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
		cachedTextDecoder = new TextDecoder("utf-8", {
			ignoreBOM: true,
			fatal: true
		});
		cachedTextDecoder.decode();
		numBytesDecoded = len;
	}
	return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}
var cachedTextEncoder = new TextEncoder();
if (!("encodeInto" in cachedTextEncoder)) cachedTextEncoder.encodeInto = function(arg, view) {
	const buf = cachedTextEncoder.encode(arg);
	view.set(buf);
	return {
		read: arg.length,
		written: buf.length
	};
};
var WASM_VECTOR_LEN = 0;
var wasm;
function __wbg_finalize_init(instance, module) {
	wasm = instance.exports;
	cachedDataViewMemory0 = null;
	cachedUint8ArrayMemory0 = null;
	wasm.__wbindgen_start();
	return wasm;
}
async function __wbg_load(module, imports) {
	if (typeof Response === "function" && module instanceof Response) {
		if (!module.ok) throw new Error(`failed to fetch Wasm: ${module.status} ${module.statusText} fetching '${module.url}'`);
		if (typeof WebAssembly.instantiateStreaming === "function") try {
			return await WebAssembly.instantiateStreaming(module, imports);
		} catch (e) {
			if (expectedResponseType(module.type) && module.headers.get("Content-Type") !== "application/wasm") console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);
			else throw e;
		}
		const bytes = await module.arrayBuffer();
		return await WebAssembly.instantiate(bytes, imports);
	} else {
		const instance = await WebAssembly.instantiate(module, imports);
		if (instance instanceof WebAssembly.Instance) return {
			instance,
			module
		};
		else return instance;
	}
	function expectedResponseType(type) {
		switch (type) {
			case "basic":
			case "cors":
			case "default": return true;
		}
		return false;
	}
}
function initSync(module) {
	if (wasm !== void 0) return wasm;
	if (module !== void 0) {
		if (Object.getPrototypeOf(module) === Object.prototype) ({module} = module);
		else console.warn("using deprecated parameters for `initSync()`; pass a single object instead");
	}
	const imports = __wbg_get_imports();
	if (!(module instanceof WebAssembly.Module)) module = new WebAssembly.Module(module);
	return __wbg_finalize_init(new WebAssembly.Instance(module, imports), module);
}
async function __wbg_init(module_or_path) {
	if (wasm !== void 0) return wasm;
	if (module_or_path !== void 0) {
		if (Object.getPrototypeOf(module_or_path) === Object.prototype) ({module_or_path} = module_or_path);
		else console.warn("using deprecated parameters for the initialization function; pass a single object instead");
	}
	const imports = __wbg_get_imports();
	if (typeof module_or_path === "string" || typeof Request === "function" && module_or_path instanceof Request || typeof URL === "function" && module_or_path instanceof URL) module_or_path = fetch(module_or_path);
	const { instance, module } = await __wbg_load(await module_or_path, imports);
	return __wbg_finalize_init(instance, module);
}
var Renderer = class {
	inner = new Renderer$1();
	fonts = new s((font) => this.inner.registerFont(font));
	async render(node, options) {
		const { options: opts } = await c(this.fonts, options ?? {}, node);
		return this.inner.render(node, opts);
	}
	async renderAsDataUrl(node, options) {
		const { options: opts } = await c(this.fonts, options ?? {}, node);
		return this.inner.renderAsDataUrl(node, opts);
	}
	async renderSvg(node, options) {
		const { options: opts } = await c(this.fonts, options ?? {}, node);
		return this.inner.renderSvg(node, opts);
	}
	async measure(node, options) {
		const { options: opts } = await c(this.fonts, options ?? {}, node);
		return this.inner.measure(node, opts);
	}
	async renderAnimation(options) {
		const nodes = options.scenes.map((scene) => scene.node);
		const { options: opts } = await c(this.fonts, options, nodes);
		return this.inner.renderAnimation(opts);
	}
	registerFont(font) {
		return this.fonts.register(font);
	}
	/** Releases the underlying wasm renderer's memory. */
	free() {
		this.inner.free();
	}
};
//#endregion
//#region node_modules/.pnpm/takumi-js@2.13.7_csstype@3.2.3_preact@10.29.3_react@19.2.4/node_modules/takumi-js/dist/wasm-init-DzwbPAKW.mjs
var wasm_init_DzwbPAKW_exports = /* @__PURE__ */ __exportAll$1({
	n: () => wasm_init_exports,
	t: () => initWasm
});
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var wasm_init_exports = /* @__PURE__ */ __exportAll({ initWasm: () => initWasm });
/**
* Initializes the WASM bindings, preferring a caller-supplied `module` and
* falling back to the per-bundler binary picked by the import condition.
* `@takumi-rs/wasm` guards against double init, so a binary already loaded by
* `@takumi-rs/wasm/auto` (e.g. on Deno) makes this a no-op.
*/
async function initWasm(module, fallback) {
	const source = module ?? fallback;
	const resolved = typeof source === "function" ? await source() : await source;
	const input = resolved !== null && typeof resolved === "object" && "default" in resolved ? resolved.default : resolved;
	await __wbg_init(input ? { module_or_path: input } : void 0);
	return export_exports;
}
//#endregion
export { o$1 as a, i$1 as i, wasm_init_DzwbPAKW_exports as n, e as r, initWasm as t };
