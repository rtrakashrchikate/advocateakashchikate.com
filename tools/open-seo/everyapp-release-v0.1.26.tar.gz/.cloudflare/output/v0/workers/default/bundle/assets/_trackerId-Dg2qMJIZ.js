import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { Fn as object, lr as uuid, xn as literal } from "./schemas-BPIpYT5n.js";
//#region src/types/schemas/local-seo-search.ts
var localSeoSearchSchema = object({
	view: literal("history").optional().catch(void 0),
	keyword: uuid().optional(),
	scan: uuid().optional(),
	point: uuid().optional()
});
//#endregion
//#region src/routes/_app/p/$projectId/local-seo/$trackerId.tsx
var $$splitComponentImporter = () => import("./_trackerId-CzHoDhqP.js");
var Route = createFileRoute("/_app/p/$projectId/local-seo/$trackerId")({
	validateSearch: localSeoSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
