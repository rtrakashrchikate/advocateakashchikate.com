//#region src/shared/report-share.ts
/**
* 24 random bytes rendered base64url: 192 bits of entropy in exactly 32
* characters, with no padding and nothing to percent-encode in a path segment.
* The token IS the capability \u2014 there is no second factor on `/s/<token>` \u2014 so
* it comes from `crypto.getRandomValues`, never `Math.random` or a uuid.
*/
function mintShareToken() {
	const bytes = crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(24));
	return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}
/** The public path for a token. One definition, used by both routes and the app. */
var sharePath = (token) => `/s/${token}`;
//#endregion
export { sharePath as n, mintShareToken as t };
