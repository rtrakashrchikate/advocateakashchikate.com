import { n as notFound } from "./not-found-DhdZhR3a.js";
import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { f as usesBetterAuthClient } from "./auth-mode-DhGCw2Bx.js";
import { t as pageHead } from "./pageHead-BfhwMlwa.js";
//#region src/routes/accept-invitation.$id.tsx
var $$splitComponentImporter = () => import("./accept-invitation._id-gBQAztB9.js");
var Route = createFileRoute("/accept-invitation/$id")({
	head: () => pageHead("Accept invitation"),
	beforeLoad: () => {
		if (!usesBetterAuthClient()) throw notFound();
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
