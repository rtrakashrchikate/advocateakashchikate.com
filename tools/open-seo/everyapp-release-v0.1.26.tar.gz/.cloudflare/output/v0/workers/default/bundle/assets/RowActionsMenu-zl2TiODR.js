import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as Ellipsis } from "./ellipsis-BmQZ40Fl.js";
import { t as Button } from "./button-DrcZrdio.js";
import { l as DropdownMenuTrigger, n as DropdownMenuContent, t as DropdownMenu } from "./dropdown-menu-DubRfxrI.js";
//#region src/client/components/RowActionsMenu.tsx
var import_jsx_runtime = require_jsx_runtime();
/** The kebab menu at the end of a table row. Children are `DropdownMenuItem`s. */
function RowActionsMenu({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "icon-xs",
			"aria-label": label
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, {})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, {
		align: "end",
		className: "w-auto min-w-40",
		children
	})] });
}
//#endregion
export { RowActionsMenu as t };
