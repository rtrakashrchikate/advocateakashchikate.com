//#region \0%23tanstack-start-server-fn-resolver
var manifest = {
	"00d9b86cac232beb62a3db5498ddb39bb62800fa3d0bd513d2cf513d616a8585": {
		functionName: "switchToProjectOrganization_createServerFn_handler",
		importer: () => import("./organization-C_2HV81w.js")
	},
	"0146a46bbe4471991fcb6663852023dad568931c1314b55cc81892ca37f08e45": {
		functionName: "exportSavedKeywords_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"02829e30c3478ce6fa128dba7467f3adc8a4086892ed668b6f9ca56a3b1c0c8b": {
		functionName: "getDomainPagesPage_createServerFn_handler",
		importer: () => import("./domain-X3jxz9VN.js")
	},
	"02a3f23c7994a670645e4ace9876310700d9e054aab37095332d1846e11ec462": {
		functionName: "disconnectGsc_createServerFn_handler",
		importer: () => import("./gsc-By688xsh.js")
	},
	"034df6b5fe778cbf6b972ce7f118196a4c5fd2a688f0f8d77023db66f9fc87d6": {
		functionName: "dismissDashboardAgentCard_createServerFn_handler",
		importer: () => import("./dashboard-8FpmOU5H.js")
	},
	"036e39c9273517cfd6b61d40fd23ac5d7595b9f3e596ec0855b8ffe11dd736d3": {
		functionName: "createBillingPortalSession_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	},
	"03f6b933adea1749a90a3091b941383771384ee499865ac928e32750bb3b6da1": {
		functionName: "exportSearchPerformanceTable_createServerFn_handler",
		importer: () => import("./searchPerformance-C38lQAK7.js")
	},
	"0400cd589829703979c0d6b38188a846f541034cb534b51326766d1a7f007970": {
		functionName: "exportAuditLighthouseIssues_createServerFn_handler",
		importer: () => import("./lighthouse-CrRoPszD.js")
	},
	"046776517b68d488e3ee09004a9f31a90f45c35a2b32b60dc538eaaf00a36b9c": {
		functionName: "getDomainOverview_createServerFn_handler",
		importer: () => import("./domain-X3jxz9VN.js")
	},
	"048f26ede391a38ee6e00487163fdc66dd0897e3a1cc488354a840bbf9b0b9cf": {
		functionName: "getDomainKeywordsPage_createServerFn_handler",
		importer: () => import("./domain-X3jxz9VN.js")
	},
	"06c91e3888f8bcec4a820827c04796cd80041afad39d1b5549be4e2cf810951b": {
		functionName: "lookupBrand_createServerFn_handler",
		importer: () => import("./ai-search-DwSd78Ni.js")
	},
	"09c514dd45ad926adb77137e5329a7701b08aa54de59598ad390532496e10ca0": {
		functionName: "getAiVisibilityAnswer_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"0a0791b200d03eb44d9630e461ef914d1da85bde9c95b201dcbeb94624848971": {
		functionName: "refreshSavedKeywordMetrics_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"0a4a16ebe522d754ddd99b702cf7418577545e6ce062ede31ea16bc201d64943": {
		functionName: "getGscConnection_createServerFn_handler",
		importer: () => import("./gsc-By688xsh.js")
	},
	"0a647ccf30a89d578588ec75e47194cefc41af7e42827d8421f039d55658edf6": {
		functionName: "revokeMcpConnection_createServerFn_handler",
		importer: () => import("./mcp-connections-D1p-1AWp.js")
	},
	"0c268077775b1f812d23756142e5d64fff541f1240b6328a92da446160513af2": {
		functionName: "getBacklinksReferringDomains_createServerFn_handler",
		importer: () => import("./backlinks-G8_943ly.js")
	},
	"0c8bc9b67b0ea0a9717a6cab4355542e7c451887732f6d9ee99a8f0ed33cf5de": {
		functionName: "getDomainKeywordSuggestions_createServerFn_handler",
		importer: () => import("./domain-X3jxz9VN.js")
	},
	"0ca7e7fd914e198e72f6ce0f3a36134fc1ec7b6dedf4da1c013ccd9c2da36595": {
		functionName: "archiveProject_createServerFn_handler",
		importer: () => import("./projects-CJDfkbx3.js")
	},
	"0e2299d91fe830180a5418ad53dd35b4fca59a0bcbd2727c9f3eff6680a88592": {
		functionName: "triggerRankCheck_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"0f196e5eafbe1adb2d3f31aa7558728e7648574a837571aa8f8f35b94a56d562": {
		functionName: "updateSavedKeywordTags_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"1166d95317aec17ef180de12f84493aa962df45035a16135f0a4ed81f7b8a834": {
		functionName: "getAccountDeletionStatus_createServerFn_handler",
		importer: () => import("./account-deletion-B4eXoly9.js")
	},
	"12b03b0354d04a43cf3d4486f81adc1c666876494f6a4e20f07319a5be99d439": {
		functionName: "getKeywordSuggestions_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"12cf2e90eb0e8dcafea37c63e5def7f535d4297b38130174b35113263fe01dd7": {
		functionName: "getDashboardEmergingQueries_createServerFn_handler",
		importer: () => import("./dashboard-8FpmOU5H.js")
	},
	"131f47ab2c8b293725f7a4013737cb0d5e77f8ac22c985f4952b7140820a6430": {
		functionName: "setGa4Property_createServerFn_handler",
		importer: () => import("./ga4-DCMuNLYL.js")
	},
	"13eeafe356c5e89ea66a0f817cddc7ecf567b949ea0f379f5d51c885ee3850bb": {
		functionName: "startAiResearchSetup_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"1655604aeefb1a34826090cdafb075f5cfd8924bb0f1f875779156c2df17ca4d": {
		functionName: "getDashboardKeywords_createServerFn_handler",
		importer: () => import("./dashboard-8FpmOU5H.js")
	},
	"16b8b61d3cfc645bc36be38a136d9d7ad7096edf8550536a9b522e2833bd5c45": {
		functionName: "updateRankTrackingConfig_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"16b95567643a21275b38fde625b8e1428bd2aeaff2440637c2a21009637d64d9": {
		functionName: "searchSerpLocations_createServerFn_handler",
		importer: () => import("./serp-locations-DddNEf5E.js")
	},
	"17c1167140bde128372935a660b28fd6e0e183774ca3f90271799ba787ecb243": {
		functionName: "refreshTrackingKeywordMetrics_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"18dd16e01eb78552f527d11670fb1a36f78c7b1e6c94df5e63902f0ec18e649c": {
		functionName: "requestAccountDeletion_createServerFn_handler",
		importer: () => import("./account-deletion-B4eXoly9.js")
	},
	"1c37d6d588141eb6ff4ed0b1776196f3493d263cd15565fc317afeae0f41540c": {
		functionName: "restoreProject_createServerFn_handler",
		importer: () => import("./projects-CJDfkbx3.js")
	},
	"1cca473f59402f4054b6e320d74b9ae77c462e3fa05628707233ab1d90112bff": {
		functionName: "getDashboardLinkActivity_createServerFn_handler",
		importer: () => import("./dashboard-8FpmOU5H.js")
	},
	"1cf1ffd3fa2ffbc031436db9db23646c4a3293cd193dd589ac8d747db58c3379": {
		functionName: "generateKeywordSuggestions_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"1d147786bb4efc50107e0030500c0d345b524d45211d5b5a8496b06fa13b2b18": {
		functionName: "listSamSessions_createServerFn_handler",
		importer: () => import("./sam-BFWneua8.js")
	},
	"1d75d4deb3fcbaf04305fae69c64722313c46f5620de0ece3b950cff9346e099": {
		functionName: "saveKeywords_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"1e3e63b95fa90f1fafbcda79f9999a31747ab722474f0eae185243ffdd1b06ab": {
		functionName: "estimateRankCheckCost_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"1e8f375975f9b25f935c01e1ed6d63147b5a7fe8693c2737dcc1869d8ef97f3b": {
		functionName: "removeSavedKeywords_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"21bda84f8a94df334b84c717a93c7a14171d2cb9718f56347c6709384af43816": {
		functionName: "startGa4Link_createServerFn_handler",
		importer: () => import("./ga4-DCMuNLYL.js")
	},
	"220c6035bb5b3c7fd8343bef9e256cab776763369fc507f45ae0676199e59f07": {
		functionName: "getDashboardBacklinks_createServerFn_handler",
		importer: () => import("./dashboard-8FpmOU5H.js")
	},
	"2498dc9ae1c9692a93484405a16016aa8af2296e6a6ac6c892aeff22c4154f17": {
		functionName: "getRankTrackingConfigs_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"258d28f360a42fb9dc6a60c60b05f23782f2fe2bf58c46d6e683b5d80693aadf": {
		functionName: "createRankTrackingConfig_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"258f5a9817cc2bde2a9731caff8ee5eebd42f0932661d6232984056163895891": {
		functionName: "getOrganizationContext_createServerFn_handler",
		importer: () => import("./organization-C_2HV81w.js")
	},
	"273ab5dcd2c400c13c6eaf49ea723e422c6435074e7b455c4fa0d0bd03df362a": {
		functionName: "archiveSamSession_createServerFn_handler",
		importer: () => import("./sam-BFWneua8.js")
	},
	"278ebde0d517c2ebe20e607d3d88ad2fb75a216d2567a5dfcf5808ab244908f7": {
		functionName: "getProjects_createServerFn_handler",
		importer: () => import("./projects-CJDfkbx3.js")
	},
	"2879a9e37e8fca55f4feda24944621abd888ee1872d158129f9a4e1d88af6df7": {
		functionName: "setAutoReload_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	},
	"28befcfbcf5683730f549639069058edbfbd3a389e71ce306bfa660e36ccc7e2": {
		functionName: "listCrawlerCredentials_createServerFn_handler",
		importer: () => import("./crawlerAccess-HOPmBXLr.js")
	},
	"29af3c6e5da3cde812413ecf58c11071ecb199e52d51246f51e1752ba03d291f": {
		functionName: "listBillingInvoices_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	},
	"2d12fc6a75afd97cb13d427976226e3dbfeb02b74b6ced8ab774e2b094fe37ec": {
		functionName: "getScheduledRankChecksPaused_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"2d163bd8f7a3abb4c6c06bb86b68f952fce78a24992b294a018759ceffc51fa0": {
		functionName: "createLocalTracker_createServerFn_handler",
		importer: () => import("./local-seo-CF2Qh2jL.js")
	},
	"315ae73a9d5769afc09d91fb78203214540b8a7a173001f0be5268d556305cb3": {
		functionName: "getLocalScan_createServerFn_handler",
		importer: () => import("./local-seo-CF2Qh2jL.js")
	},
	"319d82ec75b2b49399d07e97a0efffd36bd56066017d95b692e7074cae6b1272": {
		functionName: "getAhrefsDomainRatings_createServerFn_handler",
		importer: () => import("./ahrefs-BVYbWNbi.js")
	},
	"3331b37f10ddbfddbbc52452bd8b8b36ac7e7d2358ce6e305c3977a290263f7a": {
		functionName: "setProductUpdatesOptIn_createServerFn_handler",
		importer: () => import("./product-updates-B2bV2A8M.js")
	},
	"364efb68f010cdd93e01da48b22253ac6e745a792ce18710f489a70100cde203": {
		functionName: "prewarmSerpLocations_createServerFn_handler",
		importer: () => import("./serp-locations-DddNEf5E.js")
	},
	"368cb0582bd2b9ca19cca3123a2587fd9c1628a09d94ff3740b277802ea5ebe4": {
		functionName: "upgradePlan_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	},
	"38676cda69cb582c6220c4a51de4155a1b9ab727f01e970d9c8db0696ea8209e": {
		functionName: "setAiVisibilitySchedule_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"3992eeb732a54c016d637cd834430e610782f810ec9045432cdb3a2a10004091": {
		functionName: "reportCheckoutStart_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	},
	"39b646e1b210269ed692e316a1456d18b70794e8f2dd13b038ab141fc56de0c7": {
		functionName: "dismissDashboardGa4Card_createServerFn_handler",
		importer: () => import("./dashboard-8FpmOU5H.js")
	},
	"3b7a7d39821bb858a8e568dde7f4b7c984fdcbb1b94e2a1b26d91fdf25ff537f": {
		functionName: "updateSavedKeywordTag_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"3d7f65dfdb19058c1c6e4e20c55a56e9a9dd4247087215febdb7d1a40508edfe": {
		functionName: "acceptTermsUpdate_createServerFn_handler",
		importer: () => import("./terms-KZ6c-5uC.js")
	},
	"3e3d258ab33e0eec91eb42119fe6c8a85d60b57d03009024e754a252e2a8327d": {
		functionName: "getBillingAccount_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	},
	"407d510f79150a0f26b84675e84a2343014478019f7006cf02e64e3a875447f3": {
		functionName: "setUpIndexNow_createServerFn_handler",
		importer: () => import("./indexnow-DALB3Tx1.js")
	},
	"4123ab2c08090f8c76dca028d255df6d592a335e97c82bd9e8de0f785c55ceeb": {
		functionName: "getAiVisibilityTracker_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"438bbf3eb509914a31b35f8d0b4ec233886ee6ce742cdd7342bd2c6b4def8803": {
		functionName: "getAiResearchSetup_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"4668838a0991d80854db79faaeabec4c89b617106fa4ad7bb0435889c8e5402f": {
		functionName: "listMcpConnections_createServerFn_handler",
		importer: () => import("./mcp-connections-D1p-1AWp.js")
	},
	"47f4e168632e9bfd56794677badebb717fc5ce10103810690f0c3bdc5d098227": {
		functionName: "getBacklinksTopPages_createServerFn_handler",
		importer: () => import("./backlinks-G8_943ly.js")
	},
	"48d30e240455ab974c90d5defd14655146a5a189317efb46dfb6f240cbd157b4": {
		functionName: "shareReport_createServerFn_handler",
		importer: () => import("./reports-CroGLZcA.js")
	},
	"4904ee1c0cc68d717399e853e8f38885a443e82e0ed6b6bfe992d1b21c3b6955": {
		functionName: "deleteReport_createServerFn_handler",
		importer: () => import("./reports-CroGLZcA.js")
	},
	"4b2c9e5c0f9644b9fbac2cb8386732eb0a841e114a289b83cefa630dbcf49660": {
		functionName: "getAuditSummary_createServerFn_handler",
		importer: () => import("./audit-IWjgIb_Z.js")
	},
	"4f6705b014949bf8788050812f0e69f008b88223a27338b55f74fe6f900d69ca": {
		functionName: "getLocalMapCopyright_createServerFn_handler",
		importer: () => import("./google-maps-xG1Fj7JE.js")
	},
	"5036bfbbb0648430f1305a7b8a9540118bd537d96bd6f393c94d703319ee3282": {
		functionName: "dismissGscNudge_createServerFn_handler",
		importer: () => import("./onboarding-DGH9z6Wb.js")
	},
	"516782e359aa3cdba9ed9ea54db3d5b889263ae7b7a025542320a44198af7371": {
		functionName: "deleteAudit_createServerFn_handler",
		importer: () => import("./audit-IWjgIb_Z.js")
	},
	"5508a7b8c2ede1eee34a3696a25fb1813f0d30238ed1d48ca28dfbbbe7f5ac14": {
		functionName: "createSamSession_createServerFn_handler",
		importer: () => import("./sam-BFWneua8.js")
	},
	"55da6bb0f1efa6c7dab8088f8f282ab3d25d137bd67f9d333e7f90781a3dd032": {
		functionName: "unshareReport_createServerFn_handler",
		importer: () => import("./reports-CroGLZcA.js")
	},
	"57eebe4b148ecd8baeab46c7dc1c92b78de5e9a45d9f805e437b74cda250d02e": {
		functionName: "getSamAccessSetupStatus_createServerFn_handler",
		importer: () => import("./samAccess-BLC-3Jwm.js")
	},
	"5d6e81c82478ac1c29d17d535f32a3436431d7aaa0ab097f7e9e1ba6b538d188": {
		functionName: "listLocalTrackers_createServerFn_handler",
		importer: () => import("./local-seo-CF2Qh2jL.js")
	},
	"61741a7eb01a8566e6e4374c5fd2fdabaaf91ead63f27b96a7bd98625063f3cb": {
		functionName: "lookupLocalBusiness_createServerFn_handler",
		importer: () => import("./local-seo-CF2Qh2jL.js")
	},
	"6d7adb29ead7ab7b1698bde4f8ec4d5779c25a265645bbc6910edc16c5ca6a73": {
		functionName: "transferOwnership_createServerFn_handler",
		importer: () => import("./organization-C_2HV81w.js")
	},
	"6ddfb7a81efc3428790c631bf5547eeee71c77909fc1fce99b67caeb84279006": {
		functionName: "getAuditIssues_createServerFn_handler",
		importer: () => import("./audit-IWjgIb_Z.js")
	},
	"732677e954653e1dd758107b35a2c7548bb3bcf8ee01b685427c6f821331faf9": {
		functionName: "startLocalCheck_createServerFn_handler",
		importer: () => import("./local-seo-CF2Qh2jL.js")
	},
	"75f7965168786313e194a1941f91dd242a6b8c06b1cf69463eae0e9ce5dd6773": {
		functionName: "getAuditStatus_createServerFn_handler",
		importer: () => import("./audit-IWjgIb_Z.js")
	},
	"7666c5fd0729301eb5398e487331f9964d8727591046839d77bd310afdef21ab": {
		functionName: "getAiVisibilityTrend_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"76e64e0e5428cf6aff10f8b70b7f4c76681389990734ba9fbabc508e710f6765": {
		functionName: "saveAiVisibilityTracker_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"78f0a49990970b9cd9471f61034b671a1e71e3748c2f0cee639871f1ea324f89": {
		functionName: "setDashboardStepDismissed_createServerFn_handler",
		importer: () => import("./dashboard-8FpmOU5H.js")
	},
	"7a3ccd49a583d669523ebc977678f95cac97fe4eaa09a3151a6af5732a78eb03": {
		functionName: "getProjectContext_createServerFn_handler",
		importer: () => import("./projectContext-CNkP04xX.js")
	},
	"7b8de3fbeb51a65e379ae881c3b52cbe3e142e1231f0cf89ea7d87dbded831e8": {
		functionName: "getMcpAuthorizedAt_createServerFn_handler",
		importer: () => import("./onboarding-DGH9z6Wb.js")
	},
	"7d0fd8a9b28dba5f2f04ec33eb4c6080c38f16ae0c552126604a70af565da340": {
		functionName: "getLocalTracker_createServerFn_handler",
		importer: () => import("./local-seo-CF2Qh2jL.js")
	},
	"818c0e47d566b0b60260e752f7c39c7e2b1d4dc6a2136df2d6d0238ddea5c4cf": {
		functionName: "updateLocalKeywords_createServerFn_handler",
		importer: () => import("./local-seo-CF2Qh2jL.js")
	},
	"87159a1512adea0f10ae9e0c3b2144d065c7266c4c10b0f0b0b4aec0fefb4aa7": {
		functionName: "previewPlanUpgrade_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	},
	"8903ef9d79153d21788e22d2195e4b9ab8423b97de57d78b3ab88c5df9c85e70": {
		functionName: "getAuditPages_createServerFn_handler",
		importer: () => import("./audit-IWjgIb_Z.js")
	},
	"8907d86e952b72ab2aa7e04f0b8bc7bdd81fca3ab7ebd77a59a2f880da0ec188": {
		functionName: "saveCrawlerCredential_createServerFn_handler",
		importer: () => import("./crawlerAccess-HOPmBXLr.js")
	},
	"8acb99c0e5b1aed5cfb75318e78747749f8c2c54884ba18ff1c945a9b06a9375": {
		functionName: "getSavedKeywords_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"8e1e5f26a194415159d9074271d62e81c5b365b4c35612f4e23581af549700cf": {
		functionName: "getAuditHistory_createServerFn_handler",
		importer: () => import("./audit-IWjgIb_Z.js")
	},
	"8e808794c415d4335be9b0c4f9fea3763e25a671da529f63b40b3f8e93c7170b": {
		functionName: "deleteArchivedProject_createServerFn_handler",
		importer: () => import("./projects-CJDfkbx3.js")
	},
	"8f98467006db101f85fe1cc69a13c6ec19bee0233acb910b528d66105435362d": {
		functionName: "switchOrganization_createServerFn_handler",
		importer: () => import("./organization-C_2HV81w.js")
	},
	"9059a6b8babf4dd972195adcbd6d5b0a44a9abda3a66071b8b90e201141c10d5": {
		functionName: "saveOnboardingAnswers_createServerFn_handler",
		importer: () => import("./onboarding-DGH9z6Wb.js")
	},
	"9288a36e212527e9a39a041b25309844bcc487ad4485f4c446376761ea00747c": {
		functionName: "getAiVisibilitySources_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"928b81f17cde1c7afd6fa15afb9df0d43555915dba7bc5d293cda200d87d5806": {
		functionName: "getEveryAppAccount_createServerFn_handler",
		importer: () => import("./everyApp-DJN4Lrnt.js")
	},
	"955fb22c05a803998669e9e3cb307dc405e545b788cf580fa37af4236d97b07a": {
		functionName: "getAuditLighthouseIssues_createServerFn_handler",
		importer: () => import("./lighthouse-CrRoPszD.js")
	},
	"956a5e2004016739fc80341f1095d7bd8a96655c6c9fe7ba4126d97f40498e2a": {
		functionName: "listGscSites_createServerFn_handler",
		importer: () => import("./gsc-By688xsh.js")
	},
	"9632bd92f3de61b172319c2b693ceaafbbc52f214ba2a4fb93531fefa5b96d74": {
		functionName: "addTrackingKeywords_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"97f60b5e66484cee89a92a95c9026d73eb41370f8bbed1e07a16530b77daf61f": {
		functionName: "removeGoogleAccount_createServerFn_handler",
		importer: () => import("./googleAccounts-D7Knxim4.js")
	},
	"9ae860b1d0f9c40d6c4b0e035ec044bb80267ef265cc8a090f04db230dc7aaea": {
		functionName: "generateAiVisibilityPrompts_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"9ce7a2858b82783ef908f4396d61f4645b09ab4cbc435936a1495f8c23bcdb8d": {
		functionName: "deleteSavedKeywordTag_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"9d62c976afd0592ac01d146421e81b4b46e99090b01e75b15797fba6d6af5e1d": {
		functionName: "disconnectGa4_createServerFn_handler",
		importer: () => import("./ga4-DCMuNLYL.js")
	},
	"9da63329d53b960da32b79472469175d63f38b5e71bcef0cacabb66cba684931": {
		functionName: "getRankConfigTrend_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"9f89caac05689c3f844d5e9fdb4453cd3dbe85e64cddf60d717dad8ccc0ef965": {
		functionName: "getArchivedProjects_createServerFn_handler",
		importer: () => import("./projects-CJDfkbx3.js")
	},
	"a19f7c4228fdbf301aeba791a8732ae65a0018a25d353bdeed6343876396dd0d": {
		functionName: "getSerpAnalysis_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"a251675043aa688af223c180c37e19f98f6652a33f993dc7d1b14c4ce4ed3589": {
		functionName: "getSearchPerformanceReport_createServerFn_handler",
		importer: () => import("./searchPerformance-C38lQAK7.js")
	},
	"a28e240f440a737b1ba00fa06c35615836e9658df9c6a9b04b18bd57f4533a93": {
		functionName: "getCrawlProgress_createServerFn_handler",
		importer: () => import("./audit-IWjgIb_Z.js")
	},
	"a2d6a29497c1bebbf28ef40173a2712df71d7f163b0d27ba172aa05b8d2bd882": {
		functionName: "updateProjectContext_createServerFn_handler",
		importer: () => import("./projectContext-CNkP04xX.js")
	},
	"a49c4261f3f65e415401c7162c49edf3e6134bc3554b0b96f1230779dcdebd9b": {
		functionName: "getBacklinksOverview_createServerFn_handler",
		importer: () => import("./backlinks-G8_943ly.js")
	},
	"a4a9247a2916093ffa4adf9b4628e1d7f55af8b119ae1f0147a8b5ef5fd08691": {
		functionName: "getBacklinksRows_createServerFn_handler",
		importer: () => import("./backlinks-G8_943ly.js")
	},
	"a4aee3230867065a09c55145cf58c1f5bc0fb9ed2f053bda4ac2d635a4d2bcb4": {
		functionName: "getSearchPerformanceTable_createServerFn_handler",
		importer: () => import("./searchPerformance-C38lQAK7.js")
	},
	"a4c5ccb6a409cc77e5e7b9193c9dc297024a48793fcd4437e01eb3aa2e1e71ea": {
		functionName: "getGa4Connection_createServerFn_handler",
		importer: () => import("./ga4-DCMuNLYL.js")
	},
	"a652f6f5ac08420a126c8459db2cdb1b3b0da797b0151824db9674012541f2d3": {
		functionName: "updateProject_createServerFn_handler",
		importer: () => import("./projects-CJDfkbx3.js")
	},
	"a966ba8dbd2e5e2548b12a6c770c26da924f90ee327285fecd7df1d7afeafe95": {
		functionName: "getDashboardActivation_createServerFn_handler",
		importer: () => import("./dashboard-8FpmOU5H.js")
	},
	"aa25ed716b9d07a13f1f14b6bf21449bb122f3771eb424c765cf7cc12a979e57": {
		functionName: "exportAiVisibilityData_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"aa44d614f47b3bb85e24f8a83eaae32640bf1c04cee21679aef75e33285b6694": {
		functionName: "getBillingUsage_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	},
	"ac9f991fa4b32f09ce6b8041c8015a98dff65164124db2f699122e3b20f25ffd": {
		functionName: "getTeam_createServerFn_handler",
		importer: () => import("./organization-C_2HV81w.js")
	},
	"ad5d9770b41a3fe6e95b4eebd6d96ed461b12618b2e529b2d218dba294ec68f0": {
		functionName: "getAiVisibilityResults_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"adc17b9c24dc0b2f3130d11eb1c67a97b5778abe0418ddb33a7128b724e08223": {
		functionName: "listAiResearchKeywords_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"aef09a57d39104b1d10659a92003c6f2a2a124fab74bdfc9358f984506751295": {
		functionName: "getGa4DashboardReport_createServerFn_handler",
		importer: () => import("./ga4-DCMuNLYL.js")
	},
	"afea34b6bf4da665d300c562fed995ffb979fe6ebb3bdb7d08c7ce493506a148": {
		functionName: "listGa4Properties_createServerFn_handler",
		importer: () => import("./ga4-DCMuNLYL.js")
	},
	"b15541a6fdddc2e380c284e3172b98a1e5a18703b9c10470d2c2d23c70593389": {
		functionName: "submitIndexNowUrls_createServerFn_handler",
		importer: () => import("./indexnow-DALB3Tx1.js")
	},
	"b55a517c6ff4161ff3bcf8bfa47562d71dd21f63950855318e723829d164b395": {
		functionName: "getGscGrantStatus_createServerFn_handler",
		importer: () => import("./gsc-By688xsh.js")
	},
	"b5858986f4b26fbc7f2cea62479e3b4d97d5c4af0a61b218af88501443a3939c": {
		functionName: "getSeoApiKeyStatus_createServerFn_handler",
		importer: () => import("./config-CwXxjz-e.js")
	},
	"b694e15848bbfda53bac85dff1f870f149e6a0d751aec69fb3ac5ba8b92e5132": {
		functionName: "listReports_createServerFn_handler",
		importer: () => import("./reports-CroGLZcA.js")
	},
	"b9e1c8827cf9e915cf77cf19c85a084e1d5772198eab957890605d17d30661c7": {
		functionName: "saveReportTemplate_createServerFn_handler",
		importer: () => import("./reportTemplates-Dbb9c6Rc.js")
	},
	"bae0716c278ff567d6fca6035b6fc999ec74301979582cb6eb930ca66771f85f": {
		functionName: "getWorkspaceMergeStatus_createServerFn_handler",
		importer: () => import("./workspace-CG0qGnge.js")
	},
	"bb79e98e928653ebc50e8c4bfd905ed74cfd81dc4ad11c40a96e517c7a538648": {
		functionName: "getRankTrackingConfigSummaries_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"beec8b1048f815a332fc9fa23c0720c1d5803e888aa8d668f77371d9363eb848": {
		functionName: "startGscLink_createServerFn_handler",
		importer: () => import("./gsc-By688xsh.js")
	},
	"bf7707a336fe5f1a810d29eb9ddb4ccee4b8a2f0ce88e94d04a295456d7e71d1": {
		functionName: "getDashboardOverview_createServerFn_handler",
		importer: () => import("./dashboard-8FpmOU5H.js")
	},
	"c0d5e5c1596b1dc41fa32ed6200a9dbbe633ef4199e220331621e3971f30acac": {
		functionName: "researchProjectWebsite_createServerFn_handler",
		importer: () => import("./projectWebsite-1CsBsT2V.js")
	},
	"c110cd319dd3e78815900c0e01f7e8412ee49a6f9779bf9d1e16979c92383ad3": {
		functionName: "estimateAiVisibilityCost_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"c1ed1bc6e0cd3fb1ff5741765a7752d9bb54f9e240f6d82b76251789102af69f": {
		functionName: "getGoogleAccountRemovalImpact_createServerFn_handler",
		importer: () => import("./googleAccounts-D7Knxim4.js")
	},
	"c288e068a5aa90edd2d6e810019e669b6439af68bf53c20745ceef6d6ecc2f8c": {
		functionName: "setInvoiceEmails_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	},
	"c6715a7072113d7f7ea076796cf28e47be1bab5e1dfd14502e72467efab53306": {
		functionName: "getRankPositionMatrix_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"c725f1cd8f793cde14b9c132b907097b4f850a65a9b7596fd16b97bd674cb914": {
		functionName: "getIndexNowSetup_createServerFn_handler",
		importer: () => import("./indexnow-DALB3Tx1.js")
	},
	"ca9c08a11ec01d215de1872722fd6d9aff065e1f082c6191040a443bd949a710": {
		functionName: "setTrackingKeywordsPinned_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"ce94acd9176be823a5dd0d1b5646b9a89bb6b8aa358cd355778fc6ee44d601ad": {
		functionName: "deleteCrawlerCredential_createServerFn_handler",
		importer: () => import("./crawlerAccess-HOPmBXLr.js")
	},
	"d034f8888a5e1014831023cf2a868291cfd466101140d59d1f4251fd53203037": {
		functionName: "removeTrackingKeywords_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"d1f2d6df775a95682f80a98e2ced1e2c0553c94a8452a94f9241ab709a5fce60": {
		functionName: "createProject_createServerFn_handler",
		importer: () => import("./projects-CJDfkbx3.js")
	},
	"d2bd198d2bfa42494e65407da774107b51ad449088c45a6020a8a65e0ac5142a": {
		functionName: "deleteReportTemplate_createServerFn_handler",
		importer: () => import("./reportTemplates-Dbb9c6Rc.js")
	},
	"d4fa5f681d9ed59db5cb372ca40f8a9d2baf1065bb30fbd2e38355adfdced757": {
		functionName: "createTopUpCheckout_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	},
	"d63594f2661e4c4997c8cdec9cb7707c452b48d1a1faaf42083d76e82f433466": {
		functionName: "getAiVisibilityRun_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"da0619ace7bd73480ad71e8a4ce76149a7a119ee2904958d8e42f024a4f6f639": {
		functionName: "sendTeamInvitation_createServerFn_handler",
		importer: () => import("./organization-C_2HV81w.js")
	},
	"db353c04583ad0a099587b79c0a3518606b059e8ac631f4bd24d91f1ff34bc2a": {
		functionName: "getReport_createServerFn_handler",
		importer: () => import("./reports-CroGLZcA.js")
	},
	"dd3518eb8d7349f47f651bb345e6a70e7b48073f2557d873f09c577b0deab0bb": {
		functionName: "mergeLegacyWorkspaces_createServerFn_handler",
		importer: () => import("./workspace-CG0qGnge.js")
	},
	"ddc61ba533ee4526881dec258edaa117eac5f2984345448f00e3ed653fb873ef": {
		functionName: "listReportTemplates_createServerFn_handler",
		importer: () => import("./reportTemplates-Dbb9c6Rc.js")
	},
	"ddd165935e6b49d3557cb04d17f77f9775c81fbb0c0f735387a032421a266542": {
		functionName: "getLatestRankResults_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"de61ac92db2a9949b67232b0b1132b6cbdd66b7f381be8a22e9c245c8126d1f6": {
		functionName: "getProjectAccess_createServerFn_handler",
		importer: () => import("./projects-CJDfkbx3.js")
	},
	"e0593cb3cd167f11494046a3c1187847a3aad41f64fc6f6ce6722d9c52cf2770": {
		functionName: "checkIndexNowKeyFiles_createServerFn_handler",
		importer: () => import("./indexnow-DALB3Tx1.js")
	},
	"e07b0dfacb31a403133cc5bf5e671e8b7735dd63c2c993749b4ecd399e779acb": {
		functionName: "getLatestRankRun_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"e239daa45c0dc82d2216f3ac9a60781ba3bad43f9837cb6779399d0c3d87885c": {
		functionName: "startAudit_createServerFn_handler",
		importer: () => import("./audit-IWjgIb_Z.js")
	},
	"e2b5146b78833600dfd30aa3bda214dfa8c480278644dcff1698db1e51e5759a": {
		functionName: "explorePrompt_createServerFn_handler",
		importer: () => import("./ai-search-DwSd78Ni.js")
	},
	"e3f0286978d1640c241a1fb8865f678847bb177c551dd989cbeea21723135382": {
		functionName: "researchAiVisibilityPrompts_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"e484ba444c8df180376d2d15c72338138a489e647355c5db83b69ca01fe5ca87": {
		functionName: "getAuditCapabilities_createServerFn_handler",
		importer: () => import("./audit-IWjgIb_Z.js")
	},
	"e6b585f226be072870789dce40c5c60ca1ea063143252ad91ef39557dcc7aa64": {
		functionName: "runAiVisibilityCheck_createServerFn_handler",
		importer: () => import("./ai-visibility-C9ACrJ2q.js")
	},
	"e808431fe24faa5cddaa82ff3cee05037bdd2ddd1ba1ceef693aac01ca8e68bc": {
		functionName: "getRankKeywordHistory_createServerFn_handler",
		importer: () => import("./rank-tracking--zdaY0Ny.js")
	},
	"ee56593aa127e081b934d6fec3a8bc310d3d98cbb59dd0947c77be7c85514de4": {
		functionName: "setGscSite_createServerFn_handler",
		importer: () => import("./gsc-By688xsh.js")
	},
	"f21c50e2c2f207cba8894f939be3793d3739780d472771c8e3e1ba2e5c1f8a34": {
		functionName: "saveOnboardingWebsite_createServerFn_handler",
		importer: () => import("./projects-CJDfkbx3.js")
	},
	"f3ccdf1c5f7849adbe55a38000c0c568b1f72b75fea6deea496f965b8c7ab155": {
		functionName: "getOnboardingAnswers_createServerFn_handler",
		importer: () => import("./onboarding-DGH9z6Wb.js")
	},
	"fa088bd63c78c66cb4de7e8be1d7567e0ec901107ad1afe33e0ffbeecc57bfbc": {
		functionName: "researchKeywords_createServerFn_handler",
		importer: () => import("./keywords-hYrZh_ZA.js")
	},
	"fa7c2597b8b61de5f30f270445da8576902f377aea987bee964b0ae3ac137791": {
		functionName: "saveProjectWebsiteSetup_createServerFn_handler",
		importer: () => import("./projectWebsite-1CsBsT2V.js")
	},
	"ff6e27773f4508bc652f07296be52303efe6bfa7d715f5369db02274e80f5eed": {
		functionName: "createPlanCheckout_createServerFn_handler",
		importer: () => import("./billing-CQDBniij.js")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
