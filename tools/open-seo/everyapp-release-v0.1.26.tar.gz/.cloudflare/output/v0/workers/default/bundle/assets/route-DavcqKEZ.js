import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { n as Outlet } from "./Match-Djim5BGq.js";
import { t as useMatch } from "./useMatch-BB4BMDVC.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { r as getCurrentAuthRedirectFromHref, s as getSignInSearch } from "./auth-redirect-Dnh6pyWf.js";
import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { n as getErrorCode } from "./error-messages-D7nntGF_.js";
import { a as switchToProjectOrganization } from "./organization-BUUwiNQd.js";
import { t as Route } from "./route-CfuJHeFM.js";
import { a as getProjectAccess } from "./projects-BLNM8KiA.js";
import { n as getLastProjectId, r as setLastProjectId, t as clearLastProjectId } from "./active-project-CjOtfLST.js";
//#region src/routes/_app/p/$projectId/route.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useProjectAccessRedirect(projectId) {
	const navigate = useNavigate();
	const access = useQuery({
		queryKey: ["projectAccess", projectId],
		queryFn: () => getProjectAccess({ data: { projectId } }),
		retry: false,
		staleTime: Infinity
	});
	const error = access.error;
	(0, import_react.useEffect)(() => {
		if (!error) return;
		if (getErrorCode(error) === "UNAUTHENTICATED") {
			navigate({
				to: "/sign-in",
				search: getSignInSearch(getCurrentAuthRedirectFromHref(window.location.href)),
				replace: true
			});
			return;
		}
		switchToProjectOrganization({ data: { projectId } }).then(() => window.location.reload(), () => {
			if (getLastProjectId() === projectId) clearLastProjectId();
			navigate({
				to: "/",
				replace: true
			});
		});
	}, [
		error,
		navigate,
		projectId
	]);
	return access.isSuccess;
}
function ProjectLayout() {
	const { projectId } = Route.useParams();
	const hasAccess = useProjectAccessRedirect(projectId);
	const isSettingsPage = useMatch({
		from: "/_app/p/$projectId/settings",
		shouldThrow: false,
		select: () => true
	}) ?? false;
	(0, import_react.useEffect)(() => {
		if (!hasAccess || isSettingsPage) return;
		setLastProjectId(projectId);
	}, [
		projectId,
		hasAccess,
		isSettingsPage
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
}
//#endregion
export { ProjectLayout as component };
