import { w as isAdsKeyword } from "./pricing-CjqMqwbe.js";
import { c as getKeywordDataProvider } from "./keyword-locations-4GfvBtRY.js";
//#region src/server/lib/dataforseo/keyword-metrics.ts
/**
* Google Ads search volume for the keywords Ads accepts. One rejected keyword
* fails the whole task, so rejected ones are skipped and get no Ads metrics.
*/
async function fetchAdsSearchVolumeForKeywords(client, params) {
	const keywords = params.keywords.filter(isAdsKeyword);
	return keywords.length > 0 ? client.keywords.adsSearchVolume({
		...params,
		keywords
	}) : [];
}
var KEYWORD_METRICS_BATCH_SIZE = 700;
function toMonthlySearches(entries) {
	return (entries ?? []).map((entry) => ({
		year: entry.year ?? 0,
		month: entry.month ?? 0,
		searchVolume: entry.search_volume ?? 0
	}));
}
function normalizeKeywordOverview(item, keyword) {
	const info = item.keyword_info;
	const clickstreamInfo = item.keyword_info_normalized_with_clickstream;
	const usesClickstream = clickstreamInfo?.search_volume != null;
	return {
		keyword,
		searchVolume: clickstreamInfo?.search_volume ?? info?.search_volume ?? null,
		cpc: info?.cpc ?? null,
		competition: info?.competition ?? null,
		competitionLevel: info?.competition_level ?? null,
		keywordDifficulty: item.keyword_properties?.keyword_difficulty ?? null,
		intent: item.search_intent_info?.main_intent ?? null,
		monthlySearches: toMonthlySearches(usesClickstream ? clickstreamInfo?.monthly_searches : info?.monthly_searches)
	};
}
function normalizeAdsKeyword(item, keyword) {
	return {
		keyword,
		searchVolume: item.search_volume ?? null,
		cpc: item.cpc ?? null,
		competition: item.competition_index != null ? item.competition_index / 100 : null,
		competitionLevel: item.competition ?? null,
		keywordDifficulty: null,
		intent: null,
		monthlySearches: toMonthlySearches(item.monthly_searches)
	};
}
async function fetchKeywordMetricsForList(client, params) {
	const useGoogleAds = getKeywordDataProvider(params.locationCode) === "google_ads";
	const rows = [];
	for (let i = 0; i < params.keywords.length; i += KEYWORD_METRICS_BATCH_SIZE) {
		const keywords = params.keywords.slice(i, i + KEYWORD_METRICS_BATCH_SIZE);
		if (useGoogleAds) {
			const items = await fetchAdsSearchVolumeForKeywords(client, {
				keywords,
				locationCode: params.locationCode,
				locationName: params.locationName,
				languageCode: params.languageCode,
				creditFeature: params.creditFeature
			});
			const covered = /* @__PURE__ */ new Set();
			for (const item of items) {
				if (!item.keyword) continue;
				covered.add(item.keyword.toLowerCase());
				rows.push(normalizeAdsKeyword(item, item.keyword));
			}
			rows.push(...keywords.filter((keyword) => !covered.has(keyword.toLowerCase()) && (params.locationName || !isAdsKeyword(keyword))).map(nullMetricRow));
		} else if (params.locationName) {
			const [adsItems, labsItems] = await Promise.all([fetchAdsSearchVolumeForKeywords(client, {
				keywords,
				locationCode: params.locationCode,
				locationName: params.locationName,
				languageCode: params.languageCode,
				creditFeature: params.creditFeature
			}), client.labs.keywordOverview({
				keywords,
				locationCode: params.locationCode,
				languageCode: params.languageCode,
				includeClickstreamData: params.includeClickstreamData ?? false,
				creditFeature: params.creditFeature
			})]);
			rows.push(...mergeLocalAndNationalRows(keywords, adsItems, labsItems));
		} else {
			const items = await client.labs.keywordOverview({
				keywords,
				locationCode: params.locationCode,
				languageCode: params.languageCode,
				includeClickstreamData: params.includeClickstreamData ?? false,
				creditFeature: params.creditFeature
			});
			for (const item of items) {
				if (!item.keyword) continue;
				rows.push(normalizeKeywordOverview(item, item.keyword));
			}
		}
	}
	return rows;
}
function nullMetricRow(keyword) {
	return {
		keyword,
		searchVolume: null,
		cpc: null,
		competition: null,
		competitionLevel: null,
		keywordDifficulty: null,
		intent: null,
		monthlySearches: []
	};
}
function mergeLocalAndNationalRows(keywords, adsItems, labsItems) {
	const labsByKeyword = new Map(labsItems.filter((item) => item.keyword).map((item) => [item.keyword.toLowerCase(), item]));
	const rows = [];
	const covered = /* @__PURE__ */ new Set();
	for (const item of adsItems) {
		if (!item.keyword) continue;
		covered.add(item.keyword.toLowerCase());
		const row = normalizeAdsKeyword(item, item.keyword);
		const labs = labsByKeyword.get(item.keyword.toLowerCase());
		row.keywordDifficulty = labs?.keyword_properties?.keyword_difficulty ?? null;
		row.intent = labs?.search_intent_info?.main_intent ?? null;
		rows.push(row);
	}
	for (const keyword of keywords) {
		if (covered.has(keyword.toLowerCase())) continue;
		const labs = labsByKeyword.get(keyword.toLowerCase());
		rows.push({
			...nullMetricRow(keyword),
			keywordDifficulty: labs?.keyword_properties?.keyword_difficulty ?? null,
			intent: labs?.search_intent_info?.main_intent ?? null
		});
	}
	return rows;
}
//#endregion
export { fetchKeywordMetricsForList as n, fetchAdsSearchVolumeForKeywords as t };
