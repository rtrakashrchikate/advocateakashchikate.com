import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { m as queryClient } from "./QueryState-Q8BZIblk.js";
import { c as aiPromptHistoryQueryOptions } from "./shared-BW7GMYqD.js";
//#region src/routes/_app/p/$projectId/ai-visibility/prompts/$promptId.tsx
var $$splitComponentImporter = () => import("./_promptId-CKT4sRIx.js");
var Route = createFileRoute("/_app/p/$projectId/ai-visibility/prompts/$promptId")({
	loader: ({ params }) => {
		queryClient.prefetchQuery(aiPromptHistoryQueryOptions(params.projectId, params.promptId));
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
