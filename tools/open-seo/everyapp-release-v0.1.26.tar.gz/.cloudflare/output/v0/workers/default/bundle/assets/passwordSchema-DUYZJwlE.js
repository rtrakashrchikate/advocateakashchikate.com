import { Jn as string } from "./schemas-BPIpYT5n.js";
//#region src/client/features/auth/passwordSchema.ts
var passwordSchema = string().min(8, `Password must be at least 8 characters.`).max(128, `Password must be at most 128 characters.`);
//#endregion
export { passwordSchema as t };
