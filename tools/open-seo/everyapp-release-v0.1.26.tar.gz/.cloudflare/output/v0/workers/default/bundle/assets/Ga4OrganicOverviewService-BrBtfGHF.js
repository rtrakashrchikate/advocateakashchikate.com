import { Dr as ZodError, Fn as object, Jn as string, Lt as boolean, Nt as array, Pn as number } from "./schemas-BPIpYT5n.js";
import { J as getGoogleAccessMode, W as getGoogleAccessToken, Z as getGatewayGoogleFetch, at as GA4_OAUTH_PROVIDER_ID } from "./resolve-DrNDcpX6.js";
import { t as Ga4ConnectionRepository } from "./Ga4ConnectionRepository-CWfgy1XG.js";
//#region src/server/lib/ga4Errors.ts
var Ga4AdminApiError = class extends Error {
	status;
	constructor(status, message) {
		super(message);
		this.status = status;
		this.name = "Ga4AdminApiError";
	}
};
var Ga4TokenError = class extends Error {
	cause;
	constructor(message, cause) {
		super(message);
		this.cause = cause;
		this.name = "Ga4TokenError";
	}
};
var Ga4DataApiError = class extends Error {
	status;
	retryAfterSeconds;
	upstreamReason;
	constructor(status, message, retryAfterSeconds = null, upstreamReason = null) {
		super(message);
		this.status = status;
		this.retryAfterSeconds = retryAfterSeconds;
		this.upstreamReason = upstreamReason;
		this.name = "Ga4DataApiError";
	}
};
var Ga4MalformedResponseError = class extends Error {
	constructor() {
		super("Google Analytics returned an invalid reporting response.");
		this.name = "Ga4MalformedResponseError";
	}
};
var Ga4ReportError = class extends Error {
	code;
	retryAfterSeconds;
	constructor(code, message, retryAfterSeconds = null) {
		super(message);
		this.code = code;
		this.retryAfterSeconds = retryAfterSeconds;
		this.name = "Ga4ReportError";
	}
};
//#endregion
//#region src/server/lib/ga4Client.ts
var GA4_ADMIN_API_BASE = "https://analyticsadmin.googleapis.com/v1beta";
var GA4_ADMIN_ALPHA_API_BASE = "https://analyticsadmin.googleapis.com/v1alpha";
var GOOGLE_USERINFO_URL = "https://openidconnect.googleapis.com/v1/userinfo";
var GA4_DATA_API_BASE = "https://analyticsdata.googleapis.com/v1beta";
var MAX_ACCOUNT_SUMMARY_PAGES = 100;
var MAX_ERROR_BODY_LENGTH = 8e3;
var propertyIdSchema = string().regex(/^properties\/\d+$/);
var dataStreamNameSchema = string().regex(/^properties\/\d+\/dataStreams\/\d+$/);
var propertySummarySchema = object({
	property: propertyIdSchema,
	displayName: string()
});
var accountSummarySchema = object({
	account: string().regex(/^accounts\/\d+$/),
	displayName: string(),
	propertySummaries: array(propertySummarySchema).optional()
});
var accountSummariesResponseSchema = object({
	accountSummaries: array(accountSummarySchema).optional(),
	nextPageToken: string().optional()
});
var propertySchema = object({
	name: propertyIdSchema,
	displayName: string(),
	timeZone: string().min(1),
	currencyCode: string().min(1)
});
var dataStreamSchema = object({
	name: dataStreamNameSchema,
	type: string(),
	displayName: string().default(""),
	createTime: string().optional(),
	updateTime: string().optional(),
	webStreamData: object({
		measurementId: string().optional(),
		defaultUri: string().optional()
	}).optional(),
	androidAppStreamData: object({ packageName: string().optional() }).optional(),
	iosAppStreamData: object({ bundleId: string().optional() }).optional()
});
var dataStreamsResponseSchema = object({
	dataStreams: array(dataStreamSchema).optional(),
	nextPageToken: string().optional()
});
var enhancedMeasurementSettingsSchema = object({
	streamEnabled: boolean().default(false),
	scrollsEnabled: boolean().default(false),
	outboundClicksEnabled: boolean().default(false),
	siteSearchEnabled: boolean().default(false),
	videoEngagementEnabled: boolean().default(false),
	fileDownloadsEnabled: boolean().default(false),
	pageChangesEnabled: boolean().default(false),
	formInteractionsEnabled: boolean().default(false),
	searchQueryParameter: string().default(""),
	uriQueryParameter: string().optional().default("")
});
var keyEventSchema = object({
	eventName: string(),
	createTime: string().optional(),
	deletable: boolean().optional(),
	custom: boolean().optional(),
	countingMethod: string(),
	defaultValue: object({
		numericValue: number(),
		currencyCode: string()
	}).optional()
});
var keyEventsResponseSchema = object({
	keyEvents: array(keyEventSchema).optional(),
	nextPageToken: string().optional()
});
var customDimensionSchema = object({
	parameterName: string(),
	displayName: string(),
	description: string().optional().default(""),
	scope: string(),
	disallowAdsPersonalization: boolean().optional().default(false)
});
var customDimensionsResponseSchema = object({
	customDimensions: array(customDimensionSchema).optional(),
	nextPageToken: string().optional()
});
var customMetricSchema = object({
	parameterName: string(),
	displayName: string(),
	description: string().optional().default(""),
	measurementUnit: string(),
	scope: string(),
	restrictedMetricType: array(string()).optional().default([])
});
var customMetricsResponseSchema = object({
	customMetrics: array(customMetricSchema).optional(),
	nextPageToken: string().optional()
});
async function getGa4AccessToken(opts) {
	try {
		return await getGoogleAccessToken({
			providerId: GA4_OAUTH_PROVIDER_ID,
			userId: opts.userId,
			accountId: opts.ga4AccountId
		});
	} catch (error) {
		throw new Ga4TokenError("Could not mint a Google Analytics access token.", error);
	}
}
function adminMessageForStatus(status) {
	if (status === 401) return "Google Analytics connection expired.";
	if (status === 403) return "Google Analytics denied access. Check the account's property access and enabled APIs.";
	if (status === 429) return "Google Analytics rate limit reached.";
	return `Google Analytics Admin API error (${status}).`;
}
function isAbortError(error) {
	return error instanceof Error && error.name === "AbortError";
}
/**
* The fetch and headers that reach Google Analytics authenticated, resolved
* once per client: behind the gateway, the gateway's fetch with the
* member's token on it (gatewayGoogle.ts); otherwise OpenSEO's own grant.
*/
async function authenticateGa4(opts) {
	if (await getGoogleAccessMode() === "gateway") {
		const gatewayFetch = await getGatewayGoogleFetch(opts.userId);
		if (!gatewayFetch) throw new Ga4TokenError("Google isn't reachable through the Every App gateway here.");
		return {
			fetch: gatewayFetch,
			headers: {}
		};
	}
	return {
		fetch,
		headers: { Authorization: `Bearer ${await getGa4AccessToken(opts)}` }
	};
}
function memoizedGa4Access(opts) {
	let authenticated;
	return () => authenticated ??= authenticateGa4(opts);
}
/** Read-only Admin API client used only for account/property discovery. */
function createGa4AdminClient(opts) {
	const access = memoizedGa4Access(opts);
	async function request(url) {
		const { fetch: send, headers } = await access();
		let response;
		try {
			response = await send(url, { headers });
		} catch (error) {
			if (isAbortError(error)) throw error;
			throw new Ga4AdminApiError(0, "Google Analytics Admin API is temporarily unavailable.");
		}
		if (!response.ok) throw new Ga4AdminApiError(response.status, adminMessageForStatus(response.status));
		return response.json();
	}
	function propertyUrl(base, propertyId, child) {
		const canonicalId = propertyIdSchema.parse(propertyId);
		return new URL(`${base}/${canonicalId}/${child}`);
	}
	return {
		async getUserInfoEmail() {
			return object({ email: string().email().optional() }).parse(await request(GOOGLE_USERINFO_URL)).email ?? null;
		},
		async listProperties() {
			const properties = [];
			let pageToken;
			for (let page = 0; page < MAX_ACCOUNT_SUMMARY_PAGES; page += 1) {
				const url = new URL(`${GA4_ADMIN_API_BASE}/accountSummaries`);
				url.searchParams.set("pageSize", "200");
				if (pageToken) url.searchParams.set("pageToken", pageToken);
				const response = accountSummariesResponseSchema.parse(await request(url.toString()));
				for (const account of response.accountSummaries ?? []) for (const property of account.propertySummaries ?? []) properties.push({
					propertyId: property.property,
					displayName: property.displayName,
					accountDisplayName: account.displayName
				});
				pageToken = response.nextPageToken || void 0;
				if (!pageToken) return properties;
			}
			throw new Error("Google Analytics property discovery exceeded 100 pages.");
		},
		async getProperty(propertyId) {
			const canonicalId = propertyIdSchema.parse(propertyId);
			return propertySchema.parse(await request(`${GA4_ADMIN_API_BASE}/${canonicalId}`));
		},
		async listDataStreams(propertyId) {
			const url = propertyUrl(GA4_ADMIN_ALPHA_API_BASE, propertyId, "dataStreams");
			url.searchParams.set("pageSize", "200");
			return dataStreamsResponseSchema.parse(await request(url.toString())).dataStreams ?? [];
		},
		async getEnhancedMeasurementSettings(streamName) {
			const canonicalName = dataStreamNameSchema.parse(streamName);
			return enhancedMeasurementSettingsSchema.parse(await request(`${GA4_ADMIN_ALPHA_API_BASE}/${canonicalName}/enhancedMeasurementSettings`));
		},
		async listKeyEvents(propertyId) {
			const url = propertyUrl(GA4_ADMIN_API_BASE, propertyId, "keyEvents");
			url.searchParams.set("pageSize", "200");
			return keyEventsResponseSchema.parse(await request(url.toString())).keyEvents ?? [];
		},
		async listCustomDimensions(propertyId) {
			const url = propertyUrl(GA4_ADMIN_API_BASE, propertyId, "customDimensions");
			url.searchParams.set("pageSize", "200");
			return customDimensionsResponseSchema.parse(await request(url.toString())).customDimensions ?? [];
		},
		async listCustomMetrics(propertyId) {
			const url = propertyUrl(GA4_ADMIN_API_BASE, propertyId, "customMetrics");
			url.searchParams.set("pageSize", "200");
			return customMetricsResponseSchema.parse(await request(url.toString())).customMetrics ?? [];
		}
	};
}
var quotaStatusSchema = object({
	consumed: number().int(),
	remaining: number().int()
});
var propertyQuotaSchema = object({
	tokensPerDay: quotaStatusSchema.optional(),
	tokensPerHour: quotaStatusSchema.optional(),
	concurrentRequests: quotaStatusSchema.optional(),
	serverErrorsPerProjectPerHour: quotaStatusSchema.optional(),
	potentiallyThresholdedRequestsPerHour: quotaStatusSchema.optional(),
	tokensPerProjectPerHour: quotaStatusSchema.optional()
});
var responseMetadataSchema = object({
	dataLossFromOtherRow: boolean().optional(),
	samplingMetadatas: array(object({
		samplesReadCount: string(),
		samplingSpaceSize: string()
	})).optional(),
	schemaRestrictionResponse: object({ activeMetricRestrictions: array(object({
		metricName: string(),
		restrictedMetricTypes: array(string()).optional()
	})).optional() }).optional(),
	currencyCode: string().optional(),
	timeZone: string().optional(),
	emptyReason: string().optional(),
	subjectToThresholding: boolean().optional()
});
var runReportResponseSchema = object({
	dimensionHeaders: array(object({ name: string() })).optional(),
	metricHeaders: array(object({
		name: string(),
		type: string().optional()
	})).optional(),
	rows: array(object({
		dimensionValues: array(object({ value: string() })).optional(),
		metricValues: array(object({ value: string() })).optional()
	})).optional(),
	rowCount: number().int().nonnegative().optional(),
	metadata: responseMetadataSchema.optional(),
	propertyQuota: propertyQuotaSchema.optional(),
	kind: string().optional()
});
var googleErrorSchema = object({ error: object({ details: array(object({
	reason: string().optional(),
	metadata: object({ service: string().optional() }).optional()
})).optional() }) });
function safeRetryAfter(response) {
	const value = response.headers.get("retry-after");
	if (!value || !/^\d+$/.test(value)) return null;
	return Math.min(Number(value), 86400);
}
function dataMessageForStatus(status) {
	if (status === 400) return "Google Analytics rejected this report.";
	if (status === 401) return "Google Analytics connection expired.";
	if (status === 403) return "Google Analytics denied access to this property.";
	if (status === 429) return "Google Analytics reporting quota was exhausted.";
	return "Google Analytics reporting is temporarily unavailable.";
}
function createGa4DataClient(opts) {
	const propertyId = propertyIdSchema.parse(opts.propertyId);
	const access = memoizedGa4Access(opts);
	return { async runReport(request) {
		const { fetch: send, headers } = await access();
		let response;
		try {
			response = await send(`${GA4_DATA_API_BASE}/${propertyId}:runReport`, {
				method: "POST",
				headers: {
					...headers,
					"Content-Type": "application/json"
				},
				body: JSON.stringify(request)
			});
		} catch (error) {
			if (isAbortError(error)) throw error;
			throw new Ga4DataApiError(0, "Google Analytics reporting is temporarily unavailable.");
		}
		if (!response.ok) {
			const body = await response.text().then((responseBody) => responseBody.slice(0, MAX_ERROR_BODY_LENGTH)).catch(() => "");
			let upstreamReason = null;
			try {
				const parsed = googleErrorSchema.safeParse(JSON.parse(body));
				if (parsed.success) upstreamReason = parsed.data.error.details?.find((detail) => detail.metadata?.service === "analyticsdata.googleapis.com")?.reason ?? parsed.data.error.details?.find((detail) => detail.reason)?.reason ?? null;
			} catch {}
			throw new Ga4DataApiError(response.status, dataMessageForStatus(response.status), safeRetryAfter(response), upstreamReason);
		}
		try {
			return runReportResponseSchema.parse(await response.json());
		} catch {
			throw new Ga4MalformedResponseError();
		}
	} };
}
//#endregion
//#region src/server/features/ga4/services/Ga4ReportDefinitions.ts
var REPORT_DEFINITIONS = {
	landing_pages: {
		dimensions: ["hostName", "landingPage"],
		metrics: [
			"sessions",
			"activeUsers",
			"engagedSessions",
			"engagementRate",
			"keyEvents",
			"sessionKeyEventRate",
			"transactions",
			"purchaseRevenue"
		],
		orderMetric: "sessions"
	},
	page_performance: {
		dimensions: ["hostName", "pagePath"],
		metrics: [
			"screenPageViews",
			"activeUsers",
			"userEngagementDuration",
			"keyEvents"
		],
		orderMetric: "screenPageViews"
	},
	key_events: {
		dimensions: ["eventName"],
		metrics: ["keyEvents", "totalUsers"],
		orderMetric: "keyEvents"
	},
	traffic_acquisition: {
		dimensions: ["sessionDefaultChannelGroup"],
		metrics: [
			"sessions",
			"activeUsers",
			"engagedSessions",
			"engagementRate",
			"keyEvents",
			"transactions",
			"purchaseRevenue"
		],
		orderMetric: "sessions"
	},
	ecommerce_performance: {
		dimensions: ["itemName", "itemId"],
		metrics: [
			"itemsViewed",
			"itemsAddedToCart",
			"itemsPurchased",
			"itemRevenue"
		],
		orderMetric: "itemRevenue"
	},
	site_search: {
		dimensions: ["searchTerm"],
		metrics: [
			"eventCount",
			"activeUsers",
			"sessions",
			"engagedSessions",
			"engagementRate"
		],
		orderMetric: "eventCount"
	},
	audience_breakdown: {
		dimensions: ["deviceCategory"],
		metrics: [
			"activeUsers",
			"sessions",
			"engagementRate",
			"keyEvents"
		],
		orderMetric: "activeUsers"
	}
};
var OVERVIEW_METRICS = [
	"sessions",
	"activeUsers",
	"engagedSessions",
	"engagementRate",
	"keyEvents",
	"transactions",
	"purchaseRevenue"
];
function organicFilter() {
	return { filter: {
		fieldName: "sessionDefaultChannelGroup",
		stringFilter: {
			matchType: "EXACT",
			value: "Organic Search"
		}
	} };
}
function reportDefinition(input) {
	if (input.kind === "ecommerce_performance" && input.ecommerceBreakdown === "landing_page") return {
		dimensions: ["hostName", "landingPage"],
		metrics: [
			"sessions",
			"transactions",
			"purchaseRevenue"
		],
		orderMetric: "purchaseRevenue"
	};
	return REPORT_DEFINITIONS[input.kind];
}
function reportDimensions(input, defaults) {
	if (input.kind === "traffic_acquisition") return [{
		channel_group: "sessionDefaultChannelGroup",
		source_medium: "sessionSourceMedium",
		campaign: "sessionCampaignName"
	}[input.acquisitionBreakdown ?? "channel_group"]];
	if (input.kind === "audience_breakdown") return [{
		device: "deviceCategory",
		country: "country",
		new_vs_returning: "newVsReturning"
	}[input.audienceBreakdown ?? "device"]];
	const dimensions = [...defaults];
	if (input.kind === "page_performance" && input.includeDate) dimensions.push("date");
	if (input.kind === "key_events" && input.breakdown === "event_and_landing_page") dimensions.push("hostName", "landingPage");
	return dimensions;
}
function reportFilter(input) {
	if (input.kind === "site_search") return { andGroup: { expressions: [{ filter: {
		fieldName: "eventName",
		stringFilter: {
			matchType: "EXACT",
			value: "view_search_results"
		}
	} }, { notExpression: { filter: {
		fieldName: "searchTerm",
		stringFilter: {
			matchType: "EXACT",
			value: "(not set)"
		}
	} } }] } };
	return input.channel === "organic_search" ? organicFilter() : void 0;
}
function metricFilter(input) {
	if (input.kind === "key_events") return { filter: {
		fieldName: "keyEvents",
		numericFilter: {
			operation: "GREATER_THAN",
			value: { doubleValue: 0 }
		}
	} };
	if (input.kind === "ecommerce_performance" && input.ecommerceBreakdown === "landing_page" && input.ecommerceOnlyWithTransactions) return { filter: {
		fieldName: "transactions",
		numericFilter: {
			operation: "GREATER_THAN",
			value: { doubleValue: 0 }
		}
	} };
}
function effectiveBreakdown(input) {
	if (input.kind === "landing_pages") return "landing_page";
	if (input.kind === "page_performance") return input.includeDate ? "page_and_date" : "page";
	if (input.kind === "key_events") return input.breakdown ?? "event";
	if (input.kind === "traffic_acquisition") return input.acquisitionBreakdown ?? "channel_group";
	if (input.kind === "ecommerce_performance") return input.ecommerceBreakdown ?? "item";
	if (input.kind === "site_search") return "search_term";
	return input.audienceBreakdown ?? "device";
}
function getGa4ReportConfiguration(input) {
	const definition = reportDefinition(input);
	return {
		reportKind: input.kind,
		breakdown: effectiveBreakdown(input),
		dimensions: reportDimensions(input, definition.dimensions),
		metrics: [...definition.metrics],
		flags: {
			includeDate: input.includeDate ?? false,
			onlyWithTransactions: input.ecommerceOnlyWithTransactions ?? false
		}
	};
}
function buildGa4ReportRequest(input) {
	const definition = reportDefinition(input);
	const dimensions = reportDimensions(input, definition.dimensions);
	return {
		dateRanges: [{
			startDate: input.startDate,
			endDate: input.endDate
		}],
		dimensions: dimensions.map((name) => ({ name })),
		metrics: definition.metrics.map((name) => ({ name })),
		dimensionFilter: reportFilter(input),
		metricFilter: metricFilter(input),
		offset: String(input.offset),
		limit: String(input.limit),
		orderBys: [{
			metric: { metricName: definition.orderMetric },
			desc: true
		}],
		keepEmptyRows: false,
		returnPropertyQuota: true
	};
}
function buildGa4OverviewRequest(input) {
	const dimensions = input.trend ? [{ name: input.trend === "daily" ? "date" : "yearWeek" }] : [];
	return {
		dateRanges: [{
			startDate: input.startDate,
			endDate: input.endDate
		}],
		dimensions,
		metrics: OVERVIEW_METRICS.map((name) => ({ name })),
		dimensionFilter: organicFilter(),
		offset: "0",
		limit: input.trend ? "1000" : "1",
		orderBys: input.trend ? [{ dimension: { dimensionName: dimensions[0]?.name ?? "date" } }] : [],
		keepEmptyRows: false,
		returnPropertyQuota: true
	};
}
//#endregion
//#region src/server/features/ga4/services/Ga4Dates.ts
var DAY_MILLISECONDS = 864e5;
function shiftGa4Date(value, days) {
	const date = /* @__PURE__ */ new Date(`${value}T00:00:00.000Z`);
	if (Number.isNaN(date.valueOf())) throw new RangeError("Invalid GA4 date.");
	date.setUTCDate(date.getUTCDate() + days);
	return date.toISOString().slice(0, 10);
}
function ga4DateInTimeZone(now, timeZone) {
	const parts = new Intl.DateTimeFormat("en-US", {
		timeZone,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).formatToParts(now);
	const byType = Object.fromEntries(parts.map((part) => [part.type, part.value]));
	return `${byType.year}-${byType.month}-${byType.day}`;
}
function inclusiveGa4Days(startDate, endDate) {
	const start = /* @__PURE__ */ new Date(`${startDate}T00:00:00.000Z`);
	const end = /* @__PURE__ */ new Date(`${endDate}T00:00:00.000Z`);
	return Math.round((end.valueOf() - start.valueOf()) / DAY_MILLISECONDS) + 1;
}
//#endregion
//#region src/server/features/ga4/services/Ga4ReportEnhancements.ts
var COMPLETE_REPORT_LIMIT = 1e3;
function previousPeriod(range) {
	const days = inclusiveGa4Days(range.startDate, range.endDate);
	const endDate = shiftGa4Date(range.startDate, -1);
	return {
		startDate: shiftGa4Date(endDate, -(days - 1)),
		endDate
	};
}
function supportsComparison(input) {
	if (input.kind === "key_events") return (input.breakdown ?? "event") === "event";
	if (input.kind === "traffic_acquisition") return (input.acquisitionBreakdown ?? "channel_group") === "channel_group";
	if (input.kind === "audience_breakdown") return ["device", "new_vs_returning"].includes(input.audienceBreakdown ?? "device");
	return false;
}
function needsCompleteReport(input) {
	return input.comparePreviousPeriod === true || input.kind === "traffic_acquisition" && input.acquisitionBreakdown === "source_medium" || input.kind === "ecommerce_performance" || input.kind === "site_search";
}
function metricValue(row, metric) {
	const value = row?.[metric];
	return typeof value === "number" ? value : null;
}
function comparisonValue(current, previous) {
	const absoluteChange = current != null && previous != null ? current - previous : null;
	return {
		current,
		previous,
		absoluteChange,
		percentChange: absoluteChange != null && previous != null && previous !== 0 ? absoluteChange / previous : null
	};
}
function rowKey(row, dimensions) {
	return JSON.stringify(dimensions.map((dimension) => row[dimension] ?? null));
}
function buildReportComparison(input) {
	const currentByKey = new Map(input.current.rows.map((row) => [rowKey(row, input.dimensions), row]));
	const previousByKey = new Map(input.previous.rows.map((row) => [rowKey(row, input.dimensions), row]));
	const keys = [...currentByKey.keys(), ...[...previousByKey.keys()].filter((key) => !currentByKey.has(key))];
	const currentComplete = input.current.rows.length === input.current.totalRowCount;
	const previousComplete = input.previous.rows.length === input.previous.totalRowCount;
	return {
		previousDateRange: input.previousDateRange,
		dimensions: input.dimensions,
		metrics: input.metrics,
		rows: keys.map((key) => {
			const current = currentByKey.get(key);
			const previous = previousByKey.get(key);
			return {
				dimensions: Object.fromEntries(input.dimensions.map((dimension) => [dimension, current?.[dimension] ?? previous?.[dimension] ?? null])),
				metrics: Object.fromEntries(input.metrics.map((metric) => [metric, comparisonValue(metricValue(current, metric), metricValue(previous, metric))]))
			};
		}),
		coverage: {
			complete: currentComplete && previousComplete,
			current: {
				fetchedRowCount: input.current.rows.length,
				totalRowCount: input.current.totalRowCount
			},
			previous: {
				fetchedRowCount: input.previous.rows.length,
				totalRowCount: input.previous.totalRowCount
			}
		},
		reportMetadata: {
			hasLimitedData: input.current.reportMetadata.hasLimitedData || input.previous.reportMetadata.hasLimitedData,
			current: input.current.reportMetadata,
			previous: input.previous.reportMetadata
		},
		quota: input.previous.quota
	};
}
function isInternalHost(value) {
	const withoutProtocol = (value.split(" / ")[0]?.toLowerCase() ?? "").replace(/^https?:\/\//, "");
	if (withoutProtocol === "::1" || withoutProtocol.startsWith("[::1]")) return true;
	const host = withoutProtocol.split(":")[0] ?? "";
	if (host === "localhost" || host.startsWith("127.")) return true;
	const parts = host.split(".").map(Number);
	if (parts.length !== 4 || parts.some((part) => !Number.isInteger(part))) return false;
	return parts[0] === 10 || parts[0] === 172 && (parts[1] ?? 0) >= 16 && (parts[1] ?? 0) <= 31 || parts[0] === 192 && parts[1] === 168;
}
function buildAttributionDiagnostics(report) {
	const complete = report.rows.length === report.totalRowCount;
	const coverage = {
		complete,
		limitedData: report.reportMetadata.hasLimitedData,
		fetchedRowCount: report.rows.length,
		totalRowCount: report.totalRowCount
	};
	if (!complete || report.reportMetadata.hasLimitedData) return {
		diagnostics: [],
		diagnosticCoverage: coverage
	};
	const diagnostics = [];
	const sessions = report.rows.reduce((sum, row) => sum + (metricValue(row, "sessions") ?? 0), 0);
	const notSetSessions = report.rows.filter((row) => row.sessionSourceMedium === "(not set)").reduce((sum, row) => sum + (metricValue(row, "sessions") ?? 0), 0);
	const notSetShare = sessions > 0 ? notSetSessions / sessions : 0;
	if (notSetShare >= .05) diagnostics.push({
		code: "attribution_not_set_share_high",
		severity: "warning",
		message: "A notable share of sessions has no source/medium attribution.",
		evidence: {
			sessions: notSetSessions,
			totalSessions: sessions,
			share: notSetShare
		},
		threshold: { share: .05 }
	});
	const internalRows = report.rows.filter((row) => typeof row.sessionSourceMedium === "string" && isInternalHost(row.sessionSourceMedium));
	const internalSessions = internalRows.reduce((sum, row) => sum + (metricValue(row, "sessions") ?? 0), 0);
	if (internalSessions > 0) diagnostics.push({
		code: "internal_referral_traffic_detected",
		severity: "warning",
		message: "Local or private-network referral sources appear in acquisition data.",
		evidence: {
			sessions: internalSessions,
			sources: internalRows.map((row) => row.sessionSourceMedium)
		},
		threshold: { sessions: 0 }
	});
	const caseGroups = /* @__PURE__ */ new Map();
	for (const row of report.rows) {
		if (typeof row.sessionSourceMedium !== "string") continue;
		const key = row.sessionSourceMedium.toLowerCase();
		const variants = caseGroups.get(key) ?? /* @__PURE__ */ new Set();
		variants.add(row.sessionSourceMedium);
		caseGroups.set(key, variants);
	}
	const variantGroups = [...caseGroups.values()].filter((variants) => variants.size > 1).map((variants) => [...variants]);
	if (variantGroups.length > 0) diagnostics.push({
		code: "source_medium_case_variants_detected",
		severity: "info",
		message: "Source/medium values differ only by letter casing.",
		evidence: { variantGroups },
		threshold: { variantGroups: 0 }
	});
	return {
		diagnostics,
		diagnosticCoverage: coverage
	};
}
function activityStatus(report, detected) {
	if (report.reportMetadata.hasLimitedData || report.rows.length !== report.totalRowCount) return "unknown";
	return detected ? "detected" : "none";
}
function buildEcommerceActivity(report, input, dateRange) {
	const breakdown = input.ecommerceBreakdown ?? "item";
	const totals = Object.fromEntries((breakdown === "item" ? [
		"itemsViewed",
		"itemsAddedToCart",
		"itemsPurchased",
		"itemRevenue"
	] : ["transactions", "purchaseRevenue"]).map((metric) => [metric, report.rows.reduce((sum, row) => sum + (metricValue(row, metric) ?? 0), 0)]));
	const status = activityStatus(report, Object.values(totals).some((value) => value > 0));
	return {
		status,
		dateRange,
		channel: input.channel ?? "organic_search",
		breakdown,
		evidence: totals,
		reason: status === "none" ? "No matching ecommerce activity was reported for this period and channel." : status === "unknown" ? "The fetched report is incomplete or limited, so ecommerce activity cannot be determined." : null
	};
}
function buildSiteSearchActivity(report, dateRange) {
	const eventCount = report.rows.reduce((sum, row) => sum + (metricValue(row, "eventCount") ?? 0), 0);
	const status = activityStatus(report, eventCount > 0);
	return {
		status,
		dateRange,
		searchTermCount: report.totalRowCount,
		searchEventCount: eventCount,
		reason: status === "none" ? "No measured site-search terms were reported for this period." : status === "unknown" ? "The fetched report is incomplete or limited, so site-search activity cannot be determined." : null
	};
}
function buildReportSpecificEnhancements(report, input, dateRange) {
	if (input.kind === "traffic_acquisition" && input.acquisitionBreakdown === "source_medium") return buildAttributionDiagnostics(report);
	if (input.kind === "ecommerce_performance") {
		const ecommerceActivity = buildEcommerceActivity(report, input, dateRange);
		return {
			diagnostics: ecommerceActivity.status === "none" ? [{
				code: "no_ecommerce_activity",
				severity: "info",
				message: ecommerceActivity.reason,
				evidence: ecommerceActivity.evidence,
				threshold: { matchingActivity: 0 }
			}] : [],
			ecommerceActivity
		};
	}
	if (input.kind === "site_search") {
		const siteSearchActivity = buildSiteSearchActivity(report, dateRange);
		return {
			diagnostics: siteSearchActivity.status === "none" ? [{
				code: "no_site_search_activity",
				severity: "info",
				message: siteSearchActivity.reason,
				evidence: {
					searchTermCount: siteSearchActivity.searchTermCount,
					searchEventCount: siteSearchActivity.searchEventCount
				},
				threshold: { searchEvents: 0 }
			}] : [],
			siteSearchActivity
		};
	}
	return { diagnostics: [] };
}
//#endregion
//#region src/server/features/ga4/services/Ga4ReportNormalization.ts
function parseFiniteMetric(value) {
	const parsed = Number(value);
	if (!Number.isFinite(parsed)) throw new Ga4MalformedResponseError();
	return parsed;
}
function normalizeGa4Response(response, request) {
	const expectedDimensions = request.dimensions.map(({ name }) => name);
	const expectedMetrics = request.metrics.map(({ name }) => name);
	const dimensions = (response.dimensionHeaders ?? []).map(({ name }) => name);
	const metrics = (response.metricHeaders ?? []).map(({ name }) => name);
	if (!(response.dimensionHeaders === void 0 && response.metricHeaders === void 0 && (response.rows?.length ?? 0) === 0) && (dimensions.join("\0") !== expectedDimensions.join("\0") || metrics.join("\0") !== expectedMetrics.join("\0"))) throw new Ga4MalformedResponseError();
	const restrictedMetrics = response.metadata?.schemaRestrictionResponse?.activeMetricRestrictions?.map((restriction) => ({
		metricName: restriction.metricName,
		restrictedMetricTypes: restriction.restrictedMetricTypes ?? []
	})) ?? [];
	const restrictedNames = new Set(restrictedMetrics.map((restriction) => restriction.metricName));
	const rows = (response.rows ?? []).map((row) => {
		if ((row.dimensionValues?.length ?? 0) !== dimensions.length || (row.metricValues?.length ?? 0) !== metrics.length) throw new Ga4MalformedResponseError();
		const normalized = {};
		dimensions.forEach((name, index) => {
			normalized[name] = row.dimensionValues?.[index]?.value ?? "";
		});
		metrics.forEach((name, index) => {
			normalized[name] = restrictedNames.has(name) ? null : parseFiniteMetric(row.metricValues?.[index]?.value ?? "");
		});
		return normalized;
	});
	const sampling = response.metadata?.samplingMetadatas ?? [];
	const reportMetadata = {
		dataLossFromOtherRow: response.metadata?.dataLossFromOtherRow ?? false,
		subjectToThresholding: response.metadata?.subjectToThresholding ?? false,
		sampling,
		restrictedMetrics,
		emptyReason: response.metadata?.emptyReason ?? null,
		hasLimitedData: (response.metadata?.dataLossFromOtherRow ?? false) || (response.metadata?.subjectToThresholding ?? false) || sampling.length > 0 || restrictedMetrics.length > 0
	};
	return {
		rows,
		totalRowCount: response.rowCount ?? rows.length,
		reportMetadata,
		quota: response.propertyQuota ?? null
	};
}
//#endregion
//#region src/server/features/ga4/services/Ga4ReportingService.ts
var DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
var DEFAULT_LIMIT = 100;
var MAX_LIMIT = 1e3;
function parseDate(value) {
	if (!DATE_PATTERN.test(value)) return null;
	const date = /* @__PURE__ */ new Date(`${value}T00:00:00.000Z`);
	return Number.isNaN(date.valueOf()) || date.toISOString().slice(0, 10) !== value ? null : date;
}
function resolveGa4DateRange(input, propertyTimeZone, now = /* @__PURE__ */ new Date()) {
	if (Boolean(input.startDate) !== Boolean(input.endDate)) throw new Ga4ReportError("validation_error", "Provide both startDate and endDate, or neither.");
	const requestedDateRange = input.startDate && input.endDate ? {
		startDate: input.startDate,
		endDate: input.endDate
	} : null;
	if (requestedDateRange && (!parseDate(requestedDateRange.startDate) || !parseDate(requestedDateRange.endDate) || requestedDateRange.startDate > requestedDateRange.endDate)) throw new Ga4ReportError("validation_error", "Dates must be valid YYYY-MM-DD values with startDate on or before endDate.");
	const lastCompleteDay = shiftGa4Date(ga4DateInTimeZone(now, propertyTimeZone), -1);
	let endDate = requestedDateRange?.endDate ?? lastCompleteDay;
	const startDate = requestedDateRange?.startDate ?? shiftGa4Date(endDate, -27);
	const warnings = [];
	if (endDate > lastCompleteDay) {
		endDate = lastCompleteDay;
		warnings.push("end_date_clamped");
	}
	if (startDate > endDate) throw new Ga4ReportError("validation_error", "The resolved startDate is after the last complete Analytics day.");
	return {
		requestedDateRange,
		resolvedDateRange: {
			startDate,
			endDate
		},
		warnings
	};
}
function normalizeLimit(value) {
	const limit = value ?? DEFAULT_LIMIT;
	if (!Number.isInteger(limit) || limit < 1 || limit > MAX_LIMIT) throw new Ga4ReportError("validation_error", `limit must be an integer from 1 to ${MAX_LIMIT}.`);
	return limit;
}
function normalizeOffset(value) {
	const offset = value ?? 0;
	if (!Number.isInteger(offset) || offset < 0) throw new Ga4ReportError("validation_error", "offset must be a non-negative integer.");
	return offset;
}
function mapGa4ReportError(error) {
	if (error instanceof Ga4ReportError) throw error;
	if (error instanceof Ga4TokenError) throw new Ga4ReportError("ga4_reconnect_required", "The Google Analytics connection has expired or was revoked.");
	if (error instanceof Ga4MalformedResponseError) throw new Ga4ReportError("ga4_malformed_response", "Google Analytics returned an invalid report.");
	if (error instanceof Ga4DataApiError && error.status === 400) throw new Ga4ReportError("ga4_report_incompatible", "This report is not compatible with the selected Analytics property.");
	if (error instanceof Ga4DataApiError || error instanceof Ga4AdminApiError) {
		if (error.status === 401) throw new Ga4ReportError("ga4_reconnect_required", "The Google Analytics connection has expired or was revoked.");
		if (error.status === 403) {
			if (error instanceof Ga4DataApiError && error.upstreamReason === "SERVICE_DISABLED") throw new Ga4ReportError("ga4_upstream_unavailable", "The Google Analytics Data API is not enabled for this OAuth application.");
			throw new Ga4ReportError("ga4_property_inaccessible", "The connected Google account can no longer access this property.");
		}
		if (error.status === 404) throw new Ga4ReportError("ga4_property_inaccessible", "The selected Google Analytics property is no longer available.");
		if (error.status === 429) throw new Ga4ReportError("ga4_quota_exhausted", "Google Analytics reporting quota is exhausted. Try again later.", error instanceof Ga4DataApiError ? error.retryAfterSeconds : null);
		throw new Ga4ReportError("ga4_upstream_unavailable", "Google Analytics reporting is temporarily unavailable.");
	}
	if (error instanceof ZodError) throw new Ga4ReportError("ga4_malformed_response", "Google Analytics returned an invalid report.");
	throw error;
}
async function resolveReportPage(input) {
	const { client, normalized, request, fetchCompleteReport, offset, limit } = input;
	const requestedPageIsBuffered = normalized.totalRowCount <= normalized.rows.length || offset + limit <= normalized.rows.length;
	let rows = fetchCompleteReport ? normalized.rows.slice(offset, offset + limit) : normalized.rows;
	if (fetchCompleteReport && !requestedPageIsBuffered) {
		const pageRequest = {
			...request,
			offset: String(offset),
			limit: String(limit)
		};
		rows = normalizeGa4Response(await client.runReport(pageRequest), pageRequest).rows;
	}
	const rowCount = rows.length;
	if (rowCount === 0 && offset < normalized.totalRowCount) throw new Ga4MalformedResponseError();
	const nextOffset = offset + rowCount;
	return {
		rows,
		rowCount,
		hasMore: nextOffset < normalized.totalRowCount,
		nextOffset
	};
}
async function runReport(input, opts = {}) {
	const connection = await Ga4ConnectionRepository.getByProjectId(input.projectId);
	if (!connection) throw new Ga4ReportError("ga4_not_connected", "Google Analytics is not connected for this project.");
	const limit = normalizeLimit(input.limit);
	const offset = normalizeOffset(input.offset);
	const channel = input.channel ?? "organic_search";
	const dateRange = resolveGa4DateRange(input, connection.propertyTimeZone, opts.now);
	if (input.comparePreviousPeriod && !supportsComparison(input)) throw new Ga4ReportError("validation_error", "Previous-period comparison is only available for event key events, channel-group acquisition, device audiences, and new-versus-returning audiences.");
	const fetchCompleteReport = needsCompleteReport(input);
	const reportConfiguration = getGa4ReportConfiguration({
		...input,
		...dateRange.resolvedDateRange,
		channel,
		limit,
		offset
	});
	const request = buildGa4ReportRequest({
		...input,
		...dateRange.resolvedDateRange,
		channel,
		limit: fetchCompleteReport ? COMPLETE_REPORT_LIMIT : limit,
		offset: fetchCompleteReport ? 0 : offset
	});
	try {
		const client = createGa4DataClient({
			userId: connection.connectedByUserId,
			ga4AccountId: connection.ga4AccountId,
			propertyId: connection.propertyId
		});
		const previousDateRange = input.comparePreviousPeriod ? previousPeriod(dateRange.resolvedDateRange) : null;
		const previousRequest = previousDateRange ? buildGa4ReportRequest({
			...input,
			...previousDateRange,
			channel,
			limit: COMPLETE_REPORT_LIMIT,
			offset: 0
		}) : null;
		const [response, previousResponse] = await Promise.all([client.runReport(request), previousRequest ? client.runReport(previousRequest) : null]);
		const normalized = normalizeGa4Response(response, request);
		const previousNormalized = previousResponse && previousRequest ? normalizeGa4Response(previousResponse, previousRequest) : null;
		const { rows, rowCount, hasMore, nextOffset } = await resolveReportPage({
			client,
			normalized,
			request,
			fetchCompleteReport,
			offset,
			limit
		});
		const comparison = previousNormalized && previousDateRange ? buildReportComparison({
			current: normalized,
			previous: previousNormalized,
			previousDateRange,
			dimensions: reportConfiguration.dimensions,
			metrics: reportConfiguration.metrics
		}) : void 0;
		const comparisonIncomplete = comparison && !comparison.coverage.complete;
		const enhancements = buildReportSpecificEnhancements(normalized, input, dateRange.resolvedDateRange);
		return {
			status: "ok",
			source: {
				provider: "google_analytics",
				propertyId: connection.propertyId,
				propertyDisplayName: connection.propertyDisplayName
			},
			request: {
				requestedDateRange: dateRange.requestedDateRange,
				resolvedDateRange: dateRange.resolvedDateRange,
				propertyTimeZone: connection.propertyTimeZone,
				currencyCode: connection.propertyCurrencyCode,
				channel,
				...reportConfiguration,
				limit,
				offset
			},
			rowCount,
			totalRowCount: normalized.totalRowCount,
			rows,
			pageInfo: {
				offset,
				limit,
				hasMore,
				nextOffset: hasMore ? nextOffset : null
			},
			reportMetadata: normalized.reportMetadata,
			quota: normalized.quota,
			warnings: [...dateRange.warnings, ...comparisonIncomplete ? ["comparison_incomplete"] : []],
			...enhancements,
			comparison
		};
	} catch (error) {
		mapGa4ReportError(error);
	}
}
var Ga4ReportingService = { runReport };
//#endregion
//#region src/server/features/ga4/services/Ga4OrganicOverviewService.ts
function metricComparison(current, previous) {
	return Object.fromEntries(OVERVIEW_METRICS.map((metric) => {
		return [metric, comparisonValue(typeof current?.[metric] === "number" ? current[metric] : null, typeof previous?.[metric] === "number" ? previous[metric] : null)];
	}));
}
function keyEventDiagnostics(current, previous, hasLimitedData) {
	if (hasLimitedData) return [];
	const currentValue = typeof current?.keyEvents === "number" ? current.keyEvents : null;
	const previousValue = typeof previous?.keyEvents === "number" ? previous.keyEvents : null;
	if (currentValue == null || previousValue == null || previousValue < 5) return [];
	const percentChange = (currentValue - previousValue) / previousValue;
	if (percentChange > -.5) return [];
	return [{
		code: "key_events_sharp_decline",
		severity: "warning",
		message: "Organic key events declined sharply compared with the previous equal-length period.",
		evidence: {
			current: currentValue,
			previous: previousValue,
			percentChange
		},
		threshold: {
			minimumPreviousKeyEvents: 5,
			percentChange: -.5
		}
	}];
}
async function getOrganicOverview(input, opts = {}) {
	const connection = await Ga4ConnectionRepository.getByProjectId(input.projectId);
	if (!connection) throw new Ga4ReportError("ga4_not_connected", "Google Analytics is not connected for this project.");
	const dateRange = resolveGa4DateRange(input, connection.propertyTimeZone, opts.now);
	const previousDateRange = previousPeriod(dateRange.resolvedDateRange);
	const currentRequest = buildGa4OverviewRequest(dateRange.resolvedDateRange);
	const previousRequest = buildGa4OverviewRequest({ ...previousDateRange });
	const trend = input.trend ?? "daily";
	const trendRequest = buildGa4OverviewRequest({
		...dateRange.resolvedDateRange,
		trend
	});
	const client = createGa4DataClient({
		userId: connection.connectedByUserId,
		ga4AccountId: connection.ga4AccountId,
		propertyId: connection.propertyId
	});
	try {
		const [currentResponse, previousResponse, trendResponse] = await Promise.all([
			client.runReport(currentRequest),
			client.runReport(previousRequest),
			client.runReport(trendRequest)
		]);
		const current = normalizeGa4Response(currentResponse, currentRequest);
		const previous = normalizeGa4Response(previousResponse, previousRequest);
		const trendReport = normalizeGa4Response(trendResponse, trendRequest);
		const currentSummary = current.rows[0] ?? null;
		const previousSummary = previous.rows[0] ?? null;
		const reports = [
			current,
			previous,
			trendReport
		];
		const hasLimitedData = reports.some((report) => report.reportMetadata.hasLimitedData);
		return {
			status: "ok",
			source: {
				provider: "google_analytics",
				propertyId: connection.propertyId,
				propertyDisplayName: connection.propertyDisplayName
			},
			request: {
				requestedDateRange: dateRange.requestedDateRange,
				resolvedDateRange: dateRange.resolvedDateRange,
				previousDateRange,
				propertyTimeZone: connection.propertyTimeZone,
				currencyCode: connection.propertyCurrencyCode,
				channel: "organic_search",
				trend
			},
			current: currentSummary,
			previous: previousSummary,
			comparison: metricComparison(currentSummary, previousSummary),
			trend: trendReport.rows,
			diagnostics: keyEventDiagnostics(currentSummary, previousSummary, hasLimitedData),
			reportMetadata: {
				hasLimitedData,
				reports: reports.map((report) => report.reportMetadata)
			},
			quota: trendReport.quota ?? current.quota,
			warnings: [...dateRange.warnings, ...trendReport.totalRowCount > trendReport.rows.length ? ["trend_truncated"] : []]
		};
	} catch (error) {
		mapGa4ReportError(error);
	}
}
var Ga4OrganicOverviewService = { getOrganicOverview };
//#endregion
export { ga4DateInTimeZone as a, createGa4AdminClient as c, Ga4TokenError as d, resolveGa4DateRange as i, Ga4AdminApiError as l, Ga4ReportingService as n, shiftGa4Date as o, mapGa4ReportError as r, OVERVIEW_METRICS as s, Ga4OrganicOverviewService as t, Ga4ReportError as u };
