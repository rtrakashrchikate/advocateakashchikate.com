import { Et as _enum, Fn as object, Jn as string, Lt as boolean, Pn as number } from "./schemas-BPIpYT5n.js";
import { F as PAGE_FETCH_CLASSES } from "./db-DhHkpZWI.js";
import { t as PAID_MAX_AUDIT_PAGES } from "./audit-limits-CeWL1lsV.js";
//#region src/types/schemas/audit.ts
var startAuditSchema = object({
	projectId: string().min(1),
	renderJavaScript: boolean().optional().default(false),
	startUrl: string().min(1, "URL is required").max(2048),
	maxPages: number().int().min(10).max(PAID_MAX_AUDIT_PAGES).optional().default(50),
	lighthouseStrategy: _enum(["auto", "none"]).optional().default("auto")
});
var getAuditStatusSchema = object({
	projectId: string().min(1),
	auditId: string().min(1)
});
var getAuditSummarySchema = object({
	projectId: string().min(1),
	auditId: string().min(1)
});
var auditPagesSortFields = [
	"url",
	"statusCode",
	"title",
	"h1Count",
	"wordCount",
	"images",
	"responseTimeMs"
];
var AUDIT_ROWS_MAX_PAGE_SIZE = 2e3;
var optionalBound = number().finite().nullable().optional();
var getAuditPagesSchema = object({
	projectId: string().min(1),
	auditId: string().min(1),
	page: number().int().positive().default(1),
	pageSize: number().int().positive().max(AUDIT_ROWS_MAX_PAGE_SIZE),
	sort: _enum(auditPagesSortFields).default("url"),
	order: _enum(["asc", "desc"]).default("asc"),
	query: string().trim().max(200).optional(),
	status: _enum([
		"all",
		"ok",
		"redirect",
		"error",
		"missing"
	]).default("all"),
	fetchClass: _enum(["all", ...PAGE_FETCH_CLASSES]).default("all"),
	minWords: optionalBound,
	maxWords: optionalBound,
	minResponseMs: optionalBound,
	maxResponseMs: optionalBound,
	missingAlt: _enum([
		"all",
		"yes",
		"no"
	]).default("all")
});
var getAuditIssuesSchema = object({
	projectId: string().min(1),
	auditId: string().min(1),
	/** One issue type (an expanded group), or every issue for exports. */
	issueType: string().min(1).max(100).optional(),
	page: number().int().positive().default(1),
	pageSize: number().int().positive().max(AUDIT_ROWS_MAX_PAGE_SIZE)
});
var getAuditHistorySchema = object({ projectId: string().min(1) });
var deleteAuditSchema = object({
	projectId: string().min(1),
	auditId: string().min(1)
});
var getCrawlProgressSchema = object({
	projectId: string().min(1),
	auditId: string().min(1)
});
var auditSearchSchema = object({
	auditId: string().optional().catch(void 0),
	url: string().optional().catch(void 0),
	tab: _enum([
		"issues",
		"pages",
		"performance"
	]).catch("issues").default("issues")
});
//#endregion
export { getAuditHistorySchema as a, getAuditStatusSchema as c, startAuditSchema as d, deleteAuditSchema as i, getAuditSummarySchema as l, auditPagesSortFields as n, getAuditIssuesSchema as o, auditSearchSchema as r, getAuditPagesSchema as s, AUDIT_ROWS_MAX_PAGE_SIZE as t, getCrawlProgressSchema as u };
