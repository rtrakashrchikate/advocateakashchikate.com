//#region src/shared/lighthouse.ts
var LIGHTHOUSE_CATEGORIES = [
	"performance",
	"accessibility",
	"best-practices",
	"seo"
];
var LIGHTHOUSE_CATEGORY_TABS = ["all", ...LIGHTHOUSE_CATEGORIES];
//#endregion
export { LIGHTHOUSE_CATEGORY_TABS as n, LIGHTHOUSE_CATEGORIES as t };
