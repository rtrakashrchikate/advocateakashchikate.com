import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
import { U as AppError } from "./onboarding-drip-B7bIbv_6.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { t as ReportTemplateService } from "./ReportTemplateService-4PL3hb_n.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/serverFunctions/reportTemplates.ts?tss-serverfn-split
var projectScopeSchema = object({ projectId: string().min(1) });
var saveSchema = object({
	projectId: string().min(1),
	templateId: string().min(1).optional(),
	name: string().min(1),
	description: string().min(1),
	instructions: string().min(1)
});
var templateRefSchema = object({
	projectId: string().min(1),
	templateId: string().min(1)
});
var listReportTemplates_createServerFn_handler = createServerRpc({
	id: "ddc61ba533ee4526881dec258edaa117eac5f2984345448f00e3ed653fb873ef",
	name: "listReportTemplates",
	filename: "src/serverFunctions/reportTemplates.ts"
}, (opts) => listReportTemplates.__executeServer(opts));
var listReportTemplates = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(projectScopeSchema).handler(listReportTemplates_createServerFn_handler, async ({ context }) => ReportTemplateService.listReportTemplates(context.projectId));
var saveReportTemplate_createServerFn_handler = createServerRpc({
	id: "b9e1c8827cf9e915cf77cf19c85a084e1d5772198eab957890605d17d30661c7",
	name: "saveReportTemplate",
	filename: "src/serverFunctions/reportTemplates.ts"
}, (opts) => saveReportTemplate.__executeServer(opts));
var saveReportTemplate = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(saveSchema).handler(saveReportTemplate_createServerFn_handler, async ({ data, context }) => {
	try {
		const { templateId, created } = await ReportTemplateService.saveReportTemplate({
			projectId: context.projectId,
			templateId: data.templateId,
			name: data.name,
			description: data.description,
			instructions: data.instructions,
			createdBy: "OpenSEO app",
			createdByUserId: context.userId
		});
		return {
			ok: true,
			templateId,
			created
		};
	} catch (error) {
		if (error instanceof AppError && error.code === "VALIDATION_ERROR") return {
			ok: false,
			message: error.message
		};
		throw error;
	}
});
var deleteReportTemplate_createServerFn_handler = createServerRpc({
	id: "d2bd198d2bfa42494e65407da774107b51ad449088c45a6020a8a65e0ac5142a",
	name: "deleteReportTemplate",
	filename: "src/serverFunctions/reportTemplates.ts"
}, (opts) => deleteReportTemplate.__executeServer(opts));
var deleteReportTemplate = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(templateRefSchema).handler(deleteReportTemplate_createServerFn_handler, async ({ data, context }) => {
	await ReportTemplateService.deleteReportTemplate(context.projectId, data.templateId);
	return { templateId: data.templateId };
});
//#endregion
export { deleteReportTemplate_createServerFn_handler, listReportTemplates_createServerFn_handler, saveReportTemplate_createServerFn_handler };
