import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
import { c as isHostedClientAuthMode, f as usesBetterAuthClient } from "./auth-mode-DhGCw2Bx.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { n as getErrorCode } from "./error-messages-D7nntGF_.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { n as captureClientEvent } from "./posthog-BMFJOGWd.js";
import { r as sendTeamInvitation } from "./organization-BUUwiNQd.js";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C8cX1CPK.js";
import { i as revalidateLogic } from "./useForm-B2StPr3w.js";
import { t as useAppForm } from "./useAppForm-DjX0VDRv.js";
//#region src/client/features/team/InviteTeammateModal.tsx
var import_jsx_runtime = require_jsx_runtime();
var inviteSchema = object({ email: string().trim().email("Enter a valid email address.") });
function inviteErrorMessage(error) {
	const code = getErrorCode(error);
	if (code === "RATE_LIMITED") return "Invitation limit reached for today. Try again tomorrow.";
	if (code === "UPSTREAM_UNAVAILABLE") return "The invitation was saved but the email couldn't be sent. Use Resend in a moment to retry.";
	return "We couldn't send that invitation.";
}
function announceInvitation(result, sentMessage) {
	if (!result.inviteUrl) {
		toast.success(sentMessage);
		return;
	}
	const inviteUrl = result.inviteUrl;
	(navigator.clipboard?.writeText(inviteUrl) ?? Promise.reject(/* @__PURE__ */ new Error())).then(() => toast.success("Invitation link copied"), () => toast.success("Invitation link", {
		description: inviteUrl,
		duration: 2e4
	}));
}
function InviteTeammateModal({ onClose, onInvited }) {
	const inviteMutation = useMutation({
		mutationFn: (inviteeEmail) => sendTeamInvitation({ data: { email: inviteeEmail } }),
		onSuccess: (result) => {
			captureClientEvent("team:invitation_send");
			announceInvitation(result, "Invitation sent");
			onInvited();
			onClose();
		},
		onError: (error) => {
			if (getErrorCode(error) === "CONFLICT") form.setErrorMap({ onSubmit: { fields: { email: "This person is already a member." } } });
			else toast.error(inviteErrorMessage(error));
			onInvited();
		}
	});
	const sharesLink = usesBetterAuthClient() && !isHostedClientAuthMode();
	const form = useAppForm({
		defaultValues: { email: "" },
		validationLogic: revalidateLogic(),
		validators: { onDynamic: inviteSchema },
		onSubmit: ({ value }) => inviteMutation.mutateAsync(value.email.trim())
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => {
			if (!open && !inviteMutation.isPending) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
			showCloseButton: false,
			className: "sm:max-w-md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.AppForm, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(form.Form, {
				className: "flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Invite a teammate" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: sharesLink ? "They'll join as an Admin with full access to each project. Share the invitation link with them; they create their account from it. It expires in 7 days." : "They'll join as an Admin with full access to each project except for billing. The invitation link expires in 7 days." })] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.AppField, {
						name: "email",
						children: (field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(field.TextField, {
							label: "Email",
							type: "email",
							placeholder: "teammate@company.com",
							required: true,
							autoFocus: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						onClick: onClose,
						disabled: inviteMutation.isPending,
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.SubmitButton, { children: "Send invite" })] })
				]
			}) })
		})
	});
}
//#endregion
export { announceInvitation as n, inviteErrorMessage as r, InviteTeammateModal as t };
