import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { t as normalizeAiSuggestion } from "./ai-prompt-suggestions-BlfcqfCk.js";
import { j as useQueryClient, t as useQuery } from "./useQuery-B93OR2NQ.js";
import { a as SkeletonPageContent, g as EmptyState, s as SkeletonTableRows } from "./QueryState-Q8BZIblk.js";
import { n as createLucideIcon } from "./dist-fVOGIv0D.js";
import { t as ChevronDown } from "./chevron-down-Bmgnw7hU.js";
import { t as ChevronRight } from "./chevron-right-CMQSolKd.js";
import { t as Link2 } from "./link-2-BzRVDXzK.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as Plus } from "./plus-C1Kukp-u.js";
import { t as Badge } from "./badge-B9fV075d.js";
import { T as researchAiVisibilityPrompts, _ as useAiVisibilityTracker, a as PromptTrackingWithoutUpgradeButton, h as aiVisibilityKey, r as AiQueryError, u as aiResearchKeywordsQueryOptions } from "./shared-BW7GMYqD.js";
import { t as Route } from "./research-Cal4A95w.js";
import { n as BackLink, r as PageHeader } from "./PageHeader-a3_4WaC8.js";
import { a as TableHead, i as TableCell, n as TableBody, o as TableHeader, s as TableRow, t as Table } from "./table-CqwvrC02.js";
import { t as SafeExternalLink } from "./SafeExternalLink-UBj9FIVT.js";
import { i as useSelectionAnchor, n as makeSelectionColumn, r as useDataTable, t as DataTable } from "./DataTable-CF1_e923.js";
import { t as DomainFavicon } from "./DomainFavicon-C8RD5CUv.js";
import { n as TrackerPatchReview, r as TopicField } from "./TrackerPatchReview-B1BLBPiO.js";
import { n as SearchInput, t as SearchCard } from "./SearchCard-BQ0zhEYZ.js";
import { n as TableBulkActionButton, t as TableBulkActionBar } from "./TableBulkActionBar-D4kfSAB9.js";
import { t as PaidPlanGate } from "./PaidPlanGate-EyikrOJT.js";
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ListPlus = createLucideIcon("list-plus", [
	["path", {
		d: "M11 12H3",
		key: "51ecnj"
	}],
	["path", {
		d: "M16 6H3",
		key: "1wxfjs"
	}],
	["path", {
		d: "M16 18H3",
		key: "12xzn7"
	}],
	["path", {
		d: "M18 9v6",
		key: "1twb98"
	}],
	["path", {
		d: "M21 12h-6",
		key: "bt1uis"
	}]
]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var MessagesSquare = createLucideIcon("messages-square", [["path", {
	d: "M16 10a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 14.286V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z",
	key: "1n2ejm"
}], ["path", {
	d: "M20 9a2 2 0 0 1 2 2v10.286a.71.71 0 0 1-1.212.502l-2.202-2.202A2 2 0 0 0 17.172 19H10a2 2 0 0 1-2-2v-1",
	key: "1qfcsi"
}]]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Telescope = createLucideIcon("telescope", [
	["path", {
		d: "m10.065 12.493-6.18 1.318a.934.934 0 0 1-1.108-.702l-.537-2.15a1.07 1.07 0 0 1 .691-1.265l13.504-4.44",
		key: "k4qptu"
	}],
	["path", {
		d: "m13.56 11.747 4.332-.924",
		key: "19l80z"
	}],
	["path", {
		d: "m16 21-3.105-6.21",
		key: "7oh9d"
	}],
	["path", {
		d: "M16.485 5.94a2 2 0 0 1 1.455-2.425l1.09-.272a1 1 0 0 1 1.212.727l1.515 6.06a1 1 0 0 1-.727 1.213l-1.09.272a2 2 0 0 1-2.425-1.455z",
		key: "m7xp4m"
	}],
	["path", {
		d: "m6.158 8.633 1.114 4.456",
		key: "74o979"
	}],
	["path", {
		d: "m8 21 3.105-6.21",
		key: "1fvxut"
	}],
	["circle", {
		cx: "12",
		cy: "13",
		r: "2",
		key: "1c1ljs"
	}]
]);
//#endregion
//#region src/client/features/ai-visibility/PromptResearchTable.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var promptColumns = [
	{
		id: "prompt",
		header: "Prompt",
		cell: ({ row: { original: prompt } }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: prompt.text }),
			prompt.tracked && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "secondary",
				className: "ml-2",
				children: "Tracked"
			}),
			prompt.variants.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs text-muted-foreground",
				title: prompt.variants.join("\n"),
				children: [
					"+",
					prompt.variants.length,
					" similar",
					" ",
					prompt.variants.length === 1 ? "prompt" : "prompts",
					" merged"
				]
			})
		] })
	},
	{
		id: "sources",
		header: "Sources",
		meta: { headerClassName: "w-40" },
		cell: ({ row: { original: prompt } }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm",
			children: prompt.sources.length ? `${prompt.sources.length} ${prompt.sources.length === 1 ? "source" : "sources"}` : "No sources"
		}), prompt.ownDomainCited && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "success",
			size: "sm",
			className: "ml-2",
			children: "You"
		})] })
	},
	{
		id: "expand",
		header: () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Details"
		}),
		meta: { headerClassName: "w-10" },
		cell: ({ row }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "icon-sm",
			"aria-expanded": row.getIsExpanded(),
			"aria-label": `Show sources for ${row.original.text}`,
			onClick: () => row.toggleExpanded(),
			children: row.getIsExpanded() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {})
		})
	}
];
/** Tracked prompts can't be selected; a selection only adds new prompts. */
function PromptResearchTable({ prompts, rowSelection, onRowSelectionChange, empty, ...frame }) {
	const selectAnchorRef = useSelectionAnchor();
	const columns = (0, import_react.useMemo)(() => [makeSelectionColumn(selectAnchorRef, (row) => `Select ${row.original.text}`), ...promptColumns], [selectAnchorRef]);
	const table = useDataTable({
		data: prompts,
		columns,
		state: { rowSelection },
		onRowSelectionChange,
		getRowId: (prompt) => prompt.text,
		enableRowSelection: (row) => !row.original.tracked
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
		...frame,
		table,
		empty,
		renderExpandedRow: (row) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptSources, { prompt: row.original })
	});
}
function PromptSources({ prompt }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2 py-1 pl-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: prompt.brandMentioned ? "success" : "outline",
			children: prompt.brandMentioned ? "Your brand is mentioned" : "Your brand is not mentioned"
		}), prompt.sources.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "space-y-1.5",
			children: prompt.sources.map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DomainFavicon, { domain: source.domain }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "w-40 shrink-0 truncate text-muted-foreground",
						children: source.domain
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafeExternalLink, {
						url: source.url,
						label: source.title ?? source.url,
						className: "inline-flex min-w-0 items-center gap-1 hover:underline"
					}),
					source.own && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
						variant: "success",
						size: "sm",
						children: "You"
					})
				]
			}, source.url))
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "The AI answered from memory and cited no sources."
		})]
	});
}
//#endregion
//#region src/client/features/ai-visibility/PromptResearchKeyword.tsx
function PromptResearchKeyword({ projectId, state, keyword }) {
	const queryClient = useQueryClient();
	const [rowSelection, setRowSelection] = (0, import_react.useState)({});
	const [change, setChange] = (0, import_react.useState)(null);
	const research = useQuery({
		queryKey: [
			...aiVisibilityKey(projectId),
			"research",
			keyword,
			state.prompts.filter((prompt) => !prompt.archived).map(({ id }) => id)
		],
		queryFn: () => researchAiVisibilityPrompts({ data: {
			projectId,
			keyword
		} }),
		retry: false,
		staleTime: 36e5,
		refetchOnWindowFocus: false
	});
	const selected = (research.data?.prompts ?? []).filter((prompt) => rowSelection[prompt.text]).map((prompt) => prompt.text);
	const track = () => setChange({
		prompts: selected,
		topic: state.topics.find((name) => normalizeAiSuggestion(name) === normalizeAiSuggestion(keyword)) ?? keyword
	});
	const topic = change?.topic.trim();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBulkActionBar, {
			selectedCount: selected.length,
			onClear: () => setRowSelection({}),
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center px-1.5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBulkActionButton, {
					icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }),
					onClick: track,
					children: "Track prompts"
				})
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptResearchTable, {
			prompts: research.data?.prompts ?? [],
			rowSelection,
			onRowSelectionChange: setRowSelection,
			isLoading: research.isPending,
			error: research.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiQueryError, {
				error: research.error,
				retry: () => {
					research.refetch();
				}
			}) : void 0,
			empty: {
				title: `No prompts found for \u201C${keyword}\u201D`,
				description: "Try a shorter, broader term."
			},
			toolbar: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b px-4 py-3 border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-medium",
					children: [
						"Prompts about \u201C",
						keyword,
						"\u201D"
					]
				})
			})
		}),
		change && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrackerPatchReview, {
			projectId,
			state,
			patch: { prompts: change.prompts.map((text) => ({
				text,
				topic: topic || void 0
			})) },
			canSave: Boolean(topic),
			onClose: () => setChange(null),
			onSaved: (next) => {
				queryClient.setQueryData([...aiVisibilityKey(projectId), "tracker"], next);
				setChange(null);
				setRowSelection({});
			},
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TopicField, {
				topics: state.topics,
				value: change.topic,
				onChange: (name) => setChange({
					...change,
					topic: name
				})
			})
		})
	] });
}
//#endregion
//#region src/client/features/ai-visibility/PromptResearchPage.tsx
function PromptResearchPage({ projectId, keyword }) {
	const trackerQuery = useAiVisibilityTracker(projectId);
	const state = trackerQuery.data;
	if (trackerQuery.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonPageContent, {});
	if (trackerQuery.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiQueryError, {
		error: trackerQuery.error,
		retry: () => {
			trackerQuery.refetch();
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Prompt Research",
			description: "Find the questions people ask AI about your market, and the sites the answers cite.",
			backLink: keyword && state?.configured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {
				to: "/p/$projectId/ai-visibility/research",
				params: { projectId },
				children: "Relevant keywords"
			}) : void 0
		}), !state?.configured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			icon: Telescope,
			title: "Prompt research starts with a tracker",
			description: "Set up prompt tracking to research prompts for your topics.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				nativeButton: false,
				render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/p/$projectId/ai-visibility",
					params: { projectId }
				}),
				children: "Set up prompt tracking"
			})
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeywordSearch, {
			projectId,
			keyword
		}, `search:${keyword ?? ""}`), keyword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptResearchKeyword, {
			projectId,
			state,
			keyword
		}, keyword) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeywordList, { projectId })] })]
	});
}
function KeywordList({ projectId }) {
	const navigate = useNavigate();
	const query = useQuery(aiResearchKeywordsQueryOptions(projectId));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-lg border bg-card border-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b p-4 border-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-medium",
				children: "Relevant keywords"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Select a keyword to see the prompts people ask AI about it."
			})]
		}), query.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonTableRows, {
			rows: 5,
			columns: 1,
			className: "p-4"
		}) : query.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AiQueryError, {
			error: query.error,
			retry: () => {
				query.refetch();
			}
		}) : !query.data.keywords.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "p-10 text-center text-sm text-muted-foreground",
			children: "Add topics to your tracker, or search a keyword above."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Keyword" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
			className: "w-10",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "sr-only",
				children: "Open"
			})
		})] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: query.data.keywords.map((keyword) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
			className: "cursor-pointer",
			onClick: () => void navigate({
				to: "/p/$projectId/ai-visibility/research",
				params: { projectId },
				search: { q: keyword }
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/p/$projectId/ai-visibility/research",
				params: { projectId },
				search: { q: keyword },
				className: "font-medium hover:underline",
				onClick: (event) => event.stopPropagation(),
				children: keyword
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4 text-muted-foreground" }) })]
		}, keyword)) })] })]
	});
}
function KeywordSearch({ projectId, keyword }) {
	const navigate = useNavigate();
	const [draft, setDraft] = (0, import_react.useState)(keyword ?? "");
	const [error, setError] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchCard, {
		onSubmit: (event) => {
			event.preventDefault();
			if (!draft.trim()) {
				setError("Enter a keyword.");
				return;
			}
			navigate({
				to: "/p/$projectId/ai-visibility/research",
				params: { projectId },
				search: { q: draft.trim() }
			});
		},
		error,
		errorId: "ai-keyword-research-error",
		secondRow: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			id: "ai-keyword-research-cost",
			className: "text-xs text-muted-foreground",
			children: "About $0.25 in credits per keyword."
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchInput, {
			value: draft,
			onChange: (event) => {
				setDraft(event.target.value);
				setError(null);
			},
			placeholder: "Enter a keyword",
			"aria-label": "Keyword",
			"aria-invalid": error ? true : void 0,
			"aria-describedby": error ? "ai-keyword-research-error ai-keyword-research-cost" : "ai-keyword-research-cost",
			maxLength: 100
		})
	});
}
//#endregion
//#region src/routes/_app/p/$projectId/ai-visibility/research.tsx?tsr-split=component
var PROMPT_RESEARCH_FEATURES = [
	{
		icon: MessagesSquare,
		title: "Questions about your market",
		body: "See the questions people ask about a keyword, most common first, with ChatGPT's answer to each."
	},
	{
		icon: Link2,
		title: "Who gets cited",
		body: "See which sites ChatGPT cited when it answered, and whether yours is one of them."
	},
	{
		icon: ListPlus,
		title: "Track the ones that matter",
		body: "Pick the questions worth watching and add them to Prompt Tracking in one step."
	}
];
function AiResearchRoute() {
	const { projectId } = Route.useParams();
	const { q } = Route.useSearch();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaidPlanGate, {
		feature: "Prompt Research",
		description: "Find questions people ask about your market, see how ChatGPT answers them, and check which sites the answers cite.",
		features: PROMPT_RESEARCH_FEATURES,
		alternative: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptTrackingWithoutUpgradeButton, { projectId }),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PromptResearchPage, {
			projectId,
			keyword: q
		}, projectId)
	});
}
//#endregion
export { AiResearchRoute as component };
