import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
//#region src/types/schemas/aiPromptResearch.ts
var aiKeywordSchema = string().trim().min(1).max(100);
var researchAiPromptsSchema = object({
	projectId: string().uuid(),
	keyword: aiKeywordSchema.describe("A short head term such as a tracker topic name. Exact multi-word phrases return few prompts.")
});
//#endregion
export { researchAiPromptsSchema as t };
