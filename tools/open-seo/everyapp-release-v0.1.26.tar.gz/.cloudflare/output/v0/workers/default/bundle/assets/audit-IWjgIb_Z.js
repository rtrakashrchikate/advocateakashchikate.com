import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { R as captureServerEvent, U as AppError } from "./onboarding-drip-B7bIbv_6.js";
import { t as AuditRepository } from "./AuditRepository-BtGPAfyq.js";
import { t as requireOrgPermission } from "./org-gate-CXPt5GkI.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { a as getAuditHistorySchema, c as getAuditStatusSchema, d as startAuditSchema, i as deleteAuditSchema, l as getAuditSummarySchema, o as getAuditIssuesSchema, s as getAuditPagesSchema, u as getCrawlProgressSchema } from "./audit-BJwJwQG7.js";
import { n as parseAuditConfig, r as isAuditRenderingAllowed, t as AuditService } from "./AuditService-7n2seMDR.js";
import { t as CrawlerCredentialService } from "./CrawlerCredentialService-fwwFRyWZ.js";
import { i as listAuditPages, n as getAuditResultsSummary, r as listAuditIssues } from "./auditResultsQueries-BzGkoHGc.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
import { waitUntil } from "cloudflare:workers";
//#region src/server/features/audit/services/AuditResultsService.ts
async function requireAudit(auditId, projectId) {
	const audit = await AuditRepository.getAuditForProject(auditId, projectId);
	if (!audit) throw new AppError("NOT_FOUND");
	return audit;
}
function hostnameOf(url) {
	try {
		return new URL(url).hostname;
	} catch {
		return url;
	}
}
/**
* The host most of the site's real (2xx) pages live on, so the pages table
* can drop it from paths. The start URL's host is only a fallback: audits
* often start from the apex domain of a site that canonicalizes to www.
*/
function predominantHost(urls, startUrl) {
	const counts = /* @__PURE__ */ new Map();
	for (const url of urls) {
		const host = hostnameOf(url);
		counts.set(host, (counts.get(host) ?? 0) + 1);
	}
	let best = hostnameOf(startUrl);
	let bestCount = 0;
	for (const [host, hostCount] of counts) if (hostCount > bestCount) {
		best = host;
		bestCount = hostCount;
	}
	return best;
}
/** Everything the results page shows outside the paged tables. */
async function getSummary(auditId, projectId) {
	const audit = await requireAudit(auditId, projectId);
	const config = parseAuditConfig(audit.config);
	if (!config) throw new AppError("INTERNAL_ERROR", "Invalid audit configuration");
	const { issueGroups, fetchClassRows, lighthouse, okPageUrls } = await getAuditResultsSummary(auditId);
	const fetchClassCounts = {
		ok: 0,
		blocked: 0,
		rate_limited: 0,
		error: 0
	};
	let pageCount = 0;
	let totalResponseMs = 0;
	for (const row of fetchClassRows) {
		fetchClassCounts[row.fetchClass] += row.count;
		pageCount += row.count;
		totalResponseMs += row.totalResponseMs;
	}
	const groups = /* @__PURE__ */ new Map();
	for (const row of issueGroups) {
		const group = groups.get(row.issueType);
		if (group) group.count += row.count;
		else groups.set(row.issueType, { ...row });
	}
	return {
		audit: {
			id: audit.id,
			startUrl: audit.startUrl,
			status: audit.status,
			pagesCrawled: audit.pagesCrawled,
			pagesTotal: audit.pagesTotal,
			startedAt: audit.startedAt,
			completedAt: audit.completedAt,
			config
		},
		pageCount,
		issueCount: issueGroups.reduce((sum, row) => sum + row.count, 0),
		issueGroups: Array.from(groups.values()),
		fetchClassCounts,
		averageResponseMs: pageCount > 0 ? Math.round(totalResponseMs / pageCount) : 0,
		canonicalHost: predominantHost(okPageUrls.map((row) => row.url), audit.startUrl),
		lighthouse
	};
}
async function getPages(input, projectId) {
	const { auditId, ...params } = input;
	await requireAudit(auditId, projectId);
	return listAuditPages(auditId, params);
}
async function getIssues(input, projectId) {
	const { auditId, ...params } = input;
	await requireAudit(auditId, projectId);
	return listAuditIssues(auditId, params);
}
var AuditResultsService = {
	getSummary,
	getPages,
	getIssues
};
//#endregion
//#region src/serverFunctions/audit.ts?tss-serverfn-split
var startAudit_createServerFn_handler = createServerRpc({
	id: "e239daa45c0dc82d2216f3ac9a60781ba3bad43f9837cb6779399d0c3d87885c",
	name: "startAudit",
	filename: "src/serverFunctions/audit.ts"
}, (opts) => startAudit.__executeServer(opts));
var startAudit = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(startAuditSchema).handler(startAudit_createServerFn_handler, async ({ data, context }) => {
	const limitTier = await AuditService.resolveAuditLimitTier(context);
	const renderJavaScript = data.renderJavaScript && await isAuditRenderingAllowed();
	const result = await AuditService.startAudit({
		actorUserId: context.userId,
		billingCustomer: context,
		projectId: context.projectId,
		startUrl: data.startUrl,
		maxPages: data.maxPages,
		lighthouseStrategy: data.lighthouseStrategy,
		limitTier,
		renderJavaScript
	});
	waitUntil(captureServerEvent({
		distinctId: context.userId,
		event: "site_audit:start",
		organizationId: context.organizationId,
		properties: {
			project_id: context.projectId,
			max_pages: data.maxPages ?? 50,
			run_lighthouse: data.lighthouseStrategy !== "none",
			plan_tier: limitTier
		}
	}));
	return result;
});
var getAuditStatus_createServerFn_handler = createServerRpc({
	id: "75f7965168786313e194a1941f91dd242a6b8c06b1cf69463eae0e9ce5dd6773",
	name: "getAuditStatus",
	filename: "src/serverFunctions/audit.ts"
}, (opts) => getAuditStatus.__executeServer(opts));
var getAuditStatus = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getAuditStatusSchema).handler(getAuditStatus_createServerFn_handler, async ({ data, context }) => {
	return AuditService.getStatus(data.auditId, context.projectId);
});
var getAuditSummary_createServerFn_handler = createServerRpc({
	id: "4b2c9e5c0f9644b9fbac2cb8386732eb0a841e114a289b83cefa630dbcf49660",
	name: "getAuditSummary",
	filename: "src/serverFunctions/audit.ts"
}, (opts) => getAuditSummary.__executeServer(opts));
var getAuditSummary = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getAuditSummarySchema).handler(getAuditSummary_createServerFn_handler, async ({ data, context }) => {
	return AuditResultsService.getSummary(data.auditId, context.projectId);
});
var getAuditPages_createServerFn_handler = createServerRpc({
	id: "8903ef9d79153d21788e22d2195e4b9ab8423b97de57d78b3ab88c5df9c85e70",
	name: "getAuditPages",
	filename: "src/serverFunctions/audit.ts"
}, (opts) => getAuditPages.__executeServer(opts));
var getAuditPages = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getAuditPagesSchema).handler(getAuditPages_createServerFn_handler, async ({ data, context }) => {
	const { projectId: _projectId, ...input } = data;
	return AuditResultsService.getPages(input, context.projectId);
});
var getAuditIssues_createServerFn_handler = createServerRpc({
	id: "6ddfb7a81efc3428790c631bf5547eeee71c77909fc1fce99b67caeb84279006",
	name: "getAuditIssues",
	filename: "src/serverFunctions/audit.ts"
}, (opts) => getAuditIssues.__executeServer(opts));
var getAuditIssues = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getAuditIssuesSchema).handler(getAuditIssues_createServerFn_handler, async ({ data, context }) => {
	const { projectId: _projectId, ...input } = data;
	return AuditResultsService.getIssues(input, context.projectId);
});
var getAuditHistory_createServerFn_handler = createServerRpc({
	id: "8e1e5f26a194415159d9074271d62e81c5b365b4c35612f4e23581af549700cf",
	name: "getAuditHistory",
	filename: "src/serverFunctions/audit.ts"
}, (opts) => getAuditHistory.__executeServer(opts));
var getAuditHistory = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getAuditHistorySchema).handler(getAuditHistory_createServerFn_handler, async ({ context }) => {
	return AuditService.getHistory(context.projectId);
});
var getCrawlProgress_createServerFn_handler = createServerRpc({
	id: "a28e240f440a737b1ba00fa06c35615836e9658df9c6a9b04b18bd57f4533a93",
	name: "getCrawlProgress",
	filename: "src/serverFunctions/audit.ts"
}, (opts) => getCrawlProgress.__executeServer(opts));
var getCrawlProgress = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getCrawlProgressSchema).handler(getCrawlProgress_createServerFn_handler, async ({ data, context }) => {
	return AuditService.getCrawlProgress(data.auditId, context.projectId);
});
var deleteAudit_createServerFn_handler = createServerRpc({
	id: "516782e359aa3cdba9ed9ea54db3d5b889263ae7b7a025542320a44198af7371",
	name: "deleteAudit",
	filename: "src/serverFunctions/audit.ts"
}, (opts) => deleteAudit.__executeServer(opts));
var deleteAudit = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(deleteAuditSchema).handler(deleteAudit_createServerFn_handler, async ({ data, context }) => {
	requireOrgPermission(context, { project: ["delete"] });
	await AuditService.remove(data.auditId, context.projectId);
	return { success: true };
});
var getAuditCapabilities_createServerFn_handler = createServerRpc({
	id: "e484ba444c8df180376d2d15c72338138a489e647355c5db83b69ca01fe5ca87",
	name: "getAuditCapabilities",
	filename: "src/serverFunctions/audit.ts"
}, (opts) => getAuditCapabilities.__executeServer(opts));
var getAuditCapabilities = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getAuditHistorySchema).handler(getAuditCapabilities_createServerFn_handler, async () => ({
	canRenderJavaScript: await isAuditRenderingAllowed(),
	canStoreCrawlerAccess: await CrawlerCredentialService.hasEncryptionKey()
}));
//#endregion
export { deleteAudit_createServerFn_handler, getAuditCapabilities_createServerFn_handler, getAuditHistory_createServerFn_handler, getAuditIssues_createServerFn_handler, getAuditPages_createServerFn_handler, getAuditStatus_createServerFn_handler, getAuditSummary_createServerFn_handler, getCrawlProgress_createServerFn_handler, startAudit_createServerFn_handler };
