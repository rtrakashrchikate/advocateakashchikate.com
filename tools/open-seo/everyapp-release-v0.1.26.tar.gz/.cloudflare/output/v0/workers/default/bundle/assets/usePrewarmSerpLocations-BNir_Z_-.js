import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
import { o as formatLocationLabel } from "./keyword-locations-4GfvBtRY.js";
import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { r as Spinner, t as Button } from "./button-DrcZrdio.js";
import { t as MapPin } from "./map-pin-BzsQS5Ua.js";
import { t as Search } from "./search-8b-KxN4Z.js";
import { t as X } from "./x-CPPij64W.js";
import { t as createSsrRpc } from "./createSsrRpc-Vp3C13VD.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
import { t as Badge } from "./badge-B9fV075d.js";
import { n as InputGroupAddon } from "./input-group-CmFmGa25.js";
import { f as ComboboxList, h as useComboboxAnchor, l as ComboboxInput, o as ComboboxContent, p as ComboboxTrigger, s as ComboboxEmpty, t as Combobox, u as ComboboxItem } from "./combobox-BYdKkOBU.js";
//#region src/serverFunctions/serp-locations.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/** ISO 3166-1 alpha-2, e.g. "us" \u2014 DataForSEO rejects country names. */
var countryCodeField = string().regex(/^[a-z]{2}$/i);
var searchSerpLocationsSchema = object({
	query: string().min(1).max(100),
	countryCode: countryCodeField
});
var searchSerpLocations = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(searchSerpLocationsSchema).handler(createSsrRpc("16b95567643a21275b38fde625b8e1428bd2aeaff2440637c2a21009637d64d9"));
/**
* Warm the per-country location cache so the first real search is fast.
* Fired when the user switches to Local targeting; the first search per
* country otherwise pays the full ~9.5MB DataForSEO fetch (~3s).
*/
var prewarmSerpLocations = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(object({ countryCode: countryCodeField })).handler(createSsrRpc("364efb68f010cdd93e01da48b22253ac6e745a792ce18710f489a70100cde203"));
//#endregion
//#region src/client/components/SerpLocationCombobox.tsx
var import_jsx_runtime = require_jsx_runtime();
function useDebounce(value, delayMs) {
	const [debounced, setDebounced] = (0, import_react.useState)(value);
	(0, import_react.useEffect)(() => {
		const timer = setTimeout(() => setDebounced(value), delayMs);
		return () => clearTimeout(timer);
	}, [value, delayMs]);
	return debounced;
}
function useSerpLocationSearch(countryCode) {
	const [query, setQuery] = (0, import_react.useState)("");
	const trimmed = query.trim();
	const debounced = useDebounce(trimmed, 350);
	const searchQuery = useQuery({
		queryKey: [
			"serpLocations",
			countryCode,
			debounced
		],
		queryFn: () => searchSerpLocations({ data: {
			query: debounced,
			countryCode
		} }),
		enabled: debounced !== "",
		staleTime: 3e5
	});
	const searching = trimmed !== "" && (trimmed !== debounced || searchQuery.isFetching);
	return {
		setQuery,
		searching,
		results: searching || !trimmed ? [] : searchQuery.data ?? [],
		emptyMessage: !trimmed ? "Type a city, county, or region" : searching ? "Searching..." : searchQuery.isError ? "Unable to load locations" : `No locations found for "${trimmed}"`
	};
}
function selectedItem(value) {
	return value ? {
		locationName: value,
		displayLabel: formatLocationLabel(value)
	} : null;
}
function LocationResults() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxList, { children: (item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxItem, {
		value: item,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "truncate",
			children: item.displayLabel
		}), item.locationType ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "secondary",
			size: "sm",
			className: "ml-auto",
			children: item.locationType
		}) : null]
	}, item.locationName) });
}
/** Searches the cities, counties and regions of one country. */
function SerpLocationCombobox({ value, onChange, countryCode, placeholder = "Search cities...", id, invalid }) {
	const anchor = useComboboxAnchor();
	const { setQuery, searching, results, emptyMessage } = useSerpLocationSearch(countryCode);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Combobox, {
		items: results,
		value: selectedItem(value),
		filter: null,
		itemToStringLabel: (item) => item.displayLabel,
		isItemEqualToValue: (item, current) => item.locationName === current.locationName,
		onValueChange: (item) => {
			setQuery("");
			onChange(item?.locationName);
		},
		onOpenChange: (open) => {
			if (!open) setQuery("");
		},
		onInputValueChange: (text, { reason }) => {
			if (reason !== "input-change") return;
			setQuery(text);
			if (!text.trim()) onChange(void 0);
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref: anchor,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxInput, {
				id,
				"aria-invalid": invalid || void 0,
				className: "w-full",
				placeholder,
				showTrigger: false,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, {
					align: "inline-start",
					children: searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {})
				})
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxContent, {
			anchor,
			className: "w-max",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxEmpty, { children: emptyMessage }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocationResults, {})]
		})]
	});
}
/** `SerpLocationCombobox` as a compact button, with its search inside the list. */
function SerpLocationChip({ value, onChange, countryCode, label }) {
	const { setQuery, searching, results, emptyMessage } = useSerpLocationSearch(countryCode);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Combobox, {
			items: results,
			value: selectedItem(value),
			filter: null,
			itemToStringLabel: (item) => item.displayLabel,
			isItemEqualToValue: (item, current) => item.locationName === current.locationName,
			onValueChange: (item) => {
				setQuery("");
				onChange(item?.locationName);
			},
			onOpenChange: (open) => {
				if (!open) setQuery("");
			},
			onInputValueChange: (text, { reason }) => {
				if (reason === "input-change") setQuery(text);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxTrigger, {
				"aria-label": value ? `${label}: ${formatLocationLabel(value)}` : label,
				render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					className: `min-w-0 font-normal focus-visible:z-10 ${value ? "rounded-r-none" : ""}`
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "max-w-40 truncate",
					children: value ? formatLocationLabel(value, 2) : label
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ComboboxContent, {
				className: "w-80",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxInput, {
						showTrigger: false,
						placeholder: "Search",
						"aria-label": `Search ${label.toLowerCase()}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, { children: searching ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {}) })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ComboboxEmpty, { children: emptyMessage }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocationResults, {})
				]
			})]
		}), value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			size: "icon",
			className: "-ml-px rounded-l-none focus-visible:z-10",
			"aria-label": `Clear ${label.toLowerCase()}`,
			onClick: () => onChange(void 0),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
		}) : null]
	});
}
//#endregion
//#region src/client/components/usePrewarmSerpLocations.ts
/**
* Warm the server-side location cache before the first keystroke, so the
* country list is hot when the user searches. Best-effort: a failed warm just
* means the first search is slower, so no retries, and staleTime keeps one
* warm per country per session.
*/
function usePrewarmSerpLocations(countryCode, enabled) {
	useQuery({
		queryKey: ["serp-locations-prewarm", countryCode],
		queryFn: () => prewarmSerpLocations({ data: { countryCode } }),
		enabled,
		staleTime: Infinity,
		retry: false
	});
}
//#endregion
export { SerpLocationChip as n, SerpLocationCombobox as r, usePrewarmSerpLocations as t };
