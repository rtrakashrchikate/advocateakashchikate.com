import { Fn as object, Jn as string, Pn as number } from "./schemas-BPIpYT5n.js";
import { U as AppError } from "./onboarding-drip-B7bIbv_6.js";
import { C as LocalScanStatus, D as localGridZoom, G as eq, H as asc, Q as isNull, S as LocalPointStatus, T as isLocalScanActive, U as desc, W as and, X as inArray, ct as sql, t as db } from "./db-DhHkpZWI.js";
import { C as localRankBusinesses, D as localRankResults, E as localRankPoints, O as localRankScans, T as localRankKeywords, k as localRankTrackers, w as localRankChecks } from "./schema-Cn_vcAkd.js";
import { n as runBatch } from "./runBatch-CENJH-Sm.js";
import { t as createDataforseoClient } from "./client-D7Glrscv.js";
//#region src/server/features/local-seo/repositories/localKeywordQueries.ts
async function getKeywords(trackerId, includeArchived = false) {
	return db.select().from(localRankKeywords).where(and(eq(localRankKeywords.trackerId, trackerId), includeArchived ? void 0 : isNull(localRankKeywords.archivedAt))).orderBy(asc(localRankKeywords.keyword));
}
async function saveKeywords(trackerId, keywords, removedIds) {
	await runBatch((tx) => [...keywords.map((keyword) => tx.insert(localRankKeywords).values(keyword).onConflictDoUpdate({
		target: [localRankKeywords.trackerId, localRankKeywords.keyword],
		set: { archivedAt: null }
	})), ...removedIds.length ? [tx.update(localRankKeywords).set({ archivedAt: (/* @__PURE__ */ new Date()).toISOString() }).where(and(eq(localRankKeywords.trackerId, trackerId), inArray(localRankKeywords.id, removedIds)))] : []]);
}
//#endregion
//#region src/server/features/local-seo/repositories/LocalSeoRepository.ts
async function listTrackers(projectId) {
	return db.select().from(localRankTrackers).where(eq(localRankTrackers.projectId, projectId)).orderBy(desc(localRankTrackers.createdAt));
}
async function getTracker(projectId, trackerId) {
	return (await db.select().from(localRankTrackers).where(and(eq(localRankTrackers.projectId, projectId), eq(localRankTrackers.id, trackerId))).limit(1))[0] ?? null;
}
async function createTracker(tracker, keywords) {
	await runBatch((tx) => [tx.insert(localRankTrackers).values(tracker), ...keywords.map((keyword) => tx.insert(localRankKeywords).values(keyword))]);
}
async function listChecks(projectId, trackerId) {
	return db.select().from(localRankChecks).where(and(eq(localRankChecks.projectId, projectId), eq(localRankChecks.trackerId, trackerId))).orderBy(desc(localRankChecks.createdAt), desc(localRankChecks.id)).limit(14);
}
async function getCheck(projectId, checkId) {
	return (await db.select().from(localRankChecks).where(and(eq(localRankChecks.projectId, projectId), eq(localRankChecks.id, checkId))).limit(1))[0] ?? null;
}
async function getScansForCheck(projectId, checkId) {
	return db.select().from(localRankScans).where(and(eq(localRankScans.projectId, projectId), eq(localRankScans.checkId, checkId))).orderBy(asc(localRankScans.keywordId));
}
async function listScans(projectId, trackerId, checkIds) {
	if (!checkIds.length) return [];
	return db.select().from(localRankScans).where(and(eq(localRankScans.projectId, projectId), eq(localRankScans.trackerId, trackerId), inArray(localRankScans.checkId, checkIds))).orderBy(desc(localRankScans.createdAt), desc(localRankScans.id));
}
async function getScanSummaries(projectId, trackerId, checkIds) {
	if (!checkIds.length) return [];
	return db.select({
		scanId: localRankScans.id,
		total: sql`count(${localRankPoints.id})`.mapWith(Number),
		completed: sql`sum(case when ${localRankPoints.status} = 'completed' then 1 else 0 end)`.mapWith(Number),
		found: sql`sum(case when ${localRankPoints.status} = 'completed' and ${localRankPoints.rank} is not null then 1 else 0 end)`.mapWith(Number),
		top3: sql`sum(case when ${localRankPoints.status} = 'completed' and ${localRankPoints.rank} <= 3 then 1 else 0 end)`.mapWith(Number),
		rankTotal: sql`sum(case when ${localRankPoints.status} = 'completed' then coalesce(${localRankPoints.rank}, 0) else 0 end)`.mapWith(Number)
	}).from(localRankScans).leftJoin(localRankPoints, eq(localRankPoints.scanId, localRankScans.id)).where(and(eq(localRankScans.projectId, projectId), eq(localRankScans.trackerId, trackerId), inArray(localRankScans.checkId, checkIds))).groupBy(localRankScans.id);
}
async function getScan(projectId, scanId) {
	return (await db.select().from(localRankScans).where(and(eq(localRankScans.projectId, projectId), eq(localRankScans.id, scanId))).limit(1))[0] ?? null;
}
async function getActiveCheck(projectId, trackerId) {
	return (await db.select().from(localRankChecks).where(and(eq(localRankChecks.projectId, projectId), eq(localRankChecks.trackerId, trackerId), inArray(localRankChecks.status, [LocalScanStatus.Queued, LocalScanStatus.Running]))).limit(1))[0] ?? null;
}
async function createCheck(check, scans, points) {
	await runBatch((tx) => [
		tx.insert(localRankChecks).values(check),
		...scans.map((scan) => tx.insert(localRankScans).values(scan)),
		...points.map((point) => tx.insert(localRankPoints).values(point))
	]);
}
async function updateCheck(projectId, checkId, updates) {
	await db.update(localRankChecks).set(updates).where(and(eq(localRankChecks.projectId, projectId), eq(localRankChecks.id, checkId), inArray(localRankChecks.status, [LocalScanStatus.Queued, LocalScanStatus.Running])));
}
async function updateScan(projectId, scanId, updates) {
	await db.update(localRankScans).set(updates).where(and(eq(localRankScans.projectId, projectId), eq(localRankScans.id, scanId), inArray(localRankScans.status, [LocalScanStatus.Queued, LocalScanStatus.Running])));
}
async function getPoints(scanId) {
	return db.select().from(localRankPoints).where(eq(localRankPoints.scanId, scanId)).orderBy(asc(localRankPoints.row), asc(localRankPoints.col));
}
async function savePoint(point, businesses, rankings, rank, resultsCount) {
	await runBatch((tx) => [
		...businesses.map((business) => tx.insert(localRankBusinesses).values(business).onConflictDoNothing()),
		...rankings.map((result) => tx.insert(localRankResults).values({
			id: crypto.randomUUID(),
			pointId: point.id,
			...result
		})),
		tx.update(localRankPoints).set({
			status: LocalPointStatus.Completed,
			rank,
			resultsCount,
			error: null,
			collectedAt: (/* @__PURE__ */ new Date()).toISOString()
		}).where(eq(localRankPoints.id, point.id))
	]);
}
async function failPoint(pointId, error) {
	await db.update(localRankPoints).set({
		status: LocalPointStatus.Failed,
		error
	}).where(and(eq(localRankPoints.id, pointId), eq(localRankPoints.status, LocalPointStatus.Pending)));
}
async function failPendingPoints(scanId, error) {
	await db.update(localRankPoints).set({
		status: LocalPointStatus.Failed,
		error
	}).where(and(eq(localRankPoints.scanId, scanId), eq(localRankPoints.status, LocalPointStatus.Pending)));
}
async function getScanResults(projectId, scanId) {
	return db.select({
		pointId: localRankResults.pointId,
		id: localRankBusinesses.id,
		title: localRankBusinesses.title,
		cid: localRankBusinesses.cid,
		placeId: localRankBusinesses.placeId,
		address: localRankBusinesses.address,
		rating: localRankBusinesses.rating,
		reviews: localRankBusinesses.reviews,
		rank: localRankResults.rank
	}).from(localRankResults).innerJoin(localRankPoints, eq(localRankPoints.id, localRankResults.pointId)).innerJoin(localRankScans, eq(localRankScans.id, localRankPoints.scanId)).innerJoin(localRankBusinesses, eq(localRankBusinesses.id, localRankResults.businessId)).where(and(eq(localRankScans.projectId, projectId), eq(localRankScans.id, scanId))).orderBy(asc(localRankResults.rank));
}
var LocalSeoRepository = {
	listTrackers,
	getTracker,
	createTracker,
	getKeywords,
	saveKeywords,
	listChecks,
	getCheck,
	getScansForCheck,
	getScanSummaries,
	listScans,
	getScan,
	getActiveCheck,
	createCheck,
	updateCheck,
	updateScan,
	getPoints,
	savePoint,
	failPoint,
	failPendingPoints,
	getScanResults
};
//#endregion
//#region src/server/features/local-seo/services/localSeoCollection.ts
var resultSchema = object({
	title: string(),
	cid: string().nullish(),
	place_id: string().nullish(),
	address: string().nullish(),
	rank_absolute: number().int().positive().nullish(),
	rank_group: number().int().positive().nullish(),
	rating: object({
		value: number().nullish(),
		votes_count: number().int().nullish()
	}).nullish()
});
var SEARCH_FAILED = "The search provider could not complete this point.";
/** The live Maps search for one grid point. */
function localPointSearch(tracker, keyword, point) {
	const zoom = localGridZoom(tracker.spacingKm, tracker.latitude);
	return {
		keyword,
		locationCoordinate: `${point.latitude},${point.longitude},${zoom}z`,
		languageCode: tracker.languageCode,
		searchType: "maps",
		device: "mobile",
		depth: 20,
		searchPlaces: false
	};
}
async function prepareLocalCheck(projectId, checkId) {
	const check = await LocalSeoRepository.getCheck(projectId, checkId);
	if (!check || !isLocalScanActive(check.status)) throw new AppError("VALIDATION_ERROR", "This check is no longer available.");
	const [tracker, keywords, scans] = await Promise.all([
		LocalSeoRepository.getTracker(projectId, check.trackerId),
		LocalSeoRepository.getKeywords(check.trackerId, true),
		LocalSeoRepository.getScansForCheck(projectId, checkId)
	]);
	if (!tracker) throw new AppError("VALIDATION_ERROR", "The scan configuration is no longer available.");
	const plans = await Promise.all(scans.map(async (scan) => {
		const keyword = keywords.find((row) => row.id === scan.keywordId);
		if (!keyword) throw new AppError("VALIDATION_ERROR", "The scan configuration is no longer available.");
		await LocalSeoRepository.updateScan(projectId, scan.id, { status: LocalScanStatus.Running });
		return {
			scanId: scan.id,
			tracker,
			keyword: keyword.keyword,
			points: await LocalSeoRepository.getPoints(scan.id)
		};
	}));
	await LocalSeoRepository.updateCheck(projectId, checkId, { status: LocalScanStatus.Running });
	return plans;
}
/** Runs one paid live search per point and saves each point as it returns. */
async function searchLocalPoints(plan, points, customer) {
	const outcomes = await createDataforseoClient(customer).serp.localBatch(points.map((point) => localPointSearch(plan.tracker, plan.keyword, point)));
	await Promise.all(outcomes.map((outcome, index) => {
		const point = points[index];
		return (outcome.status === "fulfilled" ? savePointResults(plan.tracker, point, outcome.value) : Promise.reject(outcome.reason)).catch((error) => {
			console.warn(`[local-seo] point ${point.id} failed:`, error);
			return LocalSeoRepository.failPoint(point.id, SEARCH_FAILED);
		});
	}));
}
async function failLocalPoints(points) {
	await Promise.all(points.map((point) => LocalSeoRepository.failPoint(point.id, SEARCH_FAILED)));
}
async function savePointResults(tracker, point, items) {
	const parsedRows = items.map((item, index) => {
		const row = resultSchema.parse(item);
		const rank = row.rank_absolute ?? row.rank_group ?? index + 1;
		const identity = row.cid ? `cid:${row.cid}` : row.place_id ? `place:${row.place_id}` : `point:${point.id}:${rank}`;
		return {
			id: `${point.scanId}:${identity}`,
			scanId: point.scanId,
			identity,
			title: row.title,
			cid: row.cid ?? null,
			placeId: row.place_id ?? null,
			address: row.address ?? null,
			rating: row.rating?.value ?? null,
			reviews: row.rating?.votes_count ?? null,
			rank
		};
	});
	const rows = parsedRows.filter((row, index) => parsedRows.findIndex((other) => other.identity === row.identity) === index);
	const target = rows.find((row) => tracker.cid != null && row.cid === tracker.cid || tracker.placeId != null && row.placeId === tracker.placeId);
	await LocalSeoRepository.savePoint(point, rows, rows.map((row) => ({
		businessId: row.id,
		rank: row.rank
	})), target?.rank ?? null, items.length);
}
async function finalizeLocalScan(projectId, scanId, error) {
	await LocalSeoRepository.failPendingPoints(scanId, error ?? "This point did not finish in time. The search may still have used credits.");
	const points = await LocalSeoRepository.getPoints(scanId);
	const completed = points.filter((p) => p.status === LocalPointStatus.Completed).length;
	await LocalSeoRepository.updateScan(projectId, scanId, {
		status: completed === points.length && completed > 0 ? LocalScanStatus.Completed : completed > 0 ? LocalScanStatus.Partial : LocalScanStatus.Failed,
		error: error ?? null,
		completedAt: (/* @__PURE__ */ new Date()).toISOString()
	});
}
async function finalizeLocalCheck(projectId, checkId, error) {
	let scans = await LocalSeoRepository.getScansForCheck(projectId, checkId);
	for (const scan of scans) if (isLocalScanActive(scan.status)) await finalizeLocalScan(projectId, scan.id, error);
	scans = await LocalSeoRepository.getScansForCheck(projectId, checkId);
	const completed = scans.filter((scan) => scan.status === LocalScanStatus.Completed).length;
	const hasResults = scans.some((scan) => scan.status === LocalScanStatus.Completed || scan.status === LocalScanStatus.Partial);
	await LocalSeoRepository.updateCheck(projectId, checkId, {
		status: completed === scans.length && completed > 0 ? LocalScanStatus.Completed : hasResults ? LocalScanStatus.Partial : LocalScanStatus.Failed,
		completedAt: (/* @__PURE__ */ new Date()).toISOString(),
		error: error ?? null
	});
}
//#endregion
export { searchLocalPoints as a, prepareLocalCheck as i, finalizeLocalCheck as n, LocalSeoRepository as o, localPointSearch as r, failLocalPoints as t };
