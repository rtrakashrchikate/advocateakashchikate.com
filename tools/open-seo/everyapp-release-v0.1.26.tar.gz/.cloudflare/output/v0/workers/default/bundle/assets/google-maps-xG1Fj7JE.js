import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { i as localProjectSchema } from "./local-seo-DTqrCmsD.js";
import { t as googleMapsViewportSchema } from "./google-maps-C6u9XIt-.js";
import { t as GoogleMapsService } from "./GoogleMapsService-DYHI15fB.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/serverFunctions/google-maps.ts?tss-serverfn-split
var getLocalMapCopyright_createServerFn_handler = createServerRpc({
	id: "4f6705b014949bf8788050812f0e69f008b88223a27338b55f74fe6f900d69ca",
	name: "getLocalMapCopyright",
	filename: "src/serverFunctions/google-maps.ts"
}, (opts) => getLocalMapCopyright.__executeServer(opts));
var getLocalMapCopyright = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(localProjectSchema.extend({ viewport: googleMapsViewportSchema })).handler(getLocalMapCopyright_createServerFn_handler, ({ data }) => GoogleMapsService.getCopyright(data.viewport));
//#endregion
export { getLocalMapCopyright_createServerFn_handler };
