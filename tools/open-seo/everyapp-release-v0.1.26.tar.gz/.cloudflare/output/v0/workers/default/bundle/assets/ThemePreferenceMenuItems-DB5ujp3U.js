import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { n as createLucideIcon } from "./dist-fVOGIv0D.js";
import { t as Monitor } from "./monitor-CSd9Rf9l.js";
import { n as useThemePreference } from "./theme-VhxMSHKa.js";
import { a as DropdownMenuLabel, o as DropdownMenuRadioGroup, r as DropdownMenuGroup, s as DropdownMenuRadioItem } from "./dropdown-menu-DubRfxrI.js";
import { t as SegmentedToggle } from "./SegmentedToggle-TLo3swTI.js";
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Moon = createLucideIcon("moon", [["path", {
	d: "M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",
	key: "kfwtm"
}]]);
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Sun = createLucideIcon("sun", [
	["circle", {
		cx: "12",
		cy: "12",
		r: "4",
		key: "4exip2"
	}],
	["path", {
		d: "M12 2v2",
		key: "tus03m"
	}],
	["path", {
		d: "M12 20v2",
		key: "1lh1kg"
	}],
	["path", {
		d: "m4.93 4.93 1.41 1.41",
		key: "149t6j"
	}],
	["path", {
		d: "m17.66 17.66 1.41 1.41",
		key: "ptbguv"
	}],
	["path", {
		d: "M2 12h2",
		key: "1t8f8n"
	}],
	["path", {
		d: "M20 12h2",
		key: "1q8mjw"
	}],
	["path", {
		d: "m6.34 17.66-1.41 1.41",
		key: "1m8zz5"
	}],
	["path", {
		d: "m19.07 4.93-1.41 1.41",
		key: "1shlcs"
	}]
]);
//#endregion
//#region src/client/components/ThemePreferenceMenuItems.tsx
var import_jsx_runtime = require_jsx_runtime();
var THEME_OPTIONS = [
	{
		value: "system",
		label: "System",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Monitor, {})
	},
	{
		value: "light",
		label: "Light",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {})
	},
	{
		value: "dark",
		label: "Dark",
		icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {})
	}
];
/** System / Light / Dark segmented radio, shared by Settings and account menus. */
function ThemePreferenceRadio() {
	const { themePreference, setThemePreference } = useThemePreference();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SegmentedToggle, {
		items: THEME_OPTIONS,
		value: themePreference,
		onChange: setThemePreference
	});
}
function ThemePreferenceDropdownItems() {
	const { themePreference, setThemePreference } = useThemePreference();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuGroup, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "Theme" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuRadioGroup, {
		value: themePreference,
		onValueChange: (value) => {
			const option = THEME_OPTIONS.find((item) => item.value === value);
			if (option) setThemePreference(option.value);
		},
		children: THEME_OPTIONS.map(({ value, label, icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuRadioItem, {
			value,
			children: [
				icon,
				" ",
				label
			]
		}, value))
	})] });
}
//#endregion
export { ThemePreferenceRadio as n, ThemePreferenceDropdownItems as t };
