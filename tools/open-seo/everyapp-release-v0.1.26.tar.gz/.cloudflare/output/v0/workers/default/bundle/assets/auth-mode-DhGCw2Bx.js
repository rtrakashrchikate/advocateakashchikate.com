import { Et as _enum } from "./schemas-BPIpYT5n.js";
//#region src/lib/auth-mode.ts
var AUTH_MODES = [
	"cloudflare_access",
	"local_noauth",
	"hosted",
	"password",
	"everyapp"
];
var authModeSchema = _enum(AUTH_MODES);
var warnedInvalidAuthModes = /* @__PURE__ */ new Set();
function getAuthMode(value) {
	const parsed = authModeSchema.safeParse(value);
	if (parsed.success) return parsed.data;
	if (value && !warnedInvalidAuthModes.has(value)) {
		warnedInvalidAuthModes.add(value);
		console.error(`Invalid AUTH_MODE "${value}" \u2014 falling back to "cloudflare_access". Valid values: ${AUTH_MODES.join(", ")}.`);
	}
	return "cloudflare_access";
}
function isHostedAuthMode(value) {
	return getAuthMode(value) === "hosted";
}
function usesBetterAuth(value) {
	const mode = getAuthMode(value);
	return mode === "hosted" || mode === "password";
}
function setRuntimeAuthMode(value) {
	globalThis.__OPENSEO_AUTH_MODE__ = value;
}
function getClientAuthMode() {
	return getAuthMode(globalThis.__OPENSEO_AUTH_MODE__ ?? "everyapp");
}
function runtimeAuthModeScript() {
	return `globalThis.__OPENSEO_AUTH_MODE__=${JSON.stringify(getClientAuthMode())}`;
}
function isEveryAppAuthMode(value) {
	return getAuthMode(value) === "everyapp";
}
function isHostedClientAuthMode() {
	return getClientAuthMode() === "hosted";
}
function usesBetterAuthClient() {
	return usesBetterAuth(getClientAuthMode());
}
function isEveryAppClientAuthMode() {
	return isEveryAppAuthMode("everyapp");
}
function isEmailVerificationBypassed() {
	return getClientAuthMode() === "password";
}
//#endregion
export { isEveryAppAuthMode as a, isHostedClientAuthMode as c, usesBetterAuth as d, usesBetterAuthClient as f, isEmailVerificationBypassed as i, runtimeAuthModeScript as l, getAuthMode as n, isEveryAppClientAuthMode as o, getClientAuthMode as r, isHostedAuthMode as s, AUTH_MODES as t, setRuntimeAuthMode as u };
