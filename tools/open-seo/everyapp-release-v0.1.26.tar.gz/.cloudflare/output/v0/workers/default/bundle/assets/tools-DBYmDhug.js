import { yt as resolveEveryAppUserContext } from "./resolve-DrNDcpX6.js";
import { At as ToolError, Mt as toolResult, Ot as everyApp, W as asAppError, Z as serveEveryAppRequest, jt as defineTools } from "./onboarding-drip-B7bIbv_6.js";
import { wt as instrumentMcpToolHandler, yt as objectSchema } from "./explore-prompt-D91qsqeY.js";
import { n as registerOpenSeoTools } from "./server-Cbh-v0o-.js";
//#region src/server/everyapp/tools.ts
var INSTRUCTIONS = "OpenSEO's research tools call DataForSEO, which bills this organization's DataForSEO account per request through the gateway. Start with list_projects: most tools take a projectId. Ask before planned batches of more than a few hundred keywords or pages.";
/**
* Read or write, never destructive: the gateway hides destructive tools from
* AI clients until it has an approval step, and every OpenSEO tool should
* reach them, deletes included.
*/
function riskOf(tool) {
	return tool.config.annotations?.readOnlyHint ? "read" : "write";
}
function toolContext(user, request) {
	return resolveEveryAppUserContext(user).then((context) => ({ auth: {
		userId: context.userId,
		userEmail: context.userEmail,
		organizationId: context.organizationId,
		role: context.role,
		scopes: user.scopes,
		clientId: user.actor.sub,
		baseUrl: new URL(request.url).origin,
		clientLabel: "Every App"
	} }));
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function textOf(result) {
	return result.content.flatMap((part) => part.type === "text" ? [part.text] : []).join("\n\n");
}
function everyAppTool(tool) {
	const output = objectSchema(tool.config.outputSchema);
	const handler = instrumentMcpToolHandler(tool.name, output, tool.handler);
	return {
		title: tool.config.title,
		description: tool.config.description ?? tool.name,
		risk: riskOf(tool),
		idempotent: tool.config.annotations?.idempotentHint,
		openWorld: tool.config.annotations?.openWorldHint,
		input: objectSchema(tool.config.inputSchema),
		output,
		handler: async (args, { user, request }) => {
			let result;
			try {
				result = await serveEveryAppRequest(request, user, async () => {
					const context = await toolContext(user, request);
					return handler(args, context);
				});
			} catch (error) {
				const appError = asAppError(error);
				if (appError) throw new ToolError(appError.message);
				throw error;
			}
			const text = textOf(result);
			if (result.isError) throw new ToolError(text || "The tool failed.");
			const structured = result.structuredContent;
			return isRecord(structured) ? toolResult({
				text,
				structured
			}) : text;
		}
	};
}
function openSeoToolSet() {
	const tools = {};
	registerOpenSeoTools((tool) => {
		tools[tool.name] = everyAppTool(tool);
	});
	return defineTools(tools, { instructions: INSTRUCTIONS });
}
/**
* Answers the gateway's tools contract (`/__everyapp/tools/*`): the catalog
* at deploy, and each call. Loaded on the first tools request only, like the
* MCP stack in the other modes.
*/
var everyAppTools = everyApp(() => new Response("Not found", { status: 404 }), { tools: openSeoToolSet() });
//#endregion
export { everyAppTools };
