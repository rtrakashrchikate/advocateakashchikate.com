import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { t as createSsrRpc } from "./createSsrRpc-Vp3C13VD.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { c as researchKeywordsSchema, f as serpAnalysisSchema, i as keywordSuggestionsSchema, l as saveKeywordsSchema, m as updateSavedKeywordTagsSchema, n as exportSavedKeywordsSchema, o as refreshSavedKeywordMetricsSchema, p as updateSavedKeywordTagSchema, r as getSavedKeywordsSchema, s as removeSavedKeywordsSchema, t as deleteSavedKeywordTagSchema } from "./keywords-Bu6c9nGw.js";
//#region src/serverFunctions/keywords.ts
var researchKeywords = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(researchKeywordsSchema).handler(createSsrRpc("fa088bd63c78c66cb4de7e8be1d7567e0ec901107ad1afe33e0ffbeecc57bfbc"));
var saveKeywords = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(saveKeywordsSchema).handler(createSsrRpc("1d75d4deb3fcbaf04305fae69c64722313c46f5620de0ece3b950cff9346e099"));
var getSavedKeywords = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(getSavedKeywordsSchema).handler(createSsrRpc("8acb99c0e5b1aed5cfb75318e78747749f8c2c54884ba18ff1c945a9b06a9375"));
var exportSavedKeywords = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(exportSavedKeywordsSchema).handler(createSsrRpc("0146a46bbe4471991fcb6663852023dad568931c1314b55cc81892ca37f08e45"));
var updateSavedKeywordTags = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(updateSavedKeywordTagsSchema).handler(createSsrRpc("0f196e5eafbe1adb2d3f31aa7558728e7648574a837571aa8f8f35b94a56d562"));
var updateSavedKeywordTag = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(updateSavedKeywordTagSchema).handler(createSsrRpc("3b7a7d39821bb858a8e568dde7f4b7c984fdcbb1b94e2a1b26d91fdf25ff537f"));
var deleteSavedKeywordTag = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(deleteSavedKeywordTagSchema).handler(createSsrRpc("9ce7a2858b82783ef908f4396d61f4645b09ab4cbc435936a1495f8c23bcdb8d"));
var removeSavedKeywords = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(removeSavedKeywordsSchema).handler(createSsrRpc("1e8f375975f9b25f935c01e1ed6d63147b5a7fe8693c2737dcc1869d8ef97f3b"));
var refreshSavedKeywordMetrics = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(refreshSavedKeywordMetricsSchema).handler(createSsrRpc("0a0791b200d03eb44d9630e461ef914d1da85bde9c95b201dcbeb94624848971"));
var getSerpAnalysis = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(serpAnalysisSchema).handler(createSsrRpc("a19f7c4228fdbf301aeba791a8732ae65a0018a25d353bdeed6343876396dd0d"));
/** Searches worth running for the project: free, from saved topics and Search Console. */
var getKeywordSuggestions = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(keywordSuggestionsSchema).handler(createSsrRpc("12b03b0354d04a43cf3d4486f81adc1c666876494f6a4e20f07319a5be99d439"));
/** Paid: researches the website once to save topics for a project without any. */
var generateKeywordSuggestions = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(keywordSuggestionsSchema).handler(createSsrRpc("1cf1ffd3fa2ffbc031436db9db23646c4a3293cd193dd589ac8d747db58c3379"));
//#endregion
export { getSavedKeywords as a, removeSavedKeywords as c, updateSavedKeywordTag as d, updateSavedKeywordTags as f, getKeywordSuggestions as i, researchKeywords as l, exportSavedKeywords as n, getSerpAnalysis as o, generateKeywordSuggestions as r, refreshSavedKeywordMetrics as s, deleteSavedKeywordTag as t, saveKeywords as u };
