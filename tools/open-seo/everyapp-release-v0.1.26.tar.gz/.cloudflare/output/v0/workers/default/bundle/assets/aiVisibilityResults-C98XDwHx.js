import { Fn as object, Jn as string, Nt as array, sr as unknown, xn as literal } from "./schemas-BPIpYT5n.js";
import { t as t$1 } from "./purry-DMI_Uzu-.js";
import { t as t$2 } from "./sort-CLx_CHCb.js";
import { n as safeHttpUrl } from "./safe-url-B9MOXbhl.js";
import { n as parse } from "./es6-v60hw-Cv.js";
import { o as aiBrandLabel, p as isDefaultProjectName } from "./ai-visibility-b7Nyzqt-.js";
import { t as AiVisibilityRepository } from "./AiVisibilityRepository-BleS-LTq.js";
import { n as AiVisibilityError, r as publicAiAnswerError } from "./aiVisibilityErrors-CNlymTjF.js";
import { n as summarizeAiBrands, t as aiAnswerCoverage } from "./ai-visibility-results-sHsnuF4h.js";
//#region node_modules/.pnpm/remeda@2.33.6/node_modules/remeda/dist/groupByProp.js
function t(...t) {
	return t$1(n, t);
}
function n(e, t) {
	let n = Object.create(null);
	for (let r of e) {
		let e = r?.[t];
		if (e !== void 0) {
			let t = n[e];
			t === void 0 ? n[e] = [r] : t.push(r);
		}
	}
	return Object.setPrototypeOf(n, Object.prototype), n;
}
//#endregion
//#region src/server/features/ai-visibility/providers/dataforseoEvidence.ts
var optionalMarkdown = string().max(1e6).nullish();
var sourceList = array(unknown()).max(2e3).nullish();
var resultSchema = object({
	datetime: string().max(100).nullish(),
	markdown: optionalMarkdown,
	sources: sourceList,
	items: array(unknown()).max(500).nullish()
});
var aiOverviewSchema = object({
	type: literal("ai_overview"),
	markdown: optionalMarkdown,
	references: sourceList,
	items: array(object({ references: sourceList })).max(500).nullish()
});
var sourceSchema = object({
	url: string().max(16384),
	title: string().max(1e4).transform(withoutNul).nullish()
});
/**
* Normalize one DataForSEO task result. No URL fetches or model calls: all
* evidence comes from the captured result. Returns null for an unreadable
* result.
*/
function parseDataforseoAnswer(raw, engine) {
	if (raw === null) return {
		answerMarkdown: null,
		answerText: "",
		citations: [],
		collectedAt: null
	};
	const parsed = resultSchema.safeParse(raw);
	if (!parsed.success) return null;
	const result = parsed.data;
	let markdown;
	let sources;
	if (engine === "google_ai_overview") {
		const overview = result.items?.map((item) => aiOverviewSchema.safeParse(item)).find((item) => item.success)?.data;
		markdown = overview?.markdown ?? null;
		sources = [...overview?.references ?? [], ...(overview?.items ?? []).flatMap((item) => item.references ?? [])];
	} else {
		markdown = result.markdown ?? null;
		sources = result.sources ?? [];
	}
	if (markdown) markdown = withoutNul(markdown);
	const answerText = markdown ? markdownToText(markdown) : "";
	return {
		answerMarkdown: answerText.trim() ? markdown : null,
		answerText: answerText.trim() ? answerText : "",
		citations: citationsFrom(sources),
		collectedAt: dateOrNull(result.datetime)
	};
}
/**
* Normalize one live LLM Responses answer. The message sections hold the
* answer, and their annotations hold the cited pages.
*/
function parseLlmResponseAnswer(result) {
	const sections = (result.items ?? []).filter((item) => item.type === "message").flatMap((item) => item.sections ?? []);
	const markdown = withoutNul(sections.map((section) => section.text ?? "").filter(Boolean).join("\n\n"));
	const answerText = markdownToText(markdown);
	return {
		answerMarkdown: answerText.trim() ? markdown : null,
		answerText: answerText.trim() ? answerText : "",
		citations: citationsFrom(sections.flatMap((section) => section.annotations ?? [])),
		collectedAt: null
	};
}
/** Postgres text columns reject NUL, which scraped answers and titles can carry. */
function withoutNul(text) {
	return text.replaceAll("\0", "");
}
function dateOrNull(value) {
	if (!value) return null;
	const date = new Date(value);
	return Number.isNaN(date.valueOf()) ? null : date.toISOString();
}
/**
* Plain answer prose for brand matching. Citation pills (`[1]`, `[example.com]`)
* are evidence of a source, not a textual mention, so they are removed.
*/
function markdownToText(markdown) {
	return markdown.replace(/!\[[^\]]*\]\([^)\s]*\)/g, "").replace(/\[((?:[^[\]]|\[[^\]]*\])*)\]\((https?:\/\/[^)\s]+)\)/g, (_, label, url) => citationPill(label, url) ? "" : label).replace(/\*\*|__|`/g, "").replace(/^#{1,6}\s+/gm, "").replace(/^(\s*)[*+-]\s+/gm, "$1");
}
function citationPill(label, url) {
	const text = label.replace(/^\[|\]$/g, "").trim().toLowerCase();
	if (/^\d+$/.test(text)) return true;
	try {
		const host = new URL(url).hostname.toLowerCase();
		return text.replace(/^www\./, "") === host.replace(/^www\./, "");
	} catch {
		return false;
	}
}
/** Safe, de-duplicated cited URLs with tracking parameters removed. */
function citationsFrom(list) {
	const citations = /* @__PURE__ */ new Map();
	for (const item of list) {
		const source = sourceSchema.safeParse(item);
		const safe = source.success ? safeHttpUrl(source.data.url) : null;
		if (!source.success || !safe) continue;
		const url = new URL(safe);
		url.hash = "";
		for (const key of Array.from(url.searchParams.keys())) if (/^utm_/i.test(key) || [
			"gclid",
			"fbclid",
			"msclkid"
		].includes(key.toLowerCase())) url.searchParams.delete(key);
		const normalized = url.toString();
		const existing = citations.get(normalized);
		if (existing) {
			existing.title ??= source.data.title ?? null;
			continue;
		}
		citations.set(normalized, {
			url: normalized,
			domain: url.hostname,
			title: source.data.title ?? null,
			position: citations.size + 1
		});
	}
	return [...citations.values()];
}
//#endregion
//#region src/server/features/ai-visibility/services/aiVisibilityMatching.ts
function ownedAiDomain(hostname, owned) {
	const host = hostname.toLowerCase().replace(/^www\./, "");
	const domain = owned.toLowerCase().replace(/^www\./, "");
	return !!domain && (host === domain || host.endsWith(`.${domain}`));
}
function aiMentionSpans(text, names) {
	const prose = text.replace(/(?:https?:\/\/|www\.)[^\s<>]+|[\p{L}\p{N}._%+-]+@[\p{L}\p{N}.-]+\.[\p{L}]{2,}/giu, (value) => " ".repeat(value.length));
	let normalized = "";
	const starts = [], ends = [];
	let offset = 0;
	for (const character of prose) {
		const decomposed = character.normalize("NFD");
		normalized += decomposed;
		for (let i = 0; i < decomposed.length; i++) {
			starts.push(offset);
			ends.push(offset + character.length);
		}
		offset += character.length;
	}
	const found = /* @__PURE__ */ new Map();
	for (const name of new Set(names.map((n) => n.trim()).filter((n) => n.length >= 2))) {
		const escaped = name.normalize("NFD").replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/\s+/g, "\\s+");
		const pattern = new RegExp(`(?<![\\p{L}\\p{M}\\p{N}_])${escaped}(?![\\p{L}\\p{M}\\p{N}_])`, "giu");
		for (const match of normalized.matchAll(pattern)) {
			const start = starts[match.index], end = ends[match.index + match[0].length - 1];
			found.set(`${start}:${end}`, {
				start,
				end
			});
		}
	}
	return t$2([...found.values()], (a, b) => a.start - b.start || b.end - a.end).filter((span, i, all) => !all.slice(0, i).some((other) => other.start <= span.start && other.end >= span.end));
}
/** "www.acme.com" \u2192 "acme"; subdomains and non-domains \u2192 null. */
function rootDomainName(value) {
	const { hostname, domain, domainWithoutSuffix } = parse(value);
	return hostname?.replace(/^www\./, "") === domain ? domainWithoutSuffix : null;
}
/** Answer text naming the brand. A brand named "acme.com" is written "Acme". */
function aiBrandNames(brand) {
	const name = aiBrandLabel(brand);
	const stem = rootDomainName(name);
	return stem && stem === rootDomainName(brand.domain) ? [
		name,
		brand.domain,
		stem
	] : [name, brand.domain];
}
/**
* A brand is mentioned when its name or domain appears in the answer prose,
* and cited when the answer cites a page on its domain. A generic brand name
* can count as a mention of something else; that is accepted for simplicity.
*/
function matchAiBrand(answer, brand) {
	const spans = aiMentionSpans(answer.answerText, aiBrandNames(brand));
	return {
		mentioned: spans.length > 0,
		cited: answer.citations.some((citation) => ownedAiDomain(citation.domain, brand.domain)),
		firstMention: spans[0]?.start ?? null
	};
}
/** The project's own brand. Prompt cohorts must include diagnostics that name it only by URL. */
function aiPromptIsBranded(prompt, brand) {
	if (!isDefaultProjectName(brand.name) && aiMentionSpans(prompt, [brand.name]).length) return true;
	const domain = brand.domain.replace(/^www\./i, "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
	return !!domain && new RegExp(`(?<![\\p{L}\\p{M}\\p{N}_-])${domain}(?![\\p{L}\\p{M}\\p{N}_.-])`, "iu").test(prompt);
}
//#endregion
//#region src/server/features/ai-visibility/services/aiVisibilityResults.ts
function aiRunView(run, observations) {
	const completed = observations.filter((o) => o.status === "completed").length;
	const failed = observations.filter((o) => o.status === "failed").length;
	return {
		id: run.id,
		status: run.status,
		trigger: run.trigger,
		expected: observations.length,
		completed,
		failed,
		pending: observations.length - completed - failed,
		createdAt: run.createdAt,
		completedAt: run.completedAt,
		pollAfterSeconds: run.trigger === "scheduled" ? 20 : 5
	};
}
function rowsFor(observations, evidence) {
	const sources = t(evidence.sources, "observationId");
	const matches = t(evidence.matches, "observationId");
	return observations.map((o) => ({
		id: o.id,
		runId: o.runId,
		promptId: o.promptId,
		prompt: o.prompt,
		topic: o.topic,
		branded: o.branded,
		engine: o.engine,
		status: o.status,
		answerStatus: o.status !== "completed" ? null : o.answerMarkdown ? "answered" : "no_answer",
		collectedAt: o.collectedAt,
		error: publicAiAnswerError(o.error),
		citationCount: sources[o.id]?.length ?? 0,
		brands: (matches[o.id] ?? []).map((m) => ({
			name: m.name || m.domain,
			domain: m.domain,
			own: m.own,
			mentioned: m.mentioned,
			cited: m.cited,
			firstMention: m.firstMention
		}))
	}));
}
async function loadAiResultSet(rawInput) {
	const input = {
		...rawInput,
		runId: rawInput.runId ?? void 0,
		topic: rawInput.topic ?? void 0,
		engines: rawInput.engines ?? void 0,
		promptId: rawInput.promptId ?? void 0
	};
	if (input.includeHistory && !input.promptId) throw new AiVisibilityError("PROMPT_REQUIRED", "Provide promptId when requesting answer history.");
	const runs = await AiVisibilityRepository.listRuns(input.projectId, input.includeHistory ? 50 : 20);
	let run = input.runId ? await AiVisibilityRepository.getRun(input.projectId, input.runId) : await AiVisibilityRepository.getLatestScheduledRun(input.projectId);
	if (input.runId && !run) throw new AiVisibilityError("RUN_NOT_FOUND", "This run is not available in the selected project.");
	if (input.includeHistory && !input.runId) run = runs[0] ?? null;
	const runIds = input.includeHistory && !input.runId ? runs.map((r) => r.id) : run ? [run.id] : [];
	const observations = await AiVisibilityRepository.getObservations(runIds, input.promptId);
	const scoped = observations.filter((o) => (!input.topic || o.topic === input.topic) && (!input.engines || input.engines.includes(o.engine)) && (input.branded === "all" || (input.branded === "branded" ? o.branded : !o.branded)));
	const evidence = await AiVisibilityRepository.getEvidence(scoped.map((o) => o.id));
	const rows = rowsFor(scoped, evidence);
	const filtered = input.competitorGap ? rows.filter((row) => {
		const own = row.brands.find((b) => b.own);
		return !!own && !own.mentioned && !own.cited && row.brands.some((b) => !b.own && (b.mentioned || b.cited));
	}) : rows;
	return {
		result: {
			runId: run?.id ?? null,
			run: run ? aiRunView(run, observations.filter((o) => o.runId === run.id)) : null,
			rows: filtered,
			totalCount: filtered.length,
			summaries: summarizeAiBrands(filtered),
			coverage: aiAnswerCoverage(rows),
			appliedFilters: {
				topic: input.topic,
				engines: input.engines,
				competitorGap: input.competitorGap,
				branded: input.branded
			},
			truncated: input.includeHistory && runs.length === 50
		},
		runs,
		run,
		observations: scoped,
		evidence
	};
}
function resultPage(result, input) {
	const offset = Number(input.cursor ?? 0);
	return {
		...result,
		rows: result.rows.slice(offset, offset + input.limit),
		nextCursor: offset + input.limit < result.totalCount ? String(offset + input.limit) : null
	};
}
async function loadAiResults(input) {
	const { result } = await loadAiResultSet(input);
	return resultPage(result, input);
}
/**
* App reads: up to limit rows of the bounded set in one call, with history
* metadata. The MCP results contract remains paged.
*/
async function loadAiPageResults(input) {
	const { result, runs } = await loadAiResultSet(input);
	return {
		...result,
		rows: result.rows.slice(0, input.limit),
		historyRuns: input.includeHistory ? runs.map(({ id, createdAt, trigger }) => ({
			id,
			createdAt,
			trigger
		})) : []
	};
}
var ANSWER_LIMIT = 24e3;
async function loadAiAnswer(input, { full = false } = {}) {
	const observation = await AiVisibilityRepository.getObservation(input.observationId);
	const run = observation ? await AiVisibilityRepository.getRun(input.projectId, observation.runId) : null;
	if (!observation || !run) throw new AiVisibilityError("ANSWER_NOT_FOUND", "This answer is not available in the selected project.");
	return answerView(observation, run, await AiVisibilityRepository.getEvidence([observation.id]), full);
}
/** Every answer of one run in full, from a single result-set read. */
async function loadAiFullAnswers(input) {
	const { result, run, observations, evidence } = await loadAiResultSet(input);
	const sources = t(evidence.sources, "observationId");
	const matches = t(evidence.matches, "observationId");
	const rowIds = new Set(result.rows.map((row) => row.id));
	return {
		result,
		answers: run ? observations.filter((observation) => rowIds.has(observation.id)).map((observation) => answerView(observation, run, {
			sources: sources[observation.id] ?? [],
			matches: matches[observation.id] ?? []
		}, true)) : []
	};
}
function answerView(observation, run, evidence, full) {
	const row = rowsFor([observation], evidence)[0];
	const markdown = observation.answerMarkdown;
	const answerText = markdown ? markdownToText(markdown) : null;
	const limit = full ? Infinity : ANSWER_LIMIT;
	return {
		observation: row,
		answerText: answerText?.slice(0, limit) ?? null,
		answerMarkdown: markdown?.slice(0, limit) ?? null,
		sources: evidence.sources.map(({ url, domain, title, position }) => ({
			url,
			domain,
			title,
			position
		})),
		mentions: answerText ? row.brands.filter((b) => b.mentioned).map((b) => ({
			domain: b.domain,
			spans: aiMentionSpans(answerText, aiBrandNames(b)).filter((span) => span.end <= limit)
		})) : [],
		requestedLocationCode: run.locationCode,
		requestedLanguageCode: run.languageCode,
		truncated: (markdown?.length ?? 0) > limit
	};
}
async function loadAiSources(input) {
	const { result: first, evidence } = await loadAiResultSet(input);
	const groups = /* @__PURE__ */ new Map();
	const observed = new Map(first.rows.map((r) => [r.id, r]));
	for (const source of evidence.sources) {
		const answer = observed.get(source.observationId);
		if (answer?.answerStatus !== "answered") continue;
		const own = answer.brands.find((b) => b.own);
		const ownership = own && ownedAiDomain(source.domain, own.domain) ? "own" : answer.brands.some((b) => !b.own && ownedAiDomain(source.domain, b.domain)) ? "competitor" : "other";
		if (input.ownership !== "all" && input.ownership !== ownership) continue;
		const key = input.groupBy === "domain" ? source.domain : source.url;
		const group = groups.get(key) ?? {
			row: {
				key,
				url: input.groupBy === "url" ? source.url : null,
				domain: source.domain,
				title: input.groupBy === "url" ? source.title : null,
				ownership,
				answerCount: 0,
				promptCount: 0,
				promptIds: [],
				engines: [],
				observationIds: [],
				truncated: false
			},
			answers: /* @__PURE__ */ new Set(),
			prompts: /* @__PURE__ */ new Set(),
			engines: /* @__PURE__ */ new Map()
		};
		group.answers.add(answer.id);
		group.prompts.add(answer.promptId);
		const engineAnswers = group.engines.get(answer.engine) ?? /* @__PURE__ */ new Set();
		engineAnswers.add(answer.id);
		group.engines.set(answer.engine, engineAnswers);
		groups.set(key, group);
	}
	const rows = t$2([...groups.values()].map((g) => ({
		...g.row,
		answerCount: g.answers.size,
		promptCount: g.prompts.size,
		promptIds: [...g.prompts],
		engines: [...g.engines].map(([engine, answers]) => ({
			engine,
			answerCount: answers.size
		})),
		observationIds: [...g.answers].slice(0, 20),
		truncated: g.answers.size > 20
	})), (a, b) => b.answerCount - a.answerCount || a.key.localeCompare(b.key));
	const offset = Number(input.cursor ?? 0);
	return {
		runId: first.runId,
		rows: rows.slice(offset, offset + input.limit),
		totalCount: rows.length,
		nextCursor: offset + input.limit < rows.length ? String(offset + input.limit) : null,
		coverage: first.coverage,
		appliedFilters: {
			...first.appliedFilters,
			ownership: input.ownership
		},
		groupBy: input.groupBy,
		truncated: first.truncated
	};
}
//#endregion
export { loadAiResults as a, matchAiBrand as c, parseLlmResponseAnswer as d, t as f, loadAiPageResults as i, ownedAiDomain as l, loadAiAnswer as n, loadAiSources as o, loadAiFullAnswers as r, aiPromptIsBranded as s, aiRunView as t, parseDataforseoAnswer as u };
