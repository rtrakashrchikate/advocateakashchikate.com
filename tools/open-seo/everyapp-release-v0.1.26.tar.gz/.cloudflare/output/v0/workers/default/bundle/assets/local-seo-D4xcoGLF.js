import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { n as Outlet } from "./Match-Djim5BGq.js";
import { t as useParams } from "./useParams-4qBmna-E.js";
import { n as BackLink, r as PageHeader } from "./PageHeader-a3_4WaC8.js";
//#region src/routes/_app/p/$projectId/local-seo.tsx?tsr-split=component
var import_jsx_runtime = require_jsx_runtime();
function LocalSeoLayout() {
	const { projectId, trackerId } = useParams({ strict: false });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 py-4 pb-24 overflow-auto md:px-6 md:py-6 md:pb-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				title: "Local SEO",
				description: "Track Google Maps rankings across your local area",
				backLink: projectId && trackerId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {
					to: "/p/$projectId/local-seo",
					params: { projectId },
					children: "Tracked businesses"
				}) : void 0
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})]
		})
	});
}
//#endregion
export { LocalSeoLayout as component };
