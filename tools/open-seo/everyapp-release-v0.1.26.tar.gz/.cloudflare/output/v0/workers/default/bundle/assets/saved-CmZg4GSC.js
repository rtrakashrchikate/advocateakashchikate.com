import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { t as stripSearchParams } from "./searchMiddleware-B9nj7dL4.js";
import { t as pageHead } from "./pageHead-BfhwMlwa.js";
import { d as savedKeywordsSearchSchema } from "./keywords-Bu6c9nGw.js";
//#region src/routes/_app/p/$projectId/saved.tsx
var $$splitComponentImporter = () => import("./saved-CAD1qb6T.js");
var Route = createFileRoute("/_app/p/$projectId/saved")({
	head: () => pageHead("Saved Keywords"),
	validateSearch: savedKeywordsSearchSchema,
	remountDeps: ({ params }) => params.projectId,
	search: { middlewares: [stripSearchParams({
		sort: "fetchedAt",
		order: "desc",
		page: 1,
		size: 50
	})] },
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
