import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
//#region src/client/components/table/ScoreBadge.tsx
var import_jsx_runtime = require_jsx_runtime();
function scoreTierClass(value) {
	if (value == null) return "score-tier-na";
	if (value <= 20) return "score-tier-1";
	if (value <= 35) return "score-tier-2";
	if (value <= 50) return "score-tier-3";
	if (value <= 65) return "score-tier-4";
	if (value <= 80) return "score-tier-5";
	return "score-tier-6";
}
/** Keyword difficulty (0-100) as a tier-colored badge. */
function ScoreBadge({ value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `score-badge ${scoreTierClass(value)} inline-flex size-6 items-center justify-center rounded-full text-[10px] font-semibold tabular-nums`,
		children: value ?? "-"
	});
}
//#endregion
export { ScoreBadge as t };
