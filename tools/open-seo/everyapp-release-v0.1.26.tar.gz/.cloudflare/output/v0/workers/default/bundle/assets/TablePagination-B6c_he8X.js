import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as ChevronLeft } from "./chevron-left-C2BycBKd.js";
import { t as ChevronRight } from "./chevron-right-CMQSolKd.js";
import { r as Spinner, t as Button } from "./button-DrcZrdio.js";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-KTe7DEy8.js";
//#region src/client/components/table/TablePagination.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function TablePagination({ page, pageSize, pageSizes, totalCount, hasNextPage = false, isLoading = false, pageRange, loadMoreLabel, onPageChange, onPageSizeChange, renderPageButton = PageButton }) {
	const totalPages = pageRange?.pageCount ?? (totalCount != null ? Math.max(1, Math.ceil(totalCount / pageSize)) : null);
	const isOutOfRange = totalPages != null && page > totalPages;
	const currentPage = isOutOfRange ? totalPages : page;
	const isLastPage = totalPages != null && currentPage >= totalPages;
	const canGoPrev = currentPage > 1;
	const canGoNext = totalPages != null ? !isLastPage : hasNextPage;
	(0, import_react.useEffect)(() => {
		if (isOutOfRange && !isLoading) onPageChange(currentPage);
	}, [
		currentPage,
		isLoading,
		isOutOfRange,
		onPageChange
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 border-t border-border px-4 py-3 sm:flex-row sm:items-center sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 text-sm text-muted-foreground tabular-nums",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "whitespace-nowrap",
				children: formatRange(currentPage, pageSize, totalCount, pageRange)
			}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, { className: "size-3.5" }) : null]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-x-6 gap-y-2",
			children: [pageSizes && onPageSizeChange ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 text-sm text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "whitespace-nowrap",
					children: "Rows per page"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: pageSize,
					onValueChange: (value) => {
						const size = pageSizes.find((option) => option === value);
						if (size != null) onPageSizeChange(size);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
						size: "sm",
						className: "w-20",
						"aria-label": "Rows per page",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: pageSizes.map((size) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
						value: size,
						children: size
					}, size)) })]
				})]
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "whitespace-nowrap text-sm tabular-nums text-muted-foreground",
					children: [
						"Page ",
						currentPage.toLocaleString(),
						totalPages != null ? ` of ${totalPages.toLocaleString()}` : ""
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [renderPageButton({
						page: currentPage - 1,
						disabled: !canGoPrev || isLoading,
						label: "Previous page",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {}),
						onPageChange
					}), isLastPage && loadMoreLabel != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						disabled: isLoading,
						onClick: () => onPageChange(currentPage + 1),
						children: [loadMoreLabel, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { "data-icon": "inline-end" })]
					}) : renderPageButton({
						page: currentPage + 1,
						disabled: !canGoNext || isLoading,
						label: "Next page",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, {}),
						onPageChange
					})]
				})]
			})]
		})]
	});
}
function PageButton({ page, disabled, label, children, onPageChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "ghost",
		size: "icon-sm",
		"aria-label": label,
		disabled,
		onClick: () => onPageChange(page),
		children
	});
}
function formatRange(page, pageSize, totalCount, pageRange) {
	if (totalCount === 0) return "0";
	const start = pageRange?.start ?? (page - 1) * pageSize + 1;
	const pageEnd = pageRange?.end ?? start + pageSize - 1;
	if (totalCount == null) return `${start.toLocaleString()}\u2013${pageEnd.toLocaleString()}`;
	const end = Math.min(totalCount, pageEnd);
	return `${start.toLocaleString()}\u2013${end.toLocaleString()} of ${totalCount.toLocaleString()}`;
}
//#endregion
export { TablePagination as t };
