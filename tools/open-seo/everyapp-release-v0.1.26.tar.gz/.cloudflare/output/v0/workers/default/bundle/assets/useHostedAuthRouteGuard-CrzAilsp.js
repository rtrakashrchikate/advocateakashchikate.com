import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { c as isHostedClientAuthMode, f as usesBetterAuthClient, i as isEmailVerificationBypassed } from "./auth-mode-DhGCw2Bx.js";
import { c as getVerifyEmailSearch, r as getCurrentAuthRedirectFromHref, s as getSignInSearch } from "./auth-redirect-Dnh6pyWf.js";
import { r as useSession } from "./auth-client-DstRenkx.js";
//#region src/client/features/auth/useHostedAuthRouteGuard.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function useHostedAuthRouteGuard() {
	const navigate = useNavigate();
	const { data: session, isPending } = useSession();
	const isHostedMode = isHostedClientAuthMode();
	const hasAccounts = usesBetterAuthClient();
	const emailVerified = session?.user?.emailVerified === true || isEmailVerificationBypassed();
	(0, import_react.useEffect)(() => {
		if (isPending || !hasAccounts) return;
		const redirectTo = getCurrentAuthRedirectFromHref(window.location.href);
		if (!session?.user?.id) {
			navigate({
				to: "/sign-in",
				search: getSignInSearch(redirectTo),
				replace: true
			});
			return;
		}
		if (!emailVerified) navigate({
			to: "/verify-email",
			search: getVerifyEmailSearch(session.user.email, redirectTo),
			replace: true
		});
	}, [
		isPending,
		hasAccounts,
		emailVerified,
		session?.user?.email,
		session?.user?.id,
		navigate
	]);
	const hasVerifiedSession = !isPending && Boolean(session?.user?.id) && emailVerified;
	return {
		isHostedMode,
		canRenderAuthenticatedContent: !hasAccounts || hasVerifiedSession
	};
}
//#endregion
export { useHostedAuthRouteGuard as t };
