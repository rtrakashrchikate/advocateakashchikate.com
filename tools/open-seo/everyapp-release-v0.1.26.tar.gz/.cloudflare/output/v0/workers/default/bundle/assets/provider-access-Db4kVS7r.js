import { Ct as integrationFetch, Nt as ConfigurationError, U as AppError, Y as gatewayCallFor, wt as integrationStatus } from "./onboarding-drip-B7bIbv_6.js";
import { a as isEveryAppAuthMode } from "./auth-mode-DhGCw2Bx.js";
import { i as getWorkersEnv, n as getOptionalEnvValue, r as getRequiredEnvValue } from "./runtime-env-eoXh4Ywz.js";
//#region src/shared/gateway-setup-messages.ts
/**
* What OpenSEO says when the Every App gateway holds no DataForSEO key: the
* server's refusal (which a rank check stores and the MCP tools answer with)
* and the setup dialog read this one sentence. The client's
* DATAFORSEO_AUTH_FAILED copy adds "or rejected the key it holds", because
* that code also covers DataForSEO's own 401. Plain text: ErrorState, toasts
* and tool answers render it as is, so no backticks.
*/
var DATAFORSEO_NOT_SET_UP_MESSAGE = "DataForSEO isn't set up on your Every App gateway yet. An owner or admin sets it with pnpm everyapp secret set DATAFORSEO_API_KEY.";
//#endregion
//#region src/server/lib/provider-access.ts
async function isBehindEveryAppGateway() {
	return isEveryAppAuthMode(await getOptionalEnvValue("AUTH_MODE"));
}
async function gatewayEnv() {
	return await getWorkersEnv() ?? {};
}
function withAuthorization(authorization) {
	return (input, init) => {
		const headers = new Headers(init?.headers);
		headers.set("Authorization", authorization);
		return fetch(input, {
			...init,
			headers
		});
	};
}
/**
* The gateway's fetch for a capability, or null without its binding. Whose
* call it is: gateway-attribution.ts.
*/
async function gatewayFetch(provider) {
	const env = await gatewayEnv();
	try {
		return integrationFetch({
			env,
			provider,
			for: gatewayCallFor()
		});
	} catch (error) {
		if (error instanceof ConfigurationError) return null;
		throw error;
	}
}
/** A fetch that reaches DataForSEO authenticated, for this deployment. */
async function getDataforseoFetch() {
	if (await isBehindEveryAppGateway()) {
		const providerFetch = await gatewayFetch("dataforseo");
		if (!providerFetch) {
			console.warn("[openseo] no DataForSEO key: set DATAFORSEO_API_KEY in .dev.vars for local development");
			throw new AppError("DATAFORSEO_AUTH_FAILED", DATAFORSEO_NOT_SET_UP_MESSAGE);
		}
		return providerFetch;
	}
	return withAuthorization(`Basic ${await getRequiredEnvValue("DATAFORSEO_API_KEY")}`);
}
/** A fetch that reaches Context.dev authenticated, or null without a key. */
async function getContextFetch() {
	if (await isBehindEveryAppGateway()) return gatewayFetch("context");
	const apiKey = await getOptionalEnvValue("CONTEXT_API_KEY");
	return apiKey ? withAuthorization(`Bearer ${apiKey}`) : null;
}
var KEY_ENV = {
	dataforseo: "DATAFORSEO_API_KEY",
	context: "CONTEXT_API_KEY"
};
/**
* Whether calls to the provider would go through, without making one. The
* gateway answers this for no organization in particular, so it needs none.
*/
async function hasProviderAccess(provider) {
	if (await isBehindEveryAppGateway()) return (await integrationStatus({
		env: await gatewayEnv(),
		provider
	})).ready;
	return Boolean(await getOptionalEnvValue(KEY_ENV[provider]));
}
function hasDataforseoAccess() {
	return hasProviderAccess("dataforseo");
}
//#endregion
export { DATAFORSEO_NOT_SET_UP_MESSAGE as a, hasProviderAccess as i, getDataforseoFetch as n, hasDataforseoAccess as r, getContextFetch as t };
