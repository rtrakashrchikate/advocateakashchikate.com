import { r as redirect } from "./redirect-BDbpra0T.js";
import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { t as pageHead } from "./pageHead-BfhwMlwa.js";
import { a as keywordsSearchSchema } from "./keywords-Bu6c9nGw.js";
//#region src/client/features/keywords/keywordSearchParams.ts
function normalizeLegacyKeywordSearch(search) {
	const normalized = {
		...search,
		q: search.q === "" ? void 0 : search.q,
		loc: search.loc,
		locName: search.locName === "" ? void 0 : search.locName,
		kLimit: search.kLimit === 150 ? void 0 : search.kLimit,
		mode: search.mode === "auto" ? void 0 : search.mode,
		cs: search.cs === true ? true : void 0,
		grp: search.grp === true ? true : void 0,
		sort: search.sort === "searchVolume" ? void 0 : search.sort,
		order: search.order === "desc" ? void 0 : search.order,
		minVol: void 0,
		maxVol: void 0,
		minCpc: void 0,
		maxCpc: void 0,
		minKd: void 0,
		maxKd: void 0,
		include: void 0,
		exclude: void 0
	};
	return {
		normalized,
		changed: [
			"q",
			"loc",
			"locName",
			"kLimit",
			"mode",
			"cs",
			"grp",
			"sort",
			"order",
			"minVol",
			"maxVol",
			"minCpc",
			"maxCpc",
			"minKd",
			"maxKd",
			"include",
			"exclude"
		].some((key) => search[key] !== normalized[key])
	};
}
function isResultLimit(value) {
	return value === 150 || value === 300 || value === 500;
}
function normalizeKeywordMode(value) {
	if (value === "auto") return "auto";
	if (value === "related") return "related";
	if (value === "suggestions") return "suggestions";
	if (value === "ideas") return "ideas";
	return "auto";
}
function normalizeSortField(value) {
	if (value === "keyword") return "keyword";
	if (value === "searchVolume") return "searchVolume";
	if (value === "cpc") return "cpc";
	if (value === "competition") return "competition";
	if (value === "keywordDifficulty") return "keywordDifficulty";
	return "searchVolume";
}
function normalizeSortDir(value) {
	return value === "asc" ? "asc" : "desc";
}
//#endregion
//#region src/routes/_app/p/$projectId/keywords.tsx
var $$splitComponentImporter = () => import("./keywords-C6mWY-eK.js");
var Route = createFileRoute("/_app/p/$projectId/keywords")({
	head: () => pageHead("Keyword Research"),
	validateSearch: keywordsSearchSchema,
	remountDeps: ({ params }) => params.projectId,
	beforeLoad: ({ params, search }) => {
		const { normalized, changed } = normalizeLegacyKeywordSearch(search);
		if (!changed) return;
		throw redirect({
			to: "/p/$projectId/keywords",
			params: { projectId: params.projectId },
			search: normalized,
			replace: true
		});
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { normalizeSortField as a, normalizeSortDir as i, isResultLimit as n, normalizeKeywordMode as r, Route as t };
