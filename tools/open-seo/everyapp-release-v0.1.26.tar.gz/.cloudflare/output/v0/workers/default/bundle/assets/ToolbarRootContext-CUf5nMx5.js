import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { h as formatErrorMessage } from "./button-DrcZrdio.js";
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/toolbar/root/ToolbarRootContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var ToolbarRootContext = /*#__PURE__*/ import_react.createContext(void 0);
function useToolbarRootContext(optional) {
	const context = import_react.useContext(ToolbarRootContext);
	if (context === void 0 && !optional) throw new Error(formatErrorMessage(69));
	return context;
}
//#endregion
export { useToolbarRootContext as t };
