import { r as __exportAll } from "./rolldown-runtime-oLLnCvco.js";
import { EventEmitter } from "node:events";
import Stream from "node:stream";
import { env } from "cloudflare:workers";
import { AsyncLocalStorage } from "node:async_hooks";
import { Buffer as Buffer$1 } from "node:buffer";
//#region src/db/provider.ts
function getDatabaseProvider() {
	const provider = Reflect.get(env, "DATABASE_PROVIDER");
	if (provider === "postgres") return "postgres";
	if (provider === "d1" || provider === void 0 || provider === "") return "d1";
	throw new Error(`Unsupported DATABASE_PROVIDER "${String(provider)}". Expected "d1" or "postgres".`);
}
function getPostgresConnectionString() {
	const hyperdriveUrl = Reflect.get(env, "HYPERDRIVE")?.connectionString?.trim();
	if (hyperdriveUrl) return hyperdriveUrl;
	throw new Error("DATABASE_PROVIDER=postgres requires a HYPERDRIVE binding (in local dev, its localConnectionString).");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/entity.js
var entityKind = Symbol.for("drizzle:entityKind");
function is(value, type) {
	if (!value || typeof value !== "object") return false;
	if (value instanceof type) return true;
	if (!Object.prototype.hasOwnProperty.call(type, entityKind)) throw new Error(`Class "${type.name ?? "<unknown>"}" doesn't look like a Drizzle entity. If this is incorrect and the class is provided by Drizzle, please report this as a bug.`);
	let cls = Object.getPrototypeOf(value).constructor;
	if (cls) while (cls) {
		if (entityKind in cls && cls[entityKind] === type[entityKind]) return true;
		cls = Object.getPrototypeOf(cls);
	}
	return false;
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/logger.js
var ConsoleLogWriter = class {
	static [entityKind] = "ConsoleLogWriter";
	write(message) {
		console.log(message);
	}
};
var DefaultLogger = class {
	static [entityKind] = "DefaultLogger";
	writer;
	constructor(config) {
		this.writer = config?.writer ?? new ConsoleLogWriter();
	}
	logQuery(query, params) {
		const stringifiedParams = params.map((p) => {
			try {
				return JSON.stringify(p);
			} catch {
				return String(p);
			}
		});
		const paramsStr = stringifiedParams.length ? ` -- params: [${stringifiedParams.join(", ")}]` : "";
		this.writer.write(`Query: ${query}${paramsStr}`);
	}
};
var NoopLogger = class {
	static [entityKind] = "NoopLogger";
	logQuery() {}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/table.utils.js
var TableName = Symbol.for("drizzle:Name");
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/table.js
var Schema = Symbol.for("drizzle:Schema");
var Columns = Symbol.for("drizzle:Columns");
var ExtraConfigColumns = Symbol.for("drizzle:ExtraConfigColumns");
var OriginalName = Symbol.for("drizzle:OriginalName");
var BaseName = Symbol.for("drizzle:BaseName");
var IsAlias = Symbol.for("drizzle:IsAlias");
var ExtraConfigBuilder = Symbol.for("drizzle:ExtraConfigBuilder");
var IsDrizzleTable = Symbol.for("drizzle:IsDrizzleTable");
var Table = class {
	static [entityKind] = "Table";
	/** @internal */
	static Symbol = {
		Name: TableName,
		Schema,
		OriginalName,
		Columns,
		ExtraConfigColumns,
		BaseName,
		IsAlias,
		ExtraConfigBuilder
	};
	/**
	* @internal
	* Can be changed if the table is aliased.
	*/
	[TableName];
	/**
	* @internal
	* Used to store the original name of the table, before any aliasing.
	*/
	[OriginalName];
	/** @internal */
	[Schema];
	/** @internal */
	[Columns];
	/** @internal */
	[ExtraConfigColumns];
	/**
	*  @internal
	* Used to store the table name before the transformation via the `tableCreator` functions.
	*/
	[BaseName];
	/** @internal */
	[IsAlias] = false;
	/** @internal */
	[IsDrizzleTable] = true;
	/** @internal */
	[ExtraConfigBuilder] = void 0;
	constructor(name, schema, baseName) {
		this[TableName] = this[OriginalName] = name;
		this[Schema] = schema;
		this[BaseName] = baseName;
	}
};
function getTableName(table) {
	return table[TableName];
}
function getTableUniqueName(table) {
	return `${table[Schema] ?? "public"}.${table[TableName]}`;
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/column.js
var Column = class {
	constructor(table, config) {
		this.table = table;
		this.config = config;
		this.name = config.name;
		this.keyAsName = config.keyAsName;
		this.notNull = config.notNull;
		this.default = config.default;
		this.defaultFn = config.defaultFn;
		this.onUpdateFn = config.onUpdateFn;
		this.hasDefault = config.hasDefault;
		this.primary = config.primaryKey;
		this.isUnique = config.isUnique;
		this.uniqueName = config.uniqueName;
		this.uniqueType = config.uniqueType;
		this.dataType = config.dataType;
		this.columnType = config.columnType;
		this.generated = config.generated;
		this.generatedIdentity = config.generatedIdentity;
	}
	static [entityKind] = "Column";
	name;
	keyAsName;
	primary;
	notNull;
	default;
	defaultFn;
	onUpdateFn;
	hasDefault;
	isUnique;
	uniqueName;
	uniqueType;
	dataType;
	columnType;
	enumValues = void 0;
	generated = void 0;
	generatedIdentity = void 0;
	config;
	mapFromDriverValue(value) {
		return value;
	}
	mapToDriverValue(value) {
		return value;
	}
	shouldDisableInsert() {
		return this.config.generated !== void 0 && this.config.generated.type !== "byDefault";
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/column-builder.js
var ColumnBuilder = class {
	static [entityKind] = "ColumnBuilder";
	config;
	constructor(name, dataType, columnType) {
		this.config = {
			name,
			keyAsName: name === "",
			notNull: false,
			default: void 0,
			hasDefault: false,
			primaryKey: false,
			isUnique: false,
			uniqueName: void 0,
			uniqueType: void 0,
			dataType,
			columnType,
			generated: void 0
		};
	}
	/**
	* Changes the data type of the column. Commonly used with `json` columns. Also, useful for branded types.
	*
	* @example
	* ```ts
	* const users = pgTable('users', {
	* 	id: integer('id').$type<UserId>().primaryKey(),
	* 	details: json('details').$type<UserDetails>().notNull(),
	* });
	* ```
	*/
	$type() {
		return this;
	}
	/**
	* Adds a `not null` clause to the column definition.
	*
	* Affects the `select` model of the table - columns *without* `not null` will be nullable on select.
	*/
	notNull() {
		this.config.notNull = true;
		return this;
	}
	/**
	* Adds a `default <value>` clause to the column definition.
	*
	* Affects the `insert` model of the table - columns *with* `default` are optional on insert.
	*
	* If you need to set a dynamic default value, use {@link $defaultFn} instead.
	*/
	default(value) {
		this.config.default = value;
		this.config.hasDefault = true;
		return this;
	}
	/**
	* Adds a dynamic default value to the column.
	* The function will be called when the row is inserted, and the returned value will be used as the column value.
	*
	* **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
	*/
	$defaultFn(fn) {
		this.config.defaultFn = fn;
		this.config.hasDefault = true;
		return this;
	}
	/**
	* Alias for {@link $defaultFn}.
	*/
	$default = this.$defaultFn;
	/**
	* Adds a dynamic update value to the column.
	* The function will be called when the row is updated, and the returned value will be used as the column value if none is provided.
	* If no `default` (or `$defaultFn`) value is provided, the function will be called when the row is inserted as well, and the returned value will be used as the column value.
	*
	* **Note:** This value does not affect the `drizzle-kit` behavior, it is only used at runtime in `drizzle-orm`.
	*/
	$onUpdateFn(fn) {
		this.config.onUpdateFn = fn;
		this.config.hasDefault = true;
		return this;
	}
	/**
	* Alias for {@link $onUpdateFn}.
	*/
	$onUpdate = this.$onUpdateFn;
	/**
	* Adds a `primary key` clause to the column definition. This implicitly makes the column `not null`.
	*
	* In SQLite, `integer primary key` implicitly makes the column auto-incrementing.
	*/
	primaryKey() {
		this.config.primaryKey = true;
		this.config.notNull = true;
		return this;
	}
	/** @internal Sets the name of the column to the key within the table definition if a name was not given. */
	setName(name) {
		if (this.config.name !== "") return;
		this.config.name = name;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/foreign-keys.js
var ForeignKeyBuilder$1 = class {
	static [entityKind] = "PgForeignKeyBuilder";
	/** @internal */
	reference;
	/** @internal */
	_onUpdate = "no action";
	/** @internal */
	_onDelete = "no action";
	constructor(config, actions) {
		this.reference = () => {
			const { name, columns, foreignColumns } = config();
			return {
				name,
				columns,
				foreignTable: foreignColumns[0].table,
				foreignColumns
			};
		};
		if (actions) {
			this._onUpdate = actions.onUpdate;
			this._onDelete = actions.onDelete;
		}
	}
	onUpdate(action) {
		this._onUpdate = action === void 0 ? "no action" : action;
		return this;
	}
	onDelete(action) {
		this._onDelete = action === void 0 ? "no action" : action;
		return this;
	}
	/** @internal */
	build(table) {
		return new ForeignKey$1(table, this);
	}
};
var ForeignKey$1 = class {
	constructor(table, builder) {
		this.table = table;
		this.reference = builder.reference;
		this.onUpdate = builder._onUpdate;
		this.onDelete = builder._onDelete;
	}
	static [entityKind] = "PgForeignKey";
	reference;
	onUpdate;
	onDelete;
	getName() {
		const { name, columns, foreignColumns } = this.reference();
		const columnNames = columns.map((column) => column.name);
		const foreignColumnNames = foreignColumns.map((column) => column.name);
		const chunks = [
			this.table[TableName],
			...columnNames,
			foreignColumns[0].table[TableName],
			...foreignColumnNames
		];
		return name ?? `${chunks.join("_")}_fk`;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/tracing-utils.js
function iife(fn, ...args) {
	return fn(...args);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/unique-constraint.js
function uniqueKeyName$1(table, columns) {
	return `${table[TableName]}_${columns.join("_")}_unique`;
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/utils/array.js
function parsePgArrayValue(arrayString, startFrom, inQuotes) {
	for (let i = startFrom; i < arrayString.length; i++) {
		const char = arrayString[i];
		if (char === "\\") {
			i++;
			continue;
		}
		if (char === "\"") return [arrayString.slice(startFrom, i).replace(/\\/g, ""), i + 1];
		if (inQuotes) continue;
		if (char === "," || char === "}") return [arrayString.slice(startFrom, i).replace(/\\/g, ""), i];
	}
	return [arrayString.slice(startFrom).replace(/\\/g, ""), arrayString.length];
}
function parsePgNestedArray(arrayString, startFrom = 0) {
	const result = [];
	let i = startFrom;
	let lastCharIsComma = false;
	while (i < arrayString.length) {
		const char = arrayString[i];
		if (char === ",") {
			if (lastCharIsComma || i === startFrom) result.push("");
			lastCharIsComma = true;
			i++;
			continue;
		}
		lastCharIsComma = false;
		if (char === "\\") {
			i += 2;
			continue;
		}
		if (char === "\"") {
			const [value2, startFrom2] = parsePgArrayValue(arrayString, i + 1, true);
			result.push(value2);
			i = startFrom2;
			continue;
		}
		if (char === "}") return [result, i + 1];
		if (char === "{") {
			const [value2, startFrom2] = parsePgNestedArray(arrayString, i + 1);
			result.push(value2);
			i = startFrom2;
			continue;
		}
		const [value, newStartFrom] = parsePgArrayValue(arrayString, i, false);
		result.push(value);
		i = newStartFrom;
	}
	return [result, i];
}
function parsePgArray(arrayString) {
	const [result] = parsePgNestedArray(arrayString, 1);
	return result;
}
function makePgArray(array) {
	return `{${array.map((item) => {
		if (Array.isArray(item)) return makePgArray(item);
		if (typeof item === "string") return `"${item.replace(/\\/g, "\\\\").replace(/"/g, "\\\"")}"`;
		return `${item}`;
	}).join(",")}}`;
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/common.js
var PgColumnBuilder = class extends ColumnBuilder {
	foreignKeyConfigs = [];
	static [entityKind] = "PgColumnBuilder";
	array(size) {
		return new PgArrayBuilder(this.config.name, this, size);
	}
	references(ref, actions = {}) {
		this.foreignKeyConfigs.push({
			ref,
			actions
		});
		return this;
	}
	unique(name, config) {
		this.config.isUnique = true;
		this.config.uniqueName = name;
		this.config.uniqueType = config?.nulls;
		return this;
	}
	generatedAlwaysAs(as) {
		this.config.generated = {
			as,
			type: "always",
			mode: "stored"
		};
		return this;
	}
	/** @internal */
	buildForeignKeys(column, table) {
		return this.foreignKeyConfigs.map(({ ref, actions }) => {
			return iife((ref2, actions2) => {
				const builder = new ForeignKeyBuilder$1(() => {
					const foreignColumn = ref2();
					return {
						columns: [column],
						foreignColumns: [foreignColumn]
					};
				});
				if (actions2.onUpdate) builder.onUpdate(actions2.onUpdate);
				if (actions2.onDelete) builder.onDelete(actions2.onDelete);
				return builder.build(table);
			}, ref, actions);
		});
	}
	/** @internal */
	buildExtraConfigColumn(table) {
		return new ExtraConfigColumn(table, this.config);
	}
};
var PgColumn = class extends Column {
	constructor(table, config) {
		if (!config.uniqueName) config.uniqueName = uniqueKeyName$1(table, [config.name]);
		super(table, config);
		this.table = table;
	}
	static [entityKind] = "PgColumn";
};
var ExtraConfigColumn = class extends PgColumn {
	static [entityKind] = "ExtraConfigColumn";
	getSQLType() {
		return this.getSQLType();
	}
	indexConfig = {
		order: this.config.order ?? "asc",
		nulls: this.config.nulls ?? "last",
		opClass: this.config.opClass
	};
	defaultConfig = {
		order: "asc",
		nulls: "last",
		opClass: void 0
	};
	asc() {
		this.indexConfig.order = "asc";
		return this;
	}
	desc() {
		this.indexConfig.order = "desc";
		return this;
	}
	nullsFirst() {
		this.indexConfig.nulls = "first";
		return this;
	}
	nullsLast() {
		this.indexConfig.nulls = "last";
		return this;
	}
	/**
	* ### PostgreSQL documentation quote
	*
	* > An operator class with optional parameters can be specified for each column of an index.
	* The operator class identifies the operators to be used by the index for that column.
	* For example, a B-tree index on four-byte integers would use the int4_ops class;
	* this operator class includes comparison functions for four-byte integers.
	* In practice the default operator class for the column's data type is usually sufficient.
	* The main point of having operator classes is that for some data types, there could be more than one meaningful ordering.
	* For example, we might want to sort a complex-number data type either by absolute value or by real part.
	* We could do this by defining two operator classes for the data type and then selecting the proper class when creating an index.
	* More information about operator classes check:
	*
	* ### Useful links
	* https://www.postgresql.org/docs/current/sql-createindex.html
	*
	* https://www.postgresql.org/docs/current/indexes-opclass.html
	*
	* https://www.postgresql.org/docs/current/xindex.html
	*
	* ### Additional types
	* If you have the `pg_vector` extension installed in your database, you can use the
	* `vector_l2_ops`, `vector_ip_ops`, `vector_cosine_ops`, `vector_l1_ops`, `bit_hamming_ops`, `bit_jaccard_ops`, `halfvec_l2_ops`, `sparsevec_l2_ops` options, which are predefined types.
	*
	* **You can always specify any string you want in the operator class, in case Drizzle doesn't have it natively in its types**
	*
	* @param opClass
	* @returns
	*/
	op(opClass) {
		this.indexConfig.opClass = opClass;
		return this;
	}
};
var IndexedColumn = class {
	static [entityKind] = "IndexedColumn";
	constructor(name, keyAsName, type, indexConfig) {
		this.name = name;
		this.keyAsName = keyAsName;
		this.type = type;
		this.indexConfig = indexConfig;
	}
	name;
	keyAsName;
	type;
	indexConfig;
};
var PgArrayBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgArrayBuilder";
	constructor(name, baseBuilder, size) {
		super(name, "array", "PgArray");
		this.config.baseBuilder = baseBuilder;
		this.config.size = size;
	}
	/** @internal */
	build(table) {
		const baseColumn = this.config.baseBuilder.build(table);
		return new PgArray(table, this.config, baseColumn);
	}
};
var PgArray = class PgArray extends PgColumn {
	constructor(table, config, baseColumn, range) {
		super(table, config);
		this.baseColumn = baseColumn;
		this.range = range;
		this.size = config.size;
	}
	size;
	static [entityKind] = "PgArray";
	getSQLType() {
		return `${this.baseColumn.getSQLType()}[${typeof this.size === "number" ? this.size : ""}]`;
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") value = parsePgArray(value);
		return value.map((v) => this.baseColumn.mapFromDriverValue(v));
	}
	mapToDriverValue(value, isNestedArray = false) {
		const a = value.map((v) => v === null ? null : is(this.baseColumn, PgArray) ? this.baseColumn.mapToDriverValue(v, true) : this.baseColumn.mapToDriverValue(v));
		if (isNestedArray) return a;
		return makePgArray(a);
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/enum.js
var isPgEnumSym = Symbol.for("drizzle:isPgEnum");
function isPgEnum(obj) {
	return !!obj && typeof obj === "function" && isPgEnumSym in obj && obj[isPgEnumSym] === true;
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/subquery.js
var Subquery = class {
	static [entityKind] = "Subquery";
	constructor(sql, fields, alias, isWith = false, usedTables = []) {
		this._ = {
			brand: "Subquery",
			sql,
			selectedFields: fields,
			alias,
			isWith,
			usedTables
		};
	}
};
var WithSubquery = class extends Subquery {
	static [entityKind] = "WithSubquery";
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/tracing.js
var tracer = { startActiveSpan(name, fn) {
	return fn();
} };
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/view-common.js
var ViewBaseConfig = Symbol.for("drizzle:ViewBaseConfig");
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sql/sql.js
function isSQLWrapper(value) {
	return value !== null && value !== void 0 && typeof value.getSQL === "function";
}
function mergeQueries(queries) {
	const result = {
		sql: "",
		params: []
	};
	for (const query of queries) {
		result.sql += query.sql;
		result.params.push(...query.params);
		if (query.typings?.length) {
			if (!result.typings) result.typings = [];
			result.typings.push(...query.typings);
		}
	}
	return result;
}
var StringChunk = class {
	static [entityKind] = "StringChunk";
	value;
	constructor(value) {
		this.value = Array.isArray(value) ? value : [value];
	}
	getSQL() {
		return new SQL([this]);
	}
};
var SQL = class SQL {
	constructor(queryChunks) {
		this.queryChunks = queryChunks;
		for (const chunk of queryChunks) if (is(chunk, Table)) {
			const schemaName = chunk[Table.Symbol.Schema];
			this.usedTables.push(schemaName === void 0 ? chunk[Table.Symbol.Name] : schemaName + "." + chunk[Table.Symbol.Name]);
		}
	}
	static [entityKind] = "SQL";
	/** @internal */
	decoder = noopDecoder;
	shouldInlineParams = false;
	/** @internal */
	usedTables = [];
	append(query) {
		this.queryChunks.push(...query.queryChunks);
		return this;
	}
	toQuery(config) {
		return tracer.startActiveSpan("drizzle.buildSQL", (span) => {
			const query = this.buildQueryFromSourceParams(this.queryChunks, config);
			span?.setAttributes({
				"drizzle.query.text": query.sql,
				"drizzle.query.params": JSON.stringify(query.params)
			});
			return query;
		});
	}
	buildQueryFromSourceParams(chunks, _config) {
		const config = Object.assign({}, _config, {
			inlineParams: _config.inlineParams || this.shouldInlineParams,
			paramStartIndex: _config.paramStartIndex || { value: 0 }
		});
		const { casing, escapeName, escapeParam, prepareTyping, inlineParams, paramStartIndex } = config;
		return mergeQueries(chunks.map((chunk) => {
			if (is(chunk, StringChunk)) return {
				sql: chunk.value.join(""),
				params: []
			};
			if (is(chunk, Name)) return {
				sql: escapeName(chunk.value),
				params: []
			};
			if (chunk === void 0) return {
				sql: "",
				params: []
			};
			if (Array.isArray(chunk)) {
				const result = [new StringChunk("(")];
				for (const [i, p] of chunk.entries()) {
					result.push(p);
					if (i < chunk.length - 1) result.push(new StringChunk(", "));
				}
				result.push(new StringChunk(")"));
				return this.buildQueryFromSourceParams(result, config);
			}
			if (is(chunk, SQL)) return this.buildQueryFromSourceParams(chunk.queryChunks, {
				...config,
				inlineParams: inlineParams || chunk.shouldInlineParams
			});
			if (is(chunk, Table)) {
				const schemaName = chunk[Table.Symbol.Schema];
				const tableName = chunk[Table.Symbol.Name];
				return {
					sql: schemaName === void 0 || chunk[IsAlias] ? escapeName(tableName) : escapeName(schemaName) + "." + escapeName(tableName),
					params: []
				};
			}
			if (is(chunk, Column)) {
				const columnName = casing.getColumnCasing(chunk);
				if (_config.invokeSource === "indexes") return {
					sql: escapeName(columnName),
					params: []
				};
				const schemaName = chunk.table[Table.Symbol.Schema];
				return {
					sql: chunk.table[IsAlias] || schemaName === void 0 ? escapeName(chunk.table[Table.Symbol.Name]) + "." + escapeName(columnName) : escapeName(schemaName) + "." + escapeName(chunk.table[Table.Symbol.Name]) + "." + escapeName(columnName),
					params: []
				};
			}
			if (is(chunk, View)) {
				const schemaName = chunk[ViewBaseConfig].schema;
				const viewName = chunk[ViewBaseConfig].name;
				return {
					sql: schemaName === void 0 || chunk[ViewBaseConfig].isAlias ? escapeName(viewName) : escapeName(schemaName) + "." + escapeName(viewName),
					params: []
				};
			}
			if (is(chunk, Param)) {
				if (is(chunk.value, Placeholder)) return {
					sql: escapeParam(paramStartIndex.value++, chunk),
					params: [chunk],
					typings: ["none"]
				};
				const mappedValue = chunk.value === null ? null : chunk.encoder.mapToDriverValue(chunk.value);
				if (is(mappedValue, SQL)) return this.buildQueryFromSourceParams([mappedValue], config);
				if (inlineParams) return {
					sql: this.mapInlineParam(mappedValue, config),
					params: []
				};
				let typings = ["none"];
				if (prepareTyping) typings = [prepareTyping(chunk.encoder)];
				return {
					sql: escapeParam(paramStartIndex.value++, mappedValue),
					params: [mappedValue],
					typings
				};
			}
			if (is(chunk, Placeholder)) return {
				sql: escapeParam(paramStartIndex.value++, chunk),
				params: [chunk],
				typings: ["none"]
			};
			if (is(chunk, SQL.Aliased) && chunk.fieldAlias !== void 0) return {
				sql: escapeName(chunk.fieldAlias),
				params: []
			};
			if (is(chunk, Subquery)) {
				if (chunk._.isWith) return {
					sql: escapeName(chunk._.alias),
					params: []
				};
				return this.buildQueryFromSourceParams([
					new StringChunk("("),
					chunk._.sql,
					new StringChunk(") "),
					new Name(chunk._.alias)
				], config);
			}
			if (isPgEnum(chunk)) {
				if (chunk.schema) return {
					sql: escapeName(chunk.schema) + "." + escapeName(chunk.enumName),
					params: []
				};
				return {
					sql: escapeName(chunk.enumName),
					params: []
				};
			}
			if (isSQLWrapper(chunk)) {
				if (chunk.shouldOmitSQLParens?.()) return this.buildQueryFromSourceParams([chunk.getSQL()], config);
				return this.buildQueryFromSourceParams([
					new StringChunk("("),
					chunk.getSQL(),
					new StringChunk(")")
				], config);
			}
			if (inlineParams) return {
				sql: this.mapInlineParam(chunk, config),
				params: []
			};
			return {
				sql: escapeParam(paramStartIndex.value++, chunk),
				params: [chunk],
				typings: ["none"]
			};
		}));
	}
	mapInlineParam(chunk, { escapeString }) {
		if (chunk === null) return "null";
		if (typeof chunk === "number" || typeof chunk === "boolean") return chunk.toString();
		if (typeof chunk === "string") return escapeString(chunk);
		if (typeof chunk === "object") {
			const mappedValueAsString = chunk.toString();
			if (mappedValueAsString === "[object Object]") return escapeString(JSON.stringify(chunk));
			return escapeString(mappedValueAsString);
		}
		throw new Error("Unexpected param value: " + chunk);
	}
	getSQL() {
		return this;
	}
	as(alias) {
		if (alias === void 0) return this;
		return new SQL.Aliased(this, alias);
	}
	mapWith(decoder) {
		this.decoder = typeof decoder === "function" ? { mapFromDriverValue: decoder } : decoder;
		return this;
	}
	inlineParams() {
		this.shouldInlineParams = true;
		return this;
	}
	/**
	* This method is used to conditionally include a part of the query.
	*
	* @param condition - Condition to check
	* @returns itself if the condition is `true`, otherwise `undefined`
	*/
	if(condition) {
		return condition ? this : void 0;
	}
};
var Name = class {
	constructor(value) {
		this.value = value;
	}
	static [entityKind] = "Name";
	brand;
	getSQL() {
		return new SQL([this]);
	}
};
function isDriverValueEncoder(value) {
	return typeof value === "object" && value !== null && "mapToDriverValue" in value && typeof value.mapToDriverValue === "function";
}
var noopDecoder = { mapFromDriverValue: (value) => value };
var noopEncoder = { mapToDriverValue: (value) => value };
({
	...noopDecoder,
	...noopEncoder
});
var Param = class {
	/**
	* @param value - Parameter value
	* @param encoder - Encoder to convert the value to a driver parameter
	*/
	constructor(value, encoder = noopEncoder) {
		this.value = value;
		this.encoder = encoder;
	}
	static [entityKind] = "Param";
	brand;
	getSQL() {
		return new SQL([this]);
	}
};
function sql(strings, ...params) {
	const queryChunks = [];
	if (params.length > 0 || strings.length > 0 && strings[0] !== "") queryChunks.push(new StringChunk(strings[0]));
	for (const [paramIndex, param2] of params.entries()) queryChunks.push(param2, new StringChunk(strings[paramIndex + 1]));
	return new SQL(queryChunks);
}
((sql2) => {
	function empty() {
		return new SQL([]);
	}
	sql2.empty = empty;
	function fromList(list) {
		return new SQL(list);
	}
	sql2.fromList = fromList;
	function raw(str) {
		return new SQL([new StringChunk(str)]);
	}
	sql2.raw = raw;
	function join(chunks, separator) {
		const result = [];
		for (const [i, chunk] of chunks.entries()) {
			if (i > 0 && separator !== void 0) result.push(separator);
			result.push(chunk);
		}
		return new SQL(result);
	}
	sql2.join = join;
	function identifier(value) {
		return new Name(value);
	}
	sql2.identifier = identifier;
	function placeholder2(name2) {
		return new Placeholder(name2);
	}
	sql2.placeholder = placeholder2;
	function param2(value, encoder) {
		return new Param(value, encoder);
	}
	sql2.param = param2;
})(sql || (sql = {}));
((SQL2) => {
	class Aliased {
		constructor(sql2, fieldAlias) {
			this.sql = sql2;
			this.fieldAlias = fieldAlias;
		}
		static [entityKind] = "SQL.Aliased";
		/** @internal */
		isSelectionField = false;
		getSQL() {
			return this.sql;
		}
		/** @internal */
		clone() {
			return new Aliased(this.sql, this.fieldAlias);
		}
	}
	SQL2.Aliased = Aliased;
})(SQL || (SQL = {}));
var Placeholder = class {
	constructor(name2) {
		this.name = name2;
	}
	static [entityKind] = "Placeholder";
	getSQL() {
		return new SQL([this]);
	}
};
function fillPlaceholders(params, values) {
	return params.map((p) => {
		if (is(p, Placeholder)) {
			if (!(p.name in values)) throw new Error(`No value for placeholder "${p.name}" was provided`);
			return values[p.name];
		}
		if (is(p, Param) && is(p.value, Placeholder)) {
			if (!(p.value.name in values)) throw new Error(`No value for placeholder "${p.value.name}" was provided`);
			return p.encoder.mapToDriverValue(values[p.value.name]);
		}
		return p;
	});
}
var IsDrizzleView = Symbol.for("drizzle:IsDrizzleView");
var View = class {
	static [entityKind] = "View";
	/** @internal */
	[ViewBaseConfig];
	/** @internal */
	[IsDrizzleView] = true;
	constructor({ name: name2, schema, selectedFields, query }) {
		this[ViewBaseConfig] = {
			name: name2,
			originalName: name2,
			schema,
			selectedFields,
			query,
			isExisting: !query,
			isAlias: false
		};
	}
	getSQL() {
		return new SQL([this]);
	}
};
Column.prototype.getSQL = function() {
	return new SQL([this]);
};
Table.prototype.getSQL = function() {
	return new SQL([this]);
};
Subquery.prototype.getSQL = function() {
	return new SQL([this]);
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/utils.js
function mapResultRow(columns, row, joinsNotNullableMap) {
	const nullifyMap = {};
	const result = columns.reduce((result2, { path, field }, columnIndex) => {
		let decoder;
		if (is(field, Column)) decoder = field;
		else if (is(field, SQL)) decoder = field.decoder;
		else if (is(field, Subquery)) decoder = field._.sql.decoder;
		else decoder = field.sql.decoder;
		let node = result2;
		for (const [pathChunkIndex, pathChunk] of path.entries()) if (pathChunkIndex < path.length - 1) {
			if (!(pathChunk in node)) node[pathChunk] = {};
			node = node[pathChunk];
		} else {
			const rawValue = row[columnIndex];
			const value = node[pathChunk] = rawValue === null ? null : decoder.mapFromDriverValue(rawValue);
			if (joinsNotNullableMap && is(field, Column) && path.length === 2) {
				const objectName = path[0];
				if (!(objectName in nullifyMap)) nullifyMap[objectName] = value === null ? getTableName(field.table) : false;
				else if (typeof nullifyMap[objectName] === "string" && nullifyMap[objectName] !== getTableName(field.table)) nullifyMap[objectName] = false;
			}
		}
		return result2;
	}, {});
	if (joinsNotNullableMap && Object.keys(nullifyMap).length > 0) {
		for (const [objectName, tableName] of Object.entries(nullifyMap)) if (typeof tableName === "string" && !joinsNotNullableMap[tableName]) result[objectName] = null;
	}
	return result;
}
function orderSelectedFields(fields, pathPrefix) {
	return Object.entries(fields).reduce((result, [name, field]) => {
		if (typeof name !== "string") return result;
		const newPath = pathPrefix ? [...pathPrefix, name] : [name];
		if (is(field, Column) || is(field, SQL) || is(field, SQL.Aliased) || is(field, Subquery)) result.push({
			path: newPath,
			field
		});
		else if (is(field, Table)) result.push(...orderSelectedFields(field[Table.Symbol.Columns], newPath));
		else result.push(...orderSelectedFields(field, newPath));
		return result;
	}, []);
}
function haveSameKeys(left, right) {
	const leftKeys = Object.keys(left);
	const rightKeys = Object.keys(right);
	if (leftKeys.length !== rightKeys.length) return false;
	for (const [index, key] of leftKeys.entries()) if (key !== rightKeys[index]) return false;
	return true;
}
function mapUpdateSet(table, values) {
	const entries = Object.entries(values).filter(([, value]) => value !== void 0).map(([key, value]) => {
		if (is(value, SQL) || is(value, Column)) return [key, value];
		else return [key, new Param(value, table[Table.Symbol.Columns][key])];
	});
	if (entries.length === 0) throw new Error("No values to set");
	return Object.fromEntries(entries);
}
function applyMixins(baseClass, extendedClasses) {
	for (const extendedClass of extendedClasses) for (const name of Object.getOwnPropertyNames(extendedClass.prototype)) {
		if (name === "constructor") continue;
		Object.defineProperty(baseClass.prototype, name, Object.getOwnPropertyDescriptor(extendedClass.prototype, name) || /* @__PURE__ */ Object.create(null));
	}
}
function getTableColumns(table) {
	return table[Table.Symbol.Columns];
}
function getTableLikeName(table) {
	return is(table, Subquery) ? table._.alias : is(table, View) ? table[ViewBaseConfig].name : is(table, SQL) ? void 0 : table[Table.Symbol.IsAlias] ? table[Table.Symbol.Name] : table[Table.Symbol.BaseName];
}
function getColumnNameAndConfig(a, b) {
	return {
		name: typeof a === "string" && a.length > 0 ? a : "",
		config: typeof a === "object" ? a : b
	};
}
function isConfig(data) {
	if (typeof data !== "object" || data === null) return false;
	if (data.constructor.name !== "Object") return false;
	if ("logger" in data) {
		const type = typeof data["logger"];
		if (type !== "boolean" && (type !== "object" || typeof data["logger"]["logQuery"] !== "function") && type !== "undefined") return false;
		return true;
	}
	if ("schema" in data) {
		const type = typeof data["schema"];
		if (type !== "object" && type !== "undefined") return false;
		return true;
	}
	if ("casing" in data) {
		const type = typeof data["casing"];
		if (type !== "string" && type !== "undefined") return false;
		return true;
	}
	if ("mode" in data) {
		if (data["mode"] !== "default" || data["mode"] !== "planetscale" || data["mode"] !== void 0) return false;
		return true;
	}
	if ("connection" in data) {
		const type = typeof data["connection"];
		if (type !== "string" && type !== "object" && type !== "undefined") return false;
		return true;
	}
	if ("client" in data) {
		const type = typeof data["client"];
		if (type !== "object" && type !== "function" && type !== "undefined") return false;
		return true;
	}
	if (Object.keys(data).length === 0) return true;
	return false;
}
var textDecoder = typeof TextDecoder === "undefined" ? null : new TextDecoder();
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/int.common.js
var PgIntColumnBaseBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgIntColumnBaseBuilder";
	generatedAlwaysAsIdentity(sequence) {
		if (sequence) {
			const { name, ...options } = sequence;
			this.config.generatedIdentity = {
				type: "always",
				sequenceName: name,
				sequenceOptions: options
			};
		} else this.config.generatedIdentity = { type: "always" };
		this.config.hasDefault = true;
		this.config.notNull = true;
		return this;
	}
	generatedByDefaultAsIdentity(sequence) {
		if (sequence) {
			const { name, ...options } = sequence;
			this.config.generatedIdentity = {
				type: "byDefault",
				sequenceName: name,
				sequenceOptions: options
			};
		} else this.config.generatedIdentity = { type: "byDefault" };
		this.config.hasDefault = true;
		this.config.notNull = true;
		return this;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/bigint.js
var PgBigInt53Builder = class extends PgIntColumnBaseBuilder {
	static [entityKind] = "PgBigInt53Builder";
	constructor(name) {
		super(name, "number", "PgBigInt53");
	}
	/** @internal */
	build(table) {
		return new PgBigInt53(table, this.config);
	}
};
var PgBigInt53 = class extends PgColumn {
	static [entityKind] = "PgBigInt53";
	getSQLType() {
		return "bigint";
	}
	mapFromDriverValue(value) {
		if (typeof value === "number") return value;
		return Number(value);
	}
};
var PgBigInt64Builder = class extends PgIntColumnBaseBuilder {
	static [entityKind] = "PgBigInt64Builder";
	constructor(name) {
		super(name, "bigint", "PgBigInt64");
	}
	/** @internal */
	build(table) {
		return new PgBigInt64(table, this.config);
	}
};
var PgBigInt64 = class extends PgColumn {
	static [entityKind] = "PgBigInt64";
	getSQLType() {
		return "bigint";
	}
	mapFromDriverValue(value) {
		return BigInt(value);
	}
};
function bigint(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	if (config.mode === "number") return new PgBigInt53Builder(name);
	return new PgBigInt64Builder(name);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/bigserial.js
var PgBigSerial53Builder = class extends PgColumnBuilder {
	static [entityKind] = "PgBigSerial53Builder";
	constructor(name) {
		super(name, "number", "PgBigSerial53");
		this.config.hasDefault = true;
		this.config.notNull = true;
	}
	/** @internal */
	build(table) {
		return new PgBigSerial53(table, this.config);
	}
};
var PgBigSerial53 = class extends PgColumn {
	static [entityKind] = "PgBigSerial53";
	getSQLType() {
		return "bigserial";
	}
	mapFromDriverValue(value) {
		if (typeof value === "number") return value;
		return Number(value);
	}
};
var PgBigSerial64Builder = class extends PgColumnBuilder {
	static [entityKind] = "PgBigSerial64Builder";
	constructor(name) {
		super(name, "bigint", "PgBigSerial64");
		this.config.hasDefault = true;
	}
	/** @internal */
	build(table) {
		return new PgBigSerial64(table, this.config);
	}
};
var PgBigSerial64 = class extends PgColumn {
	static [entityKind] = "PgBigSerial64";
	getSQLType() {
		return "bigserial";
	}
	mapFromDriverValue(value) {
		return BigInt(value);
	}
};
function bigserial(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	if (config.mode === "number") return new PgBigSerial53Builder(name);
	return new PgBigSerial64Builder(name);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/boolean.js
var PgBooleanBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgBooleanBuilder";
	constructor(name) {
		super(name, "boolean", "PgBoolean");
	}
	/** @internal */
	build(table) {
		return new PgBoolean(table, this.config);
	}
};
var PgBoolean = class extends PgColumn {
	static [entityKind] = "PgBoolean";
	getSQLType() {
		return "boolean";
	}
};
function boolean(name) {
	return new PgBooleanBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/char.js
var PgCharBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgCharBuilder";
	constructor(name, config) {
		super(name, "string", "PgChar");
		this.config.length = config.length;
		this.config.enumValues = config.enum;
	}
	/** @internal */
	build(table) {
		return new PgChar(table, this.config);
	}
};
var PgChar = class extends PgColumn {
	static [entityKind] = "PgChar";
	length = this.config.length;
	enumValues = this.config.enumValues;
	getSQLType() {
		return this.length === void 0 ? `char` : `char(${this.length})`;
	}
};
function char(a, b = {}) {
	const { name, config } = getColumnNameAndConfig(a, b);
	return new PgCharBuilder(name, config);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/cidr.js
var PgCidrBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgCidrBuilder";
	constructor(name) {
		super(name, "string", "PgCidr");
	}
	/** @internal */
	build(table) {
		return new PgCidr(table, this.config);
	}
};
var PgCidr = class extends PgColumn {
	static [entityKind] = "PgCidr";
	getSQLType() {
		return "cidr";
	}
};
function cidr(name) {
	return new PgCidrBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/custom.js
var PgCustomColumnBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgCustomColumnBuilder";
	constructor(name, fieldConfig, customTypeParams) {
		super(name, "custom", "PgCustomColumn");
		this.config.fieldConfig = fieldConfig;
		this.config.customTypeParams = customTypeParams;
	}
	/** @internal */
	build(table) {
		return new PgCustomColumn(table, this.config);
	}
};
var PgCustomColumn = class extends PgColumn {
	static [entityKind] = "PgCustomColumn";
	sqlName;
	mapTo;
	mapFrom;
	constructor(table, config) {
		super(table, config);
		this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
		this.mapTo = config.customTypeParams.toDriver;
		this.mapFrom = config.customTypeParams.fromDriver;
	}
	getSQLType() {
		return this.sqlName;
	}
	mapFromDriverValue(value) {
		return typeof this.mapFrom === "function" ? this.mapFrom(value) : value;
	}
	mapToDriverValue(value) {
		return typeof this.mapTo === "function" ? this.mapTo(value) : value;
	}
};
function customType$1(customTypeParams) {
	return (a, b) => {
		const { name, config } = getColumnNameAndConfig(a, b);
		return new PgCustomColumnBuilder(name, config, customTypeParams);
	};
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/date.common.js
var PgDateColumnBaseBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgDateColumnBaseBuilder";
	defaultNow() {
		return this.default(sql`now()`);
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/date.js
var PgDateBuilder = class extends PgDateColumnBaseBuilder {
	static [entityKind] = "PgDateBuilder";
	constructor(name) {
		super(name, "date", "PgDate");
	}
	/** @internal */
	build(table) {
		return new PgDate(table, this.config);
	}
};
var PgDate = class extends PgColumn {
	static [entityKind] = "PgDate";
	getSQLType() {
		return "date";
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") return new Date(value);
		return value;
	}
	mapToDriverValue(value) {
		return value.toISOString();
	}
};
var PgDateStringBuilder = class extends PgDateColumnBaseBuilder {
	static [entityKind] = "PgDateStringBuilder";
	constructor(name) {
		super(name, "string", "PgDateString");
	}
	/** @internal */
	build(table) {
		return new PgDateString(table, this.config);
	}
};
var PgDateString = class extends PgColumn {
	static [entityKind] = "PgDateString";
	getSQLType() {
		return "date";
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") return value;
		return value.toISOString().slice(0, -14);
	}
};
function date(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	if (config?.mode === "date") return new PgDateBuilder(name);
	return new PgDateStringBuilder(name);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/double-precision.js
var PgDoublePrecisionBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgDoublePrecisionBuilder";
	constructor(name) {
		super(name, "number", "PgDoublePrecision");
	}
	/** @internal */
	build(table) {
		return new PgDoublePrecision(table, this.config);
	}
};
var PgDoublePrecision = class extends PgColumn {
	static [entityKind] = "PgDoublePrecision";
	getSQLType() {
		return "double precision";
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") return Number.parseFloat(value);
		return value;
	}
};
function doublePrecision(name) {
	return new PgDoublePrecisionBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/inet.js
var PgInetBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgInetBuilder";
	constructor(name) {
		super(name, "string", "PgInet");
	}
	/** @internal */
	build(table) {
		return new PgInet(table, this.config);
	}
};
var PgInet = class extends PgColumn {
	static [entityKind] = "PgInet";
	getSQLType() {
		return "inet";
	}
};
function inet(name) {
	return new PgInetBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/integer.js
var PgIntegerBuilder = class extends PgIntColumnBaseBuilder {
	static [entityKind] = "PgIntegerBuilder";
	constructor(name) {
		super(name, "number", "PgInteger");
	}
	/** @internal */
	build(table) {
		return new PgInteger(table, this.config);
	}
};
var PgInteger = class extends PgColumn {
	static [entityKind] = "PgInteger";
	getSQLType() {
		return "integer";
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") return Number.parseInt(value);
		return value;
	}
};
function integer$1(name) {
	return new PgIntegerBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/interval.js
var PgIntervalBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgIntervalBuilder";
	constructor(name, intervalConfig) {
		super(name, "string", "PgInterval");
		this.config.intervalConfig = intervalConfig;
	}
	/** @internal */
	build(table) {
		return new PgInterval(table, this.config);
	}
};
var PgInterval = class extends PgColumn {
	static [entityKind] = "PgInterval";
	fields = this.config.intervalConfig.fields;
	precision = this.config.intervalConfig.precision;
	getSQLType() {
		return `interval${this.fields ? ` ${this.fields}` : ""}${this.precision ? `(${this.precision})` : ""}`;
	}
};
function interval(a, b = {}) {
	const { name, config } = getColumnNameAndConfig(a, b);
	return new PgIntervalBuilder(name, config);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/json.js
var PgJsonBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgJsonBuilder";
	constructor(name) {
		super(name, "json", "PgJson");
	}
	/** @internal */
	build(table) {
		return new PgJson(table, this.config);
	}
};
var PgJson = class extends PgColumn {
	static [entityKind] = "PgJson";
	constructor(table, config) {
		super(table, config);
	}
	getSQLType() {
		return "json";
	}
	mapToDriverValue(value) {
		return JSON.stringify(value);
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") try {
			return JSON.parse(value);
		} catch {
			return value;
		}
		return value;
	}
};
function json(name) {
	return new PgJsonBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/jsonb.js
var PgJsonbBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgJsonbBuilder";
	constructor(name) {
		super(name, "json", "PgJsonb");
	}
	/** @internal */
	build(table) {
		return new PgJsonb(table, this.config);
	}
};
var PgJsonb = class extends PgColumn {
	static [entityKind] = "PgJsonb";
	constructor(table, config) {
		super(table, config);
	}
	getSQLType() {
		return "jsonb";
	}
	mapToDriverValue(value) {
		return JSON.stringify(value);
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") try {
			return JSON.parse(value);
		} catch {
			return value;
		}
		return value;
	}
};
function jsonb(name) {
	return new PgJsonbBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/line.js
var PgLineBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgLineBuilder";
	constructor(name) {
		super(name, "array", "PgLine");
	}
	/** @internal */
	build(table) {
		return new PgLineTuple(table, this.config);
	}
};
var PgLineTuple = class extends PgColumn {
	static [entityKind] = "PgLine";
	getSQLType() {
		return "line";
	}
	mapFromDriverValue(value) {
		const [a, b, c] = value.slice(1, -1).split(",");
		return [
			Number.parseFloat(a),
			Number.parseFloat(b),
			Number.parseFloat(c)
		];
	}
	mapToDriverValue(value) {
		return `{${value[0]},${value[1]},${value[2]}}`;
	}
};
var PgLineABCBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgLineABCBuilder";
	constructor(name) {
		super(name, "json", "PgLineABC");
	}
	/** @internal */
	build(table) {
		return new PgLineABC(table, this.config);
	}
};
var PgLineABC = class extends PgColumn {
	static [entityKind] = "PgLineABC";
	getSQLType() {
		return "line";
	}
	mapFromDriverValue(value) {
		const [a, b, c] = value.slice(1, -1).split(",");
		return {
			a: Number.parseFloat(a),
			b: Number.parseFloat(b),
			c: Number.parseFloat(c)
		};
	}
	mapToDriverValue(value) {
		return `{${value.a},${value.b},${value.c}}`;
	}
};
function line(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	if (!config?.mode || config.mode === "tuple") return new PgLineBuilder(name);
	return new PgLineABCBuilder(name);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/macaddr.js
var PgMacaddrBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgMacaddrBuilder";
	constructor(name) {
		super(name, "string", "PgMacaddr");
	}
	/** @internal */
	build(table) {
		return new PgMacaddr(table, this.config);
	}
};
var PgMacaddr = class extends PgColumn {
	static [entityKind] = "PgMacaddr";
	getSQLType() {
		return "macaddr";
	}
};
function macaddr(name) {
	return new PgMacaddrBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/macaddr8.js
var PgMacaddr8Builder = class extends PgColumnBuilder {
	static [entityKind] = "PgMacaddr8Builder";
	constructor(name) {
		super(name, "string", "PgMacaddr8");
	}
	/** @internal */
	build(table) {
		return new PgMacaddr8(table, this.config);
	}
};
var PgMacaddr8 = class extends PgColumn {
	static [entityKind] = "PgMacaddr8";
	getSQLType() {
		return "macaddr8";
	}
};
function macaddr8(name) {
	return new PgMacaddr8Builder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/numeric.js
var PgNumericBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgNumericBuilder";
	constructor(name, precision, scale) {
		super(name, "string", "PgNumeric");
		this.config.precision = precision;
		this.config.scale = scale;
	}
	/** @internal */
	build(table) {
		return new PgNumeric(table, this.config);
	}
};
var PgNumeric = class extends PgColumn {
	static [entityKind] = "PgNumeric";
	precision;
	scale;
	constructor(table, config) {
		super(table, config);
		this.precision = config.precision;
		this.scale = config.scale;
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") return value;
		return String(value);
	}
	getSQLType() {
		if (this.precision !== void 0 && this.scale !== void 0) return `numeric(${this.precision}, ${this.scale})`;
		else if (this.precision === void 0) return "numeric";
		else return `numeric(${this.precision})`;
	}
};
var PgNumericNumberBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgNumericNumberBuilder";
	constructor(name, precision, scale) {
		super(name, "number", "PgNumericNumber");
		this.config.precision = precision;
		this.config.scale = scale;
	}
	/** @internal */
	build(table) {
		return new PgNumericNumber(table, this.config);
	}
};
var PgNumericNumber = class extends PgColumn {
	static [entityKind] = "PgNumericNumber";
	precision;
	scale;
	constructor(table, config) {
		super(table, config);
		this.precision = config.precision;
		this.scale = config.scale;
	}
	mapFromDriverValue(value) {
		if (typeof value === "number") return value;
		return Number(value);
	}
	mapToDriverValue = String;
	getSQLType() {
		if (this.precision !== void 0 && this.scale !== void 0) return `numeric(${this.precision}, ${this.scale})`;
		else if (this.precision === void 0) return "numeric";
		else return `numeric(${this.precision})`;
	}
};
var PgNumericBigIntBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgNumericBigIntBuilder";
	constructor(name, precision, scale) {
		super(name, "bigint", "PgNumericBigInt");
		this.config.precision = precision;
		this.config.scale = scale;
	}
	/** @internal */
	build(table) {
		return new PgNumericBigInt(table, this.config);
	}
};
var PgNumericBigInt = class extends PgColumn {
	static [entityKind] = "PgNumericBigInt";
	precision;
	scale;
	constructor(table, config) {
		super(table, config);
		this.precision = config.precision;
		this.scale = config.scale;
	}
	mapFromDriverValue = BigInt;
	mapToDriverValue = String;
	getSQLType() {
		if (this.precision !== void 0 && this.scale !== void 0) return `numeric(${this.precision}, ${this.scale})`;
		else if (this.precision === void 0) return "numeric";
		else return `numeric(${this.precision})`;
	}
};
function numeric$1(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	const mode = config?.mode;
	return mode === "number" ? new PgNumericNumberBuilder(name, config?.precision, config?.scale) : mode === "bigint" ? new PgNumericBigIntBuilder(name, config?.precision, config?.scale) : new PgNumericBuilder(name, config?.precision, config?.scale);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/point.js
var PgPointTupleBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgPointTupleBuilder";
	constructor(name) {
		super(name, "array", "PgPointTuple");
	}
	/** @internal */
	build(table) {
		return new PgPointTuple(table, this.config);
	}
};
var PgPointTuple = class extends PgColumn {
	static [entityKind] = "PgPointTuple";
	getSQLType() {
		return "point";
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") {
			const [x, y] = value.slice(1, -1).split(",");
			return [Number.parseFloat(x), Number.parseFloat(y)];
		}
		return [value.x, value.y];
	}
	mapToDriverValue(value) {
		return `(${value[0]},${value[1]})`;
	}
};
var PgPointObjectBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgPointObjectBuilder";
	constructor(name) {
		super(name, "json", "PgPointObject");
	}
	/** @internal */
	build(table) {
		return new PgPointObject(table, this.config);
	}
};
var PgPointObject = class extends PgColumn {
	static [entityKind] = "PgPointObject";
	getSQLType() {
		return "point";
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") {
			const [x, y] = value.slice(1, -1).split(",");
			return {
				x: Number.parseFloat(x),
				y: Number.parseFloat(y)
			};
		}
		return value;
	}
	mapToDriverValue(value) {
		return `(${value.x},${value.y})`;
	}
};
function point(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	if (!config?.mode || config.mode === "tuple") return new PgPointTupleBuilder(name);
	return new PgPointObjectBuilder(name);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/postgis_extension/utils.js
function hexToBytes(hex) {
	const bytes = [];
	for (let c = 0; c < hex.length; c += 2) bytes.push(Number.parseInt(hex.slice(c, c + 2), 16));
	return new Uint8Array(bytes);
}
function bytesToFloat64(bytes, offset) {
	const view = /* @__PURE__ */ new DataView(/* @__PURE__ */ new ArrayBuffer(8));
	for (let i = 0; i < 8; i++) view.setUint8(i, bytes[offset + i]);
	return view.getFloat64(0, true);
}
function parseEWKB(hex) {
	const bytes = hexToBytes(hex);
	let offset = 0;
	const byteOrder = bytes[offset];
	offset += 1;
	const view = new DataView(bytes.buffer);
	const geomType = view.getUint32(offset, byteOrder === 1);
	offset += 4;
	if (geomType & 536870912) {
		view.getUint32(offset, byteOrder === 1);
		offset += 4;
	}
	if ((geomType & 65535) === 1) {
		const x = bytesToFloat64(bytes, offset);
		offset += 8;
		const y = bytesToFloat64(bytes, offset);
		offset += 8;
		return [x, y];
	}
	throw new Error("Unsupported geometry type");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/postgis_extension/geometry.js
var PgGeometryBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgGeometryBuilder";
	constructor(name) {
		super(name, "array", "PgGeometry");
	}
	/** @internal */
	build(table) {
		return new PgGeometry(table, this.config);
	}
};
var PgGeometry = class extends PgColumn {
	static [entityKind] = "PgGeometry";
	getSQLType() {
		return "geometry(point)";
	}
	mapFromDriverValue(value) {
		return parseEWKB(value);
	}
	mapToDriverValue(value) {
		return `point(${value[0]} ${value[1]})`;
	}
};
var PgGeometryObjectBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgGeometryObjectBuilder";
	constructor(name) {
		super(name, "json", "PgGeometryObject");
	}
	/** @internal */
	build(table) {
		return new PgGeometryObject(table, this.config);
	}
};
var PgGeometryObject = class extends PgColumn {
	static [entityKind] = "PgGeometryObject";
	getSQLType() {
		return "geometry(point)";
	}
	mapFromDriverValue(value) {
		const parsed = parseEWKB(value);
		return {
			x: parsed[0],
			y: parsed[1]
		};
	}
	mapToDriverValue(value) {
		return `point(${value.x} ${value.y})`;
	}
};
function geometry(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	if (!config?.mode || config.mode === "tuple") return new PgGeometryBuilder(name);
	return new PgGeometryObjectBuilder(name);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/real.js
var PgRealBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgRealBuilder";
	constructor(name, length) {
		super(name, "number", "PgReal");
		this.config.length = length;
	}
	/** @internal */
	build(table) {
		return new PgReal(table, this.config);
	}
};
var PgReal = class extends PgColumn {
	static [entityKind] = "PgReal";
	constructor(table, config) {
		super(table, config);
	}
	getSQLType() {
		return "real";
	}
	mapFromDriverValue = (value) => {
		if (typeof value === "string") return Number.parseFloat(value);
		return value;
	};
};
function real$1(name) {
	return new PgRealBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/serial.js
var PgSerialBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgSerialBuilder";
	constructor(name) {
		super(name, "number", "PgSerial");
		this.config.hasDefault = true;
		this.config.notNull = true;
	}
	/** @internal */
	build(table) {
		return new PgSerial(table, this.config);
	}
};
var PgSerial = class extends PgColumn {
	static [entityKind] = "PgSerial";
	getSQLType() {
		return "serial";
	}
};
function serial(name) {
	return new PgSerialBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/smallint.js
var PgSmallIntBuilder = class extends PgIntColumnBaseBuilder {
	static [entityKind] = "PgSmallIntBuilder";
	constructor(name) {
		super(name, "number", "PgSmallInt");
	}
	/** @internal */
	build(table) {
		return new PgSmallInt(table, this.config);
	}
};
var PgSmallInt = class extends PgColumn {
	static [entityKind] = "PgSmallInt";
	getSQLType() {
		return "smallint";
	}
	mapFromDriverValue = (value) => {
		if (typeof value === "string") return Number(value);
		return value;
	};
};
function smallint(name) {
	return new PgSmallIntBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/smallserial.js
var PgSmallSerialBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgSmallSerialBuilder";
	constructor(name) {
		super(name, "number", "PgSmallSerial");
		this.config.hasDefault = true;
		this.config.notNull = true;
	}
	/** @internal */
	build(table) {
		return new PgSmallSerial(table, this.config);
	}
};
var PgSmallSerial = class extends PgColumn {
	static [entityKind] = "PgSmallSerial";
	getSQLType() {
		return "smallserial";
	}
};
function smallserial(name) {
	return new PgSmallSerialBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/text.js
var PgTextBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgTextBuilder";
	constructor(name, config) {
		super(name, "string", "PgText");
		this.config.enumValues = config.enum;
	}
	/** @internal */
	build(table) {
		return new PgText(table, this.config);
	}
};
var PgText = class extends PgColumn {
	static [entityKind] = "PgText";
	enumValues = this.config.enumValues;
	getSQLType() {
		return "text";
	}
};
function text$1(a, b = {}) {
	const { name, config } = getColumnNameAndConfig(a, b);
	return new PgTextBuilder(name, config);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/time.js
var PgTimeBuilder = class extends PgDateColumnBaseBuilder {
	constructor(name, withTimezone, precision) {
		super(name, "string", "PgTime");
		this.withTimezone = withTimezone;
		this.precision = precision;
		this.config.withTimezone = withTimezone;
		this.config.precision = precision;
	}
	static [entityKind] = "PgTimeBuilder";
	/** @internal */
	build(table) {
		return new PgTime(table, this.config);
	}
};
var PgTime = class extends PgColumn {
	static [entityKind] = "PgTime";
	withTimezone;
	precision;
	constructor(table, config) {
		super(table, config);
		this.withTimezone = config.withTimezone;
		this.precision = config.precision;
	}
	getSQLType() {
		return `time${this.precision === void 0 ? "" : `(${this.precision})`}${this.withTimezone ? " with time zone" : ""}`;
	}
};
function time(a, b = {}) {
	const { name, config } = getColumnNameAndConfig(a, b);
	return new PgTimeBuilder(name, config.withTimezone ?? false, config.precision);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/timestamp.js
var PgTimestampBuilder = class extends PgDateColumnBaseBuilder {
	static [entityKind] = "PgTimestampBuilder";
	constructor(name, withTimezone, precision) {
		super(name, "date", "PgTimestamp");
		this.config.withTimezone = withTimezone;
		this.config.precision = precision;
	}
	/** @internal */
	build(table) {
		return new PgTimestamp(table, this.config);
	}
};
var PgTimestamp = class extends PgColumn {
	static [entityKind] = "PgTimestamp";
	withTimezone;
	precision;
	constructor(table, config) {
		super(table, config);
		this.withTimezone = config.withTimezone;
		this.precision = config.precision;
	}
	getSQLType() {
		return `timestamp${this.precision === void 0 ? "" : ` (${this.precision})`}${this.withTimezone ? " with time zone" : ""}`;
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") return new Date(this.withTimezone ? value : value + "+0000");
		return value;
	}
	mapToDriverValue = (value) => {
		return value.toISOString();
	};
};
var PgTimestampStringBuilder = class extends PgDateColumnBaseBuilder {
	static [entityKind] = "PgTimestampStringBuilder";
	constructor(name, withTimezone, precision) {
		super(name, "string", "PgTimestampString");
		this.config.withTimezone = withTimezone;
		this.config.precision = precision;
	}
	/** @internal */
	build(table) {
		return new PgTimestampString(table, this.config);
	}
};
var PgTimestampString = class extends PgColumn {
	static [entityKind] = "PgTimestampString";
	withTimezone;
	precision;
	constructor(table, config) {
		super(table, config);
		this.withTimezone = config.withTimezone;
		this.precision = config.precision;
	}
	getSQLType() {
		return `timestamp${this.precision === void 0 ? "" : `(${this.precision})`}${this.withTimezone ? " with time zone" : ""}`;
	}
	mapFromDriverValue(value) {
		if (typeof value === "string") return value;
		const shortened = value.toISOString().slice(0, -1).replace("T", " ");
		if (this.withTimezone) {
			const offset = value.getTimezoneOffset();
			return `${shortened}${offset <= 0 ? "+" : "-"}${Math.floor(Math.abs(offset) / 60).toString().padStart(2, "0")}`;
		}
		return shortened;
	}
};
function timestamp(a, b = {}) {
	const { name, config } = getColumnNameAndConfig(a, b);
	if (config?.mode === "string") return new PgTimestampStringBuilder(name, config.withTimezone ?? false, config.precision);
	return new PgTimestampBuilder(name, config?.withTimezone ?? false, config?.precision);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/uuid.js
var PgUUIDBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgUUIDBuilder";
	constructor(name) {
		super(name, "string", "PgUUID");
	}
	/**
	* Adds `default gen_random_uuid()` to the column definition.
	*/
	defaultRandom() {
		return this.default(sql`gen_random_uuid()`);
	}
	/** @internal */
	build(table) {
		return new PgUUID(table, this.config);
	}
};
var PgUUID = class extends PgColumn {
	static [entityKind] = "PgUUID";
	getSQLType() {
		return "uuid";
	}
};
function uuid(name) {
	return new PgUUIDBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/varchar.js
var PgVarcharBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgVarcharBuilder";
	constructor(name, config) {
		super(name, "string", "PgVarchar");
		this.config.length = config.length;
		this.config.enumValues = config.enum;
	}
	/** @internal */
	build(table) {
		return new PgVarchar(table, this.config);
	}
};
var PgVarchar = class extends PgColumn {
	static [entityKind] = "PgVarchar";
	length = this.config.length;
	enumValues = this.config.enumValues;
	getSQLType() {
		return this.length === void 0 ? `varchar` : `varchar(${this.length})`;
	}
};
function varchar(a, b = {}) {
	const { name, config } = getColumnNameAndConfig(a, b);
	return new PgVarcharBuilder(name, config);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/vector_extension/bit.js
var PgBinaryVectorBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgBinaryVectorBuilder";
	constructor(name, config) {
		super(name, "string", "PgBinaryVector");
		this.config.dimensions = config.dimensions;
	}
	/** @internal */
	build(table) {
		return new PgBinaryVector(table, this.config);
	}
};
var PgBinaryVector = class extends PgColumn {
	static [entityKind] = "PgBinaryVector";
	dimensions = this.config.dimensions;
	getSQLType() {
		return `bit(${this.dimensions})`;
	}
};
function bit(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	return new PgBinaryVectorBuilder(name, config);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/vector_extension/halfvec.js
var PgHalfVectorBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgHalfVectorBuilder";
	constructor(name, config) {
		super(name, "array", "PgHalfVector");
		this.config.dimensions = config.dimensions;
	}
	/** @internal */
	build(table) {
		return new PgHalfVector(table, this.config);
	}
};
var PgHalfVector = class extends PgColumn {
	static [entityKind] = "PgHalfVector";
	dimensions = this.config.dimensions;
	getSQLType() {
		return `halfvec(${this.dimensions})`;
	}
	mapToDriverValue(value) {
		return JSON.stringify(value);
	}
	mapFromDriverValue(value) {
		return value.slice(1, -1).split(",").map((v) => Number.parseFloat(v));
	}
};
function halfvec(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	return new PgHalfVectorBuilder(name, config);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/vector_extension/sparsevec.js
var PgSparseVectorBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgSparseVectorBuilder";
	constructor(name, config) {
		super(name, "string", "PgSparseVector");
		this.config.dimensions = config.dimensions;
	}
	/** @internal */
	build(table) {
		return new PgSparseVector(table, this.config);
	}
};
var PgSparseVector = class extends PgColumn {
	static [entityKind] = "PgSparseVector";
	dimensions = this.config.dimensions;
	getSQLType() {
		return `sparsevec(${this.dimensions})`;
	}
};
function sparsevec(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	return new PgSparseVectorBuilder(name, config);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/vector_extension/vector.js
var PgVectorBuilder = class extends PgColumnBuilder {
	static [entityKind] = "PgVectorBuilder";
	constructor(name, config) {
		super(name, "array", "PgVector");
		this.config.dimensions = config.dimensions;
	}
	/** @internal */
	build(table) {
		return new PgVector(table, this.config);
	}
};
var PgVector = class extends PgColumn {
	static [entityKind] = "PgVector";
	dimensions = this.config.dimensions;
	getSQLType() {
		return `vector(${this.dimensions})`;
	}
	mapToDriverValue(value) {
		return JSON.stringify(value);
	}
	mapFromDriverValue(value) {
		return value.slice(1, -1).split(",").map((v) => Number.parseFloat(v));
	}
};
function vector(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	return new PgVectorBuilder(name, config);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/columns/all.js
function getPgColumnBuilders() {
	return {
		bigint,
		bigserial,
		boolean,
		char,
		cidr,
		customType: customType$1,
		date,
		doublePrecision,
		inet,
		integer: integer$1,
		interval,
		json,
		jsonb,
		line,
		macaddr,
		macaddr8,
		numeric: numeric$1,
		point,
		geometry,
		real: real$1,
		serial,
		smallint,
		smallserial,
		text: text$1,
		time,
		timestamp,
		uuid,
		varchar,
		bit,
		halfvec,
		sparsevec,
		vector
	};
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/table.js
var InlineForeignKeys$1 = Symbol.for("drizzle:PgInlineForeignKeys");
var EnableRLS = Symbol.for("drizzle:EnableRLS");
var PgTable = class extends Table {
	static [entityKind] = "PgTable";
	/** @internal */
	static Symbol = Object.assign({}, Table.Symbol, {
		InlineForeignKeys: InlineForeignKeys$1,
		EnableRLS
	});
	/**@internal */
	[InlineForeignKeys$1] = [];
	/** @internal */
	[EnableRLS] = false;
	/** @internal */
	[Table.Symbol.ExtraConfigBuilder] = void 0;
	/** @internal */
	[Table.Symbol.ExtraConfigColumns] = {};
};
function pgTableWithSchema(name, columns, extraConfig, schema, baseName = name) {
	const rawTable = new PgTable(name, schema, baseName);
	const parsedColumns = typeof columns === "function" ? columns(getPgColumnBuilders()) : columns;
	const builtColumns = Object.fromEntries(Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
		const colBuilder = colBuilderBase;
		colBuilder.setName(name2);
		const column = colBuilder.build(rawTable);
		rawTable[InlineForeignKeys$1].push(...colBuilder.buildForeignKeys(column, rawTable));
		return [name2, column];
	}));
	const builtColumnsForExtraConfig = Object.fromEntries(Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
		const colBuilder = colBuilderBase;
		colBuilder.setName(name2);
		return [name2, colBuilder.buildExtraConfigColumn(rawTable)];
	}));
	const table = Object.assign(rawTable, builtColumns);
	table[Table.Symbol.Columns] = builtColumns;
	table[Table.Symbol.ExtraConfigColumns] = builtColumnsForExtraConfig;
	if (extraConfig) table[PgTable.Symbol.ExtraConfigBuilder] = extraConfig;
	return Object.assign(table, { enableRLS: () => {
		table[PgTable.Symbol.EnableRLS] = true;
		return table;
	} });
}
var pgTable = (name, columns, extraConfig) => {
	return pgTableWithSchema(name, columns, extraConfig, void 0);
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/primary-keys.js
function primaryKey$1(...config) {
	if (config[0].columns) return new PrimaryKeyBuilder$1(config[0].columns, config[0].name);
	return new PrimaryKeyBuilder$1(config);
}
var PrimaryKeyBuilder$1 = class {
	static [entityKind] = "PgPrimaryKeyBuilder";
	/** @internal */
	columns;
	/** @internal */
	name;
	constructor(columns, name) {
		this.columns = columns;
		this.name = name;
	}
	/** @internal */
	build(table) {
		return new PrimaryKey$1(table, this.columns, this.name);
	}
};
var PrimaryKey$1 = class {
	constructor(table, columns, name) {
		this.table = table;
		this.columns = columns;
		this.name = name;
	}
	static [entityKind] = "PgPrimaryKey";
	columns;
	name;
	getName() {
		return this.name ?? `${this.table[PgTable.Symbol.Name]}_${this.columns.map((column) => column.name).join("_")}_pk`;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sql/expressions/conditions.js
function bindIfParam(value, column) {
	if (isDriverValueEncoder(column) && !isSQLWrapper(value) && !is(value, Param) && !is(value, Placeholder) && !is(value, Column) && !is(value, Table) && !is(value, View)) return new Param(value, column);
	return value;
}
var eq = (left, right) => {
	return sql`${left} = ${bindIfParam(right, left)}`;
};
var ne = (left, right) => {
	return sql`${left} <> ${bindIfParam(right, left)}`;
};
function and(...unfilteredConditions) {
	const conditions = unfilteredConditions.filter((c) => c !== void 0);
	if (conditions.length === 0) return;
	if (conditions.length === 1) return new SQL(conditions);
	return new SQL([
		new StringChunk("("),
		sql.join(conditions, new StringChunk(" and ")),
		new StringChunk(")")
	]);
}
function or(...unfilteredConditions) {
	const conditions = unfilteredConditions.filter((c) => c !== void 0);
	if (conditions.length === 0) return;
	if (conditions.length === 1) return new SQL(conditions);
	return new SQL([
		new StringChunk("("),
		sql.join(conditions, new StringChunk(" or ")),
		new StringChunk(")")
	]);
}
function not(condition) {
	return sql`not ${condition}`;
}
var gt = (left, right) => {
	return sql`${left} > ${bindIfParam(right, left)}`;
};
var gte = (left, right) => {
	return sql`${left} >= ${bindIfParam(right, left)}`;
};
var lt = (left, right) => {
	return sql`${left} < ${bindIfParam(right, left)}`;
};
var lte = (left, right) => {
	return sql`${left} <= ${bindIfParam(right, left)}`;
};
function inArray(column, values) {
	if (Array.isArray(values)) {
		if (values.length === 0) return sql`false`;
		return sql`${column} in ${values.map((v) => bindIfParam(v, column))}`;
	}
	return sql`${column} in ${bindIfParam(values, column)}`;
}
function notInArray(column, values) {
	if (Array.isArray(values)) {
		if (values.length === 0) return sql`true`;
		return sql`${column} not in ${values.map((v) => bindIfParam(v, column))}`;
	}
	return sql`${column} not in ${bindIfParam(values, column)}`;
}
function isNull(value) {
	return sql`${value} is null`;
}
function isNotNull(value) {
	return sql`${value} is not null`;
}
function exists(subquery) {
	return sql`exists ${subquery}`;
}
function notExists(subquery) {
	return sql`not exists ${subquery}`;
}
function between(column, min, max) {
	return sql`${column} between ${bindIfParam(min, column)} and ${bindIfParam(max, column)}`;
}
function notBetween(column, min, max) {
	return sql`${column} not between ${bindIfParam(min, column)} and ${bindIfParam(max, column)}`;
}
function like(column, value) {
	return sql`${column} like ${value}`;
}
function notLike(column, value) {
	return sql`${column} not like ${value}`;
}
function ilike(column, value) {
	return sql`${column} ilike ${value}`;
}
function notIlike(column, value) {
	return sql`${column} not ilike ${value}`;
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sql/expressions/select.js
function asc(column) {
	return sql`${column} asc`;
}
function desc(column) {
	return sql`${column} desc`;
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/relations.js
var Relation = class {
	constructor(sourceTable, referencedTable, relationName) {
		this.sourceTable = sourceTable;
		this.referencedTable = referencedTable;
		this.relationName = relationName;
		this.referencedTableName = referencedTable[Table.Symbol.Name];
	}
	static [entityKind] = "Relation";
	referencedTableName;
	fieldName;
};
var Relations = class {
	constructor(table, config) {
		this.table = table;
		this.config = config;
	}
	static [entityKind] = "Relations";
};
var One = class One extends Relation {
	constructor(sourceTable, referencedTable, config, isNullable) {
		super(sourceTable, referencedTable, config?.relationName);
		this.config = config;
		this.isNullable = isNullable;
	}
	static [entityKind] = "One";
	withFieldName(fieldName) {
		const relation = new One(this.sourceTable, this.referencedTable, this.config, this.isNullable);
		relation.fieldName = fieldName;
		return relation;
	}
};
var Many = class Many extends Relation {
	constructor(sourceTable, referencedTable, config) {
		super(sourceTable, referencedTable, config?.relationName);
		this.config = config;
	}
	static [entityKind] = "Many";
	withFieldName(fieldName) {
		const relation = new Many(this.sourceTable, this.referencedTable, this.config);
		relation.fieldName = fieldName;
		return relation;
	}
};
function getOperators() {
	return {
		and,
		between,
		eq,
		exists,
		gt,
		gte,
		ilike,
		inArray,
		isNull,
		isNotNull,
		like,
		lt,
		lte,
		ne,
		not,
		notBetween,
		notExists,
		notLike,
		notIlike,
		notInArray,
		or,
		sql
	};
}
function getOrderByOperators() {
	return {
		sql,
		asc,
		desc
	};
}
function extractTablesRelationalConfig(schema, configHelpers) {
	if (Object.keys(schema).length === 1 && "default" in schema && !is(schema["default"], Table)) schema = schema["default"];
	const tableNamesMap = {};
	const relationsBuffer = {};
	const tablesConfig = {};
	for (const [key, value] of Object.entries(schema)) if (is(value, Table)) {
		const dbName = getTableUniqueName(value);
		const bufferedRelations = relationsBuffer[dbName];
		tableNamesMap[dbName] = key;
		tablesConfig[key] = {
			tsName: key,
			dbName: value[Table.Symbol.Name],
			schema: value[Table.Symbol.Schema],
			columns: value[Table.Symbol.Columns],
			relations: bufferedRelations?.relations ?? {},
			primaryKey: bufferedRelations?.primaryKey ?? []
		};
		for (const column of Object.values(value[Table.Symbol.Columns])) if (column.primary) tablesConfig[key].primaryKey.push(column);
		const extraConfig = value[Table.Symbol.ExtraConfigBuilder]?.(value[Table.Symbol.ExtraConfigColumns]);
		if (extraConfig) {
			for (const configEntry of Object.values(extraConfig)) if (is(configEntry, PrimaryKeyBuilder$1)) tablesConfig[key].primaryKey.push(...configEntry.columns);
		}
	} else if (is(value, Relations)) {
		const dbName = getTableUniqueName(value.table);
		const tableName = tableNamesMap[dbName];
		const relations2 = value.config(configHelpers(value.table));
		let primaryKey;
		for (const [relationName, relation] of Object.entries(relations2)) if (tableName) {
			const tableConfig = tablesConfig[tableName];
			tableConfig.relations[relationName] = relation;
		} else {
			if (!(dbName in relationsBuffer)) relationsBuffer[dbName] = {
				relations: {},
				primaryKey
			};
			relationsBuffer[dbName].relations[relationName] = relation;
		}
	}
	return {
		tables: tablesConfig,
		tableNamesMap
	};
}
function relations(table, relations2) {
	return new Relations(table, (helpers) => Object.fromEntries(Object.entries(relations2(helpers)).map(([key, value]) => [key, value.withFieldName(key)])));
}
function createOne(sourceTable) {
	return function one(table, config) {
		return new One(sourceTable, table, config, config?.fields.reduce((res, f) => res && f.notNull, true) ?? false);
	};
}
function createMany(sourceTable) {
	return function many(referencedTable, config) {
		return new Many(sourceTable, referencedTable, config);
	};
}
function normalizeRelation(schema, tableNamesMap, relation) {
	if (is(relation, One) && relation.config) return {
		fields: relation.config.fields,
		references: relation.config.references
	};
	const referencedTableTsName = tableNamesMap[getTableUniqueName(relation.referencedTable)];
	if (!referencedTableTsName) throw new Error(`Table "${relation.referencedTable[Table.Symbol.Name]}" not found in schema`);
	const referencedTableConfig = schema[referencedTableTsName];
	if (!referencedTableConfig) throw new Error(`Table "${referencedTableTsName}" not found in schema`);
	const sourceTable = relation.sourceTable;
	const sourceTableTsName = tableNamesMap[getTableUniqueName(sourceTable)];
	if (!sourceTableTsName) throw new Error(`Table "${sourceTable[Table.Symbol.Name]}" not found in schema`);
	const reverseRelations = [];
	for (const referencedTableRelation of Object.values(referencedTableConfig.relations)) if (relation.relationName && relation !== referencedTableRelation && referencedTableRelation.relationName === relation.relationName || !relation.relationName && referencedTableRelation.referencedTable === relation.sourceTable) reverseRelations.push(referencedTableRelation);
	if (reverseRelations.length > 1) throw relation.relationName ? /* @__PURE__ */ new Error(`There are multiple relations with name "${relation.relationName}" in table "${referencedTableTsName}"`) : /* @__PURE__ */ new Error(`There are multiple relations between "${referencedTableTsName}" and "${relation.sourceTable[Table.Symbol.Name]}". Please specify relation name`);
	if (reverseRelations[0] && is(reverseRelations[0], One) && reverseRelations[0].config) return {
		fields: reverseRelations[0].config.references,
		references: reverseRelations[0].config.fields
	};
	throw new Error(`There is not enough information to infer relation "${sourceTableTsName}.${relation.fieldName}"`);
}
function createTableRelationsHelpers(sourceTable) {
	return {
		one: createOne(sourceTable),
		many: createMany(sourceTable)
	};
}
function mapRelationalRow(tablesConfig, tableConfig, row, buildQueryResultSelection, mapColumnValue = (value) => value) {
	const result = {};
	for (const [selectionItemIndex, selectionItem] of buildQueryResultSelection.entries()) if (selectionItem.isJson) {
		const relation = tableConfig.relations[selectionItem.tsKey];
		const rawSubRows = row[selectionItemIndex];
		const subRows = typeof rawSubRows === "string" ? JSON.parse(rawSubRows) : rawSubRows;
		result[selectionItem.tsKey] = is(relation, One) ? subRows && mapRelationalRow(tablesConfig, tablesConfig[selectionItem.relationTableTsKey], subRows, selectionItem.selection, mapColumnValue) : subRows.map((subRow) => mapRelationalRow(tablesConfig, tablesConfig[selectionItem.relationTableTsKey], subRow, selectionItem.selection, mapColumnValue));
	} else {
		const value = mapColumnValue(row[selectionItemIndex]);
		const field = selectionItem.field;
		let decoder;
		if (is(field, Column)) decoder = field;
		else if (is(field, SQL)) decoder = field.decoder;
		else decoder = field.sql.decoder;
		result[selectionItem.tsKey] = value === null ? null : decoder.mapFromDriverValue(value);
	}
	return result;
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/alias.js
var ColumnAliasProxyHandler = class {
	constructor(table) {
		this.table = table;
	}
	static [entityKind] = "ColumnAliasProxyHandler";
	get(columnObj, prop) {
		if (prop === "table") return this.table;
		return columnObj[prop];
	}
};
var TableAliasProxyHandler = class {
	constructor(alias, replaceOriginalName) {
		this.alias = alias;
		this.replaceOriginalName = replaceOriginalName;
	}
	static [entityKind] = "TableAliasProxyHandler";
	get(target, prop) {
		if (prop === Table.Symbol.IsAlias) return true;
		if (prop === Table.Symbol.Name) return this.alias;
		if (this.replaceOriginalName && prop === Table.Symbol.OriginalName) return this.alias;
		if (prop === ViewBaseConfig) return {
			...target[ViewBaseConfig],
			name: this.alias,
			isAlias: true
		};
		if (prop === Table.Symbol.Columns) {
			const columns = target[Table.Symbol.Columns];
			if (!columns) return columns;
			const proxiedColumns = {};
			Object.keys(columns).map((key) => {
				proxiedColumns[key] = new Proxy(columns[key], new ColumnAliasProxyHandler(new Proxy(target, this)));
			});
			return proxiedColumns;
		}
		const value = target[prop];
		if (is(value, Column)) return new Proxy(value, new ColumnAliasProxyHandler(new Proxy(target, this)));
		return value;
	}
};
function aliasedTable(table, tableAlias) {
	return new Proxy(table, new TableAliasProxyHandler(tableAlias, false));
}
function aliasedTableColumn(column, tableAlias) {
	return new Proxy(column, new ColumnAliasProxyHandler(new Proxy(column.table, new TableAliasProxyHandler(tableAlias, false))));
}
function mapColumnsInAliasedSQLToAlias(query, alias) {
	return new SQL.Aliased(mapColumnsInSQLToAlias(query.sql, alias), query.fieldAlias);
}
function mapColumnsInSQLToAlias(query, alias) {
	return sql.join(query.queryChunks.map((c) => {
		if (is(c, Column)) return aliasedTableColumn(c, alias);
		if (is(c, SQL)) return mapColumnsInSQLToAlias(c, alias);
		if (is(c, SQL.Aliased)) return mapColumnsInAliasedSQLToAlias(c, alias);
		return c;
	}));
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/selection-proxy.js
var SelectionProxyHandler = class SelectionProxyHandler {
	static [entityKind] = "SelectionProxyHandler";
	config;
	constructor(config) {
		this.config = { ...config };
	}
	get(subquery, prop) {
		if (prop === "_") return {
			...subquery["_"],
			selectedFields: new Proxy(subquery._.selectedFields, this)
		};
		if (prop === ViewBaseConfig) return {
			...subquery[ViewBaseConfig],
			selectedFields: new Proxy(subquery[ViewBaseConfig].selectedFields, this)
		};
		if (typeof prop === "symbol") return subquery[prop];
		const value = (is(subquery, Subquery) ? subquery._.selectedFields : is(subquery, View) ? subquery[ViewBaseConfig].selectedFields : subquery)[prop];
		if (is(value, SQL.Aliased)) {
			if (this.config.sqlAliasedBehavior === "sql" && !value.isSelectionField) return value.sql;
			const newValue = value.clone();
			newValue.isSelectionField = true;
			return newValue;
		}
		if (is(value, SQL)) {
			if (this.config.sqlBehavior === "sql") return value;
			throw new Error(`You tried to reference "${prop}" field from a subquery, which is a raw SQL field, but it doesn't have an alias declared. Please add an alias to the field using ".as('alias')" method.`);
		}
		if (is(value, Column)) {
			if (this.config.alias) return new Proxy(value, new ColumnAliasProxyHandler(new Proxy(value.table, new TableAliasProxyHandler(this.config.alias, this.config.replaceOriginalName ?? false))));
			return value;
		}
		if (typeof value !== "object" || value === null) return value;
		return new Proxy(value, new SelectionProxyHandler(this.config));
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/query-promise.js
var QueryPromise = class {
	static [entityKind] = "QueryPromise";
	[Symbol.toStringTag] = "QueryPromise";
	catch(onRejected) {
		return this.then(void 0, onRejected);
	}
	finally(onFinally) {
		return this.then((value) => {
			onFinally?.();
			return value;
		}, (reason) => {
			onFinally?.();
			throw reason;
		});
	}
	then(onFulfilled, onRejected) {
		return this.execute().then(onFulfilled, onRejected);
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/foreign-keys.js
var ForeignKeyBuilder = class {
	static [entityKind] = "SQLiteForeignKeyBuilder";
	/** @internal */
	reference;
	/** @internal */
	_onUpdate;
	/** @internal */
	_onDelete;
	constructor(config, actions) {
		this.reference = () => {
			const { name, columns, foreignColumns } = config();
			return {
				name,
				columns,
				foreignTable: foreignColumns[0].table,
				foreignColumns
			};
		};
		if (actions) {
			this._onUpdate = actions.onUpdate;
			this._onDelete = actions.onDelete;
		}
	}
	onUpdate(action) {
		this._onUpdate = action;
		return this;
	}
	onDelete(action) {
		this._onDelete = action;
		return this;
	}
	/** @internal */
	build(table) {
		return new ForeignKey(table, this);
	}
};
var ForeignKey = class {
	constructor(table, builder) {
		this.table = table;
		this.reference = builder.reference;
		this.onUpdate = builder._onUpdate;
		this.onDelete = builder._onDelete;
	}
	static [entityKind] = "SQLiteForeignKey";
	reference;
	onUpdate;
	onDelete;
	getName() {
		const { name, columns, foreignColumns } = this.reference();
		const columnNames = columns.map((column) => column.name);
		const foreignColumnNames = foreignColumns.map((column) => column.name);
		const chunks = [
			this.table[TableName],
			...columnNames,
			foreignColumns[0].table[TableName],
			...foreignColumnNames
		];
		return name ?? `${chunks.join("_")}_fk`;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/unique-constraint.js
function uniqueKeyName(table, columns) {
	return `${table[TableName]}_${columns.join("_")}_unique`;
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/columns/common.js
var SQLiteColumnBuilder = class extends ColumnBuilder {
	static [entityKind] = "SQLiteColumnBuilder";
	foreignKeyConfigs = [];
	references(ref, actions = {}) {
		this.foreignKeyConfigs.push({
			ref,
			actions
		});
		return this;
	}
	unique(name) {
		this.config.isUnique = true;
		this.config.uniqueName = name;
		return this;
	}
	generatedAlwaysAs(as, config) {
		this.config.generated = {
			as,
			type: "always",
			mode: config?.mode ?? "virtual"
		};
		return this;
	}
	/** @internal */
	buildForeignKeys(column, table) {
		return this.foreignKeyConfigs.map(({ ref, actions }) => {
			return ((ref2, actions2) => {
				const builder = new ForeignKeyBuilder(() => {
					const foreignColumn = ref2();
					return {
						columns: [column],
						foreignColumns: [foreignColumn]
					};
				});
				if (actions2.onUpdate) builder.onUpdate(actions2.onUpdate);
				if (actions2.onDelete) builder.onDelete(actions2.onDelete);
				return builder.build(table);
			})(ref, actions);
		});
	}
};
var SQLiteColumn = class extends Column {
	constructor(table, config) {
		if (!config.uniqueName) config.uniqueName = uniqueKeyName(table, [config.name]);
		super(table, config);
		this.table = table;
	}
	static [entityKind] = "SQLiteColumn";
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/columns/blob.js
var SQLiteBigIntBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteBigIntBuilder";
	constructor(name) {
		super(name, "bigint", "SQLiteBigInt");
	}
	/** @internal */
	build(table) {
		return new SQLiteBigInt(table, this.config);
	}
};
var SQLiteBigInt = class extends SQLiteColumn {
	static [entityKind] = "SQLiteBigInt";
	getSQLType() {
		return "blob";
	}
	mapFromDriverValue(value) {
		if (typeof Buffer !== "undefined" && Buffer.from) {
			const buf = Buffer.isBuffer(value) ? value : value instanceof ArrayBuffer ? Buffer.from(value) : value.buffer ? Buffer.from(value.buffer, value.byteOffset, value.byteLength) : Buffer.from(value);
			return BigInt(buf.toString("utf8"));
		}
		return BigInt(textDecoder.decode(value));
	}
	mapToDriverValue(value) {
		return Buffer.from(value.toString());
	}
};
var SQLiteBlobJsonBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteBlobJsonBuilder";
	constructor(name) {
		super(name, "json", "SQLiteBlobJson");
	}
	/** @internal */
	build(table) {
		return new SQLiteBlobJson(table, this.config);
	}
};
var SQLiteBlobJson = class extends SQLiteColumn {
	static [entityKind] = "SQLiteBlobJson";
	getSQLType() {
		return "blob";
	}
	mapFromDriverValue(value) {
		if (typeof Buffer !== "undefined" && Buffer.from) {
			const buf = Buffer.isBuffer(value) ? value : value instanceof ArrayBuffer ? Buffer.from(value) : value.buffer ? Buffer.from(value.buffer, value.byteOffset, value.byteLength) : Buffer.from(value);
			return JSON.parse(buf.toString("utf8"));
		}
		return JSON.parse(textDecoder.decode(value));
	}
	mapToDriverValue(value) {
		return Buffer.from(JSON.stringify(value));
	}
};
var SQLiteBlobBufferBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteBlobBufferBuilder";
	constructor(name) {
		super(name, "buffer", "SQLiteBlobBuffer");
	}
	/** @internal */
	build(table) {
		return new SQLiteBlobBuffer(table, this.config);
	}
};
var SQLiteBlobBuffer = class extends SQLiteColumn {
	static [entityKind] = "SQLiteBlobBuffer";
	mapFromDriverValue(value) {
		if (Buffer.isBuffer(value)) return value;
		return Buffer.from(value);
	}
	getSQLType() {
		return "blob";
	}
};
function blob(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	if (config?.mode === "json") return new SQLiteBlobJsonBuilder(name);
	if (config?.mode === "bigint") return new SQLiteBigIntBuilder(name);
	return new SQLiteBlobBufferBuilder(name);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/columns/custom.js
var SQLiteCustomColumnBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteCustomColumnBuilder";
	constructor(name, fieldConfig, customTypeParams) {
		super(name, "custom", "SQLiteCustomColumn");
		this.config.fieldConfig = fieldConfig;
		this.config.customTypeParams = customTypeParams;
	}
	/** @internal */
	build(table) {
		return new SQLiteCustomColumn(table, this.config);
	}
};
var SQLiteCustomColumn = class extends SQLiteColumn {
	static [entityKind] = "SQLiteCustomColumn";
	sqlName;
	mapTo;
	mapFrom;
	constructor(table, config) {
		super(table, config);
		this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
		this.mapTo = config.customTypeParams.toDriver;
		this.mapFrom = config.customTypeParams.fromDriver;
	}
	getSQLType() {
		return this.sqlName;
	}
	mapFromDriverValue(value) {
		return typeof this.mapFrom === "function" ? this.mapFrom(value) : value;
	}
	mapToDriverValue(value) {
		return typeof this.mapTo === "function" ? this.mapTo(value) : value;
	}
};
function customType(customTypeParams) {
	return (a, b) => {
		const { name, config } = getColumnNameAndConfig(a, b);
		return new SQLiteCustomColumnBuilder(name, config, customTypeParams);
	};
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/columns/integer.js
var SQLiteBaseIntegerBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteBaseIntegerBuilder";
	constructor(name, dataType, columnType) {
		super(name, dataType, columnType);
		this.config.autoIncrement = false;
	}
	primaryKey(config) {
		if (config?.autoIncrement) this.config.autoIncrement = true;
		this.config.hasDefault = true;
		return super.primaryKey();
	}
};
var SQLiteBaseInteger = class extends SQLiteColumn {
	static [entityKind] = "SQLiteBaseInteger";
	autoIncrement = this.config.autoIncrement;
	getSQLType() {
		return "integer";
	}
};
var SQLiteIntegerBuilder = class extends SQLiteBaseIntegerBuilder {
	static [entityKind] = "SQLiteIntegerBuilder";
	constructor(name) {
		super(name, "number", "SQLiteInteger");
	}
	build(table) {
		return new SQLiteInteger(table, this.config);
	}
};
var SQLiteInteger = class extends SQLiteBaseInteger {
	static [entityKind] = "SQLiteInteger";
};
var SQLiteTimestampBuilder = class extends SQLiteBaseIntegerBuilder {
	static [entityKind] = "SQLiteTimestampBuilder";
	constructor(name, mode) {
		super(name, "date", "SQLiteTimestamp");
		this.config.mode = mode;
	}
	/**
	* @deprecated Use `default()` with your own expression instead.
	*
	* Adds `DEFAULT (cast((julianday('now') - 2440587.5)*86400000 as integer))` to the column, which is the current epoch timestamp in milliseconds.
	*/
	defaultNow() {
		return this.default(sql`(cast((julianday('now') - 2440587.5)*86400000 as integer))`);
	}
	build(table) {
		return new SQLiteTimestamp(table, this.config);
	}
};
var SQLiteTimestamp = class extends SQLiteBaseInteger {
	static [entityKind] = "SQLiteTimestamp";
	mode = this.config.mode;
	mapFromDriverValue(value) {
		if (this.config.mode === "timestamp") return /* @__PURE__ */ new Date(value * 1e3);
		return new Date(value);
	}
	mapToDriverValue(value) {
		const unix = value.getTime();
		if (this.config.mode === "timestamp") return Math.floor(unix / 1e3);
		return unix;
	}
};
var SQLiteBooleanBuilder = class extends SQLiteBaseIntegerBuilder {
	static [entityKind] = "SQLiteBooleanBuilder";
	constructor(name, mode) {
		super(name, "boolean", "SQLiteBoolean");
		this.config.mode = mode;
	}
	build(table) {
		return new SQLiteBoolean(table, this.config);
	}
};
var SQLiteBoolean = class extends SQLiteBaseInteger {
	static [entityKind] = "SQLiteBoolean";
	mode = this.config.mode;
	mapFromDriverValue(value) {
		return Number(value) === 1;
	}
	mapToDriverValue(value) {
		return value ? 1 : 0;
	}
};
function integer(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	if (config?.mode === "timestamp" || config?.mode === "timestamp_ms") return new SQLiteTimestampBuilder(name, config.mode);
	if (config?.mode === "boolean") return new SQLiteBooleanBuilder(name, config.mode);
	return new SQLiteIntegerBuilder(name);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/columns/numeric.js
var SQLiteNumericBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteNumericBuilder";
	constructor(name) {
		super(name, "string", "SQLiteNumeric");
	}
	/** @internal */
	build(table) {
		return new SQLiteNumeric(table, this.config);
	}
};
var SQLiteNumeric = class extends SQLiteColumn {
	static [entityKind] = "SQLiteNumeric";
	mapFromDriverValue(value) {
		if (typeof value === "string") return value;
		return String(value);
	}
	getSQLType() {
		return "numeric";
	}
};
var SQLiteNumericNumberBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteNumericNumberBuilder";
	constructor(name) {
		super(name, "number", "SQLiteNumericNumber");
	}
	/** @internal */
	build(table) {
		return new SQLiteNumericNumber(table, this.config);
	}
};
var SQLiteNumericNumber = class extends SQLiteColumn {
	static [entityKind] = "SQLiteNumericNumber";
	mapFromDriverValue(value) {
		if (typeof value === "number") return value;
		return Number(value);
	}
	mapToDriverValue = String;
	getSQLType() {
		return "numeric";
	}
};
var SQLiteNumericBigIntBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteNumericBigIntBuilder";
	constructor(name) {
		super(name, "bigint", "SQLiteNumericBigInt");
	}
	/** @internal */
	build(table) {
		return new SQLiteNumericBigInt(table, this.config);
	}
};
var SQLiteNumericBigInt = class extends SQLiteColumn {
	static [entityKind] = "SQLiteNumericBigInt";
	mapFromDriverValue = BigInt;
	mapToDriverValue = String;
	getSQLType() {
		return "numeric";
	}
};
function numeric(a, b) {
	const { name, config } = getColumnNameAndConfig(a, b);
	const mode = config?.mode;
	return mode === "number" ? new SQLiteNumericNumberBuilder(name) : mode === "bigint" ? new SQLiteNumericBigIntBuilder(name) : new SQLiteNumericBuilder(name);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/columns/real.js
var SQLiteRealBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteRealBuilder";
	constructor(name) {
		super(name, "number", "SQLiteReal");
	}
	/** @internal */
	build(table) {
		return new SQLiteReal(table, this.config);
	}
};
var SQLiteReal = class extends SQLiteColumn {
	static [entityKind] = "SQLiteReal";
	getSQLType() {
		return "real";
	}
};
function real(name) {
	return new SQLiteRealBuilder(name ?? "");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/columns/text.js
var SQLiteTextBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteTextBuilder";
	constructor(name, config) {
		super(name, "string", "SQLiteText");
		this.config.enumValues = config.enum;
		this.config.length = config.length;
	}
	/** @internal */
	build(table) {
		return new SQLiteText(table, this.config);
	}
};
var SQLiteText = class extends SQLiteColumn {
	static [entityKind] = "SQLiteText";
	enumValues = this.config.enumValues;
	length = this.config.length;
	constructor(table, config) {
		super(table, config);
	}
	getSQLType() {
		return `text${this.config.length ? `(${this.config.length})` : ""}`;
	}
};
var SQLiteTextJsonBuilder = class extends SQLiteColumnBuilder {
	static [entityKind] = "SQLiteTextJsonBuilder";
	constructor(name) {
		super(name, "json", "SQLiteTextJson");
	}
	/** @internal */
	build(table) {
		return new SQLiteTextJson(table, this.config);
	}
};
var SQLiteTextJson = class extends SQLiteColumn {
	static [entityKind] = "SQLiteTextJson";
	getSQLType() {
		return "text";
	}
	mapFromDriverValue(value) {
		return JSON.parse(value);
	}
	mapToDriverValue(value) {
		return JSON.stringify(value);
	}
};
function text(a, b = {}) {
	const { name, config } = getColumnNameAndConfig(a, b);
	if (config.mode === "json") return new SQLiteTextJsonBuilder(name);
	return new SQLiteTextBuilder(name, config);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/columns/all.js
function getSQLiteColumnBuilders() {
	return {
		blob,
		customType,
		integer,
		numeric,
		real,
		text
	};
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/table.js
var InlineForeignKeys = Symbol.for("drizzle:SQLiteInlineForeignKeys");
var SQLiteTable = class extends Table {
	static [entityKind] = "SQLiteTable";
	/** @internal */
	static Symbol = Object.assign({}, Table.Symbol, { InlineForeignKeys });
	/** @internal */
	[Table.Symbol.Columns];
	/** @internal */
	[InlineForeignKeys] = [];
	/** @internal */
	[Table.Symbol.ExtraConfigBuilder] = void 0;
};
function sqliteTableBase(name, columns, extraConfig, schema, baseName = name) {
	const rawTable = new SQLiteTable(name, schema, baseName);
	const parsedColumns = typeof columns === "function" ? columns(getSQLiteColumnBuilders()) : columns;
	const builtColumns = Object.fromEntries(Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
		const colBuilder = colBuilderBase;
		colBuilder.setName(name2);
		const column = colBuilder.build(rawTable);
		rawTable[InlineForeignKeys].push(...colBuilder.buildForeignKeys(column, rawTable));
		return [name2, column];
	}));
	const table = Object.assign(rawTable, builtColumns);
	table[Table.Symbol.Columns] = builtColumns;
	table[Table.Symbol.ExtraConfigColumns] = builtColumns;
	if (extraConfig) table[SQLiteTable.Symbol.ExtraConfigBuilder] = extraConfig;
	return table;
}
var sqliteTable = (name, columns, extraConfig) => {
	return sqliteTableBase(name, columns, extraConfig);
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/indexes.js
var IndexBuilderOn$1 = class {
	constructor(name, unique) {
		this.name = name;
		this.unique = unique;
	}
	static [entityKind] = "SQLiteIndexBuilderOn";
	on(...columns) {
		return new IndexBuilder$1(this.name, columns, this.unique);
	}
};
var IndexBuilder$1 = class {
	static [entityKind] = "SQLiteIndexBuilder";
	/** @internal */
	config;
	constructor(name, columns, unique) {
		this.config = {
			name,
			columns,
			unique,
			where: void 0
		};
	}
	/**
	* Condition for partial index.
	*/
	where(condition) {
		this.config.where = condition;
		return this;
	}
	/** @internal */
	build(table) {
		return new Index$1(this.config, table);
	}
};
var Index$1 = class {
	static [entityKind] = "SQLiteIndex";
	config;
	constructor(config, table) {
		this.config = {
			...config,
			table
		};
	}
};
function index$1(name) {
	return new IndexBuilderOn$1(name, false);
}
function uniqueIndex$1(name) {
	return new IndexBuilderOn$1(name, true);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/primary-keys.js
function primaryKey(...config) {
	if (config[0].columns) return new PrimaryKeyBuilder(config[0].columns, config[0].name);
	return new PrimaryKeyBuilder(config);
}
var PrimaryKeyBuilder = class {
	static [entityKind] = "SQLitePrimaryKeyBuilder";
	/** @internal */
	columns;
	/** @internal */
	name;
	constructor(columns, name) {
		this.columns = columns;
		this.name = name;
	}
	/** @internal */
	build(table) {
		return new PrimaryKey(table, this.columns, this.name);
	}
};
var PrimaryKey = class {
	constructor(table, columns, name) {
		this.table = table;
		this.columns = columns;
		this.name = name;
	}
	static [entityKind] = "SQLitePrimaryKey";
	columns;
	name;
	getName() {
		return this.name ?? `${this.table[SQLiteTable.Symbol.Name]}_${this.columns.map((column) => column.name).join("_")}_pk`;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/utils.js
function extractUsedTable$1(table) {
	if (is(table, SQLiteTable)) return [`${table[Table.Symbol.BaseName]}`];
	if (is(table, Subquery)) return table._.usedTables ?? [];
	if (is(table, SQL)) return table.usedTables ?? [];
	return [];
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/query-builders/delete.js
var SQLiteDeleteBase = class extends QueryPromise {
	constructor(table, session, dialect, withList) {
		super();
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			withList
		};
	}
	static [entityKind] = "SQLiteDelete";
	/** @internal */
	config;
	/**
	* Adds a `where` clause to the query.
	*
	* Calling this method will delete only those rows that fulfill a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/delete}
	*
	* @param where the `where` clause.
	*
	* @example
	* You can use conditional operators and `sql function` to filter the rows to be deleted.
	*
	* ```ts
	* // Delete all cars with green color
	* db.delete(cars).where(eq(cars.color, 'green'));
	* // or
	* db.delete(cars).where(sql`${cars.color} = 'green'`)
	* ```
	*
	* You can logically combine conditional operators with `and()` and `or()` operators:
	*
	* ```ts
	* // Delete all BMW cars with a green color
	* db.delete(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
	*
	* // Delete all cars with the green or blue color
	* db.delete(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
	* ```
	*/
	where(where) {
		this.config.where = where;
		return this;
	}
	orderBy(...columns) {
		if (typeof columns[0] === "function") {
			const orderBy = columns[0](new Proxy(this.config.table[Table.Symbol.Columns], new SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
			this.config.orderBy = orderByArray;
		} else {
			const orderByArray = columns;
			this.config.orderBy = orderByArray;
		}
		return this;
	}
	limit(limit) {
		this.config.limit = limit;
		return this;
	}
	returning(fields = this.table[SQLiteTable.Symbol.Columns]) {
		this.config.returning = orderSelectedFields(fields);
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildDeleteQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	/** @internal */
	_prepare(isOneTimeQuery = true) {
		return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true, void 0, {
			type: "delete",
			tables: extractUsedTable$1(this.config.table)
		});
	}
	prepare() {
		return this._prepare(false);
	}
	run = (placeholderValues) => {
		return this._prepare().run(placeholderValues);
	};
	all = (placeholderValues) => {
		return this._prepare().all(placeholderValues);
	};
	get = (placeholderValues) => {
		return this._prepare().get(placeholderValues);
	};
	values = (placeholderValues) => {
		return this._prepare().values(placeholderValues);
	};
	async execute(placeholderValues) {
		return this._prepare().execute(placeholderValues);
	}
	$dynamic() {
		return this;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/casing.js
function toSnakeCase(input) {
	return (input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? []).map((word) => word.toLowerCase()).join("_");
}
function toCamelCase(input) {
	return (input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? []).reduce((acc, word, i) => {
		return acc + (i === 0 ? word.toLowerCase() : `${word[0].toUpperCase()}${word.slice(1)}`);
	}, "");
}
function noopCase(input) {
	return input;
}
var CasingCache = class {
	static [entityKind] = "CasingCache";
	/** @internal */
	cache = {};
	cachedTables = {};
	convert;
	constructor(casing) {
		this.convert = casing === "snake_case" ? toSnakeCase : casing === "camelCase" ? toCamelCase : noopCase;
	}
	getColumnCasing(column) {
		if (!column.keyAsName) return column.name;
		const key = `${column.table[Table.Symbol.Schema] ?? "public"}.${column.table[Table.Symbol.OriginalName]}.${column.name}`;
		if (!this.cache[key]) this.cacheTable(column.table);
		return this.cache[key];
	}
	cacheTable(table) {
		const tableKey = `${table[Table.Symbol.Schema] ?? "public"}.${table[Table.Symbol.OriginalName]}`;
		if (!this.cachedTables[tableKey]) {
			for (const column of Object.values(table[Table.Symbol.Columns])) {
				const columnKey = `${tableKey}.${column.name}`;
				this.cache[columnKey] = this.convert(column.name);
			}
			this.cachedTables[tableKey] = true;
		}
	}
	clearCache() {
		this.cache = {};
		this.cachedTables = {};
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/errors.js
var DrizzleError = class extends Error {
	static [entityKind] = "DrizzleError";
	constructor({ message, cause }) {
		super(message);
		this.name = "DrizzleError";
		this.cause = cause;
	}
};
var DrizzleQueryError = class DrizzleQueryError extends Error {
	constructor(query, params, cause) {
		super(`Failed query: ${query}
params: ${params}`);
		this.query = query;
		this.params = params;
		this.cause = cause;
		Error.captureStackTrace(this, DrizzleQueryError);
		if (cause) this.cause = cause;
	}
};
var TransactionRollbackError = class extends DrizzleError {
	static [entityKind] = "TransactionRollbackError";
	constructor() {
		super({ message: "Rollback" });
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/view-base.js
var SQLiteViewBase = class extends View {
	static [entityKind] = "SQLiteViewBase";
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/dialect.js
var SQLiteDialect = class {
	static [entityKind] = "SQLiteDialect";
	/** @internal */
	casing;
	constructor(config) {
		this.casing = new CasingCache(config?.casing);
	}
	escapeName(name) {
		return `"${name.replace(/"/g, "\"\"")}"`;
	}
	escapeParam(_num) {
		return "?";
	}
	escapeString(str) {
		return `'${str.replace(/'/g, "''")}'`;
	}
	buildWithCTE(queries) {
		if (!queries?.length) return void 0;
		const withSqlChunks = [sql`with `];
		for (const [i, w] of queries.entries()) {
			withSqlChunks.push(sql`${sql.identifier(w._.alias)} as (${w._.sql})`);
			if (i < queries.length - 1) withSqlChunks.push(sql`, `);
		}
		withSqlChunks.push(sql` `);
		return sql.join(withSqlChunks);
	}
	buildDeleteQuery({ table, where, returning, withList, limit, orderBy }) {
		const withSql = this.buildWithCTE(withList);
		const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		const whereSql = where ? sql` where ${where}` : void 0;
		const orderBySql = this.buildOrderBy(orderBy);
		const limitSql = this.buildLimit(limit);
		return sql`${withSql}delete from ${table}${whereSql}${returningSql}${orderBySql}${limitSql}`;
	}
	buildUpdateSet(table, set) {
		const tableColumns = table[Table.Symbol.Columns];
		const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0);
		const setSize = columnNames.length;
		return sql.join(columnNames.flatMap((colName, i) => {
			const col = tableColumns[colName];
			const onUpdateFnResult = col.onUpdateFn?.();
			const value = set[colName] ?? (is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col));
			const res = sql`${sql.identifier(this.casing.getColumnCasing(col))} = ${value}`;
			if (i < setSize - 1) return [res, sql.raw(", ")];
			return [res];
		}));
	}
	buildUpdateQuery({ table, set, where, returning, withList, joins, from, limit, orderBy }) {
		const withSql = this.buildWithCTE(withList);
		const setSql = this.buildUpdateSet(table, set);
		const fromSql = from && sql.join([sql.raw(" from "), this.buildFromTable(from)]);
		const joinsSql = this.buildJoins(joins);
		const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		const whereSql = where ? sql` where ${where}` : void 0;
		const orderBySql = this.buildOrderBy(orderBy);
		const limitSql = this.buildLimit(limit);
		return sql`${withSql}update ${table} set ${setSql}${fromSql}${joinsSql}${whereSql}${returningSql}${orderBySql}${limitSql}`;
	}
	/**
	* Builds selection SQL with provided fields/expressions
	*
	* Examples:
	*
	* `select <selection> from`
	*
	* `insert ... returning <selection>`
	*
	* If `isSingleTable` is true, then columns won't be prefixed with table name
	*/
	buildSelection(fields, { isSingleTable = false } = {}) {
		const columnsLen = fields.length;
		const chunks = fields.flatMap(({ field }, i) => {
			const chunk = [];
			if (is(field, SQL.Aliased) && field.isSelectionField) chunk.push(sql.identifier(field.fieldAlias));
			else if (is(field, SQL.Aliased) || is(field, SQL)) {
				const query = is(field, SQL.Aliased) ? field.sql : field;
				if (isSingleTable) chunk.push(new SQL(query.queryChunks.map((c) => {
					if (is(c, Column)) return sql.identifier(this.casing.getColumnCasing(c));
					return c;
				})));
				else chunk.push(query);
				if (is(field, SQL.Aliased)) chunk.push(sql` as ${sql.identifier(field.fieldAlias)}`);
			} else if (is(field, Column)) {
				const tableName = field.table[Table.Symbol.Name];
				if (field.columnType === "SQLiteNumericBigInt") {
					if (isSingleTable) chunk.push(sql`cast(${sql.identifier(this.casing.getColumnCasing(field))} as text)`);
					else chunk.push(sql`cast(${sql.identifier(tableName)}.${sql.identifier(this.casing.getColumnCasing(field))} as text)`);
				} else if (isSingleTable) chunk.push(sql.identifier(this.casing.getColumnCasing(field)));
				else chunk.push(sql`${sql.identifier(tableName)}.${sql.identifier(this.casing.getColumnCasing(field))}`);
			} else if (is(field, Subquery)) {
				const entries = Object.entries(field._.selectedFields);
				if (entries.length === 1) {
					const entry = entries[0][1];
					const fieldDecoder = is(entry, SQL) ? entry.decoder : is(entry, Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
					if (fieldDecoder) field._.sql.decoder = fieldDecoder;
				}
				chunk.push(field);
			}
			if (i < columnsLen - 1) chunk.push(sql`, `);
			return chunk;
		});
		return sql.join(chunks);
	}
	buildJoins(joins) {
		if (!joins || joins.length === 0) return;
		const joinsArray = [];
		if (joins) for (const [index, joinMeta] of joins.entries()) {
			if (index === 0) joinsArray.push(sql` `);
			const table = joinMeta.table;
			const onSql = joinMeta.on ? sql` on ${joinMeta.on}` : void 0;
			if (is(table, SQLiteTable)) {
				const tableName = table[SQLiteTable.Symbol.Name];
				const tableSchema = table[SQLiteTable.Symbol.Schema];
				const origTableName = table[SQLiteTable.Symbol.OriginalName];
				const alias = tableName === origTableName ? void 0 : joinMeta.alias;
				joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join ${tableSchema ? sql`${sql.identifier(tableSchema)}.` : void 0}${sql.identifier(origTableName)}${alias && sql` ${sql.identifier(alias)}`}${onSql}`);
			} else joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join ${table}${onSql}`);
			if (index < joins.length - 1) joinsArray.push(sql` `);
		}
		return sql.join(joinsArray);
	}
	buildLimit(limit) {
		return typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
	}
	buildOrderBy(orderBy) {
		const orderByList = [];
		if (orderBy) for (const [index, orderByValue] of orderBy.entries()) {
			orderByList.push(orderByValue);
			if (index < orderBy.length - 1) orderByList.push(sql`, `);
		}
		return orderByList.length > 0 ? sql` order by ${sql.join(orderByList)}` : void 0;
	}
	buildFromTable(table) {
		if (is(table, Table) && table[Table.Symbol.IsAlias]) return sql`${sql`${sql.identifier(table[Table.Symbol.Schema] ?? "")}.`.if(table[Table.Symbol.Schema])}${sql.identifier(table[Table.Symbol.OriginalName])} ${sql.identifier(table[Table.Symbol.Name])}`;
		return table;
	}
	buildSelectQuery({ withList, fields, fieldsFlat, where, having, table, joins, orderBy, groupBy, limit, offset, distinct, setOperators }) {
		const fieldsList = fieldsFlat ?? orderSelectedFields(fields);
		for (const f of fieldsList) if (is(f.field, Column) && getTableName(f.field.table) !== (is(table, Subquery) ? table._.alias : is(table, SQLiteViewBase) ? table[ViewBaseConfig].name : is(table, SQL) ? void 0 : getTableName(table)) && !((table2) => joins?.some(({ alias }) => alias === (table2[Table.Symbol.IsAlias] ? getTableName(table2) : table2[Table.Symbol.BaseName])))(f.field.table)) {
			const tableName = getTableName(f.field.table);
			throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
		}
		const isSingleTable = !joins || joins.length === 0;
		const withSql = this.buildWithCTE(withList);
		const distinctSql = distinct ? sql` distinct` : void 0;
		const selection = this.buildSelection(fieldsList, { isSingleTable });
		const tableSql = this.buildFromTable(table);
		const joinsSql = this.buildJoins(joins);
		const whereSql = where ? sql` where ${where}` : void 0;
		const havingSql = having ? sql` having ${having}` : void 0;
		const groupByList = [];
		if (groupBy) for (const [index, groupByValue] of groupBy.entries()) {
			groupByList.push(groupByValue);
			if (index < groupBy.length - 1) groupByList.push(sql`, `);
		}
		const groupBySql = groupByList.length > 0 ? sql` group by ${sql.join(groupByList)}` : void 0;
		const orderBySql = this.buildOrderBy(orderBy);
		const limitSql = this.buildLimit(limit);
		const offsetSql = offset ? sql` offset ${offset}` : void 0;
		const finalQuery = sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}`;
		if (setOperators.length > 0) return this.buildSetOperations(finalQuery, setOperators);
		return finalQuery;
	}
	buildSetOperations(leftSelect, setOperators) {
		const [setOperator, ...rest] = setOperators;
		if (!setOperator) throw new Error("Cannot pass undefined values to any set operator");
		if (rest.length === 0) return this.buildSetOperationQuery({
			leftSelect,
			setOperator
		});
		return this.buildSetOperations(this.buildSetOperationQuery({
			leftSelect,
			setOperator
		}), rest);
	}
	buildSetOperationQuery({ leftSelect, setOperator: { type, isAll, rightSelect, limit, orderBy, offset } }) {
		const leftChunk = sql`${leftSelect.getSQL()} `;
		const rightChunk = sql`${rightSelect.getSQL()}`;
		let orderBySql;
		if (orderBy && orderBy.length > 0) {
			const orderByValues = [];
			for (const singleOrderBy of orderBy) if (is(singleOrderBy, SQLiteColumn)) orderByValues.push(sql.identifier(singleOrderBy.name));
			else if (is(singleOrderBy, SQL)) {
				for (let i = 0; i < singleOrderBy.queryChunks.length; i++) {
					const chunk = singleOrderBy.queryChunks[i];
					if (is(chunk, SQLiteColumn)) singleOrderBy.queryChunks[i] = sql.identifier(this.casing.getColumnCasing(chunk));
				}
				orderByValues.push(sql`${singleOrderBy}`);
			} else orderByValues.push(sql`${singleOrderBy}`);
			orderBySql = sql` order by ${sql.join(orderByValues, sql`, `)}`;
		}
		const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
		const operatorChunk = sql.raw(`${type} ${isAll ? "all " : ""}`);
		const offsetSql = offset ? sql` offset ${offset}` : void 0;
		return sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
	}
	buildInsertQuery({ table, values: valuesOrSelect, onConflict, returning, withList, select }) {
		const valuesSqlList = [];
		const columns = table[Table.Symbol.Columns];
		const colEntries = Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
		const insertOrder = colEntries.map(([, column]) => sql.identifier(this.casing.getColumnCasing(column)));
		if (select) {
			const select2 = valuesOrSelect;
			if (is(select2, SQL)) valuesSqlList.push(select2);
			else valuesSqlList.push(select2.getSQL());
		} else {
			const values = valuesOrSelect;
			valuesSqlList.push(sql.raw("values "));
			for (const [valueIndex, value] of values.entries()) {
				const valueList = [];
				for (const [fieldName, col] of colEntries) {
					const colValue = value[fieldName];
					if (colValue === void 0 || is(colValue, Param) && colValue.value === void 0) {
						let defaultValue;
						if (col.default !== null && col.default !== void 0) defaultValue = is(col.default, SQL) ? col.default : sql.param(col.default, col);
						else if (col.defaultFn !== void 0) {
							const defaultFnResult = col.defaultFn();
							defaultValue = is(defaultFnResult, SQL) ? defaultFnResult : sql.param(defaultFnResult, col);
						} else if (!col.default && col.onUpdateFn !== void 0) {
							const onUpdateFnResult = col.onUpdateFn();
							defaultValue = is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col);
						} else defaultValue = sql`null`;
						valueList.push(defaultValue);
					} else valueList.push(colValue);
				}
				valuesSqlList.push(valueList);
				if (valueIndex < values.length - 1) valuesSqlList.push(sql`, `);
			}
		}
		const withSql = this.buildWithCTE(withList);
		const valuesSql = sql.join(valuesSqlList);
		const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		const onConflictSql = onConflict?.length ? sql.join(onConflict) : void 0;
		return sql`${withSql}insert into ${table} ${insertOrder} ${valuesSql}${onConflictSql}${returningSql}`;
	}
	sqlToQuery(sql2, invokeSource) {
		return sql2.toQuery({
			casing: this.casing,
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			invokeSource
		});
	}
	buildRelationalQuery({ fullSchema, schema, tableNamesMap, table, tableConfig, queryConfig: config, tableAlias, nestedQueryRelation, joinOn }) {
		let selection = [];
		let limit, offset, orderBy = [], where;
		const joins = [];
		if (config === true) selection = Object.entries(tableConfig.columns).map(([key, value]) => ({
			dbKey: value.name,
			tsKey: key,
			field: aliasedTableColumn(value, tableAlias),
			relationTableTsKey: void 0,
			isJson: false,
			selection: []
		}));
		else {
			const aliasedColumns = Object.fromEntries(Object.entries(tableConfig.columns).map(([key, value]) => [key, aliasedTableColumn(value, tableAlias)]));
			if (config.where) {
				const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, getOperators()) : config.where;
				where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
			}
			const fieldsSelection = [];
			let selectedColumns = [];
			if (config.columns) {
				let isIncludeMode = false;
				for (const [field, value] of Object.entries(config.columns)) {
					if (value === void 0) continue;
					if (field in tableConfig.columns) {
						if (!isIncludeMode && value === true) isIncludeMode = true;
						selectedColumns.push(field);
					}
				}
				if (selectedColumns.length > 0) selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
			} else selectedColumns = Object.keys(tableConfig.columns);
			for (const field of selectedColumns) {
				const column = tableConfig.columns[field];
				fieldsSelection.push({
					tsKey: field,
					value: column
				});
			}
			let selectedRelations = [];
			if (config.with) selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig]) => ({
				tsKey,
				queryConfig,
				relation: tableConfig.relations[tsKey]
			}));
			let extras;
			if (config.extras) {
				extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql }) : config.extras;
				for (const [tsKey, value] of Object.entries(extras)) fieldsSelection.push({
					tsKey,
					value: mapColumnsInAliasedSQLToAlias(value, tableAlias)
				});
			}
			for (const { tsKey, value } of fieldsSelection) selection.push({
				dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
				tsKey,
				field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
				relationTableTsKey: void 0,
				isJson: false,
				selection: []
			});
			let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, getOrderByOperators()) : config.orderBy ?? [];
			if (!Array.isArray(orderByOrig)) orderByOrig = [orderByOrig];
			orderBy = orderByOrig.map((orderByValue) => {
				if (is(orderByValue, Column)) return aliasedTableColumn(orderByValue, tableAlias);
				return mapColumnsInSQLToAlias(orderByValue, tableAlias);
			});
			limit = config.limit;
			offset = config.offset;
			for (const { tsKey: selectedRelationTsKey, queryConfig: selectedRelationConfigValue, relation } of selectedRelations) {
				const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
				const relationTableTsName = tableNamesMap[getTableUniqueName(relation.referencedTable)];
				const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
				const joinOn2 = and(...normalizedRelation.fields.map((field2, i) => eq(aliasedTableColumn(normalizedRelation.references[i], relationTableAlias), aliasedTableColumn(field2, tableAlias))));
				const builtRelation = this.buildRelationalQuery({
					fullSchema,
					schema,
					tableNamesMap,
					table: fullSchema[relationTableTsName],
					tableConfig: schema[relationTableTsName],
					queryConfig: is(relation, One) ? selectedRelationConfigValue === true ? { limit: 1 } : {
						...selectedRelationConfigValue,
						limit: 1
					} : selectedRelationConfigValue,
					tableAlias: relationTableAlias,
					joinOn: joinOn2,
					nestedQueryRelation: relation
				});
				const field = sql`(${builtRelation.sql})`.as(selectedRelationTsKey);
				selection.push({
					dbKey: selectedRelationTsKey,
					tsKey: selectedRelationTsKey,
					field,
					relationTableTsKey: relationTableTsName,
					isJson: true,
					selection: builtRelation.selection
				});
			}
		}
		if (selection.length === 0) throw new DrizzleError({ message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}"). You need to have at least one item in "columns", "with" or "extras". If you need to select all columns, omit the "columns" key or set it to undefined.` });
		let result;
		where = and(joinOn, where);
		if (nestedQueryRelation) {
			let field = sql`json_array(${sql.join(selection.map(({ field: field2 }) => is(field2, SQLiteColumn) ? sql.identifier(this.casing.getColumnCasing(field2)) : is(field2, SQL.Aliased) ? field2.sql : field2), sql`, `)})`;
			if (is(nestedQueryRelation, Many)) field = sql`coalesce(json_group_array(${field}), json_array())`;
			const nestedSelection = [{
				dbKey: "data",
				tsKey: "data",
				field: field.as("data"),
				isJson: true,
				relationTableTsKey: tableConfig.tsName,
				selection
			}];
			if (limit !== void 0 || offset !== void 0 || orderBy.length > 0) {
				result = this.buildSelectQuery({
					table: aliasedTable(table, tableAlias),
					fields: {},
					fieldsFlat: [{
						path: [],
						field: sql.raw("*")
					}],
					where,
					limit,
					offset,
					orderBy,
					setOperators: []
				});
				where = void 0;
				limit = void 0;
				offset = void 0;
				orderBy = void 0;
			} else result = aliasedTable(table, tableAlias);
			result = this.buildSelectQuery({
				table: is(result, SQLiteTable) ? result : new Subquery(result, {}, tableAlias),
				fields: {},
				fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
					path: [],
					field: is(field2, Column) ? aliasedTableColumn(field2, tableAlias) : field2
				})),
				joins,
				where,
				limit,
				offset,
				orderBy,
				setOperators: []
			});
		} else result = this.buildSelectQuery({
			table: aliasedTable(table, tableAlias),
			fields: {},
			fieldsFlat: selection.map(({ field }) => ({
				path: [],
				field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
			})),
			joins,
			where,
			limit,
			offset,
			orderBy,
			setOperators: []
		});
		return {
			tableTsKey: tableConfig.tsName,
			sql: result,
			selection
		};
	}
};
var SQLiteSyncDialect = class extends SQLiteDialect {
	static [entityKind] = "SQLiteSyncDialect";
	migrate(migrations, session, config) {
		const migrationsTable = config === void 0 ? "__drizzle_migrations" : typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
		const migrationTableCreate = sql`
			CREATE TABLE IF NOT EXISTS ${sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric
			)
		`;
		session.run(migrationTableCreate);
		const lastDbMigration = session.values(sql`SELECT id, hash, created_at FROM ${sql.identifier(migrationsTable)} ORDER BY created_at DESC LIMIT 1`)[0] ?? void 0;
		session.run(sql`BEGIN`);
		try {
			for (const migration of migrations) if (!lastDbMigration || Number(lastDbMigration[2]) < migration.folderMillis) {
				for (const stmt of migration.sql) session.run(sql.raw(stmt));
				session.run(sql`INSERT INTO ${sql.identifier(migrationsTable)} ("hash", "created_at") VALUES(${migration.hash}, ${migration.folderMillis})`);
			}
			session.run(sql`COMMIT`);
		} catch (e) {
			session.run(sql`ROLLBACK`);
			throw e;
		}
	}
};
var SQLiteAsyncDialect = class extends SQLiteDialect {
	static [entityKind] = "SQLiteAsyncDialect";
	async migrate(migrations, session, config) {
		const migrationsTable = config === void 0 ? "__drizzle_migrations" : typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
		const migrationTableCreate = sql`
			CREATE TABLE IF NOT EXISTS ${sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric
			)
		`;
		await session.run(migrationTableCreate);
		const lastDbMigration = (await session.values(sql`SELECT id, hash, created_at FROM ${sql.identifier(migrationsTable)} ORDER BY created_at DESC LIMIT 1`))[0] ?? void 0;
		await session.transaction(async (tx) => {
			for (const migration of migrations) if (!lastDbMigration || Number(lastDbMigration[2]) < migration.folderMillis) {
				for (const stmt of migration.sql) await tx.run(sql.raw(stmt));
				await tx.run(sql`INSERT INTO ${sql.identifier(migrationsTable)} ("hash", "created_at") VALUES(${migration.hash}, ${migration.folderMillis})`);
			}
		});
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/query-builders/query-builder.js
var TypedQueryBuilder = class {
	static [entityKind] = "TypedQueryBuilder";
	/** @internal */
	getSelectedFields() {
		return this._.selectedFields;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/query-builders/select.js
var SQLiteSelectBuilder = class {
	static [entityKind] = "SQLiteSelectBuilder";
	fields;
	session;
	dialect;
	withList;
	distinct;
	constructor(config) {
		this.fields = config.fields;
		this.session = config.session;
		this.dialect = config.dialect;
		this.withList = config.withList;
		this.distinct = config.distinct;
	}
	from(source) {
		const isPartialSelect = !!this.fields;
		let fields;
		if (this.fields) fields = this.fields;
		else if (is(source, Subquery)) fields = Object.fromEntries(Object.keys(source._.selectedFields).map((key) => [key, source[key]]));
		else if (is(source, SQLiteViewBase)) fields = source[ViewBaseConfig].selectedFields;
		else if (is(source, SQL)) fields = {};
		else fields = getTableColumns(source);
		return new SQLiteSelectBase({
			table: source,
			fields,
			isPartialSelect,
			session: this.session,
			dialect: this.dialect,
			withList: this.withList,
			distinct: this.distinct
		});
	}
};
var SQLiteSelectQueryBuilderBase = class extends TypedQueryBuilder {
	static [entityKind] = "SQLiteSelectQueryBuilder";
	_;
	/** @internal */
	config;
	joinsNotNullableMap;
	tableName;
	isPartialSelect;
	session;
	dialect;
	cacheConfig = void 0;
	usedTables = /* @__PURE__ */ new Set();
	constructor({ table, fields, isPartialSelect, session, dialect, withList, distinct }) {
		super();
		this.config = {
			withList,
			table,
			fields: { ...fields },
			distinct,
			setOperators: []
		};
		this.isPartialSelect = isPartialSelect;
		this.session = session;
		this.dialect = dialect;
		this._ = {
			selectedFields: fields,
			config: this.config
		};
		this.tableName = getTableLikeName(table);
		this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
		for (const item of extractUsedTable$1(table)) this.usedTables.add(item);
	}
	/** @internal */
	getUsedTables() {
		return [...this.usedTables];
	}
	createJoin(joinType) {
		return (table, on) => {
			const baseTableName = this.tableName;
			const tableName = getTableLikeName(table);
			for (const item of extractUsedTable$1(table)) this.usedTables.add(item);
			if (typeof tableName === "string" && this.config.joins?.some((join) => join.alias === tableName)) throw new Error(`Alias "${tableName}" is already used in this query`);
			if (!this.isPartialSelect) {
				if (Object.keys(this.joinsNotNullableMap).length === 1 && typeof baseTableName === "string") this.config.fields = { [baseTableName]: this.config.fields };
				if (typeof tableName === "string" && !is(table, SQL)) {
					const selection = is(table, Subquery) ? table._.selectedFields : is(table, View) ? table[ViewBaseConfig].selectedFields : table[Table.Symbol.Columns];
					this.config.fields[tableName] = selection;
				}
			}
			if (typeof on === "function") on = on(new Proxy(this.config.fields, new SelectionProxyHandler({
				sqlAliasedBehavior: "sql",
				sqlBehavior: "sql"
			})));
			if (!this.config.joins) this.config.joins = [];
			this.config.joins.push({
				on,
				table,
				joinType,
				alias: tableName
			});
			if (typeof tableName === "string") switch (joinType) {
				case "left":
					this.joinsNotNullableMap[tableName] = false;
					break;
				case "right":
					this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
					this.joinsNotNullableMap[tableName] = true;
					break;
				case "cross":
				case "inner":
					this.joinsNotNullableMap[tableName] = true;
					break;
				case "full":
					this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
					this.joinsNotNullableMap[tableName] = false;
			}
			return this;
		};
	}
	/**
	* Executes a `left join` operation by adding another table to the current query.
	*
	* Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#left-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User; pets: Pet | null; }[] = await db.select()
	*   .from(users)
	*   .leftJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .leftJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	leftJoin = this.createJoin("left");
	/**
	* Executes a `right join` operation by adding another table to the current query.
	*
	* Calling this method associates each row of the joined table with the corresponding row from the main table, if a match is found. If no matching row exists, it sets all columns of the main table to null.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#right-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User | null; pets: Pet; }[] = await db.select()
	*   .from(users)
	*   .rightJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number | null; petId: number; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .rightJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	rightJoin = this.createJoin("right");
	/**
	* Executes an `inner join` operation, creating a new table by combining rows from two tables that have matching values.
	*
	* Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#inner-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
	*   .from(users)
	*   .innerJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .innerJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	innerJoin = this.createJoin("inner");
	/**
	* Executes a `full join` operation by combining rows from two tables into a new table.
	*
	* Calling this method retrieves all rows from both main and joined tables, merging rows with matching values and filling in `null` for non-matching columns.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#full-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User | null; pets: Pet | null; }[] = await db.select()
	*   .from(users)
	*   .fullJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number | null; petId: number | null; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .fullJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	fullJoin = this.createJoin("full");
	/**
	* Executes a `cross join` operation by combining rows from two tables into a new table.
	*
	* Calling this method retrieves all rows from both main and joined tables, merging all rows from each table.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#cross-join}
	*
	* @param table the table to join.
	*
	* @example
	*
	* ```ts
	* // Select all users, each user with every pet
	* const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
	*   .from(users)
	*   .crossJoin(pets)
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .crossJoin(pets)
	* ```
	*/
	crossJoin = this.createJoin("cross");
	createSetOperator(type, isAll) {
		return (rightSelection) => {
			const rightSelect = typeof rightSelection === "function" ? rightSelection(getSQLiteSetOperators()) : rightSelection;
			if (!haveSameKeys(this.getSelectedFields(), rightSelect.getSelectedFields())) throw new Error("Set operator error (union / intersect / except): selected fields are not the same or are in a different order");
			this.config.setOperators.push({
				type,
				isAll,
				rightSelect
			});
			return this;
		};
	}
	/**
	* Adds `union` set operator to the query.
	*
	* Calling this method will combine the result sets of the `select` statements and remove any duplicate rows that appear across them.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#union}
	*
	* @example
	*
	* ```ts
	* // Select all unique names from customers and users tables
	* await db.select({ name: users.name })
	*   .from(users)
	*   .union(
	*     db.select({ name: customers.name }).from(customers)
	*   );
	* // or
	* import { union } from 'drizzle-orm/sqlite-core'
	*
	* await union(
	*   db.select({ name: users.name }).from(users),
	*   db.select({ name: customers.name }).from(customers)
	* );
	* ```
	*/
	union = this.createSetOperator("union", false);
	/**
	* Adds `union all` set operator to the query.
	*
	* Calling this method will combine the result-set of the `select` statements and keep all duplicate rows that appear across them.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#union-all}
	*
	* @example
	*
	* ```ts
	* // Select all transaction ids from both online and in-store sales
	* await db.select({ transaction: onlineSales.transactionId })
	*   .from(onlineSales)
	*   .unionAll(
	*     db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
	*   );
	* // or
	* import { unionAll } from 'drizzle-orm/sqlite-core'
	*
	* await unionAll(
	*   db.select({ transaction: onlineSales.transactionId }).from(onlineSales),
	*   db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
	* );
	* ```
	*/
	unionAll = this.createSetOperator("union", true);
	/**
	* Adds `intersect` set operator to the query.
	*
	* Calling this method will retain only the rows that are present in both result sets and eliminate duplicates.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect}
	*
	* @example
	*
	* ```ts
	* // Select course names that are offered in both departments A and B
	* await db.select({ courseName: depA.courseName })
	*   .from(depA)
	*   .intersect(
	*     db.select({ courseName: depB.courseName }).from(depB)
	*   );
	* // or
	* import { intersect } from 'drizzle-orm/sqlite-core'
	*
	* await intersect(
	*   db.select({ courseName: depA.courseName }).from(depA),
	*   db.select({ courseName: depB.courseName }).from(depB)
	* );
	* ```
	*/
	intersect = this.createSetOperator("intersect", false);
	/**
	* Adds `except` set operator to the query.
	*
	* Calling this method will retrieve all unique rows from the left query, except for the rows that are present in the result set of the right query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#except}
	*
	* @example
	*
	* ```ts
	* // Select all courses offered in department A but not in department B
	* await db.select({ courseName: depA.courseName })
	*   .from(depA)
	*   .except(
	*     db.select({ courseName: depB.courseName }).from(depB)
	*   );
	* // or
	* import { except } from 'drizzle-orm/sqlite-core'
	*
	* await except(
	*   db.select({ courseName: depA.courseName }).from(depA),
	*   db.select({ courseName: depB.courseName }).from(depB)
	* );
	* ```
	*/
	except = this.createSetOperator("except", false);
	/** @internal */
	addSetOperators(setOperators) {
		this.config.setOperators.push(...setOperators);
		return this;
	}
	/**
	* Adds a `where` clause to the query.
	*
	* Calling this method will select only those rows that fulfill a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#filtering}
	*
	* @param where the `where` clause.
	*
	* @example
	* You can use conditional operators and `sql function` to filter the rows to be selected.
	*
	* ```ts
	* // Select all cars with green color
	* await db.select().from(cars).where(eq(cars.color, 'green'));
	* // or
	* await db.select().from(cars).where(sql`${cars.color} = 'green'`)
	* ```
	*
	* You can logically combine conditional operators with `and()` and `or()` operators:
	*
	* ```ts
	* // Select all BMW cars with a green color
	* await db.select().from(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
	*
	* // Select all cars with the green or blue color
	* await db.select().from(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
	* ```
	*/
	where(where) {
		if (typeof where === "function") where = where(new Proxy(this.config.fields, new SelectionProxyHandler({
			sqlAliasedBehavior: "sql",
			sqlBehavior: "sql"
		})));
		this.config.where = where;
		return this;
	}
	/**
	* Adds a `having` clause to the query.
	*
	* Calling this method will select only those rows that fulfill a specified condition. It is typically used with aggregate functions to filter the aggregated data based on a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#aggregations}
	*
	* @param having the `having` clause.
	*
	* @example
	*
	* ```ts
	* // Select all brands with more than one car
	* await db.select({
	* 	brand: cars.brand,
	* 	count: sql<number>`cast(count(${cars.id}) as int)`,
	* })
	*   .from(cars)
	*   .groupBy(cars.brand)
	*   .having(({ count }) => gt(count, 1));
	* ```
	*/
	having(having) {
		if (typeof having === "function") having = having(new Proxy(this.config.fields, new SelectionProxyHandler({
			sqlAliasedBehavior: "sql",
			sqlBehavior: "sql"
		})));
		this.config.having = having;
		return this;
	}
	groupBy(...columns) {
		if (typeof columns[0] === "function") {
			const groupBy = columns[0](new Proxy(this.config.fields, new SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			this.config.groupBy = Array.isArray(groupBy) ? groupBy : [groupBy];
		} else this.config.groupBy = columns;
		return this;
	}
	orderBy(...columns) {
		if (typeof columns[0] === "function") {
			const orderBy = columns[0](new Proxy(this.config.fields, new SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
			if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).orderBy = orderByArray;
			else this.config.orderBy = orderByArray;
		} else {
			const orderByArray = columns;
			if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).orderBy = orderByArray;
			else this.config.orderBy = orderByArray;
		}
		return this;
	}
	/**
	* Adds a `limit` clause to the query.
	*
	* Calling this method will set the maximum number of rows that will be returned by this query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
	*
	* @param limit the `limit` clause.
	*
	* @example
	*
	* ```ts
	* // Get the first 10 people from this query.
	* await db.select().from(people).limit(10);
	* ```
	*/
	limit(limit) {
		if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).limit = limit;
		else this.config.limit = limit;
		return this;
	}
	/**
	* Adds an `offset` clause to the query.
	*
	* Calling this method will skip a number of rows when returning results from this query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
	*
	* @param offset the `offset` clause.
	*
	* @example
	*
	* ```ts
	* // Get the 10th-20th people from this query.
	* await db.select().from(people).offset(10).limit(10);
	* ```
	*/
	offset(offset) {
		if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).offset = offset;
		else this.config.offset = offset;
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildSelectQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	as(alias) {
		const usedTables = [];
		usedTables.push(...extractUsedTable$1(this.config.table));
		if (this.config.joins) for (const it of this.config.joins) usedTables.push(...extractUsedTable$1(it.table));
		return new Proxy(new Subquery(this.getSQL(), this.config.fields, alias, false, [...new Set(usedTables)]), new SelectionProxyHandler({
			alias,
			sqlAliasedBehavior: "alias",
			sqlBehavior: "error"
		}));
	}
	/** @internal */
	getSelectedFields() {
		return new Proxy(this.config.fields, new SelectionProxyHandler({
			alias: this.tableName,
			sqlAliasedBehavior: "alias",
			sqlBehavior: "error"
		}));
	}
	$dynamic() {
		return this;
	}
};
var SQLiteSelectBase = class extends SQLiteSelectQueryBuilderBase {
	static [entityKind] = "SQLiteSelect";
	/** @internal */
	_prepare(isOneTimeQuery = true) {
		if (!this.session) throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
		const fieldsList = orderSelectedFields(this.config.fields);
		const query = this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), fieldsList, "all", true, void 0, {
			type: "select",
			tables: [...this.usedTables]
		}, this.cacheConfig);
		query.joinsNotNullableMap = this.joinsNotNullableMap;
		return query;
	}
	$withCache(config) {
		this.cacheConfig = config === void 0 ? {
			config: {},
			enable: true,
			autoInvalidate: true
		} : config === false ? { enable: false } : {
			enable: true,
			autoInvalidate: true,
			...config
		};
		return this;
	}
	prepare() {
		return this._prepare(false);
	}
	run = (placeholderValues) => {
		return this._prepare().run(placeholderValues);
	};
	all = (placeholderValues) => {
		return this._prepare().all(placeholderValues);
	};
	get = (placeholderValues) => {
		return this._prepare().get(placeholderValues);
	};
	values = (placeholderValues) => {
		return this._prepare().values(placeholderValues);
	};
	async execute() {
		return this.all();
	}
};
applyMixins(SQLiteSelectBase, [QueryPromise]);
function createSetOperator$1(type, isAll) {
	return (leftSelect, rightSelect, ...restSelects) => {
		const setOperators = [rightSelect, ...restSelects].map((select) => ({
			type,
			isAll,
			rightSelect: select
		}));
		for (const setOperator of setOperators) if (!haveSameKeys(leftSelect.getSelectedFields(), setOperator.rightSelect.getSelectedFields())) throw new Error("Set operator error (union / intersect / except): selected fields are not the same or are in a different order");
		return leftSelect.addSetOperators(setOperators);
	};
}
var getSQLiteSetOperators = () => ({
	union: union$1,
	unionAll: unionAll$1,
	intersect: intersect$1,
	except: except$1
});
var union$1 = createSetOperator$1("union", false);
var unionAll$1 = createSetOperator$1("union", true);
var intersect$1 = createSetOperator$1("intersect", false);
var except$1 = createSetOperator$1("except", false);
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/query-builders/query-builder.js
var QueryBuilder$1 = class {
	static [entityKind] = "SQLiteQueryBuilder";
	dialect;
	dialectConfig;
	constructor(dialect) {
		this.dialect = is(dialect, SQLiteDialect) ? dialect : void 0;
		this.dialectConfig = is(dialect, SQLiteDialect) ? void 0 : dialect;
	}
	$with = (alias, selection) => {
		const queryBuilder = this;
		const as = (qb) => {
			if (typeof qb === "function") qb = qb(queryBuilder);
			return new Proxy(new WithSubquery(qb.getSQL(), selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}), alias, true), new SelectionProxyHandler({
				alias,
				sqlAliasedBehavior: "alias",
				sqlBehavior: "error"
			}));
		};
		return { as };
	};
	with(...queries) {
		const self = this;
		function select(fields) {
			return new SQLiteSelectBuilder({
				fields: fields ?? void 0,
				session: void 0,
				dialect: self.getDialect(),
				withList: queries
			});
		}
		function selectDistinct(fields) {
			return new SQLiteSelectBuilder({
				fields: fields ?? void 0,
				session: void 0,
				dialect: self.getDialect(),
				withList: queries,
				distinct: true
			});
		}
		return {
			select,
			selectDistinct
		};
	}
	select(fields) {
		return new SQLiteSelectBuilder({
			fields: fields ?? void 0,
			session: void 0,
			dialect: this.getDialect()
		});
	}
	selectDistinct(fields) {
		return new SQLiteSelectBuilder({
			fields: fields ?? void 0,
			session: void 0,
			dialect: this.getDialect(),
			distinct: true
		});
	}
	getDialect() {
		if (!this.dialect) this.dialect = new SQLiteSyncDialect(this.dialectConfig);
		return this.dialect;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/query-builders/insert.js
var SQLiteInsertBuilder = class {
	constructor(table, session, dialect, withList) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.withList = withList;
	}
	static [entityKind] = "SQLiteInsertBuilder";
	values(values) {
		values = Array.isArray(values) ? values : [values];
		if (values.length === 0) throw new Error("values() must be called with at least one value");
		const mappedValues = values.map((entry) => {
			const result = {};
			const cols = this.table[Table.Symbol.Columns];
			for (const colKey of Object.keys(entry)) {
				const colValue = entry[colKey];
				result[colKey] = is(colValue, SQL) ? colValue : new Param(colValue, cols[colKey]);
			}
			return result;
		});
		return new SQLiteInsertBase(this.table, mappedValues, this.session, this.dialect, this.withList);
	}
	select(selectQuery) {
		const select = typeof selectQuery === "function" ? selectQuery(new QueryBuilder$1()) : selectQuery;
		if (!is(select, SQL) && !haveSameKeys(this.table[Columns], select._.selectedFields)) throw new Error("Insert select error: selected fields are not the same or are in a different order compared to the table definition");
		return new SQLiteInsertBase(this.table, select, this.session, this.dialect, this.withList, true);
	}
};
var SQLiteInsertBase = class extends QueryPromise {
	constructor(table, values, session, dialect, withList, select) {
		super();
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			values,
			withList,
			select
		};
	}
	static [entityKind] = "SQLiteInsert";
	/** @internal */
	config;
	returning(fields = this.config.table[SQLiteTable.Symbol.Columns]) {
		this.config.returning = orderSelectedFields(fields);
		return this;
	}
	/**
	* Adds an `on conflict do nothing` clause to the query.
	*
	* Calling this method simply avoids inserting a row as its alternative action.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#on-conflict-do-nothing}
	*
	* @param config The `target` and `where` clauses.
	*
	* @example
	* ```ts
	* // Insert one row and cancel the insert if there's a conflict
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoNothing();
	*
	* // Explicitly specify conflict target
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoNothing({ target: cars.id });
	* ```
	*/
	onConflictDoNothing(config = {}) {
		if (!this.config.onConflict) this.config.onConflict = [];
		if (config.target === void 0) this.config.onConflict.push(sql` on conflict do nothing`);
		else {
			const targetSql = Array.isArray(config.target) ? sql`${config.target}` : sql`${[config.target]}`;
			const whereSql = config.where ? sql` where ${config.where}` : sql``;
			this.config.onConflict.push(sql` on conflict ${targetSql} do nothing${whereSql}`);
		}
		return this;
	}
	/**
	* Adds an `on conflict do update` clause to the query.
	*
	* Calling this method will update the existing row that conflicts with the row proposed for insertion as its alternative action.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#upserts-and-conflicts}
	*
	* @param config The `target`, `set` and `where` clauses.
	*
	* @example
	* ```ts
	* // Update the row if there's a conflict
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoUpdate({
	*     target: cars.id,
	*     set: { brand: 'Porsche' }
	*   });
	*
	* // Upsert with 'where' clause
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoUpdate({
	*     target: cars.id,
	*     set: { brand: 'newBMW' },
	*     where: sql`${cars.createdAt} > '2023-01-01'::date`,
	*   });
	* ```
	*/
	onConflictDoUpdate(config) {
		if (config.where && (config.targetWhere || config.setWhere)) throw new Error("You cannot use both \"where\" and \"targetWhere\"/\"setWhere\" at the same time - \"where\" is deprecated, use \"targetWhere\" or \"setWhere\" instead.");
		if (!this.config.onConflict) this.config.onConflict = [];
		const whereSql = config.where ? sql` where ${config.where}` : void 0;
		const targetWhereSql = config.targetWhere ? sql` where ${config.targetWhere}` : void 0;
		const setWhereSql = config.setWhere ? sql` where ${config.setWhere}` : void 0;
		const targetSql = Array.isArray(config.target) ? sql`${config.target}` : sql`${[config.target]}`;
		const setSql = this.dialect.buildUpdateSet(this.config.table, mapUpdateSet(this.config.table, config.set));
		this.config.onConflict.push(sql` on conflict ${targetSql}${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`);
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildInsertQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	/** @internal */
	_prepare(isOneTimeQuery = true) {
		return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true, void 0, {
			type: "insert",
			tables: extractUsedTable$1(this.config.table)
		});
	}
	prepare() {
		return this._prepare(false);
	}
	run = (placeholderValues) => {
		return this._prepare().run(placeholderValues);
	};
	all = (placeholderValues) => {
		return this._prepare().all(placeholderValues);
	};
	get = (placeholderValues) => {
		return this._prepare().get(placeholderValues);
	};
	values = (placeholderValues) => {
		return this._prepare().values(placeholderValues);
	};
	async execute() {
		return this.config.returning ? this.all() : this.run();
	}
	$dynamic() {
		return this;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/query-builders/update.js
var SQLiteUpdateBuilder = class {
	constructor(table, session, dialect, withList) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.withList = withList;
	}
	static [entityKind] = "SQLiteUpdateBuilder";
	set(values) {
		return new SQLiteUpdateBase(this.table, mapUpdateSet(this.table, values), this.session, this.dialect, this.withList);
	}
};
var SQLiteUpdateBase = class extends QueryPromise {
	constructor(table, set, session, dialect, withList) {
		super();
		this.session = session;
		this.dialect = dialect;
		this.config = {
			set,
			table,
			withList,
			joins: []
		};
	}
	static [entityKind] = "SQLiteUpdate";
	/** @internal */
	config;
	from(source) {
		this.config.from = source;
		return this;
	}
	createJoin(joinType) {
		return (table, on) => {
			const tableName = getTableLikeName(table);
			if (typeof tableName === "string" && this.config.joins.some((join) => join.alias === tableName)) throw new Error(`Alias "${tableName}" is already used in this query`);
			if (typeof on === "function") {
				const from = this.config.from ? is(table, SQLiteTable) ? table[Table.Symbol.Columns] : is(table, Subquery) ? table._.selectedFields : is(table, SQLiteViewBase) ? table[ViewBaseConfig].selectedFields : void 0 : void 0;
				on = on(new Proxy(this.config.table[Table.Symbol.Columns], new SelectionProxyHandler({
					sqlAliasedBehavior: "sql",
					sqlBehavior: "sql"
				})), from && new Proxy(from, new SelectionProxyHandler({
					sqlAliasedBehavior: "sql",
					sqlBehavior: "sql"
				})));
			}
			this.config.joins.push({
				on,
				table,
				joinType,
				alias: tableName
			});
			return this;
		};
	}
	leftJoin = this.createJoin("left");
	rightJoin = this.createJoin("right");
	innerJoin = this.createJoin("inner");
	fullJoin = this.createJoin("full");
	/**
	* Adds a 'where' clause to the query.
	*
	* Calling this method will update only those rows that fulfill a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/update}
	*
	* @param where the 'where' clause.
	*
	* @example
	* You can use conditional operators and `sql function` to filter the rows to be updated.
	*
	* ```ts
	* // Update all cars with green color
	* db.update(cars).set({ color: 'red' })
	*   .where(eq(cars.color, 'green'));
	* // or
	* db.update(cars).set({ color: 'red' })
	*   .where(sql`${cars.color} = 'green'`)
	* ```
	*
	* You can logically combine conditional operators with `and()` and `or()` operators:
	*
	* ```ts
	* // Update all BMW cars with a green color
	* db.update(cars).set({ color: 'red' })
	*   .where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
	*
	* // Update all cars with the green or blue color
	* db.update(cars).set({ color: 'red' })
	*   .where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
	* ```
	*/
	where(where) {
		this.config.where = where;
		return this;
	}
	orderBy(...columns) {
		if (typeof columns[0] === "function") {
			const orderBy = columns[0](new Proxy(this.config.table[Table.Symbol.Columns], new SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
			this.config.orderBy = orderByArray;
		} else {
			const orderByArray = columns;
			this.config.orderBy = orderByArray;
		}
		return this;
	}
	limit(limit) {
		this.config.limit = limit;
		return this;
	}
	returning(fields = this.config.table[SQLiteTable.Symbol.Columns]) {
		this.config.returning = orderSelectedFields(fields);
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildUpdateQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	/** @internal */
	_prepare(isOneTimeQuery = true) {
		return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true, void 0, {
			type: "insert",
			tables: extractUsedTable$1(this.config.table)
		});
	}
	prepare() {
		return this._prepare(false);
	}
	run = (placeholderValues) => {
		return this._prepare().run(placeholderValues);
	};
	all = (placeholderValues) => {
		return this._prepare().all(placeholderValues);
	};
	get = (placeholderValues) => {
		return this._prepare().get(placeholderValues);
	};
	values = (placeholderValues) => {
		return this._prepare().values(placeholderValues);
	};
	async execute() {
		return this.config.returning ? this.all() : this.run();
	}
	$dynamic() {
		return this;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/query-builders/count.js
var SQLiteCountBuilder = class SQLiteCountBuilder extends SQL {
	constructor(params) {
		super(SQLiteCountBuilder.buildEmbeddedCount(params.source, params.filters).queryChunks);
		this.params = params;
		this.session = params.session;
		this.sql = SQLiteCountBuilder.buildCount(params.source, params.filters);
	}
	sql;
	static [entityKind] = "SQLiteCountBuilderAsync";
	[Symbol.toStringTag] = "SQLiteCountBuilderAsync";
	session;
	static buildEmbeddedCount(source, filters) {
		return sql`(select count(*) from ${source}${sql.raw(" where ").if(filters)}${filters})`;
	}
	static buildCount(source, filters) {
		return sql`select count(*) from ${source}${sql.raw(" where ").if(filters)}${filters}`;
	}
	then(onfulfilled, onrejected) {
		return Promise.resolve(this.session.count(this.sql)).then(onfulfilled, onrejected);
	}
	catch(onRejected) {
		return this.then(void 0, onRejected);
	}
	finally(onFinally) {
		return this.then((value) => {
			onFinally?.();
			return value;
		}, (reason) => {
			onFinally?.();
			throw reason;
		});
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/query-builders/query.js
var RelationalQueryBuilder$1 = class {
	constructor(mode, fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session) {
		this.mode = mode;
		this.fullSchema = fullSchema;
		this.schema = schema;
		this.tableNamesMap = tableNamesMap;
		this.table = table;
		this.tableConfig = tableConfig;
		this.dialect = dialect;
		this.session = session;
	}
	static [entityKind] = "SQLiteAsyncRelationalQueryBuilder";
	findMany(config) {
		return this.mode === "sync" ? new SQLiteSyncRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? config : {}, "many") : new SQLiteRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? config : {}, "many");
	}
	findFirst(config) {
		return this.mode === "sync" ? new SQLiteSyncRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? {
			...config,
			limit: 1
		} : { limit: 1 }, "first") : new SQLiteRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? {
			...config,
			limit: 1
		} : { limit: 1 }, "first");
	}
};
var SQLiteRelationalQuery = class extends QueryPromise {
	constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session, config, mode) {
		super();
		this.fullSchema = fullSchema;
		this.schema = schema;
		this.tableNamesMap = tableNamesMap;
		this.table = table;
		this.tableConfig = tableConfig;
		this.dialect = dialect;
		this.session = session;
		this.config = config;
		this.mode = mode;
	}
	static [entityKind] = "SQLiteAsyncRelationalQuery";
	/** @internal */
	mode;
	/** @internal */
	getSQL() {
		return this.dialect.buildRelationalQuery({
			fullSchema: this.fullSchema,
			schema: this.schema,
			tableNamesMap: this.tableNamesMap,
			table: this.table,
			tableConfig: this.tableConfig,
			queryConfig: this.config,
			tableAlias: this.tableConfig.tsName
		}).sql;
	}
	/** @internal */
	_prepare(isOneTimeQuery = false) {
		const { query, builtQuery } = this._toSQL();
		return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](builtQuery, void 0, this.mode === "first" ? "get" : "all", true, (rawRows, mapColumnValue) => {
			const rows = rawRows.map((row) => mapRelationalRow(this.schema, this.tableConfig, row, query.selection, mapColumnValue));
			if (this.mode === "first") return rows[0];
			return rows;
		});
	}
	prepare() {
		return this._prepare(false);
	}
	_toSQL() {
		const query = this.dialect.buildRelationalQuery({
			fullSchema: this.fullSchema,
			schema: this.schema,
			tableNamesMap: this.tableNamesMap,
			table: this.table,
			tableConfig: this.tableConfig,
			queryConfig: this.config,
			tableAlias: this.tableConfig.tsName
		});
		return {
			query,
			builtQuery: this.dialect.sqlToQuery(query.sql)
		};
	}
	toSQL() {
		return this._toSQL().builtQuery;
	}
	/** @internal */
	executeRaw() {
		if (this.mode === "first") return this._prepare(false).get();
		return this._prepare(false).all();
	}
	async execute() {
		return this.executeRaw();
	}
};
var SQLiteSyncRelationalQuery = class extends SQLiteRelationalQuery {
	static [entityKind] = "SQLiteSyncRelationalQuery";
	sync() {
		return this.executeRaw();
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/query-builders/raw.js
var SQLiteRaw = class extends QueryPromise {
	constructor(execute, getSQL, action, dialect, mapBatchResult) {
		super();
		this.execute = execute;
		this.getSQL = getSQL;
		this.dialect = dialect;
		this.mapBatchResult = mapBatchResult;
		this.config = { action };
	}
	static [entityKind] = "SQLiteRaw";
	/** @internal */
	config;
	getQuery() {
		return {
			...this.dialect.sqlToQuery(this.getSQL()),
			method: this.config.action
		};
	}
	mapResult(result, isFromBatch) {
		return isFromBatch ? this.mapBatchResult(result) : result;
	}
	_prepare() {
		return this;
	}
	/** @internal */
	isResponseInArrayMode() {
		return false;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/db.js
var BaseSQLiteDatabase = class {
	constructor(resultKind, dialect, session, schema) {
		this.resultKind = resultKind;
		this.dialect = dialect;
		this.session = session;
		this._ = schema ? {
			schema: schema.schema,
			fullSchema: schema.fullSchema,
			tableNamesMap: schema.tableNamesMap
		} : {
			schema: void 0,
			fullSchema: {},
			tableNamesMap: {}
		};
		this.query = {};
		const query = this.query;
		if (this._.schema) for (const [tableName, columns] of Object.entries(this._.schema)) query[tableName] = new RelationalQueryBuilder$1(resultKind, schema.fullSchema, this._.schema, this._.tableNamesMap, schema.fullSchema[tableName], columns, dialect, session);
		this.$cache = { invalidate: async (_params) => {} };
	}
	static [entityKind] = "BaseSQLiteDatabase";
	query;
	/**
	* Creates a subquery that defines a temporary named result set as a CTE.
	*
	* It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
	*
	* @param alias The alias for the subquery.
	*
	* Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
	*
	* @example
	*
	* ```ts
	* // Create a subquery with alias 'sq' and use it in the select query
	* const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
	*
	* const result = await db.with(sq).select().from(sq);
	* ```
	*
	* To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
	*
	* ```ts
	* // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
	* const sq = db.$with('sq').as(db.select({
	*   name: sql<string>`upper(${users.name})`.as('name'),
	* })
	* .from(users));
	*
	* const result = await db.with(sq).select({ name: sq.name }).from(sq);
	* ```
	*/
	$with = (alias, selection) => {
		const self = this;
		const as = (qb) => {
			if (typeof qb === "function") qb = qb(new QueryBuilder$1(self.dialect));
			return new Proxy(new WithSubquery(qb.getSQL(), selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}), alias, true), new SelectionProxyHandler({
				alias,
				sqlAliasedBehavior: "alias",
				sqlBehavior: "error"
			}));
		};
		return { as };
	};
	$count(source, filters) {
		return new SQLiteCountBuilder({
			source,
			filters,
			session: this.session
		});
	}
	/**
	* Incorporates a previously defined CTE (using `$with`) into the main query.
	*
	* This method allows the main query to reference a temporary named result set.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
	*
	* @param queries The CTEs to incorporate into the main query.
	*
	* @example
	*
	* ```ts
	* // Define a subquery 'sq' as a CTE using $with
	* const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
	*
	* // Incorporate the CTE 'sq' into the main query and select from it
	* const result = await db.with(sq).select().from(sq);
	* ```
	*/
	with(...queries) {
		const self = this;
		function select(fields) {
			return new SQLiteSelectBuilder({
				fields: fields ?? void 0,
				session: self.session,
				dialect: self.dialect,
				withList: queries
			});
		}
		function selectDistinct(fields) {
			return new SQLiteSelectBuilder({
				fields: fields ?? void 0,
				session: self.session,
				dialect: self.dialect,
				withList: queries,
				distinct: true
			});
		}
		function update(table) {
			return new SQLiteUpdateBuilder(table, self.session, self.dialect, queries);
		}
		function insert(into) {
			return new SQLiteInsertBuilder(into, self.session, self.dialect, queries);
		}
		function delete_(from) {
			return new SQLiteDeleteBase(from, self.session, self.dialect, queries);
		}
		return {
			select,
			selectDistinct,
			update,
			insert,
			delete: delete_
		};
	}
	select(fields) {
		return new SQLiteSelectBuilder({
			fields: fields ?? void 0,
			session: this.session,
			dialect: this.dialect
		});
	}
	selectDistinct(fields) {
		return new SQLiteSelectBuilder({
			fields: fields ?? void 0,
			session: this.session,
			dialect: this.dialect,
			distinct: true
		});
	}
	/**
	* Creates an update query.
	*
	* Calling this method without `.where()` clause will update all rows in a table. The `.where()` clause specifies which rows should be updated.
	*
	* Use `.set()` method to specify which values to update.
	*
	* See docs: {@link https://orm.drizzle.team/docs/update}
	*
	* @param table The table to update.
	*
	* @example
	*
	* ```ts
	* // Update all rows in the 'cars' table
	* await db.update(cars).set({ color: 'red' });
	*
	* // Update rows with filters and conditions
	* await db.update(cars).set({ color: 'red' }).where(eq(cars.brand, 'BMW'));
	*
	* // Update with returning clause
	* const updatedCar: Car[] = await db.update(cars)
	*   .set({ color: 'red' })
	*   .where(eq(cars.id, 1))
	*   .returning();
	* ```
	*/
	update(table) {
		return new SQLiteUpdateBuilder(table, this.session, this.dialect);
	}
	$cache;
	/**
	* Creates an insert query.
	*
	* Calling this method will create new rows in a table. Use `.values()` method to specify which values to insert.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert}
	*
	* @param table The table to insert into.
	*
	* @example
	*
	* ```ts
	* // Insert one row
	* await db.insert(cars).values({ brand: 'BMW' });
	*
	* // Insert multiple rows
	* await db.insert(cars).values([{ brand: 'BMW' }, { brand: 'Porsche' }]);
	*
	* // Insert with returning clause
	* const insertedCar: Car[] = await db.insert(cars)
	*   .values({ brand: 'BMW' })
	*   .returning();
	* ```
	*/
	insert(into) {
		return new SQLiteInsertBuilder(into, this.session, this.dialect);
	}
	/**
	* Creates a delete query.
	*
	* Calling this method without `.where()` clause will delete all rows in a table. The `.where()` clause specifies which rows should be deleted.
	*
	* See docs: {@link https://orm.drizzle.team/docs/delete}
	*
	* @param table The table to delete from.
	*
	* @example
	*
	* ```ts
	* // Delete all rows in the 'cars' table
	* await db.delete(cars);
	*
	* // Delete rows with filters and conditions
	* await db.delete(cars).where(eq(cars.color, 'green'));
	*
	* // Delete with returning clause
	* const deletedCar: Car[] = await db.delete(cars)
	*   .where(eq(cars.id, 1))
	*   .returning();
	* ```
	*/
	delete(from) {
		return new SQLiteDeleteBase(from, this.session, this.dialect);
	}
	run(query) {
		const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
		if (this.resultKind === "async") return new SQLiteRaw(async () => this.session.run(sequel), () => sequel, "run", this.dialect, this.session.extractRawRunValueFromBatchResult.bind(this.session));
		return this.session.run(sequel);
	}
	all(query) {
		const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
		if (this.resultKind === "async") return new SQLiteRaw(async () => this.session.all(sequel), () => sequel, "all", this.dialect, this.session.extractRawAllValueFromBatchResult.bind(this.session));
		return this.session.all(sequel);
	}
	get(query) {
		const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
		if (this.resultKind === "async") return new SQLiteRaw(async () => this.session.get(sequel), () => sequel, "get", this.dialect, this.session.extractRawGetValueFromBatchResult.bind(this.session));
		return this.session.get(sequel);
	}
	values(query) {
		const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
		if (this.resultKind === "async") return new SQLiteRaw(async () => this.session.values(sequel), () => sequel, "values", this.dialect, this.session.extractRawValuesValueFromBatchResult.bind(this.session));
		return this.session.values(sequel);
	}
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/cache/core/cache.js
var Cache = class {
	static [entityKind] = "Cache";
};
var NoopCache = class extends Cache {
	strategy() {
		return "all";
	}
	static [entityKind] = "NoopCache";
	async get(_key) {}
	async put(_hashedQuery, _response, _tables, _config) {}
	async onMutate(_params) {}
};
async function hashQuery(sql, params) {
	const dataToHash = `${sql}-${JSON.stringify(params)}`;
	const data = new TextEncoder().encode(dataToHash);
	const hashBuffer = await crypto.subtle.digest("SHA-256", data);
	return [...new Uint8Array(hashBuffer)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sqlite-core/session.js
var ExecuteResultSync = class extends QueryPromise {
	constructor(resultCb) {
		super();
		this.resultCb = resultCb;
	}
	static [entityKind] = "ExecuteResultSync";
	async execute() {
		return this.resultCb();
	}
	sync() {
		return this.resultCb();
	}
};
var SQLitePreparedQuery = class {
	constructor(mode, executeMethod, query, cache, queryMetadata, cacheConfig) {
		this.mode = mode;
		this.executeMethod = executeMethod;
		this.query = query;
		this.cache = cache;
		this.queryMetadata = queryMetadata;
		this.cacheConfig = cacheConfig;
		if (cache && cache.strategy() === "all" && cacheConfig === void 0) this.cacheConfig = {
			enable: true,
			autoInvalidate: true
		};
		if (!this.cacheConfig?.enable) this.cacheConfig = void 0;
	}
	static [entityKind] = "PreparedQuery";
	/** @internal */
	joinsNotNullableMap;
	/** @internal */
	async queryWithCache(queryString, params, query) {
		if (this.cache === void 0 || is(this.cache, NoopCache) || this.queryMetadata === void 0) try {
			return await query();
		} catch (e) {
			throw new DrizzleQueryError(queryString, params, e);
		}
		if (this.cacheConfig && !this.cacheConfig.enable) try {
			return await query();
		} catch (e) {
			throw new DrizzleQueryError(queryString, params, e);
		}
		if ((this.queryMetadata.type === "insert" || this.queryMetadata.type === "update" || this.queryMetadata.type === "delete") && this.queryMetadata.tables.length > 0) try {
			const [res] = await Promise.all([query(), this.cache.onMutate({ tables: this.queryMetadata.tables })]);
			return res;
		} catch (e) {
			throw new DrizzleQueryError(queryString, params, e);
		}
		if (!this.cacheConfig) try {
			return await query();
		} catch (e) {
			throw new DrizzleQueryError(queryString, params, e);
		}
		if (this.queryMetadata.type === "select") {
			const fromCache = await this.cache.get(this.cacheConfig.tag ?? await hashQuery(queryString, params), this.queryMetadata.tables, this.cacheConfig.tag !== void 0, this.cacheConfig.autoInvalidate);
			if (fromCache === void 0) {
				let result;
				try {
					result = await query();
				} catch (e) {
					throw new DrizzleQueryError(queryString, params, e);
				}
				await this.cache.put(this.cacheConfig.tag ?? await hashQuery(queryString, params), result, this.cacheConfig.autoInvalidate ? this.queryMetadata.tables : [], this.cacheConfig.tag !== void 0, this.cacheConfig.config);
				return result;
			}
			return fromCache;
		}
		try {
			return await query();
		} catch (e) {
			throw new DrizzleQueryError(queryString, params, e);
		}
	}
	getQuery() {
		return this.query;
	}
	mapRunResult(result, _isFromBatch) {
		return result;
	}
	mapAllResult(_result, _isFromBatch) {
		throw new Error("Not implemented");
	}
	mapGetResult(_result, _isFromBatch) {
		throw new Error("Not implemented");
	}
	execute(placeholderValues) {
		if (this.mode === "async") return this[this.executeMethod](placeholderValues);
		return new ExecuteResultSync(() => this[this.executeMethod](placeholderValues));
	}
	mapResult(response, isFromBatch) {
		switch (this.executeMethod) {
			case "run": return this.mapRunResult(response, isFromBatch);
			case "all": return this.mapAllResult(response, isFromBatch);
			case "get": return this.mapGetResult(response, isFromBatch);
		}
	}
};
var SQLiteSession = class {
	constructor(dialect) {
		this.dialect = dialect;
	}
	static [entityKind] = "SQLiteSession";
	prepareOneTimeQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig) {
		return this.prepareQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig);
	}
	run(query) {
		const staticQuery = this.dialect.sqlToQuery(query);
		try {
			return this.prepareOneTimeQuery(staticQuery, void 0, "run", false).run();
		} catch (err) {
			throw new DrizzleError({
				cause: err,
				message: `Failed to run the query '${staticQuery.sql}'`
			});
		}
	}
	/** @internal */
	extractRawRunValueFromBatchResult(result) {
		return result;
	}
	all(query) {
		return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), void 0, "run", false).all();
	}
	/** @internal */
	extractRawAllValueFromBatchResult(_result) {
		throw new Error("Not implemented");
	}
	get(query) {
		return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), void 0, "run", false).get();
	}
	/** @internal */
	extractRawGetValueFromBatchResult(_result) {
		throw new Error("Not implemented");
	}
	values(query) {
		return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), void 0, "run", false).values();
	}
	async count(sql) {
		return (await this.values(sql))[0][0];
	}
	/** @internal */
	extractRawValuesValueFromBatchResult(_result) {
		throw new Error("Not implemented");
	}
};
var SQLiteTransaction = class extends BaseSQLiteDatabase {
	constructor(resultType, dialect, session, schema, nestedIndex = 0) {
		super(resultType, dialect, session, schema);
		this.schema = schema;
		this.nestedIndex = nestedIndex;
	}
	static [entityKind] = "SQLiteTransaction";
	rollback() {
		throw new TransactionRollbackError();
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/d1/session.js
var SQLiteD1Session = class extends SQLiteSession {
	constructor(client, dialect, schema, options = {}) {
		super(dialect);
		this.client = client;
		this.schema = schema;
		this.options = options;
		this.logger = options.logger ?? new NoopLogger();
		this.cache = options.cache ?? new NoopCache();
	}
	static [entityKind] = "SQLiteD1Session";
	logger;
	cache;
	prepareQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig) {
		return new D1PreparedQuery(this.client.prepare(query.sql), query, this.logger, this.cache, queryMetadata, cacheConfig, fields, executeMethod, isResponseInArrayMode, customResultMapper);
	}
	async batch(queries) {
		const preparedQueries = [];
		const builtQueries = [];
		for (const query of queries) {
			const preparedQuery = query._prepare();
			const builtQuery = preparedQuery.getQuery();
			preparedQueries.push(preparedQuery);
			if (builtQuery.params.length > 0) builtQueries.push(preparedQuery.stmt.bind(...builtQuery.params));
			else {
				const builtQuery2 = preparedQuery.getQuery();
				builtQueries.push(this.client.prepare(builtQuery2.sql).bind(...builtQuery2.params));
			}
		}
		return (await this.client.batch(builtQueries)).map((result, i) => preparedQueries[i].mapResult(result, true));
	}
	extractRawAllValueFromBatchResult(result) {
		return result.results;
	}
	extractRawGetValueFromBatchResult(result) {
		return result.results[0];
	}
	extractRawValuesValueFromBatchResult(result) {
		return d1ToRawMapping(result.results);
	}
	async transaction(transaction, config) {
		const tx = new D1Transaction("async", this.dialect, this, this.schema);
		await this.run(sql.raw(`begin${config?.behavior ? " " + config.behavior : ""}`));
		try {
			const result = await transaction(tx);
			await this.run(sql`commit`);
			return result;
		} catch (err) {
			await this.run(sql`rollback`);
			throw err;
		}
	}
};
var D1Transaction = class D1Transaction extends SQLiteTransaction {
	static [entityKind] = "D1Transaction";
	async transaction(transaction) {
		const savepointName = `sp${this.nestedIndex}`;
		const tx = new D1Transaction("async", this.dialect, this.session, this.schema, this.nestedIndex + 1);
		await this.session.run(sql.raw(`savepoint ${savepointName}`));
		try {
			const result = await transaction(tx);
			await this.session.run(sql.raw(`release savepoint ${savepointName}`));
			return result;
		} catch (err) {
			await this.session.run(sql.raw(`rollback to savepoint ${savepointName}`));
			throw err;
		}
	}
};
function d1ToRawMapping(results) {
	const rows = [];
	for (const row of results) {
		const entry = Object.keys(row).map((k) => row[k]);
		rows.push(entry);
	}
	return rows;
}
var D1PreparedQuery = class extends SQLitePreparedQuery {
	constructor(stmt, query, logger, cache, queryMetadata, cacheConfig, fields, executeMethod, _isResponseInArrayMode, customResultMapper) {
		super("async", executeMethod, query, cache, queryMetadata, cacheConfig);
		this.logger = logger;
		this._isResponseInArrayMode = _isResponseInArrayMode;
		this.customResultMapper = customResultMapper;
		this.fields = fields;
		this.stmt = stmt;
	}
	static [entityKind] = "D1PreparedQuery";
	/** @internal */
	customResultMapper;
	/** @internal */
	fields;
	/** @internal */
	stmt;
	async run(placeholderValues) {
		const params = fillPlaceholders(this.query.params, placeholderValues ?? {});
		this.logger.logQuery(this.query.sql, params);
		return await this.queryWithCache(this.query.sql, params, async () => {
			return this.stmt.bind(...params).run();
		});
	}
	async all(placeholderValues) {
		const { fields, query, logger, stmt, customResultMapper } = this;
		if (!fields && !customResultMapper) {
			const params = fillPlaceholders(query.params, placeholderValues ?? {});
			logger.logQuery(query.sql, params);
			return await this.queryWithCache(query.sql, params, async () => {
				return stmt.bind(...params).all().then(({ results }) => this.mapAllResult(results));
			});
		}
		const rows = await this.values(placeholderValues);
		return this.mapAllResult(rows);
	}
	mapAllResult(rows, isFromBatch) {
		if (isFromBatch) rows = d1ToRawMapping(rows.results);
		if (!this.fields && !this.customResultMapper) return rows;
		if (this.customResultMapper) return this.customResultMapper(rows);
		return rows.map((row) => mapResultRow(this.fields, row, this.joinsNotNullableMap));
	}
	async get(placeholderValues) {
		const { fields, joinsNotNullableMap, query, logger, stmt, customResultMapper } = this;
		if (!fields && !customResultMapper) {
			const params = fillPlaceholders(query.params, placeholderValues ?? {});
			logger.logQuery(query.sql, params);
			return await this.queryWithCache(query.sql, params, async () => {
				return stmt.bind(...params).all().then(({ results }) => results[0]);
			});
		}
		const rows = await this.values(placeholderValues);
		if (!rows[0]) return;
		if (customResultMapper) return customResultMapper(rows);
		return mapResultRow(fields, rows[0], joinsNotNullableMap);
	}
	mapGetResult(result, isFromBatch) {
		if (isFromBatch) result = d1ToRawMapping(result.results)[0];
		if (!this.fields && !this.customResultMapper) return result;
		if (this.customResultMapper) return this.customResultMapper([result]);
		return mapResultRow(this.fields, result, this.joinsNotNullableMap);
	}
	async values(placeholderValues) {
		const params = fillPlaceholders(this.query.params, placeholderValues ?? {});
		this.logger.logQuery(this.query.sql, params);
		return await this.queryWithCache(this.query.sql, params, async () => {
			return this.stmt.bind(...params).raw();
		});
	}
	/** @internal */
	isResponseInArrayMode() {
		return this._isResponseInArrayMode;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/d1/driver.js
var DrizzleD1Database = class extends BaseSQLiteDatabase {
	static [entityKind] = "D1Database";
	async batch(batch) {
		return this.session.batch(batch);
	}
};
function drizzle$1(client, config = {}) {
	const dialect = new SQLiteAsyncDialect({ casing: config.casing });
	let logger;
	if (config.logger === true) logger = new DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	let schema;
	if (config.schema) {
		const tablesConfig = extractTablesRelationalConfig(config.schema, createTableRelationsHelpers);
		schema = {
			fullSchema: config.schema,
			schema: tablesConfig.tables,
			tableNamesMap: tablesConfig.tableNamesMap
		};
	}
	const db = new DrizzleD1Database("async", dialect, new SQLiteD1Session(client, dialect, schema, {
		logger,
		cache: config.cache
	}), schema);
	db.$client = client;
	db.$cache = config.cache;
	if (db.$cache) db.$cache["invalidate"] = config.cache?.onMutate;
	return db;
}
//#endregion
//#region src/db/better-auth-schema.ts
var better_auth_schema_exports$1 = /* @__PURE__ */ __exportAll({
	account: () => account$1,
	accountRelations: () => accountRelations$1,
	apikey: () => apikey$1,
	invitation: () => invitation$1,
	invitationRelations: () => invitationRelations$1,
	member: () => member$1,
	memberRelations: () => memberRelations$1,
	organization: () => organization$1,
	organizationRelations: () => organizationRelations$1,
	session: () => session$1,
	sessionRelations: () => sessionRelations$1,
	user: () => user$1,
	userRelations: () => userRelations$1,
	verification: () => verification$1
});
var user$1 = sqliteTable("user", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	email: text("email").notNull().unique(),
	emailVerified: integer("email_verified", { mode: "boolean" }).default(false).notNull(),
	image: text("image"),
	createdAt: integer("created_at", { mode: "timestamp_ms" }).default(sql`(cast(unixepoch('subsecond') * 1000 as integer))`).notNull(),
	updatedAt: integer("updated_at", { mode: "timestamp_ms" }).default(sql`(cast(unixepoch('subsecond') * 1000 as integer))`).$onUpdate(() => /* @__PURE__ */ new Date()).notNull(),
	analyticsOptedOut: integer("analytics_opted_out", { mode: "boolean" }),
	termsAcceptedVersion: text("terms_accepted_version"),
	termsAcceptedAt: integer("terms_accepted_at", { mode: "timestamp_ms" }),
	productUpdatesOptIn: integer("product_updates_opt_in", { mode: "boolean" }),
	productUpdatesChangedAt: integer("product_updates_changed_at", { mode: "timestamp_ms" }),
	lastActiveOrganizationId: text("last_active_organization_id")
});
var session$1 = sqliteTable("session", {
	id: text("id").primaryKey(),
	expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
	token: text("token").notNull().unique(),
	createdAt: integer("created_at", { mode: "timestamp_ms" }).default(sql`(cast(unixepoch('subsecond') * 1000 as integer))`).notNull(),
	updatedAt: integer("updated_at", { mode: "timestamp_ms" }).$onUpdate(() => /* @__PURE__ */ new Date()).notNull(),
	ipAddress: text("ip_address"),
	userAgent: text("user_agent"),
	userId: text("user_id").notNull().references(() => user$1.id, { onDelete: "cascade" }),
	activeOrganizationId: text("active_organization_id")
}, (table) => [index$1("session_userId_idx").on(table.userId)]);
var account$1 = sqliteTable("account", {
	id: text("id").primaryKey(),
	accountId: text("account_id").notNull(),
	providerId: text("provider_id").notNull(),
	userId: text("user_id").notNull().references(() => user$1.id, { onDelete: "cascade" }),
	accessToken: text("access_token"),
	refreshToken: text("refresh_token"),
	idToken: text("id_token"),
	accessTokenExpiresAt: integer("access_token_expires_at", { mode: "timestamp_ms" }),
	refreshTokenExpiresAt: integer("refresh_token_expires_at", { mode: "timestamp_ms" }),
	scope: text("scope"),
	password: text("password"),
	createdAt: integer("created_at", { mode: "timestamp_ms" }).default(sql`(cast(unixepoch('subsecond') * 1000 as integer))`).notNull(),
	updatedAt: integer("updated_at", { mode: "timestamp_ms" }).$onUpdate(() => /* @__PURE__ */ new Date()).notNull()
}, (table) => [
	index$1("account_userId_idx").on(table.userId),
	index$1("account_accountId_providerId_idx").on(table.accountId, table.providerId),
	uniqueIndex$1("account_google_grant_owner_idx").on(table.userId, table.providerId, table.accountId).where(sql`${table.providerId} in ('google-search-console', 'google-analytics')`)
]);
var verification$1 = sqliteTable("verification", {
	id: text("id").primaryKey(),
	identifier: text("identifier").notNull(),
	value: text("value").notNull(),
	expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
	createdAt: integer("created_at", { mode: "timestamp_ms" }).default(sql`(cast(unixepoch('subsecond') * 1000 as integer))`).notNull(),
	updatedAt: integer("updated_at", { mode: "timestamp_ms" }).default(sql`(cast(unixepoch('subsecond') * 1000 as integer))`).$onUpdate(() => /* @__PURE__ */ new Date()).notNull()
}, (table) => [index$1("verification_identifier_idx").on(table.identifier), index$1("verification_expiresAt_idx").on(table.expiresAt)]);
var organization$1 = sqliteTable("organization", {
	id: text("id").primaryKey(),
	name: text("name").notNull(),
	slug: text("slug").notNull().unique(),
	logo: text("logo"),
	createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull(),
	metadata: text("metadata")
}, (table) => [uniqueIndex$1("organization_slug_uidx").on(table.slug)]);
var member$1 = sqliteTable("member", {
	id: text("id").primaryKey(),
	organizationId: text("organization_id").notNull().references(() => organization$1.id, { onDelete: "cascade" }),
	userId: text("user_id").notNull().references(() => user$1.id, { onDelete: "cascade" }),
	role: text("role").default("member").notNull(),
	createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull()
}, (table) => [
	index$1("member_organizationId_idx").on(table.organizationId),
	index$1("member_userId_idx").on(table.userId),
	uniqueIndex$1("member_organizationId_userId_uidx").on(table.organizationId, table.userId)
]);
var invitation$1 = sqliteTable("invitation", {
	id: text("id").primaryKey(),
	organizationId: text("organization_id").notNull().references(() => organization$1.id, { onDelete: "cascade" }),
	email: text("email").notNull(),
	role: text("role"),
	status: text("status").default("pending").notNull(),
	expiresAt: integer("expires_at", { mode: "timestamp_ms" }).notNull(),
	createdAt: integer("created_at", { mode: "timestamp_ms" }).default(sql`(cast(unixepoch('subsecond') * 1000 as integer))`).notNull(),
	inviterId: text("inviter_id").notNull().references(() => user$1.id, { onDelete: "cascade" })
}, (table) => [index$1("invitation_organizationId_idx").on(table.organizationId), index$1("invitation_email_idx").on(table.email)]);
var apikey$1 = sqliteTable("apikey", {
	id: text("id").primaryKey(),
	configId: text("config_id").default("default").notNull(),
	name: text("name"),
	start: text("start"),
	prefix: text("prefix"),
	key: text("key").notNull(),
	referenceId: text("reference_id").notNull(),
	refillInterval: integer("refill_interval"),
	refillAmount: integer("refill_amount"),
	lastRefillAt: integer("last_refill_at", { mode: "timestamp_ms" }),
	enabled: integer("enabled", { mode: "boolean" }).default(true),
	rateLimitEnabled: integer("rate_limit_enabled", { mode: "boolean" }).default(true),
	rateLimitTimeWindow: integer("rate_limit_time_window").default(6e4),
	rateLimitMax: integer("rate_limit_max").default(120),
	requestCount: integer("request_count").default(0),
	remaining: integer("remaining"),
	lastRequest: integer("last_request", { mode: "timestamp_ms" }),
	expiresAt: integer("expires_at", { mode: "timestamp_ms" }),
	createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull(),
	updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull(),
	permissions: text("permissions"),
	metadata: text("metadata")
}, (table) => [
	index$1("apikey_configId_idx").on(table.configId),
	index$1("apikey_referenceId_idx").on(table.referenceId),
	index$1("apikey_key_idx").on(table.key)
]);
var userRelations$1 = relations(user$1, ({ many }) => ({
	sessions: many(session$1),
	accounts: many(account$1),
	members: many(member$1),
	invitations: many(invitation$1)
}));
var sessionRelations$1 = relations(session$1, ({ one }) => ({ user: one(user$1, {
	fields: [session$1.userId],
	references: [user$1.id]
}) }));
var accountRelations$1 = relations(account$1, ({ one }) => ({ user: one(user$1, {
	fields: [account$1.userId],
	references: [user$1.id]
}) }));
var organizationRelations$1 = relations(organization$1, ({ many }) => ({
	members: many(member$1),
	invitations: many(invitation$1)
}));
var memberRelations$1 = relations(member$1, ({ one }) => ({
	organization: one(organization$1, {
		fields: [member$1.organizationId],
		references: [organization$1.id]
	}),
	user: one(user$1, {
		fields: [member$1.userId],
		references: [user$1.id]
	})
}));
var invitationRelations$1 = relations(invitation$1, ({ one }) => ({
	organization: one(organization$1, {
		fields: [invitation$1.organizationId],
		references: [organization$1.id]
	}),
	user: one(user$1, {
		fields: [invitation$1.inviterId],
		references: [user$1.id]
	})
}));
//#endregion
//#region src/db/dashboard.schema.ts
var dataRefreshClaims$1 = sqliteTable("data_refresh_claims", {
	key: text("key").primaryKey(),
	organizationId: text("organization_id").notNull().references(() => organization$1.id, { onDelete: "cascade" }),
	token: text("token").notNull(),
	nextAttemptAt: integer("next_attempt_at").notNull()
});
//#endregion
//#region src/db/app.schema.ts
var app_schema_exports$1 = /* @__PURE__ */ __exportAll({
	accountDeletionRequests: () => accountDeletionRequests$1,
	backlinkSnapshots: () => backlinkSnapshots$1,
	crawlerCredentials: () => crawlerCredentials$1,
	dashboardStepDismissals: () => dashboardStepDismissals$1,
	dataRefreshClaims: () => dataRefreshClaims$1,
	guestAccounts: () => guestAccounts$1,
	keywordMetrics: () => keywordMetrics$1,
	organizationActivationState: () => organizationActivationState$1,
	projectActivationState: () => projectActivationState$1,
	projects: () => projects$1,
	rankCheckRuns: () => rankCheckRuns$1,
	rankSnapshots: () => rankSnapshots$1,
	rankTrackingConfigs: () => rankTrackingConfigs$1,
	rankTrackingKeywords: () => rankTrackingKeywords$1,
	savedKeywordTagAssignments: () => savedKeywordTagAssignments$1,
	savedKeywordTags: () => savedKeywordTags$1,
	savedKeywords: () => savedKeywords$1,
	userOnboardingAnswers: () => userOnboardingAnswers$1,
	userSignupCampaigns: () => userSignupCampaigns$1
});
var userOnboardingAnswers$1 = sqliteTable("user_onboarding_answers", {
	userId: text("user_id").primaryKey().references(() => user$1.id, { onDelete: "cascade" }),
	organizationId: text("organization_id").notNull().references(() => organization$1.id, { onDelete: "cascade" }),
	interestedFeatures: text("interested_features").notNull().default("[]"),
	workFor: text("work_for"),
	clientWebsiteCount: text("client_website_count"),
	foundVia: text("found_via"),
	mcpSetupIntent: text("mcp_setup_intent"),
	completedAt: text("completed_at"),
	gscNudgeDismissedAt: text("gsc_nudge_dismissed_at"),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`),
	updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [index$1("user_onboarding_answers_organization_idx").on(table.organizationId)]);
var userSignupCampaigns$1 = sqliteTable("user_signup_campaigns", {
	userId: text("user_id").primaryKey().references(() => user$1.id, { onDelete: "cascade" }),
	entry: text("entry"),
	wasGuest: integer("was_guest", { mode: "boolean" }),
	agent: text("agent"),
	utmMedium: text("utm_medium"),
	utmSource: text("utm_source"),
	utmCampaign: text("utm_campaign"),
	utmContent: text("utm_content")
});
var guestAccounts$1 = sqliteTable("guest_accounts", {
	userId: text("user_id").primaryKey(),
	ipHash: text("ip_hash").notNull(),
	slot: integer("slot").notNull().default(0),
	claimToken: text("claim_token").notNull().unique(),
	agent: text("agent"),
	claimedByUserId: text("claimed_by_user_id").references(() => user$1.id, { onDelete: "set null" }),
	createdAt: text("created_at").notNull()
}, (table) => [uniqueIndex$1("guest_accounts_ip_hash_slot_idx").on(table.ipHash, table.slot)]);
var accountDeletionRequests$1 = sqliteTable("account_deletion_requests", {
	userId: text("user_id").primaryKey().references(() => user$1.id, { onDelete: "cascade" }),
	requestedAt: text("requested_at").notNull(),
	deleteAfter: text("delete_after").notNull()
}, (table) => [index$1("account_deletion_requests_delete_after_idx").on(table.deleteAfter)]);
var projects$1 = sqliteTable("projects", {
	id: text("id").primaryKey(),
	organizationId: text("organization_id").notNull().references(() => organization$1.id, { onDelete: "cascade" }),
	name: text("name").notNull(),
	brandName: text("brand_name"),
	domain: text("domain"),
	locationCode: integer("location_code").notNull().default(2840),
	languageCode: text("language_code").notNull().default("en"),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`),
	archivedAt: text("archived_at"),
	aiResearchKeywords: text("ai_research_keywords"),
	indexnowKey: text("indexnow_key")
}, (table) => [uniqueIndex$1("projects_one_default_per_organization_idx").on(table.organizationId).where(sql`${table.name} = 'Default' AND ${table.domain} IS NULL AND ${table.archivedAt} IS NULL`), index$1("projects_organization_id_idx").on(table.organizationId)]);
var savedKeywords$1 = sqliteTable("saved_keywords", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	keyword: text("keyword").notNull(),
	locationCode: integer("location_code").notNull().default(2840),
	languageCode: text("language_code").notNull().default("en"),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [uniqueIndex$1("saved_keywords_unique_project_keyword_location_language").on(table.projectId, table.keyword, table.locationCode, table.languageCode), index$1("saved_keywords_project_created_idx").on(table.projectId, table.createdAt)]);
var savedKeywordTags$1 = sqliteTable("saved_keyword_tags", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	name: text("name").notNull(),
	normalizedName: text("normalized_name").notNull(),
	color: text("color"),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [uniqueIndex$1("saved_keyword_tags_project_normalized_name_idx").on(table.projectId, table.normalizedName), index$1("saved_keyword_tags_project_name_idx").on(table.projectId, table.name)]);
var savedKeywordTagAssignments$1 = sqliteTable("saved_keyword_tag_assignments", {
	savedKeywordId: text("saved_keyword_id").notNull().references(() => savedKeywords$1.id, { onDelete: "cascade" }),
	tagId: text("tag_id").notNull().references(() => savedKeywordTags$1.id, { onDelete: "cascade" }),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [uniqueIndex$1("saved_keyword_tag_assignments_unique_idx").on(table.savedKeywordId, table.tagId), index$1("saved_keyword_tag_assignments_tag_idx").on(table.tagId)]);
var keywordMetrics$1 = sqliteTable("keyword_metrics", {
	id: integer("id").primaryKey({ autoIncrement: true }),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	keyword: text("keyword").notNull(),
	locationCode: integer("location_code").notNull(),
	languageCode: text("language_code").notNull().default("en"),
	searchVolume: integer("search_volume"),
	cpc: real("cpc"),
	competition: real("competition"),
	keywordDifficulty: integer("keyword_difficulty"),
	intent: text("intent"),
	monthlySearches: text("monthly_searches"),
	fetchedAt: text("fetched_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [uniqueIndex$1("keyword_metrics_unique_project_keyword_location_language").on(table.projectId, table.keyword, table.locationCode, table.languageCode), index$1("keyword_metrics_lookup_idx").on(table.projectId, table.keyword, table.locationCode, table.languageCode, table.fetchedAt)]);
var rankTrackingConfigs$1 = sqliteTable("rank_tracking_configs", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	domain: text("domain").notNull(),
	locationCode: integer("location_code").notNull().default(2840),
	languageCode: text("language_code").notNull().default("en"),
	devices: text("devices", { enum: [
		"both",
		"desktop",
		"mobile"
	] }).notNull().default("both"),
	serpDepth: integer("serp_depth").notNull(),
	scheduleInterval: text("schedule_interval", { enum: [
		"daily",
		"weekly",
		"monthly",
		"manual"
	] }).notNull().default("weekly"),
	locationName: text("location_name"),
	isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
	lastCheckedAt: text("last_checked_at"),
	nextCheckAt: text("next_check_at"),
	lastSkipReason: text("last_skip_reason"),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [
	index$1("rank_tracking_configs_project_active_created_idx").on(table.projectId, table.isActive, table.createdAt),
	uniqueIndex$1("rank_tracking_configs_national_idx").on(table.projectId, table.domain, table.locationCode, table.languageCode).where(sql`${table.locationName} IS NULL`),
	uniqueIndex$1("rank_tracking_configs_local_idx").on(table.projectId, table.domain, table.locationCode, table.languageCode, table.locationName).where(sql`${table.locationName} IS NOT NULL`)
]);
var rankTrackingKeywords$1 = sqliteTable("rank_tracking_keywords", {
	id: text("id").primaryKey(),
	configId: text("config_id").notNull().references(() => rankTrackingConfigs$1.id, { onDelete: "cascade" }),
	keyword: text("keyword").notNull(),
	matchCase: integer("match_case", { mode: "boolean" }).notNull().default(false),
	searchVolume: integer("search_volume"),
	keywordDifficulty: integer("keyword_difficulty"),
	cpc: real("cpc"),
	metricsFetchedAt: text("metrics_fetched_at"),
	pinnedAt: text("pinned_at"),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [uniqueIndex$1("rank_tracking_keywords_config_keyword_idx").on(table.configId, table.keyword)]);
var rankCheckRuns$1 = sqliteTable("rank_check_runs", {
	id: text("id").primaryKey(),
	configId: text("config_id").notNull().references(() => rankTrackingConfigs$1.id, { onDelete: "cascade" }),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	status: text("status", { enum: [
		"pending",
		"running",
		"completed",
		"failed"
	] }).notNull().default("pending"),
	keywordsTotal: integer("keywords_total").notNull().default(0),
	keywordsChecked: integer("keywords_checked").notNull().default(0),
	isSubsetRun: integer("is_subset_run", { mode: "boolean" }).notNull().default(false),
	errorMessage: text("error_message"),
	startedAt: text("started_at").notNull().default(sql`(current_timestamp)`),
	completedAt: text("completed_at")
}, (table) => [
	index$1("rank_check_runs_config_idx").on(table.configId, table.startedAt),
	index$1("rank_check_runs_project_idx").on(table.projectId, table.startedAt),
	uniqueIndex$1("rank_check_runs_one_active_per_config_idx").on(table.configId).where(sql`${table.status} IN ('pending', 'running')`)
]);
var rankSnapshots$1 = sqliteTable("rank_snapshots", {
	id: integer("id").primaryKey({ autoIncrement: true }),
	runId: text("run_id").notNull().references(() => rankCheckRuns$1.id, { onDelete: "cascade" }),
	trackingKeywordId: text("tracking_keyword_id").notNull(),
	keyword: text("keyword").notNull(),
	device: text("device", { enum: ["desktop", "mobile"] }).notNull(),
	position: integer("position"),
	url: text("url"),
	serpFeatures: text("serp_features"),
	checkedAt: text("checked_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [index$1("rank_snapshots_keyword_device_idx").on(table.trackingKeywordId, table.device, table.checkedAt), uniqueIndex$1("rank_snapshots_run_keyword_device_idx").on(table.runId, table.trackingKeywordId, table.device)]);
var organizationActivationState$1 = sqliteTable("organization_activation_state", {
	organizationId: text("organization_id").primaryKey().references(() => organization$1.id, { onDelete: "cascade" }),
	firstMcpAuthorizedAt: text("first_mcp_authorized_at"),
	firstMcpToolCallAt: text("first_mcp_tool_call_at"),
	updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`)
});
var projectActivationState$1 = sqliteTable("project_activation_state", {
	projectId: text("project_id").primaryKey().references(() => projects$1.id, { onDelete: "cascade" }),
	competitorResearchedAt: text("competitor_step_clicked_at"),
	keywordResearchedAt: text("keyword_step_clicked_at"),
	mcpCardDismissedAt: text("mcp_card_dismissed_at"),
	ga4CardDismissedAt: text("ga4_card_dismissed_at"),
	updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`)
});
var backlinkSnapshots$1 = sqliteTable("backlink_snapshots", {
	id: integer("id").primaryKey({ autoIncrement: true }),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	domain: text("domain").notNull(),
	rank: integer("rank"),
	backlinks: integer("backlinks"),
	referringDomains: integer("referring_domains"),
	brokenBacklinks: integer("broken_backlinks"),
	newBacklinks: integer("new_backlinks"),
	lostBacklinks: integer("lost_backlinks"),
	newReferringDomains: integer("new_referring_domains"),
	lostReferringDomains: integer("lost_referring_domains"),
	capturedAt: text("captured_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [index$1("backlink_snapshots_project_captured_idx").on(table.projectId, table.capturedAt)]);
var dashboardStepDismissals$1 = sqliteTable("dashboard_step_dismissals", {
	userId: text("user_id").notNull().references(() => user$1.id, { onDelete: "cascade" }),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	step: text("step").notNull()
}, (table) => [primaryKey({ columns: [
	table.userId,
	table.projectId,
	table.step
] }), index$1("dashboard_step_dismissals_project_idx").on(table.projectId)]);
var crawlerCredentials$1 = sqliteTable("crawler_credentials", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	host: text("host").notNull(),
	provider: text("provider", { enum: ["shopify"] }).notNull(),
	signatureInput: text("signature_input").notNull(),
	signature: text("signature").notNull(),
	expiresAt: text("expires_at"),
	createdByUserId: text("created_by_user_id"),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [uniqueIndex$1("crawler_credentials_project_host_idx").on(table.projectId, table.host)]);
//#endregion
//#region src/db/project-context.schema.ts
var project_context_schema_exports$1 = /* @__PURE__ */ __exportAll({
	projectCompetitors: () => projectCompetitors$1,
	projectContextSections: () => projectContextSections$1,
	projectKeyPages: () => projectKeyPages$1,
	projectResearchLog: () => projectResearchLog$1
});
var projectContextSections$1 = sqliteTable("project_context_sections", {
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	key: text("key").notNull(),
	title: text("title"),
	content: text("content").notNull(),
	updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`),
	updatedBy: text("updated_by", { enum: [
		"user",
		"sam",
		"mcp"
	] }).notNull()
}, (table) => [primaryKey({ columns: [table.projectId, table.key] })]);
var projectCompetitors$1 = sqliteTable("project_competitors", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	domain: text("domain").notNull(),
	name: text("name"),
	notes: text("notes"),
	updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`),
	updatedBy: text("updated_by", { enum: [
		"user",
		"sam",
		"mcp"
	] }).notNull()
}, (table) => [uniqueIndex$1("project_competitors_project_domain_idx").on(table.projectId, table.domain)]);
var projectKeyPages$1 = sqliteTable("project_key_pages", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	url: text("url").notNull(),
	role: text("role", { enum: [
		"hub",
		"spoke",
		"money",
		"other"
	] }).notNull(),
	topic: text("topic"),
	notes: text("notes"),
	updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`),
	updatedBy: text("updated_by", { enum: [
		"user",
		"sam",
		"mcp"
	] }).notNull()
}, (table) => [uniqueIndex$1("project_key_pages_project_url_idx").on(table.projectId, table.url)]);
var projectResearchLog$1 = sqliteTable("project_research_log", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	entryDate: text("entry_date").notNull(),
	summary: text("summary").notNull(),
	createdBy: text("created_by", { enum: [
		"user",
		"sam",
		"mcp"
	] }).notNull(),
	createdAt: text("created_at").notNull().default(sql`(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`)
}, (table) => [index$1("project_research_log_project_date_idx").on(table.projectId, table.entryDate)]);
//#endregion
//#region src/db/reports.schema.ts
var reports_schema_exports$1 = /* @__PURE__ */ __exportAll({ reports: () => reports$1 });
var reports$1 = sqliteTable("reports", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	title: text("title").notNull(),
	summary: text("summary").notNull(),
	html: text("html").notNull(),
	skill: text("skill"),
	templateId: text("template_id"),
	createdBy: text("created_by").notNull(),
	createdByUserId: text("created_by_user_id").notNull(),
	sizeBytes: integer("size_bytes").notNull(),
	shareToken: text("share_token"),
	sharedAt: text("shared_at"),
	createdAt: text("created_at").notNull().default(sql`(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`),
	updatedAt: text("updated_at").notNull().default(sql`(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`)
}, (table) => [index$1("reports_project_updated_idx").on(table.projectId, table.updatedAt, table.id, table.sizeBytes), uniqueIndex$1("reports_share_token_idx").on(table.shareToken)]);
//#endregion
//#region src/db/report-templates.schema.ts
var report_templates_schema_exports$1 = /* @__PURE__ */ __exportAll({ reportTemplates: () => reportTemplates$1 });
var reportTemplates$1 = sqliteTable("report_templates", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	name: text("name").notNull(),
	description: text("description").notNull(),
	instructions: text("instructions").notNull(),
	createdBy: text("created_by").notNull(),
	createdByUserId: text("created_by_user_id").notNull(),
	createdAt: text("created_at").notNull().default(sql`(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`),
	updatedAt: text("updated_at").notNull().default(sql`(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`)
}, (table) => [uniqueIndex$1("report_templates_project_name_idx").on(table.projectId, table.name)]);
//#endregion
//#region src/shared/audit-fetch-class.ts
var PAGE_FETCH_CLASSES = [
	"ok",
	"blocked",
	"rate_limited",
	"error"
];
//#endregion
//#region src/db/audit.schema.ts
var audit_schema_exports$1 = /* @__PURE__ */ __exportAll({
	auditIssues: () => auditIssues$1,
	auditLighthouseResults: () => auditLighthouseResults$1,
	auditPages: () => auditPages$1,
	audits: () => audits$1
});
var audits$1 = sqliteTable("audits", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	startedByUserId: text("started_by_user_id").notNull(),
	startUrl: text("start_url").notNull(),
	status: text("status", { enum: [
		"running",
		"completed",
		"failed"
	] }).notNull().default("running"),
	workflowInstanceId: text("workflow_instance_id"),
	config: text("config").notNull().default("{}"),
	pagesCrawled: integer("pages_crawled").notNull().default(0),
	pagesTotal: integer("pages_total").notNull().default(0),
	lighthouseTotal: integer("lighthouse_total").notNull().default(0),
	lighthouseCompleted: integer("lighthouse_completed").notNull().default(0),
	lighthouseFailed: integer("lighthouse_failed").notNull().default(0),
	currentPhase: text("current_phase").default("discovery"),
	errorCode: text("error_code"),
	errorDetail: text("error_detail"),
	failedPhase: text("failed_phase"),
	startedAt: text("started_at").notNull().default(sql`(current_timestamp)`),
	completedAt: text("completed_at")
}, (table) => [index$1("audits_project_id_idx").on(table.projectId), index$1("audits_started_by_user_id_idx").on(table.startedByUserId)]);
var auditPages$1 = sqliteTable("audit_pages", {
	id: text("id").primaryKey(),
	auditId: text("audit_id").notNull().references(() => audits$1.id, { onDelete: "cascade" }),
	url: text("url").notNull(),
	statusCode: integer("status_code"),
	redirectUrl: text("redirect_url"),
	title: text("title"),
	metaDescription: text("meta_description"),
	canonicalUrl: text("canonical_url"),
	robotsMeta: text("robots_meta"),
	ogTitle: text("og_title"),
	ogDescription: text("og_description"),
	ogImage: text("og_image"),
	h1Count: integer("h1_count").notNull().default(0),
	h2Count: integer("h2_count").notNull().default(0),
	h3Count: integer("h3_count").notNull().default(0),
	h4Count: integer("h4_count").notNull().default(0),
	h5Count: integer("h5_count").notNull().default(0),
	h6Count: integer("h6_count").notNull().default(0),
	wordCount: integer("word_count").notNull().default(0),
	imagesTotal: integer("images_total").notNull().default(0),
	imagesMissingAlt: integer("images_missing_alt").notNull().default(0),
	internalLinkCount: integer("internal_link_count").notNull().default(0),
	externalLinkCount: integer("external_link_count").notNull().default(0),
	hasStructuredData: integer("has_structured_data", { mode: "boolean" }).notNull().default(false),
	isIndexable: integer("is_indexable", { mode: "boolean" }).notNull().default(true),
	xRobotsTag: text("x_robots_tag"),
	headerCanonicalUrl: text("header_canonical_url"),
	crawlDepth: integer("crawl_depth"),
	inSitemap: integer("in_sitemap", { mode: "boolean" }).notNull().default(false),
	contentHash: text("content_hash"),
	fetchClass: text("fetch_class", { enum: PAGE_FETCH_CLASSES }).notNull().default("ok"),
	responseTimeMs: integer("response_time_ms")
}, (table) => [index$1("audit_pages_audit_url_idx").on(table.auditId, table.url)]);
var auditIssues$1 = sqliteTable("audit_issues", {
	id: text("id").primaryKey(),
	auditId: text("audit_id").notNull().references(() => audits$1.id, { onDelete: "cascade" }),
	pageId: text("page_id").references(() => auditPages$1.id, { onDelete: "cascade" }),
	pageUrl: text("page_url").notNull(),
	issueType: text("issue_type").notNull(),
	severity: text("severity", { enum: [
		"critical",
		"warning",
		"info"
	] }).notNull().default("info"),
	detailsJson: text("details_json")
}, (table) => [index$1("audit_issues_audit_type_idx").on(table.auditId, table.issueType), index$1("audit_issues_page_id_idx").on(table.pageId)]);
var auditLighthouseResults$1 = sqliteTable("audit_lighthouse_results", {
	id: text("id").primaryKey(),
	auditId: text("audit_id").notNull().references(() => audits$1.id, { onDelete: "cascade" }),
	pageId: text("page_id").notNull().references(() => auditPages$1.id, { onDelete: "cascade" }),
	strategy: text("strategy", { enum: ["mobile", "desktop"] }).notNull(),
	performanceScore: integer("performance_score"),
	accessibilityScore: integer("accessibility_score"),
	bestPracticesScore: integer("best_practices_score"),
	seoScore: integer("seo_score"),
	lcpMs: real("lcp_ms"),
	cls: real("cls"),
	inpMs: real("inp_ms"),
	ttfbMs: real("ttfb_ms"),
	errorMessage: text("error_message"),
	r2Key: text("r2_key"),
	payloadSizeBytes: integer("payload_size_bytes")
}, (table) => [index$1("audit_lighthouse_results_audit_id_idx").on(table.auditId), index$1("audit_lighthouse_results_page_id_idx").on(table.pageId)]);
//#endregion
//#region src/db/sam.schema.ts
var sam_schema_exports$1 = /* @__PURE__ */ __exportAll({ samSessions: () => samSessions$1 });
var samSessions$1 = sqliteTable("sam_sessions", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	userId: text("user_id").notNull().references(() => user$1.id, { onDelete: "cascade" }),
	title: text("title").notNull().default("New chat"),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`),
	updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`),
	archivedAt: text("archived_at")
}, (table) => [index$1("sam_sessions_project_updated_idx").on(table.projectId, table.updatedAt)]);
//#endregion
//#region src/db/billing.schema.ts
var billing_schema_exports$1 = /* @__PURE__ */ __exportAll({ billingCustomerStatus: () => billingCustomerStatus$1 });
var billingCustomerStatus$1 = sqliteTable("billing_customer_status", {
	organizationId: text("organization_id").primaryKey().references(() => organization$1.id, { onDelete: "cascade" }),
	isPaying: integer("is_paying", { mode: "boolean" }).notNull().default(false),
	paidPlanId: text("paid_plan_id"),
	paidPlanStatus: text("paid_plan_status"),
	customerJson: text("customer_json").notNull(),
	syncedAt: text("synced_at").notNull(),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`),
	updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`)
});
//#endregion
//#region src/db/ga4.schema.ts
var ga4_schema_exports$1 = /* @__PURE__ */ __exportAll({ ga4Connections: () => ga4Connections$1 });
var ga4Connections$1 = sqliteTable("ga4_connections", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	organizationId: text("organization_id").notNull().references(() => organization$1.id, { onDelete: "cascade" }),
	propertyId: text("property_id").notNull(),
	propertyDisplayName: text("property_display_name").notNull(),
	propertyTimeZone: text("property_time_zone").notNull(),
	propertyCurrencyCode: text("property_currency_code").notNull(),
	connectedByUserId: text("connected_by_user_id").notNull(),
	ga4AccountId: text("ga4_account_id").notNull(),
	connectedAccountEmail: text("connected_account_email"),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`),
	updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [
	uniqueIndex$1("ga4_connections_project_idx").on(table.projectId),
	index$1("ga4_connections_organization_idx").on(table.organizationId),
	index$1("ga4_connections_connector_idx").on(table.connectedByUserId, table.ga4AccountId)
]);
//#endregion
//#region src/db/gsc.schema.ts
var gsc_schema_exports$1 = /* @__PURE__ */ __exportAll({ gscConnections: () => gscConnections$1 });
var gscConnections$1 = sqliteTable("gsc_connections", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	organizationId: text("organization_id").notNull().references(() => organization$1.id, { onDelete: "cascade" }),
	siteUrl: text("site_url").notNull(),
	connectedByUserId: text("connected_by_user_id").notNull(),
	gscAccountId: text("gsc_account_id"),
	connectedAccountEmail: text("connected_account_email"),
	createdAt: text("created_at").notNull().default(sql`(current_timestamp)`),
	updatedAt: text("updated_at").notNull().default(sql`(current_timestamp)`)
}, (table) => [uniqueIndex$1("gsc_connections_project_idx").on(table.projectId), index$1("gsc_connections_organization_idx").on(table.organizationId)]);
//#endregion
//#region src/db/telemetry.schema.ts
var telemetry_schema_exports$1 = /* @__PURE__ */ __exportAll({ telemetryState: () => telemetryState$1 });
var telemetryState$1 = sqliteTable("telemetry_state", {
	id: integer("id").primaryKey().default(1),
	installId: text("install_id").notNull(),
	installedAt: integer("installed_at", { mode: "timestamp_ms" }),
	lastHeartbeatAt: integer("last_heartbeat_at", { mode: "timestamp_ms" }),
	lastVersion: text("last_version"),
	mcpToolCallCount: integer("mcp_tool_call_count").notNull().default(0)
});
//#endregion
//#region src/db/ai-visibility.schema.ts
var ai_visibility_schema_exports$1 = /* @__PURE__ */ __exportAll({
	aiMatches: () => aiMatches$1,
	aiObservations: () => aiObservations$1,
	aiPrompts: () => aiPrompts$1,
	aiRuns: () => aiRuns$1,
	aiSources: () => aiSources$1,
	aiTrackers: () => aiTrackers$1
});
var aiTrackers$1 = sqliteTable("ai_trackers", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	enabled: integer("enabled", { mode: "boolean" }).notNull().default(false),
	chatgpt: integer("chatgpt", { mode: "boolean" }).notNull().default(true),
	gemini: integer("gemini", { mode: "boolean" }).notNull().default(false),
	claude: integer("claude", { mode: "boolean" }).notNull().default(false),
	perplexity: integer("perplexity", { mode: "boolean" }).notNull().default(false),
	googleAiOverview: integer("google_ai_overview", { mode: "boolean" }).notNull().default(false),
	locationCode: integer("location_code").notNull().default(2840),
	languageCode: text("language_code").notNull().default("en"),
	scheduleInterval: text("schedule_interval", { enum: [
		"daily",
		"weekly",
		"monthly"
	] }).notNull().default("weekly"),
	nextCheckAt: text("next_check_at"),
	lastSkipReason: text("last_skip_reason"),
	createdAt: text("created_at").notNull()
}, (t) => [uniqueIndex$1("ai_trackers_project_idx").on(t.projectId), index$1("ai_trackers_due_idx").on(t.enabled, t.nextCheckAt)]);
var aiPrompts$1 = sqliteTable("ai_prompts", {
	id: text("id").primaryKey(),
	trackerId: text("tracker_id").notNull().references(() => aiTrackers$1.id, { onDelete: "cascade" }),
	topic: text("topic").notNull(),
	text: text("text").notNull(),
	paused: integer("paused", { mode: "boolean" }).notNull().default(false),
	archived: integer("archived", { mode: "boolean" }).notNull().default(false),
	createdAt: text("created_at").notNull()
}, (t) => [index$1("ai_prompts_tracker_idx").on(t.trackerId)]);
var aiRuns$1 = sqliteTable("ai_runs", {
	id: text("id").primaryKey(),
	trackerId: text("tracker_id").notNull().references(() => aiTrackers$1.id, { onDelete: "cascade" }),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	trigger: text("trigger", { enum: [
		"baseline",
		"scheduled",
		"manual"
	] }).notNull(),
	status: text("status", { enum: [
		"queued",
		"running",
		"completed",
		"partial",
		"failed"
	] }).notNull().default("queued"),
	locationCode: integer("location_code").notNull(),
	languageCode: text("language_code").notNull(),
	createdAt: text("created_at").notNull(),
	completedAt: text("completed_at")
}, (t) => [index$1("ai_runs_project_created_idx").on(t.projectId, t.createdAt), uniqueIndex$1("ai_runs_one_active_idx").on(t.trackerId).where(sql`${t.status} IN ('queued', 'running')`)]);
var aiObservations$1 = sqliteTable("ai_observations", {
	id: text("id").primaryKey(),
	runId: text("run_id").notNull().references(() => aiRuns$1.id, { onDelete: "cascade" }),
	promptId: text("prompt_id").notNull().references(() => aiPrompts$1.id, { onDelete: "cascade" }),
	engine: text("engine", { enum: [
		"chatgpt",
		"gemini",
		"google_ai_overview",
		"claude",
		"perplexity"
	] }).notNull(),
	branded: integer("branded", { mode: "boolean" }).notNull(),
	status: text("status", { enum: [
		"pending",
		"completed",
		"failed"
	] }).notNull().default("pending"),
	collectedAt: text("collected_at"),
	answerMarkdown: text("answer_markdown"),
	error: text("error")
}, (t) => [uniqueIndex$1("ai_observations_run_prompt_engine_idx").on(t.runId, t.promptId, t.engine), index$1("ai_observations_prompt_idx").on(t.promptId)]);
var aiSources$1 = sqliteTable("ai_sources", {
	id: text("id").primaryKey(),
	observationId: text("observation_id").notNull().references(() => aiObservations$1.id, { onDelete: "cascade" }),
	url: text("url").notNull(),
	domain: text("domain").notNull(),
	title: text("title"),
	position: integer("position").notNull()
}, (t) => [index$1("ai_sources_observation_idx").on(t.observationId)]);
var aiMatches$1 = sqliteTable("ai_matches", {
	id: text("id").primaryKey(),
	observationId: text("observation_id").notNull().references(() => aiObservations$1.id, { onDelete: "cascade" }),
	name: text("name").notNull(),
	domain: text("domain").notNull(),
	own: integer("own", { mode: "boolean" }).notNull(),
	mentioned: integer("mentioned", { mode: "boolean" }).notNull(),
	cited: integer("cited", { mode: "boolean" }).notNull(),
	firstMention: integer("first_mention")
}, (t) => [uniqueIndex$1("ai_matches_observation_domain_idx").on(t.observationId, t.domain)]);
//#endregion
//#region src/shared/local-seo.ts
var LocalScanStatus = /* @__PURE__ */ function(LocalScanStatus) {
	LocalScanStatus["Queued"] = "queued";
	LocalScanStatus["Running"] = "running";
	LocalScanStatus["Completed"] = "completed";
	LocalScanStatus["Partial"] = "partial";
	LocalScanStatus["Failed"] = "failed";
	return LocalScanStatus;
}({});
var LocalPointStatus = /* @__PURE__ */ function(LocalPointStatus) {
	LocalPointStatus["Pending"] = "pending";
	LocalPointStatus["Completed"] = "completed";
	LocalPointStatus["Failed"] = "failed";
	return LocalPointStatus;
}({});
function isLocalScanActive(status) {
	return status === "queued" || status === "running";
}
/**
* Keep the same viewport at every point, wide enough for the grid spacing.
*
* Without an explicit zoom DataForSEO infers one per coordinate, which yields
* "No Search Results" for some points and makes ranks incomparable across the
* grid. A fixed zoom fails the other way: a mobile viewport at zoom 14 spans
* only ~\u00b11.5 km east-west at mid latitudes, so a business one 2-3 km grid step
* to the side falls outside the viewport and reads as "not ranked". A world
* tile is 40075\u00b7cos(lat)/2^z km wide and a portrait viewport ~1.5 tiles, so
* the largest zoom whose viewport still spans ~1.25\u00d7 the spacing is
* log2(24045\u00b7cos(lat)/spacing).
*/
function localGridZoom(spacingKm, latitude) {
	const cosine = Math.max(Math.abs(Math.cos(latitude * Math.PI / 180)), .01);
	return Math.min(18, Math.max(4, Math.floor(Math.log2(24045 * cosine / spacingKm))));
}
/** The grid as a customer reads it, e.g. "9 points across 4 km". */
function localAreaLabel(grid) {
	return `${grid.gridSize * grid.gridSize} points across ${(grid.gridSize - 1) * grid.spacingKm} km`;
}
/** Row zero is the northern edge; points are in row-major order. */
function buildLocalGrid(center, gridSize, spacingKm) {
	const middle = (gridSize - 1) / 2;
	const latitudeStep = spacingKm / 110.574;
	const longitudeStep = spacingKm / (111.32 * Math.max(Math.abs(Math.cos(center.latitude * Math.PI / 180)), .01));
	return Array.from({ length: gridSize * gridSize }, (_, index) => {
		const row = Math.floor(index / gridSize);
		const col = index % gridSize;
		return {
			row,
			col,
			latitude: Number((center.latitude + (middle - row) * latitudeStep).toFixed(7)),
			longitude: Number((center.longitude + (col - middle) * longitudeStep).toFixed(7))
		};
	});
}
//#endregion
//#region src/db/local-seo.schema.ts
var local_seo_schema_exports$1 = /* @__PURE__ */ __exportAll({
	localRankBusinesses: () => localRankBusinesses$1,
	localRankChecks: () => localRankChecks$1,
	localRankKeywords: () => localRankKeywords$1,
	localRankPoints: () => localRankPoints$1,
	localRankResults: () => localRankResults$1,
	localRankScans: () => localRankScans$1,
	localRankTrackers: () => localRankTrackers$1
});
var localRankTrackers$1 = sqliteTable("local_rank_trackers", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	title: text("title").notNull(),
	address: text("address"),
	cid: text("cid"),
	placeId: text("place_id"),
	latitude: real("latitude").notNull(),
	longitude: real("longitude").notNull(),
	gridSize: integer("grid_size").notNull(),
	spacingKm: real("spacing_km").notNull(),
	languageCode: text("language_code").notNull(),
	createdAt: text("created_at").notNull()
}, (t) => [index$1("local_rank_trackers_project_idx").on(t.projectId)]);
var localRankKeywords$1 = sqliteTable("local_rank_keywords", {
	id: text("id").primaryKey(),
	trackerId: text("tracker_id").notNull().references(() => localRankTrackers$1.id, { onDelete: "cascade" }),
	keyword: text("keyword").notNull(),
	archivedAt: text("archived_at")
}, (t) => [uniqueIndex$1("local_rank_keywords_tracker_keyword_idx").on(t.trackerId, t.keyword)]);
var localRankChecks$1 = sqliteTable("local_rank_checks", {
	id: text("id").primaryKey(),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	trackerId: text("tracker_id").notNull().references(() => localRankTrackers$1.id, { onDelete: "cascade" }),
	status: text("status", { enum: [
		LocalScanStatus.Queued,
		LocalScanStatus.Running,
		LocalScanStatus.Completed,
		LocalScanStatus.Partial,
		LocalScanStatus.Failed
	] }).notNull(),
	error: text("error"),
	createdAt: text("created_at").notNull(),
	completedAt: text("completed_at")
}, (t) => [index$1("local_rank_checks_tracker_created_idx").on(t.trackerId, t.createdAt), uniqueIndex$1("local_rank_checks_one_active_idx").on(t.trackerId).where(sql`${t.status} IN ('queued', 'running')`)]);
var localRankScans$1 = sqliteTable("local_rank_scans", {
	id: text("id").primaryKey(),
	checkId: text("check_id").notNull().references(() => localRankChecks$1.id, { onDelete: "cascade" }),
	projectId: text("project_id").notNull().references(() => projects$1.id, { onDelete: "cascade" }),
	trackerId: text("tracker_id").notNull().references(() => localRankTrackers$1.id, { onDelete: "cascade" }),
	keywordId: text("keyword_id").notNull().references(() => localRankKeywords$1.id, { onDelete: "cascade" }),
	status: text("status", { enum: [
		LocalScanStatus.Queued,
		LocalScanStatus.Running,
		LocalScanStatus.Completed,
		LocalScanStatus.Partial,
		LocalScanStatus.Failed
	] }).notNull(),
	error: text("error"),
	createdAt: text("created_at").notNull(),
	completedAt: text("completed_at")
}, (t) => [
	index$1("local_rank_scans_tracker_created_idx").on(t.trackerId, t.createdAt),
	index$1("local_rank_scans_project_idx").on(t.projectId),
	uniqueIndex$1("local_rank_scans_check_keyword_idx").on(t.checkId, t.keywordId)
]);
var localRankPoints$1 = sqliteTable("local_rank_points", {
	id: text("id").primaryKey(),
	scanId: text("scan_id").notNull().references(() => localRankScans$1.id, { onDelete: "cascade" }),
	row: integer("row").notNull(),
	col: integer("col").notNull(),
	latitude: real("latitude").notNull(),
	longitude: real("longitude").notNull(),
	status: text("status", { enum: [
		LocalPointStatus.Pending,
		LocalPointStatus.Completed,
		LocalPointStatus.Failed
	] }).notNull(),
	rank: integer("rank"),
	resultsCount: integer("results_count"),
	error: text("error"),
	collectedAt: text("collected_at")
}, (t) => [uniqueIndex$1("local_rank_points_scan_position_idx").on(t.scanId, t.row, t.col)]);
var localRankBusinesses$1 = sqliteTable("local_rank_businesses", {
	id: text("id").primaryKey(),
	scanId: text("scan_id").notNull().references(() => localRankScans$1.id, { onDelete: "cascade" }),
	identity: text("identity").notNull(),
	title: text("title").notNull(),
	cid: text("cid"),
	placeId: text("place_id"),
	address: text("address"),
	rating: real("rating"),
	reviews: integer("reviews")
}, (t) => [uniqueIndex$1("local_rank_businesses_scan_identity_idx").on(t.scanId, t.identity)]);
var localRankResults$1 = sqliteTable("local_rank_results", {
	id: text("id").primaryKey(),
	pointId: text("point_id").notNull().references(() => localRankPoints$1.id, { onDelete: "cascade" }),
	businessId: text("business_id").notNull().references(() => localRankBusinesses$1.id, { onDelete: "cascade" }),
	rank: integer("rank").notNull()
}, (t) => [uniqueIndex$1("local_rank_results_point_business_idx").on(t.pointId, t.businessId), index$1("local_rank_results_business_idx").on(t.businessId)]);
//#endregion
//#region src/db/d1/schema.ts
var schema_exports$1 = /* @__PURE__ */ __exportAll({
	account: () => account$1,
	accountDeletionRequests: () => accountDeletionRequests$1,
	accountRelations: () => accountRelations$1,
	aiMatches: () => aiMatches$1,
	aiObservations: () => aiObservations$1,
	aiPrompts: () => aiPrompts$1,
	aiRuns: () => aiRuns$1,
	aiSources: () => aiSources$1,
	aiTrackers: () => aiTrackers$1,
	apikey: () => apikey$1,
	auditIssues: () => auditIssues$1,
	auditLighthouseResults: () => auditLighthouseResults$1,
	auditPages: () => auditPages$1,
	audits: () => audits$1,
	backlinkSnapshots: () => backlinkSnapshots$1,
	billingCustomerStatus: () => billingCustomerStatus$1,
	crawlerCredentials: () => crawlerCredentials$1,
	dashboardStepDismissals: () => dashboardStepDismissals$1,
	dataRefreshClaims: () => dataRefreshClaims$1,
	ga4Connections: () => ga4Connections$1,
	gscConnections: () => gscConnections$1,
	guestAccounts: () => guestAccounts$1,
	invitation: () => invitation$1,
	invitationRelations: () => invitationRelations$1,
	keywordMetrics: () => keywordMetrics$1,
	localRankBusinesses: () => localRankBusinesses$1,
	localRankChecks: () => localRankChecks$1,
	localRankKeywords: () => localRankKeywords$1,
	localRankPoints: () => localRankPoints$1,
	localRankResults: () => localRankResults$1,
	localRankScans: () => localRankScans$1,
	localRankTrackers: () => localRankTrackers$1,
	member: () => member$1,
	memberRelations: () => memberRelations$1,
	organization: () => organization$1,
	organizationActivationState: () => organizationActivationState$1,
	organizationRelations: () => organizationRelations$1,
	projectActivationState: () => projectActivationState$1,
	projectCompetitors: () => projectCompetitors$1,
	projectContextSections: () => projectContextSections$1,
	projectKeyPages: () => projectKeyPages$1,
	projectResearchLog: () => projectResearchLog$1,
	projects: () => projects$1,
	rankCheckRuns: () => rankCheckRuns$1,
	rankSnapshots: () => rankSnapshots$1,
	rankTrackingConfigs: () => rankTrackingConfigs$1,
	rankTrackingKeywords: () => rankTrackingKeywords$1,
	reportTemplates: () => reportTemplates$1,
	reports: () => reports$1,
	samSessions: () => samSessions$1,
	savedKeywordTagAssignments: () => savedKeywordTagAssignments$1,
	savedKeywordTags: () => savedKeywordTags$1,
	savedKeywords: () => savedKeywords$1,
	session: () => session$1,
	sessionRelations: () => sessionRelations$1,
	telemetryState: () => telemetryState$1,
	user: () => user$1,
	userOnboardingAnswers: () => userOnboardingAnswers$1,
	userRelations: () => userRelations$1,
	userSignupCampaigns: () => userSignupCampaigns$1,
	verification: () => verification$1
});
//#endregion
//#region src/db/d1/client.ts
function createDatabase(binding) {
	return drizzle$1(binding, { schema: schema_exports$1 });
}
var binding;
var database;
function getDatabase() {
	if (!env.DB) throw new Error("The D1 binding DB is unavailable");
	if (!database || binding !== env.DB) {
		binding = env.DB;
		database = createDatabase(binding);
	}
	return database;
}
var d1Db = new Proxy({}, { get(_target, property) {
	return Reflect.get(getDatabase(), property);
} });
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/polyfills.js
var Crypto = globalThis.crypto;
var ids = 1;
var tasks = /* @__PURE__ */ new Set();
var v4Seg = "(?:[0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])";
var v4Str = `(${v4Seg}[.]){3}${v4Seg}`;
var IPv4Reg = new RegExp(`^${v4Str}$`);
var v6Seg = "(?:[0-9a-fA-F]{1,4})";
var IPv6Reg = new RegExp(`^((?:${v6Seg}:){7}(?:${v6Seg}|:)|(?:${v6Seg}:){6}(?:${v4Str}|:${v6Seg}|:)|(?:${v6Seg}:){5}(?::${v4Str}|(:${v6Seg}){1,2}|:)|(?:${v6Seg}:){4}(?:(:${v6Seg}){0,1}:${v4Str}|(:${v6Seg}){1,3}|:)|(?:${v6Seg}:){3}(?:(:${v6Seg}){0,2}:${v4Str}|(:${v6Seg}){1,4}|:)|(?:${v6Seg}:){2}(?:(:${v6Seg}){0,3}:${v4Str}|(:${v6Seg}){1,5}|:)|(?:${v6Seg}:){1}(?:(:${v6Seg}){0,4}:${v4Str}|(:${v6Seg}){1,6}|:)|(?::((?::${v6Seg}){0,5}:${v4Str}|(?::${v6Seg}){1,7}|:)))(%[0-9a-zA-Z-.:]{1,})?\$`);
var textEncoder = new TextEncoder();
var crypto$1 = {
	randomBytes: (l) => Crypto.getRandomValues(Buffer$1.alloc(l)),
	pbkdf2Sync: async (password, salt, iterations, keylen) => Crypto.subtle.deriveBits({
		name: "PBKDF2",
		hash: "SHA-256",
		salt,
		iterations
	}, await Crypto.subtle.importKey("raw", textEncoder.encode(password), "PBKDF2", false, ["deriveBits"]), keylen * 8, ["deriveBits"]),
	createHash: (type) => ({ update: (x) => ({ digest: (encoding) => {
		if (!(x instanceof Uint8Array)) x = textEncoder.encode(x);
		let prom;
		if (type === "sha256") prom = Crypto.subtle.digest("SHA-256", x);
		else if (type === "md5") prom = Crypto.subtle.digest("md5", x);
		else throw Error("createHash only supports sha256 or md5 in this environment, not ${type}.");
		if (encoding === "hex") return prom.then((arrayBuf) => Buffer$1.from(arrayBuf).toString("hex"));
		else if (encoding) throw Error(`createHash only supports hex encoding or unencoded in this environment, not ${encoding}`);
		else return prom;
	} }) }),
	createHmac: (type, key) => ({ update: (x) => ({ digest: async () => Buffer$1.from(await Crypto.subtle.sign("HMAC", await Crypto.subtle.importKey("raw", key, {
		name: "HMAC",
		hash: "SHA-256"
	}, false, ["sign"]), textEncoder.encode(x))) }) })
};
var performance = globalThis.performance;
var process = { env: {} };
var os = { userInfo() {
	return { username: "postgres" };
} };
var fs = { readFile() {
	throw new Error("Reading files not supported on CloudFlare");
} };
var net = {
	isIP: (x) => IPv4Reg.test(x) ? 4 : IPv6Reg.test(x) ? 6 : 0,
	Socket
};
var tls = { connect({ socket: tcp, servername }) {
	tcp.writer.releaseLock();
	tcp.reader.releaseLock();
	tcp.readyState = "upgrading";
	tcp.raw = tcp.raw.startTls({ servername });
	tcp.raw.closed.then(() => tcp.emit("close"), (e) => tcp.emit("error", e));
	tcp.writer = tcp.raw.writable.getWriter();
	tcp.reader = tcp.raw.readable.getReader();
	tcp.writer.ready.then(() => {
		tcp.read();
		tcp.readyState = "upgrade";
	});
	return tcp;
} };
function Socket() {
	const tcp = Object.assign(new EventEmitter(), {
		readyState: "open",
		raw: null,
		writer: null,
		reader: null,
		connect,
		write,
		end,
		destroy,
		read
	});
	return tcp;
	async function connect(port, host) {
		try {
			tcp.readyState = "opening";
			const { connect } = await import("cloudflare:sockets");
			tcp.raw = connect(host + ":" + port, tcp.ssl ? { secureTransport: "starttls" } : {});
			tcp.raw.closed.then(() => {
				tcp.readyState !== "upgrade" ? close() : (tcp.readyState = "open", tcp.emit("secureConnect"));
			}, (e) => tcp.emit("error", e));
			tcp.writer = tcp.raw.writable.getWriter();
			tcp.reader = tcp.raw.readable.getReader();
			tcp.ssl ? readFirst() : read();
			tcp.writer.ready.then(() => {
				tcp.readyState = "open";
				tcp.emit("connect");
			});
		} catch (err) {
			error(err);
		}
	}
	function close() {
		if (tcp.readyState === "closed") return;
		tcp.readyState = "closed";
		tcp.emit("close");
	}
	function write(data, cb) {
		tcp.writer.write(data).then(cb, error);
		return true;
	}
	function end(data) {
		return data ? tcp.write(data, () => tcp.raw.close()) : tcp.raw.close();
	}
	function destroy() {
		tcp.destroyed = true;
		tcp.end();
	}
	async function read() {
		try {
			let done, value;
			while ({done, value} = await tcp.reader.read(), !done) tcp.emit("data", Buffer$1.from(value));
		} catch (err) {
			error(err);
		}
	}
	async function readFirst() {
		const { value } = await tcp.reader.read();
		tcp.emit("data", Buffer$1.from(value));
	}
	function error(err) {
		tcp.emit("error", err);
		tcp.emit("close");
	}
}
function setImmediate(fn) {
	const id = ids++;
	tasks.add(id);
	queueMicrotask(() => {
		if (tasks.has(id)) {
			fn();
			tasks.delete(id);
		}
	});
	return id;
}
function clearImmediate(id) {
	tasks.delete(id);
}
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/src/query.js
var originCache = /* @__PURE__ */ new Map();
var originStackCache = /* @__PURE__ */ new Map();
var originError = Symbol("OriginError");
var CLOSE = {};
var Query = class extends Promise {
	constructor(strings, args, handler, canceller, options = {}) {
		let resolve, reject;
		super((a, b) => {
			resolve = a;
			reject = b;
		});
		this.tagged = Array.isArray(strings.raw);
		this.strings = strings;
		this.args = args;
		this.handler = handler;
		this.canceller = canceller;
		this.options = options;
		this.state = null;
		this.statement = null;
		this.resolve = (x) => (this.active = false, resolve(x));
		this.reject = (x) => (this.active = false, reject(x));
		this.active = false;
		this.cancelled = null;
		this.executed = false;
		this.signature = "";
		this[originError] = this.handler.debug ? /* @__PURE__ */ new Error() : this.tagged && cachedError(this.strings);
	}
	get origin() {
		return (this.handler.debug ? this[originError].stack : this.tagged && originStackCache.has(this.strings) ? originStackCache.get(this.strings) : originStackCache.set(this.strings, this[originError].stack).get(this.strings)) || "";
	}
	static get [Symbol.species]() {
		return Promise;
	}
	cancel() {
		return this.canceller && (this.canceller(this), this.canceller = null);
	}
	simple() {
		this.options.simple = true;
		this.options.prepare = false;
		return this;
	}
	async readable() {
		this.simple();
		this.streaming = true;
		return this;
	}
	async writable() {
		this.simple();
		this.streaming = true;
		return this;
	}
	cursor(rows = 1, fn) {
		this.options.simple = false;
		if (typeof rows === "function") {
			fn = rows;
			rows = 1;
		}
		this.cursorRows = rows;
		if (typeof fn === "function") return this.cursorFn = fn, this;
		let prev;
		return { [Symbol.asyncIterator]: () => ({
			next: () => {
				if (this.executed && !this.active) return { done: true };
				prev && prev();
				const promise = new Promise((resolve, reject) => {
					this.cursorFn = (value) => {
						resolve({
							value,
							done: false
						});
						return new Promise((r) => prev = r);
					};
					this.resolve = () => (this.active = false, resolve({ done: true }));
					this.reject = (x) => (this.active = false, reject(x));
				});
				this.execute();
				return promise;
			},
			return() {
				prev && prev(CLOSE);
				return { done: true };
			}
		}) };
	}
	describe() {
		this.options.simple = false;
		this.onlyDescribe = this.options.prepare = true;
		return this;
	}
	stream() {
		throw new Error(".stream has been renamed to .forEach");
	}
	forEach(fn) {
		this.forEachFn = fn;
		this.handle();
		return this;
	}
	raw() {
		this.isRaw = true;
		return this;
	}
	values() {
		this.isRaw = "values";
		return this;
	}
	async handle() {
		!this.executed && (this.executed = true) && await 1 && this.handler(this);
	}
	execute() {
		this.handle();
		return this;
	}
	then() {
		this.handle();
		return super.then.apply(this, arguments);
	}
	catch() {
		this.handle();
		return super.catch.apply(this, arguments);
	}
	finally() {
		this.handle();
		return super.finally.apply(this, arguments);
	}
};
function cachedError(xs) {
	if (originCache.has(xs)) return originCache.get(xs);
	const x = Error.stackTraceLimit;
	Error.stackTraceLimit = 4;
	originCache.set(xs, /* @__PURE__ */ new Error());
	Error.stackTraceLimit = x;
	return originCache.get(xs);
}
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/src/errors.js
var PostgresError = class extends Error {
	constructor(x) {
		super(x.message);
		this.name = this.constructor.name;
		Object.assign(this, x);
	}
};
var Errors = {
	connection,
	postgres,
	generic,
	notSupported
};
function connection(x, options, socket) {
	const { host, port } = socket || options;
	const error = Object.assign(/* @__PURE__ */ new Error("write " + x + " " + (options.path || host + ":" + port)), {
		code: x,
		errno: x,
		address: options.path || host
	}, options.path ? {} : { port });
	Error.captureStackTrace(error, connection);
	return error;
}
function postgres(x) {
	const error = new PostgresError(x);
	Error.captureStackTrace(error, postgres);
	return error;
}
function generic(code, message) {
	const error = Object.assign(/* @__PURE__ */ new Error(code + ": " + message), { code });
	Error.captureStackTrace(error, generic);
	return error;
}
/* c8 ignore next 10 */
function notSupported(x) {
	const error = Object.assign(/* @__PURE__ */ new Error(x + " (B) is not supported"), {
		code: "MESSAGE_NOT_SUPPORTED",
		name: x
	});
	Error.captureStackTrace(error, notSupported);
	return error;
}
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/src/types.js
var types = {
	string: {
		to: 25,
		from: null,
		serialize: (x) => "" + x
	},
	number: {
		to: 0,
		from: [
			21,
			23,
			26,
			700,
			701
		],
		serialize: (x) => "" + x,
		parse: (x) => +x
	},
	json: {
		to: 114,
		from: [114, 3802],
		serialize: (x) => JSON.stringify(x),
		parse: (x) => JSON.parse(x)
	},
	boolean: {
		to: 16,
		from: 16,
		serialize: (x) => x === true ? "t" : "f",
		parse: (x) => x === "t"
	},
	date: {
		to: 1184,
		from: [
			1082,
			1114,
			1184
		],
		serialize: (x) => (x instanceof Date ? x : new Date(x)).toISOString(),
		parse: (x) => new Date(x)
	},
	bytea: {
		to: 17,
		from: 17,
		serialize: (x) => "\\x" + Buffer$1.from(x).toString("hex"),
		parse: (x) => Buffer$1.from(x.slice(2), "hex")
	}
};
var NotTagged = class {
	then() {
		notTagged();
	}
	catch() {
		notTagged();
	}
	finally() {
		notTagged();
	}
};
var Identifier = class extends NotTagged {
	constructor(value) {
		super();
		this.value = escapeIdentifier(value);
	}
};
var Parameter = class extends NotTagged {
	constructor(value, type, array) {
		super();
		this.value = value;
		this.type = type;
		this.array = array;
	}
};
var Builder = class extends NotTagged {
	constructor(first, rest) {
		super();
		this.first = first;
		this.rest = rest;
	}
	build(before, parameters, types, options) {
		const keyword = builders.map(([x, fn]) => ({
			fn,
			i: before.search(x)
		})).sort((a, b) => a.i - b.i).pop();
		return keyword.i === -1 ? escapeIdentifiers(this.first, options) : keyword.fn(this.first, this.rest, parameters, types, options);
	}
};
function handleValue(x, parameters, types, options) {
	let value = x instanceof Parameter ? x.value : x;
	if (value === void 0) {
		x instanceof Parameter ? x.value = options.transform.undefined : value = x = options.transform.undefined;
		if (value === void 0) throw Errors.generic("UNDEFINED_VALUE", "Undefined values are not allowed");
	}
	return "$" + types.push(x instanceof Parameter ? (parameters.push(x.value), x.array ? x.array[x.type || inferType(x.value)] || x.type || firstIsString(x.value) : x.type) : (parameters.push(x), inferType(x)));
}
var defaultHandlers = typeHandlers(types);
function stringify(q, string, value, parameters, types, options) {
	for (let i = 1; i < q.strings.length; i++) {
		string += stringifyValue(string, value, parameters, types, options) + q.strings[i];
		value = q.args[i];
	}
	return string;
}
function stringifyValue(string, value, parameters, types, o) {
	return value instanceof Builder ? value.build(string, parameters, types, o) : value instanceof Query ? fragment(value, parameters, types, o) : value instanceof Identifier ? value.value : value && value[0] instanceof Query ? value.reduce((acc, x) => acc + " " + fragment(x, parameters, types, o), "") : handleValue(value, parameters, types, o);
}
function fragment(q, parameters, types, options) {
	q.fragment = true;
	return stringify(q, q.strings[0], q.args[0], parameters, types, options);
}
function valuesBuilder(first, parameters, types, columns, options) {
	return first.map((row) => "(" + columns.map((column) => stringifyValue("values", row[column], parameters, types, options)).join(",") + ")").join(",");
}
function values(first, rest, parameters, types, options) {
	const multi = Array.isArray(first[0]);
	const columns = rest.length ? rest.flat() : Object.keys(multi ? first[0] : first);
	return valuesBuilder(multi ? first : [first], parameters, types, columns, options);
}
function select(first, rest, parameters, types, options) {
	typeof first === "string" && (first = [first].concat(rest));
	if (Array.isArray(first)) return escapeIdentifiers(first, options);
	let value;
	return (rest.length ? rest.flat() : Object.keys(first)).map((x) => {
		value = first[x];
		return (value instanceof Query ? fragment(value, parameters, types, options) : value instanceof Identifier ? value.value : handleValue(value, parameters, types, options)) + " as " + escapeIdentifier(options.transform.column.to ? options.transform.column.to(x) : x);
	}).join(",");
}
var builders = Object.entries({
	values,
	in: (...xs) => {
		const x = values(...xs);
		return x === "()" ? "(null)" : x;
	},
	select,
	as: select,
	returning: select,
	"\\(": select,
	update(first, rest, parameters, types, options) {
		return (rest.length ? rest.flat() : Object.keys(first)).map((x) => escapeIdentifier(options.transform.column.to ? options.transform.column.to(x) : x) + "=" + stringifyValue("values", first[x], parameters, types, options));
	},
	insert(first, rest, parameters, types, options) {
		const columns = rest.length ? rest.flat() : Object.keys(Array.isArray(first) ? first[0] : first);
		return "(" + escapeIdentifiers(columns, options) + ")values" + valuesBuilder(Array.isArray(first) ? first : [first], parameters, types, columns, options);
	}
}).map(([x, fn]) => [new RegExp("((?:^|[\\s(])" + x + "(?:$|[\\s(]))(?![\\s\\S]*\\1)", "i"), fn]);
function notTagged() {
	throw Errors.generic("NOT_TAGGED_CALL", "Query not called as a tagged template literal");
}
var serializers = defaultHandlers.serializers;
var parsers = defaultHandlers.parsers;
function firstIsString(x) {
	if (Array.isArray(x)) return firstIsString(x[0]);
	return typeof x === "string" ? 1009 : 0;
}
var mergeUserTypes = function(types) {
	const user = typeHandlers(types || {});
	return {
		serializers: Object.assign({}, serializers, user.serializers),
		parsers: Object.assign({}, parsers, user.parsers)
	};
};
function typeHandlers(types) {
	return Object.keys(types).reduce((acc, k) => {
		types[k].from && [].concat(types[k].from).forEach((x) => acc.parsers[x] = types[k].parse);
		if (types[k].serialize) {
			acc.serializers[types[k].to] = types[k].serialize;
			types[k].from && [].concat(types[k].from).forEach((x) => acc.serializers[x] = types[k].serialize);
		}
		return acc;
	}, {
		parsers: {},
		serializers: {}
	});
}
function escapeIdentifiers(xs, { transform: { column } }) {
	return xs.map((x) => escapeIdentifier(column.to ? column.to(x) : x)).join(",");
}
var escapeIdentifier = function escape(str) {
	return "\"" + str.replace(/"/g, "\"\"").replace(/\./g, "\".\"") + "\"";
};
var inferType = function inferType(x) {
	return x instanceof Parameter ? x.type : x instanceof Date ? 1184 : x instanceof Uint8Array ? 17 : x === true || x === false ? 16 : typeof x === "bigint" ? 20 : Array.isArray(x) ? inferType(x[0]) : 0;
};
var escapeBackslash = /\\/g;
var escapeQuote = /"/g;
function arrayEscape(x) {
	return x.replace(escapeBackslash, "\\\\").replace(escapeQuote, "\\\"");
}
var arraySerializer = function arraySerializer(xs, serializer, options, typarray) {
	if (Array.isArray(xs) === false) return xs;
	if (!xs.length) return "{}";
	const first = xs[0];
	const delimiter = typarray === 1020 ? ";" : ",";
	if (Array.isArray(first) && !first.type) return "{" + xs.map((x) => arraySerializer(x, serializer, options, typarray)).join(delimiter) + "}";
	return "{" + xs.map((x) => {
		if (x === void 0) {
			x = options.transform.undefined;
			if (x === void 0) throw Errors.generic("UNDEFINED_VALUE", "Undefined values are not allowed");
		}
		return x === null ? "null" : "\"" + arrayEscape(serializer ? serializer(x.type ? x.value : x) : "" + x) + "\"";
	}).join(delimiter) + "}";
};
var arrayParserState = {
	i: 0,
	char: null,
	str: "",
	quoted: false,
	last: 0
};
var arrayParser = function arrayParser(x, parser, typarray) {
	arrayParserState.i = arrayParserState.last = 0;
	return arrayParserLoop(arrayParserState, x, parser, typarray);
};
function arrayParserLoop(s, x, parser, typarray) {
	const xs = [];
	const delimiter = typarray === 1020 ? ";" : ",";
	for (; s.i < x.length; s.i++) {
		s.char = x[s.i];
		if (s.quoted) {
			if (s.char === "\\") s.str += x[++s.i];
			else if (s.char === "\"") {
				xs.push(parser ? parser(s.str) : s.str);
				s.str = "";
				s.quoted = x[s.i + 1] === "\"";
				s.last = s.i + 2;
			} else s.str += s.char;
		} else if (s.char === "\"") s.quoted = true;
		else if (s.char === "{") {
			s.last = ++s.i;
			xs.push(arrayParserLoop(s, x, parser, typarray));
		} else if (s.char === "}") {
			s.quoted = false;
			s.last < s.i && xs.push(parser ? parser(x.slice(s.last, s.i)) : x.slice(s.last, s.i));
			s.last = s.i + 1;
			break;
		} else if (s.char === delimiter && s.p !== "}" && s.p !== "\"") {
			xs.push(parser ? parser(x.slice(s.last, s.i)) : x.slice(s.last, s.i));
			s.last = s.i + 1;
		}
		s.p = s.char;
	}
	s.last < s.i && xs.push(parser ? parser(x.slice(s.last, s.i + 1)) : x.slice(s.last, s.i + 1));
	return xs;
}
var toCamel = (x) => {
	let str = x[0];
	for (let i = 1; i < x.length; i++) str += x[i] === "_" ? x[++i].toUpperCase() : x[i];
	return str;
};
var toPascal = (x) => {
	let str = x[0].toUpperCase();
	for (let i = 1; i < x.length; i++) str += x[i] === "_" ? x[++i].toUpperCase() : x[i];
	return str;
};
var toKebab = (x) => x.replace(/_/g, "-");
var fromCamel = (x) => x.replace(/([A-Z])/g, "_$1").toLowerCase();
var fromPascal = (x) => (x.slice(0, 1) + x.slice(1).replace(/([A-Z])/g, "_$1")).toLowerCase();
var fromKebab = (x) => x.replace(/-/g, "_");
function createJsonTransform(fn) {
	return function jsonTransform(x, column) {
		return typeof x === "object" && x !== null && (column.type === 114 || column.type === 3802) ? Array.isArray(x) ? x.map((x) => jsonTransform(x, column)) : Object.entries(x).reduce((acc, [k, v]) => Object.assign(acc, { [fn(k)]: jsonTransform(v, column) }), {}) : x;
	};
}
toCamel.column = { from: toCamel };
toCamel.value = { from: createJsonTransform(toCamel) };
fromCamel.column = { to: fromCamel };
var camel = { ...toCamel };
camel.column.to = fromCamel;
toPascal.column = { from: toPascal };
toPascal.value = { from: createJsonTransform(toPascal) };
fromPascal.column = { to: fromPascal };
var pascal = { ...toPascal };
pascal.column.to = fromPascal;
toKebab.column = { from: toKebab };
toKebab.value = { from: createJsonTransform(toKebab) };
fromKebab.column = { to: fromKebab };
var kebab = { ...toKebab };
kebab.column.to = fromKebab;
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/src/result.js
var Result = class extends Array {
	constructor() {
		super();
		Object.defineProperties(this, {
			count: {
				value: null,
				writable: true
			},
			state: {
				value: null,
				writable: true
			},
			command: {
				value: null,
				writable: true
			},
			columns: {
				value: null,
				writable: true
			},
			statement: {
				value: null,
				writable: true
			}
		});
	}
	static get [Symbol.species]() {
		return Array;
	}
};
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/src/queue.js
var queue_default = Queue;
function Queue(initial = []) {
	let xs = initial.slice();
	let index = 0;
	return {
		get length() {
			return xs.length - index;
		},
		remove: (x) => {
			const index = xs.indexOf(x);
			return index === -1 ? null : (xs.splice(index, 1), x);
		},
		push: (x) => (xs.push(x), x),
		shift: () => {
			const out = xs[index++];
			if (index === xs.length) {
				index = 0;
				xs = [];
			} else xs[index - 1] = void 0;
			return out;
		}
	};
}
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/src/bytes.js
var size = 256;
var buffer = Buffer$1.allocUnsafe(size);
var messages = "BCcDdEFfHPpQSX".split("").reduce((acc, x) => {
	const v = x.charCodeAt(0);
	acc[x] = () => {
		buffer[0] = v;
		b.i = 5;
		return b;
	};
	return acc;
}, {});
var b = Object.assign(reset, messages, {
	N: String.fromCharCode(0),
	i: 0,
	inc(x) {
		b.i += x;
		return b;
	},
	str(x) {
		const length = Buffer$1.byteLength(x);
		fit(length);
		b.i += buffer.write(x, b.i, length, "utf8");
		return b;
	},
	i16(x) {
		fit(2);
		buffer.writeUInt16BE(x, b.i);
		b.i += 2;
		return b;
	},
	i32(x, i) {
		if (i || i === 0) {
			buffer.writeUInt32BE(x, i);
			return b;
		}
		fit(4);
		buffer.writeUInt32BE(x, b.i);
		b.i += 4;
		return b;
	},
	z(x) {
		fit(x);
		buffer.fill(0, b.i, b.i + x);
		b.i += x;
		return b;
	},
	raw(x) {
		buffer = Buffer$1.concat([buffer.subarray(0, b.i), x]);
		b.i = buffer.length;
		return b;
	},
	end(at = 1) {
		buffer.writeUInt32BE(b.i - at, at);
		const out = buffer.subarray(0, b.i);
		b.i = 0;
		buffer = Buffer$1.allocUnsafe(size);
		return out;
	}
});
function fit(x) {
	if (buffer.length - b.i < x) {
		const prev = buffer, length = prev.length;
		buffer = Buffer$1.allocUnsafe(length + (length >> 1) + x);
		prev.copy(buffer);
	}
}
function reset() {
	b.i = 0;
	return b;
}
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/src/connection.js
var connection_default = Connection;
var uid = 1;
var Sync = b().S().end();
var Flush = b().H().end();
var SSLRequest = b().i32(8).i32(80877103).end(8);
var ExecuteUnnamed = Buffer$1.concat([b().E().str(b.N).i32(0).end(), Sync]);
var DescribeUnnamed = b().D().str("S").str(b.N).end();
var noop$1 = () => {};
var retryRoutines = /* @__PURE__ */ new Set([
	"FetchPreparedStatement",
	"RevalidateCachedQuery",
	"transformAssignedExpr"
]);
var errorFields = {
	83: "severity_local",
	86: "severity",
	67: "code",
	77: "message",
	68: "detail",
	72: "hint",
	80: "position",
	112: "internal_position",
	113: "internal_query",
	87: "where",
	115: "schema_name",
	116: "table_name",
	99: "column_name",
	100: "data type_name",
	110: "constraint_name",
	70: "file",
	76: "line",
	82: "routine"
};
function Connection(options, queues = {}, { onopen = noop$1, onend = noop$1, onclose = noop$1 } = {}) {
	const { sslnegotiation, ssl, max, user, host, port, database, parsers, transform, onnotice, onnotify, onparameter, max_pipeline, keep_alive, backoff, target_session_attrs } = options;
	const sent = queue_default(), id = uid++, backend = {
		pid: null,
		secret: null
	}, idleTimer = timer(end, options.idle_timeout), lifeTimer = timer(end, options.max_lifetime), connectTimer = timer(connectTimedOut, options.connect_timeout);
	let socket = null, cancelMessage, errorResponse = null, result = new Result(), incoming = Buffer$1.alloc(0), needsTypes = options.fetch_types, backendParameters = {}, statements = {}, statementId = Math.random().toString(36).slice(2), statementCount = 1, closedTime = 0, remaining = 0, hostIndex = 0, retries = 0, length = 0, delay = 0, rows = 0, serverSignature = null, nextWriteTimer = null, terminated = false, incomings = null, results = null, initial = null, ending = null, stream = null, chunk = null, ended = null, nonce = null, query = null, final = null;
	const connection = {
		queue: queues.closed,
		idleTimer,
		connect(query) {
			initial = query;
			reconnect();
		},
		terminate,
		execute,
		cancel,
		end,
		count: 0,
		id
	};
	queues.closed && queues.closed.push(connection);
	return connection;
	async function createSocket() {
		let x;
		try {
			x = options.socket ? await Promise.resolve(options.socket(options)) : new net.Socket();
		} catch (e) {
			error(e);
			return;
		}
		x.on("error", error);
		x.on("close", closed);
		x.on("drain", drain);
		return x;
	}
	async function cancel({ pid, secret }, resolve, reject) {
		try {
			cancelMessage = b().i32(16).i32(80877102).i32(pid).i32(secret).end(16);
			await connect();
			socket.once("error", reject);
			socket.once("close", resolve);
		} catch (error) {
			reject(error);
		}
	}
	function execute(q) {
		if (terminated) return queryError(q, Errors.connection("CONNECTION_DESTROYED", options));
		if (stream) return queryError(q, Errors.generic("COPY_IN_PROGRESS", "You cannot execute queries during copy"));
		if (q.cancelled) return;
		try {
			q.state = backend;
			query ? sent.push(q) : (query = q, query.active = true);
			build(q);
			return write(toBuffer(q)) && !q.describeFirst && !q.cursorFn && sent.length < max_pipeline && (!q.options.onexecute || q.options.onexecute(connection));
		} catch (error) {
			sent.length === 0 && write(Sync);
			errored(error);
			return true;
		}
	}
	function toBuffer(q) {
		if (q.parameters.length >= 65534) throw Errors.generic("MAX_PARAMETERS_EXCEEDED", "Max number of parameters (65534) exceeded");
		return q.options.simple ? b().Q().str(q.statement.string + b.N).end() : q.describeFirst ? Buffer$1.concat([describe(q), Flush]) : q.prepare ? q.prepared ? prepared(q) : Buffer$1.concat([describe(q), prepared(q)]) : unnamed(q);
	}
	function describe(q) {
		return Buffer$1.concat([Parse(q.statement.string, q.parameters, q.statement.types, q.statement.name), Describe("S", q.statement.name)]);
	}
	function prepared(q) {
		return Buffer$1.concat([Bind(q.parameters, q.statement.types, q.statement.name, q.cursorName), q.cursorFn ? Execute("", q.cursorRows) : ExecuteUnnamed]);
	}
	function unnamed(q) {
		return Buffer$1.concat([
			Parse(q.statement.string, q.parameters, q.statement.types),
			DescribeUnnamed,
			prepared(q)
		]);
	}
	function build(q) {
		const parameters = [], types = [];
		const string = stringify(q, q.strings[0], q.args[0], parameters, types, options);
		!q.tagged && q.args.forEach((x) => handleValue(x, parameters, types, options));
		q.prepare = options.prepare && ("prepare" in q.options ? q.options.prepare : true);
		q.string = string;
		q.signature = q.prepare && types + string;
		q.onlyDescribe && delete statements[q.signature];
		q.parameters = q.parameters || parameters;
		q.prepared = q.prepare && q.signature in statements;
		q.describeFirst = q.onlyDescribe || parameters.length && !q.prepared;
		q.statement = q.prepared ? statements[q.signature] : {
			string,
			types,
			name: q.prepare ? statementId + statementCount++ : ""
		};
		typeof options.debug === "function" && options.debug(id, string, parameters, types);
	}
	function write(x, fn) {
		chunk = chunk ? Buffer$1.concat([chunk, x]) : Buffer$1.from(x);
		if (fn || chunk.length >= 1024) return nextWrite(fn);
		nextWriteTimer === null && (nextWriteTimer = setImmediate(nextWrite));
		return true;
	}
	function nextWrite(fn) {
		const x = socket.write(chunk, fn);
		nextWriteTimer !== null && clearImmediate(nextWriteTimer);
		chunk = nextWriteTimer = null;
		return x;
	}
	function connectTimedOut() {
		errored(Errors.connection("CONNECT_TIMEOUT", options, socket));
		socket.destroy();
	}
	async function secure() {
		if (sslnegotiation !== "direct") {
			write(SSLRequest);
			if (!await new Promise((r) => socket.once("data", (x) => r(x[0] === 83))) && ssl === "prefer") return connected();
		}
		const options = {
			socket,
			servername: net.isIP(socket.host) ? void 0 : socket.host
		};
		if (sslnegotiation === "direct") options.ALPNProtocols = ["postgresql"];
		if (ssl === "require" || ssl === "allow" || ssl === "prefer") options.rejectUnauthorized = false;
		else if (typeof ssl === "object") Object.assign(options, ssl);
		socket.removeAllListeners();
		socket = tls.connect(options);
		socket.on("secureConnect", connected);
		socket.on("error", error);
		socket.on("close", closed);
		socket.on("drain", drain);
	}
	/* c8 ignore next 3 */
	function drain() {
		!query && onopen(connection);
	}
	function data(x) {
		if (incomings) {
			incomings.push(x);
			remaining -= x.length;
			if (remaining > 0) return;
		}
		incoming = incomings ? Buffer$1.concat(incomings, length - remaining) : incoming.length === 0 ? x : Buffer$1.concat([incoming, x], incoming.length + x.length);
		while (incoming.length > 4) {
			length = incoming.readUInt32BE(1);
			if (length >= incoming.length) {
				remaining = length - incoming.length;
				incomings = [incoming];
				break;
			}
			try {
				handle(incoming.subarray(0, length + 1));
			} catch (e) {
				query && (query.cursorFn || query.describeFirst) && write(Sync);
				errored(e);
			}
			incoming = incoming.subarray(length + 1);
			remaining = 0;
			incomings = null;
		}
	}
	async function connect() {
		terminated = false;
		backendParameters = {};
		socket || (socket = await createSocket());
		if (!socket) return;
		connectTimer.start();
		if (options.socket) return ssl ? secure() : connected();
		socket.on("connect", ssl ? secure : connected);
		if (options.path) return socket.connect(options.path);
		socket.ssl = ssl;
		socket.connect(port[hostIndex], host[hostIndex]);
		socket.host = host[hostIndex];
		socket.port = port[hostIndex];
		hostIndex = (hostIndex + 1) % port.length;
	}
	function reconnect() {
		setTimeout(connect, closedTime ? Math.max(0, closedTime + delay - performance.now()) : 0);
	}
	function connected() {
		try {
			statements = {};
			needsTypes = options.fetch_types;
			statementId = Math.random().toString(36).slice(2);
			statementCount = 1;
			lifeTimer.start();
			socket.on("data", data);
			keep_alive && socket.setKeepAlive && socket.setKeepAlive(true, 1e3 * keep_alive);
			write(StartupMessage());
		} catch (err) {
			error(err);
		}
	}
	function error(err) {
		if (connection.queue === queues.connecting && options.host[retries + 1]) return;
		errored(err);
		while (sent.length) queryError(sent.shift(), err);
	}
	function errored(err) {
		stream && (stream.destroy(err), stream = null);
		query && queryError(query, err);
		initial && (queryError(initial, err), initial = null);
	}
	function queryError(query, err) {
		if (query.reserve) return query.reject(err);
		if (!err || typeof err !== "object") err = new Error(err);
		"query" in err || "parameters" in err || Object.defineProperties(err, {
			stack: {
				value: err.stack + query.origin.replace(/.*\n/, "\n"),
				enumerable: options.debug
			},
			query: {
				value: query.string,
				enumerable: options.debug
			},
			parameters: {
				value: query.parameters,
				enumerable: options.debug
			},
			args: {
				value: query.args,
				enumerable: options.debug
			},
			types: {
				value: query.statement && query.statement.types,
				enumerable: options.debug
			}
		});
		query.reject(err);
	}
	function end() {
		return ending || (!connection.reserved && onend(connection), !connection.reserved && !initial && !query && sent.length === 0 ? (terminate(), new Promise((r) => socket && socket.readyState !== "closed" ? socket.once("close", r) : r())) : ending = new Promise((r) => ended = r));
	}
	function terminate() {
		terminated = true;
		if (stream || query || initial || sent.length) error(Errors.connection("CONNECTION_DESTROYED", options));
		clearImmediate(nextWriteTimer);
		if (socket) {
			socket.removeListener("data", data);
			socket.removeListener("connect", connected);
			socket.readyState === "open" && socket.end(b().X().end());
		}
		ended && (ended(), ending = ended = null);
	}
	async function closed(hadError) {
		incoming = Buffer$1.alloc(0);
		remaining = 0;
		incomings = null;
		clearImmediate(nextWriteTimer);
		socket.removeListener("data", data);
		socket.removeListener("connect", connected);
		idleTimer.cancel();
		lifeTimer.cancel();
		connectTimer.cancel();
		socket.removeAllListeners();
		socket = null;
		if (initial) return reconnect();
		!hadError && (query || sent.length) && error(Errors.connection("CONNECTION_CLOSED", options, socket));
		closedTime = performance.now();
		hadError && options.shared.retries++;
		delay = (typeof backoff === "function" ? backoff(options.shared.retries) : backoff) * 1e3;
		onclose(connection, Errors.connection("CONNECTION_CLOSED", options, socket));
	}
	function handle(xs, x = xs[0]) {
		(x === 68 ? DataRow : x === 100 ? CopyData : x === 65 ? NotificationResponse : x === 83 ? ParameterStatus : x === 90 ? ReadyForQuery : x === 67 ? CommandComplete : x === 50 ? BindComplete : x === 49 ? ParseComplete : x === 116 ? ParameterDescription : x === 84 ? RowDescription : x === 82 ? Authentication : x === 110 ? NoData : x === 75 ? BackendKeyData : x === 69 ? ErrorResponse : x === 115 ? PortalSuspended : x === 51 ? CloseComplete : x === 71 ? CopyInResponse : x === 78 ? NoticeResponse : x === 72 ? CopyOutResponse : x === 99 ? CopyDone : x === 73 ? EmptyQueryResponse : x === 86 ? FunctionCallResponse : x === 118 ? NegotiateProtocolVersion : x === 87 ? CopyBothResponse : 
		/* c8 ignore next */
		UnknownMessage)(xs);
	}
	function DataRow(x) {
		let index = 7;
		let length;
		let column;
		let value;
		const row = query.isRaw ? new Array(query.statement.columns.length) : {};
		for (let i = 0; i < query.statement.columns.length; i++) {
			column = query.statement.columns[i];
			length = x.readInt32BE(index);
			index += 4;
			value = length === -1 ? null : query.isRaw === true ? x.subarray(index, index += length) : column.parser === void 0 ? x.toString("utf8", index, index += length) : column.parser.array === true ? column.parser(x.toString("utf8", index + 1, index += length)) : column.parser(x.toString("utf8", index, index += length));
			query.isRaw ? row[i] = query.isRaw === true ? value : transform.value.from ? transform.value.from(value, column) : value : row[column.name] = transform.value.from ? transform.value.from(value, column) : value;
		}
		query.forEachFn ? query.forEachFn(transform.row.from ? transform.row.from(row) : row, result) : result[rows++] = transform.row.from ? transform.row.from(row) : row;
	}
	function ParameterStatus(x) {
		const [k, v] = x.toString("utf8", 5, x.length - 1).split(b.N);
		backendParameters[k] = v;
		if (options.parameters[k] !== v) {
			options.parameters[k] = v;
			onparameter && onparameter(k, v);
		}
	}
	function ReadyForQuery(x) {
		if (query) {
			if (errorResponse) query.retried ? errored(query.retried) : query.prepared && retryRoutines.has(errorResponse.routine) ? retry(query, errorResponse) : errored(errorResponse);
			else query.resolve(results || result);
		} else if (errorResponse) errored(errorResponse);
		query = results = errorResponse = null;
		result = new Result();
		connectTimer.cancel();
		if (initial) {
			if (target_session_attrs) {
				if (!backendParameters.in_hot_standby || !backendParameters.default_transaction_read_only) return fetchState();
				else if (tryNext(target_session_attrs, backendParameters)) return terminate();
			}
			if (needsTypes) {
				initial.reserve && (initial = null);
				return fetchArrayTypes();
			}
			initial && !initial.reserve && execute(initial);
			options.shared.retries = retries = 0;
			initial = null;
			return;
		}
		while (sent.length && (query = sent.shift()) && (query.active = true, query.cancelled)) Connection(options).cancel(query.state, query.cancelled.resolve, query.cancelled.reject);
		if (query) return;
		connection.reserved ? !connection.reserved.release && x[5] === 73 ? ending ? terminate() : (connection.reserved = null, onopen(connection)) : connection.reserved() : ending ? terminate() : onopen(connection);
	}
	function CommandComplete(x) {
		rows = 0;
		for (let i = x.length - 1; i > 0; i--) {
			if (x[i] === 32 && x[i + 1] < 58 && result.count === null) result.count = +x.toString("utf8", i + 1, x.length - 1);
			if (x[i - 1] >= 65) {
				result.command = x.toString("utf8", 5, i);
				result.state = backend;
				break;
			}
		}
		final && (final(), final = null);
		if (result.command === "BEGIN" && max !== 1 && !connection.reserved) return errored(Errors.generic("UNSAFE_TRANSACTION", "Only use sql.begin, sql.reserved or max: 1"));
		if (query.options.simple) return BindComplete();
		if (query.cursorFn) {
			result.count && query.cursorFn(result);
			write(Sync);
		}
	}
	function ParseComplete() {
		query.parsing = false;
	}
	function BindComplete() {
		!result.statement && (result.statement = query.statement);
		result.columns = query.statement.columns;
	}
	function ParameterDescription(x) {
		const length = x.readUInt16BE(5);
		for (let i = 0; i < length; ++i) !query.statement.types[i] && (query.statement.types[i] = x.readUInt32BE(7 + i * 4));
		query.prepare && (statements[query.signature] = query.statement);
		query.describeFirst && !query.onlyDescribe && (write(prepared(query)), query.describeFirst = false);
	}
	function RowDescription(x) {
		if (result.command) {
			results = results || [result];
			results.push(result = new Result());
			result.count = null;
			query.statement.columns = null;
		}
		const length = x.readUInt16BE(5);
		let index = 7;
		let start;
		query.statement.columns = Array(length);
		for (let i = 0; i < length; ++i) {
			start = index;
			while (x[index++] !== 0);
			const table = x.readUInt32BE(index);
			const number = x.readUInt16BE(index + 4);
			const type = x.readUInt32BE(index + 6);
			query.statement.columns[i] = {
				name: transform.column.from ? transform.column.from(x.toString("utf8", start, index - 1)) : x.toString("utf8", start, index - 1),
				parser: parsers[type],
				table,
				number,
				type
			};
			index += 18;
		}
		result.statement = query.statement;
		if (query.onlyDescribe) return query.resolve(query.statement), write(Sync);
	}
	async function Authentication(x, type = x.readUInt32BE(5)) {
		(type === 3 ? AuthenticationCleartextPassword : type === 5 ? AuthenticationMD5Password : type === 10 ? SASL : type === 11 ? SASLContinue : type === 12 ? SASLFinal : type !== 0 ? UnknownAuth : noop$1)(x, type);
	}
	/* c8 ignore next 5 */
	async function AuthenticationCleartextPassword() {
		const payload = await Pass();
		write(b().p().str(payload).z(1).end());
	}
	async function AuthenticationMD5Password(x) {
		const payload = "md5" + await md5(Buffer$1.concat([Buffer$1.from(await md5(await Pass() + user)), x.subarray(9)]));
		write(b().p().str(payload).z(1).end());
	}
	async function SASL() {
		nonce = (await crypto$1.randomBytes(18)).toString("base64");
		b().p().str("SCRAM-SHA-256" + b.N);
		const i = b.i;
		write(b.inc(4).str("n,,n=*,r=" + nonce).i32(b.i - i - 4, i).end());
	}
	async function SASLContinue(x) {
		const res = x.toString("utf8", 9).split(",").reduce((acc, x) => (acc[x[0]] = x.slice(2), acc), {});
		const saltedPassword = await crypto$1.pbkdf2Sync(await Pass(), Buffer$1.from(res.s, "base64"), parseInt(res.i), 32, "sha256");
		const clientKey = await hmac(saltedPassword, "Client Key");
		const auth = "n=*,r=" + nonce + ",r=" + res.r + ",s=" + res.s + ",i=" + res.i + ",c=biws,r=" + res.r;
		serverSignature = (await hmac(await hmac(saltedPassword, "Server Key"), auth)).toString("base64");
		const payload = "c=biws,r=" + res.r + ",p=" + xor(clientKey, Buffer$1.from(await hmac(await sha256(clientKey), auth))).toString("base64");
		write(b().p().str(payload).end());
	}
	function SASLFinal(x) {
		if (x.toString("utf8", 9).split(b.N, 1)[0].slice(2) === serverSignature) return;
		/* c8 ignore next 5 */
		errored(Errors.generic("SASL_SIGNATURE_MISMATCH", "The server did not return the correct signature"));
		socket.destroy();
	}
	function Pass() {
		return Promise.resolve(typeof options.pass === "function" ? options.pass() : options.pass);
	}
	function NoData() {
		result.statement = query.statement;
		result.statement.columns = [];
		if (query.onlyDescribe) return query.resolve(query.statement), write(Sync);
	}
	function BackendKeyData(x) {
		backend.pid = x.readUInt32BE(5);
		backend.secret = x.readUInt32BE(9);
	}
	async function fetchArrayTypes() {
		needsTypes = false;
		(await new Query([`
      select b.oid, b.typarray
      from pg_catalog.pg_type a
      left join pg_catalog.pg_type b on b.oid = a.typelem
      where a.typcategory = 'A'
      group by b.oid, b.typarray
      order by b.oid
    `], [], execute)).forEach(({ oid, typarray }) => addArrayType(oid, typarray));
	}
	function addArrayType(oid, typarray) {
		if (!!options.parsers[typarray] && !!options.serializers[typarray]) return;
		const parser = options.parsers[oid];
		options.shared.typeArrayMap[oid] = typarray;
		options.parsers[typarray] = (xs) => arrayParser(xs, parser, typarray);
		options.parsers[typarray].array = true;
		options.serializers[typarray] = (xs) => arraySerializer(xs, options.serializers[oid], options, typarray);
	}
	function tryNext(x, xs) {
		return x === "read-write" && xs.default_transaction_read_only === "on" || x === "read-only" && xs.default_transaction_read_only === "off" || x === "primary" && xs.in_hot_standby === "on" || x === "standby" && xs.in_hot_standby === "off" || x === "prefer-standby" && xs.in_hot_standby === "off" && options.host[retries];
	}
	function fetchState() {
		const query = new Query([`
      show transaction_read_only;
      select pg_catalog.pg_is_in_recovery()
    `], [], execute, null, { simple: true });
		query.resolve = ([[a], [b]]) => {
			backendParameters.default_transaction_read_only = a.transaction_read_only;
			backendParameters.in_hot_standby = b.pg_is_in_recovery ? "on" : "off";
		};
		query.execute();
	}
	function ErrorResponse(x) {
		if (query) {
			(query.cursorFn || query.describeFirst) && write(Sync);
			errorResponse = Errors.postgres(parseError(x));
		} else errored(Errors.postgres(parseError(x)));
	}
	function retry(q, error) {
		delete statements[q.signature];
		q.retried = error;
		execute(q);
	}
	function NotificationResponse(x) {
		if (!onnotify) return;
		let index = 9;
		while (x[index++] !== 0);
		onnotify(x.toString("utf8", 9, index - 1), x.toString("utf8", index, x.length - 1));
	}
	async function PortalSuspended() {
		try {
			const x = await Promise.resolve(query.cursorFn(result));
			rows = 0;
			x === CLOSE ? write(Close(query.portal)) : (result = new Result(), write(Execute("", query.cursorRows)));
		} catch (err) {
			write(Sync);
			query.reject(err);
		}
	}
	function CloseComplete() {
		result.count && query.cursorFn(result);
		query.resolve(result);
	}
	function CopyInResponse() {
		stream = new Stream.Writable({
			autoDestroy: true,
			write(chunk, encoding, callback) {
				socket.write(b().d().raw(chunk).end(), callback);
			},
			destroy(error, callback) {
				callback(error);
				socket.write(b().f().str(error + b.N).end());
				stream = null;
			},
			final(callback) {
				socket.write(b().c().end());
				final = callback;
				stream = null;
			}
		});
		query.resolve(stream);
	}
	function CopyOutResponse() {
		stream = new Stream.Readable({ read() {
			socket.resume();
		} });
		query.resolve(stream);
	}
	/* c8 ignore next 3 */
	function CopyBothResponse() {
		stream = new Stream.Duplex({
			autoDestroy: true,
			read() {
				socket.resume();
			},
			/* c8 ignore next 11 */
			write(chunk, encoding, callback) {
				socket.write(b().d().raw(chunk).end(), callback);
			},
			destroy(error, callback) {
				callback(error);
				socket.write(b().f().str(error + b.N).end());
				stream = null;
			},
			final(callback) {
				socket.write(b().c().end());
				final = callback;
			}
		});
		query.resolve(stream);
	}
	function CopyData(x) {
		stream && (stream.push(x.subarray(5)) || socket.pause());
	}
	function CopyDone() {
		stream && stream.push(null);
		stream = null;
	}
	function NoticeResponse(x) {
		onnotice ? onnotice(parseError(x)) : console.log(parseError(x));
	}
	/* c8 ignore next 3 */
	function EmptyQueryResponse() {}
	/* c8 ignore next 3 */
	function FunctionCallResponse() {
		errored(Errors.notSupported("FunctionCallResponse"));
	}
	/* c8 ignore next 3 */
	function NegotiateProtocolVersion() {
		errored(Errors.notSupported("NegotiateProtocolVersion"));
	}
	/* c8 ignore next 3 */
	function UnknownMessage(x) {
		console.error("Postgres.js : Unknown Message:", x[0]);
	}
	/* c8 ignore next 3 */
	function UnknownAuth(x, type) {
		console.error("Postgres.js : Unknown Auth:", type);
	}
	function Bind(parameters, types, statement = "", portal = "") {
		let prev, type;
		b().B().str(portal + b.N).str(statement + b.N).i16(0).i16(parameters.length);
		parameters.forEach((x, i) => {
			if (x === null) return b.i32(4294967295);
			type = types[i];
			parameters[i] = x = type in options.serializers ? options.serializers[type](x) : "" + x;
			prev = b.i;
			b.inc(4).str(x).i32(b.i - prev - 4, prev);
		});
		b.i16(0);
		return b.end();
	}
	function Parse(str, parameters, types, name = "") {
		b().P().str(name + b.N).str(str + b.N).i16(parameters.length);
		parameters.forEach((x, i) => b.i32(types[i] || 0));
		return b.end();
	}
	function Describe(x, name = "") {
		return b().D().str(x).str(name + b.N).end();
	}
	function Execute(portal = "", rows = 0) {
		return Buffer$1.concat([b().E().str(portal + b.N).i32(rows).end(), Flush]);
	}
	function Close(portal = "") {
		return Buffer$1.concat([b().C().str("P").str(portal + b.N).end(), b().S().end()]);
	}
	function StartupMessage() {
		return cancelMessage || b().inc(4).i16(3).z(2).str(Object.entries(Object.assign({
			user,
			database,
			client_encoding: "UTF8"
		}, options.connection)).filter(([, v]) => v).map(([k, v]) => k + b.N + v).join(b.N)).z(2).end(0);
	}
}
function parseError(x) {
	const error = {};
	let start = 5;
	for (let i = 5; i < x.length - 1; i++) if (x[i] === 0) {
		error[errorFields[x[start]]] = x.toString("utf8", start + 1, i);
		start = i + 1;
	}
	return error;
}
function md5(x) {
	return crypto$1.createHash("md5").update(x).digest("hex");
}
function hmac(key, x) {
	return crypto$1.createHmac("sha256", key).update(x).digest();
}
function sha256(x) {
	return crypto$1.createHash("sha256").update(x).digest();
}
function xor(a, b) {
	const length = Math.max(a.length, b.length);
	const buffer = Buffer$1.allocUnsafe(length);
	for (let i = 0; i < length; i++) buffer[i] = a[i] ^ b[i];
	return buffer;
}
function timer(fn, seconds) {
	seconds = typeof seconds === "function" ? seconds() : seconds;
	if (!seconds) return {
		cancel: noop$1,
		start: noop$1
	};
	let timer;
	return {
		cancel() {
			timer && (clearTimeout(timer), timer = null);
		},
		start() {
			timer && clearTimeout(timer);
			timer = setTimeout(done, seconds * 1e3, arguments);
		}
	};
	function done(args) {
		fn.apply(null, args);
		timer = null;
	}
}
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/src/subscribe.js
var noop = () => {};
function Subscribe(postgres, options) {
	const subscribers = /* @__PURE__ */ new Map(), slot = "postgresjs_" + Math.random().toString(36).slice(2), state = {};
	let connection, stream, ended = false;
	const sql = subscribe.sql = postgres({
		...options,
		transform: {
			column: {},
			value: {},
			row: {}
		},
		max: 1,
		fetch_types: false,
		idle_timeout: null,
		max_lifetime: null,
		connection: {
			...options.connection,
			replication: "database"
		},
		onclose: async function() {
			if (ended) return;
			stream = null;
			state.pid = state.secret = void 0;
			connected(await init(sql, slot, options.publications));
			subscribers.forEach((event) => event.forEach(({ onsubscribe }) => onsubscribe()));
		},
		no_subscribe: true
	});
	const end = sql.end, close = sql.close;
	sql.end = async () => {
		ended = true;
		stream && await new Promise((r) => (stream.once("close", r), stream.end()));
		return end();
	};
	sql.close = async () => {
		stream && await new Promise((r) => (stream.once("close", r), stream.end()));
		return close();
	};
	return subscribe;
	async function subscribe(event, fn, onsubscribe = noop, onerror = noop) {
		event = parseEvent(event);
		if (!connection) connection = init(sql, slot, options.publications);
		const subscriber = {
			fn,
			onsubscribe
		};
		const fns = subscribers.has(event) ? subscribers.get(event).add(subscriber) : subscribers.set(event, /* @__PURE__ */ new Set([subscriber])).get(event);
		const unsubscribe = () => {
			fns.delete(subscriber);
			fns.size === 0 && subscribers.delete(event);
		};
		return connection.then((x) => {
			connected(x);
			onsubscribe();
			stream && stream.on("error", onerror);
			return {
				unsubscribe,
				state,
				sql
			};
		});
	}
	function connected(x) {
		stream = x.stream;
		state.pid = x.state.pid;
		state.secret = x.state.secret;
	}
	async function init(sql, slot, publications) {
		if (!publications) throw new Error("Missing publication names");
		const xs = await sql.unsafe(`CREATE_REPLICATION_SLOT ${slot} TEMPORARY LOGICAL pgoutput NOEXPORT_SNAPSHOT`);
		const [x] = xs;
		const stream = await sql.unsafe(`START_REPLICATION SLOT ${slot} LOGICAL ${x.consistent_point} (proto_version '1', publication_names '${publications}')`).writable();
		const state = { lsn: Buffer$1.concat(x.consistent_point.split("/").map((x) => Buffer$1.from(("00000000" + x).slice(-8), "hex"))) };
		stream.on("data", data);
		stream.on("error", error);
		stream.on("close", sql.close);
		return {
			stream,
			state: xs.state
		};
		function error(e) {
			console.error("Unexpected error during logical streaming - reconnecting", e);
		}
		function data(x) {
			if (x[0] === 119) parse(x.subarray(25), state, sql.options.parsers, handle, options.transform);
			else if (x[0] === 107 && x[17]) {
				state.lsn = x.subarray(1, 9);
				pong();
			}
		}
		function handle(a, b) {
			const path = b.relation.schema + "." + b.relation.table;
			call("*", a, b);
			call("*:" + path, a, b);
			b.relation.keys.length && call("*:" + path + "=" + b.relation.keys.map((x) => a[x.name]), a, b);
			call(b.command, a, b);
			call(b.command + ":" + path, a, b);
			b.relation.keys.length && call(b.command + ":" + path + "=" + b.relation.keys.map((x) => a[x.name]), a, b);
		}
		function pong() {
			const x = Buffer$1.alloc(34);
			x[0] = "r".charCodeAt(0);
			x.fill(state.lsn, 1);
			x.writeBigInt64BE(BigInt(Date.now() - Date.UTC(2e3, 0, 1)) * BigInt(1e3), 25);
			stream.write(x);
		}
	}
	function call(x, a, b) {
		subscribers.has(x) && subscribers.get(x).forEach(({ fn }) => fn(a, b, x));
	}
}
function Time(x) {
	return new Date(Date.UTC(2e3, 0, 1) + Number(x / BigInt(1e3)));
}
function parse(x, state, parsers, handle, transform) {
	const char = (acc, [k, v]) => (acc[k.charCodeAt(0)] = v, acc);
	Object.entries({
		R: (x) => {
			let i = 1;
			const r = state[x.readUInt32BE(i)] = {
				schema: x.toString("utf8", i += 4, i = x.indexOf(0, i)) || "pg_catalog",
				table: x.toString("utf8", i + 1, i = x.indexOf(0, i + 1)),
				columns: Array(x.readUInt16BE(i += 2)),
				keys: []
			};
			i += 2;
			let columnIndex = 0, column;
			while (i < x.length) {
				column = r.columns[columnIndex++] = {
					key: x[i++],
					name: transform.column.from ? transform.column.from(x.toString("utf8", i, i = x.indexOf(0, i))) : x.toString("utf8", i, i = x.indexOf(0, i)),
					type: x.readUInt32BE(i += 1),
					parser: parsers[x.readUInt32BE(i)],
					atttypmod: x.readUInt32BE(i += 4)
				};
				column.key && r.keys.push(column);
				i += 4;
			}
		},
		Y: () => {},
		O: () => {},
		B: (x) => {
			state.date = Time(x.readBigInt64BE(9));
			state.lsn = x.subarray(1, 9);
		},
		I: (x) => {
			let i = 1;
			const relation = state[x.readUInt32BE(i)];
			const { row } = tuples(x, relation.columns, i += 7, transform);
			handle(row, {
				command: "insert",
				relation
			});
		},
		D: (x) => {
			let i = 1;
			const relation = state[x.readUInt32BE(i)];
			i += 4;
			const key = x[i] === 75;
			handle(key || x[i] === 79 ? tuples(x, relation.columns, i += 3, transform).row : null, {
				command: "delete",
				relation,
				key
			});
		},
		U: (x) => {
			let i = 1;
			const relation = state[x.readUInt32BE(i)];
			i += 4;
			const key = x[i] === 75;
			const xs = key || x[i] === 79 ? tuples(x, relation.columns, i += 3, transform) : null;
			xs && (i = xs.i);
			const { row } = tuples(x, relation.columns, i + 3, transform);
			handle(row, {
				command: "update",
				relation,
				key,
				old: xs && xs.row
			});
		},
		T: () => {},
		C: () => {}
	}).reduce(char, {})[x[0]](x);
}
function tuples(x, columns, xi, transform) {
	let type, column, value;
	const row = transform.raw ? new Array(columns.length) : {};
	for (let i = 0; i < columns.length; i++) {
		type = x[xi++];
		column = columns[i];
		value = type === 110 ? null : type === 117 ? void 0 : column.parser === void 0 ? x.toString("utf8", xi + 4, xi += 4 + x.readUInt32BE(xi)) : column.parser.array === true ? column.parser(x.toString("utf8", xi + 5, xi += 4 + x.readUInt32BE(xi))) : column.parser(x.toString("utf8", xi + 4, xi += 4 + x.readUInt32BE(xi)));
		transform.raw ? row[i] = transform.raw === true ? value : transform.value.from ? transform.value.from(value, column) : value : row[column.name] = transform.value.from ? transform.value.from(value, column) : value;
	}
	return {
		i: xi,
		row: transform.row.from ? transform.row.from(row) : row
	};
}
function parseEvent(x) {
	const xs = x.match(/^(\*|insert|update|delete)?:?([^.]+?\.?[^=]+)?=?(.+)?/i) || [];
	if (!xs) throw new Error("Malformed subscribe pattern: " + x);
	const [, command, path, key] = xs;
	return (command || "*") + (path ? ":" + (path.indexOf(".") === -1 ? "public." + path : path) : "") + (key ? "=" + key : "");
}
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/src/large.js
function largeObject(sql, oid, mode = 393216) {
	return new Promise(async (resolve, reject) => {
		await sql.begin(async (sql) => {
			let finish;
			!oid && ([{oid}] = await sql`select lo_creat(-1) as oid`);
			const [{ fd }] = await sql`select lo_open(${oid}, ${mode}) as fd`;
			const lo = {
				writable,
				readable,
				close: () => sql`select lo_close(${fd})`.then(finish),
				tell: () => sql`select lo_tell64(${fd})`,
				read: (x) => sql`select loread(${fd}, ${x}) as data`,
				write: (x) => sql`select lowrite(${fd}, ${x})`,
				truncate: (x) => sql`select lo_truncate64(${fd}, ${x})`,
				seek: (x, whence = 0) => sql`select lo_lseek64(${fd}, ${x}, ${whence})`,
				size: () => sql`
          select
            lo_lseek64(${fd}, location, 0) as position,
            seek.size
          from (
            select
              lo_lseek64($1, 0, 2) as size,
              tell.location
            from (select lo_tell64($1) as location) tell
          ) seek
        `
			};
			resolve(lo);
			return new Promise(async (r) => finish = r);
			async function readable({ highWaterMark = 16384, start = 0, end = Infinity } = {}) {
				let max = end - start;
				start && await lo.seek(start);
				return new Stream.Readable({
					highWaterMark,
					async read(size) {
						const l = size > max ? size - max : size;
						max -= size;
						const [{ data }] = await lo.read(l);
						this.push(data);
						if (data.length < size) this.push(null);
					}
				});
			}
			async function writable({ highWaterMark = 16384, start = 0 } = {}) {
				start && await lo.seek(start);
				return new Stream.Writable({
					highWaterMark,
					write(chunk, encoding, callback) {
						lo.write(chunk).then(() => callback(), callback);
					}
				});
			}
		}).catch(reject);
	});
}
//#endregion
//#region node_modules/.pnpm/postgres@3.4.9/node_modules/postgres/cf/src/index.js
Object.assign(Postgres, {
	PostgresError,
	toPascal,
	pascal,
	toCamel,
	camel,
	toKebab,
	kebab,
	fromPascal,
	fromCamel,
	fromKebab,
	BigInt: {
		to: 20,
		from: [20],
		parse: (x) => BigInt(x),
		serialize: (x) => x.toString()
	}
});
var src_default = Postgres;
function Postgres(a, b) {
	const options = parseOptions(a, b), subscribe = options.no_subscribe || Subscribe(Postgres, { ...options });
	let ending = false;
	const queries = queue_default(), connecting = queue_default(), reserved = queue_default(), closed = queue_default(), ended = queue_default(), open = queue_default(), busy = queue_default(), full = queue_default(), queues = {
		connecting,
		reserved,
		closed,
		ended,
		open,
		busy,
		full
	};
	const connections = [...Array(options.max)].map(() => connection_default(options, queues, {
		onopen,
		onend,
		onclose
	}));
	const sql = Sql(handler);
	Object.assign(sql, {
		get parameters() {
			return options.parameters;
		},
		largeObject: largeObject.bind(null, sql),
		subscribe,
		CLOSE,
		END: CLOSE,
		PostgresError,
		options,
		reserve,
		listen,
		begin,
		close,
		end
	});
	return sql;
	function Sql(handler) {
		handler.debug = options.debug;
		Object.entries(options.types).reduce((acc, [name, type]) => {
			acc[name] = (x) => new Parameter(x, type.to);
			return acc;
		}, typed);
		Object.assign(sql, {
			types: typed,
			typed,
			unsafe,
			notify,
			array,
			json,
			file
		});
		return sql;
		function typed(value, type) {
			return new Parameter(value, type);
		}
		function sql(strings, ...args) {
			return strings && Array.isArray(strings.raw) ? new Query(strings, args, handler, cancel) : typeof strings === "string" && !args.length ? new Identifier(options.transform.column.to ? options.transform.column.to(strings) : strings) : new Builder(strings, args);
		}
		function unsafe(string, args = [], options = {}) {
			arguments.length === 2 && !Array.isArray(args) && (options = args, args = []);
			return new Query([string], args, handler, cancel, {
				prepare: false,
				...options,
				simple: "simple" in options ? options.simple : args.length === 0
			});
		}
		function file(path, args = [], options = {}) {
			arguments.length === 2 && !Array.isArray(args) && (options = args, args = []);
			return new Query([], args, (query) => {
				fs.readFile(path, "utf8", (err, string) => {
					if (err) return query.reject(err);
					query.strings = [string];
					handler(query);
				});
			}, cancel, {
				...options,
				simple: "simple" in options ? options.simple : args.length === 0
			});
		}
	}
	async function listen(name, fn, onlisten) {
		const listener = {
			fn,
			onlisten
		};
		const sql = listen.sql || (listen.sql = Postgres({
			...options,
			max: 1,
			idle_timeout: null,
			max_lifetime: null,
			fetch_types: false,
			onclose() {
				Object.entries(listen.channels).forEach(([name, { listeners }]) => {
					delete listen.channels[name];
					Promise.all(listeners.map((l) => listen(name, l.fn, l.onlisten).catch(() => {})));
				});
			},
			onnotify(c, x) {
				c in listen.channels && listen.channels[c].listeners.forEach((l) => l.fn(x));
			}
		}));
		const channels = listen.channels || (listen.channels = {});
		if (name in channels) {
			channels[name].listeners.push(listener);
			const result = await channels[name].result;
			listener.onlisten && listener.onlisten();
			return {
				state: result.state,
				unlisten
			};
		}
		channels[name] = {
			result: sql`listen ${sql.unsafe("\"" + name.replace(/"/g, "\"\"") + "\"")}`,
			listeners: [listener]
		};
		const result = await channels[name].result;
		listener.onlisten && listener.onlisten();
		return {
			state: result.state,
			unlisten
		};
		async function unlisten() {
			if (name in channels === false) return;
			channels[name].listeners = channels[name].listeners.filter((x) => x !== listener);
			if (channels[name].listeners.length) return;
			delete channels[name];
			return sql`unlisten ${sql.unsafe("\"" + name.replace(/"/g, "\"\"") + "\"")}`;
		}
	}
	async function notify(channel, payload) {
		return await sql`select pg_notify(${channel}, ${"" + payload})`;
	}
	async function reserve() {
		const queue = queue_default();
		const c = open.length ? open.shift() : await new Promise((resolve, reject) => {
			const query = {
				reserve: resolve,
				reject
			};
			queries.push(query);
			closed.length && connect(closed.shift(), query);
		});
		move(c, reserved);
		c.reserved = () => queue.length ? c.execute(queue.shift()) : move(c, reserved);
		c.reserved.release = true;
		const sql = Sql(handler);
		sql.release = () => {
			c.reserved = null;
			onopen(c);
		};
		return sql;
		function handler(q) {
			c.queue === full ? queue.push(q) : c.execute(q) || move(c, full);
		}
	}
	async function begin(options, fn) {
		!fn && (fn = options, options = "");
		const queries = queue_default();
		let savepoints = 0, connection, prepare = null;
		try {
			await sql.unsafe("begin " + options.replace(/[^a-z ]/gi, ""), [], { onexecute }).execute();
			return await Promise.race([scope(connection, fn), new Promise((_, reject) => connection.onclose = reject)]);
		} catch (error) {
			throw error;
		}
		async function scope(c, fn, name) {
			const sql = Sql(handler);
			sql.savepoint = savepoint;
			sql.prepare = (x) => prepare = x.replace(/[^a-z0-9$-_. ]/gi);
			let uncaughtError, result;
			name && await sql`savepoint ${sql(name)}`;
			try {
				result = await new Promise((resolve, reject) => {
					const x = fn(sql);
					Promise.resolve(Array.isArray(x) ? Promise.all(x) : x).then(resolve, reject);
				});
				if (uncaughtError) throw uncaughtError;
			} catch (e) {
				await (name ? sql`rollback to ${sql(name)}` : sql`rollback`);
				throw e instanceof PostgresError && e.code === "25P02" && uncaughtError || e;
			}
			if (!name) prepare ? await sql`prepare transaction '${sql.unsafe(prepare)}'` : await sql`commit`;
			return result;
			function savepoint(name, fn) {
				if (name && Array.isArray(name.raw)) return savepoint((sql) => sql.apply(sql, arguments));
				arguments.length === 1 && (fn = name, name = null);
				return scope(c, fn, "s" + savepoints++ + (name ? "_" + name : ""));
			}
			function handler(q) {
				q.catch((e) => uncaughtError || (uncaughtError = e));
				c.queue === full ? queries.push(q) : c.execute(q) || move(c, full);
			}
		}
		function onexecute(c) {
			connection = c;
			move(c, reserved);
			c.reserved = () => queries.length ? c.execute(queries.shift()) : move(c, reserved);
		}
	}
	function move(c, queue) {
		c.queue.remove(c);
		queue.push(c);
		c.queue = queue;
		queue === open ? c.idleTimer.start() : c.idleTimer.cancel();
		return c;
	}
	function json(x) {
		return new Parameter(x, 3802);
	}
	function array(x, type) {
		if (!Array.isArray(x)) return array(Array.from(arguments));
		return new Parameter(x, type || (x.length ? inferType(x) || 25 : 0), options.shared.typeArrayMap);
	}
	function handler(query) {
		if (ending) return query.reject(Errors.connection("CONNECTION_ENDED", options, options));
		if (open.length) return go(open.shift(), query);
		if (closed.length) return connect(closed.shift(), query);
		busy.length ? go(busy.shift(), query) : queries.push(query);
	}
	function go(c, query) {
		return c.execute(query) ? move(c, busy) : move(c, full);
	}
	function cancel(query) {
		return new Promise((resolve, reject) => {
			query.state ? query.active ? connection_default(options).cancel(query.state, resolve, reject) : query.cancelled = {
				resolve,
				reject
			} : (queries.remove(query), query.cancelled = true, query.reject(Errors.generic("57014", "canceling statement due to user request")), resolve());
		});
	}
	async function end({ timeout = null } = {}) {
		if (ending) return ending;
		await 1;
		let timer;
		return ending = Promise.race([new Promise((r) => timeout !== null && (timer = setTimeout(destroy, timeout * 1e3, r))), Promise.all(connections.map((c) => c.end()).concat(listen.sql ? listen.sql.end({ timeout: 0 }) : [], subscribe.sql ? subscribe.sql.end({ timeout: 0 }) : []))]).then(() => clearTimeout(timer));
	}
	async function close() {
		await Promise.all(connections.map((c) => c.end()));
	}
	async function destroy(resolve) {
		await Promise.all(connections.map((c) => c.terminate()));
		while (queries.length) queries.shift().reject(Errors.connection("CONNECTION_DESTROYED", options));
		resolve();
	}
	function connect(c, query) {
		move(c, connecting);
		c.connect(query);
		return c;
	}
	function onend(c) {
		move(c, ended);
	}
	function onopen(c) {
		if (queries.length === 0) return move(c, open);
		let max = Math.ceil(queries.length / (connecting.length + 1)), ready = true;
		while (ready && queries.length && max-- > 0) {
			const query = queries.shift();
			if (query.reserve) return query.reserve(c);
			ready = c.execute(query);
		}
		ready ? move(c, busy) : move(c, full);
	}
	function onclose(c, e) {
		move(c, closed);
		c.reserved = null;
		c.onclose && (c.onclose(e), c.onclose = null);
		options.onclose && options.onclose(c.id);
		queries.length && connect(c, queries.shift());
	}
}
function parseOptions(a, b) {
	if (a && a.shared) return a;
	const env = process.env, o = (!a || typeof a === "string" ? b : a) || {}, { url, multihost } = parseUrl(a), query = [...url.searchParams].reduce((a, [b, c]) => (a[b] = c, a), {}), host = o.hostname || o.host || multihost || url.hostname || env.PGHOST || "localhost", port = o.port || url.port || env.PGPORT || 5432, user = o.user || o.username || url.username || env.PGUSERNAME || env.PGUSER || osUsername();
	o.no_prepare && (o.prepare = false);
	query.sslmode && (query.ssl = query.sslmode, delete query.sslmode);
	"timeout" in o && (console.log("The timeout option is deprecated, use idle_timeout instead"), o.idle_timeout = o.timeout);
	query.sslrootcert === "system" && (query.ssl = "verify-full");
	const ints = [
		"idle_timeout",
		"connect_timeout",
		"max_lifetime",
		"max_pipeline",
		"backoff",
		"keep_alive"
	];
	const defaults = {
		max: globalThis.Cloudflare ? 3 : 10,
		ssl: false,
		sslnegotiation: null,
		idle_timeout: null,
		connect_timeout: 30,
		max_lifetime,
		max_pipeline: 100,
		backoff,
		keep_alive: 60,
		prepare: true,
		debug: false,
		fetch_types: true,
		publications: "alltables",
		target_session_attrs: null
	};
	return {
		host: Array.isArray(host) ? host : host.split(",").map((x) => x.split(":")[0]),
		port: Array.isArray(port) ? port : host.split(",").map((x) => parseInt(x.split(":")[1] || port)),
		path: o.path || host.indexOf("/") > -1 && host + "/.s.PGSQL." + port,
		database: o.database || o.db || (url.pathname || "").slice(1) || env.PGDATABASE || user,
		user,
		pass: o.pass || o.password || url.password || env.PGPASSWORD || "",
		...Object.entries(defaults).reduce((acc, [k, d]) => {
			const value = k in o ? o[k] : k in query ? query[k] === "disable" || query[k] === "false" ? false : query[k] : env["PG" + k.toUpperCase()] || d;
			acc[k] = typeof value === "string" && ints.includes(k) ? +value : value;
			return acc;
		}, {}),
		connection: {
			application_name: env.PGAPPNAME || "postgres.js",
			...o.connection,
			...Object.entries(query).reduce((acc, [k, v]) => (k in defaults || (acc[k] = v), acc), {})
		},
		types: o.types || {},
		target_session_attrs: tsa(o, url, env),
		onnotice: o.onnotice,
		onnotify: o.onnotify,
		onclose: o.onclose,
		onparameter: o.onparameter,
		socket: o.socket,
		transform: parseTransform(o.transform || { undefined: void 0 }),
		parameters: {},
		shared: {
			retries: 0,
			typeArrayMap: {}
		},
		...mergeUserTypes(o.types)
	};
}
function tsa(o, url, env) {
	const x = o.target_session_attrs || url.searchParams.get("target_session_attrs") || env.PGTARGETSESSIONATTRS;
	if (!x || [
		"read-write",
		"read-only",
		"primary",
		"standby",
		"prefer-standby"
	].includes(x)) return x;
	throw new Error("target_session_attrs " + x + " is not supported");
}
function backoff(retries) {
	return (.5 + Math.random() / 2) * Math.min(3 ** retries / 100, 20);
}
function max_lifetime() {
	return 60 * (30 + Math.random() * 30);
}
function parseTransform(x) {
	return {
		undefined: x.undefined,
		column: {
			from: typeof x.column === "function" ? x.column : x.column && x.column.from,
			to: x.column && x.column.to
		},
		value: {
			from: typeof x.value === "function" ? x.value : x.value && x.value.from,
			to: x.value && x.value.to
		},
		row: {
			from: typeof x.row === "function" ? x.row : x.row && x.row.from,
			to: x.row && x.row.to
		}
	};
}
function parseUrl(url) {
	if (!url || typeof url !== "string") return { url: { searchParams: /* @__PURE__ */ new Map() } };
	let host = url;
	host = host.slice(host.indexOf("://") + 3).split(/[?/]/)[0];
	host = decodeURIComponent(host.slice(host.indexOf("@") + 1));
	const urlObj = new URL(url.replace(host, host.split(",")[0]));
	return {
		url: {
			username: decodeURIComponent(urlObj.username),
			password: decodeURIComponent(urlObj.password),
			host: urlObj.host,
			hostname: urlObj.hostname,
			port: urlObj.port,
			pathname: urlObj.pathname,
			searchParams: urlObj.searchParams
		},
		multihost: host.indexOf(",") > -1 && host
	};
}
function osUsername() {
	try {
		return os.userInfo().username;
	} catch (_) {
		return process.env.USERNAME || process.env.USER || process.env.LOGNAME;
	}
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/indexes.js
var IndexBuilderOn = class {
	constructor(unique, name) {
		this.unique = unique;
		this.name = name;
	}
	static [entityKind] = "PgIndexBuilderOn";
	on(...columns) {
		return new IndexBuilder(columns.map((it) => {
			if (is(it, SQL)) return it;
			it = it;
			const clonedIndexedColumn = new IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
			it.indexConfig = JSON.parse(JSON.stringify(it.defaultConfig));
			return clonedIndexedColumn;
		}), this.unique, false, this.name);
	}
	onOnly(...columns) {
		return new IndexBuilder(columns.map((it) => {
			if (is(it, SQL)) return it;
			it = it;
			const clonedIndexedColumn = new IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
			it.indexConfig = it.defaultConfig;
			return clonedIndexedColumn;
		}), this.unique, true, this.name);
	}
	/**
	* Specify what index method to use. Choices are `btree`, `hash`, `gist`, `spgist`, `gin`, `brin`, or user-installed access methods like `bloom`. The default method is `btree.
	*
	* If you have the `pg_vector` extension installed in your database, you can use the `hnsw` and `ivfflat` options, which are predefined types.
	*
	* **You can always specify any string you want in the method, in case Drizzle doesn't have it natively in its types**
	*
	* @param method The name of the index method to be used
	* @param columns
	* @returns
	*/
	using(method, ...columns) {
		return new IndexBuilder(columns.map((it) => {
			if (is(it, SQL)) return it;
			it = it;
			const clonedIndexedColumn = new IndexedColumn(it.name, !!it.keyAsName, it.columnType, it.indexConfig);
			it.indexConfig = JSON.parse(JSON.stringify(it.defaultConfig));
			return clonedIndexedColumn;
		}), this.unique, true, this.name, method);
	}
};
var IndexBuilder = class {
	static [entityKind] = "PgIndexBuilder";
	/** @internal */
	config;
	constructor(columns, unique, only, name, method = "btree") {
		this.config = {
			name,
			columns,
			unique,
			only,
			method
		};
	}
	concurrently() {
		this.config.concurrently = true;
		return this;
	}
	with(obj) {
		this.config.with = obj;
		return this;
	}
	where(condition) {
		this.config.where = condition;
		return this;
	}
	/** @internal */
	build(table) {
		return new Index(this.config, table);
	}
};
var Index = class {
	static [entityKind] = "PgIndex";
	config;
	constructor(config, table) {
		this.config = {
			...config,
			table
		};
	}
};
function index(name) {
	return new IndexBuilderOn(false, name);
}
function uniqueIndex(name) {
	return new IndexBuilderOn(true, name);
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/view-base.js
var PgViewBase = class extends View {
	static [entityKind] = "PgViewBase";
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/dialect.js
var PgDialect = class {
	static [entityKind] = "PgDialect";
	/** @internal */
	casing;
	constructor(config) {
		this.casing = new CasingCache(config?.casing);
	}
	async migrate(migrations, session, config) {
		const migrationsTable = typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
		const migrationsSchema = typeof config === "string" ? "drizzle" : config.migrationsSchema ?? "drizzle";
		const migrationTableCreate = sql`
			CREATE TABLE IF NOT EXISTS ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at bigint
			)
		`;
		await session.execute(sql`CREATE SCHEMA IF NOT EXISTS ${sql.identifier(migrationsSchema)}`);
		await session.execute(migrationTableCreate);
		const lastDbMigration = (await session.all(sql`select id, hash, created_at from ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} order by created_at desc limit 1`))[0];
		await session.transaction(async (tx) => {
			for await (const migration of migrations) if (!lastDbMigration || Number(lastDbMigration.created_at) < migration.folderMillis) {
				for (const stmt of migration.sql) await tx.execute(sql.raw(stmt));
				await tx.execute(sql`insert into ${sql.identifier(migrationsSchema)}.${sql.identifier(migrationsTable)} ("hash", "created_at") values(${migration.hash}, ${migration.folderMillis})`);
			}
		});
	}
	escapeName(name) {
		return `"${name.replace(/"/g, "\"\"")}"`;
	}
	escapeParam(num) {
		return `$${num + 1}`;
	}
	escapeString(str) {
		return `'${str.replace(/'/g, "''")}'`;
	}
	buildWithCTE(queries) {
		if (!queries?.length) return void 0;
		const withSqlChunks = [sql`with `];
		for (const [i, w] of queries.entries()) {
			withSqlChunks.push(sql`${sql.identifier(w._.alias)} as (${w._.sql})`);
			if (i < queries.length - 1) withSqlChunks.push(sql`, `);
		}
		withSqlChunks.push(sql` `);
		return sql.join(withSqlChunks);
	}
	buildDeleteQuery({ table, where, returning, withList }) {
		const withSql = this.buildWithCTE(withList);
		const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		const whereSql = where ? sql` where ${where}` : void 0;
		return sql`${withSql}delete from ${table}${whereSql}${returningSql}`;
	}
	buildUpdateSet(table, set) {
		const tableColumns = table[Table.Symbol.Columns];
		const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== void 0 || tableColumns[colName]?.onUpdateFn !== void 0);
		const setSize = columnNames.length;
		return sql.join(columnNames.flatMap((colName, i) => {
			const col = tableColumns[colName];
			const onUpdateFnResult = col.onUpdateFn?.();
			const value = set[colName] ?? (is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col));
			const res = sql`${sql.identifier(this.casing.getColumnCasing(col))} = ${value}`;
			if (i < setSize - 1) return [res, sql.raw(", ")];
			return [res];
		}));
	}
	buildUpdateQuery({ table, set, where, returning, withList, from, joins }) {
		const withSql = this.buildWithCTE(withList);
		const tableName = table[PgTable.Symbol.Name];
		const tableSchema = table[PgTable.Symbol.Schema];
		const origTableName = table[PgTable.Symbol.OriginalName];
		const alias = tableName === origTableName ? void 0 : tableName;
		const tableSql = sql`${tableSchema ? sql`${sql.identifier(tableSchema)}.` : void 0}${sql.identifier(origTableName)}${alias && sql` ${sql.identifier(alias)}`}`;
		const setSql = this.buildUpdateSet(table, set);
		const fromSql = from && sql.join([sql.raw(" from "), this.buildFromTable(from)]);
		const joinsSql = this.buildJoins(joins);
		const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: !from })}` : void 0;
		const whereSql = where ? sql` where ${where}` : void 0;
		return sql`${withSql}update ${tableSql} set ${setSql}${fromSql}${joinsSql}${whereSql}${returningSql}`;
	}
	/**
	* Builds selection SQL with provided fields/expressions
	*
	* Examples:
	*
	* `select <selection> from`
	*
	* `insert ... returning <selection>`
	*
	* If `isSingleTable` is true, then columns won't be prefixed with table name
	*/
	buildSelection(fields, { isSingleTable = false } = {}) {
		const columnsLen = fields.length;
		const chunks = fields.flatMap(({ field }, i) => {
			const chunk = [];
			if (is(field, SQL.Aliased) && field.isSelectionField) chunk.push(sql.identifier(field.fieldAlias));
			else if (is(field, SQL.Aliased) || is(field, SQL)) {
				const query = is(field, SQL.Aliased) ? field.sql : field;
				if (isSingleTable) chunk.push(new SQL(query.queryChunks.map((c) => {
					if (is(c, PgColumn)) return sql.identifier(this.casing.getColumnCasing(c));
					return c;
				})));
				else chunk.push(query);
				if (is(field, SQL.Aliased)) chunk.push(sql` as ${sql.identifier(field.fieldAlias)}`);
			} else if (is(field, Column)) {
				if (isSingleTable) chunk.push(sql.identifier(this.casing.getColumnCasing(field)));
				else chunk.push(field);
			} else if (is(field, Subquery)) {
				const entries = Object.entries(field._.selectedFields);
				if (entries.length === 1) {
					const entry = entries[0][1];
					const fieldDecoder = is(entry, SQL) ? entry.decoder : is(entry, Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
					if (fieldDecoder) field._.sql.decoder = fieldDecoder;
				}
				chunk.push(field);
			}
			if (i < columnsLen - 1) chunk.push(sql`, `);
			return chunk;
		});
		return sql.join(chunks);
	}
	buildJoins(joins) {
		if (!joins || joins.length === 0) return;
		const joinsArray = [];
		for (const [index, joinMeta] of joins.entries()) {
			if (index === 0) joinsArray.push(sql` `);
			const table = joinMeta.table;
			const lateralSql = joinMeta.lateral ? sql` lateral` : void 0;
			const onSql = joinMeta.on ? sql` on ${joinMeta.on}` : void 0;
			if (is(table, PgTable)) {
				const tableName = table[PgTable.Symbol.Name];
				const tableSchema = table[PgTable.Symbol.Schema];
				const origTableName = table[PgTable.Symbol.OriginalName];
				const alias = tableName === origTableName ? void 0 : joinMeta.alias;
				joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${tableSchema ? sql`${sql.identifier(tableSchema)}.` : void 0}${sql.identifier(origTableName)}${alias && sql` ${sql.identifier(alias)}`}${onSql}`);
			} else if (is(table, View)) {
				const viewName = table[ViewBaseConfig].name;
				const viewSchema = table[ViewBaseConfig].schema;
				const origViewName = table[ViewBaseConfig].originalName;
				const alias = viewName === origViewName ? void 0 : joinMeta.alias;
				joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${viewSchema ? sql`${sql.identifier(viewSchema)}.` : void 0}${sql.identifier(origViewName)}${alias && sql` ${sql.identifier(alias)}`}${onSql}`);
			} else joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join${lateralSql} ${table}${onSql}`);
			if (index < joins.length - 1) joinsArray.push(sql` `);
		}
		return sql.join(joinsArray);
	}
	buildFromTable(table) {
		if (is(table, Table) && table[Table.Symbol.IsAlias]) {
			let fullName = sql`${sql.identifier(table[Table.Symbol.OriginalName])}`;
			if (table[Table.Symbol.Schema]) fullName = sql`${sql.identifier(table[Table.Symbol.Schema])}.${fullName}`;
			return sql`${fullName} ${sql.identifier(table[Table.Symbol.Name])}`;
		}
		return table;
	}
	buildSelectQuery({ withList, fields, fieldsFlat, where, having, table, joins, orderBy, groupBy, limit, offset, lockingClause, distinct, setOperators }) {
		const fieldsList = fieldsFlat ?? orderSelectedFields(fields);
		for (const f of fieldsList) if (is(f.field, Column) && getTableName(f.field.table) !== (is(table, Subquery) ? table._.alias : is(table, PgViewBase) ? table[ViewBaseConfig].name : is(table, SQL) ? void 0 : getTableName(table)) && !((table2) => joins?.some(({ alias }) => alias === (table2[Table.Symbol.IsAlias] ? getTableName(table2) : table2[Table.Symbol.BaseName])))(f.field.table)) {
			const tableName = getTableName(f.field.table);
			throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
		}
		const isSingleTable = !joins || joins.length === 0;
		const withSql = this.buildWithCTE(withList);
		let distinctSql;
		if (distinct) distinctSql = distinct === true ? sql` distinct` : sql` distinct on (${sql.join(distinct.on, sql`, `)})`;
		const selection = this.buildSelection(fieldsList, { isSingleTable });
		const tableSql = this.buildFromTable(table);
		const joinsSql = this.buildJoins(joins);
		const whereSql = where ? sql` where ${where}` : void 0;
		const havingSql = having ? sql` having ${having}` : void 0;
		let orderBySql;
		if (orderBy && orderBy.length > 0) orderBySql = sql` order by ${sql.join(orderBy, sql`, `)}`;
		let groupBySql;
		if (groupBy && groupBy.length > 0) groupBySql = sql` group by ${sql.join(groupBy, sql`, `)}`;
		const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
		const offsetSql = offset ? sql` offset ${offset}` : void 0;
		const lockingClauseSql = sql.empty();
		if (lockingClause) {
			const clauseSql = sql` for ${sql.raw(lockingClause.strength)}`;
			if (lockingClause.config.of) clauseSql.append(sql` of ${sql.join(Array.isArray(lockingClause.config.of) ? lockingClause.config.of : [lockingClause.config.of], sql`, `)}`);
			if (lockingClause.config.noWait) clauseSql.append(sql` nowait`);
			else if (lockingClause.config.skipLocked) clauseSql.append(sql` skip locked`);
			lockingClauseSql.append(clauseSql);
		}
		const finalQuery = sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}${lockingClauseSql}`;
		if (setOperators.length > 0) return this.buildSetOperations(finalQuery, setOperators);
		return finalQuery;
	}
	buildSetOperations(leftSelect, setOperators) {
		const [setOperator, ...rest] = setOperators;
		if (!setOperator) throw new Error("Cannot pass undefined values to any set operator");
		if (rest.length === 0) return this.buildSetOperationQuery({
			leftSelect,
			setOperator
		});
		return this.buildSetOperations(this.buildSetOperationQuery({
			leftSelect,
			setOperator
		}), rest);
	}
	buildSetOperationQuery({ leftSelect, setOperator: { type, isAll, rightSelect, limit, orderBy, offset } }) {
		const leftChunk = sql`(${leftSelect.getSQL()}) `;
		const rightChunk = sql`(${rightSelect.getSQL()})`;
		let orderBySql;
		if (orderBy && orderBy.length > 0) {
			const orderByValues = [];
			for (const singleOrderBy of orderBy) if (is(singleOrderBy, PgColumn)) orderByValues.push(sql.identifier(singleOrderBy.name));
			else if (is(singleOrderBy, SQL)) {
				for (let i = 0; i < singleOrderBy.queryChunks.length; i++) {
					const chunk = singleOrderBy.queryChunks[i];
					if (is(chunk, PgColumn)) singleOrderBy.queryChunks[i] = sql.identifier(chunk.name);
				}
				orderByValues.push(sql`${singleOrderBy}`);
			} else orderByValues.push(sql`${singleOrderBy}`);
			orderBySql = sql` order by ${sql.join(orderByValues, sql`, `)} `;
		}
		const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : void 0;
		const operatorChunk = sql.raw(`${type} ${isAll ? "all " : ""}`);
		const offsetSql = offset ? sql` offset ${offset}` : void 0;
		return sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
	}
	buildInsertQuery({ table, values: valuesOrSelect, onConflict, returning, withList, select, overridingSystemValue_ }) {
		const valuesSqlList = [];
		const columns = table[Table.Symbol.Columns];
		const colEntries = Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
		const insertOrder = colEntries.map(([, column]) => sql.identifier(this.casing.getColumnCasing(column)));
		if (select) {
			const select2 = valuesOrSelect;
			if (is(select2, SQL)) valuesSqlList.push(select2);
			else valuesSqlList.push(select2.getSQL());
		} else {
			const values = valuesOrSelect;
			valuesSqlList.push(sql.raw("values "));
			for (const [valueIndex, value] of values.entries()) {
				const valueList = [];
				for (const [fieldName, col] of colEntries) {
					const colValue = value[fieldName];
					if (colValue === void 0 || is(colValue, Param) && colValue.value === void 0) {
						if (col.defaultFn !== void 0) {
							const defaultFnResult = col.defaultFn();
							const defaultValue = is(defaultFnResult, SQL) ? defaultFnResult : sql.param(defaultFnResult, col);
							valueList.push(defaultValue);
						} else if (!col.default && col.onUpdateFn !== void 0) {
							const onUpdateFnResult = col.onUpdateFn();
							const newValue = is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col);
							valueList.push(newValue);
						} else valueList.push(sql`default`);
					} else valueList.push(colValue);
				}
				valuesSqlList.push(valueList);
				if (valueIndex < values.length - 1) valuesSqlList.push(sql`, `);
			}
		}
		const withSql = this.buildWithCTE(withList);
		const valuesSql = sql.join(valuesSqlList);
		const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : void 0;
		const onConflictSql = onConflict ? sql` on conflict ${onConflict}` : void 0;
		const overridingSql = overridingSystemValue_ === true ? sql`overriding system value ` : void 0;
		return sql`${withSql}insert into ${table} ${insertOrder} ${overridingSql}${valuesSql}${onConflictSql}${returningSql}`;
	}
	buildRefreshMaterializedViewQuery({ view, concurrently, withNoData }) {
		const concurrentlySql = concurrently ? sql` concurrently` : void 0;
		const withNoDataSql = withNoData ? sql` with no data` : void 0;
		return sql`refresh materialized view${concurrentlySql} ${view}${withNoDataSql}`;
	}
	prepareTyping(encoder) {
		if (is(encoder, PgJsonb) || is(encoder, PgJson)) return "json";
		else if (is(encoder, PgNumeric)) return "decimal";
		else if (is(encoder, PgTime)) return "time";
		else if (is(encoder, PgTimestamp) || is(encoder, PgTimestampString)) return "timestamp";
		else if (is(encoder, PgDate) || is(encoder, PgDateString)) return "date";
		else if (is(encoder, PgUUID)) return "uuid";
		else return "none";
	}
	sqlToQuery(sql2, invokeSource) {
		return sql2.toQuery({
			casing: this.casing,
			escapeName: this.escapeName,
			escapeParam: this.escapeParam,
			escapeString: this.escapeString,
			prepareTyping: this.prepareTyping,
			invokeSource
		});
	}
	buildRelationalQueryWithoutPK({ fullSchema, schema, tableNamesMap, table, tableConfig, queryConfig: config, tableAlias, nestedQueryRelation, joinOn }) {
		let selection = [];
		let limit, offset, orderBy = [], where;
		const joins = [];
		if (config === true) selection = Object.entries(tableConfig.columns).map(([key, value]) => ({
			dbKey: value.name,
			tsKey: key,
			field: aliasedTableColumn(value, tableAlias),
			relationTableTsKey: void 0,
			isJson: false,
			selection: []
		}));
		else {
			const aliasedColumns = Object.fromEntries(Object.entries(tableConfig.columns).map(([key, value]) => [key, aliasedTableColumn(value, tableAlias)]));
			if (config.where) {
				const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, getOperators()) : config.where;
				where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
			}
			const fieldsSelection = [];
			let selectedColumns = [];
			if (config.columns) {
				let isIncludeMode = false;
				for (const [field, value] of Object.entries(config.columns)) {
					if (value === void 0) continue;
					if (field in tableConfig.columns) {
						if (!isIncludeMode && value === true) isIncludeMode = true;
						selectedColumns.push(field);
					}
				}
				if (selectedColumns.length > 0) selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
			} else selectedColumns = Object.keys(tableConfig.columns);
			for (const field of selectedColumns) {
				const column = tableConfig.columns[field];
				fieldsSelection.push({
					tsKey: field,
					value: column
				});
			}
			let selectedRelations = [];
			if (config.with) selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig]) => ({
				tsKey,
				queryConfig,
				relation: tableConfig.relations[tsKey]
			}));
			let extras;
			if (config.extras) {
				extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql }) : config.extras;
				for (const [tsKey, value] of Object.entries(extras)) fieldsSelection.push({
					tsKey,
					value: mapColumnsInAliasedSQLToAlias(value, tableAlias)
				});
			}
			for (const { tsKey, value } of fieldsSelection) selection.push({
				dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
				tsKey,
				field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
				relationTableTsKey: void 0,
				isJson: false,
				selection: []
			});
			let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, getOrderByOperators()) : config.orderBy ?? [];
			if (!Array.isArray(orderByOrig)) orderByOrig = [orderByOrig];
			orderBy = orderByOrig.map((orderByValue) => {
				if (is(orderByValue, Column)) return aliasedTableColumn(orderByValue, tableAlias);
				return mapColumnsInSQLToAlias(orderByValue, tableAlias);
			});
			limit = config.limit;
			offset = config.offset;
			for (const { tsKey: selectedRelationTsKey, queryConfig: selectedRelationConfigValue, relation } of selectedRelations) {
				const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
				const relationTableTsName = tableNamesMap[getTableUniqueName(relation.referencedTable)];
				const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
				const joinOn2 = and(...normalizedRelation.fields.map((field2, i) => eq(aliasedTableColumn(normalizedRelation.references[i], relationTableAlias), aliasedTableColumn(field2, tableAlias))));
				const builtRelation = this.buildRelationalQueryWithoutPK({
					fullSchema,
					schema,
					tableNamesMap,
					table: fullSchema[relationTableTsName],
					tableConfig: schema[relationTableTsName],
					queryConfig: is(relation, One) ? selectedRelationConfigValue === true ? { limit: 1 } : {
						...selectedRelationConfigValue,
						limit: 1
					} : selectedRelationConfigValue,
					tableAlias: relationTableAlias,
					joinOn: joinOn2,
					nestedQueryRelation: relation
				});
				const field = sql`${sql.identifier(relationTableAlias)}.${sql.identifier("data")}`.as(selectedRelationTsKey);
				joins.push({
					on: sql`true`,
					table: new Subquery(builtRelation.sql, {}, relationTableAlias),
					alias: relationTableAlias,
					joinType: "left",
					lateral: true
				});
				selection.push({
					dbKey: selectedRelationTsKey,
					tsKey: selectedRelationTsKey,
					field,
					relationTableTsKey: relationTableTsName,
					isJson: true,
					selection: builtRelation.selection
				});
			}
		}
		if (selection.length === 0) throw new DrizzleError({ message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}")` });
		let result;
		where = and(joinOn, where);
		if (nestedQueryRelation) {
			let field = sql`json_build_array(${sql.join(selection.map(({ field: field2, tsKey, isJson }) => isJson ? sql`${sql.identifier(`${tableAlias}_${tsKey}`)}.${sql.identifier("data")}` : is(field2, SQL.Aliased) ? field2.sql : field2), sql`, `)})`;
			if (is(nestedQueryRelation, Many)) field = sql`coalesce(json_agg(${field}${orderBy.length > 0 ? sql` order by ${sql.join(orderBy, sql`, `)}` : void 0}), '[]'::json)`;
			const nestedSelection = [{
				dbKey: "data",
				tsKey: "data",
				field: field.as("data"),
				isJson: true,
				relationTableTsKey: tableConfig.tsName,
				selection
			}];
			if (limit !== void 0 || offset !== void 0 || orderBy.length > 0) {
				result = this.buildSelectQuery({
					table: aliasedTable(table, tableAlias),
					fields: {},
					fieldsFlat: [{
						path: [],
						field: sql.raw("*")
					}],
					where,
					limit,
					offset,
					orderBy,
					setOperators: []
				});
				where = void 0;
				limit = void 0;
				offset = void 0;
				orderBy = [];
			} else result = aliasedTable(table, tableAlias);
			result = this.buildSelectQuery({
				table: is(result, PgTable) ? result : new Subquery(result, {}, tableAlias),
				fields: {},
				fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
					path: [],
					field: is(field2, Column) ? aliasedTableColumn(field2, tableAlias) : field2
				})),
				joins,
				where,
				limit,
				offset,
				orderBy,
				setOperators: []
			});
		} else result = this.buildSelectQuery({
			table: aliasedTable(table, tableAlias),
			fields: {},
			fieldsFlat: selection.map(({ field }) => ({
				path: [],
				field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
			})),
			joins,
			where,
			limit,
			offset,
			orderBy,
			setOperators: []
		});
		return {
			tableTsKey: tableConfig.tsName,
			sql: result,
			selection
		};
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/query-builders/select.js
var PgSelectBuilder = class {
	static [entityKind] = "PgSelectBuilder";
	fields;
	session;
	dialect;
	withList = [];
	distinct;
	constructor(config) {
		this.fields = config.fields;
		this.session = config.session;
		this.dialect = config.dialect;
		if (config.withList) this.withList = config.withList;
		this.distinct = config.distinct;
	}
	authToken;
	/** @internal */
	setToken(token) {
		this.authToken = token;
		return this;
	}
	/**
	* Specify the table, subquery, or other target that you're
	* building a select query against.
	*
	* {@link https://www.postgresql.org/docs/current/sql-select.html#SQL-FROM | Postgres from documentation}
	*/
	from(source) {
		const isPartialSelect = !!this.fields;
		const src = source;
		let fields;
		if (this.fields) fields = this.fields;
		else if (is(src, Subquery)) fields = Object.fromEntries(Object.keys(src._.selectedFields).map((key) => [key, src[key]]));
		else if (is(src, PgViewBase)) fields = src[ViewBaseConfig].selectedFields;
		else if (is(src, SQL)) fields = {};
		else fields = getTableColumns(src);
		return new PgSelectBase({
			table: src,
			fields,
			isPartialSelect,
			session: this.session,
			dialect: this.dialect,
			withList: this.withList,
			distinct: this.distinct
		}).setToken(this.authToken);
	}
};
var PgSelectQueryBuilderBase = class extends TypedQueryBuilder {
	static [entityKind] = "PgSelectQueryBuilder";
	_;
	config;
	joinsNotNullableMap;
	tableName;
	isPartialSelect;
	session;
	dialect;
	cacheConfig = void 0;
	usedTables = /* @__PURE__ */ new Set();
	constructor({ table, fields, isPartialSelect, session, dialect, withList, distinct }) {
		super();
		this.config = {
			withList,
			table,
			fields: { ...fields },
			distinct,
			setOperators: []
		};
		this.isPartialSelect = isPartialSelect;
		this.session = session;
		this.dialect = dialect;
		this._ = {
			selectedFields: fields,
			config: this.config
		};
		this.tableName = getTableLikeName(table);
		this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
		for (const item of extractUsedTable(table)) this.usedTables.add(item);
	}
	/** @internal */
	getUsedTables() {
		return [...this.usedTables];
	}
	createJoin(joinType, lateral) {
		return (table, on) => {
			const baseTableName = this.tableName;
			const tableName = getTableLikeName(table);
			for (const item of extractUsedTable(table)) this.usedTables.add(item);
			if (typeof tableName === "string" && this.config.joins?.some((join) => join.alias === tableName)) throw new Error(`Alias "${tableName}" is already used in this query`);
			if (!this.isPartialSelect) {
				if (Object.keys(this.joinsNotNullableMap).length === 1 && typeof baseTableName === "string") this.config.fields = { [baseTableName]: this.config.fields };
				if (typeof tableName === "string" && !is(table, SQL)) {
					const selection = is(table, Subquery) ? table._.selectedFields : is(table, View) ? table[ViewBaseConfig].selectedFields : table[Table.Symbol.Columns];
					this.config.fields[tableName] = selection;
				}
			}
			if (typeof on === "function") on = on(new Proxy(this.config.fields, new SelectionProxyHandler({
				sqlAliasedBehavior: "sql",
				sqlBehavior: "sql"
			})));
			if (!this.config.joins) this.config.joins = [];
			this.config.joins.push({
				on,
				table,
				joinType,
				alias: tableName,
				lateral
			});
			if (typeof tableName === "string") switch (joinType) {
				case "left":
					this.joinsNotNullableMap[tableName] = false;
					break;
				case "right":
					this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
					this.joinsNotNullableMap[tableName] = true;
					break;
				case "cross":
				case "inner":
					this.joinsNotNullableMap[tableName] = true;
					break;
				case "full":
					this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
					this.joinsNotNullableMap[tableName] = false;
			}
			return this;
		};
	}
	/**
	* Executes a `left join` operation by adding another table to the current query.
	*
	* Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#left-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User; pets: Pet | null; }[] = await db.select()
	*   .from(users)
	*   .leftJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number; petId: number | null; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .leftJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	leftJoin = this.createJoin("left", false);
	/**
	* Executes a `left join lateral` operation by adding subquery to the current query.
	*
	* A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
	*
	* Calling this method associates each row of the table with the corresponding row from the joined table, if a match is found. If no matching row exists, it sets all columns of the joined table to null.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#left-join-lateral}
	*
	* @param table the subquery to join.
	* @param on the `on` clause.
	*/
	leftJoinLateral = this.createJoin("left", true);
	/**
	* Executes a `right join` operation by adding another table to the current query.
	*
	* Calling this method associates each row of the joined table with the corresponding row from the main table, if a match is found. If no matching row exists, it sets all columns of the main table to null.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#right-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User | null; pets: Pet; }[] = await db.select()
	*   .from(users)
	*   .rightJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number | null; petId: number; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .rightJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	rightJoin = this.createJoin("right", false);
	/**
	* Executes an `inner join` operation, creating a new table by combining rows from two tables that have matching values.
	*
	* Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#inner-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
	*   .from(users)
	*   .innerJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .innerJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	innerJoin = this.createJoin("inner", false);
	/**
	* Executes an `inner join lateral` operation, creating a new table by combining rows from two queries that have matching values.
	*
	* A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
	*
	* Calling this method retrieves rows that have corresponding entries in both joined tables. Rows without matching entries in either table are excluded, resulting in a table that includes only matching pairs.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#inner-join-lateral}
	*
	* @param table the subquery to join.
	* @param on the `on` clause.
	*/
	innerJoinLateral = this.createJoin("inner", true);
	/**
	* Executes a `full join` operation by combining rows from two tables into a new table.
	*
	* Calling this method retrieves all rows from both main and joined tables, merging rows with matching values and filling in `null` for non-matching columns.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#full-join}
	*
	* @param table the table to join.
	* @param on the `on` clause.
	*
	* @example
	*
	* ```ts
	* // Select all users and their pets
	* const usersWithPets: { user: User | null; pets: Pet | null; }[] = await db.select()
	*   .from(users)
	*   .fullJoin(pets, eq(users.id, pets.ownerId))
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number | null; petId: number | null; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .fullJoin(pets, eq(users.id, pets.ownerId))
	* ```
	*/
	fullJoin = this.createJoin("full", false);
	/**
	* Executes a `cross join` operation by combining rows from two tables into a new table.
	*
	* Calling this method retrieves all rows from both main and joined tables, merging all rows from each table.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#cross-join}
	*
	* @param table the table to join.
	*
	* @example
	*
	* ```ts
	* // Select all users, each user with every pet
	* const usersWithPets: { user: User; pets: Pet; }[] = await db.select()
	*   .from(users)
	*   .crossJoin(pets)
	*
	* // Select userId and petId
	* const usersIdsAndPetIds: { userId: number; petId: number; }[] = await db.select({
	*   userId: users.id,
	*   petId: pets.id,
	* })
	*   .from(users)
	*   .crossJoin(pets)
	* ```
	*/
	crossJoin = this.createJoin("cross", false);
	/**
	* Executes a `cross join lateral` operation by combining rows from two queries into a new table.
	*
	* A `lateral` join allows the right-hand expression to refer to columns from the left-hand side.
	*
	* Calling this method retrieves all rows from both main and joined queries, merging all rows from each query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/joins#cross-join-lateral}
	*
	* @param table the query to join.
	*/
	crossJoinLateral = this.createJoin("cross", true);
	createSetOperator(type, isAll) {
		return (rightSelection) => {
			const rightSelect = typeof rightSelection === "function" ? rightSelection(getPgSetOperators()) : rightSelection;
			if (!haveSameKeys(this.getSelectedFields(), rightSelect.getSelectedFields())) throw new Error("Set operator error (union / intersect / except): selected fields are not the same or are in a different order");
			this.config.setOperators.push({
				type,
				isAll,
				rightSelect
			});
			return this;
		};
	}
	/**
	* Adds `union` set operator to the query.
	*
	* Calling this method will combine the result sets of the `select` statements and remove any duplicate rows that appear across them.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#union}
	*
	* @example
	*
	* ```ts
	* // Select all unique names from customers and users tables
	* await db.select({ name: users.name })
	*   .from(users)
	*   .union(
	*     db.select({ name: customers.name }).from(customers)
	*   );
	* // or
	* import { union } from 'drizzle-orm/pg-core'
	*
	* await union(
	*   db.select({ name: users.name }).from(users),
	*   db.select({ name: customers.name }).from(customers)
	* );
	* ```
	*/
	union = this.createSetOperator("union", false);
	/**
	* Adds `union all` set operator to the query.
	*
	* Calling this method will combine the result-set of the `select` statements and keep all duplicate rows that appear across them.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#union-all}
	*
	* @example
	*
	* ```ts
	* // Select all transaction ids from both online and in-store sales
	* await db.select({ transaction: onlineSales.transactionId })
	*   .from(onlineSales)
	*   .unionAll(
	*     db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
	*   );
	* // or
	* import { unionAll } from 'drizzle-orm/pg-core'
	*
	* await unionAll(
	*   db.select({ transaction: onlineSales.transactionId }).from(onlineSales),
	*   db.select({ transaction: inStoreSales.transactionId }).from(inStoreSales)
	* );
	* ```
	*/
	unionAll = this.createSetOperator("union", true);
	/**
	* Adds `intersect` set operator to the query.
	*
	* Calling this method will retain only the rows that are present in both result sets and eliminate duplicates.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect}
	*
	* @example
	*
	* ```ts
	* // Select course names that are offered in both departments A and B
	* await db.select({ courseName: depA.courseName })
	*   .from(depA)
	*   .intersect(
	*     db.select({ courseName: depB.courseName }).from(depB)
	*   );
	* // or
	* import { intersect } from 'drizzle-orm/pg-core'
	*
	* await intersect(
	*   db.select({ courseName: depA.courseName }).from(depA),
	*   db.select({ courseName: depB.courseName }).from(depB)
	* );
	* ```
	*/
	intersect = this.createSetOperator("intersect", false);
	/**
	* Adds `intersect all` set operator to the query.
	*
	* Calling this method will retain only the rows that are present in both result sets including all duplicates.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#intersect-all}
	*
	* @example
	*
	* ```ts
	* // Select all products and quantities that are ordered by both regular and VIP customers
	* await db.select({
	*   productId: regularCustomerOrders.productId,
	*   quantityOrdered: regularCustomerOrders.quantityOrdered
	* })
	* .from(regularCustomerOrders)
	* .intersectAll(
	*   db.select({
	*     productId: vipCustomerOrders.productId,
	*     quantityOrdered: vipCustomerOrders.quantityOrdered
	*   })
	*   .from(vipCustomerOrders)
	* );
	* // or
	* import { intersectAll } from 'drizzle-orm/pg-core'
	*
	* await intersectAll(
	*   db.select({
	*     productId: regularCustomerOrders.productId,
	*     quantityOrdered: regularCustomerOrders.quantityOrdered
	*   })
	*   .from(regularCustomerOrders),
	*   db.select({
	*     productId: vipCustomerOrders.productId,
	*     quantityOrdered: vipCustomerOrders.quantityOrdered
	*   })
	*   .from(vipCustomerOrders)
	* );
	* ```
	*/
	intersectAll = this.createSetOperator("intersect", true);
	/**
	* Adds `except` set operator to the query.
	*
	* Calling this method will retrieve all unique rows from the left query, except for the rows that are present in the result set of the right query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#except}
	*
	* @example
	*
	* ```ts
	* // Select all courses offered in department A but not in department B
	* await db.select({ courseName: depA.courseName })
	*   .from(depA)
	*   .except(
	*     db.select({ courseName: depB.courseName }).from(depB)
	*   );
	* // or
	* import { except } from 'drizzle-orm/pg-core'
	*
	* await except(
	*   db.select({ courseName: depA.courseName }).from(depA),
	*   db.select({ courseName: depB.courseName }).from(depB)
	* );
	* ```
	*/
	except = this.createSetOperator("except", false);
	/**
	* Adds `except all` set operator to the query.
	*
	* Calling this method will retrieve all rows from the left query, except for the rows that are present in the result set of the right query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/set-operations#except-all}
	*
	* @example
	*
	* ```ts
	* // Select all products that are ordered by regular customers but not by VIP customers
	* await db.select({
	*   productId: regularCustomerOrders.productId,
	*   quantityOrdered: regularCustomerOrders.quantityOrdered,
	* })
	* .from(regularCustomerOrders)
	* .exceptAll(
	*   db.select({
	*     productId: vipCustomerOrders.productId,
	*     quantityOrdered: vipCustomerOrders.quantityOrdered,
	*   })
	*   .from(vipCustomerOrders)
	* );
	* // or
	* import { exceptAll } from 'drizzle-orm/pg-core'
	*
	* await exceptAll(
	*   db.select({
	*     productId: regularCustomerOrders.productId,
	*     quantityOrdered: regularCustomerOrders.quantityOrdered
	*   })
	*   .from(regularCustomerOrders),
	*   db.select({
	*     productId: vipCustomerOrders.productId,
	*     quantityOrdered: vipCustomerOrders.quantityOrdered
	*   })
	*   .from(vipCustomerOrders)
	* );
	* ```
	*/
	exceptAll = this.createSetOperator("except", true);
	/** @internal */
	addSetOperators(setOperators) {
		this.config.setOperators.push(...setOperators);
		return this;
	}
	/**
	* Adds a `where` clause to the query.
	*
	* Calling this method will select only those rows that fulfill a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#filtering}
	*
	* @param where the `where` clause.
	*
	* @example
	* You can use conditional operators and `sql function` to filter the rows to be selected.
	*
	* ```ts
	* // Select all cars with green color
	* await db.select().from(cars).where(eq(cars.color, 'green'));
	* // or
	* await db.select().from(cars).where(sql`${cars.color} = 'green'`)
	* ```
	*
	* You can logically combine conditional operators with `and()` and `or()` operators:
	*
	* ```ts
	* // Select all BMW cars with a green color
	* await db.select().from(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
	*
	* // Select all cars with the green or blue color
	* await db.select().from(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
	* ```
	*/
	where(where) {
		if (typeof where === "function") where = where(new Proxy(this.config.fields, new SelectionProxyHandler({
			sqlAliasedBehavior: "sql",
			sqlBehavior: "sql"
		})));
		this.config.where = where;
		return this;
	}
	/**
	* Adds a `having` clause to the query.
	*
	* Calling this method will select only those rows that fulfill a specified condition. It is typically used with aggregate functions to filter the aggregated data based on a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#aggregations}
	*
	* @param having the `having` clause.
	*
	* @example
	*
	* ```ts
	* // Select all brands with more than one car
	* await db.select({
	* 	brand: cars.brand,
	* 	count: sql<number>`cast(count(${cars.id}) as int)`,
	* })
	*   .from(cars)
	*   .groupBy(cars.brand)
	*   .having(({ count }) => gt(count, 1));
	* ```
	*/
	having(having) {
		if (typeof having === "function") having = having(new Proxy(this.config.fields, new SelectionProxyHandler({
			sqlAliasedBehavior: "sql",
			sqlBehavior: "sql"
		})));
		this.config.having = having;
		return this;
	}
	groupBy(...columns) {
		if (typeof columns[0] === "function") {
			const groupBy = columns[0](new Proxy(this.config.fields, new SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			this.config.groupBy = Array.isArray(groupBy) ? groupBy : [groupBy];
		} else this.config.groupBy = columns;
		return this;
	}
	orderBy(...columns) {
		if (typeof columns[0] === "function") {
			const orderBy = columns[0](new Proxy(this.config.fields, new SelectionProxyHandler({
				sqlAliasedBehavior: "alias",
				sqlBehavior: "sql"
			})));
			const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
			if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).orderBy = orderByArray;
			else this.config.orderBy = orderByArray;
		} else {
			const orderByArray = columns;
			if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).orderBy = orderByArray;
			else this.config.orderBy = orderByArray;
		}
		return this;
	}
	/**
	* Adds a `limit` clause to the query.
	*
	* Calling this method will set the maximum number of rows that will be returned by this query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
	*
	* @param limit the `limit` clause.
	*
	* @example
	*
	* ```ts
	* // Get the first 10 people from this query.
	* await db.select().from(people).limit(10);
	* ```
	*/
	limit(limit) {
		if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).limit = limit;
		else this.config.limit = limit;
		return this;
	}
	/**
	* Adds an `offset` clause to the query.
	*
	* Calling this method will skip a number of rows when returning results from this query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#limit--offset}
	*
	* @param offset the `offset` clause.
	*
	* @example
	*
	* ```ts
	* // Get the 10th-20th people from this query.
	* await db.select().from(people).offset(10).limit(10);
	* ```
	*/
	offset(offset) {
		if (this.config.setOperators.length > 0) this.config.setOperators.at(-1).offset = offset;
		else this.config.offset = offset;
		return this;
	}
	/**
	* Adds a `for` clause to the query.
	*
	* Calling this method will specify a lock strength for this query that controls how strictly it acquires exclusive access to the rows being queried.
	*
	* See docs: {@link https://www.postgresql.org/docs/current/sql-select.html#SQL-FOR-UPDATE-SHARE}
	*
	* @param strength the lock strength.
	* @param config the lock configuration.
	*/
	for(strength, config = {}) {
		this.config.lockingClause = {
			strength,
			config
		};
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildSelectQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	as(alias) {
		const usedTables = [];
		usedTables.push(...extractUsedTable(this.config.table));
		if (this.config.joins) for (const it of this.config.joins) usedTables.push(...extractUsedTable(it.table));
		return new Proxy(new Subquery(this.getSQL(), this.config.fields, alias, false, [...new Set(usedTables)]), new SelectionProxyHandler({
			alias,
			sqlAliasedBehavior: "alias",
			sqlBehavior: "error"
		}));
	}
	/** @internal */
	getSelectedFields() {
		return new Proxy(this.config.fields, new SelectionProxyHandler({
			alias: this.tableName,
			sqlAliasedBehavior: "alias",
			sqlBehavior: "error"
		}));
	}
	$dynamic() {
		return this;
	}
	$withCache(config) {
		this.cacheConfig = config === void 0 ? {
			config: {},
			enable: true,
			autoInvalidate: true
		} : config === false ? { enable: false } : {
			enable: true,
			autoInvalidate: true,
			...config
		};
		return this;
	}
};
var PgSelectBase = class extends PgSelectQueryBuilderBase {
	static [entityKind] = "PgSelect";
	/** @internal */
	_prepare(name) {
		const { session, config, dialect, joinsNotNullableMap, authToken, cacheConfig, usedTables } = this;
		if (!session) throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
		const { fields } = config;
		return tracer.startActiveSpan("drizzle.prepareQuery", () => {
			const fieldsList = orderSelectedFields(fields);
			const query = session.prepareQuery(dialect.sqlToQuery(this.getSQL()), fieldsList, name, true, void 0, {
				type: "select",
				tables: [...usedTables]
			}, cacheConfig);
			query.joinsNotNullableMap = joinsNotNullableMap;
			return query.setToken(authToken);
		});
	}
	/**
	* Create a prepared statement for this query. This allows
	* the database to remember this query for the given session
	* and call it by name, rather than specifying the full query.
	*
	* {@link https://www.postgresql.org/docs/current/sql-prepare.html | Postgres prepare documentation}
	*/
	prepare(name) {
		return this._prepare(name);
	}
	authToken;
	/** @internal */
	setToken(token) {
		this.authToken = token;
		return this;
	}
	execute = (placeholderValues) => {
		return tracer.startActiveSpan("drizzle.operation", () => {
			return this._prepare().execute(placeholderValues, this.authToken);
		});
	};
};
applyMixins(PgSelectBase, [QueryPromise]);
function createSetOperator(type, isAll) {
	return (leftSelect, rightSelect, ...restSelects) => {
		const setOperators = [rightSelect, ...restSelects].map((select) => ({
			type,
			isAll,
			rightSelect: select
		}));
		for (const setOperator of setOperators) if (!haveSameKeys(leftSelect.getSelectedFields(), setOperator.rightSelect.getSelectedFields())) throw new Error("Set operator error (union / intersect / except): selected fields are not the same or are in a different order");
		return leftSelect.addSetOperators(setOperators);
	};
}
var getPgSetOperators = () => ({
	union,
	unionAll,
	intersect,
	intersectAll,
	except,
	exceptAll
});
var union = createSetOperator("union", false);
var unionAll = createSetOperator("union", true);
var intersect = createSetOperator("intersect", false);
var intersectAll = createSetOperator("intersect", true);
var except = createSetOperator("except", false);
var exceptAll = createSetOperator("except", true);
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/query-builders/query-builder.js
var QueryBuilder = class {
	static [entityKind] = "PgQueryBuilder";
	dialect;
	dialectConfig;
	constructor(dialect) {
		this.dialect = is(dialect, PgDialect) ? dialect : void 0;
		this.dialectConfig = is(dialect, PgDialect) ? void 0 : dialect;
	}
	$with = (alias, selection) => {
		const queryBuilder = this;
		const as = (qb) => {
			if (typeof qb === "function") qb = qb(queryBuilder);
			return new Proxy(new WithSubquery(qb.getSQL(), selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}), alias, true), new SelectionProxyHandler({
				alias,
				sqlAliasedBehavior: "alias",
				sqlBehavior: "error"
			}));
		};
		return { as };
	};
	with(...queries) {
		const self = this;
		function select(fields) {
			return new PgSelectBuilder({
				fields: fields ?? void 0,
				session: void 0,
				dialect: self.getDialect(),
				withList: queries
			});
		}
		function selectDistinct(fields) {
			return new PgSelectBuilder({
				fields: fields ?? void 0,
				session: void 0,
				dialect: self.getDialect(),
				distinct: true
			});
		}
		function selectDistinctOn(on, fields) {
			return new PgSelectBuilder({
				fields: fields ?? void 0,
				session: void 0,
				dialect: self.getDialect(),
				distinct: { on }
			});
		}
		return {
			select,
			selectDistinct,
			selectDistinctOn
		};
	}
	select(fields) {
		return new PgSelectBuilder({
			fields: fields ?? void 0,
			session: void 0,
			dialect: this.getDialect()
		});
	}
	selectDistinct(fields) {
		return new PgSelectBuilder({
			fields: fields ?? void 0,
			session: void 0,
			dialect: this.getDialect(),
			distinct: true
		});
	}
	selectDistinctOn(on, fields) {
		return new PgSelectBuilder({
			fields: fields ?? void 0,
			session: void 0,
			dialect: this.getDialect(),
			distinct: { on }
		});
	}
	getDialect() {
		if (!this.dialect) this.dialect = new PgDialect(this.dialectConfig);
		return this.dialect;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/utils.js
function extractUsedTable(table) {
	if (is(table, PgTable)) return [table[Schema] ? `${table[Schema]}.${table[Table.Symbol.BaseName]}` : table[Table.Symbol.BaseName]];
	if (is(table, Subquery)) return table._.usedTables ?? [];
	if (is(table, SQL)) return table.usedTables ?? [];
	return [];
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/query-builders/delete.js
var PgDeleteBase = class extends QueryPromise {
	constructor(table, session, dialect, withList) {
		super();
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			withList
		};
	}
	static [entityKind] = "PgDelete";
	config;
	cacheConfig;
	/**
	* Adds a `where` clause to the query.
	*
	* Calling this method will delete only those rows that fulfill a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/delete}
	*
	* @param where the `where` clause.
	*
	* @example
	* You can use conditional operators and `sql function` to filter the rows to be deleted.
	*
	* ```ts
	* // Delete all cars with green color
	* await db.delete(cars).where(eq(cars.color, 'green'));
	* // or
	* await db.delete(cars).where(sql`${cars.color} = 'green'`)
	* ```
	*
	* You can logically combine conditional operators with `and()` and `or()` operators:
	*
	* ```ts
	* // Delete all BMW cars with a green color
	* await db.delete(cars).where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
	*
	* // Delete all cars with the green or blue color
	* await db.delete(cars).where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
	* ```
	*/
	where(where) {
		this.config.where = where;
		return this;
	}
	returning(fields = this.config.table[Table.Symbol.Columns]) {
		this.config.returningFields = fields;
		this.config.returning = orderSelectedFields(fields);
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildDeleteQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	/** @internal */
	_prepare(name) {
		return tracer.startActiveSpan("drizzle.prepareQuery", () => {
			return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true, void 0, {
				type: "delete",
				tables: extractUsedTable(this.config.table)
			}, this.cacheConfig);
		});
	}
	prepare(name) {
		return this._prepare(name);
	}
	authToken;
	/** @internal */
	setToken(token) {
		this.authToken = token;
		return this;
	}
	execute = (placeholderValues) => {
		return tracer.startActiveSpan("drizzle.operation", () => {
			return this._prepare().execute(placeholderValues, this.authToken);
		});
	};
	/** @internal */
	getSelectedFields() {
		return this.config.returningFields ? new Proxy(this.config.returningFields, new SelectionProxyHandler({
			alias: getTableName(this.config.table),
			sqlAliasedBehavior: "alias",
			sqlBehavior: "error"
		})) : void 0;
	}
	$dynamic() {
		return this;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/query-builders/insert.js
var PgInsertBuilder = class {
	constructor(table, session, dialect, withList, overridingSystemValue_) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.withList = withList;
		this.overridingSystemValue_ = overridingSystemValue_;
	}
	static [entityKind] = "PgInsertBuilder";
	authToken;
	/** @internal */
	setToken(token) {
		this.authToken = token;
		return this;
	}
	overridingSystemValue() {
		this.overridingSystemValue_ = true;
		return this;
	}
	values(values) {
		values = Array.isArray(values) ? values : [values];
		if (values.length === 0) throw new Error("values() must be called with at least one value");
		const mappedValues = values.map((entry) => {
			const result = {};
			const cols = this.table[Table.Symbol.Columns];
			for (const colKey of Object.keys(entry)) {
				const colValue = entry[colKey];
				result[colKey] = is(colValue, SQL) ? colValue : new Param(colValue, cols[colKey]);
			}
			return result;
		});
		return new PgInsertBase(this.table, mappedValues, this.session, this.dialect, this.withList, false, this.overridingSystemValue_).setToken(this.authToken);
	}
	select(selectQuery) {
		const select = typeof selectQuery === "function" ? selectQuery(new QueryBuilder()) : selectQuery;
		if (!is(select, SQL) && !haveSameKeys(this.table[Columns], select._.selectedFields)) throw new Error("Insert select error: selected fields are not the same or are in a different order compared to the table definition");
		return new PgInsertBase(this.table, select, this.session, this.dialect, this.withList, true);
	}
};
var PgInsertBase = class extends QueryPromise {
	constructor(table, values, session, dialect, withList, select, overridingSystemValue_) {
		super();
		this.session = session;
		this.dialect = dialect;
		this.config = {
			table,
			values,
			withList,
			select,
			overridingSystemValue_
		};
	}
	static [entityKind] = "PgInsert";
	config;
	cacheConfig;
	returning(fields = this.config.table[Table.Symbol.Columns]) {
		this.config.returningFields = fields;
		this.config.returning = orderSelectedFields(fields);
		return this;
	}
	/**
	* Adds an `on conflict do nothing` clause to the query.
	*
	* Calling this method simply avoids inserting a row as its alternative action.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#on-conflict-do-nothing}
	*
	* @param config The `target` and `where` clauses.
	*
	* @example
	* ```ts
	* // Insert one row and cancel the insert if there's a conflict
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoNothing();
	*
	* // Explicitly specify conflict target
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoNothing({ target: cars.id });
	* ```
	*/
	onConflictDoNothing(config = {}) {
		if (config.target === void 0) this.config.onConflict = sql`do nothing`;
		else {
			let targetColumn = "";
			targetColumn = Array.isArray(config.target) ? config.target.map((it) => this.dialect.escapeName(this.dialect.casing.getColumnCasing(it))).join(",") : this.dialect.escapeName(this.dialect.casing.getColumnCasing(config.target));
			const whereSql = config.where ? sql` where ${config.where}` : void 0;
			this.config.onConflict = sql`(${sql.raw(targetColumn)})${whereSql} do nothing`;
		}
		return this;
	}
	/**
	* Adds an `on conflict do update` clause to the query.
	*
	* Calling this method will update the existing row that conflicts with the row proposed for insertion as its alternative action.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert#upserts-and-conflicts}
	*
	* @param config The `target`, `set` and `where` clauses.
	*
	* @example
	* ```ts
	* // Update the row if there's a conflict
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoUpdate({
	*     target: cars.id,
	*     set: { brand: 'Porsche' }
	*   });
	*
	* // Upsert with 'where' clause
	* await db.insert(cars)
	*   .values({ id: 1, brand: 'BMW' })
	*   .onConflictDoUpdate({
	*     target: cars.id,
	*     set: { brand: 'newBMW' },
	*     targetWhere: sql`${cars.createdAt} > '2023-01-01'::date`,
	*   });
	* ```
	*/
	onConflictDoUpdate(config) {
		if (config.where && (config.targetWhere || config.setWhere)) throw new Error("You cannot use both \"where\" and \"targetWhere\"/\"setWhere\" at the same time - \"where\" is deprecated, use \"targetWhere\" or \"setWhere\" instead.");
		const whereSql = config.where ? sql` where ${config.where}` : void 0;
		const targetWhereSql = config.targetWhere ? sql` where ${config.targetWhere}` : void 0;
		const setWhereSql = config.setWhere ? sql` where ${config.setWhere}` : void 0;
		const setSql = this.dialect.buildUpdateSet(this.config.table, mapUpdateSet(this.config.table, config.set));
		let targetColumn = "";
		targetColumn = Array.isArray(config.target) ? config.target.map((it) => this.dialect.escapeName(this.dialect.casing.getColumnCasing(it))).join(",") : this.dialect.escapeName(this.dialect.casing.getColumnCasing(config.target));
		this.config.onConflict = sql`(${sql.raw(targetColumn)})${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`;
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildInsertQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	/** @internal */
	_prepare(name) {
		return tracer.startActiveSpan("drizzle.prepareQuery", () => {
			return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true, void 0, {
				type: "insert",
				tables: extractUsedTable(this.config.table)
			}, this.cacheConfig);
		});
	}
	prepare(name) {
		return this._prepare(name);
	}
	authToken;
	/** @internal */
	setToken(token) {
		this.authToken = token;
		return this;
	}
	execute = (placeholderValues) => {
		return tracer.startActiveSpan("drizzle.operation", () => {
			return this._prepare().execute(placeholderValues, this.authToken);
		});
	};
	/** @internal */
	getSelectedFields() {
		return this.config.returningFields ? new Proxy(this.config.returningFields, new SelectionProxyHandler({
			alias: getTableName(this.config.table),
			sqlAliasedBehavior: "alias",
			sqlBehavior: "error"
		})) : void 0;
	}
	$dynamic() {
		return this;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/query-builders/refresh-materialized-view.js
var PgRefreshMaterializedView = class extends QueryPromise {
	constructor(view, session, dialect) {
		super();
		this.session = session;
		this.dialect = dialect;
		this.config = { view };
	}
	static [entityKind] = "PgRefreshMaterializedView";
	config;
	concurrently() {
		if (this.config.withNoData !== void 0) throw new Error("Cannot use concurrently and withNoData together");
		this.config.concurrently = true;
		return this;
	}
	withNoData() {
		if (this.config.concurrently !== void 0) throw new Error("Cannot use concurrently and withNoData together");
		this.config.withNoData = true;
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildRefreshMaterializedViewQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	/** @internal */
	_prepare(name) {
		return tracer.startActiveSpan("drizzle.prepareQuery", () => {
			return this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), void 0, name, true);
		});
	}
	prepare(name) {
		return this._prepare(name);
	}
	authToken;
	/** @internal */
	setToken(token) {
		this.authToken = token;
		return this;
	}
	execute = (placeholderValues) => {
		return tracer.startActiveSpan("drizzle.operation", () => {
			return this._prepare().execute(placeholderValues, this.authToken);
		});
	};
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/query-builders/update.js
var PgUpdateBuilder = class {
	constructor(table, session, dialect, withList) {
		this.table = table;
		this.session = session;
		this.dialect = dialect;
		this.withList = withList;
	}
	static [entityKind] = "PgUpdateBuilder";
	authToken;
	setToken(token) {
		this.authToken = token;
		return this;
	}
	set(values) {
		return new PgUpdateBase(this.table, mapUpdateSet(this.table, values), this.session, this.dialect, this.withList).setToken(this.authToken);
	}
};
var PgUpdateBase = class extends QueryPromise {
	constructor(table, set, session, dialect, withList) {
		super();
		this.session = session;
		this.dialect = dialect;
		this.config = {
			set,
			table,
			withList,
			joins: []
		};
		this.tableName = getTableLikeName(table);
		this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
	}
	static [entityKind] = "PgUpdate";
	config;
	tableName;
	joinsNotNullableMap;
	cacheConfig;
	from(source) {
		const src = source;
		const tableName = getTableLikeName(src);
		if (typeof tableName === "string") this.joinsNotNullableMap[tableName] = true;
		this.config.from = src;
		return this;
	}
	getTableLikeFields(table) {
		if (is(table, PgTable)) return table[Table.Symbol.Columns];
		else if (is(table, Subquery)) return table._.selectedFields;
		return table[ViewBaseConfig].selectedFields;
	}
	createJoin(joinType) {
		return (table, on) => {
			const tableName = getTableLikeName(table);
			if (typeof tableName === "string" && this.config.joins.some((join) => join.alias === tableName)) throw new Error(`Alias "${tableName}" is already used in this query`);
			if (typeof on === "function") {
				const from = this.config.from && !is(this.config.from, SQL) ? this.getTableLikeFields(this.config.from) : void 0;
				on = on(new Proxy(this.config.table[Table.Symbol.Columns], new SelectionProxyHandler({
					sqlAliasedBehavior: "sql",
					sqlBehavior: "sql"
				})), from && new Proxy(from, new SelectionProxyHandler({
					sqlAliasedBehavior: "sql",
					sqlBehavior: "sql"
				})));
			}
			this.config.joins.push({
				on,
				table,
				joinType,
				alias: tableName
			});
			if (typeof tableName === "string") switch (joinType) {
				case "left":
					this.joinsNotNullableMap[tableName] = false;
					break;
				case "right":
					this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
					this.joinsNotNullableMap[tableName] = true;
					break;
				case "inner":
					this.joinsNotNullableMap[tableName] = true;
					break;
				case "full":
					this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
					this.joinsNotNullableMap[tableName] = false;
			}
			return this;
		};
	}
	leftJoin = this.createJoin("left");
	rightJoin = this.createJoin("right");
	innerJoin = this.createJoin("inner");
	fullJoin = this.createJoin("full");
	/**
	* Adds a 'where' clause to the query.
	*
	* Calling this method will update only those rows that fulfill a specified condition.
	*
	* See docs: {@link https://orm.drizzle.team/docs/update}
	*
	* @param where the 'where' clause.
	*
	* @example
	* You can use conditional operators and `sql function` to filter the rows to be updated.
	*
	* ```ts
	* // Update all cars with green color
	* await db.update(cars).set({ color: 'red' })
	*   .where(eq(cars.color, 'green'));
	* // or
	* await db.update(cars).set({ color: 'red' })
	*   .where(sql`${cars.color} = 'green'`)
	* ```
	*
	* You can logically combine conditional operators with `and()` and `or()` operators:
	*
	* ```ts
	* // Update all BMW cars with a green color
	* await db.update(cars).set({ color: 'red' })
	*   .where(and(eq(cars.color, 'green'), eq(cars.brand, 'BMW')));
	*
	* // Update all cars with the green or blue color
	* await db.update(cars).set({ color: 'red' })
	*   .where(or(eq(cars.color, 'green'), eq(cars.color, 'blue')));
	* ```
	*/
	where(where) {
		this.config.where = where;
		return this;
	}
	returning(fields) {
		if (!fields) {
			fields = Object.assign({}, this.config.table[Table.Symbol.Columns]);
			if (this.config.from) {
				const tableName = getTableLikeName(this.config.from);
				if (typeof tableName === "string" && this.config.from && !is(this.config.from, SQL)) {
					const fromFields = this.getTableLikeFields(this.config.from);
					fields[tableName] = fromFields;
				}
				for (const join of this.config.joins) {
					const tableName2 = getTableLikeName(join.table);
					if (typeof tableName2 === "string" && !is(join.table, SQL)) {
						const fromFields = this.getTableLikeFields(join.table);
						fields[tableName2] = fromFields;
					}
				}
			}
		}
		this.config.returningFields = fields;
		this.config.returning = orderSelectedFields(fields);
		return this;
	}
	/** @internal */
	getSQL() {
		return this.dialect.buildUpdateQuery(this.config);
	}
	toSQL() {
		const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
		return rest;
	}
	/** @internal */
	_prepare(name) {
		const query = this.session.prepareQuery(this.dialect.sqlToQuery(this.getSQL()), this.config.returning, name, true, void 0, {
			type: "insert",
			tables: extractUsedTable(this.config.table)
		}, this.cacheConfig);
		query.joinsNotNullableMap = this.joinsNotNullableMap;
		return query;
	}
	prepare(name) {
		return this._prepare(name);
	}
	authToken;
	/** @internal */
	setToken(token) {
		this.authToken = token;
		return this;
	}
	execute = (placeholderValues) => {
		return this._prepare().execute(placeholderValues, this.authToken);
	};
	/** @internal */
	getSelectedFields() {
		return this.config.returningFields ? new Proxy(this.config.returningFields, new SelectionProxyHandler({
			alias: getTableName(this.config.table),
			sqlAliasedBehavior: "alias",
			sqlBehavior: "error"
		})) : void 0;
	}
	$dynamic() {
		return this;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/query-builders/count.js
var PgCountBuilder = class PgCountBuilder extends SQL {
	constructor(params) {
		super(PgCountBuilder.buildEmbeddedCount(params.source, params.filters).queryChunks);
		this.params = params;
		this.mapWith(Number);
		this.session = params.session;
		this.sql = PgCountBuilder.buildCount(params.source, params.filters);
	}
	sql;
	token;
	static [entityKind] = "PgCountBuilder";
	[Symbol.toStringTag] = "PgCountBuilder";
	session;
	static buildEmbeddedCount(source, filters) {
		return sql`(select count(*) from ${source}${sql.raw(" where ").if(filters)}${filters})`;
	}
	static buildCount(source, filters) {
		return sql`select count(*) as count from ${source}${sql.raw(" where ").if(filters)}${filters};`;
	}
	/** @intrnal */
	setToken(token) {
		this.token = token;
		return this;
	}
	then(onfulfilled, onrejected) {
		return Promise.resolve(this.session.count(this.sql, this.token)).then(onfulfilled, onrejected);
	}
	catch(onRejected) {
		return this.then(void 0, onRejected);
	}
	finally(onFinally) {
		return this.then((value) => {
			onFinally?.();
			return value;
		}, (reason) => {
			onFinally?.();
			throw reason;
		});
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/query-builders/query.js
var RelationalQueryBuilder = class {
	constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session) {
		this.fullSchema = fullSchema;
		this.schema = schema;
		this.tableNamesMap = tableNamesMap;
		this.table = table;
		this.tableConfig = tableConfig;
		this.dialect = dialect;
		this.session = session;
	}
	static [entityKind] = "PgRelationalQueryBuilder";
	findMany(config) {
		return new PgRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? config : {}, "many");
	}
	findFirst(config) {
		return new PgRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? {
			...config,
			limit: 1
		} : { limit: 1 }, "first");
	}
};
var PgRelationalQuery = class extends QueryPromise {
	constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session, config, mode) {
		super();
		this.fullSchema = fullSchema;
		this.schema = schema;
		this.tableNamesMap = tableNamesMap;
		this.table = table;
		this.tableConfig = tableConfig;
		this.dialect = dialect;
		this.session = session;
		this.config = config;
		this.mode = mode;
	}
	static [entityKind] = "PgRelationalQuery";
	/** @internal */
	_prepare(name) {
		return tracer.startActiveSpan("drizzle.prepareQuery", () => {
			const { query, builtQuery } = this._toSQL();
			return this.session.prepareQuery(builtQuery, void 0, name, true, (rawRows, mapColumnValue) => {
				const rows = rawRows.map((row) => mapRelationalRow(this.schema, this.tableConfig, row, query.selection, mapColumnValue));
				if (this.mode === "first") return rows[0];
				return rows;
			});
		});
	}
	prepare(name) {
		return this._prepare(name);
	}
	_getQuery() {
		return this.dialect.buildRelationalQueryWithoutPK({
			fullSchema: this.fullSchema,
			schema: this.schema,
			tableNamesMap: this.tableNamesMap,
			table: this.table,
			tableConfig: this.tableConfig,
			queryConfig: this.config,
			tableAlias: this.tableConfig.tsName
		});
	}
	/** @internal */
	getSQL() {
		return this._getQuery().sql;
	}
	_toSQL() {
		const query = this._getQuery();
		return {
			query,
			builtQuery: this.dialect.sqlToQuery(query.sql)
		};
	}
	toSQL() {
		return this._toSQL().builtQuery;
	}
	authToken;
	/** @internal */
	setToken(token) {
		this.authToken = token;
		return this;
	}
	execute() {
		return tracer.startActiveSpan("drizzle.operation", () => {
			return this._prepare().execute(void 0, this.authToken);
		});
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/query-builders/raw.js
var PgRaw = class extends QueryPromise {
	constructor(execute, sql, query, mapBatchResult) {
		super();
		this.execute = execute;
		this.sql = sql;
		this.query = query;
		this.mapBatchResult = mapBatchResult;
	}
	static [entityKind] = "PgRaw";
	/** @internal */
	getSQL() {
		return this.sql;
	}
	getQuery() {
		return this.query;
	}
	mapResult(result, isFromBatch) {
		return isFromBatch ? this.mapBatchResult(result) : result;
	}
	_prepare() {
		return this;
	}
	/** @internal */
	isResponseInArrayMode() {
		return false;
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/db.js
var PgDatabase = class {
	constructor(dialect, session, schema) {
		this.dialect = dialect;
		this.session = session;
		this._ = schema ? {
			schema: schema.schema,
			fullSchema: schema.fullSchema,
			tableNamesMap: schema.tableNamesMap,
			session
		} : {
			schema: void 0,
			fullSchema: {},
			tableNamesMap: {},
			session
		};
		this.query = {};
		if (this._.schema) for (const [tableName, columns] of Object.entries(this._.schema)) this.query[tableName] = new RelationalQueryBuilder(schema.fullSchema, this._.schema, this._.tableNamesMap, schema.fullSchema[tableName], columns, dialect, session);
		this.$cache = { invalidate: async (_params) => {} };
	}
	static [entityKind] = "PgDatabase";
	query;
	/**
	* Creates a subquery that defines a temporary named result set as a CTE.
	*
	* It is useful for breaking down complex queries into simpler parts and for reusing the result set in subsequent parts of the query.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
	*
	* @param alias The alias for the subquery.
	*
	* Failure to provide an alias will result in a DrizzleTypeError, preventing the subquery from being referenced in other queries.
	*
	* @example
	*
	* ```ts
	* // Create a subquery with alias 'sq' and use it in the select query
	* const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
	*
	* const result = await db.with(sq).select().from(sq);
	* ```
	*
	* To select arbitrary SQL values as fields in a CTE and reference them in other CTEs or in the main query, you need to add aliases to them:
	*
	* ```ts
	* // Select an arbitrary SQL value as a field in a CTE and reference it in the main query
	* const sq = db.$with('sq').as(db.select({
	*   name: sql<string>`upper(${users.name})`.as('name'),
	* })
	* .from(users));
	*
	* const result = await db.with(sq).select({ name: sq.name }).from(sq);
	* ```
	*/
	$with = (alias, selection) => {
		const self = this;
		const as = (qb) => {
			if (typeof qb === "function") qb = qb(new QueryBuilder(self.dialect));
			return new Proxy(new WithSubquery(qb.getSQL(), selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}), alias, true), new SelectionProxyHandler({
				alias,
				sqlAliasedBehavior: "alias",
				sqlBehavior: "error"
			}));
		};
		return { as };
	};
	$count(source, filters) {
		return new PgCountBuilder({
			source,
			filters,
			session: this.session
		});
	}
	$cache;
	/**
	* Incorporates a previously defined CTE (using `$with`) into the main query.
	*
	* This method allows the main query to reference a temporary named result set.
	*
	* See docs: {@link https://orm.drizzle.team/docs/select#with-clause}
	*
	* @param queries The CTEs to incorporate into the main query.
	*
	* @example
	*
	* ```ts
	* // Define a subquery 'sq' as a CTE using $with
	* const sq = db.$with('sq').as(db.select().from(users).where(eq(users.id, 42)));
	*
	* // Incorporate the CTE 'sq' into the main query and select from it
	* const result = await db.with(sq).select().from(sq);
	* ```
	*/
	with(...queries) {
		const self = this;
		function select(fields) {
			return new PgSelectBuilder({
				fields: fields ?? void 0,
				session: self.session,
				dialect: self.dialect,
				withList: queries
			});
		}
		function selectDistinct(fields) {
			return new PgSelectBuilder({
				fields: fields ?? void 0,
				session: self.session,
				dialect: self.dialect,
				withList: queries,
				distinct: true
			});
		}
		function selectDistinctOn(on, fields) {
			return new PgSelectBuilder({
				fields: fields ?? void 0,
				session: self.session,
				dialect: self.dialect,
				withList: queries,
				distinct: { on }
			});
		}
		function update(table) {
			return new PgUpdateBuilder(table, self.session, self.dialect, queries);
		}
		function insert(table) {
			return new PgInsertBuilder(table, self.session, self.dialect, queries);
		}
		function delete_(table) {
			return new PgDeleteBase(table, self.session, self.dialect, queries);
		}
		return {
			select,
			selectDistinct,
			selectDistinctOn,
			update,
			insert,
			delete: delete_
		};
	}
	select(fields) {
		return new PgSelectBuilder({
			fields: fields ?? void 0,
			session: this.session,
			dialect: this.dialect
		});
	}
	selectDistinct(fields) {
		return new PgSelectBuilder({
			fields: fields ?? void 0,
			session: this.session,
			dialect: this.dialect,
			distinct: true
		});
	}
	selectDistinctOn(on, fields) {
		return new PgSelectBuilder({
			fields: fields ?? void 0,
			session: this.session,
			dialect: this.dialect,
			distinct: { on }
		});
	}
	/**
	* Creates an update query.
	*
	* Calling this method without `.where()` clause will update all rows in a table. The `.where()` clause specifies which rows should be updated.
	*
	* Use `.set()` method to specify which values to update.
	*
	* See docs: {@link https://orm.drizzle.team/docs/update}
	*
	* @param table The table to update.
	*
	* @example
	*
	* ```ts
	* // Update all rows in the 'cars' table
	* await db.update(cars).set({ color: 'red' });
	*
	* // Update rows with filters and conditions
	* await db.update(cars).set({ color: 'red' }).where(eq(cars.brand, 'BMW'));
	*
	* // Update with returning clause
	* const updatedCar: Car[] = await db.update(cars)
	*   .set({ color: 'red' })
	*   .where(eq(cars.id, 1))
	*   .returning();
	* ```
	*/
	update(table) {
		return new PgUpdateBuilder(table, this.session, this.dialect);
	}
	/**
	* Creates an insert query.
	*
	* Calling this method will create new rows in a table. Use `.values()` method to specify which values to insert.
	*
	* See docs: {@link https://orm.drizzle.team/docs/insert}
	*
	* @param table The table to insert into.
	*
	* @example
	*
	* ```ts
	* // Insert one row
	* await db.insert(cars).values({ brand: 'BMW' });
	*
	* // Insert multiple rows
	* await db.insert(cars).values([{ brand: 'BMW' }, { brand: 'Porsche' }]);
	*
	* // Insert with returning clause
	* const insertedCar: Car[] = await db.insert(cars)
	*   .values({ brand: 'BMW' })
	*   .returning();
	* ```
	*/
	insert(table) {
		return new PgInsertBuilder(table, this.session, this.dialect);
	}
	/**
	* Creates a delete query.
	*
	* Calling this method without `.where()` clause will delete all rows in a table. The `.where()` clause specifies which rows should be deleted.
	*
	* See docs: {@link https://orm.drizzle.team/docs/delete}
	*
	* @param table The table to delete from.
	*
	* @example
	*
	* ```ts
	* // Delete all rows in the 'cars' table
	* await db.delete(cars);
	*
	* // Delete rows with filters and conditions
	* await db.delete(cars).where(eq(cars.color, 'green'));
	*
	* // Delete with returning clause
	* const deletedCar: Car[] = await db.delete(cars)
	*   .where(eq(cars.id, 1))
	*   .returning();
	* ```
	*/
	delete(table) {
		return new PgDeleteBase(table, this.session, this.dialect);
	}
	refreshMaterializedView(view) {
		return new PgRefreshMaterializedView(view, this.session, this.dialect);
	}
	authToken;
	execute(query) {
		const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
		const builtQuery = this.dialect.sqlToQuery(sequel);
		const prepared = this.session.prepareQuery(builtQuery, void 0, void 0, false);
		return new PgRaw(() => prepared.execute(void 0, this.authToken), sequel, builtQuery, (result) => prepared.mapResult(result, true));
	}
	transaction(transaction, config) {
		return this.session.transaction(transaction, config);
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/pg-core/session.js
var PgPreparedQuery = class {
	constructor(query, cache, queryMetadata, cacheConfig) {
		this.query = query;
		this.cache = cache;
		this.queryMetadata = queryMetadata;
		this.cacheConfig = cacheConfig;
		if (cache && cache.strategy() === "all" && cacheConfig === void 0) this.cacheConfig = {
			enable: true,
			autoInvalidate: true
		};
		if (!this.cacheConfig?.enable) this.cacheConfig = void 0;
	}
	authToken;
	getQuery() {
		return this.query;
	}
	mapResult(response, _isFromBatch) {
		return response;
	}
	/** @internal */
	setToken(token) {
		this.authToken = token;
		return this;
	}
	static [entityKind] = "PgPreparedQuery";
	/** @internal */
	joinsNotNullableMap;
	/** @internal */
	async queryWithCache(queryString, params, query) {
		if (this.cache === void 0 || is(this.cache, NoopCache) || this.queryMetadata === void 0) try {
			return await query();
		} catch (e) {
			throw new DrizzleQueryError(queryString, params, e);
		}
		if (this.cacheConfig && !this.cacheConfig.enable) try {
			return await query();
		} catch (e) {
			throw new DrizzleQueryError(queryString, params, e);
		}
		if ((this.queryMetadata.type === "insert" || this.queryMetadata.type === "update" || this.queryMetadata.type === "delete") && this.queryMetadata.tables.length > 0) try {
			const [res] = await Promise.all([query(), this.cache.onMutate({ tables: this.queryMetadata.tables })]);
			return res;
		} catch (e) {
			throw new DrizzleQueryError(queryString, params, e);
		}
		if (!this.cacheConfig) try {
			return await query();
		} catch (e) {
			throw new DrizzleQueryError(queryString, params, e);
		}
		if (this.queryMetadata.type === "select") {
			const fromCache = await this.cache.get(this.cacheConfig.tag ?? await hashQuery(queryString, params), this.queryMetadata.tables, this.cacheConfig.tag !== void 0, this.cacheConfig.autoInvalidate);
			if (fromCache === void 0) {
				let result;
				try {
					result = await query();
				} catch (e) {
					throw new DrizzleQueryError(queryString, params, e);
				}
				await this.cache.put(this.cacheConfig.tag ?? await hashQuery(queryString, params), result, this.cacheConfig.autoInvalidate ? this.queryMetadata.tables : [], this.cacheConfig.tag !== void 0, this.cacheConfig.config);
				return result;
			}
			return fromCache;
		}
		try {
			return await query();
		} catch (e) {
			throw new DrizzleQueryError(queryString, params, e);
		}
	}
};
var PgSession = class {
	constructor(dialect) {
		this.dialect = dialect;
	}
	static [entityKind] = "PgSession";
	/** @internal */
	execute(query, token) {
		return tracer.startActiveSpan("drizzle.operation", () => {
			return tracer.startActiveSpan("drizzle.prepareQuery", () => {
				return this.prepareQuery(this.dialect.sqlToQuery(query), void 0, void 0, false);
			}).setToken(token).execute(void 0, token);
		});
	}
	all(query) {
		return this.prepareQuery(this.dialect.sqlToQuery(query), void 0, void 0, false).all();
	}
	/** @internal */
	async count(sql2, token) {
		const res = await this.execute(sql2, token);
		return Number(res[0]["count"]);
	}
};
var PgTransaction = class extends PgDatabase {
	constructor(dialect, session, schema, nestedIndex = 0) {
		super(dialect, session, schema);
		this.schema = schema;
		this.nestedIndex = nestedIndex;
	}
	static [entityKind] = "PgTransaction";
	rollback() {
		throw new TransactionRollbackError();
	}
	/** @internal */
	getTransactionConfigSQL(config) {
		const chunks = [];
		if (config.isolationLevel) chunks.push(`isolation level ${config.isolationLevel}`);
		if (config.accessMode) chunks.push(config.accessMode);
		if (typeof config.deferrable === "boolean") chunks.push(config.deferrable ? "deferrable" : "not deferrable");
		return sql.raw(chunks.join(" "));
	}
	setTransaction(config) {
		return this.session.execute(sql`set transaction ${this.getTransactionConfigSQL(config)}`);
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/postgres-js/session.js
var PostgresJsPreparedQuery = class extends PgPreparedQuery {
	constructor(client, queryString, params, logger, cache, queryMetadata, cacheConfig, fields, _isResponseInArrayMode, customResultMapper) {
		super({
			sql: queryString,
			params
		}, cache, queryMetadata, cacheConfig);
		this.client = client;
		this.queryString = queryString;
		this.params = params;
		this.logger = logger;
		this.fields = fields;
		this._isResponseInArrayMode = _isResponseInArrayMode;
		this.customResultMapper = customResultMapper;
	}
	static [entityKind] = "PostgresJsPreparedQuery";
	async execute(placeholderValues = {}) {
		return tracer.startActiveSpan("drizzle.execute", async (span) => {
			const params = fillPlaceholders(this.params, placeholderValues);
			span?.setAttributes({
				"drizzle.query.text": this.queryString,
				"drizzle.query.params": JSON.stringify(params)
			});
			this.logger.logQuery(this.queryString, params);
			const { fields, queryString: query, client, joinsNotNullableMap, customResultMapper } = this;
			if (!fields && !customResultMapper) return tracer.startActiveSpan("drizzle.driver.execute", () => {
				return this.queryWithCache(query, params, async () => {
					return await client.unsafe(query, params);
				});
			});
			const rows = await tracer.startActiveSpan("drizzle.driver.execute", () => {
				span?.setAttributes({
					"drizzle.query.text": query,
					"drizzle.query.params": JSON.stringify(params)
				});
				return this.queryWithCache(query, params, async () => {
					return await client.unsafe(query, params).values();
				});
			});
			return tracer.startActiveSpan("drizzle.mapResponse", () => {
				return customResultMapper ? customResultMapper(rows) : rows.map((row) => mapResultRow(fields, row, joinsNotNullableMap));
			});
		});
	}
	all(placeholderValues = {}) {
		return tracer.startActiveSpan("drizzle.execute", async (span) => {
			const params = fillPlaceholders(this.params, placeholderValues);
			span?.setAttributes({
				"drizzle.query.text": this.queryString,
				"drizzle.query.params": JSON.stringify(params)
			});
			this.logger.logQuery(this.queryString, params);
			return tracer.startActiveSpan("drizzle.driver.execute", () => {
				span?.setAttributes({
					"drizzle.query.text": this.queryString,
					"drizzle.query.params": JSON.stringify(params)
				});
				return this.queryWithCache(this.queryString, params, async () => {
					return this.client.unsafe(this.queryString, params);
				});
			});
		});
	}
	/** @internal */
	isResponseInArrayMode() {
		return this._isResponseInArrayMode;
	}
};
var PostgresJsSession = class PostgresJsSession extends PgSession {
	constructor(client, dialect, schema, options = {}) {
		super(dialect);
		this.client = client;
		this.schema = schema;
		this.options = options;
		this.logger = options.logger ?? new NoopLogger();
		this.cache = options.cache ?? new NoopCache();
	}
	static [entityKind] = "PostgresJsSession";
	logger;
	cache;
	prepareQuery(query, fields, name, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig) {
		return new PostgresJsPreparedQuery(this.client, query.sql, query.params, this.logger, this.cache, queryMetadata, cacheConfig, fields, isResponseInArrayMode, customResultMapper);
	}
	query(query, params) {
		this.logger.logQuery(query, params);
		return this.client.unsafe(query, params).values();
	}
	queryObjects(query, params) {
		return this.client.unsafe(query, params);
	}
	transaction(transaction, config) {
		return this.client.begin(async (client) => {
			const session = new PostgresJsSession(client, this.dialect, this.schema, this.options);
			const tx = new PostgresJsTransaction(this.dialect, session, this.schema);
			if (config) await tx.setTransaction(config);
			return transaction(tx);
		});
	}
};
var PostgresJsTransaction = class PostgresJsTransaction extends PgTransaction {
	constructor(dialect, session, schema, nestedIndex = 0) {
		super(dialect, session, schema, nestedIndex);
		this.session = session;
	}
	static [entityKind] = "PostgresJsTransaction";
	transaction(transaction) {
		return this.session.client.savepoint((client) => {
			const session = new PostgresJsSession(client, this.dialect, this.schema, this.session.options);
			return transaction(new PostgresJsTransaction(this.dialect, session, this.schema));
		});
	}
};
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/postgres-js/driver.js
var PostgresJsDatabase = class extends PgDatabase {
	static [entityKind] = "PostgresJsDatabase";
};
function construct(client, config = {}) {
	const transparentParser = (val) => val;
	for (const type of [
		"1184",
		"1082",
		"1083",
		"1114",
		"1182",
		"1185",
		"1115",
		"1231"
	]) {
		client.options.parsers[type] = transparentParser;
		client.options.serializers[type] = transparentParser;
	}
	client.options.serializers["114"] = transparentParser;
	client.options.serializers["3802"] = transparentParser;
	const dialect = new PgDialect({ casing: config.casing });
	let logger;
	if (config.logger === true) logger = new DefaultLogger();
	else if (config.logger !== false) logger = config.logger;
	let schema;
	if (config.schema) {
		const tablesConfig = extractTablesRelationalConfig(config.schema, createTableRelationsHelpers);
		schema = {
			fullSchema: config.schema,
			schema: tablesConfig.tables,
			tableNamesMap: tablesConfig.tableNamesMap
		};
	}
	const db = new PostgresJsDatabase(dialect, new PostgresJsSession(client, dialect, schema, {
		logger,
		cache: config.cache
	}), schema);
	db.$client = client;
	db.$cache = config.cache;
	if (db.$cache) db.$cache["invalidate"] = config.cache?.onMutate;
	return db;
}
function drizzle(...params) {
	if (typeof params[0] === "string") return construct(src_default(params[0]), params[1]);
	if (isConfig(params[0])) {
		const { connection, client, ...drizzleConfig } = params[0];
		if (client) return construct(client, drizzleConfig);
		if (typeof connection === "object" && connection.url !== void 0) {
			const { url, ...config } = connection;
			return construct(src_default(url, config), drizzleConfig);
		}
		return construct(src_default(connection), drizzleConfig);
	}
	return construct(params[0], params[1]);
}
((drizzle2) => {
	function mock(config) {
		return construct({ options: {
			parsers: {},
			serializers: {}
		} }, config);
	}
	drizzle2.mock = mock;
})(drizzle || (drizzle = {}));
//#endregion
//#region src/db/pg/retry.ts
/**
* Per-query retry for transient connection failures.
*
* PlanetScale HA operations (cluster resizes, image upgrades, unplanned
* failovers) terminate every connection when the primary moves, with the
* cutover completing in under ~5 seconds. Hyperdrive reconnects transparently
* for new queries, but a query in flight \u2014 or one issued before the new
* primary accepts connections \u2014 fails with a connection error. This wrapper
* retries those instead of failing the whole request.
*
* Safety: a write may have committed even though the connection died before
* the response arrived, so writes are only retried on errors that occur
* strictly before the query reaches the server (connect-phase failures).
* Selects are retried on any transient connection error. Transactions
* (`db.transaction` \u2192 `sql.begin`) are not retried: postgres.js hands the
* transaction callback a raw connection-scoped client that bypasses this
* wrapper, and replaying a partially applied transaction is not safe.
*/
var TRANSIENT_ERROR_CODES = /* @__PURE__ */ new Set([
	"CONNECTION_CLOSED",
	"CONNECTION_ENDED",
	"CONNECTION_DESTROYED",
	"CONNECT_TIMEOUT",
	"ECONNRESET",
	"ECONNREFUSED",
	"EPIPE",
	"ETIMEDOUT",
	"08000",
	"08001",
	"08003",
	"08004",
	"08006",
	"08P01",
	"57P01",
	"57P02",
	"57P03"
]);
var PRE_EXECUTION_CODES = /* @__PURE__ */ new Set([
	"CONNECT_TIMEOUT",
	"ECONNREFUSED",
	"08001",
	"08004",
	"57P03"
]);
var RETRY_DELAYS_MS = [
	250,
	1e3,
	2500
];
function isWorkerdConnectionLost(error) {
	return error instanceof Error && error.message.startsWith("Network connection lost");
}
function isRetryable(error, query) {
	const code = error?.code;
	if (!(typeof code === "string" ? TRANSIENT_ERROR_CODES.has(code) : isWorkerdConnectionLost(error))) return false;
	if (typeof code === "string" && PRE_EXECUTION_CODES.has(code)) return true;
	return /^\s*select\b/i.test(query);
}
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
/**
* Wrap a postgres.js client so `sql.unsafe` \u2014 the single entrypoint
* drizzle-orm/postgres-js issues queries through \u2014 retries transient
* connection errors. Everything else on the client passes through untouched.
*/
function withQueryRetries(sql) {
	const retryingUnsafe = ((query, ...rest) => {
		const run = () => sql.unsafe(query, ...rest);
		const attempt = async (execute) => {
			for (let i = 0;; i++) try {
				return await execute(run());
			} catch (error) {
				if (i >= RETRY_DELAYS_MS.length || !isRetryable(error, query)) throw error;
				await sleep(RETRY_DELAYS_MS[i] + Math.random() * 250);
			}
		};
		return {
			then: (onFulfilled, onRejected) => attempt((q) => q).then(onFulfilled, onRejected),
			catch: (onRejected) => attempt((q) => q).catch(onRejected),
			finally: (onFinally) => attempt((q) => q).finally(onFinally),
			values: () => attempt((q) => q.values()),
			raw: () => attempt((q) => q.raw()),
			execute: () => attempt((q) => q.execute())
		};
	});
	return new Proxy(sql, { get(target, prop, receiver) {
		if (prop === "unsafe") return retryingUnsafe;
		return Reflect.get(target, prop, receiver);
	} });
}
//#endregion
//#region src/db/pg/better-auth-schema.ts
var better_auth_schema_exports = /* @__PURE__ */ __exportAll({
	account: () => account,
	accountRelations: () => accountRelations,
	apikey: () => apikey,
	invitation: () => invitation,
	invitationRelations: () => invitationRelations,
	member: () => member,
	memberRelations: () => memberRelations,
	organization: () => organization,
	organizationRelations: () => organizationRelations,
	session: () => session,
	sessionRelations: () => sessionRelations,
	user: () => user,
	userRelations: () => userRelations,
	verification: () => verification
});
var timestampColumn$2 = (name) => timestamp(name, {
	mode: "date",
	withTimezone: true
});
var user = pgTable("user", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	email: text$1("email").notNull().unique(),
	emailVerified: boolean("email_verified").default(false).notNull(),
	image: text$1("image"),
	createdAt: timestampColumn$2("created_at").defaultNow().notNull(),
	updatedAt: timestampColumn$2("updated_at").defaultNow().$onUpdate(() => /* @__PURE__ */ new Date()).notNull(),
	analyticsOptedOut: boolean("analytics_opted_out"),
	termsAcceptedVersion: text$1("terms_accepted_version"),
	termsAcceptedAt: timestampColumn$2("terms_accepted_at"),
	productUpdatesOptIn: boolean("product_updates_opt_in"),
	productUpdatesChangedAt: timestampColumn$2("product_updates_changed_at"),
	lastActiveOrganizationId: text$1("last_active_organization_id")
});
var session = pgTable("session", {
	id: text$1("id").primaryKey(),
	expiresAt: timestampColumn$2("expires_at").notNull(),
	token: text$1("token").notNull().unique(),
	createdAt: timestampColumn$2("created_at").defaultNow().notNull(),
	updatedAt: timestampColumn$2("updated_at").$onUpdate(() => /* @__PURE__ */ new Date()).notNull(),
	ipAddress: text$1("ip_address"),
	userAgent: text$1("user_agent"),
	userId: text$1("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
	activeOrganizationId: text$1("active_organization_id")
}, (table) => [index("session_userId_idx").on(table.userId)]);
var account = pgTable("account", {
	id: text$1("id").primaryKey(),
	accountId: text$1("account_id").notNull(),
	providerId: text$1("provider_id").notNull(),
	userId: text$1("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
	accessToken: text$1("access_token"),
	refreshToken: text$1("refresh_token"),
	idToken: text$1("id_token"),
	accessTokenExpiresAt: timestampColumn$2("access_token_expires_at"),
	refreshTokenExpiresAt: timestampColumn$2("refresh_token_expires_at"),
	scope: text$1("scope"),
	password: text$1("password"),
	createdAt: timestampColumn$2("created_at").defaultNow().notNull(),
	updatedAt: timestampColumn$2("updated_at").$onUpdate(() => /* @__PURE__ */ new Date()).notNull()
}, (table) => [
	index("account_userId_idx").on(table.userId),
	index("account_accountId_providerId_idx").on(table.accountId, table.providerId),
	uniqueIndex("account_google_grant_owner_idx").on(table.userId, table.providerId, table.accountId).where(sql`${table.providerId} in ('google-search-console', 'google-analytics')`)
]);
var verification = pgTable("verification", {
	id: text$1("id").primaryKey(),
	identifier: text$1("identifier").notNull(),
	value: text$1("value").notNull(),
	expiresAt: timestampColumn$2("expires_at").notNull(),
	createdAt: timestampColumn$2("created_at").defaultNow().notNull(),
	updatedAt: timestampColumn$2("updated_at").defaultNow().$onUpdate(() => /* @__PURE__ */ new Date()).notNull()
}, (table) => [index("verification_identifier_idx").on(table.identifier), index("verification_expiresAt_idx").on(table.expiresAt)]);
var organization = pgTable("organization", {
	id: text$1("id").primaryKey(),
	name: text$1("name").notNull(),
	slug: text$1("slug").notNull().unique(),
	logo: text$1("logo"),
	createdAt: timestampColumn$2("created_at").notNull(),
	metadata: text$1("metadata")
}, (table) => [uniqueIndex("organization_slug_uidx").on(table.slug)]);
var member = pgTable("member", {
	id: text$1("id").primaryKey(),
	organizationId: text$1("organization_id").notNull().references(() => organization.id, { onDelete: "cascade" }),
	userId: text$1("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
	role: text$1("role").default("member").notNull(),
	createdAt: timestampColumn$2("created_at").notNull()
}, (table) => [
	index("member_organizationId_idx").on(table.organizationId),
	index("member_userId_idx").on(table.userId),
	uniqueIndex("member_organizationId_userId_uidx").on(table.organizationId, table.userId)
]);
var invitation = pgTable("invitation", {
	id: text$1("id").primaryKey(),
	organizationId: text$1("organization_id").notNull().references(() => organization.id, { onDelete: "cascade" }),
	email: text$1("email").notNull(),
	role: text$1("role"),
	status: text$1("status").default("pending").notNull(),
	expiresAt: timestampColumn$2("expires_at").notNull(),
	createdAt: timestampColumn$2("created_at").defaultNow().notNull(),
	inviterId: text$1("inviter_id").notNull().references(() => user.id, { onDelete: "cascade" })
}, (table) => [index("invitation_organizationId_idx").on(table.organizationId), index("invitation_email_idx").on(table.email)]);
var apikey = pgTable("apikey", {
	id: text$1("id").primaryKey(),
	configId: text$1("config_id").default("default").notNull(),
	name: text$1("name"),
	start: text$1("start"),
	prefix: text$1("prefix"),
	key: text$1("key").notNull(),
	referenceId: text$1("reference_id").notNull(),
	refillInterval: integer$1("refill_interval"),
	refillAmount: integer$1("refill_amount"),
	lastRefillAt: timestampColumn$2("last_refill_at"),
	enabled: boolean("enabled").default(true),
	rateLimitEnabled: boolean("rate_limit_enabled").default(true),
	rateLimitTimeWindow: integer$1("rate_limit_time_window").default(6e4),
	rateLimitMax: integer$1("rate_limit_max").default(120),
	requestCount: integer$1("request_count").default(0),
	remaining: integer$1("remaining"),
	lastRequest: timestampColumn$2("last_request"),
	expiresAt: timestampColumn$2("expires_at"),
	createdAt: timestampColumn$2("created_at").notNull(),
	updatedAt: timestampColumn$2("updated_at").notNull(),
	permissions: text$1("permissions"),
	metadata: text$1("metadata")
}, (table) => [
	index("apikey_configId_idx").on(table.configId),
	index("apikey_referenceId_idx").on(table.referenceId),
	index("apikey_key_idx").on(table.key)
]);
var userRelations = relations(user, ({ many }) => ({
	sessions: many(session),
	accounts: many(account),
	members: many(member),
	invitations: many(invitation)
}));
var sessionRelations = relations(session, ({ one }) => ({ user: one(user, {
	fields: [session.userId],
	references: [user.id]
}) }));
var accountRelations = relations(account, ({ one }) => ({ user: one(user, {
	fields: [account.userId],
	references: [user.id]
}) }));
var organizationRelations = relations(organization, ({ many }) => ({
	members: many(member),
	invitations: many(invitation)
}));
var memberRelations = relations(member, ({ one }) => ({
	organization: one(organization, {
		fields: [member.organizationId],
		references: [organization.id]
	}),
	user: one(user, {
		fields: [member.userId],
		references: [user.id]
	})
}));
var invitationRelations = relations(invitation, ({ one }) => ({
	organization: one(organization, {
		fields: [invitation.organizationId],
		references: [organization.id]
	}),
	user: one(user, {
		fields: [invitation.inviterId],
		references: [user.id]
	})
}));
//#endregion
//#region src/db/pg/dashboard.schema.ts
var dataRefreshClaims = pgTable("data_refresh_claims", {
	key: text$1("key").primaryKey(),
	organizationId: text$1("organization_id").notNull().references(() => organization.id, { onDelete: "cascade" }),
	token: text$1("token").notNull(),
	nextAttemptAt: bigint("next_attempt_at", { mode: "number" }).notNull()
});
//#endregion
//#region src/db/pg/app.schema.ts
var app_schema_exports = /* @__PURE__ */ __exportAll({
	accountDeletionRequests: () => accountDeletionRequests,
	backlinkSnapshots: () => backlinkSnapshots,
	crawlerCredentials: () => crawlerCredentials,
	dashboardStepDismissals: () => dashboardStepDismissals,
	dataRefreshClaims: () => dataRefreshClaims,
	guestAccounts: () => guestAccounts,
	keywordMetrics: () => keywordMetrics,
	organizationActivationState: () => organizationActivationState,
	projectActivationState: () => projectActivationState,
	projects: () => projects,
	rankCheckRuns: () => rankCheckRuns,
	rankSnapshots: () => rankSnapshots,
	rankTrackingConfigs: () => rankTrackingConfigs,
	rankTrackingKeywords: () => rankTrackingKeywords,
	savedKeywordTagAssignments: () => savedKeywordTagAssignments,
	savedKeywordTags: () => savedKeywordTags,
	savedKeywords: () => savedKeywords,
	userOnboardingAnswers: () => userOnboardingAnswers,
	userSignupCampaigns: () => userSignupCampaigns
});
var isoNow$8 = sql`to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')`;
var timestampColumn$1 = (name) => text$1(name);
var userOnboardingAnswers = pgTable("user_onboarding_answers", {
	userId: text$1("user_id").primaryKey().references(() => user.id, { onDelete: "cascade" }),
	organizationId: text$1("organization_id").notNull().references(() => organization.id, { onDelete: "cascade" }),
	interestedFeatures: text$1("interested_features").notNull().default("[]"),
	workFor: text$1("work_for"),
	clientWebsiteCount: text$1("client_website_count"),
	foundVia: text$1("found_via"),
	mcpSetupIntent: text$1("mcp_setup_intent"),
	completedAt: timestampColumn$1("completed_at"),
	gscNudgeDismissedAt: timestampColumn$1("gsc_nudge_dismissed_at"),
	createdAt: timestampColumn$1("created_at").notNull().default(isoNow$8),
	updatedAt: timestampColumn$1("updated_at").notNull().default(isoNow$8)
}, (table) => [index("user_onboarding_answers_organization_idx").on(table.organizationId)]);
var userSignupCampaigns = pgTable("user_signup_campaigns", {
	userId: text$1("user_id").primaryKey().references(() => user.id, { onDelete: "cascade" }),
	entry: text$1("entry"),
	wasGuest: boolean("was_guest"),
	agent: text$1("agent"),
	utmMedium: text$1("utm_medium"),
	utmSource: text$1("utm_source"),
	utmCampaign: text$1("utm_campaign"),
	utmContent: text$1("utm_content")
});
var guestAccounts = pgTable("guest_accounts", {
	userId: text$1("user_id").primaryKey(),
	ipHash: text$1("ip_hash").notNull(),
	slot: integer$1("slot").notNull().default(0),
	claimToken: text$1("claim_token").notNull().unique(),
	agent: text$1("agent"),
	claimedByUserId: text$1("claimed_by_user_id").references(() => user.id, { onDelete: "set null" }),
	createdAt: text$1("created_at").notNull()
}, (table) => [uniqueIndex("guest_accounts_ip_hash_slot_idx").on(table.ipHash, table.slot)]);
var accountDeletionRequests = pgTable("account_deletion_requests", {
	userId: text$1("user_id").primaryKey().references(() => user.id, { onDelete: "cascade" }),
	requestedAt: text$1("requested_at").notNull(),
	deleteAfter: text$1("delete_after").notNull()
}, (table) => [index("account_deletion_requests_delete_after_idx").on(table.deleteAfter)]);
var projects = pgTable("projects", {
	id: text$1("id").primaryKey(),
	organizationId: text$1("organization_id").notNull().references(() => organization.id, { onDelete: "cascade" }),
	name: text$1("name").notNull(),
	brandName: text$1("brand_name"),
	domain: text$1("domain"),
	locationCode: integer$1("location_code").notNull().default(2840),
	languageCode: text$1("language_code").notNull().default("en"),
	createdAt: timestampColumn$1("created_at").notNull().default(isoNow$8),
	archivedAt: timestampColumn$1("archived_at"),
	aiResearchKeywords: text$1("ai_research_keywords"),
	indexnowKey: text$1("indexnow_key")
}, (table) => [uniqueIndex("projects_one_default_per_organization_idx").on(table.organizationId).where(sql`${table.name} = 'Default' AND ${table.domain} IS NULL AND ${table.archivedAt} IS NULL`), index("projects_organization_id_idx").on(table.organizationId)]);
var savedKeywords = pgTable("saved_keywords", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	keyword: text$1("keyword").notNull(),
	locationCode: integer$1("location_code").notNull().default(2840),
	languageCode: text$1("language_code").notNull().default("en"),
	createdAt: timestampColumn$1("created_at").notNull().default(isoNow$8)
}, (table) => [uniqueIndex("saved_keywords_unique_project_keyword_location_language").on(table.projectId, table.keyword, table.locationCode, table.languageCode), index("saved_keywords_project_created_idx").on(table.projectId, table.createdAt)]);
var savedKeywordTags = pgTable("saved_keyword_tags", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	name: text$1("name").notNull(),
	normalizedName: text$1("normalized_name").notNull(),
	color: text$1("color"),
	createdAt: timestampColumn$1("created_at").notNull().default(isoNow$8)
}, (table) => [uniqueIndex("saved_keyword_tags_project_normalized_name_idx").on(table.projectId, table.normalizedName), index("saved_keyword_tags_project_name_idx").on(table.projectId, table.name)]);
var savedKeywordTagAssignments = pgTable("saved_keyword_tag_assignments", {
	savedKeywordId: text$1("saved_keyword_id").notNull().references(() => savedKeywords.id, { onDelete: "cascade" }),
	tagId: text$1("tag_id").notNull().references(() => savedKeywordTags.id, { onDelete: "cascade" }),
	createdAt: timestampColumn$1("created_at").notNull().default(isoNow$8)
}, (table) => [uniqueIndex("saved_keyword_tag_assignments_unique_idx").on(table.savedKeywordId, table.tagId), index("saved_keyword_tag_assignments_tag_idx").on(table.tagId)]);
var keywordMetrics = pgTable("keyword_metrics", {
	id: serial("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	keyword: text$1("keyword").notNull(),
	locationCode: integer$1("location_code").notNull(),
	languageCode: text$1("language_code").notNull().default("en"),
	searchVolume: integer$1("search_volume"),
	cpc: real$1("cpc"),
	competition: real$1("competition"),
	keywordDifficulty: integer$1("keyword_difficulty"),
	intent: text$1("intent"),
	monthlySearches: text$1("monthly_searches"),
	fetchedAt: timestampColumn$1("fetched_at").notNull().default(isoNow$8)
}, (table) => [uniqueIndex("keyword_metrics_unique_project_keyword_location_language").on(table.projectId, table.keyword, table.locationCode, table.languageCode), index("keyword_metrics_lookup_idx").on(table.projectId, table.keyword, table.locationCode, table.languageCode, table.fetchedAt)]);
var rankTrackingConfigs = pgTable("rank_tracking_configs", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	domain: text$1("domain").notNull(),
	locationCode: integer$1("location_code").notNull().default(2840),
	languageCode: text$1("language_code").notNull().default("en"),
	devices: text$1("devices", { enum: [
		"both",
		"desktop",
		"mobile"
	] }).notNull().default("both"),
	serpDepth: integer$1("serp_depth").notNull(),
	scheduleInterval: text$1("schedule_interval", { enum: [
		"daily",
		"weekly",
		"monthly",
		"manual"
	] }).notNull().default("weekly"),
	locationName: text$1("location_name"),
	isActive: boolean("is_active").notNull().default(true),
	lastCheckedAt: timestampColumn$1("last_checked_at"),
	nextCheckAt: timestampColumn$1("next_check_at"),
	lastSkipReason: text$1("last_skip_reason"),
	createdAt: timestampColumn$1("created_at").notNull().default(isoNow$8)
}, (table) => [
	index("rank_tracking_configs_project_active_created_idx").on(table.projectId, table.isActive, table.createdAt),
	uniqueIndex("rank_tracking_configs_national_idx").on(table.projectId, table.domain, table.locationCode, table.languageCode).where(sql`${table.locationName} IS NULL`),
	uniqueIndex("rank_tracking_configs_local_idx").on(table.projectId, table.domain, table.locationCode, table.languageCode, table.locationName).where(sql`${table.locationName} IS NOT NULL`)
]);
var rankTrackingKeywords = pgTable("rank_tracking_keywords", {
	id: text$1("id").primaryKey(),
	configId: text$1("config_id").notNull().references(() => rankTrackingConfigs.id, { onDelete: "cascade" }),
	keyword: text$1("keyword").notNull(),
	matchCase: boolean("match_case").notNull().default(false),
	searchVolume: integer$1("search_volume"),
	keywordDifficulty: integer$1("keyword_difficulty"),
	cpc: real$1("cpc"),
	metricsFetchedAt: timestampColumn$1("metrics_fetched_at"),
	pinnedAt: timestampColumn$1("pinned_at"),
	createdAt: timestampColumn$1("created_at").notNull().default(isoNow$8)
}, (table) => [uniqueIndex("rank_tracking_keywords_config_keyword_idx").on(table.configId, table.keyword)]);
var rankCheckRuns = pgTable("rank_check_runs", {
	id: text$1("id").primaryKey(),
	configId: text$1("config_id").notNull().references(() => rankTrackingConfigs.id, { onDelete: "cascade" }),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	status: text$1("status", { enum: [
		"pending",
		"running",
		"completed",
		"failed"
	] }).notNull().default("pending"),
	keywordsTotal: integer$1("keywords_total").notNull().default(0),
	keywordsChecked: integer$1("keywords_checked").notNull().default(0),
	isSubsetRun: boolean("is_subset_run").notNull().default(false),
	errorMessage: text$1("error_message"),
	startedAt: timestampColumn$1("started_at").notNull().default(isoNow$8),
	completedAt: timestampColumn$1("completed_at")
}, (table) => [
	index("rank_check_runs_config_idx").on(table.configId, table.startedAt),
	index("rank_check_runs_project_idx").on(table.projectId, table.startedAt),
	uniqueIndex("rank_check_runs_one_active_per_config_idx").on(table.configId).where(sql`${table.status} IN ('pending', 'running')`)
]);
var rankSnapshots = pgTable("rank_snapshots", {
	id: serial("id").primaryKey(),
	runId: text$1("run_id").notNull().references(() => rankCheckRuns.id, { onDelete: "cascade" }),
	trackingKeywordId: text$1("tracking_keyword_id").notNull(),
	keyword: text$1("keyword").notNull(),
	device: text$1("device", { enum: ["desktop", "mobile"] }).notNull(),
	position: integer$1("position"),
	url: text$1("url"),
	serpFeatures: text$1("serp_features"),
	checkedAt: timestampColumn$1("checked_at").notNull().default(isoNow$8)
}, (table) => [index("rank_snapshots_keyword_device_idx").on(table.trackingKeywordId, table.device, table.checkedAt), uniqueIndex("rank_snapshots_run_keyword_device_idx").on(table.runId, table.trackingKeywordId, table.device)]);
var organizationActivationState = pgTable("organization_activation_state", {
	organizationId: text$1("organization_id").primaryKey().references(() => organization.id, { onDelete: "cascade" }),
	firstMcpAuthorizedAt: timestampColumn$1("first_mcp_authorized_at"),
	firstMcpToolCallAt: timestampColumn$1("first_mcp_tool_call_at"),
	updatedAt: timestampColumn$1("updated_at").notNull().default(isoNow$8)
});
var projectActivationState = pgTable("project_activation_state", {
	projectId: text$1("project_id").primaryKey().references(() => projects.id, { onDelete: "cascade" }),
	competitorResearchedAt: timestampColumn$1("competitor_step_clicked_at"),
	keywordResearchedAt: timestampColumn$1("keyword_step_clicked_at"),
	mcpCardDismissedAt: timestampColumn$1("mcp_card_dismissed_at"),
	ga4CardDismissedAt: timestampColumn$1("ga4_card_dismissed_at"),
	updatedAt: timestampColumn$1("updated_at").notNull().default(isoNow$8)
});
var backlinkSnapshots = pgTable("backlink_snapshots", {
	id: serial("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	domain: text$1("domain").notNull(),
	rank: integer$1("rank"),
	backlinks: bigint("backlinks", { mode: "number" }),
	referringDomains: bigint("referring_domains", { mode: "number" }),
	brokenBacklinks: bigint("broken_backlinks", { mode: "number" }),
	newBacklinks: bigint("new_backlinks", { mode: "number" }),
	lostBacklinks: bigint("lost_backlinks", { mode: "number" }),
	newReferringDomains: bigint("new_referring_domains", { mode: "number" }),
	lostReferringDomains: bigint("lost_referring_domains", { mode: "number" }),
	capturedAt: timestampColumn$1("captured_at").notNull().default(isoNow$8)
}, (table) => [index("backlink_snapshots_project_captured_idx").on(table.projectId, table.capturedAt)]);
var dashboardStepDismissals = pgTable("dashboard_step_dismissals", {
	userId: text$1("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	step: text$1("step").notNull()
}, (table) => [primaryKey$1({ columns: [
	table.userId,
	table.projectId,
	table.step
] }), index("dashboard_step_dismissals_project_idx").on(table.projectId)]);
var crawlerCredentials = pgTable("crawler_credentials", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	host: text$1("host").notNull(),
	provider: text$1("provider", { enum: ["shopify"] }).notNull(),
	signatureInput: text$1("signature_input").notNull(),
	signature: text$1("signature").notNull(),
	expiresAt: timestampColumn$1("expires_at"),
	createdByUserId: text$1("created_by_user_id"),
	createdAt: timestampColumn$1("created_at").notNull().default(isoNow$8)
}, (table) => [uniqueIndex("crawler_credentials_project_host_idx").on(table.projectId, table.host)]);
//#endregion
//#region src/db/pg/project-context.schema.ts
var project_context_schema_exports = /* @__PURE__ */ __exportAll({
	projectCompetitors: () => projectCompetitors,
	projectContextSections: () => projectContextSections,
	projectKeyPages: () => projectKeyPages,
	projectResearchLog: () => projectResearchLog
});
var isoNow$7 = sql`to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')`;
var projectContextSections = pgTable("project_context_sections", {
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	key: text$1("key").notNull(),
	title: text$1("title"),
	content: text$1("content").notNull(),
	updatedAt: text$1("updated_at").notNull().default(isoNow$7),
	updatedBy: text$1("updated_by", { enum: [
		"user",
		"sam",
		"mcp"
	] }).notNull()
}, (table) => [primaryKey$1({ columns: [table.projectId, table.key] })]);
var projectCompetitors = pgTable("project_competitors", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	domain: text$1("domain").notNull(),
	name: text$1("name"),
	notes: text$1("notes"),
	updatedAt: text$1("updated_at").notNull().default(isoNow$7),
	updatedBy: text$1("updated_by", { enum: [
		"user",
		"sam",
		"mcp"
	] }).notNull()
}, (table) => [uniqueIndex("project_competitors_project_domain_idx").on(table.projectId, table.domain)]);
var projectKeyPages = pgTable("project_key_pages", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	url: text$1("url").notNull(),
	role: text$1("role", { enum: [
		"hub",
		"spoke",
		"money",
		"other"
	] }).notNull(),
	topic: text$1("topic"),
	notes: text$1("notes"),
	updatedAt: text$1("updated_at").notNull().default(isoNow$7),
	updatedBy: text$1("updated_by", { enum: [
		"user",
		"sam",
		"mcp"
	] }).notNull()
}, (table) => [uniqueIndex("project_key_pages_project_url_idx").on(table.projectId, table.url)]);
var projectResearchLog = pgTable("project_research_log", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	entryDate: text$1("entry_date").notNull(),
	summary: text$1("summary").notNull(),
	createdBy: text$1("created_by", { enum: [
		"user",
		"sam",
		"mcp"
	] }).notNull(),
	createdAt: text$1("created_at").notNull().default(isoNow$7)
}, (table) => [index("project_research_log_project_date_idx").on(table.projectId, table.entryDate)]);
//#endregion
//#region src/db/pg/reports.schema.ts
var reports_schema_exports = /* @__PURE__ */ __exportAll({ reports: () => reports });
var isoNow$6 = sql`to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')`;
var reports = pgTable("reports", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	title: text$1("title").notNull(),
	summary: text$1("summary").notNull(),
	html: text$1("html").notNull(),
	skill: text$1("skill"),
	templateId: text$1("template_id"),
	createdBy: text$1("created_by").notNull(),
	createdByUserId: text$1("created_by_user_id").notNull(),
	sizeBytes: integer$1("size_bytes").notNull(),
	shareToken: text$1("share_token"),
	sharedAt: text$1("shared_at"),
	createdAt: text$1("created_at").notNull().default(isoNow$6),
	updatedAt: text$1("updated_at").notNull().default(isoNow$6)
}, (table) => [index("reports_project_updated_idx").on(table.projectId, table.updatedAt, table.id, table.sizeBytes), uniqueIndex("reports_share_token_idx").on(table.shareToken)]);
//#endregion
//#region src/db/pg/report-templates.schema.ts
var report_templates_schema_exports = /* @__PURE__ */ __exportAll({ reportTemplates: () => reportTemplates });
var isoNow$5 = sql`to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')`;
var reportTemplates = pgTable("report_templates", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	name: text$1("name").notNull(),
	description: text$1("description").notNull(),
	instructions: text$1("instructions").notNull(),
	createdBy: text$1("created_by").notNull(),
	createdByUserId: text$1("created_by_user_id").notNull(),
	createdAt: text$1("created_at").notNull().default(isoNow$5),
	updatedAt: text$1("updated_at").notNull().default(isoNow$5)
}, (table) => [uniqueIndex("report_templates_project_name_idx").on(table.projectId, table.name)]);
//#endregion
//#region src/db/pg/audit.schema.ts
var audit_schema_exports = /* @__PURE__ */ __exportAll({
	auditIssues: () => auditIssues,
	auditLighthouseResults: () => auditLighthouseResults,
	auditPages: () => auditPages,
	audits: () => audits
});
var isoNow$4 = sql`to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')`;
var timestampColumn = (name) => text$1(name);
var audits = pgTable("audits", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	startedByUserId: text$1("started_by_user_id").notNull(),
	startUrl: text$1("start_url").notNull(),
	status: text$1("status", { enum: [
		"running",
		"completed",
		"failed"
	] }).notNull().default("running"),
	workflowInstanceId: text$1("workflow_instance_id"),
	config: text$1("config").notNull().default("{}"),
	pagesCrawled: integer$1("pages_crawled").notNull().default(0),
	pagesTotal: integer$1("pages_total").notNull().default(0),
	lighthouseTotal: integer$1("lighthouse_total").notNull().default(0),
	lighthouseCompleted: integer$1("lighthouse_completed").notNull().default(0),
	lighthouseFailed: integer$1("lighthouse_failed").notNull().default(0),
	currentPhase: text$1("current_phase").default("discovery"),
	errorCode: text$1("error_code"),
	errorDetail: text$1("error_detail"),
	failedPhase: text$1("failed_phase"),
	startedAt: timestampColumn("started_at").notNull().default(isoNow$4),
	completedAt: timestampColumn("completed_at")
}, (table) => [index("audits_project_id_idx").on(table.projectId), index("audits_started_by_user_id_idx").on(table.startedByUserId)]);
var auditPages = pgTable("audit_pages", {
	id: text$1("id").primaryKey(),
	auditId: text$1("audit_id").notNull().references(() => audits.id, { onDelete: "cascade" }),
	url: text$1("url").notNull(),
	statusCode: integer$1("status_code"),
	redirectUrl: text$1("redirect_url"),
	title: text$1("title"),
	metaDescription: text$1("meta_description"),
	canonicalUrl: text$1("canonical_url"),
	robotsMeta: text$1("robots_meta"),
	ogTitle: text$1("og_title"),
	ogDescription: text$1("og_description"),
	ogImage: text$1("og_image"),
	h1Count: integer$1("h1_count").notNull().default(0),
	h2Count: integer$1("h2_count").notNull().default(0),
	h3Count: integer$1("h3_count").notNull().default(0),
	h4Count: integer$1("h4_count").notNull().default(0),
	h5Count: integer$1("h5_count").notNull().default(0),
	h6Count: integer$1("h6_count").notNull().default(0),
	wordCount: integer$1("word_count").notNull().default(0),
	imagesTotal: integer$1("images_total").notNull().default(0),
	imagesMissingAlt: integer$1("images_missing_alt").notNull().default(0),
	internalLinkCount: integer$1("internal_link_count").notNull().default(0),
	externalLinkCount: integer$1("external_link_count").notNull().default(0),
	hasStructuredData: boolean("has_structured_data").notNull().default(false),
	isIndexable: boolean("is_indexable").notNull().default(true),
	xRobotsTag: text$1("x_robots_tag"),
	headerCanonicalUrl: text$1("header_canonical_url"),
	crawlDepth: integer$1("crawl_depth"),
	inSitemap: boolean("in_sitemap").notNull().default(false),
	contentHash: text$1("content_hash"),
	fetchClass: text$1("fetch_class", { enum: PAGE_FETCH_CLASSES }).notNull().default("ok"),
	responseTimeMs: integer$1("response_time_ms")
}, (table) => [index("audit_pages_audit_url_idx").on(table.auditId, table.url)]);
var auditIssues = pgTable("audit_issues", {
	id: text$1("id").primaryKey(),
	auditId: text$1("audit_id").notNull().references(() => audits.id, { onDelete: "cascade" }),
	pageId: text$1("page_id").references(() => auditPages.id, { onDelete: "cascade" }),
	pageUrl: text$1("page_url").notNull(),
	issueType: text$1("issue_type").notNull(),
	severity: text$1("severity", { enum: [
		"critical",
		"warning",
		"info"
	] }).notNull().default("info"),
	detailsJson: text$1("details_json")
}, (table) => [index("audit_issues_audit_type_idx").on(table.auditId, table.issueType), index("audit_issues_page_id_idx").on(table.pageId)]);
var auditLighthouseResults = pgTable("audit_lighthouse_results", {
	id: text$1("id").primaryKey(),
	auditId: text$1("audit_id").notNull().references(() => audits.id, { onDelete: "cascade" }),
	pageId: text$1("page_id").notNull().references(() => auditPages.id, { onDelete: "cascade" }),
	strategy: text$1("strategy", { enum: ["mobile", "desktop"] }).notNull(),
	performanceScore: integer$1("performance_score"),
	accessibilityScore: integer$1("accessibility_score"),
	bestPracticesScore: integer$1("best_practices_score"),
	seoScore: integer$1("seo_score"),
	lcpMs: real$1("lcp_ms"),
	cls: real$1("cls"),
	inpMs: real$1("inp_ms"),
	ttfbMs: real$1("ttfb_ms"),
	errorMessage: text$1("error_message"),
	r2Key: text$1("r2_key"),
	payloadSizeBytes: integer$1("payload_size_bytes")
}, (table) => [index("audit_lighthouse_results_audit_id_idx").on(table.auditId), index("audit_lighthouse_results_page_id_idx").on(table.pageId)]);
//#endregion
//#region src/db/pg/sam.schema.ts
var sam_schema_exports = /* @__PURE__ */ __exportAll({ samSessions: () => samSessions });
var isoNow$3 = sql`to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')`;
var samSessions = pgTable("sam_sessions", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	userId: text$1("user_id").notNull().references(() => user.id, { onDelete: "cascade" }),
	title: text$1("title").notNull().default("New chat"),
	createdAt: text$1("created_at").notNull().default(isoNow$3),
	updatedAt: text$1("updated_at").notNull().default(isoNow$3),
	archivedAt: text$1("archived_at")
}, (table) => [index("sam_sessions_project_updated_idx").on(table.projectId, table.updatedAt)]);
//#endregion
//#region src/db/pg/billing.schema.ts
var billing_schema_exports = /* @__PURE__ */ __exportAll({ billingCustomerStatus: () => billingCustomerStatus });
var isoNow$2 = sql`to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')`;
var billingCustomerStatus = pgTable("billing_customer_status", {
	organizationId: text$1("organization_id").primaryKey().references(() => organization.id, { onDelete: "cascade" }),
	isPaying: boolean("is_paying").notNull().default(false),
	paidPlanId: text$1("paid_plan_id"),
	paidPlanStatus: text$1("paid_plan_status"),
	customerJson: text$1("customer_json").notNull(),
	syncedAt: text$1("synced_at").notNull(),
	createdAt: text$1("created_at").notNull().default(isoNow$2),
	updatedAt: text$1("updated_at").notNull().default(isoNow$2)
});
//#endregion
//#region src/db/pg/ga4.schema.ts
var ga4_schema_exports = /* @__PURE__ */ __exportAll({ ga4Connections: () => ga4Connections });
var isoNow$1 = sql`to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')`;
var ga4Connections = pgTable("ga4_connections", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	organizationId: text$1("organization_id").notNull().references(() => organization.id, { onDelete: "cascade" }),
	propertyId: text$1("property_id").notNull(),
	propertyDisplayName: text$1("property_display_name").notNull(),
	propertyTimeZone: text$1("property_time_zone").notNull(),
	propertyCurrencyCode: text$1("property_currency_code").notNull(),
	connectedByUserId: text$1("connected_by_user_id").notNull(),
	ga4AccountId: text$1("ga4_account_id").notNull(),
	connectedAccountEmail: text$1("connected_account_email"),
	createdAt: text$1("created_at").notNull().default(isoNow$1),
	updatedAt: text$1("updated_at").notNull().default(isoNow$1)
}, (table) => [
	uniqueIndex("ga4_connections_project_idx").on(table.projectId),
	index("ga4_connections_organization_idx").on(table.organizationId),
	index("ga4_connections_connector_idx").on(table.connectedByUserId, table.ga4AccountId)
]);
//#endregion
//#region src/db/pg/gsc.schema.ts
var gsc_schema_exports = /* @__PURE__ */ __exportAll({ gscConnections: () => gscConnections });
var isoNow = sql`to_char(now() AT TIME ZONE 'utc', 'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"')`;
var gscConnections = pgTable("gsc_connections", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	organizationId: text$1("organization_id").notNull().references(() => organization.id, { onDelete: "cascade" }),
	siteUrl: text$1("site_url").notNull(),
	connectedByUserId: text$1("connected_by_user_id").notNull(),
	gscAccountId: text$1("gsc_account_id"),
	connectedAccountEmail: text$1("connected_account_email"),
	createdAt: text$1("created_at").notNull().default(isoNow),
	updatedAt: text$1("updated_at").notNull().default(isoNow)
}, (table) => [uniqueIndex("gsc_connections_project_idx").on(table.projectId), index("gsc_connections_organization_idx").on(table.organizationId)]);
//#endregion
//#region src/db/pg/telemetry.schema.ts
var telemetry_schema_exports = /* @__PURE__ */ __exportAll({ telemetryState: () => telemetryState });
var telemetryState = pgTable("telemetry_state", {
	id: integer$1("id").primaryKey().default(1),
	installId: text$1("install_id").notNull(),
	installedAt: timestamp("installed_at", {
		mode: "date",
		withTimezone: true
	}),
	lastHeartbeatAt: timestamp("last_heartbeat_at", {
		mode: "date",
		withTimezone: true
	}),
	lastVersion: text$1("last_version"),
	mcpToolCallCount: integer$1("mcp_tool_call_count").notNull().default(0)
});
//#endregion
//#region src/db/pg/ai-visibility.schema.ts
var ai_visibility_schema_exports = /* @__PURE__ */ __exportAll({
	aiMatches: () => aiMatches,
	aiObservations: () => aiObservations,
	aiPrompts: () => aiPrompts,
	aiRuns: () => aiRuns,
	aiSources: () => aiSources,
	aiTrackers: () => aiTrackers
});
var aiTrackers = pgTable("ai_trackers", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	enabled: boolean("enabled").notNull().default(false),
	chatgpt: boolean("chatgpt").notNull().default(true),
	gemini: boolean("gemini").notNull().default(false),
	claude: boolean("claude").notNull().default(false),
	perplexity: boolean("perplexity").notNull().default(false),
	googleAiOverview: boolean("google_ai_overview").notNull().default(false),
	locationCode: integer$1("location_code").notNull().default(2840),
	languageCode: text$1("language_code").notNull().default("en"),
	scheduleInterval: text$1("schedule_interval", { enum: [
		"daily",
		"weekly",
		"monthly"
	] }).notNull().default("weekly"),
	nextCheckAt: text$1("next_check_at"),
	lastSkipReason: text$1("last_skip_reason"),
	createdAt: text$1("created_at").notNull()
}, (t) => [uniqueIndex("ai_trackers_project_idx").on(t.projectId), index("ai_trackers_due_idx").on(t.enabled, t.nextCheckAt)]);
var aiPrompts = pgTable("ai_prompts", {
	id: text$1("id").primaryKey(),
	trackerId: text$1("tracker_id").notNull().references(() => aiTrackers.id, { onDelete: "cascade" }),
	topic: text$1("topic").notNull(),
	text: text$1("text").notNull(),
	paused: boolean("paused").notNull().default(false),
	archived: boolean("archived").notNull().default(false),
	createdAt: text$1("created_at").notNull()
}, (t) => [index("ai_prompts_tracker_idx").on(t.trackerId)]);
var aiRuns = pgTable("ai_runs", {
	id: text$1("id").primaryKey(),
	trackerId: text$1("tracker_id").notNull().references(() => aiTrackers.id, { onDelete: "cascade" }),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	trigger: text$1("trigger", { enum: [
		"baseline",
		"scheduled",
		"manual"
	] }).notNull(),
	status: text$1("status", { enum: [
		"queued",
		"running",
		"completed",
		"partial",
		"failed"
	] }).notNull().default("queued"),
	locationCode: integer$1("location_code").notNull(),
	languageCode: text$1("language_code").notNull(),
	createdAt: text$1("created_at").notNull(),
	completedAt: text$1("completed_at")
}, (t) => [index("ai_runs_project_created_idx").on(t.projectId, t.createdAt), uniqueIndex("ai_runs_one_active_idx").on(t.trackerId).where(sql`${t.status} IN ('queued', 'running')`)]);
var aiObservations = pgTable("ai_observations", {
	id: text$1("id").primaryKey(),
	runId: text$1("run_id").notNull().references(() => aiRuns.id, { onDelete: "cascade" }),
	promptId: text$1("prompt_id").notNull().references(() => aiPrompts.id, { onDelete: "cascade" }),
	engine: text$1("engine", { enum: [
		"chatgpt",
		"gemini",
		"google_ai_overview",
		"claude",
		"perplexity"
	] }).notNull(),
	branded: boolean("branded").notNull(),
	status: text$1("status", { enum: [
		"pending",
		"completed",
		"failed"
	] }).notNull().default("pending"),
	collectedAt: text$1("collected_at"),
	answerMarkdown: text$1("answer_markdown"),
	error: text$1("error")
}, (t) => [uniqueIndex("ai_observations_run_prompt_engine_idx").on(t.runId, t.promptId, t.engine), index("ai_observations_prompt_idx").on(t.promptId)]);
var aiSources = pgTable("ai_sources", {
	id: text$1("id").primaryKey(),
	observationId: text$1("observation_id").notNull().references(() => aiObservations.id, { onDelete: "cascade" }),
	url: text$1("url").notNull(),
	domain: text$1("domain").notNull(),
	title: text$1("title"),
	position: integer$1("position").notNull()
}, (t) => [index("ai_sources_observation_idx").on(t.observationId)]);
var aiMatches = pgTable("ai_matches", {
	id: text$1("id").primaryKey(),
	observationId: text$1("observation_id").notNull().references(() => aiObservations.id, { onDelete: "cascade" }),
	name: text$1("name").notNull(),
	domain: text$1("domain").notNull(),
	own: boolean("own").notNull(),
	mentioned: boolean("mentioned").notNull(),
	cited: boolean("cited").notNull(),
	firstMention: integer$1("first_mention")
}, (t) => [uniqueIndex("ai_matches_observation_domain_idx").on(t.observationId, t.domain)]);
//#endregion
//#region src/db/pg/local-seo.schema.ts
var local_seo_schema_exports = /* @__PURE__ */ __exportAll({
	localRankBusinesses: () => localRankBusinesses,
	localRankChecks: () => localRankChecks,
	localRankKeywords: () => localRankKeywords,
	localRankPoints: () => localRankPoints,
	localRankResults: () => localRankResults,
	localRankScans: () => localRankScans,
	localRankTrackers: () => localRankTrackers
});
var localRankTrackers = pgTable("local_rank_trackers", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	title: text$1("title").notNull(),
	address: text$1("address"),
	cid: text$1("cid"),
	placeId: text$1("place_id"),
	latitude: doublePrecision("latitude").notNull(),
	longitude: doublePrecision("longitude").notNull(),
	gridSize: integer$1("grid_size").notNull(),
	spacingKm: doublePrecision("spacing_km").notNull(),
	languageCode: text$1("language_code").notNull(),
	createdAt: text$1("created_at").notNull()
}, (t) => [index("local_rank_trackers_project_idx").on(t.projectId)]);
var localRankKeywords = pgTable("local_rank_keywords", {
	id: text$1("id").primaryKey(),
	trackerId: text$1("tracker_id").notNull().references(() => localRankTrackers.id, { onDelete: "cascade" }),
	keyword: text$1("keyword").notNull(),
	archivedAt: text$1("archived_at")
}, (t) => [uniqueIndex("local_rank_keywords_tracker_keyword_idx").on(t.trackerId, t.keyword)]);
var localRankChecks = pgTable("local_rank_checks", {
	id: text$1("id").primaryKey(),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	trackerId: text$1("tracker_id").notNull().references(() => localRankTrackers.id, { onDelete: "cascade" }),
	status: text$1("status", { enum: [
		LocalScanStatus.Queued,
		LocalScanStatus.Running,
		LocalScanStatus.Completed,
		LocalScanStatus.Partial,
		LocalScanStatus.Failed
	] }).notNull(),
	error: text$1("error"),
	createdAt: text$1("created_at").notNull(),
	completedAt: text$1("completed_at")
}, (t) => [index("local_rank_checks_tracker_created_idx").on(t.trackerId, t.createdAt), uniqueIndex("local_rank_checks_one_active_idx").on(t.trackerId).where(sql`${t.status} IN ('queued', 'running')`)]);
var localRankScans = pgTable("local_rank_scans", {
	id: text$1("id").primaryKey(),
	checkId: text$1("check_id").notNull().references(() => localRankChecks.id, { onDelete: "cascade" }),
	projectId: text$1("project_id").notNull().references(() => projects.id, { onDelete: "cascade" }),
	trackerId: text$1("tracker_id").notNull().references(() => localRankTrackers.id, { onDelete: "cascade" }),
	keywordId: text$1("keyword_id").notNull().references(() => localRankKeywords.id, { onDelete: "cascade" }),
	status: text$1("status", { enum: [
		LocalScanStatus.Queued,
		LocalScanStatus.Running,
		LocalScanStatus.Completed,
		LocalScanStatus.Partial,
		LocalScanStatus.Failed
	] }).notNull(),
	error: text$1("error"),
	createdAt: text$1("created_at").notNull(),
	completedAt: text$1("completed_at")
}, (t) => [
	index("local_rank_scans_tracker_created_idx").on(t.trackerId, t.createdAt),
	index("local_rank_scans_project_idx").on(t.projectId),
	uniqueIndex("local_rank_scans_check_keyword_idx").on(t.checkId, t.keywordId)
]);
var localRankPoints = pgTable("local_rank_points", {
	id: text$1("id").primaryKey(),
	scanId: text$1("scan_id").notNull().references(() => localRankScans.id, { onDelete: "cascade" }),
	row: integer$1("row").notNull(),
	col: integer$1("col").notNull(),
	latitude: doublePrecision("latitude").notNull(),
	longitude: doublePrecision("longitude").notNull(),
	status: text$1("status", { enum: [
		LocalPointStatus.Pending,
		LocalPointStatus.Completed,
		LocalPointStatus.Failed
	] }).notNull(),
	rank: integer$1("rank"),
	resultsCount: integer$1("results_count"),
	error: text$1("error"),
	collectedAt: text$1("collected_at")
}, (t) => [uniqueIndex("local_rank_points_scan_position_idx").on(t.scanId, t.row, t.col)]);
var localRankBusinesses = pgTable("local_rank_businesses", {
	id: text$1("id").primaryKey(),
	scanId: text$1("scan_id").notNull().references(() => localRankScans.id, { onDelete: "cascade" }),
	identity: text$1("identity").notNull(),
	title: text$1("title").notNull(),
	cid: text$1("cid"),
	placeId: text$1("place_id"),
	address: text$1("address"),
	rating: doublePrecision("rating"),
	reviews: integer$1("reviews")
}, (t) => [uniqueIndex("local_rank_businesses_scan_identity_idx").on(t.scanId, t.identity)]);
var localRankResults = pgTable("local_rank_results", {
	id: text$1("id").primaryKey(),
	pointId: text$1("point_id").notNull().references(() => localRankPoints.id, { onDelete: "cascade" }),
	businessId: text$1("business_id").notNull().references(() => localRankBusinesses.id, { onDelete: "cascade" }),
	rank: integer$1("rank").notNull()
}, (t) => [uniqueIndex("local_rank_results_point_business_idx").on(t.pointId, t.businessId), index("local_rank_results_business_idx").on(t.businessId)]);
//#endregion
//#region src/db/pg/schema.ts
var schema_exports = /* @__PURE__ */ __exportAll({
	account: () => account,
	accountDeletionRequests: () => accountDeletionRequests,
	accountRelations: () => accountRelations,
	aiMatches: () => aiMatches,
	aiObservations: () => aiObservations,
	aiPrompts: () => aiPrompts,
	aiRuns: () => aiRuns,
	aiSources: () => aiSources,
	aiTrackers: () => aiTrackers,
	apikey: () => apikey,
	auditIssues: () => auditIssues,
	auditLighthouseResults: () => auditLighthouseResults,
	auditPages: () => auditPages,
	audits: () => audits,
	backlinkSnapshots: () => backlinkSnapshots,
	billingCustomerStatus: () => billingCustomerStatus,
	crawlerCredentials: () => crawlerCredentials,
	dashboardStepDismissals: () => dashboardStepDismissals,
	dataRefreshClaims: () => dataRefreshClaims,
	ga4Connections: () => ga4Connections,
	gscConnections: () => gscConnections,
	guestAccounts: () => guestAccounts,
	invitation: () => invitation,
	invitationRelations: () => invitationRelations,
	keywordMetrics: () => keywordMetrics,
	localRankBusinesses: () => localRankBusinesses,
	localRankChecks: () => localRankChecks,
	localRankKeywords: () => localRankKeywords,
	localRankPoints: () => localRankPoints,
	localRankResults: () => localRankResults,
	localRankScans: () => localRankScans,
	localRankTrackers: () => localRankTrackers,
	member: () => member,
	memberRelations: () => memberRelations,
	organization: () => organization,
	organizationActivationState: () => organizationActivationState,
	organizationRelations: () => organizationRelations,
	projectActivationState: () => projectActivationState,
	projectCompetitors: () => projectCompetitors,
	projectContextSections: () => projectContextSections,
	projectKeyPages: () => projectKeyPages,
	projectResearchLog: () => projectResearchLog,
	projects: () => projects,
	rankCheckRuns: () => rankCheckRuns,
	rankSnapshots: () => rankSnapshots,
	rankTrackingConfigs: () => rankTrackingConfigs,
	rankTrackingKeywords: () => rankTrackingKeywords,
	reportTemplates: () => reportTemplates,
	reports: () => reports,
	samSessions: () => samSessions,
	savedKeywordTagAssignments: () => savedKeywordTagAssignments,
	savedKeywordTags: () => savedKeywordTags,
	savedKeywords: () => savedKeywords,
	session: () => session,
	sessionRelations: () => sessionRelations,
	telemetryState: () => telemetryState,
	user: () => user,
	userOnboardingAnswers: () => userOnboardingAnswers,
	userRelations: () => userRelations,
	userSignupCampaigns: () => userSignupCampaigns,
	verification: () => verification
});
//#endregion
//#region src/db/pg/client.ts
function createPgDb(sql) {
	return drizzle(sql, { schema: schema_exports });
}
var pgClientStore = new AsyncLocalStorage();
var pgDb = new Proxy({}, { get(_target, prop, receiver) {
	const store = pgClientStore.getStore();
	if (!store) throw new Error("Postgres database accessed outside a request scope. Entrypoints (fetch, scheduled, workflow run) must wrap DB usage in withPgClient().");
	return Reflect.get(store.db, prop, receiver);
} });
/**
* Run `fn` with a request-scoped Postgres client in scope.
*
* - D1 mode (default): a no-op \u2014 just runs `fn` (no Postgres client created).
* - Postgres mode: creates a fresh per-request client and makes it the active
*   `pgDb` for the duration of `fn`.
*
* Wrap every entrypoint that touches the DB: the `fetch` handler, the
* `scheduled` cron, and each WorkflowEntrypoint `run`.
*
* Per Hyperdrive's guidance we use a single connection (`max: 1` \u2014 Hyperdrive
* pools the origin connections at the edge, so a client-side pool only adds
* stale-connection risk) and do NOT call `sql.end()`: the Workers\u2194Hyperdrive
* socket is torn down automatically when the invocation ends, and the pooled
* origin connection stays warm for reuse. Not ending it also means a streamed
* response can keep querying after the handler returns.
*/
async function withPgClient(fn) {
	if (getDatabaseProvider() !== "postgres") return fn();
	if (pgClientStore.getStore()) return fn();
	const sql = withQueryRetries(src_default(getPostgresConnectionString(), {
		max: 1,
		fetch_types: false,
		connect_timeout: 10
	}));
	return pgClientStore.run({
		sql,
		db: createPgDb(sql)
	}, fn);
}
//#endregion
//#region src/db/index.ts
var db_exports = /* @__PURE__ */ __exportAll({
	db: () => db,
	withPgClient: () => withPgClient
});
var db = getDatabaseProvider() === "postgres" ? pgDb : d1Db;
//#endregion
export { like as $, gsc_schema_exports$1 as A, better_auth_schema_exports$1 as B, LocalScanStatus as C, localGridZoom as D, localAreaLabel as E, PAGE_FETCH_CLASSES as F, eq as G, asc as H, report_templates_schema_exports$1 as I, gte as J, exists as K, reports_schema_exports$1 as L, billing_schema_exports$1 as M, sam_schema_exports$1 as N, ai_visibility_schema_exports$1 as O, audit_schema_exports$1 as P, isNull as Q, project_context_schema_exports$1 as R, LocalPointStatus as S, isLocalScanActive as T, desc as U, aliasedTable as V, and as W, inArray as X, ilike as Y, isNotNull as Z, app_schema_exports as _, schema_exports as a, notInArray as at, schema_exports$1 as b, telemetry_schema_exports as c, sql as ct, billing_schema_exports as d, getDatabaseProvider as dt, lt as et, sam_schema_exports as f, project_context_schema_exports as g, reports_schema_exports as h, withPgClient as i, notExists as it, ga4_schema_exports$1 as j, telemetry_schema_exports$1 as k, gsc_schema_exports as l, Column as lt, report_templates_schema_exports as m, db_exports as n, ne as nt, local_seo_schema_exports as o, or as ot, audit_schema_exports as p, gt as q, pgDb as r, not as rt, ai_visibility_schema_exports as s, getTableColumns as st, db as t, lte as tt, ga4_schema_exports as u, is as ut, better_auth_schema_exports as v, buildLocalGrid as w, local_seo_schema_exports$1 as x, d1Db as y, app_schema_exports$1 as z };
