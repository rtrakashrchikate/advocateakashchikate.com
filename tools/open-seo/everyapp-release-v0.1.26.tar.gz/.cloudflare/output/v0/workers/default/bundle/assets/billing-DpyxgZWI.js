import { r as __exportAll } from "./rolldown-runtime-oLLnCvco.js";
import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { Et as _enum, Fn as object, Jn as string, Lt as boolean, Pn as number, or as union, xn as literal } from "./schemas-BPIpYT5n.js";
import { A as autoReloadSettingsSchema, T as CHECKOUT_PLAN_IDS } from "./onboarding-drip-B7bIbv_6.js";
import { t as createSsrRpc } from "./createSsrRpc-Vp3C13VD.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
import { n as timeZoneSchema } from "./schedule-time-OuEt6tvj.js";
//#region src/serverFunctions/billing.ts
var billing_exports = /* @__PURE__ */ __exportAll({
	createBillingPortalSession: () => createBillingPortalSession,
	createPlanCheckout: () => createPlanCheckout,
	createTopUpCheckout: () => createTopUpCheckout,
	getBillingAccount: () => getBillingAccount,
	getBillingUsage: () => getBillingUsage,
	listBillingInvoices: () => listBillingInvoices,
	previewPlanUpgrade: () => previewPlanUpgrade,
	reportCheckoutStart: () => reportCheckoutStart,
	setAutoReload: () => setAutoReload,
	setInvoiceEmails: () => setInvoiceEmails,
	upgradePlan: () => upgradePlan
});
var getBillingAccount = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).handler(createSsrRpc("3e3d258ab33e0eec91eb42119fe6c8a85d60b57d03009024e754a252e2a8327d"));
var createPlanCheckout = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(object({
	planId: _enum(CHECKOUT_PLAN_IDS),
	redirectTo: string()
})).handler(createSsrRpc("ff6e27773f4508bc652f07296be52303efe6bfa7d715f5369db02274e80f5eed"));
var reportCheckoutStart = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(object({ planId: _enum(CHECKOUT_PLAN_IDS) })).handler(createSsrRpc("3992eeb732a54c016d637cd834430e610782f810ec9045432cdb3a2a10004091"));
var upgradePlanInput = object({ planId: _enum(CHECKOUT_PLAN_IDS) });
var previewPlanUpgrade = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(upgradePlanInput).handler(createSsrRpc("87159a1512adea0f10ae9e0c3b2144d065c7266c4c10b0f0b0b4aec0fefb4aa7"));
var upgradePlan = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(upgradePlanInput).handler(createSsrRpc("368cb0582bd2b9ca19cca3123a2587fd9c1628a09d94ff3740b277802ea5ebe4"));
var createTopUpCheckout = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(object({ amountUsd: number().int().min(10).max(99) })).handler(createSsrRpc("d4fa5f681d9ed59db5cb372ca40f8a9d2baf1065bb30fbd2e38355adfdced757"));
var setAutoReload = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(union([object({ enabled: literal(false) }), object({ enabled: literal(true) }).and(autoReloadSettingsSchema)])).handler(createSsrRpc("2879a9e37e8fca55f4feda24944621abd888ee1872d158129f9a4e1d88af6df7"));
var createBillingPortalSession = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(object({ returnTo: string() })).handler(createSsrRpc("036e39c9273517cfd6b61d40fd23ac5d7595b9f3e596ec0855b8ffe11dd736d3"));
var listBillingInvoices = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).handler(createSsrRpc("29af3c6e5da3cde812413ecf58c11071ecb199e52d51246f51e1752ba03d291f"));
var setInvoiceEmails = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(object({ enabled: boolean() })).handler(createSsrRpc("c288e068a5aa90edd2d6e810019e669b6439af68bf53c20745ceef6d6ecc2f8c"));
var getBillingUsage = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(object({ timezone: timeZoneSchema })).handler(createSsrRpc("aa44d614f47b3bb85e24f8a83eaae32640bf1c04cee21679aef75e33285b6694"));
//#endregion
export { getBillingUsage as a, reportCheckoutStart as c, upgradePlan as d, createTopUpCheckout as i, setAutoReload as l, createBillingPortalSession as n, listBillingInvoices as o, createPlanCheckout as r, previewPlanUpgrade as s, billing_exports as t, setInvoiceEmails as u };
