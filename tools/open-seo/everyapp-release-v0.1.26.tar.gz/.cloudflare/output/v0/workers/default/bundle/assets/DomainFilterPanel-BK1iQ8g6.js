import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as TriangleAlert } from "./triangle-alert-C9SRPVjv.js";
import { r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { t as Badge } from "./badge-B9fV075d.js";
import { t as Input } from "./input-B1cALAbz.js";
import { i as DataTableRangeFilter, n as DataTableFilterPanel, t as DataTableFilterGroup } from "./DataTableToolbar-H0nNW-WC.js";
//#region src/client/features/domain/components/DomainFilterPanel.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function DomainFilterPanel({ activeFilterCount, appliedFilters, fields, textFields, rangeFields, countConditions, maxConditions = 8, onApply, onClear, renderExtra }) {
	const appliedKey = (0, import_react.useMemo)(() => fields.map((key) => appliedFilters[key]).join("|"), [appliedFilters, fields]);
	const [draftFilters, setDraftFilters] = (0, import_react.useState)(appliedFilters);
	(0, import_react.useEffect)(() => {
		setDraftFilters(appliedFilters);
	}, [appliedKey]);
	const meta = (0, import_react.useMemo)(() => getFilterMeta({
		values: draftFilters,
		appliedFilters,
		fields,
		countConditions,
		maxConditions
	}), [
		appliedFilters,
		countConditions,
		draftFilters,
		fields,
		maxConditions
	]);
	const applyFilters = (0, import_react.useCallback)(() => {
		if (meta.overLimit) return;
		onApply(draftFilters);
	}, [
		draftFilters,
		meta.overLimit,
		onApply
	]);
	const cancelFilterEdits = (0, import_react.useCallback)(() => {
		setDraftFilters(appliedFilters);
	}, [appliedFilters]);
	const resetFilters = (0, import_react.useCallback)(() => {
		setDraftFilters((current) => {
			const next = { ...current };
			for (const key of fields) Object.assign(next, { [key]: "" });
			return next;
		});
		onClear();
	}, [fields, onClear]);
	const handleKeyDown = (event) => {
		if (event.key !== "Enter") return;
		if (event.target instanceof HTMLButtonElement) return;
		if (meta.overLimit) return;
		event.preventDefault();
		applyFilters();
	};
	const handleValueChange = (0, import_react.useCallback)((key, value) => {
		setDraftFilters((current) => ({
			...current,
			[key]: value
		}));
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFilterPanel, {
		activeCount: activeFilterCount,
		onReset: resetFilters,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-3",
			onKeyDown: handleKeyDown,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 gap-2 lg:grid-cols-2",
					children: textFields.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFilterGroup, {
						label: field.label,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "h-7",
							"aria-label": field.label,
							placeholder: field.placeholder,
							value: draftFilters[field.key],
							onChange: (event) => handleValueChange(field.key, event.target.value)
						})
					}, String(field.key)))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5",
					children: rangeFields.map((field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableRangeFilter, {
						label: field.title,
						min: {
							step: field.step,
							value: draftFilters[field.minKey],
							onChange: (event) => handleValueChange(field.minKey, event.target.value)
						},
						max: {
							step: field.step,
							value: draftFilters[field.maxKey],
							onChange: (event) => handleValueChange(field.maxKey, event.target.value)
						}
					}, String(field.minKey)))
				}),
				renderExtra ? renderExtra(draftFilters, handleValueChange) : null,
				meta.overLimit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "warning",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, {
						className: "text-foreground",
						children: [
							"Too many filter conditions (",
							meta.conditionCount,
							" of",
							" ",
							maxConditions,
							" max). Remove some terms or ranges before applying."
						]
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted-foreground tabular-nums",
							children: [
								meta.conditionCount,
								" / ",
								maxConditions,
								" conditions"
							]
						}), meta.dirtyCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							size: "sm",
							variant: "warning",
							children: [meta.dirtyCount, " unapplied"]
						}) : null]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "sm",
							onClick: cancelFilterEdits,
							disabled: !meta.isDirty,
							children: "Cancel"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							onClick: applyFilters,
							disabled: !meta.isDirty || meta.overLimit,
							title: meta.overLimit ? `This scope leaves room for at most ${maxConditions} filter conditions per request` : void 0,
							children: ["Apply filters", meta.isDirty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								size: "sm",
								variant: "secondary",
								children: meta.dirtyCount
							}) : null]
						})]
					})]
				})
			]
		})
	});
}
function getFilterMeta({ values, appliedFilters, fields, countConditions, maxConditions }) {
	const conditionCount = countConditions(values);
	const dirtyCount = fields.reduce((acc, key) => acc + (values[key].trim() !== appliedFilters[key].trim() ? 1 : 0), 0);
	return {
		conditionCount,
		dirtyCount,
		isDirty: dirtyCount > 0,
		overLimit: conditionCount > maxConditions
	};
}
//#endregion
export { DomainFilterPanel as t };
