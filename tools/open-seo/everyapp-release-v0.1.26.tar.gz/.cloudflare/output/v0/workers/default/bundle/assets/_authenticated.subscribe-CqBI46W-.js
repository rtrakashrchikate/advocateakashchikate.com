import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { C as BILLING_ROUTE, F as isMonthlyPlan } from "./onboarding-drip-B7bIbv_6.js";
import { r as useSession } from "./auth-client-DstRenkx.js";
import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { c as Skeleton, f as billingAccountQueryOptions, m as queryClient, t as QueryError } from "./QueryState-Q8BZIblk.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { n as getErrorCode, r as getStandardErrorMessage } from "./error-messages-D7nntGF_.js";
import { t as ChevronLeft } from "./chevron-left-C2BycBKd.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { n as captureClientEvent } from "./posthog-BMFJOGWd.js";
import { d as upgradePlan, s as previewPlanUpgrade } from "./billing-DpyxgZWI.js";
import { n as useCanManageBilling } from "./organizationQueries-BMLHGNAs.js";
import { n as openUpgradeCheckout } from "./checkout-BQDDJux8.js";
import { n as TIERS, r as isTier, t as Route } from "./_authenticated.subscribe-C875LLxA.js";
import { t as Badge } from "./badge-B9fV075d.js";
import { t as SUPPORT_EMAIL } from "./support-jwdBlqyi.js";
import { i as UpdateCardButton, n as PlanChangeAction } from "./PlanChange-Bb_KYLtj.js";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C8cX1CPK.js";
import { n as ToggleGroupItem, t as ToggleGroup } from "./toggle-group-ijQviuQv.js";
import { t as StatusScreen } from "./StatusScreen-amfvL7o2.js";
import { t as PlanPageAccountMenu } from "./PlanPageAccountMenu-Djgu2IRb.js";
import { n as PlanGuarantee, r as PlanOfferCard, t as PLAN_FOOTER_LINK_CLASS } from "./PlanOfferCard-lnqCbiRT.js";
//#region src/client/features/billing/AnnualPlanDialog.tsx
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AnnualPlanDialog({ open, onOpenChange, planName, annualPriceUsd, onSubscribeMonthly }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Yearly plans are set up by email for now" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					"Email ",
					SUPPORT_EMAIL,
					" and we\u2019ll move you to the ",
					planName,
					" at $",
					annualPriceUsd.toLocaleString(),
					"/year. Paying yearly in the app is coming soon."
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Want to start today? Subscribe monthly now, and when you switch we\u2019ll credit the rest of your month toward the yearly plan."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => {
						onOpenChange(false);
						onSubscribeMonthly();
					},
					children: "Subscribe monthly"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					nativeButton: false,
					render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: `mailto:${SUPPORT_EMAIL}?subject=${encodeURIComponent(`Yearly ${planName}`)}` }),
					children: "Email us"
				})] })
			]
		})
	});
}
//#endregion
//#region src/client/features/billing/UpgradePlanDialog.tsx
var usd = (amount) => `$${amount.toFixed(2)}`;
function upgradeErrorMessage(error, fallback) {
	if (getErrorCode(error) === "PAYMENT_ACTION_REQUIRED") return "Your bank needs more time or a confirmation for this charge. Check your plan on the Billing page in a minute before trying again.";
	return getStandardErrorMessage(error, fallback);
}
/**
* Confirms an upgrade with what it charges today, the credits the
* organization will have and when the plan renews. The plan starts over
* today, and credits left from the current plan carry over until then.
*/
function UpgradePlanDialog({ open, onOpenChange, offer }) {
	const navigate = useNavigate();
	const previewQuery = useQuery({
		queryKey: [
			"billing",
			"upgrade-preview",
			offer.planId
		],
		queryFn: () => previewPlanUpgrade({ data: { planId: offer.planId } }),
		enabled: open,
		staleTime: 0,
		retry: false
	});
	const mutation = useMutation({
		mutationFn: () => upgradePlan({ data: { planId: offer.planId } }),
		meta: { errorToast: false },
		onSuccess: async ({ paymentUrl }) => {
			if (paymentUrl) {
				window.location.assign(paymentUrl);
				return;
			}
			await queryClient.invalidateQueries({
				queryKey: ["billing"],
				predicate: (query) => query.queryKey[1] !== "upgrade-preview"
			});
			toast.success(`You're on the ${offer.name}`);
			navigate({ to: BILLING_ROUTE });
		}
	});
	const upgrading = mutation.isPending || mutation.isSuccess;
	const preview = previewQuery.data;
	const error = mutation.error ?? previewQuery.error;
	function handleOpenChange(next) {
		if (upgrading) return;
		if (!next) mutation.reset();
		onOpenChange(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: handleOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogTitle, { children: ["Upgrade to the ", offer.name] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Your plan starts over today. Credits you haven\u2019t used carry over until it renews." })] }),
				preview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "space-y-3 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: "Due today"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-medium tabular-nums",
								children: usd(preview.chargeUsd)
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted-foreground",
								children: "Then"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "tabular-nums",
								children: [usd(preview.renewalUsd), "/month"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between gap-4 border-t border-border pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dt", {
								className: "text-muted-foreground",
								children: [
									"Usage credits until ",
									renewalDate(preview.renewsAt),
									preview.carriedUsd > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "block text-xs tabular-nums",
										children: [
											usd(offer.monthlyCreditsUsd),
											" plan +",
											" ",
											usd(preview.carriedUsd),
											" unused"
										]
									}) : null
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "font-medium tabular-nums",
								children: usd(offer.monthlyCreditsUsd + preview.carriedUsd)
							})]
						})
					]
				}) : previewQuery.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					"aria-busy": true,
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-5 w-full" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-5 w-full" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-5 w-2/3" })
					]
				}) : null,
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						role: "alert",
						className: "text-sm text-destructive",
						children: upgradeErrorMessage(error, mutation.error ? "We couldn't upgrade your plan. Please try again." : "We couldn't work out the price of this upgrade. Please try again.")
					}), getErrorCode(error) === "PAYMENT_METHOD_REQUIRED" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpdateCardButton, {}) : null]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					disabled: upgrading,
					onClick: () => handleOpenChange(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					pending: upgrading,
					disabled: !preview || upgrading,
					onClick: () => mutation.mutate(),
					children: preview ? `Pay ${usd(preview.chargeUsd)} and upgrade` : "Upgrade"
				})] })
			]
		})
	});
}
function renewalDate(at) {
	return new Date(at).toLocaleDateString(void 0, {
		month: "short",
		day: "numeric"
	});
}
//#endregion
//#region src/client/features/billing/route-state.ts
function getSubscribeRouteState(args) {
	if (args.isCustomerLoading) return "loading";
	if (args.checkoutCompleted && args.finalizingTimedOut) return "redirectToApp";
	if (args.isCustomerError && !args.checkoutCompleted && !args.hasCustomerData) return "error";
	if (args.planStatus === "paid") return args.isPlanChange && !args.checkoutCompleted ? "changePlan" : "redirectToApp";
	if (args.checkoutCompleted) return "finalizing";
	if (args.hasManagedAccess && !args.isUpgradeFlow) return "redirectToApp";
	return "showPaywall";
}
//#endregion
//#region src/routes/_authenticated.subscribe.tsx?tsr-split=component
var FINALIZING_TIMEOUT_MS = 3e4;
var FINALIZING_POLL_MS = 1e3;
var PERIOD_ITEM_CLASS = "h-8 gap-2 rounded-md! px-3 text-muted-foreground hover:bg-transparent aria-pressed:bg-card aria-pressed:text-foreground aria-pressed:shadow-sm";
function SubscribePage() {
	const navigate = useNavigate();
	const { upgrade: isUpgradeFlow, redirect, checkout, plan: requestedPlan, billing } = Route.useSearch();
	const { data: session } = useSession();
	const [attachingPlan, setAttachingPlan] = (0, import_react.useState)(null);
	const [yearly, setYearly] = (0, import_react.useState)(billing === "yearly");
	const [annualPlan, setAnnualPlan] = (0, import_react.useState)("base");
	const [annualDialogOpen, setAnnualDialogOpen] = (0, import_react.useState)(false);
	const [upgradeTier, setUpgradeTier] = (0, import_react.useState)("pro");
	const [upgradeDialogOpen, setUpgradeDialogOpen] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(null);
	const [finalizingTimedOut, setFinalizingTimedOut] = (0, import_react.useState)(false);
	const checkoutCompleted = checkout === "success";
	const accountQuery = useQuery({
		...billingAccountQueryOptions(),
		refetchInterval: (query) => checkoutCompleted && !finalizingTimedOut && query.state.data?.planStatus !== "paid" ? FINALIZING_POLL_MS : false
	});
	const account = accountQuery.data;
	const paidPlanId = account?.paidPlanId ?? null;
	const paidPlanName = account?.paidPlanName ?? null;
	const canManageBilling = useCanManageBilling();
	const subscribeRouteState = getSubscribeRouteState({
		isCustomerLoading: accountQuery.isPending,
		isCustomerError: accountQuery.isError,
		hasCustomerData: account !== void 0,
		hasManagedAccess: account?.hasManagedAccess ?? false,
		planStatus: account?.planStatus ?? "free",
		isUpgradeFlow: isUpgradeFlow === true,
		isPlanChange: isMonthlyPlan(paidPlanId) && (isUpgradeFlow === true || requestedPlan !== void 0),
		checkoutCompleted,
		finalizingTimedOut
	});
	const isChangingPlan = subscribeRouteState === "changePlan";
	const highlightedPlan = requestedPlan ?? (isChangingPlan ? null : "base");
	(0, import_react.useEffect)(() => {
		if (!checkoutCompleted || finalizingTimedOut) return;
		const timeout = setTimeout(() => setFinalizingTimedOut(true), FINALIZING_TIMEOUT_MS);
		return () => clearTimeout(timeout);
	}, [checkoutCompleted, finalizingTimedOut]);
	(0, import_react.useEffect)(() => {
		if (subscribeRouteState === "redirectToApp") {
			if (checkoutCompleted) captureClientEvent("billing:checkout_success");
			else if (requestedPlan && paidPlanId) {
				const wanted = TIERS[requestedPlan].offer;
				toast.info(paidPlanId === wanted.planId ? `You're already on the ${wanted.name}` : `You're on the ${paidPlanName}`, {
					id: "subscribe-plan-switch",
					description: paidPlanId === wanted.planId ? void 0 : `To switch to the ${wanted.name}, email ${SUPPORT_EMAIL}.`,
					duration: 1e4
				});
			}
			navigate({
				href: redirect ?? "/",
				replace: true
			});
		}
	}, [
		checkoutCompleted,
		navigate,
		paidPlanId,
		paidPlanName,
		redirect,
		requestedPlan,
		subscribeRouteState
	]);
	(0, import_react.useEffect)(() => {
		if (subscribeRouteState === "showPaywall" && !isUpgradeFlow) captureClientEvent("billing:paywall_viewed");
	}, [isUpgradeFlow, subscribeRouteState]);
	if (subscribeRouteState === "loading" || subscribeRouteState === "redirectToApp") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, { pending: true });
	if (subscribeRouteState === "finalizing") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, {
		logo: true,
		size: "sm",
		title: "Finalizing your subscription\u2026",
		pending: true,
		description: "This usually takes a few seconds.",
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			"Taking longer?",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
				className: "underline underline-offset-2 hover:text-foreground",
				href: `mailto:${SUPPORT_EMAIL}`,
				children: ["Email ", SUPPORT_EMAIL]
			}),
			"."
		] })
	});
	if (subscribeRouteState === "error") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusScreen, {
		logo: true,
		title: "Billing unavailable",
		size: "sm",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
			cause: accountQuery.error,
			fallback: "We couldn't verify your billing status right now. Please try again.",
			onRetry: () => void accountQuery.refetch(),
			isRetrying: accountQuery.isFetching
		})
	});
	async function handleSubscribe(tier) {
		setError(null);
		setAttachingPlan(tier);
		try {
			await openUpgradeCheckout(TIERS[tier].offer.planId);
		} catch (err) {
			setError(getStandardErrorMessage(err, "We couldn't start the checkout. Please try again."));
			setAttachingPlan(null);
		}
	}
	function openAnnualDialog(tier) {
		setAnnualPlan(tier);
		setAnnualDialogOpen(true);
		captureClientEvent("billing:annual_plan_interest", { planId: TIERS[tier].offer.planId });
	}
	const firstName = session?.user?.name?.split(" ")[0] || "";
	const annual = TIERS[annualPlan];
	const showYearly = yearly && !isChangingPlan;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-5xl space-y-8 pt-12 pb-4",
		children: [
			isUpgradeFlow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed top-4 left-4 z-20",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					onClick: () => void navigate({
						to: "/",
						replace: true
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, {}), "Back to app"]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanPageAccountMenu, { email: session?.user?.email }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-md space-y-2 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/transparent-logo.png",
							alt: "OpenSEO",
							className: "mx-auto mb-4 size-10 rounded-lg"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-2xl font-semibold tracking-tight",
							children: isChangingPlan ? "Change your plan" : isUpgradeFlow ? "Upgrade your plan" : firstName ? `Welcome to OpenSEO, ${firstName}!` : "Welcome to OpenSEO!"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-balance text-muted-foreground",
							children: "SEO on your terms. All your SEO tools in one place at a fair price."
						})
					]
				}), isChangingPlan ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToggleGroup, {
					spacing: 0,
					value: [yearly ? "yearly" : "monthly"],
					onValueChange: (next) => {
						if (next[0]) setYearly(next[0] === "yearly");
					},
					className: "mx-auto rounded-lg bg-foreground/[0.06] p-1",
					"aria-label": "Billing period",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleGroupItem, {
						value: "monthly",
						className: PERIOD_ITEM_CLASS,
						children: "Monthly"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(ToggleGroupItem, {
						value: "yearly",
						className: PERIOD_ITEM_CLASS,
						children: ["Yearly", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "soft",
							children: "2 months free"
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 md:grid-cols-3",
				children: Object.keys(TIERS).filter(isTier).map((tier) => {
					const { offer, annualPriceUsd, description, features } = TIERS[tier];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanOfferCard, {
						offer,
						description,
						priceUsd: showYearly ? annualPriceUsd : offer.priceUsd,
						period: showYearly ? "year" : "month",
						features,
						highlighted: tier === highlightedPlan,
						children: !canManageBilling ? null : isChangingPlan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanChangeAction, {
							offer,
							currentPlanId: paidPlanId,
							highlighted: tier === highlightedPlan,
							onUpgrade: () => {
								setUpgradeTier(tier);
								setUpgradeDialogOpen(true);
							}
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							variant: tier === highlightedPlan ? "default" : "outline",
							pending: attachingPlan === tier,
							disabled: attachingPlan !== null,
							onClick: () => yearly ? openAnnualDialog(tier) : void handleSubscribe(tier),
							children: attachingPlan === tier ? "Redirecting..." : "Subscribe"
						})
					}, tier);
				})
			}),
			error || !canManageBilling ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-md space-y-2 text-center text-sm",
				children: [error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "alert",
					className: "text-destructive",
					children: error
				}) : null, canManageBilling ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted-foreground",
					children: isChangingPlan ? "Only the organization owner can change the plan. Ask them if you need a bigger one." : "Only the organization owner can subscribe. Ask them to upgrade this organization."
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlanGuarantee, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex flex-wrap items-center justify-center gap-x-2 gap-y-1 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							className: PLAN_FOOTER_LINK_CLASS,
							href: "https://openseo.so/pricing",
							target: "_blank",
							rel: "noreferrer",
							onClick: () => captureClientEvent("billing:pricing_estimator_click"),
							children: ["How far do usage credits go? ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								"aria-hidden": "true",
								children: "\u2197"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							"aria-hidden": "true",
							children: "\u00B7"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Questions? Email",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								className: PLAN_FOOTER_LINK_CLASS,
								href: `mailto:${SUPPORT_EMAIL}`,
								children: SUPPORT_EMAIL
							}),
							"."
						] })
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnnualPlanDialog, {
				open: annualDialogOpen,
				onOpenChange: setAnnualDialogOpen,
				planName: annual.offer.name,
				annualPriceUsd: annual.annualPriceUsd,
				onSubscribeMonthly: () => void handleSubscribe(annualPlan)
			}),
			isChangingPlan ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UpgradePlanDialog, {
				open: upgradeDialogOpen,
				onOpenChange: setUpgradeDialogOpen,
				offer: TIERS[upgradeTier].offer
			}) : null
		]
	});
}
//#endregion
export { SubscribePage as component };
