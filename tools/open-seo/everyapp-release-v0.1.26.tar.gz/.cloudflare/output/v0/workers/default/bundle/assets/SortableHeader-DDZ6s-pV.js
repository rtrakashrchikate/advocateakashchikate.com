import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { n as createLucideIcon } from "./dist-fVOGIv0D.js";
import { t as ArrowUp } from "./arrow-up-zHO4rX22.js";
import { n as TooltipContent, r as TooltipTrigger, t as Tooltip } from "./tooltip-D5ss-ZNP.js";
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ArrowDown = createLucideIcon("arrow-down", [["path", {
	d: "M12 5v14",
	key: "s699le"
}], ["path", {
	d: "m19 12-7 7-7-7",
	key: "1idqje"
}]]);
//#endregion
//#region src/client/components/HelpLabel.tsx
var import_jsx_runtime = require_jsx_runtime();
/**
* A label with a help tooltip, for table headers and stat labels. The trigger
* is a span, so it can sit inside a sort button.
*/
function HelpLabel({ label, helpText }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		delay: 150,
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
		children: label
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, { children: helpText })] });
}
//#endregion
//#region src/client/components/table/SortableHeader.tsx
function SortableHeader({ column, label, helpText, title, align, className }) {
	const sorted = column.getIsSorted();
	const content = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: `inline-flex items-center gap-1 font-medium transition-colors hover:text-foreground ${className ?? ""}`,
		onClick: column.getToggleSortingHandler(),
		title,
		"aria-label": `Sort by ${label}`,
		"aria-pressed": !!sorted,
		children: [helpText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HelpLabel, {
			label,
			helpText
		}) : label, sorted === "asc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "size-3 shrink-0" }) : sorted === "desc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "size-3 shrink-0" }) : null]
	});
	if (align === "right") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "flex w-full justify-end",
		children: content
	});
	return content;
}
//#endregion
export { HelpLabel as n, SortableHeader as t };
