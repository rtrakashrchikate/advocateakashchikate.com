//#region src/lib/oauth-resource.ts
var MCP_RESOURCE_PATH = "/mcp";
var MCP_OAUTH_SCOPES = ["offline_access", "mcp"];
function getMcpResource(baseUrl) {
	return new URL(MCP_RESOURCE_PATH, baseUrl).toString();
}
//#endregion
export { getMcpResource as n, MCP_OAUTH_SCOPES as t };
