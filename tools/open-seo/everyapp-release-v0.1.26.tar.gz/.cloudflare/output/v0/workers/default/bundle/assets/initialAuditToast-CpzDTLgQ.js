import { r as getStandardErrorMessage } from "./error-messages-D7nntGF_.js";
import { t as toast } from "./dist-DVm-Qvek.js";
//#region src/client/features/projects/initialAuditToast.ts
/** Tells the user whether saving a website started its first site scan. */
function toastInitialAudit(initialAudit) {
	if (initialAudit?.status === "unavailable") toast.warning("Website saved. The first scan could not start.", { description: getStandardErrorMessage(new Error(initialAudit.code)) });
	else if (initialAudit?.status === "started") toast.success("Your 50-page site scan is running");
}
//#endregion
export { toastInitialAudit as t };
