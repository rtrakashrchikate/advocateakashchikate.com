import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { a as o$2, i as i$3, r as e$2, t as initWasm } from "./wasm-init-DzwbPAKW-Bo6eiF7F.js";
import { r as domainField } from "./domain-BDAqKQBz.js";
import module from "./takumi_wasm_bg-BZcERD8P.wasm";
//#region node_modules/.pnpm/@takumi-rs+helpers@2.13.7_preact@10.29.3_react@19.2.4/node_modules/@takumi-rs/helpers/dist/helpers-CVQCT1Rh.mjs
function e$1(e, t) {
	t && Object.keys(t).length > 0 && (e.style = t);
}
function t$1(e, t) {
	t && Object.keys(t).length > 0 && (e.preset = t);
}
function n$1(e, t) {
	t.tagName !== void 0 && (e.tagName = t.tagName), t.className !== void 0 && (e.className = t.className), t.id !== void 0 && (e.id = t.id), t.dir !== void 0 && (e.dir = t.dir), t.lang !== void 0 && (e.lang = t.lang), t.attributes !== void 0 && (e.attributes = t.attributes);
}
function r$2(r) {
	let i = {
		type: `container`,
		children: r.children
	};
	return r.tw && (i.tw = r.tw), n$1(i, r), t$1(i, r.preset), e$1(i, r.style), i;
}
function i$2(r, i) {
	if (typeof r == `string`) {
		let t = {
			type: `text`,
			text: r
		};
		return e$1(t, i), t;
	}
	let a = {
		type: `text`,
		text: r.text
	};
	return r.tw && (a.tw = r.tw), n$1(a, r), t$1(a, r.preset), e$1(a, i ?? r.style), a;
}
function a$2(r) {
	let i = {
		type: `image`,
		src: r.src,
		width: r.width,
		height: r.height
	};
	return r.tw && (i.tw = r.tw), n$1(i, r), t$1(i, r.preset), e$1(i, r.style), i;
}
function s$2(e) {
	return `${e}%`;
}
//#endregion
//#region node_modules/.pnpm/@takumi-rs+helpers@2.13.7_preact@10.29.3_react@19.2.4/node_modules/@takumi-rs/helpers/dist/emoji.mjs
var r$1 = /\uFE0F/g;
var i$1 = /^\p{Extended_Pictographic}/u;
var a$1 = /^\p{Emoji_Presentation}/u;
var o$1 = /^\p{Emoji_Modifier_Base}\p{Emoji_Modifier}/u;
var s$1 = /^(?:\p{Regional_Indicator}){1,2}$/u;
var c$1 = /^[#*0-9]\uFE0F?\u20E3$/u;
function l$2(e) {
	return [...e.indexOf(`\u200D`) < 0 ? e.replace(r$1, ``) : e].map((e) => e.codePointAt(0)?.toString(16)).join(`-`);
}
var u$2 = {
	twemoji: (e) => `https://cdn.jsdelivr.net/gh/jdecked/twemoji@17.0.2/assets/svg/${e.toLowerCase()}.svg`,
	openmoji: `https://cdn.jsdelivr.net/npm/@svgmoji/openmoji@2.0.0/svg/`,
	blobmoji: `https://cdn.jsdelivr.net/npm/@svgmoji/blob@2.0.0/svg/`,
	noto: (e) => `https://cdn.jsdelivr.net/gh/googlefonts/noto-emoji@v2.051/svg/emoji_u${e.toLowerCase().replaceAll(`-`, `_`)}.svg`,
	fluent: (e) => `https://cdn.jsdelivr.net/gh/shuding/fluentui-emoji-unicode/assets/${e.toLowerCase()}_color.svg`,
	fluentFlat: (e) => `https://cdn.jsdelivr.net/gh/shuding/fluentui-emoji-unicode/assets/${e.toLowerCase()}_flat.svg`
};
function d$2(e, t) {
	let n = l$2(e), r = u$2[t];
	return typeof r == `function` ? r(n) : `${r}${n.toUpperCase()}.svg`;
}
var f$2 = new Intl.Segmenter(`en`, { granularity: `grapheme` });
function p$2(e) {
	return Array.from(f$2.segment(e));
}
function m$2(e) {
	return e.includes(`\uFE0E`) ? !1 : s$1.test(e) || c$1.test(e) ? !0 : i$1.test(e) && (e.includes(`\uFE0F`) || e.includes(`\u200D`) || a$1.test(e) || o$1.test(e));
}
function h$2(n, r) {
	let i = [], a = ``, o = p$2(n.text);
	for (let { segment: n } of o) m$2(n) ? (a &&= (i.push(i$2({ text: a })), ``), i.push(a$2({
		src: d$2(n, r),
		style: {
			display: `inline-block`,
			width: `1em`,
			height: `1em`,
			margin: `0 0.05em 0 0.1em`,
			verticalAlign: `-0.1em`
		}
	}))) : a += n;
	return a && i.push(i$2({ text: a })), i;
}
function g$2(e, t) {
	if (e.type === `text`) {
		if (p$2(e.text).some(({ segment: e }) => m$2(e))) {
			let { type: r, ...i } = e;
			return r$2({
				...i,
				children: h$2(e, t)
			});
		}
	} else if (e.type === `container` && e.children) return {
		...e,
		children: e.children.map((e) => e && g$2(e, t))
	};
	return e;
}
//#endregion
//#region node_modules/.pnpm/@takumi-rs+helpers@2.13.7_preact@10.29.3_react@19.2.4/node_modules/@takumi-rs/helpers/dist/index.mjs
var b$2 = /url\(\s*(['"]?)(.*?)\1\s*\)/g;
function x$2(e) {
	return e.startsWith(`https://`) || e.startsWith(`http://`);
}
function S$2(e, t) {
	if (typeof e == `string`) for (let n of e.matchAll(b$2)) {
		let e = n[2]?.trim();
		e && x$2(e) && t.add(e);
	}
	else if (Array.isArray(e)) for (let n of e) S$2(n, t);
}
function C$2(e) {
	let t = /* @__PURE__ */ new Set(), n = (e) => {
		let r = (e) => {
			e && (S$2(e.backgroundImage, t), S$2(e.maskImage, t), S$2(e.listStyleImage, t));
		};
		if (r(e.style), r(e.preset), S$2(e.tw, t), e.type === `image`) {
			typeof e.src == `string` && x$2(e.src) && t.add(e.src);
			return;
		}
		if (e.type === `container`) for (let t of e.children ?? []) n(t);
	};
	return n(e), [...t];
}
function w$2(e, n, i) {
	let a = n.maxBytes ?? 33554432, { allowUrl: o } = n, c = i?.get(e);
	if (c) return new e$2(n).waitFor(c).then((t) => {
		if (o && !o(e)) throw Error(`URL blocked by allowUrl policy: ${e}`);
		if (t.byteLength > a) throw Error(`Response exceeds ${a} bytes`);
		return t;
	});
	let l = i$3(e, n).then((e) => o$2(e, a)).catch((t) => {
		throw i?.delete(e), t;
	});
	return i?.set(e, l), l;
}
async function T$2({ node: e, sources: t = [], fetchCache: n, fetch: r, timeout: i, signal: a, maxBytes: o, allowUrl: s, throwOnError: c = !0 }) {
	let l = Array.isArray(e) ? e : [e], u = /* @__PURE__ */ new Map();
	for (let e of t) u.set(e.src, e);
	let d = [...new Set(l.flatMap(C$2))].filter((e) => !u.has(e)), f = {
		fetch: r,
		timeout: i,
		signal: a,
		maxBytes: o,
		allowUrl: s
	}, p = d.map(async (e) => ({
		src: e,
		data: await w$2(e, f, n)
	})), m = c ? await Promise.all(p) : (await Promise.allSettled(p)).filter((e) => e.status === `fulfilled`).map((e) => e.value);
	return [...u.values(), ...m];
}
//#endregion
//#region node_modules/.pnpm/@takumi-rs+helpers@2.13.7_preact@10.29.3_react@19.2.4/node_modules/@takumi-rs/helpers/dist/utils-4GQubbLq.mjs
var e = {
	html: { display: `block` },
	head: { display: `none` },
	meta: { display: `none` },
	title: { display: `none` },
	link: { display: `none` },
	style: { display: `none` },
	script: { display: `none` },
	noscript: { display: `none` },
	datalist: { display: `none` },
	template: { display: `none` },
	body: {
		margin: 8,
		display: `block`
	},
	p: {
		marginTop: `1em`,
		marginBottom: `1em`,
		display: `block`
	},
	blockquote: {
		marginTop: `1em`,
		marginBottom: `1em`,
		marginLeft: 40,
		marginRight: 40,
		display: `block`
	},
	figure: {
		marginTop: `1em`,
		marginBottom: `1em`,
		marginLeft: 40,
		marginRight: 40,
		display: `block`
	},
	figcaption: { display: `block` },
	address: {
		fontStyle: `italic`,
		display: `block`
	},
	article: { display: `block` },
	aside: { display: `block` },
	footer: { display: `block` },
	header: { display: `block` },
	hgroup: { display: `block` },
	main: { display: `block` },
	nav: { display: `block` },
	section: { display: `block` },
	center: {
		textAlign: `center`,
		display: `block`
	},
	hr: {
		marginTop: `0.5em`,
		marginBottom: `0.5em`,
		marginLeft: `auto`,
		marginRight: `auto`,
		borderWidth: 1,
		display: `block`
	},
	ul: {
		marginTop: `1em`,
		marginBottom: `1em`,
		paddingInlineStart: 40,
		display: `block`,
		listStyleType: `disc`
	},
	ol: {
		marginTop: `1em`,
		marginBottom: `1em`,
		paddingInlineStart: 40,
		display: `block`,
		listStyleType: `decimal`
	},
	menu: {
		marginTop: `1em`,
		marginBottom: `1em`,
		paddingInlineStart: 40,
		display: `block`,
		listStyleType: `disc`
	},
	li: { display: `list-item` },
	dl: {
		marginTop: `1em`,
		marginBottom: `1em`,
		display: `block`
	},
	dt: { display: `block` },
	dd: {
		marginLeft: 40,
		display: `block`
	},
	form: { display: `block` },
	fieldset: {
		marginLeft: 2,
		marginRight: 2,
		paddingTop: `0.35em`,
		paddingRight: `0.75em`,
		paddingBottom: `0.625em`,
		paddingLeft: `0.75em`,
		borderWidth: 2,
		display: `block`
	},
	legend: {
		paddingLeft: 2,
		paddingRight: 2,
		display: `block`
	},
	details: { display: `block` },
	summary: { display: `block` },
	search: { display: `block` },
	h1: {
		fontSize: `2em`,
		marginTop: `0.67em`,
		marginBottom: `0.67em`,
		marginLeft: 0,
		marginRight: 0,
		fontWeight: `bold`,
		display: `block`
	},
	h2: {
		fontSize: `1.5em`,
		marginTop: `0.83em`,
		marginBottom: `0.83em`,
		marginLeft: 0,
		marginRight: 0,
		fontWeight: `bold`,
		display: `block`
	},
	h3: {
		fontSize: `1.17em`,
		marginTop: `1em`,
		marginBottom: `1em`,
		marginLeft: 0,
		marginRight: 0,
		fontWeight: `bold`,
		display: `block`
	},
	h4: {
		marginTop: `1.33em`,
		marginBottom: `1.33em`,
		marginLeft: 0,
		marginRight: 0,
		fontWeight: `bold`,
		display: `block`
	},
	h5: {
		fontSize: `0.83em`,
		marginTop: `1.67em`,
		marginBottom: `1.67em`,
		marginLeft: 0,
		marginRight: 0,
		fontWeight: `bold`,
		display: `block`
	},
	h6: {
		fontSize: `0.67em`,
		marginTop: `2.33em`,
		marginBottom: `2.33em`,
		marginLeft: 0,
		marginRight: 0,
		fontWeight: `bold`,
		display: `block`
	},
	u: { textDecoration: `underline` },
	ins: { textDecoration: `underline` },
	strong: { fontWeight: `bolder` },
	b: { fontWeight: `bolder` },
	i: { fontStyle: `italic` },
	em: { fontStyle: `italic` },
	cite: { fontStyle: `italic` },
	dfn: { fontStyle: `italic` },
	code: { fontFamily: `monospace` },
	kbd: { fontFamily: `monospace` },
	samp: { fontFamily: `monospace` },
	pre: {
		fontFamily: `monospace`,
		whiteSpace: `pre`,
		margin: `1em 0`,
		display: `block`
	},
	br: { whiteSpace: `pre` },
	mark: {
		backgroundColor: `yellow`,
		color: `black`
	},
	big: { fontSize: `larger` },
	small: { fontSize: `smaller` },
	s: { textDecoration: `line-through` },
	del: { textDecoration: `line-through` },
	sub: {
		fontSize: `smaller`,
		verticalAlign: `sub`
	},
	sup: {
		fontSize: `smaller`,
		verticalAlign: `super`
	},
	div: { display: `block` },
	table: {
		display: `table`,
		boxSizing: `border-box`,
		borderSpacing: `2px`
	},
	thead: { display: `table-header-group` },
	tbody: { display: `table-row-group` },
	tfoot: { display: `table-footer-group` },
	tr: { display: `table-row` },
	td: {
		display: `table-cell`,
		padding: 1
	},
	th: {
		display: `table-cell`,
		padding: 1,
		fontWeight: `bold`,
		textAlign: `center`
	},
	caption: {
		display: `table-caption`,
		textAlign: `center`
	}
};
function t(t) {
	if (t !== !1) return t ?? e;
}
function n(e, t) {
	let n;
	for (let r in e) {
		if (!Object.hasOwn(e, r)) continue;
		let i = e[r];
		r !== `children` && r !== `className` && r !== `class` && r !== `id` && r !== `style` && r !== t && r !== `ref` && r !== `key` && r !== `dangerouslySetInnerHTML` && r !== `suppressHydrationWarning` && i != null && i !== !1 && typeof i != `function` && typeof i != `symbol` && typeof i != `object` && (n ??= {}, n[r] = i === !0 ? `` : String(i));
	}
	return n;
}
var r = !1;
function i(e) {
	Object.defineProperty(e, "stylesheets", { enumerable: !1 });
}
function a() {
	r || (r = !0, console.warn("takumi: the `stylesheets` result field is deprecated, use `css` instead."));
}
var o = /* @__PURE__ */ new Set([
	`head`,
	`meta`,
	`link`,
	`style`,
	`script`
]);
function s(e) {
	return o.has(e);
}
function c(e, t) {
	return e.type === t && `props` in e;
}
function l$1(e) {
	return e.replace(/([A-Z])/g, `-$1`).toLowerCase();
}
function u$1(e) {
	return typeof e == `object` && !!e && `type` in e;
}
function d$1(e) {
	return typeof e == `function`;
}
var f$1 = Symbol.for(`react.forward_ref`);
var p$1 = Symbol.for(`react.memo`);
var m$1 = Symbol.for(`react.fragment`);
function h$1(e, t) {
	return typeof e == `object` && !!e && `$$typeof` in e && e.$$typeof === t;
}
function g$1(e) {
	return h$1(e, f$1) && `render` in e && typeof e.render == `function`;
}
function _$2(e) {
	return h$1(e, p$1) && `type` in e;
}
function v$2(e) {
	return e.type === m$1;
}
//#endregion
//#region node_modules/.pnpm/@takumi-rs+helpers@2.13.7_preact@10.29.3_react@19.2.4/node_modules/@takumi-rs/helpers/dist/jsx.mjs
var _$1;
function v$1(e, t) {
	return typeof e == `object` && e && t in e ? e[t] : void 0;
}
function y$1(e) {
	return typeof e == `object` && !!e && `then` in e && typeof e.then == `function`;
}
function ee(e) {
	let t = v$1(e, `__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE`);
	if (typeof t == `object` && t && `H` in t) {
		let e = t;
		return {
			get: () => e.H,
			set: (t) => {
				e.H = t;
			}
		};
	}
	let n = v$1(v$1(e, `__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED`), `ReactCurrentDispatcher`);
	if (typeof n == `object` && n && `current` in n) {
		let e = n;
		return {
			get: () => e.current,
			set: (t) => {
				e.current = t;
			}
		};
	}
	return null;
}
function b$1() {
	return _$1 ??= import("./react-CSJzK7Q0.js").then((n) => /* @__PURE__ */ __toESM(n.t(), 1)).then((e) => ee(e.default ?? e)).catch(() => null), _$1;
}
function x$1(e, t) {
	return e.contexts.has(t) ? e.contexts.get(t) : v$1(t, `_currentValue`);
}
var S$1 = () => {};
function C$1(e, t) {
	let n = (t) => x$1(e, t), r = 0;
	return {
		readContext: n,
		useContext: n,
		use: (e) => {
			if (y$1(e)) {
				if (e.status === `fulfilled`) return e.value;
				throw e.status === `rejected` ? e.reason : e;
			}
			return n(e);
		},
		useState: (e) => [typeof e == `function` ? e() : e, S$1],
		useReducer: (e, t, n) => [n ? n(t) : t, S$1],
		useMemo: (e) => e(),
		useCallback: (e) => e,
		useRef: (e) => ({ current: e }),
		useEffect: S$1,
		useLayoutEffect: S$1,
		useInsertionEffect: S$1,
		useImperativeHandle: S$1,
		useDebugValue: S$1,
		useDeferredValue: (e) => e,
		useTransition: () => [!1, S$1],
		useOptimistic: (e) => [e, S$1],
		useActionState: (e, t) => [
			t,
			S$1,
			!1
		],
		useSyncExternalStore: (e, t, n) => (n ?? t)(),
		useId: () => `:t${t}-${r++}:`,
		useCacheRefresh: () => S$1,
		useHostTransitionStatus: () => ({
			pending: !1,
			data: null,
			method: null,
			action: null
		})
	};
}
async function w$1(e, t, n) {
	let r = await b$1();
	if (!r) return e(t);
	let i = n.ids.current++;
	for (let a = 0;; a++) {
		let o = r.get();
		r.set(C$1(n, i));
		let s;
		try {
			return e(t);
		} catch (e) {
			s = e;
		} finally {
			r.set(o);
		}
		if (!y$1(s) || a >= 64) throw s;
		await T$1(s);
	}
}
async function T$1(e) {
	try {
		e.value = await e, e.status = `fulfilled`;
	} catch (t) {
		e.reason = t, e.status = `rejected`;
	}
}
function E$1(e) {
	return typeof e == `string` || typeof e == `number`;
}
function D$1(e) {
	return e.replace(/&/g, `&amp;`).replace(/"/g, `&quot;`).replace(/</g, `&lt;`).replace(/>/g, `&gt;`);
}
function O$1(e) {
	let t = [];
	for (let n in e) Object.hasOwn(e, n) && t.push(`${l$1(n)}:${String(e[n]).trim()}`);
	return t.join(`;`);
}
var k$1 = new Set(`stopColor.stopOpacity.strokeWidth.strokeDasharray.strokeDashoffset.strokeLinecap.strokeLinejoin.fillRule.clipRule.colorInterpolationFilters.floodColor.floodOpacity.accentHeight.alignmentBaseline.arabicForm.baselineShift.capHeight.clipPath.clipPathUnits.colorInterpolation.colorProfile.colorRendering.enableBackground.fillOpacity.fontFamily.fontSize.fontSizeAdjust.fontStretch.fontStyle.fontVariant.fontWeight.glyphName.glyphOrientationHorizontal.glyphOrientationVertical.horizAdvX.horizOriginX.imageRendering.letterSpacing.lightingColor.markerEnd.markerMid.markerStart.overlinePosition.overlineThickness.paintOrder.preserveAspectRatio.pointerEvents.shapeRendering.strokeMiterlimit.strokeOpacity.textAnchor.textDecoration.textRendering.transformOrigin.underlinePosition.underlineThickness.unicodeBidi.unicodeRange.unitsPerEm.vectorEffect.vertAdvY.vertOriginX.vertOriginY.vAlphabetic.vHanging.vIdeographic.vMathematical.wordSpacing.writingMode`.split(`.`));
function A$1(e, t) {
	if (e === `children` || t == null) return;
	let n;
	if (n = e === `className` ? `class` : k$1.has(e) ? l$1(e) : e, typeof t == `boolean`) return `${n}="${String(t)}"`;
	if (e === `style` && typeof t == `object`) {
		let e = O$1(t);
		if (e) return `style="${D$1(e)}"`;
	}
	return `${n}="${D$1(String(t))}"`;
}
function j$1(e, t, n) {
	let r = !1;
	for (let n in e) {
		if (!Object.hasOwn(e, n)) continue;
		let i = A$1(n, e[n]);
		i !== void 0 && (t.push(` `, i), n === `xmlns` && (r = !0));
	}
	n && !r && t.push(` xmlns="http://www.w3.org/2000/svg"`);
}
var M$1 = (e, t, n) => {
	let r = e.props || {};
	if (d$1(e.type)) {
		N$1(e.type(e.props), t, !1);
		return;
	}
	if (typeof e.type == `symbol`) {
		N$1(r.children, t, !1);
		return;
	}
	if (g$1(e.type)) {
		N$1(e.type.render(e.props, null), t, !1);
		return;
	}
	if (_$2(e.type)) {
		M$1({
			...e,
			type: e.type.type
		}, t, n);
		return;
	}
	if (typeof e.type != `string`) return;
	t.push(`<`, e.type), j$1(r, t, n && e.type === `svg`);
	let a = r.children;
	t.push(`>`), N$1(a, t, !1), t.push(`</`, e.type, `>`);
};
function N$1(e, t, n) {
	if (e != null && e !== !1) {
		if (E$1(e)) {
			t.push(String(e));
			return;
		}
		if (Array.isArray(e)) {
			for (let n of e) N$1(n, t, !1);
			return;
		}
		u$1(e) && M$1(e, t, n);
	}
}
function te(e) {
	let t = [];
	return N$1(e, t, !0), t.join(``);
}
function P$1() {
	return {
		nodes: [],
		css: []
	};
}
async function F$1(t$3, n) {
	let i$5 = await I$1(t$3, {
		defaultStyles: L$1(n),
		presets: t(n?.defaultStyles),
		tailwindClassesProperty: n?.tailwindClassesProperty ?? `tw`,
		contexts: /* @__PURE__ */ new Map(),
		ids: { current: 0 }
	}), a$4 = i$5.nodes, o;
	o = a$4.length === 0 ? r$2({}) : a$4.length === 1 && a$4[0] !== void 0 ? a$4[0] : r$2({
		children: a$4,
		style: {
			display: `block`,
			width: s$2(100),
			height: s$2(100)
		}
	});
	let c = i$5.css, u = {
		node: o,
		css: c,
		get stylesheets() {
			return a(), c;
		}
	};
	return i(u), u;
}
async function I$1(e, t) {
	return e == null || e === !1 ? P$1() : e instanceof Promise ? I$1(await e, t) : typeof e == `object` && Symbol.iterator in e ? se(e, t) : u$1(e) ? await Z(e, t) : {
		nodes: [i$2({
			text: String(e),
			preset: t.presets?.span
		})],
		css: []
	};
}
function L$1(e$3) {
	return e$3 && `defaultStyles` in e$3 ? e$3.defaultStyles ?? e : e;
}
var R$1 = Symbol.for(`react.context`);
var z$1 = Symbol.for(`react.provider`);
var B$1 = Symbol.for(`react.consumer`);
function V$1(e, t) {
	let n = e.type;
	if (typeof n != `object` || !n) return;
	let r = v$1(n, `$$typeof`);
	if (r === z$1) return H$1(e, v$1(n, `_context`), t);
	if (r === B$1) return U$1(e, v$1(n, `_context`) ?? n, t);
	if (r === R$1) return typeof K$1(e) == `function` ? U$1(e, n, t) : H$1(e, n, t);
}
function H$1(e, t, n) {
	let r = new Map(n.contexts);
	return r.set(t, v$1(e.props, `value`)), $(e, {
		...n,
		contexts: r
	});
}
function U$1(e, t, n) {
	let r = K$1(e);
	return d$1(r) ? I$1(r(x$1(n, t)), n) : $(e, n);
}
async function W$1(e, t, n) {
	return I$1(await w$1(e, t, n), n);
}
function G$1(e, t) {
	if (g$1(e.type)) {
		let { render: n } = e.type;
		return W$1((e) => n(e, null), e.props, t);
	}
	if (_$2(e.type)) {
		let n = e.type.type;
		return d$1(n) ? W$1(n, e.props, t) : Z({
			...e,
			type: n
		}, t);
	}
}
function K$1(e) {
	if (typeof e.props == `object` && e.props !== null && `children` in e.props) return e.props.children;
}
function q$1(e) {
	if (!u$1(e)) return;
	let t = K$1(e);
	if (typeof t == `string`) return t;
	if (typeof t == `number`) return String(t);
	if (Array.isArray(t) || typeof t == `object` && t && Symbol.iterator in t) return X(t);
	if (u$1(t) && v$2(t)) return q$1(t);
}
function J(e) {
	let t = [];
	for (let n of e) {
		let e = Y(n);
		if (e === void 0) return;
		t.push(e);
	}
	return t.join(``);
}
function Y(e) {
	if (typeof e == `string`) return e;
	if (typeof e == `number`) return String(e);
	if (e == null || typeof e == `boolean` || typeof e == `symbol`) return ``;
	if (typeof e == `object` && Symbol.iterator in e) return J(e);
	if (!u$1(e)) return;
	if (v$2(e)) return Y(K$1(e));
	let t = K$1(e);
	return t === void 0 ? `` : typeof t == `object` && t && Symbol.iterator in t ? J(t) : Y(t);
}
function X(e) {
	let t = [], n = !1;
	for (let r of e) {
		if (u$1(r)) return;
		if (typeof r == `string`) {
			n = !0, t.push(r);
			continue;
		}
		if (typeof r == `number`) {
			n = !0, t.push(String(r));
			continue;
		}
		return;
	}
	if (n) return t.join(``);
}
async function Z(e, t) {
	let i = V$1(e, t);
	if (i !== void 0) return i;
	if (d$1(e.type)) return W$1(e.type, e.props, t);
	let a = G$1(e, t);
	if (a !== void 0) return a;
	if (v$2(e)) return $(e, t);
	if (c(e, `style`)) {
		let t = Y(K$1(e));
		return {
			nodes: [],
			css: t && t.length > 0 ? [t] : []
		};
	}
	if (c(e, `head`)) return {
		nodes: [],
		css: (await $(e, t)).css
	};
	if (typeof e.type != `string` || s(e.type)) return P$1();
	let o = Q(e, t);
	if (c(e, `br`)) return {
		nodes: [i$2({
			text: `
`,
			preset: t.presets?.br,
			...o
		})],
		css: []
	};
	if (c(e, `img`)) return {
		nodes: [re(e, t)],
		css: []
	};
	if (c(e, `svg`)) return {
		nodes: [ie(e, t)],
		css: []
	};
	let s$4 = q$1(e);
	if (s$4 !== void 0) return {
		nodes: [i$2({
			text: s$4,
			...o
		})],
		css: []
	};
	let l = await $(e, t);
	return {
		nodes: [r$2({
			children: l.nodes,
			...o
		})],
		css: l.css
	};
}
function re(e, n) {
	if (!e.props.src) throw Error(`Image element must have a 'src' prop.`);
	let r = Q(e, n), i = e.props.width === void 0 ? void 0 : Number(e.props.width), a = e.props.height === void 0 ? void 0 : Number(e.props.height);
	return a$2({
		src: e.props.src,
		width: i,
		height: a,
		...r
	});
}
function ie(e, n) {
	let r = Q(e, n);
	return a$2({
		src: te(e),
		width: e.props.width === void 0 ? void 0 : Number(e.props.width),
		height: e.props.height === void 0 ? void 0 : Number(e.props.height),
		...r
	});
}
function ae(e, t, n) {
	let r = n.presets, i = r && e !== void 0 && e in r ? r[e] : void 0;
	if (typeof t != `object` || !t) return { preset: i };
	for (let e in t) if (Object.hasOwn(t, e)) return {
		preset: i,
		style: t
	};
	return { preset: i };
}
function oe(e, t) {
	let n = t.tailwindClassesProperty;
	if (typeof e.props != `object` || e.props === null || !(n in e.props)) return;
	let r = e.props[n];
	if (typeof r == `string`) return r;
}
function Q(e, t) {
	let n$3 = e.props, r = typeof e.type == `string` ? e.type : void 0, { preset: i, style: a } = ae(r, n$3.style, t), s = oe(e, t), c = n(n$3, t.tailwindClassesProperty);
	return {
		tagName: r,
		className: n$3.className ?? n$3.class,
		id: n$3.id,
		dir: n$3.dir,
		lang: n$3.lang,
		attributes: c,
		tw: s,
		style: a,
		preset: i
	};
}
function $(e, t) {
	let n = K$1(e);
	return n === void 0 ? Promise.resolve(P$1()) : I$1(n, t);
}
async function se(e, t) {
	let n = [], r = /* @__PURE__ */ new Set(), i = 0;
	for (let a of e) {
		let e = i;
		i += 1;
		let o = I$1(a, t).then((t) => {
			n[e] = t;
		}).finally(() => r.delete(o));
		r.add(o), r.size >= 8 && await Promise.race(r);
	}
	await Promise.all(r);
	let a = [], o = [];
	for (let e of n) e && (a.push(...e.nodes), o.push(...e.css));
	return {
		nodes: a,
		css: o
	};
}
//#endregion
//#region node_modules/.pnpm/@takumi-rs+wasm@2.13.7_csstype@3.2.3_preact@10.29.3_react@19.2.4/node_modules/@takumi-rs/wasm/bundlers/workerd.js
var workerd_default = module;
//#endregion
//#region node_modules/.pnpm/takumi-js@2.13.7_csstype@3.2.3_preact@10.29.3_react@19.2.4/node_modules/takumi-js/dist/backend/wasm.mjs
var loadBackend = (module) => initWasm(module, workerd_default);
//#endregion
//#region node_modules/.pnpm/@takumi-rs+helpers@2.13.7_preact@10.29.3_react@19.2.4/node_modules/@takumi-rs/helpers/dist/html.mjs
var l = Symbol(`Fragment`);
var u = /* @__PURE__ */ new Set([
	`area`,
	`base`,
	`br`,
	`col`,
	`embed`,
	`hr`,
	`img`,
	`input`,
	`keygen`,
	`link`,
	`meta`,
	`param`,
	`source`,
	`track`,
	`wbr`
]);
var d = /* @__PURE__ */ new Set([`script`, `style`]);
var f = /(?:<(\/?)([a-zA-Z][a-zA-Z0-9\:-]*)(?:\s([^>]*?))?((?:\s*\/)?)>|(<\!\-\-)([\s\S]*?)(\-\->)|(<\!)([\s\S]*?)(>))/gm;
var p = 64;
var m = 46;
var h = 45;
var g = 58;
var _ = 95;
var v = 61;
var y = 34;
var b = 39;
var x = 92;
function S(e) {
	return e >= 97 && e <= 122 || e >= 65 && e <= 90 || e >= 48 && e <= 57 || e === p || e === m || e === h || e === g || e === _;
}
function C(e) {
	let t = {};
	if (e) {
		let n = `none`, r, i = ``, a;
		for (let o = 0; o < e.length; o++) {
			let s = e.charCodeAt(o);
			if (n === `none`) S(s) ? (r && (t[r] = i, r = void 0, i = ``), a = o, n = `key`) : s === v && r && (n = `value`);
			else if (n === `key`) S(s) || (r = e.substring(a, o), n = s === v ? `value` : `none`);
			else if (s === y || s === b) {
				let t = s === y ? `"` : `'`, r = o + 1, a = e.indexOf(t, r);
				for (; a > 0 && e.charCodeAt(a - 1) === x;) a = e.indexOf(t, a + 1);
				if (a === -1) break;
				i = e.substring(r, a), o = a, n = `none`;
			}
		}
		n === `key` && a != null && a < e.length && (r = e.substring(a, e.length)), r && (t[r] = i);
	}
	return t;
}
function w(e) {
	let t = typeof e == `string` ? e : e.value, n, r, i, a, o, s, c, l, p, m = [];
	f.lastIndex = 0, r = n = {
		type: 0,
		children: []
	};
	let h = 0;
	function g() {
		a = t.substring(h, f.lastIndex - i[0].length), a && r.children.push({
			type: 2,
			value: a,
			parent: r
		});
	}
	for (; i = f.exec(t);) {
		if (s = i[5] || i[8], c = i[6] || i[9], l = i[7] || i[10], d.has(r.name) && i[2] !== r.name) {
			o = f.lastIndex - i[0].length, r.children.length > 0 && (r.children[0].value += i[0]);
			continue;
		}
		if (s === `<!--`) {
			if (o = f.lastIndex - i[0].length, d.has(r.name)) continue;
			p = {
				type: 3,
				value: c,
				parent: r,
				loc: [{
					start: o,
					end: o + s.length
				}, {
					start: f.lastIndex - l.length,
					end: f.lastIndex
				}]
			}, m.push(p), p.parent.children.push(p);
		} else if (s === `<!`) o = f.lastIndex - i[0].length, p = {
			type: 4,
			value: c,
			parent: r,
			loc: [{
				start: o,
				end: o + s.length
			}, {
				start: f.lastIndex - l.length,
				end: f.lastIndex
			}]
		}, m.push(p), p.parent.children.push(p);
		else if (i[1] !== `/`) {
			if (g(), d.has(r.name)) {
				h = f.lastIndex, g();
				continue;
			}
			p = {
				type: 1,
				name: i[2] + ``,
				attributes: C(i[3]),
				parent: r,
				children: [],
				loc: [{
					start: f.lastIndex - i[0].length,
					end: f.lastIndex
				}]
			}, m.push(p), p.parent.children.push(p), i[4] && i[4].indexOf(`/`) > -1 || u.has(p.name) ? (p.loc[1] = p.loc[0], p.isSelfClosingTag = !0) : r = p;
		} else g(), i[2] + `` === r.name ? (p = r, r = p.parent, p.loc.push({
			start: f.lastIndex - i[0].length,
			end: f.lastIndex
		}), a = t.substring(p.loc[0].end, p.loc[1].start), p.children.length === 0 && p.children.push({
			type: 2,
			value: a,
			parent: r
		})) : i[2] + `` === m[m.length - 1].name && m[m.length - 1].isSelfClosingTag === !0 && (p = m[m.length - 1], p.loc.push({
			start: f.lastIndex - i[0].length,
			end: f.lastIndex
		}));
		h = f.lastIndex;
	}
	return a = t.slice(h), r.children.push({
		type: 2,
		value: a,
		parent: r
	}), n;
}
var T = Symbol(`HTMLString`);
var E = Symbol(`RenderFn`);
function D(e, t = [T]) {
	let n = { value: e };
	for (let e of t) Object.defineProperty(n, e, {
		value: !0,
		enumerable: !1,
		writable: !1
	});
	return n;
}
var O = {
	"&": `&amp;`,
	"<": `&lt;`,
	">": `&gt;`
};
function k(e) {
	return e.replace(/[&<>]/g, (e) => O[e] || e);
}
function A(e) {
	let t = ``;
	for (let [n, r] of Object.entries(e)) t += ` ${n}="${r}"`;
	return t;
}
function j(e) {
	if (e.children.length === 0) {
		let t = e;
		for (; t = t.parent;) if (t.name === `svg`) return !0;
	}
	return !1;
}
function M(e) {
	let { name: t, attributes: n = {} } = e, r = e.children.map((e) => N(e)).join(``);
	if (E in e) {
		let t = e[E](n, D(r));
		return t && t[T] ? t.value : k(String(t));
	}
	if (t === l) return r;
	let i = j(e);
	return i || u.has(t) ? `<${e.name}${A(n)}${i ? ` /` : ``}>` : `<${e.name}${A(n)}>${r}</${e.name}>`;
}
function N(e) {
	switch (e.type) {
		case 0: return e.children.map((e) => N(e)).join(``);
		case 1: return M(e);
		case 2: return `${e.value}`;
		case 3: return `<!--${e.value}-->`;
		case 4: return `<!${e.value}>`;
	}
}
var P = {
	quot: `"`,
	amp: `&`,
	lt: `<`,
	gt: `>`,
	apos: `'`,
	nbsp: `\xA0`,
	iexcl: `\u00A1`,
	cent: `\u00A2`,
	pound: `\u00A3`,
	curren: `\u00A4`,
	yen: `\u00A5`,
	brvbar: `\u00A6`,
	sect: `\u00A7`,
	uml: `\u00A8`,
	copy: `\u00A9`,
	ordf: `\u00AA`,
	laquo: `\u00AB`,
	not: `\u00AC`,
	shy: `\u00AD`,
	reg: `\u00AE`,
	macr: `\u00AF`,
	deg: `\u00B0`,
	plusmn: `\u00B1`,
	sup2: `\u00B2`,
	sup3: `\u00B3`,
	acute: `\u00B4`,
	micro: `\u00B5`,
	para: `\u00B6`,
	middot: `\u00B7`,
	cedil: `\u00B8`,
	sup1: `\u00B9`,
	ordm: `\u00BA`,
	raquo: `\u00BB`,
	frac14: `\u00BC`,
	frac12: `\u00BD`,
	frac34: `\u00BE`,
	iquest: `\u00BF`,
	Agrave: `\u00C0`,
	Aacute: `\u00C1`,
	Acirc: `\u00C2`,
	Atilde: `\u00C3`,
	Auml: `\u00C4`,
	Aring: `\u00C5`,
	AElig: `\u00C6`,
	Ccedil: `\u00C7`,
	Egrave: `\u00C8`,
	Eacute: `\u00C9`,
	Ecirc: `\u00CA`,
	Euml: `\u00CB`,
	Igrave: `\u00CC`,
	Iacute: `\u00CD`,
	Icirc: `\u00CE`,
	Iuml: `\u00CF`,
	ETH: `\u00D0`,
	Ntilde: `\u00D1`,
	Ograve: `\u00D2`,
	Oacute: `\u00D3`,
	Ocirc: `\u00D4`,
	Otilde: `\u00D5`,
	Ouml: `\u00D6`,
	times: `\u00D7`,
	Oslash: `\u00D8`,
	Ugrave: `\u00D9`,
	Uacute: `\u00DA`,
	Ucirc: `\u00DB`,
	Uuml: `\u00DC`,
	Yacute: `\u00DD`,
	THORN: `\u00DE`,
	szlig: `\u00DF`,
	agrave: `\u00E0`,
	aacute: `\u00E1`,
	acirc: `\u00E2`,
	atilde: `\u00E3`,
	auml: `\u00E4`,
	aring: `\u00E5`,
	aelig: `\u00E6`,
	ccedil: `\u00E7`,
	egrave: `\u00E8`,
	eacute: `\u00E9`,
	ecirc: `\u00EA`,
	euml: `\u00EB`,
	igrave: `\u00EC`,
	iacute: `\u00ED`,
	icirc: `\u00EE`,
	iuml: `\u00EF`,
	eth: `\u00F0`,
	ntilde: `\u00F1`,
	ograve: `\u00F2`,
	oacute: `\u00F3`,
	ocirc: `\u00F4`,
	otilde: `\u00F5`,
	ouml: `\u00F6`,
	divide: `\u00F7`,
	oslash: `\u00F8`,
	ugrave: `\u00F9`,
	uacute: `\u00FA`,
	ucirc: `\u00FB`,
	uuml: `\u00FC`,
	yacute: `\u00FD`,
	thorn: `\u00FE`,
	yuml: `\u00FF`,
	fnof: `\u0192`,
	Alpha: `\u0391`,
	Beta: `\u0392`,
	Gamma: `\u0393`,
	Delta: `\u0394`,
	Epsilon: `\u0395`,
	Zeta: `\u0396`,
	Eta: `\u0397`,
	Theta: `\u0398`,
	Iota: `\u0399`,
	Kappa: `\u039A`,
	Lambda: `\u039B`,
	Mu: `\u039C`,
	Nu: `\u039D`,
	Xi: `\u039E`,
	Omicron: `\u039F`,
	Pi: `\u03A0`,
	Rho: `\u03A1`,
	Sigma: `\u03A3`,
	Tau: `\u03A4`,
	Upsilon: `\u03A5`,
	Phi: `\u03A6`,
	Chi: `\u03A7`,
	Psi: `\u03A8`,
	Omega: `\u03A9`,
	alpha: `\u03B1`,
	beta: `\u03B2`,
	gamma: `\u03B3`,
	delta: `\u03B4`,
	epsilon: `\u03B5`,
	zeta: `\u03B6`,
	eta: `\u03B7`,
	theta: `\u03B8`,
	iota: `\u03B9`,
	kappa: `\u03BA`,
	lambda: `\u03BB`,
	mu: `\u03BC`,
	nu: `\u03BD`,
	xi: `\u03BE`,
	omicron: `\u03BF`,
	pi: `\u03C0`,
	rho: `\u03C1`,
	sigmaf: `\u03C2`,
	sigma: `\u03C3`,
	tau: `\u03C4`,
	upsilon: `\u03C5`,
	phi: `\u03C6`,
	chi: `\u03C7`,
	psi: `\u03C8`,
	omega: `\u03C9`,
	thetasym: `\u03D1`,
	upsih: `\u03D2`,
	piv: `\u03D6`,
	bull: `\u2022`,
	hellip: `\u2026`,
	prime: `\u2032`,
	Prime: `\u2033`,
	oline: `\u203E`,
	frasl: `\u2044`,
	weierp: `\u2118`,
	image: `\u2111`,
	real: `\u211C`,
	trade: `\u2122`,
	alefsym: `\u2135`,
	larr: `\u2190`,
	uarr: `\u2191`,
	rarr: `\u2192`,
	darr: `\u2193`,
	harr: `\u2194`,
	crarr: `\u21B5`,
	lArr: `\u21D0`,
	uArr: `\u21D1`,
	rArr: `\u21D2`,
	dArr: `\u21D3`,
	hArr: `\u21D4`,
	forall: `\u2200`,
	part: `\u2202`,
	exist: `\u2203`,
	empty: `\u2205`,
	nabla: `\u2207`,
	isin: `\u2208`,
	notin: `\u2209`,
	ni: `\u220B`,
	prod: `\u220F`,
	sum: `\u2211`,
	minus: `\u2212`,
	lowast: `\u2217`,
	radic: `\u221A`,
	prop: `\u221D`,
	infin: `\u221E`,
	ang: `\u2220`,
	and: `\u2227`,
	or: `\u2228`,
	cap: `\u2229`,
	cup: `\u222A`,
	int: `\u222B`,
	there4: `\u2234`,
	sim: `\u223C`,
	cong: `\u2245`,
	asymp: `\u2248`,
	ne: `\u2260`,
	equiv: `\u2261`,
	le: `\u2264`,
	ge: `\u2265`,
	sub: `\u2282`,
	sup: `\u2283`,
	nsub: `\u2284`,
	sube: `\u2286`,
	supe: `\u2287`,
	oplus: `\u2295`,
	otimes: `\u2297`,
	perp: `\u22A5`,
	sdot: `\u22C5`,
	lceil: `\u2308`,
	rceil: `\u2309`,
	lfloor: `\u230A`,
	rfloor: `\u230B`,
	lang: `\u27E8`,
	rang: `\u27E9`,
	loz: `\u25CA`,
	spades: `\u2660`,
	clubs: `\u2663`,
	hearts: `\u2665`,
	diams: `\u2666`,
	OElig: `\u0152`,
	oelig: `\u0153`,
	Scaron: `\u0160`,
	scaron: `\u0161`,
	Yuml: `\u0178`,
	circ: `\u02C6`,
	tilde: `\u02DC`,
	ensp: `\u2002`,
	emsp: `\u2003`,
	thinsp: `\u2009`,
	zwnj: `\u200C`,
	zwj: `\u200D`,
	lrm: `\u200E`,
	rlm: `\u200F`,
	ndash: `\u2013`,
	mdash: `\u2014`,
	lsquo: `\u2018`,
	rsquo: `\u2019`,
	sbquo: `\u201A`,
	ldquo: `\u201C`,
	rdquo: `\u201D`,
	bdquo: `\u201E`,
	dagger: `\u2020`,
	Dagger: `\u2021`,
	permil: `\u2030`,
	lsaquo: `\u2039`,
	rsaquo: `\u203A`,
	euro: `\u20AC`
};
function F(e) {
	return e.includes(`&`) ? e.replace(/&(?:#(\d+)|#[xX]([\da-fA-F]+)|([a-zA-Z][\w-]+));/g, (e, t, n, r) => t ? I(Number(t)) ?? e : n ? I(Number.parseInt(n, 16)) ?? e : Object.hasOwn(P, r) ? P[r] ?? e : e) : e;
}
function I(e) {
	if (!(!Number.isInteger(e) || e < 0 || e > 1114111) && !(e >= 55296 && e <= 57343)) {
		if (e === 0) return `\uFFFD`;
		if (e >= 128 && e <= 159) return `\u20AC\u0081\u201A\u0192\u201E\u2026\u2020\u2021\u02C6\u2030\u0160\u2039\u0152\u008D\u017D\u008F\u0090\u2018\u2019\u201C\u201D\u2022\u2013\u2014\u02DC\u2122\u0161\u203A\u0153\u009D\u017E\u0178`[e - 128];
		try {
			return String.fromCodePoint(e);
		} catch {
			return;
		}
	}
}
function L(e, t$2) {
	let n = w(e), r = {
		nodes: [],
		css: []
	}, i = t(t$2?.defaultStyles), o = t$2?.tailwindClassesProperty ?? `tw`;
	for (let e of n.children) R(e, i, o, r.nodes, r.css);
	return r;
}
function R(e, i, a, s$3, c) {
	if (e.type === 3) return;
	if (e.type === 2) {
		let t = F(e.value ?? ``);
		t && s$3.push(i$2({
			text: t,
			preset: i?.span
		}));
		return;
	}
	if (e.type === 0) {
		for (let t of e.children) R(t, i, a, s$3, c);
		return;
	}
	if (e.type !== 1) return;
	let l = e;
	if (l.name === `style`) {
		let e = ``;
		for (let t of l.children) t.type === 2 && typeof t.value == `string` && (e += t.value);
		e && c.push(e);
		return;
	}
	if (l.name === `head`) {
		let e = [];
		for (let t of l.children) R(t, i, a, e, c);
		return;
	}
	let u = z(l, i, a);
	if (l.name === `br`) {
		s$3.push(i$2({
			text: `
`,
			preset: i?.br,
			...u
		}));
		return;
	}
	if (l.name === `img`) {
		let e = l.attributes?.src;
		if (!e) throw Error(`Image element must have a 'src' prop.`);
		s$3.push(a$2({
			src: e,
			width: G(l.attributes?.width),
			height: G(l.attributes?.height),
			...u
		}));
		return;
	}
	if (s(l.name)) return;
	if (l.name === `svg`) {
		s$3.push(a$2({
			src: N(l),
			width: G(l.attributes?.width),
			height: G(l.attributes?.height),
			...u
		}));
		return;
	}
	let d = !0, f = ``;
	for (let e of l.children) if (e.type !== 3) {
		if (e.type !== 2) {
			d = !1;
			break;
		}
		f += e.value ?? ``;
	}
	if (d && f) {
		s$3.push(i$2({
			text: F(f),
			...u
		}));
		return;
	}
	let p = [];
	for (let e of l.children) R(e, i, a, p, c);
	s$3.push(r$2({
		children: p,
		...u
	}));
}
function z(e, t, n$2) {
	let r = e.attributes ? B(e.attributes) : {}, a = typeof r.style == `string` ? V(r.style) : void 0, o = n(r, n$2), s = typeof r[n$2] == `string` ? r[n$2] : void 0, c = t && e.name in t ? t[e.name] : void 0;
	return {
		tagName: e.name,
		className: r.class,
		id: r.id,
		dir: r.dir,
		lang: r.lang,
		attributes: o,
		tw: s,
		style: a,
		preset: c
	};
}
function B(e) {
	let t = {};
	for (let n in e) {
		let r = e[n];
		r !== void 0 && (t[n] = F(r));
	}
	return t;
}
function V(e) {
	let t = {}, n = 0, r = -1, i = 0, a = (i) => {
		if (r < 0) return;
		let a = e.slice(n, r).trim(), o = e.slice(r + 1, i).trim();
		a && o && (t[W(a)] = o);
	};
	for (let t = 0; t < e.length; t += 1) {
		let o = e[t];
		if (o === `\\`) t += 1;
		else if (o === `"` || o === `'`) t = H(e, t);
		else if (o === `/` && e[t + 1] === `*`) t = U(e, t);
		else if (o === `(`) i += 1;
		else if (o === `)`) i = Math.max(0, i - 1);
		else if (i > 0) continue;
		else o === `:` && r < 0 ? r = t : o === `;` && (a(t), n = t + 1, r = -1);
	}
	return a(e.length), Object.keys(t).length > 0 ? t : void 0;
}
function H(e, t) {
	let n = e[t];
	for (let r = t + 1; r < e.length; r += 1) if (e[r] === `\\`) r += 1;
	else if (e[r] === n) return r;
	return e.length;
}
function U(e, t) {
	let n = e.indexOf(`*/`, t + 2);
	return n < 0 ? e.length : n + 1;
}
function W(e) {
	return e.startsWith(`--`) ? e : e.replace(/-([a-z])/g, (e, t) => t.toUpperCase());
}
function G(e) {
	if (!e) return;
	let t = Number(e);
	return Number.isFinite(t) ? t : void 0;
}
var K = (e) => `text` in e && typeof e.text == `string` && e.text.trim() === ``;
function q(t) {
	let { nodes: n, css: i$4 } = L(t);
	for (; n[0] && K(n[0]);) n.shift();
	for (; n.at(-1) && K(n.at(-1));) n.pop();
	let a$3;
	a$3 = n.length === 0 ? r$2({}) : n.length === 1 && n[0] ? n[0] : r$2({
		style: {
			display: `block`,
			width: s$2(100),
			height: s$2(100)
		},
		children: n
	});
	let o = {
		node: a$3,
		css: i$4,
		get stylesheets() {
			return a(), i$4;
		}
	};
	return i(o), o;
}
var RendererProvider = class {
	load;
	backend;
	renderer;
	constructor(load) {
		this.load = load;
	}
	async get(module) {
		this.backend ??= this.load(module).catch((error) => {
			this.backend = void 0;
			throw error;
		});
		const backend = await this.backend;
		return this.renderer ??= new backend.Renderer();
	}
};
var defaultRenderer = new RendererProvider(async (module) => {
	return await (module === void 0 ? loadBackend() : import("./wasm-init-DzwbPAKW-Bo6eiF7F.js").then((n) => n.n).then((n) => n.n).then(({ initWasm }) => initWasm(module)));
});
function isTakumiNode(element) {
	if (typeof element !== "object" || element === null || !("type" in element)) return false;
	return element.type === "container" || element.type === "text" || element.type === "image";
}
async function transformElement(element, options) {
	if (isTakumiNode(element)) return {
		node: element,
		css: []
	};
	if (typeof element === "string") return q(element);
	return F$1(element, options?.jsx);
}
/** Resolves a caller-supplied renderer or the default provider. */
async function resolveRenderer(options) {
	if (options && "renderer" in options && options.renderer) return options.renderer;
	return defaultRenderer.get(options?.module);
}
/** Transforms an input into a node tree and extracts its emojis. */
async function resolveContent(element, options) {
	const { node: originalNode, css } = await transformElement(element, options);
	const emojiType = options?.emoji ?? "twemoji";
	return {
		node: emojiType !== "from-font" ? g$2(originalNode, emojiType) : originalNode,
		css
	};
}
/** Resolves the render's `images` option into concrete entries via {@link prepareImages}. */
async function collectImages(node, options) {
	const images = options?.images;
	const { sources, fetchCache, fetch, timeout, maxBytes, allowUrl, cache } = Array.isArray(images) ? { sources: images } : images ?? {};
	const prepared = await T$2({
		node,
		sources,
		fetchCache,
		fetch,
		timeout,
		maxBytes,
		allowUrl,
		signal: options?.signal
	});
	return cache ? prepared.map((image) => ({
		...image,
		cache: ("cache" in image ? image.cache : void 0) ?? cache
	})) : prepared;
}
var warnedStylesheets = false;
function warnStylesheetsDeprecated() {
	if (warnedStylesheets) return;
	warnedStylesheets = true;
	console.warn("takumi: the `stylesheets` option is deprecated, use `css` instead.");
}
/** Narrows the `css` option, which takes one entry or a list of them. */
function isCssList(css) {
	return Array.isArray(css);
}
function mergeCss(options, extra) {
	if (options?.css !== void 0 && options?.stylesheets !== void 0) throw new Error("pass either `css` or `stylesheets`, not both");
	if (options?.stylesheets !== void 0) warnStylesheetsDeprecated();
	return [...options?.css !== void 0 ? isCssList(options.css) ? options.css : [options.css] : options?.stylesheets ?? [], ...extra];
}
/**
* Renders a React element, HTML string, or Takumi node tree into an image.
*
* This function automatically detects the best renderer for your environment (native Rust on Node.js,
* WASM on Edge/Workers) and handles fetching fonts and images, and emoji extraction.
*
* @example
* ```tsx
* import { render } from "takumi-js";
*
* const buffer = await render(
*   <div tw="bg-blue-500 text-white p-4">Hello World</div>,
*   { width: 1200, height: 630 }
* );
* ```
*
* @param element - The content to render. Can be a JSX element (React-like), an HTML string, or a pre-constructed node tree.
* @param options - Configuration for rendering, including dimensions, format, fonts, and more.
* @returns A promise that resolves to the rendered image data (Buffer/Uint8Array).
*/
async function render(element, options) {
	options?.signal?.throwIfAborted();
	const renderer = await resolveRenderer(options);
	const { node, css: extractedCss } = await resolveContent(element, options);
	const images = await collectImages(node, options);
	options?.signal?.throwIfAborted();
	const { css: _, stylesheets: _alias, ...forward } = options ?? {};
	return renderer.render(node, {
		...forward,
		images,
		css: mergeCss(options, extractedCss)
	});
}
//#endregion
//#region node_modules/.pnpm/takumi-js@2.13.7_csstype@3.2.3_preact@10.29.3_react@19.2.4/node_modules/takumi-js/dist/response.mjs
var contentTypeMap = {
	png: "image/png",
	jpeg: "image/jpeg",
	webp: "image/webp",
	ico: "image/x-icon",
	raw: "application/octet-stream"
};
function defaultErrorHandler(error) {
	console.error("Failed to render image.");
	console.error(error);
}
function buildImageResponse(element, options) {
	let resolveReady;
	let rejectReady;
	const ready = new Promise((resolve, reject) => {
		resolveReady = resolve;
		rejectReady = reject;
	});
	ready.catch(() => {});
	const stream = new ReadableStream({ async start(controller) {
		try {
			const image = await render(element, options);
			controller.enqueue(image);
			controller.close();
			resolveReady();
		} catch (error) {
			controller.error(error);
			rejectReady(error);
			await (options?.onError ?? defaultErrorHandler)(error);
		}
	} });
	const headers = new Headers(options?.headers);
	if (!headers.get("content-type")) headers.set("content-type", contentTypeMap[options?.format ?? "png"]);
	const response = new Response(stream, {
		headers,
		status: options?.status,
		statusText: options?.statusText
	});
	return Object.defineProperty(response, "ready", {
		enumerable: false,
		value: ready,
		writable: false
	});
}
/**
* A universal ImageResponse class for generating images in API routes.
*
* Drop-in compatible with `next/og`'s `ImageResponse`. It supports React elements,
* custom fonts, Tailwind CSS (via `tw` prop), and various image formats.
*
* @example
* ```tsx
* import { ImageResponse } from "takumi-js/response";
*
* export function GET() {
*   return new ImageResponse(
*     <div tw="flex h-full w-full items-center justify-center bg-white">
*       <h1 tw="text-6xl font-bold">Hello World</h1>
*     </div>,
*     { width: 1200, height: 630 }
*   );
* }
* ```
*
* @param component - The JSX element to render.
* @param options - Rendering and response options.
*/
var ImageResponse = class extends Response {
	ready;
	constructor(component, options) {
		const response = buildImageResponse(component, options);
		super(response.body, response);
		this.ready = response.ready;
	}
};
//#endregion
//#region src/public/android-chrome-192x192.png?inline
var android_chrome_192x192_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAYAAABS3GwHAAAQAElEQVR4AVT9Cby12VXWiz7PGGvtXV+lkpAQmoAQ8KBIQtpKVSoJjUfpW2kCBLwqiIIeReHKUZD7C3gvYAvmghAa5SCKGmmUzoZWOBoUpEvfN6RvK1WVqu/b+33nvP9nrv0V3nevueecY47xjGeM2bzvWmvXV/Wxj3vs/NjHfsx84hOeMB9H+3EfS/9xj5tPfPzj58d+7OPm4x//sfMJT/jY+cQnPn4+5SlPmk+g/6QnPmE++UlPnE9+4hORP2E+EdsnPP5xSy/jKU9iPBhPRPeJT3g8Oo+fT6J+EjZrHHl0noAsWNF7ypOfhN4T5pMYuylLe9njP7Lo3JQ9Cdnt2ET+5Cc/cQYvY2lH9qQnPWHxjE30bn/Kk8F//JLF31Nvf/J86u1PIa4nz4w9GaxVP+lJM/rLDpunUG5H73biD+4dT33KsrvjqbfP28G4k/qpkVHfjm4wV33Vv/0pJ/3Ig3nnHU+dd931tPmMu+5a9nfccft8UP60O/D95Pm0O++Yd4AZv3c97c55JzZPxyb1HeA+4+l3oXPnjN/078Lu6U9/2kzJWGzi706wg5USvTvAvAOsp1FO7dtn+uEY2U29+Elcd2L/9LvuROf2GcxnPv3p8847n7r4RPcZ+LwLrilPh98zUuAW38985tPnM58BT7jFJv6e+Ywr2Z13zo//uGfOpz+IfQc5uZP+0+bT0I+v4K+4wLwTH7FNzlIifybYqcM1Mccu9TPxET5Pw0dw7rrrjhn508GJztPx+Uxsk7sql2Rr2y/V1SpZLvpjky3NOWR+xj60XURmjTm10x9XY0svlq6F5aJGx+AsexSmsBlTICpyO6iSbUYYRX8fQ92Fz/RPfmWpkIXnvu/43WVwbauqNXR1gV3Iog8gY6VmvKoU8QB/UroP8tWPqCPHIa+p2I/EZEa6FkZhH7zYFnjdrW0bsq0B34wlF5YJbS4bWqcaHVGqI8lwxr18DWK5vLxg2MpPg4sq8Q0djgcl31PSAfm2XS6by0tqZMJitQe5oE22GNeyvbi41L5ti9vhAA4g4R6utuF10IR3ch2/5RLMdAoTZYt2ybb4pa5W8i6uYGysiy7G6ZMw/EyZvioC5pj8xV9479u+bJPXQscucrdRdvWhdHFxESMd4WnG/4DLKfcuOMgKXlrhkVgHSbetnTkX9fKVXNCO7kb8EwO6Cx91ZV4H83/yIXgNNbmtjYmwDY5xFGhp7nMN2pEXyvsCCvjAaSGvTsQnm0FCQyKJLQJJHd2QjXzEBjlmkqV2P0jIwh/jq07yBgIU7YIPCIxlMYQ8Iwp+ggj+IOgB/7RnBhUUK/5AxX5oJ2ggkA3KzsLa5IY7qol9mfFr2ds69jGm6O3YT01iQ7yQ4yuNw6FTwcVyWTJ6+InhDqf9ymbQ7oyvMSlGq4n+QEeGaw4S9BLDvtokAPlka0+ID8Zs+ErKhE3szIwW+Vw5sXQ8HhV7VFTY7tjZ1o7uEa7xFd3UsQ1OcxAcz46nONHPZll+SESwBnNhRVvqw1Hx5zIuTmUQyGCBRzfyCUbmJWXfN9gPxSbjWSu21V3KVXDf2MxrbbDWNnCS22z0jfnMfAv9YCW2xQ3D8E9M4yonhY59irO7NeGAGqZWsOPHJoaJFL7p09IlGwQx62GoDg2pGbEwLHW1HBFglldCT7LS4XiQCG0DIITXJAEsWxtBB2YngBCTJQO0M6nNbjdb0lXL6QUnWuTCNgmyLUuK3ZhZeGORFBNtbFymOZV6Iov/JuDq1jLMsMSEZ6NOxd/lJTgMGv3JQmBY3eGPhH4HE+FkojOZQLAYTn4nMdq18AbjNjZwdbVyqmUi5pJJBT+YJRTQrLPjGQvyAP9dRxZOdFNm7GU1nHEv26ou9I/LtuCTYltZCFWn2KYsVy27/SrHA6yNRWOD4YZ34vaqgznhHJ+DhTKYx2YTZJ5tsJmPEQLkJSdwdavJy5Y5RZ52Fl7jv7o0goVfWEixZ+Hu6BZtG5/gb5ebupuYN3I2VNXEda41x5IueXKIzo7uxG/894E7EXFUl2RpMJaFLq74XLEyfuPGjXWnSAxVVhf6U7qAw7oLJh7WXDaNbfzvYA1878p4ctD4qGoJ36iAQc6u/BW1hLRRiPIgCbq6JgQGChOCESVJRq8KEhFAJFWGI+suFVgDO3zh76SQRGzcOoNvWQcmpIJhKbp7fGLnyAA0OmucdjZasDIWeThlbGRisOtqZcKqTB0NK5zTBxJZrQmJTWg1vmcAJRKRsaviQsLm6VYmhw7jTWW0p2IPLcZaNjL8B+eSR46in9hy+m8slp1J6SoW8iaM0T/Z0FgT01XgivF9TZjttQlit+JzEcOQ+bmJndxXNfFYVZRmtEqnq+IGeWE3V2178R/kaGYOJdnYWOgM9Ofqh/NgbgyWwc3mi03KziYLnylpjUunGr3k8TSPVtnEMVRgpEQenNQ2DiV1w5UJCF5EO4v2khL/kuXyykcFw9GVNsZXnzkZiSH2MDe6Z4eDcgfDVMfzM1WXCnlX46uBtE7+S7niF1PZpSrylPkDb42GxCBRUUyJkgFLe6KYes2QvCZwYCjasckiGJATeqnTly2hM1NodhUiaznGT3Zr2pgol+2VwMHt0DamU/ySscv4zqIanGY7CQFSGxNjVVRob4tT5DbOJBV1TpOdZ/WBkx37xQWlS+4+ScQ+hmStC4/a4JX+hu5ImxHbYMGdgR3/2Yw7izvLp1xqkn048sgETvx1HTiFGcWPuGwGUtcEwWvhueDNHSZ8utKWkotwzIR14Q+7CYcJ95nc6iQDar1m8CcpQmdn8a5HsJu8M2YJCPIzqb3KgLe4XFZ3L56JhdE1Hkz75Cc5U66SjCz8Lnm/krwcWXgDTtkcG/MwyEs1ihM++B5wGoxXNfMylLqIiSHlOh4P8BKU8ezU2GFjGTm5o33gkEo+k+PwmuShCKi4U3lic6Ub/kJ+yV0p8Q2c2BaI6zVYT6I7wFxcGb8kjkkd7By8FYV0ooQlJLKEJ5M116KM8iQg/Cq64AE+FT9dpRBLe2dxMrCSKwhPhDbarDNxobnGjI1tJYFiJR66qaYOXYyX4s8mGdjkOTH61UeVW40uiKse+IjvAq+ZFNSx1eKcwC5Iios+kxSdFC9/Bw0SEP3BokiRrC6v5//zszPaLRtt9CYOo38g+fHfBWjywdiAwyS5wC7fBKIDHLtr+VixgLtnI6JUYKakb3CS8+jsLCJDdkNPOvktYur4PDawu2wr+kaP7OvmAulqmR8Vv9FxwQ/S0FOuoh+eN9tzcR+K/IxYq7F36VAH5mTTxjx2lwq7pUt8MwVAPJBfuOArmNWtZm4y94mhXGGiCxZZFppZreF85JBInNXFYwl3RUvVRpeCn7Ozo6AueivGnXl54PoD5HRqXfi+ZB6DlfiCNVjcE64D3a5Wd4sUL/sTzk53KtxjYzinfeCxlAEV/cZpxWoB0wlw+pOJFU4PAUW+r9OFwGFTBGEzGYyTZ9lA0E+9zEjwoMRJFmKjv4cogxtB2JYovJRr41muu0nsXMlPyLZlBqtKIW3AKjLKkoF1ki+2BA03xiacuuETW/pUymlCGtIERbKtrlq14R6b8Fs1C3FcTba4kjiBGS7Rydiq8b8lJuKctIOfGpMVw86khN/EVvg7sJiDYRuuA05sQnxlvOByM7ZuxsGL3/jKeB6xJOT4osKeiYXjJRs8/fBJqRWLONkZ532UcuEvY7ZlW6tdZoQ2/nM3HNTxs+VTQHhmznd8ZUEnl+E3mWiDH05JomVVNb8lc3fjl5YdORFXuKwYyEPyl+f4wu8AN2Nl4slEoxuQrIFJv4881rBZbK/3T5NcTGzsUuyF8wHf1M1doipy1gg42/INM0sDsIyL9uJBvop2da/5KToDGWqqSaO7BDZOSrbDGUjL/D51TNvprVtXVWlCbFyVCUYGMZUBv+k8ASS4jBHfWngTr5PAbMu2DgS8JSjkXRVVZfxAMuySDR+kBneiI0vllm7KxThyiyu1S4VuGVvGUocv6vQIE98jfJnUyaPIgUQ2iYmO0MjYzkaNrzzypNbVlXb0bKPpJcUlfKX4TIzVTX8mnWt8ZxFc8iYxndjbXhPkINCOPBNmOE9k0RnkI+zDJdyi4wr3qZP/UuQ7cUTfsYXIIDYg5CoOlNOhENss/DCyl1cdz45qt2yvTREdzJW48+w+r3Bjl8KkyyjZXrHpKroBz9ghZFRqNhAqinJXn7SWYGqwVgS/AfagPamXztQaSxyDXKXuKjV5bObmeDwoMUceQNTZ5EOKY6eafGpJn0HMTmJ8Ju/n3OEimPjbuLtOfE44XHKgh6RtlU1mBRKvEVBJXSXG1nNxiFSXCtkAYMM4dZVJYknWulwEjH0W/MBZxLFJyQlYAOZUORE6EY+/nTsA63BhJNl51LBrTcaOLztI4tZ5edIBe8tzL76SDFfJPumkn0XLnVeZNHFFRm5YEHO52TgpXMZGyubI+EhSeG+wUYBdCyR1SnczQUPGT4xsg5qCJQoz4BSayHnRiMqBybOtSimfMDCbjI+1cGI5V5wW40w+MLKtyYRl1Da8h8TATtxUq43GSQec5Df6GKq71HVYY2aD74kVjK4OBJ/SXHICbsqnP4ZT8JJvQFVVOh6bupX5OhyOV+1eeOFtW+K1wzVzuYGfT3dyJ9mzNsifXfiCPXFGfcsc4t+2irrJZ+Er9ZZ5xK551HP4oLOBmU94xDUZ28nFDkb8r0K/uollC33yW2p4r44s24peV+vG9Rv04QNWMx9UihytpbMRR25gyKfWhKUF8QDIQmlQJkbFBE6FZOM845NFM7jVTibBjvKuShATO9jsBGJAbGO7Lwxd9aNnl1YiIIaKbC9f+1WwCHTT/oDP7lrjqCntqgJ3rNOAPJ3GdPI9iGGQqEm9E2Tq2DG8Ega9tbAu2Xz7Fc+8uTtwghUxRBaktLeMIxPxCryTvNR1Smw20U1f7UJlqqpRM/xYCHF65Ty8XFYTj66uAmeVyDyV8fBYlo4SMhU2li1KacBlsp2LhSNkyhVuE7eM2VZwEueI3ELNYLS6WgfitM3wXHx1dSWONAcJzfuvtIWluMJx5ZF+wzX9lAfx0LGt2LpKWby2FR3jSVwTbinRmeGFTOjAWskjRug3bXEwbMrYJE478af0g+s0HAIbnJ05DkZK+smfcpHrbFThY7BO43djzgu5LPyYIswgM1gwMbQt2yysnQEGeW0sgmahTgKI0FVKYDKBypLRDwblwCNNVatJ0iCRO2Ui36i7C1Ur/eCk3iHf6NpeNrq6ukqCaCZwW5tiWZxsOd1iW9jwEohLnlvwzaS4rAJjsElTW0JPOsLPttamYjxjE36D+JOcLP5V4Mt6CgVNxtKOXuLJneIyj0niAkuxp1yS3OgJ2SRXE5ltMIzICYC8jtV2+Jn8oTPwte5cis4Ebso2pU42YEmnfjCT4wEn63Qlf6eW1gKMzkSQ2Lpq+cz8hPQKpgAAEABJREFUHTjVEa+7aXS6wEewEcvOAsElXmIp2cmqrnSH1hUZXDbiHLwJtaIzF75N+yqW5E+M7XDMwt7AZxgRFquBDTGLcaw0aKcYPumjqLRJhGIvJrWz2SUFC2iGpqqL7THoTvoM0irymvcc4RBbPMoGAW62QUpbKlndVsVxkrGxyFPQW2DH45mEgbgmBDeCLjc9L4SVpivljJ9upb5KxlLB3DIW4nd08sYtiRa4hmjG8m1iyIori32SlB1/0a0iQNphHY4pB06vySRU7MGJbfTCfdsuVN3Aw4NHhgm/qlZ0djZa+huTkTqyxJ6SxVFVSg0NdbUWNxbFgI8N3pV95LlbuKSCQ5J1ODYBS6Y/4batRwGruxbOhIe4Mm4kY2FJGzmnK9uMnvrxl/gjGPiPbRNT+rEP/50YVh5IzITfxtxkPCU6VSe/eQyc8LGtGxcXzM0u83NkI2T+XA3H1tnZUXatGLKchP4MZ0oOjCbndiynGpv4jrKv4rWxZby7VFVLZ6x5ixfpAH9oxoTFPilDeXSqbm3EMuE4UEgsmRdxjdi7GL9k/sbaiFkfspQ6fib8jIBKDVZsgtddsp2pWTVp4ou5Mxm+RYleMAY++bTtoKoY4DVIFoaDMmV+omgzvoanBsQGhEO2upfj2GfSbGzjDd20bctgyxFIVU3TdHgNCq+88x/4TTBdhb7RM3UFTI1NFW0jd/PosisXJnCUDplMOmfHo8z4uLlojs14YhB4vYpt8VoMbSOr5SOftOxrUaKPfC4NqdIGOzHTXPp04TCZ1NOztiztbLaMx3e5ZBudXblGchWjdKaukKUq68jCgqRkrX5hl/YpFy3bi4O4BpMVjt1FD59sHttypdTCDe//xdWaK1ziYqqZq+Bu3E3XXGExmcudfg6bgC65DcmpqtIAbI0BspOfPRzI78DOtib9hcs5HOzoZCyHXHepqxQ55gJVGVsNbDNOperGNaO8Cv1sOARKe5K7AzlKmXABDG6SjW/6DCvXhE+wU2yfxolvXHEdKF7y0eyEL6OLh00LfzUZnADQVTWLhvZc4KSTMePhJhmaSruqtTMBE8A4jX4FULWCjiy6wngnwaZxc2GItrjyuDDwQ5OFcEwF5mnjNfhGYnstpOAVdgM+O/yqi1xMAtm1gR//l3wsOAjYcMjjxAVfvwubuJjYiYTo6grXqlo9e3lCU5yQwYQDI5m0ifFN3Zv6qatiI9nUUZRWOzGebGptkPC2rFyxE/oTHjYTeDN3DGYDbeRzjSNv8BNnk4clgwcmWkg0gpGSUxS4lYtJXoyGwYus0EsJRlXyNRjBCqzMSfDpqXm0cMGHHDEEgmRbSNRdHDCHlefj8aBcNmNXJfEN+Cbu5DzjKWhkS4gn1RM3sNemgIfQ72rZfnC+5VhN8g9H8pkcJp7cKc0gIgn9wfxO8UOsg3kXXrr7amwocSS2LXcV/FSVTqWJ5UBpWdItt5xLJkJwahB1dS/FicC2EtAO6ey87tJYcmp00w7BAnzjs+PqCqUVTILcmchibGDPwMK6YHFKuMa+SLZpV0GGyEZOFoKxck3Z1nZ1Sw/GSS4+kcrn21OHKjk/6DWngzELH1/JJ0k5J8DGzwwH+hO/ph9ua6FhkziyCCLvQ62NBqQWzpQO3WhZ01bz/uekS6xg7Zz4sQ+/YAY/jyWDpAtuG/yzwYM1yN1NvR15cnzCAhusiU114e8gXCm/dnIyscunK7ZX/uMDWgqGZRVy+zRW0jpEgjs1ydXG76nqXo8O1Q0+8bh43DlbC0HTEoDxM+GQdldphBNlp2SDhX91s5CHJpwGuoM6cx1OVcZmyFUn3AUbYGlc6TKors5MwPT0QkNGNxsrYxY/YCVvwcabMrax6MdaU1Z1o1USv1UlKCr5F1ewil9Zs8WYyyr6UbXEJ1+X2vZNwb24uFRiyXAZjQQSskkeuhpZOKBnIncmI/2UPOcHPMXGEkdZwJW2BZLWNbA1PduKblfhcJeQxU8CJD3JOYVUoKdVpHAx+uLiQxHEXhiHLpUFt6nwwkqnICyjXxSjEOqXnACSeVnNCRfM+K0GA73BBF4Nr1NnxYD8pLeD5z/gJXyibwzil4qxsXg4i4jxhdutPHPn20872uY591K2lQPF4EuWVhHcpzJZzcKI35TwsK1qsCRVkTe8mbhMn6FlQ5MNOxiRgjsk+rsKvdgoPkjQZAEa2do0ZuEwL4khfibLcSeuzFVsUgbJK+OJV8Cr8b9sduId6j7xcllVFS/4HbJjQEzodpXyaJd4Ir4aUfr8krFNuzlUUF9zueZDxMBCP3Cn6Too+Fl7sV9+yfXMWmRDoKrIg7PadqDB2tkQIyLISBt4gxK9a9fOteZhWaICQPyX7WW85FMEOmWCEIJVo5iATD8nUnbcSiLJbZMEayUhTqpaNgJpYUZm078qeXPIkJBoYI+WirHopRyuErxOeeQuyza6CcqYnopdmMKTsYk0nGI/iGgycyMTm0Lwe+4uwUEeUkHARBubxG4VsVbXg4kDQgsHfsGMrmVlsaY/mYTCJliIl/1AVyWdHc7IRRjMJT87P6M2MhYQXG7qT7jt4OQLssGnVD45kW2Z9gwJ2iOftDDxwQ+nVWOb8e5WJjQ8YjOQrxDhUsQbnVXoA0m8GzHuaapZfO3CPpYRWYmp+rTgDQvc5/dJnk4SLS4LudZl9H3VC+XB4lybagg7K3xcxs8JN/2dvE822pa7YYzAtb04uZiHq/EB742crRrdrL0D7/MOR+6U6E1sbXxIsq1wN76yhnbsCp2zfBEmr/xf8GUkamp0ECVtir8SvQkhU4urqzRIpi3N1MgG4929NGwDUupeppJKmQj4kGCSjM2yw1HsLvj0wWgJ684jC52qVjE+MSJ+pR60NxZFVa0vOZLInUAwI29zTWBzmhf+B3xQx9/OsJXFObAFGtxaxWUZrJ1FJBbRTkJX21r+qGiM1Y7tgUUBmNrED5ZyQS6xzPjTVJnNiOMJVmJeKugwtL6NzJ95ZwISwyQPFzcuyOUE1jJcjMHk5EUguvge6jpQT00wB9hVVrDb1LQHvoNpW+ExWGTimujubG4sZVvVp7ijb/GDrauU3ERXXE2MNjjEN+nflAdnJ9d5H4XpymtiiixrIT72q8e+2AmlPA2Ia43DJViZ39Q7vOwSrlb8BY+CT3UDi39AivHgTpQylg8imBDlwwxgsbVu4QDpzHmVDl2LVzYQiZCwt4mTssN9Z5NkHi9pd/yQ/xsXN5QrXA/IJHxL/LZyXbI2Kwm1EXhC9rQgEgQcdUqeZGNIkEkoFUFISXQcTiYoSThmd7LAC7IhEJJdrcbxwCh6IRrdgU3kKROisSl88MKXlk3sq1rmBwYKVjAm3rtK1RTqYAWjmdyoLhzI21YwsrAHi4aeqrweebpPvCa8xFVgUeGjlBMmNsI++rY5QeaySz5SYrfDe2DPcFQ1WMA2+MgtK5jJV3TERXr5LUasTL5oiWsSz1WTnk6+wBDC+BHXpB/O8e0qCT/i6uTbp4UR3YHe4XBkRJrwGcQ9qCOwjXC9FIzo35QXmKtP3nY2h1EVxXbYKXyTF6OXxRTdbJbYpaCqQnew+HwyJB9ZS1LGM+9Gnlwkt7ZFV8FKc8Mu8RnhJQvZpmXpBgcIgWiN4VtX1wmPWMh/uGQ860/YdVeqxfvmr0kOYhNdCWDiRGt9419cGizIKDe7DUx1lXLFKHUABskNGZcDgXeru1ch1PW8u3H72tn9SxcyG20b/avSdVq0Eyw4MNmc4IxlEYTcTvJjm3JgcvNtZDaZhTsIZtFFbxDQCAYghf1If9lOTomBJoiMK2PEZpumNSIDa725I9BMBprLJtwv4b8xATsTEr/xd0n/5GOsu1AwEreshbeh63RY4aljE/vgdBcpGxr4WiqFBlwSg+2bE8AzM4uWvtAz/Aq9jcVLE9GU7VUnb5Y1GAu/LMJJTNGPvKqIZTvpLmOtN8HALtkgT9HfsZkZt4jpNAeZ1+PxoK5WUVwFr4MK37bxOZQr3FPbXtiJ84Q/lm53UUdDax4Se/KR932FePDIR6UZLsxZV2sCEJ0Zi6t2dJr1NeGYL7aiP+C9CjqxIRWyT9xif8B38rKDmz6DwFjGsdPySTd+hCBYtTPpVS1dDVJJYhQnIS8u2+qQmeIk3HWST5J3Snb+M8I6WFWxk4Q+LfonXNu0YSFrY8EEa2dzEK9yddVqxoa8oJWWdH7tFiUB8Wd0chKVG6zTuDSVILqt7lI5OJDkpfhMqWaMJEtq7hIVnHZM2YBj2Vgn+y7sifumTupuZPhBRfYpgZnMiLpOPm/2B5ObSTB5MGODYKpa5ZIUL14LVFxZOO94x7v01V/9VXrqU58qVoGM3liTPLGRbCOe8NxXMeMFbgWza8W1oT8lxsdVLlqFDoZItXTm1SFQi5d17FZXKU9jhQ/bag6/sfiKOdqUv6PJXE0Cjb24Jr4GxbTzyiF1PJ6lKYGRT44uWU/RCSfOBAn7Ki86eTyxSqZ/5IlBAF3y+fyRu1Y4k3o13MSVdbmvhTyUebvkk0TbWj4PjYZYi0PJ47IFLPqDWHfWWGSHK6zwGYBHt7G96du2mJuC3ATs9CnCVC5+Q45xDQBFg5dWXQRAJw6qWgHfx8bEgkECm5M7sonD3BKTtJSQE5flNVlSSeDYJIdAqehaDWYW/c4p9wfvH6Ym2EXiBotsgi1K6ibIwViCC0YV8VgiMFSmdk7wS4qNH8IKD5sEMjuxA1kTX8Cp+sQpCZTQZ7ILPOZQNn2UTD+ym8md5Me2wiPyjeRLJ92JPUMqeAuQ4O5wvcGz57333acP/IBH6UlPfKKe+cxnYn9QdDLByTmuNPkVzMlIgZnxYKSe4Bj5oRkxZY2LeE+bJTi2ZXxXMW5rgCf0dngl7owl14N+7rbBTTuPJme8gYz/+JFLwTiVYNJvMIVF4sdHdG2rKHZlQNWtYAknyc+Jq9aVN7VCt6qVnNleNmlXgw/npo54EGsV/JmnAdf4GviN/WpHhs7QlPlZCxwv2TSA0rKqSgYjd//kcGITXaSSbUUhSRHXpORWsnxgOGkMHBR6MYpxQFCTy/iwumpN2IDkoU8bw5HFjlrrmssXBsJK5tdgUiYNCyroZeFPbCSTvBNOVWomdm0UjAi08YHZ8pldXdgCpciiER9T0knPdIkOheBnY0qWbRGaitOPUQ2SEkFVa+cOxbB2TrSJXTbYgNdAZ0O2rXEv/J1FPwBCDT+iTLgfFv7AZss4dsEZ5GdjQ+a2/gWf/3m659579ZTbn6Jbb72mrlKwKo5DPgU4wtUO/sDBEuWX4+bBBloTf1S8LOJCd8Qnha5iW+CveWVs503t4gO3JpfRMeOiEQ7xmbZdvMFP7ilgTeJZ4xJcB2UnZTNkNBiz8V5WsE96U31s+tEdSydjmAtV5FM7+aCBaD4oq245OGAWdTNHkpVrI/9lK6XLsmmnltWxs6hL5+fny98g5+HONJYAABAASURBVPHZ1bp5JR87c7jMJoENys4Ci6LROp0gNPgUZUACbOXkcElVtcpcp7F04IukjSC6K2qa6Me+QC9uOcsOkhnM5+RdJIQMM6cEUSRg4IhEMBmmldeAdOyagJIgG2wGZ3hSNnRJl2xr5yOumzaZ4NVmkgWPS770yIJP17JyOhQ8gxNZ4h3gpQ8lGT8TYqlF+1R7LegDsRy6T18mFQsDgHBMosutcO1m4TN2ySlvS0CoixjxkTvRJXzyePGHP/Ij9fgnPkHvfvd71uPG53zu5yqfWjQ5E3Yq8YQyEoLWNSXcMUQDomWU0qQK/6qWcUZX9mkBVrcK3+VS9BPXgbkK3tkZPNE7Hg/4SP6tcMsBMQGZeI8+XlVdC7PrFLNt5uz0xGBbLqsYS57LpzH7JLu83HX9+g1tLFr7xGsyL4SgnfVme80JDniBJZHrZmxTAj7yqJS4N9YXCnmpm3E2cOJOCnbWwmDOJopZK8HdkOWQCS/Jim7uOgeeUABe+WjmqmIorgBl0EYZsEysaMtSV2kngAS3yKMfwJnBOCWQA89xiInLbBROC/TprEcr0YifebWZgj3xEfPIu08+DcCk5NXVDE8sOU1JgotRXpPZKcaSnInf2OcEj42NQhoU2yomt5jwwwoaFvE5waRU1cLn1/Kx8JULDF5XLXWjR3/xAnNiO0hulkx1r0QmFyMblklCZcXcbJbBRC/9K7+DTZCJGWB84id+QlyzOK7rLW99i571rC/UtWu3wsXqSuxWUSdscbmKkKfsknBio8PgwEfwsnAH+GIsPlPWopHW5BO1AAdjVbrk0BjhJXJPHjMQzh2fyGyrqkTF0FxzGvzgBDu2uD7p6JSgJh+5U+WQiE4W5sQHNJdePE9ijzztZUY/uOEvrqyNHBR4lm0lX4iXPV7gotU+kF8DTEbUVSrX2jjNXGOmXNXkLEHTCd/obJz6dFdO4rcKbVcpekmYGbXMb15TqmoJnbzZ6aYtYcyAfPph7BTUBjnSwyRkwUVj0i6woykchATmaVJMmSoqgXQ6ub36jhBc+8QrCw5lFT+I8c9tV1KCFbOQQAa1keUVn8GbmVgEAx6DBWpbGxtzkPRMQurGV1GgB38puvMKi2iUpFlZJPhcOEOxyzPzxoJHVaF5xiYNQOxxCdzUfuVfscc2h8jFjRt62EMfoqc97Wks/gtiaL3zHe+Iqf7Mn/kzyK4v/PgID9mMTVmSw1Oizy8EtvPlMwvAS5h5iH/b6i5lIaY/8B2sm+Np2zdthjBWsJGw0Af4iVzLp7hIl+zwkMxPcKtYXOCuHFDbGZ9AzQcxjE51S9goFzq2lTe94RA+DxYSmZhtc4CMlYONuWpi5qXKLzCiv+2XSlzhtdYabtMn6VeerK4ifu5ykoxt3oskqi7WlK2iDn56C0xcXXSpbcIENNkdWTjILrcLJnRX90GHI8AWdiwKvFa3mhJyCXoQTGw5rLVxWgYqC6m65ZDJ7sXeJolgj6sE5hSIPSJOqHyJFHwpZHcW0xq3ZJVsEoVdfMCEvmAi6pO88BOJZYS86uSr8R15EieucC7wwh9I3SxJ7sBn4t5Y6OGwJggczGTqE8bUxkTd4NOM4vQJnm0WkdbHnMHIZlsbhtPnBp9mfNZnfaYe+tCHrYkO7oHN88pXvFyf/hmfqQ/4wA+A3lRXLS4B6uq4VBtZ1WqfvlVHjzucl9zq5JdwB/lPvsKl62Q7yFX4VrdgxyLdJVo5cTM3iXfHruAePrb5QhId6nA8EhvEoDOUGKJvWy4rV+bYNrhZZlOHqzwXso7PMutlrMWPW8mVJaJgp1/dygSaTniKq2z80UA2KUuXrnWaywwmt30sNf52YtwoiXvjESkfoogrObBBnrggxszJZOEgUk2e9QLcXahKtjW4bU0+JQmhJG71MU59uV0ycbtUXuQz+ad31gP1KfOzM9GiDpFTcucaC2FxBUP4uTke31WlBL6zmKJ3shPX1IB0k6BJL21MZdqEI6hqMpAiBlLTPcnQSRvnUaXHawmkjY25MOkv5iQu2Ilx6oQeDqIdbsFdUhozTsnPACOy6FW1Jhj2KY/iuuR9wEC2sYF2Yrjg+f8jHvPh+rRP+3Tdc889uuBQCbeug97znrsV3E/6pE9WkVvMVc1Ex1+UEEzag9xmfICXspGvPTyIfcNP/E/4TXRnbChdJTtMpfyubiXXhTwn40DXko4sIuN7cujRZUMVcz3WwbdzGNjRsrqKfE5YTZZBwXsyR0O5GFmy6DOwdCLvKtnFBtkRT3WDFV/4lswPv8HfiW/AP9yqGyEv5OGUhVtXNrYVneR8Z7FP8hGQiW3qw5GDOvbKdcpEdWssf6HPZuTgKaE9maSdJEZtpx065VJ1q0nK4Nm9qyR0c/ubgMzl0AoJxATFMkI2eGNsSGpdILFQupIkLeeDRC5sZCI9W/wGb5Wh2KZUt4I9ggmnSSlb8ZUgwtdg8ML3pOAfjBwraCmqCJXLxj++gjdJUPrxHb3UwRooxiZj8XMgblBlG5gpl8nFgYnrUzHJhNOg7MSEEi/0fNIPrl0r5ooMvci+7Eu/VBsL9YKv6ZOHJk6V1F169atfrc/8zM/S8XgmYzuJfRJTciauQT82hILOEYlUJKC5K1v4RbKRz8hiN698JrbEmD/NyPxmDLIsxsEpfymFH36iE/yNeCa+osPgei2bOJY0Fu6pDrcmBtuMSO4CzjK8Mk8xKdobG9USkPPK3sp/DIVI1UU11VU6HI4K5k6OLjlATocrB67QZ+4GvA4HnkDSh4cDipPwm2zcNuuWsmwZJ6wV58Bu0E9xWYWvjNUkWAEWEgsLMIHKVK6Jylh3CNJacinjygWCZRXyAjDE4LjAbUYoqCjXnolB12XljVIeCZIgM5hk2wQIyf1qNw8SYFu2SVoW98DPKTikaiZ9Q4eYFO7xb7CSvAQZf/FtmYSfTp34jB5q6moBDbbTVRKeJBbCLJLozgQjy1WaOMrnygsXnraW34aHCx9LV/gaGrQjbzZR+Fznuf86C/4JT3i8HvvYx+qd73oXj3ibdiYsC3bNAYDXH7hf7//IR+iTPvmTdHHjuuI3fLOoVoxd3K8nM0SBj22FzwAnMedw6ipVSreaknGRiMxN87gEuTWvidEgWaWMx35nLVxyl0p/Y76miJHhxFDEaFvVtTZfdaurUfDiAJRIlXYWerAq+hFIxHqx7Gwvie21yJv8GL18ijfhOCioq8GO3FXpKjEkV9Eh8gf5CzTbqmrZxu4gGifsLhWy2MRranEVmIknOasyOvxCT1ESv3MCTCYwSSgGdm5J+1UybEuMDfoZmxCe9ANaXZr0A7qTyIl8MkkT2SkhBBNzsloFOUpXZAipokNLNsnBhgYLZCgYh+OBbtHfCbZoi2uoXcqJH87iGizMYEehSEpVsIZM3V3UcGSmjKPwCs/Iu058ijqTUCiY9uQ5cVwtroxFLmxtMynhNjX4EtAR4lvIB3Gnf8GizyZKf2NRZLI/+ZM/mYV9IVYxbKUDp91qwEkWE7vrjW96o77qq/6SHvmoR60/L1HGJn7I6YDLxI+jvAy9Jt22Es9ENxyzuDNHqW0rV3VrgOMm1hTkdin5y/x2IUcWjGB1kSv0UVDRTm435jOxXPB+BzC5LAuG0aNher38DPKTU5uxcIo9/MNnkB9MFMx82jPAjE36ad8syX93qavVbJSqU9sYVxf2aU3WxFBsJn7CO6WaMRudUnTFhQS9pXWSV6+7X8V4kNgEtoYn2gSSxNiWXaIiEkYhu2KFzMYmiLxIQnb9xue9SWSsu1tY4hByGCzIDFC6SGxwaNteOrV8GEle+MEGAKUEK/i2meSh+D35OekbpY07QXzY9KyFOUmIuOgKw3UqFOODx7nBZCRRK3YmhHUuYNDjRX9jwYqralmrsIv+jBLcdvJVVWhIps5Y+jnJ7JONy/CYLISxFvLjOPk/5mP+mHI3iL24Ynft2jX02KTzhPcOPhEK37/1N/8W8imBF+yrcJRr8SaHB070yW6qPtkmriyyMEjeoKDCPvq5ewUjG6Mrc6CFbxmdAmUqm6OrdOARIyW4sQ1GuLYtkR+rgMIzHEiHci0dpNG3S7bpZUQyP+Kynd+UqWrr7HCm7gZz6saNi7WY6TBuZc4Hmz0bZmN+g592eEzktmXjAw6DsvGx7loXkUGKUcUuZcJ5gloV/bS0bKNTZ3zlLRevDA7pf6E9AGrGGNSkzSC1VPYiPmXtWUySXFZVraRmIqaEzoFSS9+27MJ+qqtlxvOyTxi2FXsqoYRNUwv8XUY/wR04McteEySu5mQQ/dhFTpNu6cAE8tZDk8REJnlhh5N907Nkhw81A2YXDBJVyA7g2par1ExQ5Inf5GawgRhZvAY5Sb8bHFuNnSIDB9ca1Pm0Jl/m/MW/8JW6/sB1Tp2NR4iDhP5gI93gUed4PKOv9c0l5nrRi16opzzlKfqET/h4ZSE0HFRSV+t0eVUZmzjKm+sVM5i2tXE4JV87czPgHP+2cXkqOwsoi0aMJa7jGfME9kRuW1k0e+78HGq2WZi7DuRU5KapqQhz6gzettTwGxDfeXy1rcxFFqQl9AZ5YLOQi7nKVHiFcyVv8IfY+sQsOAa8kVfVyY7xtC/49Cxv2JtHzgnv+ANe3a2MH8+Oq46P4If/8XiKayMP0YFNTJTYcxAkpsrJEKIpGZ0EkkREIe046iqZIjsv3GuBZDw2ssSQcrnoRAMcrZrftO0sH4InoBCwT30qCZNgjZUgqbpJ0sapvWtdyON/z8TGHrxg5BY66UfnZE9qGCPrCqYCToluEtVdgk1YyfCcnHvRnZHQL2K0/WBssds4fWxjd3o1i9z+g35hF9+RRD/uozl4NMoi2OH37Gd/sR7ykNt0333vWxM2WGgFRuKJ63C54LEiiyscs2l+//ffoC959rP5cuyaBqDZmPET7PhMveKTdcIaCn9xpbatavLI3Sx5StziGvCZFFfJNnxKG3mNnC6LfWgtjGo1scY3imvjntaEFC7xsbFJxPUHvCQLT8xXxpNXI+lqbMxAXlMZqy7eG1wm/aQATXIiWslX+AXzxMnqKg6NM+18wBKZcuFjUNKMbLDI0w43XKo7sQ+lnY9w59K1Cr+2ZRv/vDeJ8SlB0oCEcVZlrYvEx0kWQZiGmGR+pK5S3nQJoAZ0YisuuopskGTlQhDMwWknAuwq/IzAUabMz8B24kvRTZHVzWlHu9CPvXLRnwQy0Y+84GlbokzsbRYvtRAN6hEO5EBcF7wJzWY/2RW+pbQZYrOx0aZWnUm2rUzETXygFA7G386GQPXUtxVf+v+71iibd6yPOT/6j/4RfQLf+r71bW8/xUQOwnUShw0P+tkImcBsGBFbc3K9+U1v1kd+5EfqS/nU6N5770Nryvi34caCpdLO4p4hJyaTj6eDE3l4J/7QOjseFVlyZpu2xa/FJbaJMzinXFgrTktrzsUFT36rbDhIwU6LLbFyAAAQAElEQVQes/g37hAnjH2NbeGDsqv4LcVn6G18cZV6Im2XBmsheQ7HzFEKQxgo1FRdOpCDQzYgczi46054dLVcXtxJk9KPbXSrSrHDqcxP/BkaE/v4vRln9JOn+BZ61ThJkjJga00c+1E5BRQBSJMSgNQD8js7P5/l72sivJKFinJF1l3L3gZwDUw2y2ERvoldbRUMg9lVMmUS1SBQkc6Q7m5t+Bj4FDhF8LkN5hk6fjJxkmVbVYUZVuhFjmjJeLLRgUVwOByFJsln85EUcfpvPDcKxea2quVX2hizg2dyscuSwjEcdk6Z8Byp8SNsUiU34bOUsU07/7xfTp7P+ezPXs+3ydfG5rnBm+PD2YENNpX4UnCh6CYE2On+++7nxL3U61/3On3Fn//zesqTn6hwIC2rDof4NSFXl3CpM+IrAEihCE2F0DFAqauVseQ+dQ6uCfcREFJms4F4xEg/C3MHxPbKFQsErMLvCM216YLRVfRBBCPzmDwdyXPqk1sWZK0eetEVa6AUst0tXKgZzyLP46e4ij601pxv2UxgN+tzENCkbYOHYfKPujbyiZgPFi6VnF/yCdbG3GQtzwAJfUo+UexqGfysn9RmqKtUWxzBuBpyoBYjxmiyENImRMhOkmCJMfJFXWo3SRFlqllADIEyZX6CGRIbizdEQjh3mQuSnGQl0ZNAdnxEHxPZtCjlxh8hM7ZjDyhOeBFpcCY1asrV3anWQk1j8st2fssudWJCf1uJYTEzVgRtSlXreDwoPEFXZA1eFRNPEuO3E1eRFzAGfG2veKup48XFZwVThZwuL683vPk7mxvXH9Af/8RPXKf4fffdpwM4GweHZOWP4QDCxVwTB7wGE5aTNfGlNFze9va3653vfKe+8W9/kx7xiEewaYa6Wss2RmClPWgnl4OcpW974Q0453EqeC4rOR/o3Cy2Q0eNrypikVZ7ohOblJ1FFnxcKOoTnbwmJ4ttGbsMRJ75GkS1s6YgoIkwuLKUOn3bMVdX6SaPfOnaXcitAwu+GIvWhL8x7mr0T+uiunUFQe2F213K1YylTtmxzTzYpWpsick2OdzAKtnFIbOpojxQPp2Gyl6DOMveIhTJKObEqGohUi7bqo4pERLVZPJsRum6SuWS7VUYVq5iAkzjtAhQpI0jGXmaIwTTiBLDE8MqsCiwEWC8vPQbLtWN+UTGUJVyHTkFmwQe+HSEQYId6gaD0kVNCe7E1yTmQSmzMDBek0zEtrVAaefUjn5EKwcuhtCfWpOXMQS4QoBSFvAA+4LHrY/6qI/S533e5+u+971POfWrmsU+KBsn146Z11+xZtHsLDJx5eCwwWcWDsQh6pe85MX68A//cD2b9wM4ghUbjjhQp5t2K9wOiRkhTDSYjzL5oY8jbRwkO4vSBpu8hmPkiz8GqRkCbyhjTW5ta6CbfAqvLis54zcxjJgjxZjfg40duWTZVh9bLAJVF7pbzNdcxE9iRAnsoaqmnnS9xlcuFtehSQwMoFO0p2J3ebGxaC9PNuKy1phtVI18LP2iX+SICv/7OiBH8IgnMVBp8FRR3aFpflmHw0HSCUhcUQpAlRfoZDIUAQOTSd45JW3IKSQo1GLctsTrpkOlL65JoR1ig4U3wUGyiOwsgEHgA9kA+6QKCAq21SSKSLWhM2O7ylD0tyvbjF3wRvLixmVUKVM7kx55fO0EnDtI8CWv8fhRrgF//GY8vkzMQsciPjgVd4JgoLV8jky4S8G6wWK/xE/a4rrkbvPwhz9cX/7lf07XuQtcv35dhW54ZoOG/2AyRhYOdTAJEUstvHDIf2F3cXW3zKJ49atepc/5nD+lxz/+8drJe3K4DDC8JP5gp048RKbOXJK+AxMs/BTxxCYcJ31Cy0uR2Za7ZJ9KhqMnS0dwTCOcjcOqkimH42Et2K5m1Drw6JPTdhJP+Cfvk3wmF4VO5CRcg1yGz2T+YruTx7STn/i0wcIndJfuqsFBrKJjSvhNZBOsBjt9qK1XFfzCCHnykD6irFy1SwKoGIst5lAaQgolejuLqxlEymsiRF9WiO04tK0moa6WaEfBtroCQVrBUC7qYElJmReW0RkEPViEDKvoV2OHSvrNArPppyMu3PN72cZPJt228jNIsrENZlfpwKkvLoZlW8E9+Ze6W9bpSpLTiWyC8aArGi4reLbXJsMxr8Q0FsYgN0GZxFDoxCdPABFpPVPSulyb74ZU1md95mfokY98f73zXe9mwe6qbjUn+mQqsrDP+fgQB8rCbWKv5iQEe/FiRi/Aiq/EurPA3/Pud+vtb3+rnvOc5+iDP/iDtMGnsUk5Ho4q8pD4Ct8Zy5dwkzm7mQfogTqv9JKTzAtbMDrMSXwM6kEuqivqorm4D3IVPwPdDNyUx5eCiiBPD1WxC+6UbdJA6UIjKSkF15KaBW545kBKHlHVyoObUS2fa35drL25+pLXhivsbEv0bWTk4cBmXGQlKjLMJ0U8ly6/Qg96QpV+7II/6HvpFgMpq2McZgK6evUHloNJSWJtDDh58s1meaqrVJQkbaInVkPgA5Z+V5IxlR8L2+CUJdrimvR38GKa+pJPCZKg7kIDfSwLjCy8iX7GqBiTmgUDQdleZTBBwREclj1yBiRrXXYSOSTktvno61K5wk2Ah28mwLaqW6dTk2RagiYTMDC1BgvAxDBwlslTBrGJfRbaoP/A9Ru68847dNfT7tI73/FO7KT4yAKrag0w8h/PbJx8ad9yyzVCgQm28XvCGWoWydkZXxLVQeYnp/vb3vIW3Xbbbfrmb/4W3faQhyw70JX/wAgaqu50dWje7CMwXLPAJnnOHB7AXAoQ6i41+ieZVdXg1Fq08WWXQrzRQZ3XVHRtL50jJ37mcMCbQZm5KsPUklax8ucusYGosqBJW1R5HNlWToNtW8bXlDQyj2iQDXQGd58Ww5LFNVWVOQiPXtyjx4AGORWKtlWU4O7ckYFS8hw7y9AYEuMHDqLIqrIuJjaycoXAxhcZmVzbSIeS3AmxAeCUVxLk00ROjLxA0Cspd4kUoSeuBBwntpSSdkrw0hdXCCdJxzpA8Gq34y/yy4uL9V9eTQIc7HTU8bGvN5kJHlgSuau7VnJc1nU+Yckmta1y45cajjklc2vewDH9cC90RJbSbiY6iy8bIX4lq6vVYN/kG59ZHMsGThmDtG5eOQU/+qM/Wl/yRV+s+x+4X+/j2b+qBBRexDXBa1Ubs1M7d42ZRYTGxqZwNfFtaupM7I5scuAE536+RPvd3/sd/dGP/qP6s3/uz7LQmQfi2Vngk82ffCTG8Dyw2IM7ONWzWHf0Nj6yTMjNAtiZz9jFx6FLmd/Mf/rJy+RO5RCnLC74yBhBMAdDO3clGw1LObwm+RD92EZ/or/jLz6T04H/pUOy7VJRdjis+Nd8S7aXfM4pl1nYU0UeDsyNZMXe8ccnd+FKytSMTezDLWXpoRs9g3FrvmW/wks/ctHf8D2pq+CSCa3qBeaShFZzyjYnycjkICS/iK2NwAdJnfEuaRK47SuypYCuMWR0sEEHvTSyORJ44yt6UXHF4ZQILFiN33SWHsEtm+igHNyiXd3KeCbV9AefESvjcDk/O1d0JrwHPMM/izalSEg3AVflDokbEwVJvvJNpQKneaTIITBJbIrtNelWfnTSgeeWSSWJG8nMm+UP+dAP4bn/zyiPL1n8+WYyz8WZ6Am3CadJzdpaG3vxB3sgCwbu8AAt+MV/MPfYkJ5sbHFtTP6LX/IifcqnfKo+/TM+Q5PxJh8uacKlYgufYK822AO5beZoJ46pweKcyxNtnO7oxNbIYmN7YeGOemA3aJoafXSTIzv9wbi0Fij9YEw083JZOWkRq7pkg05p2hmHrbobecZKhb4c6aSddSRtbP7kZifGYLuQ0y7qqlaBN+C/fGK77Il1wlF0Jrp5/2Xaiyh18CazbkmY08JfHGwsbHphgO5UgB9URjvOJs4wWwm0S4jVOWlwWpDqLnW1Ahxb2wqJ2CbpFj/GBfq2VXUKSFz7mpSpxYOxgc6JT8KbWMYfxujOFSCN9SIA9EGVqLNADG71CRsRnErdnJbwnyRlgj2lddJaJemEuzDEb/QK2c1FRBOhFkaBLQTBNQQnJYv1eDzoWc/6Aj30tofqXe9+F1IrMVmSsYm/vCGWr6zCgzjCNxsmvgZ+XYxTQ1F5cx3eyck6Qa/k995zj972trfqa/7aX9Of+JP/O58wXVf0bbxR8kxsB2eq3cplW8HqLuZ2hoZydZXyE7mNTYTApNJVHV45MZo7hx37IQJceNEzCDa/M0ZME54F7k47dVfDb1Dmmt8JWVcFQpLlil8KawBysq2uorRin9gRnfpd5JVHKD4gmIIGeSwGTTuA9motX+Gd7qkgx++EU+Zl4/C6qV8NaJIGnAI2CWBn96WfR4d5dcJWtbpLAiuTkpKFDkBEBLdrcOpOSInLtmwjG3KZ02fj+Xtb5LJwNk6q1PBSEbBtrHTSp2lka4PJqkYzEdMWVxZdutlYqz0QAlQNPwZOvEoFRvjsBGwDilp+p3lgQqu9+Bh+NpMCBirKY0d3K7ZdrepS7iIZnvmFErlkMnBM/4ue9Sz9kT/yR5U/ZLObzXW5TvmVaHQnOY1+gSUZrIuVL55ueNY9RISvXROsfR1Gc32xhapywoYvQ9qYl3LpbW99m976ljfr6//Pv6Xbb789anDZtfRwlPgn9dS+8qlcBJ4NhxNVVSrmZKqaAQyXb/BF/oq+mMfoBdS2duarCl2wBrexLPDYpB1fqbuLUWtLDKimjk64G1tggB1gbXwEnPdic+kGW+gLhehn8aa9j01VpQGXyLpq5TV31/DEGbncqIweec3GwFl3k7cDMU5gTnM8MbBNX4y1Bno7j/y1sTiyQFDV6VGn1IUCCYy8uqSZ1yBhQ0Cs8e7WTsISfEjbjLhU1eouDezjxI5cKpeaz6pty7StXFMnn1JViyHhCtw9g9xtTvW+NiEiVoyr0CtONyttpLwm9qaGJ4GVfUosG9JtZbEHONg2ehQ8n/ykTYKXMW1XEiaxZpW4Jo1CHoxBrgb9Cx5FLrcLRf75n//5uuuuu5QvrC6YgI2cBGtk8lxshgvN4ON2Y2Hk/3+7k/gNrA1+GwtrwnlPvjgFm7wO5KfHp03Jy458R5YDacM2+K99zWv13ve+R3/9r3+dPuIjHkN4k7wYffgL/vhDoGCnoKD0bRM3i2ZKkQ18Z9y2jnlzS3/AN8PxO8OLUuR9h7NkFhCbFj1xVbW6C6zJnM/lr4khheH1skNGqm4lhkL/7Pwcu1ZVqzmMDP7yi+NAD+IdzHu4gQr2YD0MuJ+Ky0rJAbGcwKu70ds14TuZJ7uWvnTijIXiT1yFv+oSpSDPK0YEnqTIJPFBImPtusgLeWE4AB/oS1d6Eo72U2HiZyJwMCcL8ZIGCxRbGyFljWMz8Jc3YDf7xbP1oUu2Nfg4K0mJXxs7+Cx9/LIPIlbeQEuMwohO6wAAEABJREFU8UIsHKmKDvqZzCglifvVohS8stAUZfCM7UjbWDKW8Qmn1CMTQHtQshgzbLBTZ2xn4f7JP/kn9Akf//F6x9vfoesP3DhNEIt8o9gtgWuXNrC6SnmDvbN5cK2iPwFLGSzwxDLob7Q3Flrhq6s08T/gmJrJ0nb1idngFH7d616nh/CJ0Lf/3b+nRz7ikco3zKjr2H1apLLsU4kfgb+DhVB9ZBEnkUmSxe+p5aNa3bW4I3mQ5+IgLjCiHR3b2ok1vCNODMEO/538RGcQ+4RUyiC2cMzYzpxkU0/G8009FDRZV6nxIggFajXL8CFpLG10aKA045DRAXb8m3yNOVTdyrrZGUdT8RuwSw6n0118ajC2SvIMhopEFwCmTDxvkDuwGGMYxUs+l04tHEevqxQb27IpAHYVbYnecprxYDVvpnd28k7wqGkQcHCrGwyruSskmMhToicwizLgkefP6IsrMjubY6DCwiIol9fwAZyu1k5QwlEwk4BgTmFDopYuOKoSIuXqLpoUcGcElCb2JLGiR39iuxYv2MnFBd9IPuMZz9Cnfuqn6m3vePv69Cl/qbjBN5O1E+vOwgiPwYIbtG/wqdaGvLrZCDfWnaEPrWyWBJDHk0viSTsLyS6tfkm2dUB3B//Wa7cq2F2lIzxf+apXro9Hv+u7v1uPfvQHa+LvEr0druKqrmWffAQ3f5JBxpR+V7NpmSXim5RwFfN/QXxZrIXfLFLLSMVvrSvxDfQjOHDXWOPkPN94j/glkdXExidByQcelPWzfBJHwykY8YmZGtkJz9rhDjlVlbpa1S1oLL/tWnVwTGvHVzcyQHY2nGXFdpCDQ53sgi3kB3ByKOZPQ1xWAVpFDVfIDeXqqjXQJjGcMHXVFwAhOwg6TkMgdg1oFU4NCUnRF8AbxOjK+XFaScEk2fGDAOMkCt4ZJLkI8qIEr8CQC7nl1JhNToe5JFJ1a2dRzQBQkuSNBAQsnFayo2sp/SQl3IxCNzEWfOPLp3oubMkoJL618MAlm6CgiNw2eaIt65M/6U/qC77w83X33Xfrkm9+33fffYtPV7MZrvOouPNseonbufwf+GTpwAcGQOhAO9BBumBTALccF7wGEzfIccYvOHRsg7vjdyg53dlA+Yg1p/jE8AY6l3wTnf9+IN8+f8M3fKMe9aj3Zw6JC+bQVuYtMXW3hGxQhK1wEnmaVSXbclm5msPENnEMZSyy00haFMZq6aLDPCTf2aDZDIfjQQcWtMFv6jziVvUJHzsbG2K0S4PD0LZMW/AKZlXkA988UWReWEuJN5hrM6J/JJczNMSckDPbhDNVXRLtgWxjI4118O6MBY/I4VRwGcu/FN5lW/hGSdoIZgGXZUm2VYvQLiObAA8KA8o1mJCJ8QRYMi0pRLPbZpyUlCQHo5skgCGu5SMOsIjpQDeljJBXeKDGRN60t4JhAyipq5REB1Ncg0QBtXwlSQko/hlaQdomvkHX2tkoO3HSIcmRSbYlABYHsJsFEJxIETMW+7k28J/8E/+7PuMzPk1vfvNb2AD3rJyZ2GIbmOPxTGivv1Ac5CrcDsdW8nKkjp9T+4ymibG0Mcm2V1yxZUDhn/zaxpbHFYm7xq7kxng41SVXKzl+zWtew3cEH61/9I++Q7dcu0XJV/KcseT4VCPhNSIALzo7c5gyyGH4Zg7iexJ4E1fmdhX6VScuwSI0aM7lR1d4E4yd/IZb8he9jEVeNk2c45emVlGBOhW/dsaFvLQuVKta4YXhijHy6MZH2sEN97gf/Eq+chjaZIidByJqBmMy16xh08Vj8NKyrNrZKRPhgHwTsKWTM0DijCjXf6mUAJqdJ4xQ17pQ3gg4erE3Y7mVZyyyCSkhE1hpW1zI0ia+QGdIZ8ejmkUX2WA8gU/4bOzg+A0/LJd+cPMst7NotquFnLFqEgdAEgCEAgyEch3gnfEkS7K6W4JTYxM/8Rm8LiYEjMSX2yWzq1wDoAHoJ37iJ/DY82l6w++/Sffee68uOH1z288dI1/AhVf4moltTr/iEcXKj/TAAw/o1371/8buHglZbsX5NGMj/9xs153k/Nq58m+F/vS//2nd/d73qsAYnJKT1TbxP3hfFHxx5Vvk9M/PjngL/v16zatfpUc/+kP0/d///XrUB3yADsSZOFy+mnOr0gYv8Q4OnuSeVMDI6mpt5LW615vV3KUj68Z+SBtzvcO3r/K2UgWGqzTAtLj4ZVuHw5HSpNIUYbutegcfLdlWdauMLfnNKV/IdvAnfdtK3AZb0cFPAAz+Rk4s7At7xvOFbcNJDGatuKw8OqctkmvBpw+yS9WtzGU2S8YrBCypME4QwksVpAhIFjtnKF8oTCZgZ8HZCHnzlH5KdJdzMLLrqXTCEebRFZC4wj6Oo48UmZR+MPImcxBg5MZqkABoCBpLR5HBJ7rCvyWlXX2Tp1fflVor8dFBa8l3kr7z6Ykd6YlL7OOzqlGbwBax7kGm6HTa8oY1CyJ/vvB5f+pz9Jmf+Zmc/G/W/fffr5tful3wGDPgFi4F4fhKu7s5SDbF9u73vFf/5t88Xy/49f+ObE9o+JRu3LiOHz4kIJ+JOXkI7q/91/9bz/ve79VLX/ISPoA41/F4pvgIJmmU8XPjxgNKf2NR9tlx4Q0GX8IXZQ976MP0nOd8sz6UL+eWXbUOx4NkXl6/lFyZZuKzS7l24rCtzPPlFl60yR1iVZtSim/L6qJta2SuThHRJreZR+TJL3TQlJgEmbmhoWYhRn3ZRYFOV6NnJXdarVrtU1+KafCCEROjowcvfE46GYDLxD+Qkq0Ct6qoa3HL+gzmgYOFG4SCU6IKuLh2FsnOLXGBpE97J8ECjC4VJhbkhpbOcjoXeE6brlKw5kJHEaP0F6a8xhQsSuRUaOim6DROMN0lgyUuB2bOFUQlEys6BnhVtQ453ZeSwDFFykKqKgRamAm6EzQJqi5lUdim3ikDPewklWvZ25Z4JWEFzv/jT/9pPfWpd+jVPGbce9+9nGaXGnDaOImC21VxpEveDwjb6uYAmiz+M73hDW/QD/7QD+kFL/h1oaT8R/DrjsHCskpFDBNeO+XyxoXe7xHvR353verVr9Y/+2fY/foLdNtDbtX58ShU2AyHNV514JOn0yaIHW4Xp53V+opXvEIf/EEfqH/0Hd+5PiK95CPbiRzKYExVlCX0h5KL3I2qe8nT7zrlKHeAxGmTDOZlpX4IDH5hLwCN7syik5W6uiT0czAoF23bOuU2C3sTCOvu5DKqVoFRS8fEd1SWT2TZtPaVTtfCd536g2SEklf+5hqL/wmnjYNaDBa4Ft6QRR6ZkUXPgi9ydIyKNeg0i6S7NQHHbL2yY+Eg9CnRnSpIrD6/MNMkuRsbBZ+aEXDbSSLXI0EV+hRMeWmwaE63Hy18Ee1NUoSBEPGgwMEmmYDyWqdzMNeksDElrwWXCQ/36NiWbRUlugSnI7fiPAZMODabZSM50U3fZfhKWOns/EyG64TP2rDwfPjDHqa/+lf+D+XPHF7PQs5jzw0WaXAf4C6wcfrfeOA6MQ1tLOhsmOUL7me3nOmNb3qTfuiHf1ivfOWrFL+PfMQjlL9PidPkIP7zsSDqmsQ0aLz/Ix+p93u/99P1Gzf0Vr7wyuPM83/sxyS4FXztUj5VyqJNPOI6cofIo+fOp0i21V161atepcT4Xd/9T9i8T9XheJAlJUZx2SY3B+XTviYv0WXXKrnZyJVVcpUOrIlluEaYF+pJ2chP5FCSAe62Cn3LitYtt5wra6ELHBTqqgTPNvM51kaebJ6sE5dFU5e8sT+GD7nIHJr5SG6jJ/zmFRdlcOMJrssvmOFLpQoW8uR8S15pFwPBG8wTZrym0q9JxIwhAD5OMbANSCuASCU8Dp7HBwyrWnEuLttypRS9uQJypY0Mm6Jdtqq8eIu2XTL9MjoUGQ//C4ksgpSIJsSFTur4TEIL/7HHSqkjG3CecNsJzgaQl7jCNwtlBCd9xruJi/Z6XcUef1mI0RtMbCbk8U94wvq/t+Q5/pUspjybxybQE7w1KQjW4qG2iwV1VDbAxp3gF37+F/W93/M8vZH3Cwk+fj/swz5c0GQznB61brDIk69925BdUjYWb+vJT36KEu8NcO659316/vN/TP/sn/4zvmx7h5oFeTw704pfVlVp47m5jyxwYp842OFX1XrVq1+p/Cn1N/ytb9Cnf9qnsbjyWKPlI3oXbJhBvBP95Bs03byjAiWbeQMv+UVFp/wMFraVn8HYntyvRTrhgj5A0d9yINLeiG2iN2jnLrcxB6RdkRXchY+ytKGfrmRlTgv+0dmIzciKQWAUnOST5aub104MsFpjEy7VTYwloFVdCy+63b3yaseHVGCWzBCCrg4uZVJILxEXzEI2u2ayOUCC6EYieUMTNtgm2B3yITZRBkq2F4EDk7WToExIV+Hcin6wdpRDYOIHGKAnY1NpN0TXaRQdQ5EiruhTaQNzMgZL2VY1QS7W4mTZNeE2V3/CozXwscoU+uDBZRCPbQVm0mZIkd24fl2fyac8n/5pn77+pPmNv//78BpwL2Vhb0zIBe8Njny/ccECPZ4d18Y/o84bz9e+9jX6v37kn+vn/sN/1Lvf/W4VOWzycH5+i/63/+0Pa2NBRJZaXDtfHF6u/EnJ4913360v/MIvkPlJHpKvu+9+j37lV//LeqT5zd/8Td320Nt0OJypurWzoC64E+URNDHu8LO95M3z9lvf9lbdjf1f/Zqv0d/4+r+BRym4VaWc/tWtXJNEhFPsk4f0VyGPtldu0o+ubYliU0vkcGiS44047JPMNjmjzesm3hFfljHglZzjM5wxVfhU9eKGSzFENSVworOtvJWWH/I/MscoFXGUW+anu9CfGgAOxgfjk7rQCfeUjXylWFp6NVEWiju7KMIoVzULiaCQCxoFQEO+MpnUOeWqay0M47MPEIBoxuO4OgmbTPaOG2Ut0960sXCj290kR8sH8ArRqtLhGBxw4VLs5AG3nQllCIpDthXbhgepETlUguquJV+nV4ENvlGwvBZCfBQ6mMEZTsRV6O3wCTmfHPB4cqu++i9/FY8Md+i1fMv6LhbORsIKv7Z14OQ98rgRnxfcqi2psM3/zvPud9+tH/nhf67v4dR/8Ytfsh5hztAPp67SIx7xcH3UH/ko3vje0AUnr8si8NU+HDm94dvc+t/DBrjjqU/VXc+4i5hKTW7LrXvvuU+vf93r9dznfpe+73nP0wPXeSN+fqZzHjXOzo4wsbKgRcw34xVX+L37PXfrpS9+sT77sz5LX/83vl7n2A1yPKNILoRNYqJSrq6WiDcHn2XaArtU3bIN7V2TuYl58MVle43t5Csx22a+dx2vHkFR0WAxJh5Z6j6oXIp9JRcoTB6d089aFOB2nfyA1eQmPm0LQ4V2OF+Sy501knYOi52NYlndYGNf1F2lrLFgHsjngf6UVNQVQ9qyvQQDx5OVFXLLoQpnc0YF8fgAABAASURBVC2kyBNE6uWoxOXgLlvL9KVBcmyrCxIJDrGpeTFG8vA+SQZiRZ46NiMyOsu3se+WTcKH5OoTD7CL9oGx7nAbi5ttFtOFclKICxMlaNuq6C1sL4wkDzeKvWTlTeRHPOYx+tNf9mV62EMfrpe89CVroYZjEcMgH12l8I/fvJE1nXw69qIXvUj//qd+Wt/7fc/Tr/3X/7r+O4AsxGu33KIcFN29fD719tuV/6BlZ4HE9wUbaOP0v4U7Q57fb/J+3/vu59HlVfqmv/23eS/wcB26lEWTRXWDk/69771HP/XTP6tv/Ma/rX/+z39Ev/U/f0uX3ImyCY4s7CzubLwjCyY2B/ynfYnfV77yFeufaPnmb/k7+uAPfjS8mKurZBz4GLqryYY1yHE4NraTcVIoloUm8oxVtapKYsGOjJOL6NEkp73soxf/G4tzxQxIxoOT+cU41hyCrIcIKZM5il3GgofDhRcuyjgFgmr8ASdTV7cORw4QW7EpeKVevgDauCuFY/IgjJfcoK2GVN3NrxL2wE9VfuhUwCtyq9mtdgl1MaSNZCa4EMYr8qzoK1CaO+8XMhbHN8kY3LRxEkVwwAPMVz4sLkjFZr9KdHRzGgw+/87unoxPxtBciUuyDC/EYErmp8CMfLJo5xrI0Fw0s9CCHzk0VxzZyJd85PdBH/Jo/c/f+i298IUvZAKnkpfzsyN3jG19hv8e7gZvfsub9Vu//T/1n/7jf9K/ff6/1Y/8yI/ox378J9YnPG9/+zuU6xYW/jW+iDrj9G9Om/B5KI8s+aO5d63/RHKD+5C4w4VeFmdiDJ8LFvKE9yte/nI99rEfs07s8EhJvs+OPPaUdcFGeM1rXqfn89Hq3//7f19f/3/+Tf2/v/Xb9OM/9uN6Efzf9KY38lHtA0svJ+QDD7xPb3rzG/Xf/tsL+KLsH+rnfvZn9OGP+Qjlcc8hobk4zdWWwjuxkEplAW18OuhmvhAa/8kvqVbVAcmkadqnYlvrogpe7iJJfjbBYB5Pc7uT46HJgl+bgVzYwTf++JQIW1FCJ74W5JSO3E3MQDAiO62JoZ1FHvzOWs56gmM42FbTptKad+KcgPKS+BVZDRI+AKAfGQVAFtmAXBwNbpX5kif8AiR+hUgSc3LYC1zg4FvdtU4t+GoiC34eM4JTKEwcmToy+7RrYQMsodHnJUs6sHhEp6tllXLZVvXp1K8qfLUmPI1G/Jhg49eSKnbo21a7RaX8ykmQ9iDG2F5wC73nnnv1L//Fj+onfvLfsaj/JY8Y36fn8ZiRx5nnff8P6Ad+8Acp/1Q/+qP/Sj/7c/+Rz/NfoJexSN/8lrfqffnX3vCV/8ld/jAt9dn/svjD90u++It120Mfqvved58SfxawbWI8sMF28tXq8ip2aeOA+b3ffaH+7J/9c+sTqCYXyceqj4fTF4fEf4MN8/Z3vpM7xqv1q//lV+H8ffp/fv3f1F/4i1+tL+Vu9iVf8qX6wmd9Ee0/o6/6i39Jf+sb/ra++7u/R9/1Xd+jn/iJH5ebXEraLvdMweKWvNzsD+bqyJ2kbGW+bSs/3a3kbrA2uhoEXozxW5c8giTGLPxttaXmAM3dMBs4+rbVYAzmbkqqsrKAU+iSEw4IGkZeVYreYL527ibBts1oqRhfrS4JWfIWvQnuYO2Ja+cwXh+Lyyp0umr50lW7opyOfVIIoYmx69S3cYSD6E0SMgg6xT6RXm1x0ZdCRyqc5Ns5sbNPO1xcJpBTYMGZkBR4ZmRe2U2ldQo44xMeE52CC2rrlBrY+UH9SCUzPkiQuLrhW4VGsPCJ/UbihOTI4gledHcWWeTXr99QrnMWbTb6/fc/oHzcmUeN995zj+7hkeOe996r++69T+/jo8/rvEmObfycn5+vv8Z8yG236taHPESnx54z1fIfVCn/JPof/+OfqPypQnIR38fjUTnRbXJIjEZ/EFd1kRJORji/613vVO4cX/vX/rpi191r0eTx6oB9MM7Ojjo7nBGZ+WDiUje4M2Rz5VvnvGd4793vVeK49957eM9wg4nfZFsPe/hD9Ug+bm23Br6aDcbA4n2gfeBxyO3Vl7XqKkt0og9JuYpCfsl7ZOGf3Io5zMKPbqEjW8nzIM586jVYP7hcc1lgMgzcRB18OrFJrAgwDf6+aq3hVsZMZ4J38ilNcnc62KwJuI0GkANu8XFGnkYeuNALj+ReXLnz4g8jOgNiJ4Oih2wpZ0mm4ATgXqdBr3EbHZwkEUob6UAnoBPbKvSQV5eiY6PAL5tJZty2BjUQ6qoMxgn1VAgOyAfL9goqOKfgUCPJk82Fsga31Zw2TTInYBt3s5xCOzt/Y+FnrMDPos0CCe5EMXUeD4IWTgdur3kez6I+sMAOxNrdSkk7STw7O1d0brl2Tdeu3aqc9g+59Vba13QLY83isVegsq3bbnuInvWsZyn/95d8SRZuVWDCpxgPh+Rqh+cZG3AkHxTbyp3pVa98pf7U532evvLPf4UyFh7H40Gn+qjj2amcHc90PB51dlVnkzRcuks5wY9wu5VHs9sechtvxh+ph/H9BkllEe6EPxQuYR0e8cPaUniJPG2c4utJIB8YkPf1BhK5UEpudw6S1JdsvtjaViU+SvJcEtw5+KZUzdxjl3kdzC9DgVk8uqyuUlEyNhkvR1+SxVjjPWtxyvaSDXI1dcIf6NtWc7eJ343+Brfwv+BOOdGVLNsacIgfKsHPetCRzClxIhvAicYk2MIoBjkhBxsFXovMKaCpjKXYcVDKnwbnuUxoXS7nQ3bGkIAZ3eDKwt++ykQOEBbzqj916KOiEy6wZhi6iVjgwCPPgAcWrm1sBsnED2MHJj/cjseDYr+xKbIgjkee6UnMIBmDmtBkWwf0+9g6HA/Kojo7O1NKNkPKGSf9OQvoGnWe7/MnyXncuXbLNZ2dn6m75bIO2TTUWlFIz/rCZ+lDH/2hevd73r0kiXFnsV9c3lgnti1VNRyahmVx8WtC7KG3PVTv5eT+zf/xP/S1X/d1yl2k8dPV+Gkdw5XYj8R0PDvyyc658uXbGYs9nwyl3JKNyga9jbtT7lB5DLuV9yfH45muIc/msJvc7Vr5kNdpnfmjqfgKtmAfnjub4BL+4Tfg6MXlAJ+DzshZEbsJIetJBFdNXPRdrAkW4yTvkte8Gszlk3kPdv4pyR2dSx5JbZMXw2WnLnF4a2Mj3rTJhozu4VBqfMb3AGdSTutO6i789OJmdE7Lhg0Eh6yb+I4O7wEQQqYhG1DRLoyrLZsiJFjzUlXrFMxQdALCMMkDIwmhM6lXoHwOWTiuIoDIwYXfwoxd5Ebe3fxOCz8hRwFNQjQxAO7kE3tE/Na6Yh+9TIpsrf7UuuI/JYFGsPRI4E6J7gl3qqvoFrZNsg4KlwN8jsdM6HFNapJ7fn62TtczNsAZC+yMRXdg0xypy4VtK3XiGhAOxhd83p/Sx3/8x/Nx6mt5s8njB74LnslxV+PX69nbZlrZzDubNBNbV2Muo1PKP4/4ute+Vl/HJvhDf+hDF8fmlEvJhssiDp9wSX12fuKdO9WtbIC8Kb/11mvrzyny7ezheKYCO6e2beWqhj8y28RyiEhJdO6kiYmQlJwxrIbfUiDXkQ3ma/UxMBgS8dDGAAyUcBE7V7FOxlVhwzHU+E0R16Ea7JKNAX2GRe/Uv8IN7Klk7hotgzfXo1+Bb1vVWAFhWbkm5E27GBtrPWHLQWUbijP6pSyWTMDheEBVa7d10XZJKIrLFPEruqtwGsSZEE4mUFxZaKioQgZ5yNpIKBk7go+amsUDL9km4fEhjQjk9ROy6WZRsY8wgSi/gxff4+r0LlI0CWpncU0MgJP4leRRKVe5FTzbis6MrfBj4gYQsbKQulsNr+TgyMI+40Q7nh11Tn12POPEPSqLLf0mgV0tYNQNDg6DY1uDBbH+avRTPkUvfdlLefa+LlerqmSbjXQuyRLlGgt040S96f/8eOQ03lSuNQfZLAWnV/IolMeX7/yO71BwGq7hGH4HbA5nRx3J7ZH2OVzD8fz8TLdw2mfRRxbO2ZhVhvNBJEOnDRcuqyvoUZyhVehoZ2NGY5C3+CbNiCMRb1aZVfK/cXIHa+fToozHByNkV/igNbQu2w/axsHANgOTemcNBWMEACGa2shNcmD6J0wt++RLoIdTcnHoxMOYSjs2kWdcXLZxNTXwkbwyVcoaiE4KdwDJJZKCcYK1lYnOrSiKOwv9JpggF93q0pFE5xTJWFUWwdRk8uPAsgI+0U9fXPhXnsWqm8QN4WbpXOJzJ4HpH7pUNAq8rpYspZhf1ZAsWlclfsMlizZl+ZPQ1MINprhOHExidnqSq9CZKnAaH90t2yv+nELHw1FJcORHEpt2FlbKgUVW2B14k3hgYR7ZCBgrn6Zk8pKzJz7x8frcz/1cvZxFK+KPzvnZkekiP5Iu+Pw/ORlM+I2L69rZvIhXnceLs7MzFs1Q/tYo7ytinzePv/d7v6P8KcX3fM/38Mb7Vtxa7YJr60AMR3ifOB6ZmyMb7UxdtTZww/OMzZHYy5Zgwy+lteF/rjmWCv3kLTrJW7h1lxr85KEYX0YYx+fh2LSsrtIpq4lssnB3Hfq4VEtSFp/w2eRs0ndZC4v3cfGfhZlNW5HDL5naWchH8iaubA7byyZ2GRdX6o21E2xjm5weDkdGrB056V+5NJL4oNJkI0/WaebPtvgUaEc4IZlFEbp/0Ha1ukuJJAmxS84PhknOGiCwtfiywhkT10RWVbTEp51zSQuCmHHb3yJU8MSVOj5ingWUYIM3WCAZm+hkce1slPQxVLlV1Wnq5ke4AtzoJuiqkilLHy6mHFgE4TUJfo3LC6O71FUS/UxQ0Y7uzRJZVzGhrWYhVKU+LPzwio9xlew77niqvvzL/5ze9ra3KZ8WVR3WBMgwYLK78MUiCHbRDpemvxYI5CPfWYzpB3djEVx/4AF4ljbi/83f/A191Ef9b/qGb/iG9ca7iekAp9gdzw4sehY+i6aRBTe17WUvrmIOwqWQJa+uomtVn+r40LqmXFZXS2IxsWiyoDI/k/YgyZdsnMxTeO5wDlZhM5lIY3PJm2JxFfEhFlOg6JfJBXMAhFxSfGduczjidelNBoO39LtVLg1w438jJ0uOrBc/Kf1wj12+05GtYsxFTZvUK/YTjCM5k7XyKcZKXPhTCFanyyiygK4VlsEhVTEJOLetkcWZZ5OJoiwhC8kssC4w6EeW4YF9sKhWINVeu9PiB4KZwOjFt+3QkBiLbKxEpYWEMTFq8AeB5I/cEpCQTyYg/OIjOoMFCbqia9OiBKuqZfyLK1xzCsQmvhsutlecNjayRN1Vil4zkYc+RERaxqpty9hlcTz9rjv1ZXz2/vu//0Y+Rr1Ph5xEjFkwYtE0aclEEwKHwOXKAeEpmDduXOi4TkyUlv5c9he8IQzvxrddPE49oJe85MV6+l1P17d/+7ctnOrWEV+5ezXtrua9y1F1CxlUAAAQAElEQVRVpaZvW7webEeejSuLK1k45TcLCwGxTeZ3asI5eZ5JEKSjFTxGFJnNoiTv3aXgJweFLJ2Bje2FM8ApuAQbQ6U9mL/gbJebnB/ylPHMW+R507vzOCUSZBuzeEcTHH6D4XWw5LCMafhMdIOx1hM+057UtmkaL4UdnOEW/UHdGBejDJiKWxe7Oq5CGoGyc1JX45BFtQxxlEnDXnm+7DigE0DjZgNj2SMrxmyrqwlCkN6VN6Znx3Ml4TsJHEkGdcgmeNuSpmyfCr12IRF3E2vpYeNChg8bvS4NNqWLcWRVhS1oJGBxkdRdykKefDxqW+VaHGxjO3Q4HtE5yNhm7HA8KM/RRR+hVi3RLHUdlMWcWC/5lOsZT3+6nsUXTvlDuAce4LEm/HzChYg2Tu/m5EmslnWgHR8Tzjmxgn3BiblxwEw421baltRrEZeO8LkOdj7j/53f/R099alP1Q/+4A/q4Q9/OPx3TWK3g90rV+3koJavZuOKvBjZZP6qrEI3CxCxcpjYVhdlbTarrmojO9kN/Ax0etkOuGcsC99V6i5NsC3ThoMlIJdsRE5np84pXrRTYpOxXjFKdYXjLp2d836IXOysJ3F5Cv87ZYCp5SMY8X1A/0h+giNZuQa2g+C2ZY8xwvinkm11wRcxGFZAkOo0KZw+nYWAHAW7tK9FU4wjMxMLcDbD9Rs3FCeSJdI+18TX6oVAZLZZ+EONissqyCbh1b1IlMGtlhmzS8BI8qpYwqse4KaRfsbSBk62V4lfKMFzV2px7WyqQacIlC7yyeabqsYHdhMQMxD/xyx+1+Jje2EyxMLYU1HQBquxLcYz6TsJvsabzC/+oi9Syutf/3o+2kR/SiUrh8QZuBgrHysa/Cz8E1fwLBbnEZtN1U0hz5ks5IPFFf7xU2Xi2tY3rMezI3oHXVzc0H/7b/91fUv8rd/6rXrMhz9G2diCW2Ju8IwdXWIeK/aM0ZDAt/lFo682YlWvoYlsY7OK8eBNcRF3tMOdnjKvKTZztBSE7RRrm4zeFKCJnWJIM6/YVFtVhb4wooCR/o7PEQD6E6OY5aC86RNNbgqT+WnZJ7+D/E9sYisHc0ZNkdlWcJs8NBt5wqXIRyFPTl0n/WAUYxgNmZ+qGHolfMYBIRlZAGYWITobp5SNXkqVRC30qlrrshbZYmxAcMYBsp22BfnU2NgWZjrhSTZYiohksgAmCzjjiFaFVDexVs1AJjs846fAs63ATCwSZFcCBRMO0dmJCRBeU+HXJMhlFKRq/Fuq9K1V21J0uko7i3OjDDAmucim+Ytf+ZWcxLfrxS99KYvyQud8RCoL26JI2egHJuDscFB4ikHbgo664AbPokYi22yG06NRJmmQ58SXE98yeNYgdxPj9AccXvyiF+mDPuiD9Lzv+77F45K7SFex6HclHhu7LlHh8xSzRbisFWDQG0p/EFOhNMj7oXvpLj/FKLrxZZeETuSnmq6kij/sGVL0gjXhZnvhJH80tHI/TvoT5zkUJvHsxLnwwMqiF7Z/gCOGrMylbQU7/miqDB98J79rXrDb85SSnHbJcLctXCnXIDbAFP2ZtgzeBMcZpnCP2QBALmFowMU1kBXtql7GRTtfiMXpJPAEU4wVDnOipA+URB/zB1+2tbOobQNvwZMXBLBNchL8CupqvJkIoWZ+GRSv2opP29rg1VWMSEuX8WVPbYqIPFwm29FLj5nEoxiLPOPBSDsJD4euUlepKJijqTVxgzgPnOaRR+9Rj3qUvukbv0GPfP8P0Mte/grdXDSX24UKbgPjOhx5bDmTzYLE9RmbgyHFb7MhBpNfZSaBuxbtgY9soOTBVTocDyoMjtid8f2DuKqsEtFRd7WyKV/32tfo3e9+p/7xc5+rL/riL1JOzbMz/PL82uTQtnI5PPBj04dP4p4smklObEOLFnIxXOAjUq1fhbnZnBeLe/BNfGgrcYZ3V2FmctfLv7jmklhrneAjuUsZLD7DhSzLtiILVpUl9HbWyNnxjLa0szlQYaPuq0S4RYZuakgvDgdyjSl4IMAtnCb5HBxYXSduiytrJvOXdVJgrCL8hkAAKt6mVuCTZMXhjAKDK1nz5KCqlUnM+LJhfOc2FkIBNTaxt40Ioyii00yIGAvBQfIHZINrF6NTg+Q0NjJadbLNuJChunRsKzhVRXJ38AUpCi/bMvXySFsUsxDWosKHbRncorhKXcRByQIu6vjAXHlDaRrNo2DZCs89yaN83Mc9U1/zNX9VGxP15je/SWdnPJag05z05dLx7EypS9JGTmyzEQ6hosPxqI2JMZEgZoJ3uE8ldzt4236pJkfnLPr8AZcrKFJO9hMmMY9N4ZTn99yFMk1vetOb9YpXvExf8eVfoa/92q/V+7//+y/OybNtHdhwpxhryXG6+FQXtVXVEgF3MQ4P6ClX7CcOgFgYxfjGApwIwiE6KZPETeYzuDtzKMabYvTju8hjVzFXg4JW9JcTK3gDn4i07Lp0gw8FxHVgYdtWk9uzs6PCt6sUXjaEJTbGUO60rlMf0XploYfnTd3uVvh0NUfiXBgTDqD5RCqdIiEADYIu6pBiFF4n8JAtRzIVyWAyU3b0J8pJVkrzOXkXWC5QtXSnJExXKcbiNLaYEcXQUpQYBxnl3Hlsa+lKEN75nXpqZyHGTwKIcGdRuAQkONiAoJSFSSPcBhMTLNuMFXgD/SBMZYEboCqvBTiYzOoWiKc7ABMUrl/BR5yf+imfqre85a18Q/s2JaF51jdJTRzNRHUVcoM5dKRvSGSBA7ZeHd3I4DzJ25rkKiW3J5wJr13XbrlFWbSohsayrT7xHti5LdPPaWxb+ZcnXvOaV+spT3mKvuu7vksf+7GPw5RE8nsQ+2DaRbFhhPhw4A4Dl41cCh3bEiW5SrHpSysOySvngyALeVeproq4os+QBrxmCp1Lvu/YOYEv+ZBgsE4QoWm54n/ItrqK0jqQp0ZuaeWbpkiCFsagif12uWvnk6Gddnx0N9rJ1VxYkUkWsCJM0VKBH99ZSwNexeBgbqPrsnIVECoGkCsDgze8CSj/yaJIDHb8hlgUsNhZDCKaQTkcD0odPeMsWLYVnQHRLMzoRo76eiO3AphSMwFnnIioL/wqq7oVO0UoK1fw0zocjhJyoxes1Icu6WTNSTC1ODA4IJ0YivGq0qmADfdMim0W52El3vIaj/6Jd3AM7QkXCgvkwz7sD+k5z/l/6cMf8xi9kY8577//fuX0tS1RCk7lLM65/qWGIyfeJH4jD//8Hc4lH2n+9u/8tgTlpLKqF3PMVQfLyC3p1ltv1Qte8N/1Ut5XTBQPLI48L3eVkruuUmzbJfMjysgCp+QLsxe9+EW6++736B/8w3+oz/iMz4DnGSrY2BK6RZ030zlEBhy7W+FI2pS+jR4v5UKYZnSjtzxWr9xEVnCJraljpuCD12VVtwp5Nfr4yV8HR3cwB/Ff6GzcTcQ18XP6yHcod9+JLJiJfXBQMJ1SISQfybOr1lqyI5QG8mA86I/Mhh9EpRDDl5BtbMgJWPRSN/ZrA5wcWjtAQlGWAr2c+bQI0i7AeMm2LGlnR5pW5GscYlWWGE8yI2sWg7gKwEIeoiG8QSY6tuNRscniHCTDEOMzT+UCLZVQU4gHo1kU6cutJsFVVmSDRRCw9G1wCTaxiSuy7lKz8RhSAHGVauUpcRfj4prY5X3O8XjQp37ap+grvuLLdcFt+bWvex2PMDuPPWfy1U9ixAQedfoi6pZzBSdxhMtDbn3I+lb3Z3/uP+iFv/tCHbp14tLaWQCuWkhdh8Dotofetv7toX/5oz+qX/jFXxSDLOLjqg9wF5eJN9x3NudaRNNrQcRn91FvefNb9LKXvERf9VVfred887foY/7YH+M0vVRhF7yciFXxK2Kf6itO9EDnN0njJbvlk0SZL2O/wzm2KZOFfXY4KPnMvArlfXHa01yWoOmkO5csejuPhjsH7VjrDQ2CSR5ts5hPfGjCTeTroPjJWqluoar0caVg2dayhdtg/oPdXcvnYB4Tq5Zng9WyzbTMZZvxqgiCqhBJCVGU8JBgiiQk8VW1yB04iRsiIC0nkU9s43yAg09AEMgCGpshWjhE7Jtyn2R0rYJYMTjBI0AAQjp+LcQUAbSR2AVCP4FL5ic22EoaTEaz2QhNDCjXJMEpD/YRTjhOdGkKWLmsbku8grExwRfcvvON69d//d/Qxz3z45Rn7Lvvfq/KTSlNo8wrd8Blp6ng2F7jom645G9x8t/4ZjG/4NdfoJx8167dqo1YJnFahvdkI+S9zKDNCciCeuQj33/9i9O/8Au/qB/+v34YuzM84MNC96RnW7kjhHP45juCxNbEM8C+59571n/d9oj3e7j+7t/7e/rzf/4rdf/77hdApHFqkJtwFtfGF1KnhXOQwO0iRjhGeZCvrlZX4ZuF7dJgoXn5GRwIQ7kKHYCXXqE7yPHE2arxdcqZlS/tTvpeuVpzjX5sdHVls2GOn0GM+MSXTfC8msfrKzXNKE16GbtZo7Nzl2nyeKQE9wC+iCP5slGAcvjPkioBV4QodDkxq65qmz53gGAHoKqYvEtITbqTGiSCPLIpbKsoIvkLBNOdXW4b0ULgUHfcrdLdogfetk6nHdIG32Xllp9JveSksC3hw05tVbdyZbI3JmlDZ+Jzkoxs2G44IluJRzETOBkX9hmb6MmZxEEMKEBtwHPHfwT50+H8qwx/5a/+Fb7RvVevfe3r1sTniyovHuJxa1cZPkwsvxW7AtNtHXmsO5L4hz38YetflfhRTvKXvOSlfGu76Q996B9SlWlfKvzwriy8Cb/EEY4XfLfy2I/5Y+RlVzbdb//u7+gff+c/Vv6jnMSXx6nEYXBCYZUqnfNJ0cZddckZq27df//79Fber7yUb48//ws+Xz/6r/6VHve4xyl/2l0xJPbO3bSsAiOL0ZLCx/Rtq8E5cbWygApZcr94i4t1M3gS2MifyyuuYGQBDmTBRWXlLLgbB0zwNuYuejkUoAEQL7AjL5dmcpua3FjWktGO36qW44v5YCUyqnUFf70nM1zxc51cZuBiu1xxpD2CW7RwOsNvwo6XBr92HOSNlYC0rcIJ+hrs+OjBihHIsYiKcV4RaceZ6CQwWdCSbGNf2I7VFhciMUwyJu9TptI/BdMQLE38dBWPEmeUow5MTvxaJgEWlfKmSly2ZZuW5DKl6Jd2JiPJCm7qrlKuAeecdNWFHhyJ15Z2JuKBG9f1qPd/1Hpm/rqv+1o9/vFP0Itf/FJlAe7YJTfdrdQbi0zIdpInWYMEZaJtr8ekfDkGtP7nb/ymfvCf/lO9/GUvXz6u3XJNf/gPfwSL8gEtLvi1zaLaeXy5lA0WsjzH33nHHWtBRy//ZdfLXvYy/dAP/RBYL9ORnIRLeGeyobJsk6dwDT/bK0+WdZ3Y3nv3Pfr1F/y67rnnvfqmb/omfd3Xfp2e8IQnnuYJna5Sg1vUdJV8zoxO4kvn7wAAEABJREFULa5VnVCV9zZ75oi7W3Wrq5Djpc38iDhvzrWJa6jREZfRKwrNhb36tqpbWdAiYeFdyLoKz1OiHQ6xS2yX5N1lpb3xadlkrSb+YCVuYWUXB8cGHJZAHI/c0ZTLD+YYNe0ceMHpLsWbjE5XYzho8UJQZVURoIBGnMkYOKWnGGQsJAbkeSltQXpjEi0rDuiqjAsUgFvJvCkXWBuzN0noZBFNA4vuQCauFRRBzPQZo4lUOnALzM4d+BF+xBWbCV5wHEfctXY25ZJjGB4QwiWB4AiRIrvBG9PjsfXsL34WHx/+dT32cY/VG9dHiq9cC2jKsq3EuoFHJ/lT/mozE3KBfXzkFMvCzd/eZyJ/5md/Rv/63zxfb+ANc/IT+0c84v30mMd8hDa+K8jdZBJXbFMnR12l4N977736sA//MD3h8Y+ne/L/vvfdr5eyCX7kR/6F/v2/+ymmYOrA4rG4iDUh79mQyQG44XWDb4sXNrjxt5PnPMq97OUv04c8+tH65m/5Fn3bt32bPpDvNHKnCFaDuQKkkzapuuKAH16DeQrXndwP8MIfsczP4fAHi+0kzyKcDFPDabIGDNEJx4FtRjbu1NvCmmo2YPCDbQcxYQ6mDU36fcWtwEjswduYE4aUkhwvfPzgNMbkelO4THwuRBQzPDl+I0/KyjbPcftSPB6OivJgZINYFuFMRiw1AVazmOljxC7a8QM5+pMARZ1XyIVkdKbYCAhtCw6yLX5ppIP8pKPTJkF2ya3KLh4RTsSD6W7uGCQCHxunwAa3goerlGe7gdziB+wkJVyqWkceRcI9suga3JwYicmSbrvtoevf+X/Oc75Zf+xjHrtO13zCk7++JAmyTTXYCBfK5Gbij92CtoKfDYgKeiXzc+ut15R/GeK5z/0u/Zf/8l84be/RoYtTkDdxU7rrrqfx5vlcN65fqMlleKSEH+a6zre4OxN6wfP4W970Fv2lv/yXVwy2Vd26fv2G3v6Od+hnfu7n9L3P+z696z3v5pTduVOerW+hD8dWrpyoB/QT6+HsiM6Q4RGOVa3777tfb3nrW7hD/YY+6AMepX/BI9q3fuu3rT+17kMrCyQxBkcmBwiyFoJtm7kDjzp4hMU6GCy0S13wvinGk8UV3fKJT+ILn+hn3EUL+8zT0mMeeTbWZP5TmrvLwGewj+QptVGczPPNDTnQLXASI/sfW+mCj1uTP8uhr8RqdKpLiaupDU61ZVvdTS3VANiO0VzBxCiETtNqlKwgPqgHowQVkgHpKglHNrX14LV02ESxTTsgq74KLu3CNhgximn6g9Mhsiw6C17BQAEz0Q2MYhvcfGple8kTfOxT0s5msQ01xkWC2Fy3XLum25/yJH3BF3yB/uJf+Eo99fan6mU8orzi5a9UsFCTsDk/v4WJ3pWPLsMjWBsbj9AzvPxX9crXOc/eD/CsnTesz/ve5yn/jOKO7pFvM5vJBE4f9EEfoE/+5E9S3pgGg0wRx1RXsXg2ZbE1irZX/6Wc0nfeeQf8bod/UawGa+Oz8PyH+r/B49Vz//H/V7/6a7+m+x/gI9mzM/gOmXnIZGcxFu1s0maiJ3Oc+ZsszuIOmiDyv3J91aterV/5lV/WB3/wB+tbuCN80zd+kz77sz9bH/CBH6gL7m6T3C97kj9ZdJOkVy32Emm1rcJPuGm1S86PC81EKi5iAkeM0xEDik5wuokN+8iq0sZu3WW8VJPHwm4is61wGPAYKx7YwCuHSJSbOA1yvBpBbKIvdJKHzN+yY24cPeQ7vMpXjkMg7KJkt2wDI4VA5OmMRSQtq6tJOiTEFTAWrlcTGf0Qid2AcE6A4HslBiVeiJUAQ9Jl2cZXqftAPuZqT+SxWzud8fiUg6p1ZazQSZC2uVPsGvi2rZuYWcQf8KgP0LO/6Iv1NX/l/9AnfMInrH9tIf/S8yte+Qq9j8W7sTmiJ5tFfyFZawFc8LgSHzt3nkOXTqfMnmGd83HnQ297iH77t/6nfohPav7Tf/7PnMrvUTbMLXyJlW8um0nJnehPfe7nqIkr/6vUyeSpavkYtKMnLrtWPmKfDffaV79az372l+jWh9yq6tYh5XiQ0b3/gQfWm/Mf+/EfV/7x2zf8/huU/+g9/wlk/Jyx+YI9XaSG+SCjBX8q7M0d9nLxpCNC1utf/3q9+lWvJHe7Pv/zPk/Pfe5z9R3f8Z36uI/7OBVcTycxM8oRHDTb6jpxsbx85CS2TQw7/YFU4GGjU71xd6MpoRNuWXyJk+lCf+qmTFwTYabV9pJL5OtKnvntPvVjEzysGfVV0cILRncvWREDDaV2gOWlw+/cAfaMqXBWXbIDNFEQba0TKUCZAEYhxBiZjANxZUJtY18KucgHq9uylh231Z1dt/PmdLKB2HHqyijJIdDcbYKxsRt3vvRY6OhtSRgLJCqn0/mkjyu40bZWspNI4UsM1FWgE/9Q1MA+z8/3X39Av/t7v6tf/x+/oVe/5nXrX122vThHz9065xTNQj87O1+4ecOXcp1PEjYeS+IneNWl4/mZ8p8pft/3/4Ce/29/XK97/RvYfENZgCkHYk7sjW6+kb3zzqcp/0bnTh424rStvIdIySOPuC54Zs8mvORWfoPvHF71qlfp6U9/Om9WH68iLpOz7tZN7I3n53e94916KZ8wfdu3fru+7wd+QG984xvVnPCFbuI4tBX9s8PZykV1kzsWZ0nVzBd52rirZJPewG+4vfa1r9Zv/MZ/18te+mI9/P3eTzk8EjsUsSXvTMggjp35WfOJr4nMrqRSVbV8ZR4xWG1jHDlLU5mbcslGGjjmyDf7kVF2cgTksj0cD1iDhqCrmDMj16pz+k/WSvBSBz9loht/GwdX2l2l44HYF0OtNZ3xPhyCY1kCdCjKaQsJPBQHaWeiQmotAMBQ5EUiUbKtBIUJL6xJCCIJZ8Eb3BkmJI0coQZt8i6hFBIjHdpdjajAAlfUBDGRE7piPyVsyZi8fhAKF3nRHMo1sLHhQyeTef36dRba5fo8/Jd+5Vf07/7dv9PP//x/Vv45w9e/4Q26//77l/3ZSrJ1zsLuLtnBmLrGc/3Z2VGydPd736vXv+H1+vVf/+/6lz/yL9c/pPWKV5zeLOc/QM+/EpGTP0lNLLG57bbb9Fmf9Zm6++67190DWGWxJZdLh3CMYmK0rcFi2FlY3b3el72au8Df+Za/o/yT6VWllOZOksPoCK/qUu4G9933Pv3Kr/yqvv3v/j19/w/8oH71V39N+SO5fDdgScezA7GdKyd5OGZz3MKnUokvHI/En0eiV7ziFbzH+A963vf9AN8d/AP9k+/+J8rjmG3ZKaQczvFrp19rjRhuO/Mc/rhTxiexFHIMlXnJGNOjgd5cWZecNWELVCQA54XSgYUZfTE0ODgzbnvpoKLBGsratFFAYFvJ2chauurHNjK6i+MlB4YjRHBgMwz4bciqMMan5FJTEgwrCieIJCWYrqJl2g2EJVsJroq2LHepbGwGJ+GknkDMVbtKLq9TVeiKi64mBGiqGCcymjALEddqR25adn5rWWZ4EKRtBTd3j+hVtWyDOfEzNFHcOUVyUkW/WTT5Jvcd73jneub/HzxD//Iv/bJ+6qd+Sj/5kz+pn/7pn1EeYX6eb15/6Rd/Wb/0i7+k//zzP6+f+Zmf1U/8+E9yyv9bPf/5z1/6v/ALv6CXvPSl67/O6m42yS265dotLLLjOm2LeEyAOc0/l0efR/N8nT9NEBesycmA4774ZmFOgh/kwjZvaI9rPI9KiPWa175m4X/7t3+7jsej4q+78HPQITVxZVEPcpI/m86nPL/8S7+yPu9/7nd9t/4/vLn9B//wHyl3qn/1r/61fuZnf3bF+cu//Mv66Z/5Gf0ob4C/87n/eC327/jO79T3fM/3rn9e8TfJTzbErXyLncfPHCbxsXJKbhNb2skzyVZKF7zgE72UCacs1EIezok9NjlQmgUoWaIMYhexW06X35MFu2tgH4zk0i7lynzGV9pdTQ4Oqi5SNWVbRd6nuGiv9ZEmJTk29cadfHGmHb0GowIahcHO3Dh98oZhssPAQE1rsgZBEyW3jksJJF44pUkjY5PxBGcGGxLdEAYg8gmuVMptKhvF6GT3NskKZgKalhYOYzP/0NUVXsYGCcopEKx86nPgFj/gl7F2U4X9XPgTeeIIl/w15cYmsK0jCc+fFOdk2bgtvpfT/O1vf7vyTxv+Ph9Vvoo3gy984Yv0u7/7e/qt3/4t/dbv/K5+7/deqBdSXv6Kl+s1r3mtfv+Nb9K73/0e8jF0dn724ONOTtJzHp+yUAx/2yuWP/6Jn6hP+aRPXt8i75lMYhrUxwMbpVu58rgTTnl+vuRTlBt8EpT5qAID3ST5F9iIT3nKk/WlX/qlysKpKtlWk7/D8bBkR+oDuFWtSzDyb5C+6Y1vXu8TXvzil6y71s//ws/rJ3/iJ/Wv//W/0b/4Fz/Kxv4J7oa/qN/8H7+p/Huo+Z945H/8d51Hvlt4D/Pwhz+c9x/XdDjwngwuyevUilAN/2p4wHPqdA3mKTEcmJ/Y3JxrEUTBN3XsLnjkCkeglAPMZXK6UYZso00hV5HjVgiUK36K2CdjTLryWDyZ7zCKTuY8es4vlHdO9zRTwm3EDnycsHFa0cvKqQQSJRvHNBDIpo1327TF4qIPaMYmgQYszgc6cIIPg+gGUEJ3nGwSMCqabAKjmMlNRKROqbGiRpfftpU/mFJ2A/0Di3Zxpn3iaD7D4HTg+RNNTQaHTgjhtG2X9GCAw0kJPqZrssLj0K0zFuo5n9qcUZoFNInlkk87cnrm3/i89557+fb3vqt/BvF9up9HqIuLTbLW6XyNT5FW4fHhnPY5b4TDM7FVExUxDDCf9MQnKt8mv5xHinw/UN0qxprFkYk6sQaTjbRx6GSyq3pRrj7VO++Hipyd84nUr/3ar+rLvuxLlX82ncDV6MTvqokjmy+bYBViPHK3qK61qK7z8WneB9137/t073336b6rkna+c8g/95gcZNE+hDf1D+cb7Ic+7KG6tmI7qBruZVWFF8yzWyXu9GSfPBdx0ZVdqu7lM3PTdVg8G1nGmo0UvUOf9GJmWazhpZe+mNNTkYrYy7pa6PhFMYeXUKSn6MVP8hncQnmikzYqcn5oTDCTn8PigRnzc4PDxo6G8iaY1YpVTuiUwWIdBDZQRLyIxCFLC+sp4yjyLOadxRiftjXRp1qLcKedIpwnARODiWJjG9zsXkSyzWm5WvkFPi9sVmfVk/GpHU4JEHAgJ3ZoTHThOSkRuIqq1jhDMj+1ZFaxSMKju5SJODse1mY4np3x6HIqZyzGbJDj2XGNnZ+d6xY2yjUeb65xIuZz/pyM6Ud+xiLratnxRKEOz0fzJdOXPvvZegef2ecxQlz5w7qqcJMseBNb6tySMzET6U4c0Ul+TJ4S10A2yGXuWG9+8xvXJzMf8qEfKtsqSmyPxHKgHOHzIHd4J5bz89n4Y2AAABAASURBVLMVy/HsFNO6+xyOiu5Z4mORX2Mj5/1Lym0PuU2pr2WDg9EsmoKonXkaOlwdSjucxBVuWYAzbe7c4WzitM1G2Hhi2NZGWTrYDNbAzobPPGatoQbmQcGpag3yEh8VDDBTR2+Qh+CGt211MdeUDr8uDbB3dNZ6BGOwXlxCvq9cncb3tTb4pWZwQiJy1IRsLGXlwgEvBRwsTYCXIsIEGtlSgwDomgiik1qc3l2lKjNkbTyCRG6TQEguHEh3FYsaCsiaAFZSAC3a1X9gm6ALXYYWljTBLnzSAhME2vwGJ9jxFY6MKsk0PLpbhW7qA5N/xkLJJkg5y8I4HtbpfuCESoLPWRjnbIxsiHMWwfn5mc7PbtHNBRO9YFWXDDfbsJqL36M/5NH6xm/4m7r7vXfrnvfeoz4cVd06UiTLNryGqhq8o1zWzpu8wYSlBE+guYNtiVeKbb3uda+nvFY//MP/XB/5kR+h6paxL7Cadko+tToSRzgej2f4ONMtt1CI4+z8qHMW/Dnt00Y+1y0s9GzsW2+9ValvYfyM2A+HxrfVtmyLX6tNptXFGHMuriO5jH8mgV70pg7N3PKYiUCxu+C0Pc1LxshH7CXlrnODT7ty5y4X+dvUsc2hSg5iE/s8JiUnkzlu4rSMtdSFzfLj1Z9sruTPpg/eZN1WHU5jPDvkLtDgs0SZgwkKeoyWUa7qB2MImeqWjQIvyUIJSpKNgOBtL5m4aMplFYSc4aWpdUWWRuTBtaOAc3QLGwCVhVv4Tw10Yl3YDYfITvYl8zOvFCYB5XFp4is4kaedIAof8RV725hPpX0AL3XKWiBroRx1YBKPxwOL5bjKkf7ZedpZQEdOS2o2QRZWVyu2LviA3V3q6uXjyU96or76q76Kz9TfoHe9811M6B7GanRyx8tE5/0VyuqyrjP54b0CnkJWunHjOsNmU+wrL5csHjGRyYNt3sC/VG95y5v1nOc8h03wh2WXgn9gwTbxhVsTV7ienR3gHv5HNjAxHM91zuI/Ffps9Cz4c+rj2UkviyS5s6wsoMGiSsrjH5FS7xxqkOR14inmgA4n/Y6NdMEjZfjYVleR0zMlX8Hdc/rrdEV2PDuNLe7wd5wwHF0q/J0wC5zwuMyC5xEsthtYtsnVpoxbhX9WAfkq5OIaHCykFrm0w3tjcy3dhTdlWzUT5NpdJclKf0e5uiAAIAFWNe0hmoyLYAf1lCIwdrCblB0HwGkFsPo7OgIVXHSNY3HtBNJdJzl68EAqfMSfFlnUGZcm3MyozW9K8DFR/BmNSXEZRZRoByH9QrerdOQU/v9R9R9wt2VpWS/6PO875/p2VXVAQuM95gRHiaJiQPCogIqgooiBdJVwVEAB47ki3p8R7vUKIlwPiAgIkhq6m9hA0wm66S46Nx3pUN1VnaqrU+W9v7XGOP9nrO8rOPObY40x3vC8YYQ511xrr93dim3bCi+LYWeihx7+fjgo/X3PxGAy0L+gHOhf7LuqrMja6KdgBweWv7nN+cRP/ER9zl/5nPXNy+z+8e3EAKEoRZZiMITuZIAe5Zm/OI68UWsm7yCgTK7YTO5sKzZtr8ehuVU6MSYD3Xy57hYL5du//dv1kR/5kUBamXCJqcjpvm/EsuHvuc6kXouCOHbKYZUDi+HAlY9CnLlyVBU2GRNrYdqm3xIDUbRxUfGtymBnPpw0GIzEOqXlw6SPOuOX+aHFX7jRB8fonog5dfI3A0rJrSMQGox1sBCFzUgSb+yFd4J3Yt4cr95Ex5fou4q7CeYmhjdyKWwIgPAyHyFrYzMIduFHbt0BXzEGt2hRe4EMVozk9XfJByNRQIeAjgJTOQKMwNlZnJ8ErRAoGYA4msQYx+JkDE/kgjUISAC6S5e8uSREWeejq2jMhZsEDXQUWehpCkG6ig3bsksZ9AQTPiRVt2yDMeWy4vOIfwjYZuBq6WQyd9EmYV2l+BnatjcDuat9polj21kQlGrLyDq8wgaY4kr0lz77L/KJ7d/gA7Y3rTeZGzvw4YKJxeI58kSmbHbBXUYvyc9gZxKGvuFv3oAf9twHn2PPV8Elq2uXqLNALcku7WBPSW9445v0ql95ub79279N/9v/9idVbmVy7xu+g7lRp1/428S4Uy4OxEG9pz4ctG8sENqR2Wg3ei6rquWSqku2lWMQq+2kk7lwnvgFdgpTT5NxnbJik+aaS0JnnCbyY10No1wGs0v5RD1zYmZsMBD95MXwG/6RzcO2Bvws/JRcuRJLfI2d0AofukqN32dPpe4Wa4WCR9AzH4+3Tqpqiinnjd32ki1xTJwtgBTvac94axjUdGWvTnq0RcJL1Y2A6Zs658wLoECmiaJxIMRBOzaSFEAUjYI38XRQjrlyRBBO/LAt24gHSDKQIzJ0I6+r48iuuORVqto0WcC21WAn2VWht5K0TDbbOtNbOexSdatTCrna1FUy+ikNffkty0YWugggl+J84ps3u3/wEz5Br3j5y7l9uans4Hn8GlmDU106smud8DPFljYmZ348K74TjgzuzZuXuEPWyVN2Y8SWXurBJAhWdAe52vdWJm++tfqiF75Qf+/v/h39DR6Rxs/4W9jdWFBbFwvvsHb5zgSnVG+KTFet2raKmKqKumT+Bota1MKXYIbXVUSthK7qFi4pvsT/ruhGU0z2k4BEbi6+bU2Ek3PbZxowXeChHOyJHVmc8HkjHVxENaBXtXJUt0I/OxH4ufyPbvI6mLcTZtop1bX4kGSbnDcwEwyM0mr40V028FAuKR2RjIFWGY9wgFN0IyKXF1ggBgMRgDI0ALN6k/TQz/e5UybIohh+MCA8pr9w7dWvapwlIcGkLGNTsnRVCh+sBLUSKUEnWZnsErvNidcEd1LFXvk8hABg4szLIMDr7rMMjLS7a9ne2Bmv/a3QmCwbBTEZPIPVfR6EfKD2QTwq/Kp/8Pf14R/+G3lj+hZlMh8O+6qNdxkEnF5n9MQ7rwKkmYDh7/umLIwDO3GK7XWrc148SLRFRNqQS67iS/It5LIRSGYRHPTAQw8qv0D9V/7yX+JTYD4sO+yKrDgy6atatlkEu5p2FkXqqkLC0EobVzfbOh9TG3LLFoTsnic2nhUPjgzyOClb8uXzmCUuyUz+I0M3BVtNrnrJaB3RT2yZH9FPru3oMNuCiw0qiTxFprppT9lWZCfM87wKeSj+X/uSdlULSVV3BPBhaDA/qhOn1hyJD8ERkqu2dORKw3uApaPJLqUplYtghookTXH4XOLYZIIm+O6SbU2iTZK6Skc+ZbMt0+aV/qVyz1bV6h3HmJbBAG2dCWiwcm1wqEOkCebUSMDLuDR4Hm47bGXSDJKVziRZEbHQx/EJRnwRdQaRSnYx+Adtvcu2MlguK4Oz7ZsKX2XllG1U57LfrtXftl1AQ6MiobaV/7zuX/yLr9X97//A+u5N3vQZ+dzSdRcYJJ9cZsAFdny+dXkTmKkMQt4MTxyHxa3ATWhHBeOwH5QBSwxdjaqVW4UTg4RX62HIJR9SiaPwY5LP8HML9fznPU8f/qQn6ev//dcrP4my+CSg28otD+bQ0sJ3WRuLO1cRouIMd8q2XIU/JzX2MwZdyYO07bsKWtEP0CW3dr7CmQRT3Us3+i5pME9OjFN4TBF4BmNbNhDnPeRJZa/S+BLcKgtNCYCMpZ2+1jHBK+w7MpCz4bYLvMbfgb3TksucgshpRX4wZhWcKUFUjolDVaVJfoo5BB9EOHYpjDgvlJIAMWywMDCWsxPvE1h4kZswbS8pu+iJ4HCIwQlWysCJTFqr1I1hHBA41a1ml0gwGV0bP1Jk2ZYiJ2rag/aMw5U+LCw2WFQSfBs6nVq1NMCPrxPaicm4nhhBQ1iFnzxIkGTZpt+qotDuKtq19K2rg0awBsn6M3/mz/AB1+folb/yKr37ve+V4G0spPhanckzwPMalJ1JE4HqJu5NjQ1MCBhlAtoo0znypnAjD7HRYCw5gDcWX26HrvuDHBRyyXtT98JtbZ17+YNe/apXKZD52sQf/WOfJJdllXIsDPqCYme8khluI5h8U1oYIj+mXUX8jFldyUPSJU92TizEtBWMKgnFE7lFTRN5QxedlV9scMq2gmeJeXGCjZIso79mCRM7k3YS26AteAhxImetekK38RkZkS8tltcYJSdREcfENlWUlt7Ap6pebaHf5EtgDuRi65yBqTpd7bDBrjYOI4WQrg566OVVqm4McIaPI0uEOsYCXC5VN/Il25KvakVncCkaaviRXQ6Dk4mSCWkjP89ytFQkCRAVukSh6rTOgc8xlSDCui7bGkyr0FtFlk2/61xDty1xKgcJNR3TnmQ1fhWDbmhVBU6SN7jqnNbXp7/mq/+BPv7jPpZbnjcrO2A+3DrsF0jrMV8mgxUc2+gd1/P/on1xdatT3Uo/8RgbLjH5YmeuvCR/whd3KZvCpB0Dhex+OCi1y6rGPzNRyd8Zp9b9/j333KO3vvUtyu3ZF33RF7EQjwoeaeVKuKvAcSjoJf+DPIaWx7R2OJId21b+BvEodHI1kD2xCKzzMX7d/foEL3IDuVMWBSK28X6u3NjWssOkXP5EXl4xi2NQzvwhRNETC4a2rK5SaMqBno0HKWlDy7hTrTMYaWTDjdIJfyXkScBgo7FLGaP4a5FDsKvcisVMwlu8GUugSbA4LK9JOwkMDBI6oE6o0sSByKaz9R4CMOeA6ShJzeoORsXhlCkwTrp2OvpH3iROQAbJ7i4JJ0ewp4AZ4MxlK1eeEwmsIgj4sY+A6GoyONGf+JlbiIGcykKMMkHHCxtA0RY61rbvCqmQs8Fc3msdoR9JXvzIr0NkQj388CN6/et/lYl94tbkFhPuYsmeuNT3vjHQJ137lji2bj3yaJ7rY69L73v/e5Vfjx7xFccm5eajN8E7Lhy81cD/Cz51fsHzX6B8P6nQSygD2dzuJG8bO/4tbkGqG3vWinVKR/wI71H8/KXnP19/lqvVv/k3/5bF+4Qld2RiJtZGL/E2G0b6gzhP17evBD4Zh5RBLZNh6uAmnq4++4qcXXKRN2QKP6kQtpp29BOfbRX5hbGyG5zuVlcp8rlNTGztc78LPKZYVylyIh/xe5CzjGvGP2Xg0wQ7NrIR6fogT5zYkgrMA5vG8hufihK8G+TX8GxrgI/FuRpxMpNCBo2EFk7YFqdMWyCXnWoZCOPAwHedd7DIown5LBMH0s8EHwQQZ10OSQl8QovNRYeKybU49m56OUM5y9vnusPD6eDY2EEs+tVFDFPxxeIPHiz6VvxI8sSx9KpoSYMkOu3IEhtaSmCRySX/Qz/kQ3i2/1f01z73r+rNb3qz8nx/I94I7ftB21bryU8m0iUfahVYwVzgvEzADgxAHt/lS3Q/93PP0Jv5NHcwo/MUCREw9lSKbnyMr/mvUbOT//RP/7Re+pKXqkhH4aORTKxdpUnu8v7qXJ+UgTwxkQe7cuym3HnnC/WEJzxO3/SN36g//xmH63Y+AAAQAElEQVSfQS7QI874300O0k6Kydd1/qLnsgobtpdOeHYtG4IWFdsq5GKfu921W4cemmR44AtL+GlbpJoyF/06R7aJv5cN0T7FH3REoJGZ9DM+3R2qbCttK3/iVdKiFZUVeQjC6sKdzJO8Lx04eI2H4JpjkRmMQ5Aql9sCCE3NeJpILJ24ZATEsvAFNq26KvQSbFZnEk9XM5eQ6NJJAqPkkqqvkgevruxEF1iJvmVqTtriOLGTUWnJop/2IJEDh0/sYkJ+LD+nbLB51gwC8rRx1LYMvcuIpkjVLFLNlUDlQGYiW8bAlBxZJS3Sgw89pD/yhz9RX/qlX6IP/bAPXbv+gzxtiewln42cruwdyY+NDr711gv7RNK78QOaJ0xw85/cPfWpT9WrX/1a3cYnsTb5JMbEc2TSuopUDSW2YGaX/+AP/mC961336lnPfrZe/OIXK7tWJrnAnOhnYU3FcWwQRy75kGWXTNm2XSd8eCOfF7zpTW/UZ33WZ66fS/ywD32SctVBS+ZPFNvKzlzUiVHU8WnVFhOXKYQNy6udvK25wRhUhZYFOM88fBrI4lmgZXzJWAFJjFcy8E/ohiaO8IM5GNvoVpWqm5K8nO03fdugo8AZOSoVNMLUdX+Q/wH+cd1VnO0lN5GFjHwJRzRQQjXkfBI8AZ6yMRApyKZU0ZeFrNKOY5ChLIw0ee59IdcZNO+ou0u99ObiBy7B2aVCbg24LU6Kl0zudU9MiK5SsJqdFYe4pJPY40BOqrY2Ltm2FZlyoUub1+AmoXhFbANVbJMIG99JdOwXPu1MikE/WtEJPaW6FHoW8Id86AfrH/3Dr9Ff/At/Qfm3wvlNnZs8eelqFsaDKupqM7nwjcTY2MgOsxaD1332LRZJI3O42PXwgw+t7+C/+c134an0pA9/knL1iK0QElMmvhSvjP9zxf3RH/NRXCUvlf9f+FnPerZ+/lnPVHPrE39PV4Mbn0S01b1yU91rEQEFdTKpW/HhwQcf1itf8Qrd/4H3rw/OPvev/XXlt4+Sd9KiciEv2diXzn02m9ia0zrbGcrixkFMkl8Uk4tMNkvoWPkj7dRa/YAeTzwJvMLaGT/BnaibsnJOxzZUqbvQk07kMjnJVXgCOCgTucnYnYh9XOX9jAUQ/AJDHLbVVWpyoWmZ9mPy1sop+xf2Ju75nDfoBMWrLftcsEe7BENeoryGmAKlcBYm98I3qXCizDQ4D14ctg1dKhzQamMQR212YgKIU8AuGasUvEGA4shkjl6K7SVmUWO7qxgD7JFBXhVbSU6EjuwgtlUU2wpeMMI/FxaTzkd4tlGbK4bf/Jt/s/7iZ/0FfcHnfZ5ucjvz/F96gVbCwUwyB7Yv1u6thYuqJrcbwaGh/XABfa5bgezWFxc39La3vU0/9MNP1l1M/tjPty6f9GFPUq4iKSKm6Nr4QeyJ58gV4ZGHH9Ynf9IfV3b5W5e3dP/9D+h5v/i89R9i5P63qtWUifc5B5tHJsvCA7PcCj15OLGBpGPX+vcMz37Ws/jk+FP0df/y6/QZn/GZunHb7YiCRHy8siZ4ZZyKxYZbGrQzGaesqlIOu2RbiZ0KfdrIoQkda2BFL7E1OI2v0T3hZ+hVljgFzmAuJDcTfUOcysErGHXFTx1q5yrLIlr6EJKLidwJDNvKHLItUUKnkvnrKiUGccQPYau7mSda9BqAILcCQoaTUBAilHUaAChnel6Rj4FxNWgTB9KPsWUAsCMrVXjAPAVjytGjNMFXSijgQNLE1pmPFWjBC73Qh6nU8dHoHJmQVcVAmR2u4BWiU91Ff1PBm2AgutrRCY1RItghwx/YE8f5J1ikfJr7hV/w+XriEz9I+RdYb+NJil1nWRSrm9ywuC9PMnTJkuC7lR284WcwEvPOG+v888g3ctvxYz/xE+uLccmTbf0v/4/fqPw2UNS7WpHPe4GBv9cDdED/A3y+8Nt/x+/Qx33sxyJqZXK/l0euz3ve8/X0n366ekeXPMT2thMzV8zrWKosTOHvWB+sTWLdmDiuYpEedMnumjfyb3v72/XnPuPP6hu/6Rv1yZ/yKXrwwQeUw7aSr8hXtUBT2ro6BmM9sqNn7PHbRuKqFPUJ+hKlbZsN4SRAKFb3WVZXx0S28CvFLoZ6Ls6KCXp3o1Nr3JKfI75HZzImQKvQiW41Mos3V9wGpdC3LU6k58KOfCxM/D5iO77SFLIxLnXFYAOCAiAJVpYmQa8CjR6ACnk5kM6kZxMsyY6jMZB7SnHEiMEVfMvKBI5Rd2kYgQBQRyd0RNQMmKAP2K6ChAD9PMvvwg6Dz5UZP4eAjdRqJxGI5aR/WokLLgJagsDkTZFl3XH77fr0T/1U/et/9a/1QU/8DXrpS1+md7/7XmK1br/jDvSHclwv4GaSxZcTO3Rh9PJ4Sy68xOlM0MGkyFcjsmu/6jWv1o/9+E/oXe+8V4X/za7lsv7QJ/4hVbUeZoePXCbwvvMMf9s1bZ3ASL4eefQRvelNb9KXfdmX6noyJG+5HXrRS16s7/ve710/tnti0E/kIpiH/cBkO/ucf/ASbLuEexLYyYNtdReYu25xW/fKV7xSr3/d6/SVX/EV+r7v+5/6hN//B1bsueXL/fhkkkiM7pVewDbGprvBYXEQ08j9hKRMroF8/KUbNQ10Y3ew80c3dVd8mipqo895LS6mmSYvGaMJNbElH7Fp+8oGCwpmYo8s4nyAOxUscVjMD4iDXGYWJ/5gCPoap5WvoieOyJ7O7wFMdxm8FjCUnKkJBPb5nFImYnYt21qBIBdDVPCs/A0Wg3KYXJAYKnoor1dcQ6FdMC1Th0NLZE0nrh5JppfduRZNZAaBoQaCFLvRAYl+WmYCnEjiOblIyPYVDyl8mOj/nt/zu/VZf+Ez9UU8I/+Ij/xI3mC+ZP1D92ZgYWMRLIy4wEOni4EGJrvPIKkALtzQEVP8yGLfmMQPPvyQnsktxlOf+lRlF9/2XWvwUPpwbn1+/8d//PrqgsG+PF4y2IMiPfLIw+oqBSeP9JrbhleziH7/J3wCnzt83LK31cYCGetfqr3qVa/RD/zgD+ruu+9Gf3KFYDHiI1Hiv7Rj91EmeGEnOROOZiImr5G55BEqpCX3MLZ/idu9d7z9bfrf/86X6Z/9s/9Df+mzP1t5AnaLD79sKzEGp5KLYgJLQIJEqgobdDXIlW1NahwW7iAk+Yp/ZONAfPknjsg3eCOOnKW1cWWrKsmWlcNMeivz0g5lyi4ZmZ18V7CZZ6mXnqRBn9sDBfbEBjHTh15dipxtxXYKZGjQA0o4EjamtJxMII2DQiEGqyLYDMKU+UMMIyPV6iF2pQcfxyazaTkerqWBRwNahAphSDTn0gcIKVNNwVpOZRJoXtGQsvhzrRZQOrJIGv+cAm/CyRn9iYCRtb3kHuSN6P/6kR+hv//3v0J//jP/vG6//Q7d87Z79MY3vlEPPvSAEnveuCIeCN1icm7s2sHMm9X4nX7KykORi77yDfu333H7+hHcH3vaj61/e5svum37xoRuVcVv6dM//dOU9wY3H3lUxood307qLkprMnFSOnZpP8LnA3e9+c36K3/lL+vixoWqWxsFVT344IPrJ1n+5/f/gO785V9e9MNhV7k0rwacRk5ue9jtmfA+W10yDc4jfFZwuDgAZ+K9pSyEX3396/XQg/fr0z71Tyv/QP5rv/af60M+9ENZdA9gY9NgA5jkNvooihDkqjSZpNdzwSKhOZUxRxy+iXFf/uTKknkhjvCDZVSu6bbBtaqbYjX5qG7lGMRmk3fyc5PFmfEJfUI/MtkH9KpmI2REz4Zhg6eUuRb89Rg2mNFbOidWJ5JKZwKyIsBQDK5Pz8K0NHjTVwQ8riayGdzIJAknLnOIqKBN+BMHulq5WiTyXP5s0xeLaKyyssRLZJWa7T9BDXSzQyJO4lpRGgRpWwP/qgs7xZvXWzryxIV1Qt8xs/i3bt3SRP7ixkEf93Efp3/1//6Xyi8jv5UdM9+lv/8DH1B+LqS7ZTV6U43fhwMTAtvx9cQCm9ja2Gk2BiEDhIsLPz7AWrdRxufcm//wk5+sNzNhJ/oH3ixnFw6+VMob7D/2x/6oYl/OJLUwrOa26sQV13SM/YFuV0m0Y/+ut9ylT/nkT9bv+d2/e/nXXWp8Tskie/e979ZP8VnBU576ND3MhL7AboGVW6lgWOKp1AGTpfSzw8ZG/hHM45/whBXLzkLN1y1u8sZ/MG4PPfKI3vrWt+pFfIaQ7xZ953/7Dn3rt36rPvbjPoZ471BXrU0FaE4rfjZ+7SxAmT7zYDBPkrvGV4SU2MR4bFxl7VLog35iHyRyYjdXPxF/blfOtEF3asIPRujX+belYFVbhe2qXrVkhVfkTxwTvCNPoZo8T/qn0/GKXzo9lvdSFQCoqqnrSrkqAzUVA5nccSoOTBw3MikTx880qUIzwDg8SEAcxH1FpLmkGz4+yFU44VXiVIrENMLZqk3rSBvaCYdHACCWrRk6+oMkQ1KTUJXT5DbgUjdv3dQFkzg/KvtnPv3T9fmf/3nrl81+9Q1v1AvvvJOd7MEV+ADneLWbiQCqmgU5ldsPWI/ZCXDuGxNHd9OdamLJRIud13H/nHv95/Gp6wO8idz3XRfs1vu+qV0SPu/4+Kf+5J9U/gF6PvwjCoV2WjvW1AmDE19ODEh8ObLwortvm/JbQu9657v0T//JP1Xs2634Wl3KoryVJ0QfuF8vfOGd+q//9TuUD75usTOGZ/FX1pEJUHX2PdjBvckVYduJmTxiXmuXJa/dRTpLkzFs4syHcT//jGcoP9Hy5X/vy/Vv/92/47ORL9Mf+SN/RLfddtt6H5HxOxLL8h8wY7PcEvYXDrgix3R5A37UIFaRl3IJD+kP5SqbHEfHkrpbGWum2tIxtA3fqFTgDeZENqTInNuDXf8kYFcZKNq1cIIVGeEo7im+XvONr8FOxKqu4GOYCsmzAeHglM2wYXQCHCDLCFnGmaJEaUaHxK0+/EF/0kdQAz3TWDvTpMGZPuhRpSdFb6wJP2Tji7GJ7NJBIgkyDtNEZ6yJHF8KudA/+qM/Wn/7b/9tfdU/+Af6pE/6Y9r31r3vum/9I5VHbz7KwriQ7XVLAIAyALio8GI7/ttn/shkpG1iy86UJFa3Li4Oyu3Om9jp83tC+d2g173u9Sy+o/Lk54JHn9u2q6uFMSX+3/Jbfos+/uM/TnmKI2tN3FxpBpNv2SVHW3ZPYs2bv7UwJd0iF/u+61de9Sp234/VF3/x39ZAttoLf2OB7Niyze7/sN7AB15P+7Ef13d/z/fw+PUe5T/FCP4B7Cy2tEulI7ENxjL2Eyfq5PKo7qI+rbq6k1ptLOQh8XDg3Xr5y16md77z7fqNH/5h+lu8f8rPvmdB5Ap1IC8n4gnuDDYbYHDtWpgBYwooYyVlXKeS7/Srisk7ltyJ+MQRHpUybzZ8ObenIkuaZHuVI0/lAOKcj5VM8LP8WJhIYxhqYAAAEABJREFULru2wZtnOXwUTsXOkXyA28sJUBEasKTqRibmUtIvXfNlcUx0TssIHXWVmt0uynO9TNkITi05OspkimySlMknWd3BFS3T3mTH0aEcGwOcJAXOKmUgBaSxVS7la8W3uHSHH7m73/oW3fmiF63JcP8DDzIxbyr0JH9gsJk02an2w0HxJQnIr6IFNztafiP0xMS77cYNfGl1laqNSS9bb3nr3fr+7/9+/eRP/pRe//o3KDb2/aDbb7uhCz4H2A+7OvHgULAP9L/gCz9feY6fJysrbngFrqiPV9+/ERZCi4956jRx+MAOHL+yQJ/+0z+1fin6D/zBTyCeUmRTNuJpxil1Js99972H9wZv0Ld8y3/hU99vUf6Psfe/9/264FawwdsOm7prlSlRn2Oc5EZXPjz66KM6MpkLuRNPeMK7wW5v+vmJmA+Q1zzi/cVfeC4frL1Pv/N3/k59zEd/FPPmpMhUWV0baIkQK7ZEGez8hjeJjVkITbre3KpbrmJMWkUtGZGpos6iusWVLnXyA0O2VZSN+LEgOqoGwwUbPWoLmc4cORLPcdF3ZJpSZcE+01jkFUcmSRgMfgQYG42sRuTEMWmHbxtbPvOUw+AsFwiGhQMGBOW7+DY8DMWYq8gGcoxu0S7oM0YgZRKcSPgkMWfaZMGABX+mIAMU+Kf0dGLFrkJCk5CbLIB77nnbevryMz/7c3rJS16iu+66Sx/g1uDhhx/F18kHSruyk9zOQCY+43pzX3hbJi73zTtJOFCe+IQnat8Oqi695z3v0Tve+U699jWvXV9HePKP/Kh+hHLXXW9ZP6Zb3dwT364b3PIcrid/FeF7JXZjcD7ncz5HT+Be+z6wsjPFh6Toktuc6taGzcRyJO+EqfhWYEQm+Td52rZ93Qq98hUv11d++Zfr8Y9/PN5P2VZ1LZ0NWzsl9SNM4Ee4j8/Xtb/zv3+XvuM7v1NP4z3CS178Yq4Mb9MR213RK+VnEaek6BV4yfcddzwOzOK9w85V7UCMdyx+HhszfHo7T4teytXgGc/4ef2nb/7P+g//8f+nn3vGM1UukewVe+ZLxub6/WNidPgYM7ZlcRo7rXUkYEquSpGdXEEQlSuCUztXwq4Ce8jGDkrBGcwByypbOdKvbtn0cbbQORwOMn8o68jcSV4ntphMss1cm7pC1HIoTizjeWeJYMkyQNdKsjWvFoQsuTCo85EkxEB2I9vkY1LGYgJFbU0memQmhEk7GMAvuSwG08nEUBg4MpCZyC6HpVAV+5e8+b1185Jd/pZs61GemryT++VXv/rVehGD/fxfer7yG6DP+Pln6NnPeY7y3wzl0WJ+F/+t99ytfDXhDW94g17+8pfrFa98pX7pBS/Us5/9HHb3n9SPPuWp+nkG+Bnc/z77Oc9lUb1Ub2eRZRdPUm/cuI3Jc4MJcrEW185ErkpsOIyjA3//6B/+RB5hfozexJMmusgd8PWoS+6/T0z4lEzGlLwJTU66zztWsIp2ou0qxmVXbrXye0Nf8RVfzn3xacVci9fwe03SXNUO+y7jyy2uLvmRr9e+9rX6+Wc+Sz/85Cfrv377f9U3/sdv4grxrfqu7/5uPRnac5/zC3re856nl7/iFXrpi1/K+4g7lW+S5qcT82W8J//Ik/VdLKT//J+/lavKf9Z//87v0g/+wA8x6Z+h173+V1fezwt7KuNkkwezFhI0fmQ8bQtX2cSYC9C7WoZ3YkISiJIvGyVosCXRJpXJzeR2JUU5oEUnuUp93rjBhHdtm3mvavBVUK1cRQ0uMHKVbGh0oo9hZKaKMVOMDLq2Zeq8MRGtATOG7FChuFQEIA4bwJIiaxtjR2URkAqd2NVXm4hgCYZEm1OOHsTUhVODS211q7dG76S88URYk7+GLmTTHjieEgxZJDRXBa0JsB8Oyk525A1ZfkTqXXwI9c533cuO9Y51W/DSl7xsDfTP/ewz9Iyfe4ae89zn6hd+4XnrDWS+cfkKPhTKgshtTr7CkN0/T1ke5kMr27x3OLDb31hv/m5w1ThkV8LfriITOc2Ll/+/lfv+T/u0T+PzhXvYdYZOPFY9sfPOLGakTsehql5+Z4d6lGf20c6C3g+HpAmdk47o5A1r9PIGP1+K+7y/+Xn6oi/4AvQLJKm61VXqLm17KznY9wM7+LbaUikL973vea/e/o53rCc8r//VN+hl5OPZz3qOnva0p+mHf/jJ+o7/9p36Hj5g+z4+EPuhH/4R/ciPPoUP835y/cjuC+/8ZeXHhPPTiW/lNvDed9/HGB11OxvBEx//hLVDD8b7SO6PTOqZAZpSJtnpdBTpW4t2w8eiXLJ5Rb7a7MBDhUBUtm58buWoMu1zDOFN5oJtNVfutKuR5bbOPuc8SXOVTuT4mFsmriLJeWEPVYmX+BX/2kW+WiqjNvkgDHZ1a7Kz0zyf81xZ5vZhu+5oYmB18Oosb7opknFAHLZlp0hVHdvyohf6uI/uxuRBJFSFeVqJk7pKuZzbOMeEP5HUSY3/Sze7RYIY8dWSCaK78LG17/vaaS+YoJkIGZDcDuTn//IU5v77H1w/e/gA97HZHRf9gQd0PyX9Bx96iB3tkTVwhR8XvBe4jUFehdun2/j0OJP/gkm69a5ySTjv1MSUGH7Tb/pf9MV/62/pQRbOo9yOFP7B0iCG+L5l0KKm85HFvu+bYC/fj0x6Wyryc6KNOo97L5V47rvvPj396T+tv/f3/q4+48/9OcVHA1Pd6t7UlMidJ9J2lY+d+qD9cFDBz9U5C+JhbpOSkwf5jORcn3OTXKxy/wM8NXuAW8kPkLMHFPnobvj6uMfdwa3Y49YDgfP7nlZ8SZkJlrlTXeoq2YWHWv6vHKxxY2wXNfVc+Y7egJfCQC9uXrJQkg9xRwKsMhe6tqWTfEa+SFLawnY38xjB5LnJYXCDY1umUVU6sihFL1iD+QzNgi9ewRjh/d9KhAI0cbCLSSwsRBqlODiYvIAs3cF92RV7VdHNRME3BnmcaeBk4JPQiQNdxSDtuj5GhOkEMwNKU8LWhD7Bp4mtqfjbdCKXwDcCTtm3ncm06+LiQLnQgQVxYHGEF7lz2dTcN0d2h5eSiZ1Jf8HTnAt0LtA/UM73+QfFlw3ZJsnb3lptMHCB2KZ+44c/SX/n7/zdNfnf8fZ3KHLVrWrDJ69Tqz7HTYd4kpDkYpKH44mJjjzBarDwD7y3QEpNXHmEuh8Oevvb385tygv1D//RP9RH/b7fh+iU7SXT6HYz8ZC/9jVxHfZNh8NOOVyVC/KdeHZt8DJZqltd6FJvKcS17dG50AW5uJHN4PbbdDubwG1sBuknV9G1LTMJmzhLXmMzr2JLfHZpcIVI3Cfqzi7Oig9tMhcyDvn0NhuIOOYqedXCFUfuQgoctk/ls6WuUnQH+mdbUwPME5O7u2mTb/TwTIUsTU1yHB3TH8yj0NolkFDGMduqagTP/ThPBxph4Y9tJYiJIVmwpiAtsQxiHKhuaOckDJwTR/5DucihoK2L5G/atoMKomVW5AmHz1hHFtMkedE9EkwCmliYOO9CGueLQktFP7ta4XNXMYCtxn41bXa7PYNLORx2bFKYQJlUmdQXF7tuhE4d/oEnJTuTPfQL6tt4g7webaKzMRG2TCpwbWO3lMO8pOS9y2/4DU/UF3BrkqvIO3nz3AxycnIiHsSUH5o1aoXPh21fO9iEkcE8MtknMSevifXEWGTCkxrkBjk/Kf9ia5AP48PbWFyve91r9J3f+R36vf/r71VXIWqZurqVHHSRA2w18r0l38SfGGjv1IfDxsTerxbErosDE51JfmCyJ/4L6hu8wb8gF5nsycdtbAyrDX0nJxWrtpKbwt5gXsQHm/GnLewPxi05cOMfdEJW4q0urRI9ctTVqoLmApXMsOMPcpJcCL0D9mJncrsc/QHutm3Y3hV+2ku/r+YvuoP5l99Yiv20Bz4ZfKaTGjlxDORqYoy2ZMGbVFbAaEi8DIAiMiViwsGikdPIz4mEZIc4IdAWFXTAZFv5ywDTYKIPxegkAMGbCMXWYEXaVtrW+bBIZCDBsn0mpp9ASJZTIEenutUMbAYmu1JXrSDT3uDt+6Z923WuN61JvR90WDRq2pkEB+oN2pZ63xfmBm65VIWNZr/A52t3jkzK3/7bf9v6/8Zs614mfzHwJybxqpncdnS8/Ald+Jz4J3H1Wqi7qmr51PhK9tgrpmwrtvdtW/wTcU9KZN/wq29aX+DL/x/8KZ/yyYvf2O3CxxRwVjv1VUkugrXtxA/mipN6J84dWsph29aiuGABHFj8mfAXLILDfuA2amehHNT43GBWlTIGU+dj9U1wnIUviS+57y6uACfCmmr0UuhoXMVSBZ85FpTs9JLhnVRgVZueWDRH3ndcqhgL21FX5lEasZNiOxcSRmeiW+RQ5KUDp3WgN5adyaYy4JWqKeLjfNtLhjGRaFeVcpyNpKUFugDmmbcsyIqsxYHeZGIHo6rlChVnqO20kUE+g7hw6NpgTT2GXelDr2t52JEZSZYIivBcVuFfZFGl7ZXY0MSxkaT9sKvxIe3sgN3bmvwbA7xnMJnkGfDInWnww1v0XdcDl4HHJBMxk9Cgi/a+Qs/jzN/9u3+PvvhL/rbyj07ewuPX7PqRz8KO30fu4xNKdqHQ42Pij2+hnRiQQiC3A+nf5LFudG4dby5bkpU4zRUlEzFf8zix6CZjlv+34BU8Hv3n//xr9Smf/Me5WpzUXfjX2omjiacT96pb6SfWDV7KvhNnckU+NmSik3wc6B/2nc1h04H2fjhoO+wLs6qUSZP82BanJjGswsCPbGQSdCuyk6DzXkbsoBmrE7u9OAY7eXRpog+H0wYb/Oi4esVzZAMZ4Ecu5Ug+UyOuX09PezD3kk/biEzlddmbksHuKklTtuW0kCeNIv+WbVbpoA6HGlnbMKXuhl6oTtrUKM4Eq/MRoxPaCjh0kiDqM9foejUnk3jAs8/9ENMP/uBd+0TnlMGd4fisN3CZBGxlVi27iKwJTi2MqSYwU2I7EyVYKRnQbd+ZDBT8z4BV9fK/u6Bv6tpU1dr31EW7JHA5idsiYOUwibOt/MXGwMcTA/l7f+9H6v/5RZ/P5w5v0X3vuU/7RZ7gMHzEkcdxXWAaTAY//iSsYOC+MhkNeGwnbuDV+JkSG4f9hnJrNbiSZNJnQl7eOvL49Tbk4m/zVOo2vY33BC984Qv19d/w/9Ff+6t/TTsxF3Zd1rYmd2vbN220g512V61+5HYmeHiHw65t35jw+7oCHA6Z9AfwNuUxbRbHFgyKzRgQTGwU7ZUfMEfidq2JmTGK78nhtu1ymXxOxeaJ/BV9k9FMaDKmPEkMPXNJ0CfzJLJlq7pWAV5d51scS6oq4QY+HmhvLJjjshHbtmVTyD2itBcLuaLtkJAfis8VkFx6XAmMHoqDFZqBQVqDCQhnKaW9sVsUMimRsfjDGeGhbXVvNAdlrkUVI5iX4CGiwWJZntUCWRgAABAASURBVDsk60hCLCsDbyeoyWQfsq0cqS6ZNUnEotTZm8h3t4q+bVVTVEJRzp+lht/4k8HNAGYgQ0vyukuJxaZGJv2dAc5iMZiNburgD+xP/D4x8ffDQZ/1mZ+pz/2rn6M3vemu9aQkST8xWXMPPQiyqtclez+cBz9XBkvnWGkEj65Sk3FVFQNyEmGsUs2gb6XGH8Mr1WoP7J/YFaP7yCMPqZF717vepZ/+qZ9Y3336cj4su403qRUdF1ilos7tT+Lq6jXB089i2bq0MUGrUm+PtbtbkTG6jQ/hC+csq8iNbU3mRWK2zodtVRc+tTAqGxmJuBhL6m3bFs22JjmyjXxTSl29eFUlS2t6TF7TJ+3Moyk7HK3apo19gHjM+6gGG2hdYST/KQgubDQQmzqjnl/Tc2wBw3uAiWwhwDlTMB2rgoujGfSBsUmbeaC0bcs2SWpqURLUuR7oRgb/IWjJoypLMsnT1ZFdMs3uPovCSztFYJwGKxqBuBTd2K8ucOgBGHps2VYRzITTJLmrVr+rJOQK3EyCFEHq6jN/yZ7bwRX6dlGdYxG4Kw7q4I8rrPxPLR/7sR+r17zmdbr//vvX4EXWtrLI1q6G/92tHRvJ35GJm83okB26S4VP0YmsbTW07MIXhxuqbpl8Z+fd0paUrwPglapacsJKtFa5lZjf89736XnPf54+5mM+Rt/8zd/M1eGGIldVqi4Ze6lT0u7usGVbDS+TvZC1AZcUGeWga1um3WwSoY9MghCgBmfg62DxZ0GkJNZzXMI/C3W0HadXXySiqtfCuMwze3RP7PgD3Dz9inzFF3n9sR1qkM/IFL7GBwDlIi5b5WKYs8jI0JRsK8fAr4ne6vICCznQjpea2JqLL/RhisGdlKJd3egDduXUGoQYk1VlEQniAOF4vjsPISAyvAFwnN+2PWSK1YWjymGlFYeBIqhJhR3siiNJvMS5XPqLBKXIsWcqq9Ke4pLc2vdt9SNjFy4NZbLR0KJhs1I6PJTQdQWjZPuxMklQIzPxIRMJSeVABKi5bEziPPKI8sM+9EP1j3j8eMftd+j1v/qrAkTBFEfFlmvt+huT3vRN/9bxFtxJDkxpPfjQgyJ5nEM0ZKcaTIYTDXPlOyJn5b91fZQPyM63BFIGSzrnKnFmUd1+xx18wMRgciMbnDzPf8ELX6BbfP7wgz/0g2sxiIBsg1mrJPfGr/iXq1Mz1unr6qhGLjs+Om4rY1/E0l0a3H/H3dC6SkU+8UxrLGhv6J3IVVUtPckaTLJBbrMgjmwCacfGSN6X3EbM5CKLoktN7k7cfWQOJMbMB8EzWA0/4yTm2LjCTD/0rXfFlykCplXxHx1RD+RliOiEX9Vqrq6FfdgqWJywEAhwLrEBrm5FYBDEicCQiA3sz1UqoGhKV4FiKPIZrIkjRqBCUNQMZa5/pzpYWMJW1Bcbn216nI3NOBabKdEs6GEDo9SIk7SpJuFdpchXcRUJJsKRKV5CK/hJqu0ll8Grjg6geJS2xR9ygwGqQu5KlkrXPnzyH//j+qIv/AK9h09U777nnnWvHF1dHdGLfDMQuX8WmItGekFXJm2wXvLil6wfy8JVXfBYMXLNzjqRn+T5eHnS4XCh/KP8O++8U/kkWgBfctsTnWBeMhEL2vo3DVWa5H0D44JbsyYPL+eNcb7i8Q+/5mv0hV/4hQsvdqY40LOtsmT+ultFPrIYDuiXS4tWhUwpR/xOqW66jCP21hyhdz1fBOaROWKHP1beJpPcVzhrU4CnBEHefaVre+WG7tIZzA1I+FBauuhn7jkOCy2CmNRlI9PKER9iK+2uYsrMhUUDSakKn/BN6JSZJwiO9Kkn/sA2Tcn5s5SJRXOBuFq2dX27MhKUtHhVBTgDQEABQkzkhp6UBCHGGXdN3EkKbYTKJaNr6iR2RuNKcaZGKz7YNIRuKhwdFEEc+BCSZTWDEj8MVuo1wcEWcilRCXwRZUGzoyUtH9CxrRzRy04mpY/NTEYm2n446Eu/9Iv1B//QH9Sb3/LWdctzYqFcMiFP8LOzVZeS0I3bm+PlJbEflef7Asq2XMlT66d+6id11913r3/Dundr6ZZ15D2Qctg60c6jx3ffe+/6KZNXvOIVylcHtj33z1O3eEo0ryZJci50ukoDf29hO/nIRL73ne/Sy172Mv2JP/HJ+tZv+RZ9+Id/uOpKNrEWOsn7dX6WeV5WbqcWXndBsZI/m5ysxpTRNbzgwcX/ueQLehc69hoXwfR6QcdatCbujHEw8oxeHPGdCcIJDg65zrYKnCorcyG5ilxiPpH/9HNLNPEpdkNPO3X6cfpaXhzVHU9oTVhTkanGV6hXvwoRo4unE4Nr13IYCiakurpkFE7F+ew4RxyxHBG5WFlcuugtvaoC54hBs1sPaim6aXBFU4JI29hJQnKpx7WQZKODD4PFcPYKMnJLPwmCbyPDoJ8HbApz6iqSKMpU9Lqs7oJHQX5KyxcgVkyQ4DXUuSbwAA+V1TeNj/qoj9LX/vP/FwN80hvf8AZdMsEeffTmws9XsbOIDvtBeTojwDL5L7mnzQTubmxT8Cm7/888/Wf0+te/QcwUNbm8ya2ebdQKe4Z8wocTfoXmZeM973kfz/pfqte+9jWLd8nV4fY7bken8WmgQ2EMjuQqk8FGjxhO7G7xL7dQd975y7r77rfqP/7H/6hP+AN/gKvB1a0CSWh8LPyzLQwvvLzvCJYgZVGnNi4yFMRT+KV125VGxszoHy42dZUmtjMeRik+iYGemjodh2KLQJVxr27igYbdGSIlNou+aQ/mUXJLU7iJ7Em5ugl+5LuLptVxDMIA345minRkY4q/uepkQQQ7AQaz8DP0+DEixM5eSxegVfMSoTOU0INBNQguC2OidOZNdRUcaeDliZ0rA4s6Dg9tWys4SUCh0FXLaZsOWnahN2SYkYOkM0ekbCq0ghdsCBDxw1YSnkCShPBXhlCGq4FvsYcU5Ln6Zau6lCPyCb6qFHqSA7BM39aSv8kk/w0f/MH67M/+bOULbZlA73jHu8ADgThzlehuBQMKp9XEmsk/uDLthwNPJW6uR5iNXPLwghe8UK9+zWvW4tsPByWPJtrYTIlPtnWJbVxRbBwiR07f//4PKF9Gy//je2TR5ApgWzPjQVEOS5n0M/HjY3cpXwpbrLLexYdzL37xi/QVX/EV+gdf9VX6Xb/rd+mErJcPXrEUOq6Wkd95/xaero6CvrFoBwurbHX3GpK0Q0s8y7a06FSqsib5EMW28ih3cOXKOE38hrvyfa1R3cIdipfuaivHFCGdc0MXqLwi09jyarPOdGQjmAieqJPPQnBgBwFOr/GI7YANYk8MtThWgSTkAS1qXAsQygkuoMsMAgFIYmNMOssdGSRYSzc4YCsTYb15iUxwwBuU6AtvbYtz6QR/aK5+aKIdbOWY9JYeDWstrCSPlGiAG9Gpsx/pr6AAcVk2dAROyE2cin26TJQTyCAEF/qJ3WL5wEDdvHVTf/gT/5C+7Mu+ZN3jv+GNb1iJRYHTusUEjCwdXd66tXhHBrWxF3pVwWLxMpgXN27otttu13N/4Rf1y7/8Il1eHtVV2nmTd+vWpeJrfFq7FRjl1n7B4mCSdW/YP8jIZ1G857736MUveYle9epXr7izs4c+ie1ESTsDf4urz0hM4J3YReMTbOW4//4P4Mcv05z6un/5L/W5n/tXlS+9DWTlkJNJrZgWDVJ1L1ZypIwb/sSOFFnLtnJvHH9F6EU/ZZBLuTitqlY2iOpWjol/RybppFPg5dcubMv0u1q2iXHqyFWNURLDBIYptejRO8c14K3eqht8y9oPyeFxzZVB8JHoLvSN10OxjQmtg8bCj8P4tZQSbFVxefFSSnsglfvGroJWss0OcpLkdWkq5Zi8wR3wnY66Wi7LxvGp5eQg2VPogYc3BDTCwJaQ7XPfhqYrfCn2bS9aVrbBLPplrELmRNlqEjB4FjxlbEl54xsfGvrEXmpxoBrTqi5lYBBHfupxj3+C/ncm/p/+U39KL37RS5XHm5NJdDjsK2mTQY1doWAb3U22lVvByejvO3IMWv4xUHTwQvk+/Yt++cXKxIytqlLK7bffWDvSYCII3aqWrPV0K3a6aw2kke/ulYt773237uRNcd4ThBbeXJFoYZ7HBxDOE4sI1xR/m8YQ6SMHlyzwd77zHXr+835Rf/kv/SV993d9lz7iIz5SyWt0qkw8LVctzIyXXWoWbfyaTJLGn9DSzwQrN/kbskqDHA3slHGCduSzYI58gJcaFh4PHbaDhEZk10YZeUnBm+Sk2mrsRF85gEtVZbQsXhSV61ubCfBksi8am9QOfnNVxpiQ1olbJOFfEUtVKb5k44i96JRtccowxTFwXmUSPzQAh8t93xGOVNVnWRf4c8nMxRGJYEgiDy8GFtkCyspfgW94cdgOxRL1ILFoqxpM9JXHeoIn8UqNAcTAH4prkR8EHJyUMy+2kUcc11eQwkOBV8suDEm2V4n+ozwu/OAP/pD11eK/9UVfJOY799wvl0s6MpndtXZugZM8zGs/MQBKyNhJXqYqNiRd3LhQ5J73/F/Sy17+cvI3lMVR3ctuoYtLSKIO3mTRxpeuOtt0Y21q61IWU6O3MQEjk3/l9gu/mCvKnWuzig+JHyTs3sD/KUs6MeAFnrGVxVfUduHL1GG/0C2uQD//zJ/Xfffdq6/+mq/WV37FV+qjP+ajdeJqHizEyYHVXIkmCU888dkwJo0JLXixkfb1WK8J5pL5i7+LLy2sspXD8C7Xo2HRogc9sukFi8mi9GfGl0xYHFx9hPS8sq3U8LZMcvRjZ+ATImEpCyOyxW1bkzsXKJwLF13biE7lYNZgEkI6KUsYHnLpruIiLQxWAg2IULekwSQZ7DYxZmjdBViK6MEnCHHMK+eie2KFx8EjdYRmDP06+7lFCJZtQrzGwCGEIwtZGdAEbFvNBEnioxP8ZOCET4tmHNcZY+K/wJCKiXaUbf31v/7X9aVf8iX6oA96Ip/ovlH38ISmr5MGbnyNE9nllx1ouZUJVu8NKxN1Uyb4II7HPe7xLJhL/czTn85CepmSm/CqkhMrfzv31+sWhp1qkJfgxu/ktroZ/BMOizerB1WXCt3IZBEcmaB5T/Cyl71cz37Os3UkhxnA3AJdcvtzcWBy8z7imCst2LE/iDvliG7yl8kf+r4f9Ja3vlUvefGL9YQPerz+yT/+x/rH//ifSOQn8gSnIkfdGz5YJpVmIsafwbi6jKy1Ec/Wi6mmrtBhVRVDwcZgK+0TY0KKVjt9xQBlhEiNGPZa7H1KvjPiYU0HW0gMeWGf54UNHaHIwMSWZP46i0LIwzsyP0+UMLduFvhQVctGkjpxFO2KwCSoSdICJotzKsckgTFyBp5CXqG5zGV6px9hx28lmIAOdKJrWTPKKE3wDbExvG8Mbi2zeCoCT3uu9iUDmJ23wDe6XSW70MxQSwOcI/ftSVJ8PTEHaN7iAAAQAElEQVSwwEvWGgBQtO1MJHQju1yxzlcw6gvus//4J/0x/R//7J+uf9RxJ09J3sXtxQMPPCRj5xb280azAM0iqi5NBg9VEYwkYhIHhmzryG720IMPLtZ9971bP/KUp+jVr3t9XFsLo7vlFQMInEU7NGCWzol4qvCX+sj7hCrrgI/XC6fR7yomRSuLxyjmFybykyw//uM/pocefEgbkzB5GywI1LUhPwg8eUJ8LcpmIkd3P2wK7YjsYUvbuuctd+u5z32Ofttv+616ylOfoj/7Zz9DdzzujuVfGS1KchGdvAcMVsZzsNCW3SHGZepInhLPIJbUJp9CV5aqvOyGZ5ND8pf5Ylt2Kbj52jxr7DxWjJ9tcE+a4CElSCpoVaUc0U+iIS16aJO4874kc+DA+4HBFVYIXDJn9n3DxyM4zKVgQp+yzmh0lpEgioBijXpSFh3grtZiW2t3W8GUgaAfAwyW6YfgKgGpJG7pgFNNoCQtToWHJ7DmClIi2GWMmsGJ+QntRGOwMCt4kky9MXDXtouBPeHbRM4u5TgxEAJZ1sLOIP3O3/E71q1OfgT39/2+j1r/zjf/wN3IdJeAVXcrCyv4JxZW9It4qlsD/GAXJrpYFPR3/Fhvdm+/nUeNb9HT2fnvfus9a6JekPzgdJUaDNuyreqmX7K0Snbj+JfJ6pLOA2jt+77kCv3qVnUr/jU2k4P8S6673vIW5edZ7rrrzSyCTbYV3n44ADSVnHThK4OdxaEc5Mq2ipK8WdKGLanWVetnf+Zn9Bf/4met30z93M/9XH3wh3ywsikgpsNhQ8qKrq6PMi1GKhU5XxWUrlo5SzzLNvbCSxmMJ12lPfENZ2lbGzEWjMRpwyXHBAGqdEKuyqs9iQETS4eXNMnXturJa9SymWSOdPUSAU2Dubf6YBss29DG+Z9EoieXtAToOAKoNvWkP3F6gjyp45RtqJxhUjW70EoUMuFPas5lIAEPOhPHsyBKhUgUU8ABqxvjNEU71Mk1xZAa+1Wl6Idn4zRYQnaSlIk/kOhamUS4IqNjKPkU9bf91t+qr/z7X6m/wKDmVyHyb1rffNddepQPlC4udgZ/W4tZyAcrScuEjJ95tJmfENyzc3Bl2FKzOI8sjrK1MRlP9POPyp/1zGcpV5LDYVf+IUl04ve1L4jLtqJnW5LZ6U7qdcme0KVBfkKf1Pt+UHSDsYqLsSltyF9PlIcfemT90sMzsZ1Pji8uLpBpPiy7KTs2pABfXBzkssSZ3Mom/9ItnmSlHbsNru31KfWLuS1685vfpE/kidh/+uZv1pd+6Zdy+3BaPzyGiAY5j0/RDVCGY4HLOpKPX+MNaU1ZwbFsKxsWLdGRGddmA1t9RZJRB+zEZho6JORbwTOdI5+DxF7spz816Y7lzylv4CBO9Adt24zrSYktNAlmaCyC6J/YJM/0qbIN2zrx5glIlAZ9KS8DwAhWtRBT+sbxs9xUJkBWZ+7rbXDgKQftQaIG+hhQoz9lOBOMgeOTku5UGmuXYOC7ij7nmQwrclMjkx3+WI5bdskU4BdvYCuTNr4eWIy/5bf8Jt7cfYX+5t/8G3rH296u/CTiBx64Xw8/8ii+bNoZ8AFekoopbeyCwe4KLn4xcBdMqEy4XD6b3Wlyfd6q1bRFfPe95771pOflfOIa3Mjvh4OyMCLTXarg1dlfWYqd+LhkoF/yhnQkNpiZ2FQYn7pg0jZ2QktdDVY3tkvRDU6uVjdZyPe9+z698IUv0Pd93/fpfe9/PzItG2OcR26rHn7kEeUIVmIVucon1ZMYJ+3BpCgEqs56k7zke0Wvfd1r9bxfeK4+kU/B8yn2l3zxl+pJT/qNujjcYEee6irFB+UAuLDZXfCYeIyTXGtsJrxlh0bmSeZLcn2eO6d4EQTBVjBsc9t2C9p5EkfOJhgk045MMKJgW40dwQ6vr3I0ACv8O9Mz3yhDEvIWf6lTaCd25XAZzCk7dSbhuW2YE8BJbfsqqLnkHCOhUySvBSGOmQSggzhuQwCEU4IwJexI0b22SW+dSUxo4rBMMvEaBftsFxIcaKCOq8G7xRvA7Li/43f+dn3ap/7p9X96ffqn/Rnd++5714dI7//A+9fOdmRnycCPeVw7lc5g6zW7fbMbDXzeWEAndpFM/An3lB2fxIqrUn5L50Hu+V/Kc/kf+7EfV26jRA7yb2UPTNod3ZV4SXYpMdimk9O65p14c2anb57MHFS0c+XBPLmZTPJdNvyupVPXdbXS7m5lERxYcJkMD/Ie5k1vvks/+qNP0Qt/+U499PDDqmp15LZtjcspYyKiYIIf2ak36KQROwVVNAc6VnIZvUvymitlPsf42Z/9WX3UR/0+fd3XfS1Pjr5qfR08X6945JGHriarlNwxJNjcwJQMYpEbL3jTlyD92qKBEqrtFT+Bh63obORxAmb0s0Hgshp/wxPy4piU6B/ZuCOTDTBjnHawUoefTcw2/g0lzwbT6E5Kk5+67ljnvwyC0kZJHDZ0SlGyA0IKPs5OpKaqmz77CQ4vHi87zsoF34pjCCz55ZShFZhQxGEcQlC2GaijImtb1aXoFrJVtLskeZ03eYRpWx/5ER+hL/z8z9fXfPVXr/8V8YOe+EF6x7vu1et+9fV6//s+sPCyox3Y4c+7lblFuKX4d+RJzOFiR2Zga+MSf4v2SfvOAMYWpgq7B56u7Oh3lV70ohetXT8/KX4/V5Rm0dzgSpHJvxHzxlOk+O34KULBRzu9FMm2gnmJbYM3WGgmvkzITKBz7IUPu6paid/IdW3qrlUyBtWtxlYmxb7tCzePdd/2tnv0SzyCffIP/zD39C9Rfjx4x6+uBnpotdE9sQAKGooaXAGyiEpWV6koecJHS9u+qZG//4EHlF+PzifSsfPJn/xJ+oZv+Ab9n9/27evfQn/Yk56kR1h0zZV1Mlujc55H4jAjPTUyP6zVxpRIxaIlB4PFOZGcKI0UfIoA4trA7C7NXCkRSl0oW0ZDavKQeJLDKmOAAsc+18FMKfqJ87Q2QnwCL3p1wjg8RQi95eBg18MPwObahQfvpqOssmxTnQHspCn9UldLsgYJyO7ZyNkOCarRqVViFCPLnuGknQSIdnUvfXEMBolKR/ybYEZu4vStm5f6lD/xJ/R5n/d5+tRP/VS5Snnm/urXvFpv54Oe7FxGMYnLpN8yeZkEgwGwrcbGJLhM6vySWpPgIq4myfkeT25LJgNQRdIxevPmo+t3cX7oh56sfC0hvzla3bpxcRuf9t6mCxZAJlaRC2CViVRdajBNTMphUkmJzUz+rjN2bMffwi/YWCPf5H4/bLItIxcctOkHWVc08LEX3oqT+BJr7Oc/0njHO9+lZz7z2fre7/tevea1r2WXvlR8GgicyOsFizq5TLGlYOwXhzXW+ZLabbfdkMtKHgZ521hkE+8ueS/0KLdUb3zjG9eTo9e++lX6+N//cfqn//gf6uv+5dcJeDYRrrC5wimHcT2zljZVxjQ26S38rlIZO2CHFgDLq5n2EZzJ2B+ZtMGOD9WNjYHG1DF8xNemAJbRrbaKNi/qLuUIBgpwg6DH9DMPyuXYko26JaNc1fTxXVbBH+xU4ogTZeRBq270hgaTZcCYJKqqlHvNIfHJ8InXCYKRlgaLqJlsjZ4LQ3DWogLPtoIT/ZQJHmz0pgrZwcSPjYGN7P65/fi2b/s2/bfv/E4961nP1jsZcKGQ3Xqg6y70KNg6MaHWGz74WyYKJT5kMpZb1a0LPsC6/fbbZFvh3f+B+5Xf57/zBXfqaU/7cT2fXfW+976XN67HJZuFkl3/cNhVxk41ekXZZPydEr4LHg05L7QNba4Fc2RABwv7xGQ85s2drSPtok6sXSWa4JWKdhZY42czEat8pq9cskNTJ5Zt570Ni32j3Hz05vo9n/wY1tOe9mP6n9///fr5n3/m+mJdPuUO5sJBVxxHJtIRn5L3E34d6UPWjRu3qQsf0sGhfT8oYxj9++9/QK/8lV/Rf/pP36y//1Vfra/92n9x/vcOS1Yr1sl4zYxHfCbvG75ZJhelXGViK+PVxFbIJG/JiY0Upbok5O1z7qqKyXtS6F2lnZiTR9NmMrKAT1RzlSy2IzkNJhCLVtUrHht8iNXNU6A4aGng7Ing8VwNI3UB7Ahe1ZP74ABWoQiIOEb0qRPoZKJOFJtgGgxYyoCGN1jJcTYyiAtYBSI8WSpsHHnTtvpLdq5gs0jWm6c1kS8XLUl673vfxyS9i0F97fqey7Of8xzlZxFzX57LcWSMHx/2YR+mx/Mh1W03bujxj38Cz7gfpwP3zrcxuBfsepc8DXkXt02vfOWvrF3tp3/m6XrOc39xTfpf+ZVXKb8TemRyJNl5krRuedA/MJhdrUwIS4RgFQHFV9MTJbFYORhAEpfFMshRdcO1gjtW3k/atl1CPzlqbq2Sj3Np6JzwdHXYlmkvftfyYWOCNWXHr/1wUFXp8tZRD/JZwZve9GbieQG3b0/XD/7QD+m/f9d3Kz/y+4pXvFLvfd/7l2wW2eMf9zjdcccdumBDeMITn7jo+U7TYCDf/773KT+M+yyuLFlQ3/8DP6D8IvULX3gnG9A7JXw6f5uUGTDSLU3GURyDOuMxiV04nrZtYmbDoM4Y2yVYqrZib5CXxOCybIOiNfZpBScYA7yCj0W5zvaS08xjO5JSxqC6VN0skLGwCx3Jyns/2qUARbwREhP4yGSLA5kcMRSQGGH+w544cmTwTuzyQ12tZichR4oOfi+jkyvD8gHgKhyoVrngaR3GAaeFYleBKzX3czMAOGj8MPTJopzIHNmVBpgTncbPDPiJxH6A3TpXgHe+4116C28EX/bSlzLQP6P8xudTeFP4P77ne9cHPD/5kz+ppz71KXraU5+6fuj2f3zv/9AP//AP6SlP+VH9HG/yXvayl61flr77LfcwoO9gB31Qwo8LbnFusHhusGBuUB/o7+w87VbishLTlMsiJOULXgmSHjR4iYMiW1298tb4rwhAry4lLthaB/SNfA4G1wgZop38eekn7qpSM9kLJctKXd2KXvj73uuDyv2wQ2OSIZNbl3yn6O1vf4fuestd6/dAn/ZjT9N/+S//Rf/+679e/+bf/jvqb9B/+P/+B33jN32Tvv7rv0H/7t//e/2rf/OvoX+9vuVb///6nu/5H3rGM5+pX3nlq5Wfib/vPe9RY/f22+9Q8ZdxsjKUzI31PseqLgisCMYQN0gNuWqk8D2LfenQPbLJFHFNnrZ1Fbi8eYdmO2pKjKvlkuGLwzZzcWiw06dUt2ykKBiiLQozCfPhw9Ekr5nTyVMeWVcmrSWGQjoClIZtdZWagajyAgl9SgzWVOFEdyn3XhmoAMqSbU0msE1HDOxk2aREmTIohd5gIkcveOI4ZXLDO3GrFZs2ONiY9GEvm5PJnmJb3a0EkIm4s+MVmLnNyeO7Bx54UA899BBPQh7S/bTf9/73695779U9PA59GyVfb373ADKWvwAAEABJREFUfffp/e+/X+efS3yIyf4A5UHl1kHWukLcYMLfxk6YJKVcMJmySza2FCHkbC9fulvJCaESBfmhL3gkY9Ftr25ynbgvecJCZtRM4nXVI7a8uRTHoG1ir2r5KvcZAwmM674LXKu6l/3IwpJtNY2G/uvzk4WwHw4rLkT06NUtUp4ePfTQw3qA25m8d8hG8nYWyN13v2394sQ733kvV8D36gPwk9eUh8hp3scc9oMez5X1dj4IvI2N4eLGQVX4RZG82hnf5CS+2MyHbGZSPqzVZCLm1yDiT3jXc0lkMPNgopg4Bptx2mgp+IKuqyP4Xdjsks2c+XU8svWYaPSrrUKukDflBO4t3tPUJOHVDQAgAOQSnkHI7ip5TT4q3NI6MnAnFsqJYHKvHV65tG+7bCM3WZFMdbC6WrlqZIJb0iRoQbdqyRXygpFAnBd4g0k/wF68EvaHllghyFnUCaLxedu578VubO+Hg7IYQrfxA4wTO8glQd7iViB1ShZKvtOTGFZiqtA7rHvz25j0NxjMlLwRvO2223ize2M9qswgxpG82dzYGLrPMUwikXBMYvJBI5+TUvgQcsJaIvDt+DWJCSoyoQfXtpqrX6648TF+iY2k8K2xZVtppzig9G1alOTekqpL8S3yzS1Uu9S9K/jJyyH5Oewr1tXeD/B2FTYGeT8xNlmMsX/J5xPn9nHtsILfVejuukFObmfHX7nK1XA7qLoVnCrLKS7ZVuITR+YKlRq5EIleLmTklYuMt9HDjGrVJ+gZd2s/HIQYUNFKUSDog59Xn3EWNuxVwzoyR41i8LqLzX0SywkfNk1iBUVne1XLmEi4cbApZcOfqEvVVleMYBfF8BoZ28pjtgEtA5ZdQRy2FcWJc0dWmcpgFD1d1aY9wGycOim6KSP2kT234+wxMLK97t3EUdU6l6K+Kl1qJkkmZQY7ZWdn3fZNKTsDvR+2NXj74aADO9XFxa7DBe30V02f9o7cBXXu8xdGJhKxFjZMDpo6fiaBtvHI+EfFKo/fKY1tl0KRuJzb1hKaqawbt9/QzqKlq3XZh73ha6EUG9ket30nLzpvJOTX4g8cS1q+WLKtwifbil/tbdEsjEuKXJHP7j7zqc8LZMN+a8dmyuGw60DMB2xe52S/ONMuLg4s/nM7vIurK+IF/AvyeAifnLWtOHxi08lkxuzZF8i4osyF1FlcdJClx+ybjPnqIJdcBCb6Z59bgDBph6q2JZani+LIGFzLDu4mjkz2FIETTKBVXbrFlfbI3UV4+Qwo+Qi/GNeBUPrrd4Fsyy4VNfick8JERYjzsQnostbGBTGiVcV4QcsghYDaiADaZXgptCfyKbbTU+LODpxAz3KhSwMcBLTEeIlckheZM93wzIC2OpO+qVOKmrKFxgTcGMx9PygTbd83BpH2gYGEfgg9Zdu177+elvZBG/K9MDZVl0zM3a0tbVvrj7gJifbZ5yQznchOYoiMOKrNeCcCOjlRAkKTwGykKBnUCT1XpdRVrY04SGU00JcWLjJVJWGosF/GN1tpy4xdaeVlw9c9/lO6ClrKtjAb7B3+lthTiH9DLiW5uC6H5Oew64KFcXFxoQsm+sXFDd3G1fFwSP9i5S54se0qVTe2WnZiPufFpp18pE7MXSp8EFGt+KAXurbRK0nIS2u+ZX7ks5rUJzbSYhyygK+zaeRil7Solj4EzgJ/69gpYt6wF0lxWLiwFlTe/IY6mKtYnew0JybfSRmAlDWgOBmjSXRV0ZuyvYyJY1Bc1rbHCDBX/YaWSRCcLvTiIXqWsTGWfnTo6sTqnCA3yQvfjjzpiQ54A49toyPJnGmDL2qLP+roFnbOda9BOPdLvbViKwOc5DX9Mw852pkoGfQmhsO+qxqdahV4tpn0XC6n1oEr+E/HqyvbMr74SjbUxC3TSkE0CU7TxBhZSMrXF/ZDdvipQj95sktla9+gM2G6KknQ8qcbQKkKFJxInTGRrOtj0apkn2lG1vLKhX2mRyd5aCZ8Vyn1BnazG27kIrnZ9k0beYjcHjlKdvmLLAIWw4Z/oQcrOWr0hE/iGOzCGctJP+3BGJ4WLaFM2fEoMVy16SdfE7nUSCEjcoAP+BXfqnrlpalzixaZyaTFnILvNMjtdTXJXTaUyA7amGBuD9hnyYFvolmdeTahS7R4aQwV90lcToxEiqhHnEMp94OxM66Mw9KEnv7AUANYWJvIizrJdSVYKX2E1y1BJvzx6r7cxgo2k6TBZwR0tQJ8DHeqICIluYCh5ZRSSWp83higKqurziU0yoFBbAY2j+W6WpHLRM+Ott7QXhy4t79Q/Ay/q2Rw1iJBv6uU9iSeDHhiD9+2KgW+OMI3MjRl/gQvsiGlmZK+ZDFiLPijMkgnbhUyqSIXP5OTJpbzBDoPTDO5bCv5Nfq2VdVccbUgN/jdpcbfqpZNDJKCY1tVKQW/lNiDF1ojv+0b9FZ1c3W8vhIeVvuC3ByY7DuTPrnat/0x2e7gtVwl26vEXmGLjiwtW1t0qmRTBDWBpsbzc4xacVWBBU4zVslJ3n9mAicfqbX0pBNXAKA5rcIWiNCGbK+SceBuc7W7S2IOdZUKfmKoMjStI4sXN1SRg1KCl/uuweTOO3FHGEVO2BJkiY5tdSFOHQCLP2sdWXGnrHYcHiyI4C3Weme7RJYzGQSDce2EbTBbAyMJQgvTShAFz7biTyZNF7YxbAkabVs2QVYruBsTKCXt2EidwemGT4KbgO1f0ynwIl9d6kKmSq7wjRVp+WPaxFTwRFJhSzrTqGRbOezSgD8pgrTIvNjpIJFqta3cB2eHvLm+ziEG8nzlzZvzTIBB/mJvYhdNfCsqFgVnbFzjZyJF7rqfdmIunGziSQ5Syi1DK5ciY5u6ZVvdYKeuXu0s+sh1lTbots/05LZb4VX3ohW8+GpZooSHiwotJW0bHnOg0ZnkZoW0GFNdFTVud058wHiJT8iCY1sZlx2b4rAND1mdx2QukMi0Bu3Ysq1CN7zBXLJr4cLWozdvMXQYpVPYnGzFwlTkJrLEQQ8Al3VkpWWXnjh7ngUSOhTgaSy6pQDYpQko0DJtw4+ObXEq/Qx0aCnj6unOYIBnCNLSp0LWj7VVZ7rxJ4lYoi6VrSTy1xeXlUELLe3uwnYpR1erq1TIdJs2/W74kqHZpUa+ippkVzcMrxKakVEOSHiETkn2SqxyEPiKnxxAXlhdG34WhXhIbvhX6oRB1NAM7pFbv2DFDoFzTo119S3IFHyayA5KMFJH79duC0oA/t8LPllWMI1+E0/aKW3kcXLLVQNeFDPBmo0hmL3oraVH+3yFIJaCZjDRt6mju+K1hK34kEmoHJC6znNiEAtBwR5CLVzFj7QbzJTEZRt6M4ZnO8oBfvJzZEPNhkCX3Ayw8Jp56bJG7hjkpdfEKdrxY+PKX2BmQ77WUw7zQskmbWQnczD+xSc8hnl1ZsIlGVUt5DCagRkaKJxYHIy55hqUszMxNnFqrIClxhmjGGcGl/kkFMmFZd5uTxBtAgBjoDfBDTZkZKwZrzFim51xrAUJnMSqHSwgQc+z48gb6rIPzzasXxvkw2FTkmxbG5fjxFNdi5YPqsqlKkKPPWEXP5RraGyDiyM5kTGF3YTBmPgc/6LX1fCngiOOxDDg503bIBcZAMiywU6DMmUl5n0/gBl/rdPlSdUNTvolxLlnPQlBuYy/laa2fVPsZkLYpn0uXegg55KivGopTQoxdnFLsq124zMNFbTkRJZsq6Lvkgt52iumqdXfWAzdTUeCtErkLKvBCa2r1DzCbXuNmTgKWnikQknt4OWUHELM08JM7uRyQh/kjVPCh8K+baXuArda64BmpUUOEbbIC/PrFo+4tY6JR8LWUIaxulXozPAY42WLOn65SxsbnsFHRJFbyrZBmJoYmExOepoocbLSCqfqqj8VUXFkoCf19XkeIHoQzzI06NrGUKPnhZHElmv1G2ft8EvSlPkTBZLWgQOFs9UlG+7Sk1xpp1zTrXbaJalUZUraU9dHJuBaQCFA7mpkrGAT+cKXpUX32VdxFDul6NOksoKzulzeISixVJUMHrAJQ0YY11c7LxGFtHQXnc5xHLFFXol7kvORCUFtsAazJ2Vr+IwJ4pKxvWRixTohG9uNf0W8lgUUr9TiWIZYqPAanKpSF37Csq2CXt3UdR5jlwS9oTW8YImjoEWWil5sY4aqmfjJ22AyxlSKZNlW/CrggmEaNnRJ1SXnD1riNbQVOwtkySIXnMnLry+2VWU0xYHxkjKREdMgP6kjb1bAJEcRTBxVRdPolnKs97NpoJBx5JPgqTgYZWEgdQDRko1Biz2WMFGIXgKIoytAFypekxoJ2GlLxugpTij9KQTEiyaORjf4sSObXeOk0KK/NTsrksKW5bTCWmV1oYeXwMJMcClaTGDCl1SJAy1Th5++sNVMFBufoZuSBEjmT2sCdIWHD8ZnQ2OnAEaFxCAeU9vWOqgnyRa08CYq4kheBI9mHNK5jQ6YsbcGgO6JK+rG1enmzZuKj3at9we6OpKrAWhKcnPtR9iRTw66WiYO4GRbobvxFhqnwmf6k7Ir55TxkBRZI0edccgzctEfa0FJWoDnKmMiW4nLsgBTjonsZOIbmpfuVGM7PGM8WKuNbm6rQ5OjPhVeciZ4k8CCXVVc8U/KJlrouwq8jogKOTQxPeXQr8Zl4ZcUXdvIXhUZca+rqU0bG7mtmoxhV2E/ViW7hC4EdqKZZCcg5Lt5mQpT6xjg0RiRyf0r7Tjq8nIKfNm0s2uRGJqCIPNXXWGvUhhPv9CLTNxIO7U4TtgHUCaoBFo0ultdBdeK/kbwWVzBxh3Fs7K1bhO4ZE/sTxjhp0Qn/fUGH+muWngTX6sbTFNKdvycJO0YSOU4sSsBLbXksnJMFnFK2sJWhJcN8LauMzn2bSWG8CfRxweqxR8MRJ5yDPQfvXWTN2o3ZThlr0mQK2QIXfiEPYG3rlzwkw9EGUQGBUCbvDNWdhCsYKxSOC3Rn2ritK2qc4mfoXWVNhahFb8Ht0s8hgWrq5GloDewH98H993xybwUcVY3ujwmxofjmj9Dor1ipdnwbWstrtDByZWioS186roqyQNm1VVgmMJJzGs+0LShRYD2JHcpVV6bZ/zLXBQ2BjoDvuGlXwVedFGvLhX9KSuk5HSQ/4pTdssmkYDY1sDZCE7qgpd+u9RVcpdkrSNVmVcKr9DOr9FLC7JsKzITY+KYOJlisEqRkgpsWL92srNGJmUkIDAMd6ag34VmaBAdDBMuvlIpiU9JO6xg5I1yBsZlIpwaweBqQIMJP9h1xpp4kJf+jK90BpicS4YNHOtSMIIPEB1jIphpFgPCPSh6Nv5EgDacJbNqGKY34cWnQWxdrYKW7+G7WyceE4vDhhp5fC5kUAF04itPjdBDhDGc+HYiDDKzzqngC70ZBUcK//AjfcsKFl24yFYJUNmLA9Yg/lL8OuLHIA/GfrheXkruWstFP5YAABAASURBVHYnINcTtODBWXReFL1sHpEZvHcr7ExJRRxOG91BYsO/lptsIJBxhxjZeMKjEzgN4l0lAj7Hg9Nhwx9qcBdrYsRacdDSgDjAsiwCDomCEBg01iPl9dZUBBoBu5bSMo5yhGK4umCTQmhxODTbyj0ocKLJbZLkJMsYy0l9wvFgjRWsFEHLuj5AXLji1dCbHbyqlg+hFXirz5UhskImiyu8gcVgd7cEPbQsJLtAg9IZXJLFbjSI76zniBFu0OI5cpBsq1LKGvjsKqU0GLBlr1elL3IQu7YVzCDRUqGT9qqXzDKlyE4w07Ot7Fa17JxUbsW3PBq9OFwoP3l+9krriG78Sce2XLXs2F51du9mIXeVRNTlwldRrLQnGwkdpVSXlgy2Vxz0UAmJasrQbSKZ53YXeaQdMTmv0OGbzmA8RC2Ocxse8DYvMlRgyflAP4UK2lRiSYEroFZuCjuhMUUgT+SE3FwbUoSWrwiHU9Sxl3mVettbzh9mB/YmkSh9SxNAm4Y4qKussRyZ5wUCTchCRhj0MJNwL6KBQhDQyIW+hK94BTFOw5ZtpS0MRib6g3YcSBkM/gRN65jIpzEVeloZwAQU31LHjy6HxWQZiu3c3tAABf0qMEpdzSAjx5lbBtuITAozHu2u0sabtAKrM0lYXDAXxpoMGDQ8B6dKAkccRT+7cBKMsAZBxtfoDHQ4ld3RbXW32i1hOxuDOI7ZceiTVXqCZRl828pRtEutW7cudf8D71cmflUr38o87DvvA25laeMqsRpJeMmBZSWfNjVAJyZhFk54hS+QcHfg71ymEdNOzIYRGaNv8NKeMLctT4esoi2OLmLpouWlX934dlDYkaluHYntdLzUJCcpjXx4yU/yMrlNupYP3vlRa6sYB8mK/Am/hZCj2xs+S41fkJbvE6C0ixfbSl4nc8g+xx2/g8NIwxuqKp24Le8iV/gYPclCXDkMHYcVQ+EBHzL9IEzVkkS6CiWkEsxAqlwKOE30x1LglfZqLh4qivxZE0ASkx1uI/HV6FPCS4nVweUw2MG8psV528r1aH2qCjMythUfLC8b3U1L2LVWQ/hBif0kyUUoOGTDByOJPpKYdHMZHCxK2yqKAajuM8BVzLnFGSQ6pZkche+Dy7Jd6JBkBi564lg8JsORN7L5QSdI6wwf+CtcKvKRAU3ScCkEbZ2JdJRt3bhxm/K9FHmpq9qa+NkqRS95QEku6GDZRv6orl7FhdzyfwJgYIpaUDIWUyf8C6GJpcBIO35MfJ/EioJi49qntKuIt2vtkslfxDKmQW8mrMKvVuHLxFcj2+Qr2AU9fh+Dj0sDfvoEg1PxSY/pTYAT+ySuaQFb2vdt1caGwF96OvPKBYY00EsM6QcjfduIm3hPqMzV5pU2MxbheV3AcsqVPE3VOZAoSjFcVSRQV8c58V0YtyMsFxA5bTUJKfpZlXFIHN1MFu4fTyQBD1T0hTwshWc6cSiOi3Z2ffxDlARJ2J55WQOQBmYWbw2Oa9Gjj6hsi+Fa9TkZYAB2baOq0U0ME72Tro+RpCMX3+NH8NxWd8vEgxPoTXCJW6IG0Sb5J1l4xcDapa5Wd8mGyhmcqkIdXXn9IS0aOZUjt42Ar34WXTU+woj/KKqqVV2qYOInrCVb0NMo/FyYCDftTN5r3oQWmVQTxVXACNTpyGSwVGU4xEL82RjCG8QDEbdAQJ5GulQDP4QOPiJvgI2BpUNfXfQE38hZeS6fHDT01Gts0TmyEYkjC2mgFx4VV+hGrxbGxG7kQi8MTHw6+2U0ta4+VbXaqQfyQq66F22iOFgcOL3GqRrZec5UBNZDBBqIKdgVLDqMluUKCDvGcnQqDsTAxEhWdyZz+stBHENjgSTg2Ly8vAX09WlVt2IAfCbe0EyDRAQnTZfVyISeAURAwexqpdj0roquD4KJDziHTBEkuPAmNwxUEvLiQJOmsQYnOzit5oqU3WXSjm0jlzMJi1r8OLHDC4ZtxXdElatSeCmQ1fgc++EP5DOg4aUtBFzxC0eVxMcaDc7EHKptHW9eauNWJ7LZ+Y5sFpmI++GASQcGDRMfiw356IY4iCW2rFr/Em8Q97i6ooaHMmmcK9+yZBt/S8UmNfC1ycFk7I7ZmOBfyyNIE+84lYOxSZ5TMvaxmXFTpHAmdCrU8JH5cqTkm6zuUsbSKweRHspR9LNBJnddjZ6WX+EN/JHFzr+rXMJlJvqR2Mdqx/aR/MS1A1eH5DvIoTdjkXiSuwgPJuKWGPEz2Cf0Bo4O8mYb33jChQzNlac8hXOVKjtSAMMI6CLiTEBSwJCrhZ/UBh53bCWwlNAbZ1YberCuy2ABXTtQ1TqDSMXIh1fIi6NwhGo5NrGQtssS/NgfvKRvO3OS9wYTViUXJGtKgk4BAO2pgd1g2vFXXBqZLgQvjkHS7VI06Mq0I1uRhTeRM4zQzrz0YkMa8CQvGy4rMoVe6timeZZB3A7fsi2hISrImbZLhpAgWSb2aiY1E3PwONEuFTQYQEaDeLCbVmBk5VyQiTO5NpTuc0zBsjiiQJno2mZhZEEJyRQvG9Wta36h39XCQWhz8TPx7bNs7AjtqlIO23JZ13qTRSaOuXJvNViwV6xHFsm6GsCzvcI440wlDyd0bS+sA5uDOOxSsDOpIzQYm+jYhoubxJV+da/+BGiwIThGkQlvYfjsbxaPfbYdhfiX2KtRKBhiUoYRYytwIUwCk+TQYuDMj/ETu9BpdYfmmmDRqcoOOFbQAwcNxrax8sCZBJC+kJ/Lns5ycZwyrbX6sxMgDm8u3BhJCIgoGECqyiSY0qXoxbY0tXEvagMEgB0tSemS+DSWPryqAn9A8qoLHchATA0MZXc4cv+cGAaDM/D9mB2FemSiIhNa9AZxJjfGXmSrMMgZ2kB+4cr8aR37dmDHO6y20clOFW5uh45MlIGv0U2RLCMjGd+k+B36qiVycB58mhr44djGYLPrT/JxTbOLnlTdstOGSwzBygKM/gnbmSQxtJHH1GsswLPJE/KRCxDa2DtpoCPosYPYYkenIk/sorbyp/Mr/djMOCRX4gh3suqS8xO5Dt9lOBPoFCk+rrwKr64MGcTYzb9ei04TW2rSh17kIjg18A81ZdxktOhHLjupq9mMkZtElaTCVwZBRoVO/Mgb023n3TqKabsKppRAx7JGu0txOhMx9FUiZ4F3jDdYwAoYCX45AIqNADT7XDdBHJl4+fBkQz/9sORSLWcMjlgYJ64CQxk0OPJZXbFPU+IlybEt+1wmmoS6eLERPDjqqnOSYA586QKReBKDpaWfdnwRhII3mWx5wqGFXQpeYip0LUtXpcIXByTbit7Nm4+Qjyw+KvJ3cXGhwWX65vGWgoELQpSCPKoTGdTpS/msgDCQH+TfyA/K1EBGslbM1PlOUlerWQgIKPxgHlnEGXhdHV3EmoKOqUO+rht9yHJZttVVQE3R1WRyWyXRsQv8qcnkHdDj/zELQ1qmUF26RKuM10RgkD85FMqV78ldirEzFs5UdIV89LJAkNZAN+N8HdN5PCZ0fMMfgVvUA73kKphTwofWRHcC2o3PsUG/4lDKiYk3o22kOQc7HdU6s8psEjxXV0U7zmSSpj0AO3POr7YVTNuqKvyIcyUX/aa+smF4RVmO4bBjn2LjrLEATes4Gy5bq6BT1aqiv0oJi8tmAq9KP/riMHJNKeWwvTCCOEh+ahwUAEtmSDQtg2twyg5hlUmcJ/JS2M6kP64JJTX9YOUyLw7bvGJ/vWrhnW1Ye57337wJTQza4LHnpapKN6Db0ZtalQRufCay5AFiu+UyHK1Yz2QjjwwGGj8mtW0NmGnDVOixkSJZ51qKv4NJMC2hghxjRT8xZsJlDqRcj6WxjXdKjQfoGD+GukuZiIYvDgcP1+dql3KbPcjdWa5VVTJ/E8OhJ6+xsWrs1wKIhIWY1jFB49y4z4ca84t8FoXCmZjDCFaYrvg32f3H8sFGiPyE7wBbXAGQNJ2NW5Wu0iHfVnRBnVdJpAk/r0SryW51NiStBDKJYtT2WYTXxwygNzFoW6HxogQJCSnh2EmIyLayywYvKJHNIIigiVmRj14SF544Zuyit/j018TF78hk8Ca6UZyRA+BafzAQKaiyQ1n5Qx1TZyTTGQzCiBy7Wib6wmCwlg789I1mbNkWaVNXKQMsDlPOJ9EDy0mX1+sBIYcXFwfcmzK0E3Z6DayVRQVVOKS146MZO8lHblFy69CFLcqEN4nTaeNvZBLnEbzoD+I4sUgvLy/X7mt8JhUKfeBD2qGd2LGDm7zJUKp507jRLIpXOSIzl40jeVvuKfMA86szyHP8DPYEI9gDG6G38bdLoi4b+aETG4mWjlX4bzNHUDphYwAanGNkdHXAL/wa8Ndio49jcv4qr8g50FOZSwXmJP4URBYN2JhUcoakZrCCE0KeZ+epTi6fA8UAFMzUVLIJIoOEE7YVegmLOh/ZKexQpsZV4MGxCQzLliXaKY5zEhOm4wcty0WRVd0khySnjZxt0ZRtZQIU9pUjoy9jK7cB0pVlFtVQbk8KXcwiaaRMaqfmSjiSFjaGjE0EhIByTBRMJ7qGEL7phz6JCRI4pjJ3rRN/xrI3SOQkZykDGylGbCw8BUHCw0ceekjvfe971++T5oOvgSzeyPZ6vp9+ftLl3e++D3krAykLv+eKKXEJWWCVydrkShy5F4+vQjZ1Nf6BbVsb9/OdcaMdPuIBpEKY15zhN1j5egbG4BMX8Q5iGhhLHZzo27Xe/1Hhn5R6EH/ROPEhWXI3WCwkSjZ+MImPwUFGZO3IgjRjc7jYVV0AiLE4KkfyHPuW19ywSxZHXij5KvUkrgnWAHNSsrjTNmMZ6fh74mFCaFUNzq6GZxyKTAALemq3uQIAJhzNm7Du0mrjYOZXHJ3wJ0mYMUwdB8WxVrAs2+o66wmZgTxEwZFtSZZtDXhCf+J0Fos4gjFIdBye8JKgCT92ZSHOpA0ezgzkJu18eBIbcOAPUDjhR75cKoIlVs4Q4XGmdcY3yT7BgxgFquCE4Kv+wH58XXT450GyRAzBafDpCeNqF4sAPHwPT/SdIiQgxJ9JUxxMKb31rfesX7F7zi88d/03R/lt/2c84xl65jOfuf6DjZ/92Z/TT/zET+pnfvZnlEmZ/MRO4Aaxn/DN4CWWrmbxnWSbggHsObbTl1XUS4cJmPgST/RSultVJZeFqHKETlCKzrktVSNjxm7ZvrblNd6EjGot+bqSqWrcHeqmjlHoaZellVNwbCMzWfAn/B9gwHSt9xB22oKG/Ck8SfCSR9aOBGfZtVWdsW7t+w4VebAHzMKYbcX8YM6cTpdaMQkSfDiKQmhCpxogPIp8JGTjIIwInLiUGsCVkCn4UgyAQyfdEA3OJOEllDm9iixo8BgA07EkO04jJ8lYNLZdRduKvVAH9ARc0DNoMKFM4ZJyGH+KcsYzyQazzxiZMPFosNiuMeJl4tPVEd0ixg2dxBVevXN3AAAQAElEQVScM2siNmVbhmBer/EiD2md4zp4+MHuymCLXmI4DypICyv8bCwEoPjz0MMPKT8+lV+xy3/Wcffd96xF8da33K177nmb7n7r3Xob9bvvve98CwJq4h5MfJrATfFCLqgtZZFUtYTP4uiqsJVbGruUK8bi44Dt5UPuX46MSTAhaYKdIkd1ks9e+OGhpoRb4KaeODPIrcuIU6gTF94oHzSljk+PxQ8hOc7CFe3gDDDEEYx1P4+hyOAcmKKy1MYuKBhdYzBPyy+jFyHI5KeXTK6E84poI8GOEz8jOnkxvsdm7A3iDi35iS9Cfv17AFaBUI2PGiRkdVZvqhDaDzzKpD9SCMC+chADK214dGK1wZYdJKjQEpgd2bHo6S989IxjGFt02zK0AXat1jn4BGL61aUU2yoX4JINh/bA7mRQEti2b7+OJw6oyIGmwh5NGWrsnOIfDqctGFPhmI1mSvRdJunb2qWgKId9tn1uYwqMQWEkCGUs+WrTnRIYuEUtxbYsBm3nTfCOXDPGvejV1F3wNh14InTHHY/THbffoY3blhUXUA1/YmcNjcmFOFafEcGIDThl0EZcycOkndvZ1KHRVfiJt8CIP0CQgSkXPkCzz75nV5VbDmwkYjg1ZgtisIiec6gKIXgFPbiTMZwBpp+8o6IGv4lzhI7sCZn4cQL3xCa7FXaH5CperOIvt1wG2rLkWr4HowsuJRM/rK4i3wP+1ABv4JyRL3JmVEMT9YlPwo3sMbdn+BB6IVBnh2Nd6wgxAXRlhUlHVs0JJ7tb4QklLFKBikZkq4rWr/VtI4tjGJrioB+Dkz5N1KeysiV0lkA4U1X0RV5J1DXu4pAwh4Z+6COTHrlgdm2ysUXwEzkFAsxBG5XVtUMUCZoaEF34S6IiY5tJfgIN+4gFAxGlhqUVG3i2z1joVqOPhkKzVDxuLOjH3N/KcCxYMvHYlji7Wt2lDOzGA4dsKvvhoH1n4lNf3Djotttv6OLioGqrqtTcv0c9+RdH2oM4Ba4CiqPxU9QhnduDbhxGAoyJXLlUCExibnwd1MEXB03Nlc9JgqaA0ok4Bk8FT+SwqhU/SL2u7bPJrjwuWWQkn/XimyQ7/bnq6MXu2iAl/CjlymRdHTROSw+/qSegyeOgHduCH8nQB34emcBHfAtuykA+IonRNqlhLkDLm3rhaHfLLsGiWBcHbpnSkbh9HSpqTiCmCIIXmNtSsqpghyRedObHEZDoefFta6wkCLIp0rUzVv7QCx+I6BpM24pMkrJoLi1HGaRB4IoeMiOjM7R4oq8c1EZ+ucT9RRbSRMfgRp7YI6W0sbxiGthPSTwON7jgbMUip19dCj0yKKy2TVws/DNGBmeCSRAYXj4jlTr2JngzDXgmhkJX8FdFXfiWeLtbeaO5MbFTMhGyAHYGZede9rBnQezq6rMtMDeuBLZlF4unZUmDeKmUmJPD01V8tmVbkz4uCXXRw6up5ElMiMGGZkNdMud4ghX/J/QqyWXF5yn+ADrx5tbQbKnxJ8DBjh+DSZnbqujb4AIZ+sTHVUvKBmHqyAwUM4FtZJEJLXE0uUmNSUUm9FzBCECh2ciDYVs27djBNyl9nAaXlmIzCsbfYMQPlkRcRlLkgQklDvQFBU0hn0AXhd1wIHRCYawCd62UgAkFbMM/Lp2R4CWFlkUTmTifd+sZmInnYzkp1VaqYmBJ/ApUUhN0MGxj62zfpk1iZCn/gF0lJRHBtukkUGRQlxaWsTJVVQq58gIz/Qk/enQV+ly+II+p8OKj0A5/KWMzAxy/w0MMss/YZVlIg0kl21p/podPdGBKJy61I31wbZ91qZv4M5mbCZQ6E/7Xl42rQldyVCsvJGTlPRO30B/kOm1xdBWh4yW+JO/BG8Q2sRufq1u2NdEZyOAKmNzOwYcMghbfNv4xJtAHOY/+EufF2Chp2TF4JzaDy8uTBjzI6PMafSM1JPMXX4KRxe7QJVUZnZOqW6GffWk4Oa0uYsH2iZ19UosDWBV6mR9rHFEKL+3wgu0KdmmuuMd6MjWIt7oUvVwBJnqD2HK7K9on8K/HNfiGVrYlistUv1YminZEpiyO9M+VuhrV0OGvhJggVxbglWyvEozuVuFUEpfdp+CFDtRyPsmNozYY2IjDtuFNXT8HBw1xEwM2r3hKF2qw7ILHbcy0RhKCd4NgYzu+us50xJW2bdmWOHV1jMQxtTYA27AsnODEu/jFBIhuMGMTqmyvQbWxL9rECWnlIHJVLdtaf1VKf/1YV7e2q6tArgg7k/+w76puFXLBt8/ytpWBE0d8HPhiW5yStfwj6IWXPiQW4RHSkMGqZqzIyZoctgyubeVIDKlTbCt/lRq9Qf6MLKnUJDc7C3fft4jKvNqWba3dn9pl/DwhHlQSGRZ0cSSe4I1M0Mitq5DwuQWIzJ+goyWBYFshJW5akKZWXvDDLvpD15hNjqMXviu8qdhaELwsmjhoZ4E28gsTEqkUGuCRoDPgxDxwS4JJg8Emgb2dAxcgRgJdFe3USKeSK6sRfQhVraKfFZ+dY5JMrCyZga0qq2yd/yQbVGxFx2UNPAsvfSK96oMAPStYObAjmRN58C/ZQWzLPpfoRja7piWlnxhN29hIMizTk1bCaMWvkNbugS2igXrGjw6dNchGKDqst9VHVPEz/MRsm75lW9VFIR+0m7ar1sCnvTGpklsbWehdJZRk/BNH/KVaGUeCplXIZGJI1iRnqZkOSpxdhW7slXKM8Mm3TT8F4qB/xiWBZ8fxVSpbVVaO6KWV/An6oi3ZtKRx1R7kPVgRWW360bN5xXb8wwoQVvLdzKP0gxKI6Jwfa49lf6I/lbiGciUVQkfej1ApsnP5PpRNw8idc3Fafncx/9Af2BX2Td+2WtYaE3HQ51z5HGCJDjwMTpgC0tSxlj7MDNI4zWXcANLAp3kuyAuZODEwvJxfelLaCg54hUzkVpe+bWWwTnGAGTTYWQdOg8rue8qGsnbQQEVuyrLx0ZKLF3HYGgAW/dhKbRmTQwNfCv4EE0nZTrVs2pGZtMf6IGmCwSmL5EmKSiYsYjJzposX6E6HOv5Y/NkicZrLVmmxC7rAsZScVFs5jHwGf9HA627ia5VL3Zu6qVkIYlhGckJdyK0++EKftzrKY8Zqh6zwvZoDn8kQnXLpyM6afNqWnSIWKDLsvDirxGtD14IRQpz0LSVvWViDhBAKslKD2WUV/iT2lEmSdq5WE19Dt6yJn6kXf0oCY1DRoMnIopN/AXdiMhv61iXUFNEmH9u+0Ta5aGxJxh5atItONKT41eTL9vp3B/E3sRZAmFtxBqvwN/SUid2lR36NXGjpi8NirMjLegpkcYBi00oBJAEOAIRrqSdBDtoCSBwxFF7KaqM6wYiRiEQn4oELPQOUOjTUEbHclNgC27aKEpkET+aWTPDNQrnuWzmmbBKPvXIhQr9MkqQqAkPE9C2jBtqUMmjpw1p2kiwbiqF4IikVOsvv0FUwzqdtGlZsLf+wi1HkW7axO+lODRJKQ4PJsfIgwZeEunmJfmrbqsZPcK5pVaUubEI7sSkUg92NTHKDX4X+vBqPcy3ZjU/WRCZ2LQloxUfbsnTeLV0yJbtLsCGjF5r1WLzIdxWsiT5o8QPcQT2Jp7sf08muXNWysUAp9AYyOxMZzTXEXSWngCjEukvVnd6ymfxAXrK5NU57MZNK7Hb18iMCvmLmvaDocFKVqsgPvILQRRvdYFSXmkm/UYhGJ+4OCv7ildWFb+g1V6QSx0pCahIvOXmSUge4W7lfFe1rEAMyGQyLBJKgQYm3BT1BBy871iApZ5zSQCby4qheZjUIlK5sK3hLJm1kQ78ugw9CQlq7CvyB7chKIFpKm0qYVxI2Ebah5ISYBF9eHhW/q0qGvnYrXR1JXIiyuvEV/CQuuEAFUmc2ivKyd+YNDWIAUYKeUwgGToiuye1SDi+7XvirjUDjmylxeuFBE/qoKkV5TSOAV/SzP3hHY5JfWsLd5ePCCB3CiTfjdrEz5r4cC9CDt+KjPbJYqRGR7cf0bQzmpDa+Jb4JXhdxQBfFvAz0T+zoyeOAn1hPqbtU6DklGJT04ydeyLZyGLiElXbq4FyX5CeyzQQW4uHXld7ExooTj3OLNonhmCsf9LSrO6oajEvowa9iTPmEZ2ExiaJ/ie/B4oMwKNkBMRBB7GmQ2C5HXgGa9LNisSWbZGEsViKHqhwrV2WSmKy8rlZFNko4a6NHO5v5MU8T0r4q1S1XLQTbKtrBnAQh0HvbVSFc9dM8Syc1Qr410UtvgmmfuRkUQaymD/3EAh9gZKCs/Gkda3CgD3w/3jqqqxScWpjnSY46soARsGnlDJbLslOkdqnkpZ9NIxi53HdyUSWlWKQuFsFCeiaX0YcsTdnWwNgg5wjK+QsN/4y+gVk6yEOGK1V5+evVs1b+2xrEUwhNsFzQuaoM7HnplgZ2kp8JdhXA0AftiUw2MIPXVWqeYB3z7B1hIzOvNiS7dP0oWTCiN7hlDqwhZOM5MjlFOzTc4DZt4KsIzbycT9sq/BNHNWOJ8ImxyreQJ+2ukm1VNz4PbpWHyqX4DBkfSgBSpOilYYM/oRJLJvvyi9hCzkKraqKZ4LgAJxkwl7EGGNpp9UewcHiqoKdTcSbOgmR7geAjNcYwKBknTjhJgZGhXjr4I45U3UULzpKX1hshEpWgoMITNqliKwpBx5ZjF/Kq08dWWBm0iNmWbQ0GfhL4dQxpQwZz4ttYMhnggX8QSQL+gF0InbGlwnb48anKMoaCk2IbLwQNKnaO+A6bPQbvwYzMiQGsbnbgEcEVkJkBsOUq2YXKkIHipPYq4tjQy1gggHtD8cPGFvpIyfgDQ1ZwrBzxF+vEd1SudgO/7OhIiSF4KYWuqzQYX6N49gc5+nPhQ4TBOsfExP/JWOIn1gaYiWvSjm8Cf6QREEp8sC0DMcCrbtnW4BYkNJKgwv7AzkQeMUiTsk54xAPRsqp7FRt9sDKWg5zGXOfKkAZlTqSraIExpxCXLI65/LetotgQKbGdzanoRgnNs1J1KceRS8MRh9OeebkS9BlVAYjzCTB1AZoSURHYEkPRLtloUU8cj/ODBMaoZHbJ5r58U+G8bdkJFKeRiaysnGJWAQud4M76gHPGptEVgLaRtZY/fbYrjirzaiW2qtClLD5L7BqbGj5QIIB/leRgwFYmcTcDiJ6wbVu15Cc5mAq/qhQfqIQDsk0p5CjiIB9nGXxLN8ZiDbz43dWK/urCF4MpOrbPGNijoZkkSAvbxqas4IojOZn4jtCiNfe1Qt+2whvhWeJUxi79FNgQkcFedFN18WY0PkhMfCb9EsJp6uQlGPF7501w4dtg4YeWNlK4nuVAC/lli3E3licGoPIqrbGFVl2KHzI18RW5EPQT4z/JW0owJn0jk0UsC4yZSrZX6bYyX2cCMH5jM37Fjm1VlRDUY8fUsht5miojYPvKMcRod6MEdwkBnJysINK+yFCsVwAADutJREFUcsgu2aYUgcOFLpXwEBBpRBaMAl8kq1m1qFzJkij4JxYaDoDhVaotcSoHupzKTm2fiQWOTZvzxMCeuCwfsTtJ2PmpkhTMJPbE4CQJ3fiHjNArHLAsnOCcilxMFbwZOh2aZzpiRzaDydUE8poQsZnn+JERLyd4p3xKCi7haEaQV5eV/3XGNmIUWXnWX/jSVWvh2QbztPzILYttaU2EWvZnBnKBTsUmzCv55C4F/4l7qcEctDGtlCDZ1r5vsq3s2kdyjZisks1rcQuAw0V7YCc+502mS8IpFX4eySG984lcodPcjubWJMRqIwoIne5aOt1ND59ZiNlpURMGJcUrKXxLOpFbKqjocwr/B6Vg2qWJT5MxzrwZ1OHBUgEYfmiTcR3ccgUzj0aDt++t2BVya3wYI4Eb/fCDa/GHjfzLw4ojAYMmFwwaS4iAbEsYEc5ExrZsa+KQyLRBnKmjlwKhrvToLmcHDgwwMiERR18rCQPM6CbJNpjBiQDFPvdn7JCcyEGCI9wZq24M2KWulJbzhxCnbHopyGTSJp4BVnBSmD5Ym6rqhXXCvzRs43OSjx3k7fgh8Ipi5GtNQpRXX7KKgQ6+iCfFtmIreVUO6JywRnpRlW2wKC7lGEz2K8aqEFCKpdU/Lv6UiWfRKz7SF7YAt0uO8JJGSdDx/0TpbnXXmhTxc7LIIhZeoRRa+sCk0iQXBX7K1tgBIzJHJuxgIp3YdBpMoStZRtY2E/pE92x3gDEAPLGAbKurJPoxMJgPqEnQxTEpNnrh044tWaqybPK9MKSiHZ7tNQYd32Q0pBM+Ja4q/AVn4LPgRcfUsdEVH6TqZnzi61yYyMAQB1IZiImXKWkPAhEGS17CA2fihKBJcWQoR9FPQQjwAUerXo+TwHWEKNFdBRu2FYepFIUkbNKY2JySbMtx2hLimsPrKpWuvV6XPlwSwpQmcNtaOvLidbVsvC8rdmMv+HB1fSy+tQbJV0TbIjGrxHZ2kvg3SGx8C9ZyCmZ0znYMRpI75WWzziJgzTm0jskr5cSEzjwQyhO/q0tV58FDgpMRQCc81Fc/9ie73ViKgISBfnfLiY+8xb+BXnANL4vw1q1bK28LC0aFAaJt2VY1domjymuRQDrnk1gHvmVnLYjZVa8x4kNoyREsxnouLIuQ8SM8VDXwJbFO6Ha4q7HGghGhwxlBBCyRv1KzoRhysONTV9PLiZDCsWzryFzU8rs0sJn5CvCKFYGcqrLEGaxoiyNyVWcdgRMRyJx0hDCYwVW3SUjLSEwYDIlsyygbccgKUJJyYkCPOHRal1nj0EC2dKQf/kiQ8pIXdRyeJCfOrDbJZrroxC5T3coxCWpCn+jGtgovYtROnDqy6k/YLGhNgRw1TfRCs82bwfxjCG4zmDjthsdCifPsgrE7wFfwU6LteCH8j8UUrXQYnxu8rlIhY/tcK4kcih9L0uKY6FDAduEr/jQxLVvho8tJbgvTxERnIosGVhCIL5Rt25XJlzejUFXVsktV5/t0O1QKshiUHV7JhhYCnmxMpo1bz8IP2FCwVyUhMhib01UOd2RO5DKl4Nv4LSltoZtbYEcJ2hqPqXP+eRo0iI+uqMjDWDpHsESOOz5Hn/iET9WgTC2k7l02vsgqZESd+XLkcXXaA53Mj1ypmvwJnyxQoNsl2+RPLNaTqkuRSY3IeREkL0smmZ34dsTHzEsp2JETc7DswFLimBkUOK5CYVCYPABFxLYKuulPghlETFPmL4ZtWpYEMfyUOGVD5ISxzoWBWM7odRdNyy4VAxGhLtrdqsWTbIcsX/2Jo6tlG3OxpNW2kaAkcZlUVaWugjkZjiFcXvIQROCpiIQKHZGMVImruxbeCE1Xh8+5mWiQqvW6oFGyY7eWYHyeGJqy1glvMmhNbLZVRenGlyWBH+CSs4FM5GlKNAY7/bLv0gAv/Yk/KxEIDSZZ+pm0Z5+mcmBVNnmhc2JjwoBcJecPrAmW4Tl+hE7niJztSGiCbfgTWzSxPXRisaRf6MT+DGNJV7oKvarkK34ZhLhDBZTsUvhAaqCb/pHNbkKY9DPJAxQ/he6JhXmWM3pmsY3lF686L0YhZhX4hfz/xbO5IFaO6kD0lMjr2f92O9fwTuGkaduAVCp9wJ8kM3bUXdd9ZmkzCOAKwWHEGoNY2jJX9lgL7cNaCgbbUWHnEfxnUi3YcxfHohrs9pE0ylWLEj+5jlS9Tlzc1AGvfNRPHR9h9sU5dIJ36nuDtQiV1dfS9rhdtaYJRJ7qZ43TQxLl597527h2i2giVojHTbF1cIyson66PA5mlhLtZFjri1+umTFm5R7C2L2ILJdQ1ujz8h1F27M94t7xo39463KMYztvDiNflGOrL4z5d96NO5FXX2+cfSo1jrsA9ImNzhsbaKXt8uZZU70WHkloi3o8m3f9qiJyc9thGsiWTV+Z2kNNH+fHvForbNfeOYHH/jEPOnHcWL/WIjFmHcwa+p9vC6VcvQi7a2nYt0bR79ZHc60fI3BtDERAc9nWqnblLnYYYnyXU0zHA74BFzev4utb3iR0XY8xFrd1nuSuCerr8/EGCpGh66WhsThh3Af3rKoCMbMl6p1zZSVTeMcC2ktxyUssFe7Nm0ztmtx9yhhAItqjuLVGa0zlaHsuYxOPku1r89hfQG0cJDF2T5F/+1sVfu2hCWJc279s1uy1lTOWzYSvlX6xrbW8VifKoiVBiOaHxruVPT55+ncHhebhDQgcC/TlAjjAEC729t5QkaC8xxjWTMWM/bFuBeuCNtUUVx2iln886rx+R1B9l6O6/mEGW8Q1JyPgGFvn/WY/krWuR2XtklYOZrkhlFUuhO1FFWuatyzG9BizZDK/NsWUr0/cO75+DzPyTewX//35z94Nbh3WzA9faNuuF7Kd60vOjXX7MEsC6vPpxZGdOQiz5sOfP39YPzfuzKJxVtd6JBG85bH+Cj992xl34xv9j/po88hX4t4oaBLeGGfdCf2MWzPyGBTG5edT45pZ3Hyth2I+9tvctnzbMZId58exX9bnljQSuXUo4FFxpafQkKQ15bb0eizSW4CpnfiKW6TO5S5IzAIVjwneBVURBQEyIYmFAOwa3H29xYTkK1fV5XtjE6bNK5+a0FZM+y13/XQ8FiBipf0X91pD/6FBMsLCZNEAEvNzNLNIQot4/ZgbqJMbW304dXRIsaVx1qOL3YJWH31/XNDHT4vq7nlg5Iu6tZY1h+Z8dRpFXX3OLCZz9dXFy93UYsrfeZUpj+dol4TOScCjl+3GQqDRk+Se5d+tLW36MKY+sLbrc5RnlNcuiAfspXifuA6OdThuopGvuR2x0UgaFInP7be4v99/eXxofazDx4daZd1T0nCbBjd2wvvWA0U+X7f+PLX7tTn6PPrajTFm5c9007WbZgdjj215w22xPcsNsZZhjblex0bqF8zRS31Fu2pkRKf+MCGQn5bE0fm3gcZ5Upniezi+8/NvIRtgnavR3eHjq8i4DSMcg28SiePGobSclZWutmvuCqiBzuNoxuu1OXJoKHhfUuXqrTWonzVUomNeTv1Uor2WVN6E14grvn2FQJKbP4EjYe2TGMOxgNy2lV+/2iQFVjdXV98Y06uPw+revlxI3BjKrSWPdSnFGMNuXVyQ7cJNhQIeFx9ltU26Qb6gfsVHrubxi931K0dEJFErUlkyTG+mtdS0brmfFEvZ/ZuE2PI3wXLgXBcQc7r2xu8N/ManGOdXPtbld86/tmus3jI50p9HkgZDEjIRexzjGUKbVTHv3igkHvrY3A07awwt9OZIRtmCSAdkhjgeLzcHlFuD1k06RvxRloSs2oXVntAW+1mLNSM2wavHyHLIhOQOuQv2OzetyhNxstyimbBibRd9XS2/r2uzjaKBhbCufXDIrIXMHVrE7QlJ7M36QD9/xqAsC20fF+DTTxZ/CJvyeIJc168GyKavu0itvLrk5bMzLsdyoLzxFPe4uRpfefvG6duun4Brvt44pG8MI0HPR94kJJ7UHwSb88e4HCm8V1aGx3gRUY4k1O/f729QhvNt7IkMN/wwq/WMvzEOj4uYOJ4x9kVr+9FHn6AScdR/jP8YU3l8cEupjwLRTlt6ApX26f5oj21709UWb6z+H3vNvRsFuZLQGmD/iPut0/KJ+uVvo6I9+mgu23q/63OMUUWV5uKD1cl71D6jwqP25dXczvqYw/GMOR4E6HNWKPeVK6u9Ak0On28/kxzVP+qSH+zB0A/bImxrutx797dmP37RprpjvTp+XBe9MbHecvTz6XFvTKJYghuAyTkjyT1FU2MIbb+BJbmSXhOvckok9JAu6IEktHUBj8GUvxJV0AGw9XdckCTEgixtHTV3ilEEDhKUHY6F88ptyvbZjKDEotSHxRBOYkA3p01GnX4Q3+TrJwmV4y7owpXj/MZR4MG3l7aJrtRoX8zdrPKWh/YrHDdQc0Ps4fD15Q/Z+mytFFG7/ynr+PzwhLy5y3E8daLlIVHuoqDsVBiIPkLUWwNglUv+yTArCotUr019FlhOpzRX7yxIWGshWnVI4oZ/bgxOdHeInM2l8SYvpmtXTmdixQQm1hbdepo6sU/CrJEbtmtQX8e1qqCxYEtEGlS0OM57JOEX51C42g6KKaj4QCLuZ4y9QMZ4k/zkVf3W91btKhjYmrl22/H2JphZ5vyjl6P0kWO2k5EoCWI9D9vge3ZzQJjxzLzOxHFPbutTq1g9Q4MFIh5bi9JxKu9FGYJ02c5Ru6Gt6u3iN56Oy9f5abY/SNob+SujkBtr+W6CKDOJG4/YRMfKlk+HtYbGctyEySCMbo4Ya/n2FUBzvU+LAJ7Nb5IOOWJmtG1Myuq3tsV8fMIYmryHbf1mQvWTxXF+TWQ5Cstx4wm2F1db5Fw+dfsQuTYaFfLzpBKL3P4+Wz6h8h4Rii9n6L9tfkqgAIrf1P5jbRHdmm7zqCzqkwjtiblPIWz5hN554z2diG2M3UxxHOK1kogzh829OZrb44ZLIo8bTttx/P58Jnb9+DCH7c1S/iQgX6/b+LtvnJIRq33lRD55d+2Ufftmay61b3zbmLd5dY4GSejDqAnNLNYaXeS+Zbc+Lg74PwAAAP//IWWmcAAAAAZJREFUAwCnoT+sOdq4egAAAABJRU5ErkJggg==";
//#endregion
//#region src/server/features/reports/reportSocialImage.tsx
var import_jsx_runtime = require_jsx_runtime();
/** One template for all reports. Assets stay local; titles never go to an image service. */
async function renderReportSocialImage(title, projectDomain) {
	const domain = domainField.safeParse(projectDomain);
	const response = new ImageResponse(/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		style: {
			width: "100%",
			height: "100%",
			position: "relative",
			display: "flex",
			flexDirection: "column",
			padding: 64,
			backgroundColor: "#f5f4ef",
			color: "#1d2925"
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 20
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: android_chrome_192x192_default,
					width: 64,
					height: 64,
					style: { borderRadius: 14 }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						fontSize: 34,
						fontWeight: 600,
						letterSpacing: -1
					},
					children: "OpenSEO"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					display: "flex",
					flex: 1,
					alignItems: "center",
					paddingTop: 24
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					style: {
						fontSize: title.length > 85 ? 54 : title.length > 48 ? 64 : 80,
						fontWeight: 700,
						letterSpacing: -2,
						lineHeight: 1.12,
						overflowWrap: "anywhere"
					},
					children: title
				})
			}),
			domain.success && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				style: {
					position: "absolute",
					right: 64,
					bottom: 28,
					maxWidth: "80%",
					fontSize: 24,
					fontWeight: 400,
					color: "#65716b",
					whiteSpace: "nowrap",
					overflow: "hidden",
					textOverflow: "ellipsis"
				},
				children: domain.data
			})
		]
	}), {
		width: 1200,
		height: 630,
		format: "png",
		emoji: "from-font",
		headers: {
			"Cache-Control": "no-store",
			"X-Robots-Tag": "noindex, nofollow",
			"X-Content-Type-Options": "nosniff"
		}
	});
	await response.ready;
	return response;
}
//#endregion
export { renderReportSocialImage };
