import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { o as authRedirectSearchSchema } from "./AuthPage-Bxu7AMPh.js";
//#region src/routes/_auth.tsx
var $$splitComponentImporter = () => import("./_auth-D-QHwZI_.js");
var Route = createFileRoute("/_auth")({
	validateSearch: authRedirectSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
