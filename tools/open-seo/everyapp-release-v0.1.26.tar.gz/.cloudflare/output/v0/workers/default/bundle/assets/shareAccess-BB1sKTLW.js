import { G as eq, Q as isNull, U as desc, W as and, t as db } from "./db-DhHkpZWI.js";
import { a as sum, t as count } from "./aggregate-CkzWoiih.js";
import { R as projects, W as reports } from "./schema-Cn_vcAkd.js";
import { s as usesBetterAuthServer } from "./runtime-env-eoXh4Ywz.js";
//#region src/server/features/reports/repositories/ReportRepository.ts
var metadataColumns = {
	id: reports.id,
	projectId: reports.projectId,
	title: reports.title,
	summary: reports.summary,
	skill: reports.skill,
	templateId: reports.templateId,
	createdBy: reports.createdBy,
	createdByUserId: reports.createdByUserId,
	sizeBytes: reports.sizeBytes,
	shareToken: reports.shareToken,
	sharedAt: reports.sharedAt,
	createdAt: reports.createdAt,
	updatedAt: reports.updatedAt
};
async function listReports(params) {
	return db.select(metadataColumns).from(reports).where(eq(reports.projectId, params.projectId)).orderBy(desc(reports.updatedAt), desc(reports.id)).limit(params.limit).offset(params.offset);
}
async function getReport(projectId, reportId) {
	const [row] = await db.select(metadataColumns).from(reports).where(and(eq(reports.id, reportId), eq(reports.projectId, projectId))).limit(1);
	return row ?? null;
}
async function getReportProjectId(reportId) {
	const [row] = await db.select({ projectId: reports.projectId }).from(reports).where(eq(reports.id, reportId)).limit(1);
	return row?.projectId ?? null;
}
async function getReportHtml(projectId, reportId) {
	const [row] = await db.select({ html: reports.html }).from(reports).where(and(eq(reports.id, reportId), eq(reports.projectId, projectId))).limit(1);
	return row?.html ?? null;
}
async function getReportWithHtml(projectId, reportId) {
	const [row] = await db.select({
		...metadataColumns,
		html: reports.html
	}).from(reports).where(and(eq(reports.id, reportId), eq(reports.projectId, projectId))).limit(1);
	return row ?? null;
}
async function findReportByTitle(projectId, title) {
	const [row] = await db.select({
		id: reports.id,
		title: reports.title
	}).from(reports).where(and(eq(reports.projectId, projectId), eq(reports.title, title))).limit(1);
	return row ?? null;
}
async function countReports(projectId) {
	const [row] = await db.select({ value: count() }).from(reports).where(eq(reports.projectId, projectId));
	return row?.value ?? 0;
}
async function sumReportBytesForOrganization(organizationId) {
	const [row] = await db.select({ value: sum(reports.sizeBytes) }).from(reports).innerJoin(projects, eq(projects.id, reports.projectId)).where(eq(projects.organizationId, organizationId));
	return Number(row?.value ?? 0);
}
async function insertReport(params) {
	const now = (/* @__PURE__ */ new Date()).toISOString();
	await db.insert(reports).values({
		...params,
		createdAt: now,
		updatedAt: now
	});
}
async function updateReportContent(params) {
	await db.update(reports).set({
		title: params.title,
		summary: params.summary,
		html: params.html,
		skill: params.skill,
		templateId: params.templateId,
		sizeBytes: params.sizeBytes,
		updatedAt: (/* @__PURE__ */ new Date()).toISOString()
	}).where(and(eq(reports.id, params.reportId), eq(reports.projectId, params.projectId)));
}
async function getSharedReportByToken(token) {
	const [row] = await db.select({
		id: reports.id,
		projectId: reports.projectId,
		organizationId: projects.organizationId,
		projectDomain: projects.domain,
		title: reports.title,
		summary: reports.summary,
		skill: reports.skill,
		updatedAt: reports.updatedAt,
		archivedAt: projects.archivedAt
	}).from(reports).innerJoin(projects, eq(projects.id, reports.projectId)).where(eq(reports.shareToken, token)).limit(1);
	if (!row) return null;
	const { archivedAt, ...report } = row;
	return {
		...report,
		archived: archivedAt !== null
	};
}
async function setShareToken(projectId, reportId, share) {
	return (await db.update(reports).set({
		shareToken: share?.shareToken ?? null,
		sharedAt: share?.sharedAt ?? null
	}).where(and(eq(reports.id, reportId), eq(reports.projectId, projectId), share ? isNull(reports.shareToken) : void 0)).returning({ id: reports.id })).length > 0;
}
/** True when a row was deleted; false when the id is not in this project. */
async function deleteReport(projectId, reportId) {
	return (await db.delete(reports).where(and(eq(reports.id, reportId), eq(reports.projectId, projectId))).returning({ id: reports.id })).length > 0;
}
var ReportRepository = {
	listReports,
	getReport,
	getReportProjectId,
	getReportHtml,
	getReportWithHtml,
	getSharedReportByToken,
	setShareToken,
	findReportByTitle,
	countReports,
	sumReportBytesForOrganization,
	insertReport,
	updateReportContent,
	deleteReport
};
//#endregion
//#region src/server/features/reports/shareAccess.ts
/**
* Sharing needs a deployment with its own accounts (hosted and password modes): a
* public origin and a sign-in page. The other self-hosted modes are behind
* Cloudflare Access or have no auth at all, and neither can serve a link to a
* reader who is not signed in. One predicate, so the mint, the share page and
* the raw endpoint cannot disagree.
*/
function sharesEnabled() {
	return usesBetterAuthServer();
}
/**
* The shape check both public entry points run before touching the database, so
* a scanner walking `/s/<anything>` is answered without a query. Matches what
* mintShareToken emits: 32 base64url characters.
*/
var SHARE_TOKEN_PATTERN = /^[A-Za-z0-9_-]{32}$/;
//#endregion
export { sharesEnabled as n, ReportRepository as r, SHARE_TOKEN_PATTERN as t };
