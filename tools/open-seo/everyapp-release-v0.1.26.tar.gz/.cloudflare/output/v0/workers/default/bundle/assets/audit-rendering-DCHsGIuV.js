import { N as creditsForProviderUsd, j as autumnSeoDataCreditsToUsd } from "./onboarding-drip-B7bIbv_6.js";
//#region src/shared/audit-rendering.ts
var CLOUDFLARE_RENDER_TIMEOUT_MS = 2e4;
var CLOUDFLARE_USD_PER_ATTEMPT = CLOUDFLARE_RENDER_TIMEOUT_MS / 36e5 * .09;
var CONTEXT_USD_PER_CREDIT = .0025;
/**
* Why a rendered audit can't start behind an Every App gateway: the Context
* key is the gateway's, and optional in the manifest, so audits run
* unrendered until an admin sets it once for every app. Plain text: it is
* shown by ErrorState, toasts and MCP answers as is.
*/
var GATEWAY_RENDERING_NOT_SET_UP_MESSAGE = "JavaScript rendering isn't set up on your Every App gateway yet. An owner or admin sets it with pnpm everyapp secret set CONTEXT_API_KEY.";
function renderUsageCredits(usage) {
	return creditsForProviderUsd(usage.cloudflareAttempts * CLOUDFLARE_USD_PER_ATTEMPT + usage.contextCredits * CONTEXT_USD_PER_CREDIT);
}
/**
* Usage-credit range for rendering up to `maxPages` pages. The low end renders
* every page on Cloudflare, which is what most sites cost. The high end is
* every page falling back to Context after its Cloudflare attempt.
*/
function estimateRenderingCredits(maxPages) {
	return {
		low: renderUsageCredits({
			cloudflareAttempts: maxPages,
			contextCredits: 0
		}),
		high: renderUsageCredits({
			cloudflareAttempts: maxPages,
			contextCredits: maxPages
		})
	};
}
/**
* What a hosted rendered audit holds when it starts, and the most it charges:
* twice the Cloudflare-only estimate. Most pages render on Cloudflare, so
* this covers almost every audit without holding the Context worst case.
*/
function renderingHoldCredits(maxPages) {
	return estimateRenderingCredits(maxPages).low * 2;
}
/**
* Usage credits as the dollars users see everywhere else. Rounded up to the
* cent, so an account holding the shown amount always covers the hold.
*/
function formatRenderingUsd(credits) {
	return `$${(Math.ceil(autumnSeoDataCreditsToUsd(credits * 100)) / 100).toFixed(2)}`;
}
/** Why a hosted account cannot start a rendered audit of `maxPages` pages. */
function renderingCreditsNeededText(maxPages) {
	return `Rendering up to ${maxPages.toLocaleString("en-US")} pages needs ${formatRenderingUsd(renderingHoldCredits(maxPages))} of credits available. Lower the page limit or add credits.`;
}
var RENDERING_COST_NOTE = "Sites that block our browser need an advanced renderer. If the cost is higher than expected, it will stop.";
function renderingCostText(maxPages) {
	return `Costs up to ${formatRenderingUsd(renderingHoldCredits(maxPages))}.`;
}
function renderingEstimateText(maxPages) {
	return `${renderingCostText(maxPages)} ${RENDERING_COST_NOTE}`;
}
//#endregion
export { renderingCostText as a, renderingHoldCredits as c, RENDERING_COST_NOTE as i, CONTEXT_USD_PER_CREDIT as n, renderingCreditsNeededText as o, GATEWAY_RENDERING_NOT_SET_UP_MESSAGE as r, renderingEstimateText as s, CLOUDFLARE_RENDER_TIMEOUT_MS as t };
