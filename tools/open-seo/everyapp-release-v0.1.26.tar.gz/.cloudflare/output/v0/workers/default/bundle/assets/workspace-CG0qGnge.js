import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { St as SHARED_WORKSPACE_ORGANIZATION_ID } from "./resolve-DrNDcpX6.js";
import { U as AppError } from "./onboarding-drip-B7bIbv_6.js";
import { n as getAuthMode } from "./auth-mode-DhGCw2Bx.js";
import { $ as like, G as eq, Q as isNull, W as and, X as inArray, t as db } from "./db-DhHkpZWI.js";
import { M as organizationActivationState, Q as userOnboardingAnswers, R as projects, j as organization, v as ga4Connections, y as gscConnections } from "./schema-Cn_vcAkd.js";
import { n as runBatch } from "./runBatch-CENJH-Sm.js";
import { t as n } from "./firstBy-CZOZmzYv.js";
import { t as e } from "./identity-41c0vDC1.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
import { env } from "cloudflare:workers";
//#region src/server/auth/workspace-merge.ts
function earliest(values) {
	return n(values.filter((value) => value !== null), e()) ?? null;
}
var legacyWorkspaceFilter = like(organization.id, "delegated-%");
async function countLegacyWorkspaces() {
	return (await db.select({ id: organization.id }).from(organization).where(legacyWorkspaceFilter)).length;
}
async function mergeLegacyWorkspaces$1() {
	if (getAuthMode(env.AUTH_MODE) !== "cloudflare_access") throw new AppError("FORBIDDEN", "Workspace merge is only available in cloudflare_access auth mode.");
	const legacyOrgs = await db.select({
		id: organization.id,
		name: organization.name
	}).from(organization).where(legacyWorkspaceFilter);
	if (legacyOrgs.length === 0) return { mergedWorkspaces: 0 };
	const legacyIds = legacyOrgs.map((org) => org.id);
	const ownerLabelByOrgId = new Map(legacyOrgs.map((org) => [org.id, org.name.replace(/ workspace$/, "")]));
	const conflictingDefaults = await db.select({
		id: projects.id,
		organizationId: projects.organizationId
	}).from(projects).where(and(inArray(projects.organizationId, legacyIds), eq(projects.name, "Default"), isNull(projects.domain), isNull(projects.archivedAt)));
	const activationRows = await db.select().from(organizationActivationState).where(inArray(organizationActivationState.organizationId, [SHARED_WORKSPACE_ORGANIZATION_ID, ...legacyIds]));
	const mergedActivation = {
		firstMcpAuthorizedAt: earliest(activationRows.map((row) => row.firstMcpAuthorizedAt)),
		firstMcpToolCallAt: earliest(activationRows.map((row) => row.firstMcpToolCallAt))
	};
	const repointToShared = { organizationId: SHARED_WORKSPACE_ORGANIZATION_ID };
	await runBatch((tx) => [
		...conflictingDefaults.map((project) => tx.update(projects).set({ name: `Default (${ownerLabelByOrgId.get(project.organizationId) ?? "imported"})` }).where(eq(projects.id, project.id))),
		tx.update(projects).set(repointToShared).where(inArray(projects.organizationId, legacyIds)),
		tx.update(userOnboardingAnswers).set(repointToShared).where(inArray(userOnboardingAnswers.organizationId, legacyIds)),
		tx.update(gscConnections).set(repointToShared).where(inArray(gscConnections.organizationId, legacyIds)),
		tx.update(ga4Connections).set(repointToShared).where(inArray(ga4Connections.organizationId, legacyIds)),
		...activationRows.length > 0 ? [tx.insert(organizationActivationState).values({
			organizationId: SHARED_WORKSPACE_ORGANIZATION_ID,
			...mergedActivation
		}).onConflictDoUpdate({
			target: organizationActivationState.organizationId,
			set: mergedActivation
		})] : [],
		tx.delete(organization).where(inArray(organization.id, legacyIds))
	]);
	return { mergedWorkspaces: legacyOrgs.length };
}
var WorkspaceMergeService = {
	countLegacyWorkspaces,
	mergeLegacyWorkspaces: mergeLegacyWorkspaces$1
};
//#endregion
//#region src/serverFunctions/workspace.ts?tss-serverfn-split
function isCloudflareAccessMode() {
	return getAuthMode(env.AUTH_MODE) === "cloudflare_access";
}
var getWorkspaceMergeStatus_createServerFn_handler = createServerRpc({
	id: "bae0716c278ff567d6fca6035b6fc999ec74301979582cb6eb930ca66771f85f",
	name: "getWorkspaceMergeStatus",
	filename: "src/serverFunctions/workspace.ts"
}, (opts) => getWorkspaceMergeStatus.__executeServer(opts));
var getWorkspaceMergeStatus = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).handler(getWorkspaceMergeStatus_createServerFn_handler, async () => {
	if (!isCloudflareAccessMode()) return { legacyWorkspaceCount: 0 };
	return { legacyWorkspaceCount: await WorkspaceMergeService.countLegacyWorkspaces() };
});
var mergeLegacyWorkspaces_createServerFn_handler = createServerRpc({
	id: "dd3518eb8d7349f47f651bb345e6a70e7b48073f2557d873f09c577b0deab0bb",
	name: "mergeLegacyWorkspaces",
	filename: "src/serverFunctions/workspace.ts"
}, (opts) => mergeLegacyWorkspaces.__executeServer(opts));
var mergeLegacyWorkspaces = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).handler(mergeLegacyWorkspaces_createServerFn_handler, async () => WorkspaceMergeService.mergeLegacyWorkspaces());
//#endregion
export { getWorkspaceMergeStatus_createServerFn_handler, mergeLegacyWorkspaces_createServerFn_handler };
