import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
//#region src/routes/_app/p/$projectId/sam.tsx
var $$splitComponentImporter = () => import("./sam-D-SkzIPY.js");
var samSearchSchema = object({ s: string().optional() });
var Route = createFileRoute("/_app/p/$projectId/sam")({
	validateSearch: samSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
