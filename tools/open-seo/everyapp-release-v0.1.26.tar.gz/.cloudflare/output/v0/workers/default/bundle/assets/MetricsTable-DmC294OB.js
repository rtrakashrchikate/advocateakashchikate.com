import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { a as TableHead, i as TableCell, n as TableBody, o as TableHeader, s as TableRow, t as Table } from "./table-CqwvrC02.js";
//#region src/client/components/MetricsTable.tsx
var import_jsx_runtime = require_jsx_runtime();
function MetricsTable({ rows, showChange = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Metric" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
			className: "text-right",
			children: "Value"
		}),
		showChange && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {
			className: "text-right",
			children: "Change"
		})
	] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: rows.map((row, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: row.label }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-right tabular-nums",
			children: row.value
		}),
		showChange && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
			className: "text-right tabular-nums",
			children: row.change ?? "\u2014"
		})
	] }, index)) })] });
}
function percentChange(current, previous) {
	if (current === null || previous === null || previous <= 0) return null;
	return Math.round((current - previous) / previous * 100);
}
//#endregion
export { percentChange as n, MetricsTable as t };
