import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as cn } from "./dist-fVOGIv0D.js";
import { B as cva, d as useButton, i as useRenderElement } from "./button-DrcZrdio.js";
import { D as useControlled, M as useBaseUiId, t as createChangeEventDetails, y as none } from "./createBaseUIEventDetails-CaTwrmZM.js";
import { t as CompositeItem } from "./CompositeItem-DehNJvwY.js";
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/toggle-group/ToggleGroupContext.mjs
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var ToggleGroupContext = /*#__PURE__*/ import_react.createContext(void 0);
function useToggleGroupContext() {
	return import_react.useContext(ToggleGroupContext);
}
//#endregion
//#region node_modules/.pnpm/@base-ui+react@1.8.0_@types+react@19.2.14_react-dom@19.2.4_react@19.2.4__react@19.2.4/node_modules/@base-ui/react/toggle/Toggle.mjs
var import_jsx_runtime = require_jsx_runtime();
var Toggle$1 = /*#__PURE__*/ import_react.forwardRef(function Toggle(componentProps, forwardedRef) {
	const { className, defaultPressed = false, disabled: disabledProp = false, form, onPressedChange, pressed: pressedProp, render, type, value: valueProp, nativeButton = true, style, ...elementProps } = componentProps;
	const value = useBaseUiId(valueProp || void 0);
	const groupContext = useToggleGroupContext();
	const groupValue = groupContext?.value ?? [];
	const disabled = (disabledProp || groupContext?.disabled) ?? false;
	const [pressed, setPressedState] = useControlled({
		controlled: groupContext ? value !== void 0 && groupValue.indexOf(value) > -1 : pressedProp,
		default: defaultPressed,
		name: "Toggle",
		state: "pressed"
	});
	const { getButtonProps, buttonRef } = useButton({
		disabled,
		native: nativeButton
	});
	const state = {
		disabled,
		pressed
	};
	const refs = [buttonRef, forwardedRef];
	const props = [
		{
			"aria-pressed": pressed,
			onClick(event) {
				const nextPressed = !pressed;
				const details = createChangeEventDetails(none, event.nativeEvent);
				onPressedChange?.(nextPressed, details);
				if (details.isCanceled) return;
				if (value) groupContext?.setGroupValue?.(value, nextPressed, details);
				if (details.isCanceled) return;
				setPressedState(nextPressed);
			}
		},
		elementProps,
		getButtonProps
	];
	const element = useRenderElement("button", componentProps, {
		enabled: !groupContext,
		state,
		ref: refs,
		props
	});
	const itemMetadata = import_react.useMemo(() => ({
		disabled,
		focusableWhenDisabled: false
	}), [disabled]);
	if (groupContext) return /*#__PURE__*/ (0, import_jsx_runtime.jsx)(CompositeItem, {
		tag: "button",
		render,
		className,
		style,
		metadata: itemMetadata,
		state,
		refs,
		props
	});
	return element;
});
//#endregion
//#region src/client/components/ui/toggle.tsx
var toggleVariants = cva("group/toggle inline-flex items-center justify-center gap-1 rounded-lg text-sm font-medium whitespace-nowrap transition-all outline-none hover:bg-muted hover:text-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-destructive/20 aria-pressed:bg-muted data-[state=on]:bg-muted dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4", {
	variants: {
		variant: {
			default: "bg-transparent",
			outline: "border border-input bg-transparent hover:bg-muted"
		},
		size: {
			default: "h-10 min-w-10 px-3",
			sm: "h-7 min-w-7 rounded-[min(var(--radius-md),12px)] px-2.5 text-[0.8rem] [&_svg:not([class*='size-'])]:size-3.5",
			lg: "h-12 min-w-12 px-4 text-base"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Toggle({ className, variant = "default", size = "default", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle$1, {
		"data-slot": "toggle",
		className: cn(toggleVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
//#endregion
export { ToggleGroupContext as i, toggleVariants as n, Toggle$1 as r, Toggle as t };
