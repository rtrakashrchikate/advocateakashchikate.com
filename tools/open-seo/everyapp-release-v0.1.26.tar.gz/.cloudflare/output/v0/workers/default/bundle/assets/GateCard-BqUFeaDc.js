import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as cn } from "./dist-fVOGIv0D.js";
import { r as CardContent, t as Card } from "./card-CqQO-5bL.js";
//#region src/client/components/GateCard.tsx
var import_jsx_runtime = require_jsx_runtime();
var ICON_TONES = {
	primary: "bg-primary/10 text-primary",
	warning: "bg-warning/15 text-warning-foreground dark:text-warning"
};
/**
* The card that stands in for a feature the user cannot use yet: a paid-plan
* upsell, a beta opt-in or a missing setup step. It says what the feature
* does and gives the one action that unlocks it.
*/
function GateCard({ icon: Icon, tone = "primary", badge, title, description, actions, features, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		size: "lg",
		className: cn("w-full gap-0 py-0", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
			className: "space-y-5 py-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						Icon ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: cn("flex size-10 items-center justify-center rounded-lg", ICON_TONES[tone]),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-5",
								"aria-hidden": true
							})
						}) : null,
						badge,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-semibold tracking-tight",
							children: title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3 text-sm leading-relaxed text-muted-foreground",
							children: description
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap items-center gap-3",
					children: actions
				}),
				children
			]
		}), features ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
			className: "grid grid-cols-1 gap-5 border-t border-border py-6 sm:grid-cols-3",
			children: features.map((feature) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "inline-flex size-9 items-center justify-center rounded-lg bg-primary/10 text-primary",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(feature.icon, {
							className: "size-4",
							"aria-hidden": true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-sm font-semibold",
						children: feature.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-relaxed text-muted-foreground",
						children: feature.body
					})
				]
			}, feature.title))
		}) : null]
	});
}
//#endregion
export { GateCard as t };
