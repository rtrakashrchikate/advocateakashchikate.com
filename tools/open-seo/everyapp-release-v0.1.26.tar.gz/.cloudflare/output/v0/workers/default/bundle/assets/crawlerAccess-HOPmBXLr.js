import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { t as requireOrgPermission } from "./org-gate-CXPt5GkI.js";
import { n as requireAuthenticatedContext, r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { n as saveCrawlerCredentialSchema, t as deleteCrawlerCredentialSchema } from "./crawlerAccess-BD3fH5iy.js";
import { t as CrawlerCredentialService } from "./CrawlerCredentialService-fwwFRyWZ.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/serverFunctions/crawlerAccess.ts?tss-serverfn-split
var listCrawlerCredentials_createServerFn_handler = createServerRpc({
	id: "28befcfbcf5683730f549639069058edbfbd3a389e71ce306bfa660e36ccc7e2",
	name: "listCrawlerCredentials",
	filename: "src/serverFunctions/crawlerAccess.ts"
}, (opts) => listCrawlerCredentials.__executeServer(opts));
var listCrawlerCredentials = createServerFn({ method: "GET" }).middleware(requireAuthenticatedContext).handler(listCrawlerCredentials_createServerFn_handler, async ({ context }) => CrawlerCredentialService.listCrawlerCredentials(context.organizationId));
var saveCrawlerCredential_createServerFn_handler = createServerRpc({
	id: "8907d86e952b72ab2aa7e04f0b8bc7bdd81fca3ab7ebd77a59a2f880da0ec188",
	name: "saveCrawlerCredential",
	filename: "src/serverFunctions/crawlerAccess.ts"
}, (opts) => saveCrawlerCredential.__executeServer(opts));
var saveCrawlerCredential = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(saveCrawlerCredentialSchema).handler(saveCrawlerCredential_createServerFn_handler, async ({ data, context }) => {
	requireOrgPermission(context, { integration: ["manage"] });
	return CrawlerCredentialService.saveCrawlerCredential({
		organizationId: context.organizationId,
		projectId: context.projectId,
		userId: context.userId,
		host: data.host,
		signatureInput: data.signatureInput,
		signature: data.signature
	});
});
var deleteCrawlerCredential_createServerFn_handler = createServerRpc({
	id: "ce94acd9176be823a5dd0d1b5646b9a89bb6b8aa358cd355778fc6ee44d601ad",
	name: "deleteCrawlerCredential",
	filename: "src/serverFunctions/crawlerAccess.ts"
}, (opts) => deleteCrawlerCredential.__executeServer(opts));
var deleteCrawlerCredential = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(deleteCrawlerCredentialSchema).handler(deleteCrawlerCredential_createServerFn_handler, async ({ data, context }) => {
	requireOrgPermission(context, { integration: ["manage"] });
	await CrawlerCredentialService.deleteCrawlerCredential({
		organizationId: context.organizationId,
		id: data.id
	});
	return { success: true };
});
//#endregion
export { deleteCrawlerCredential_createServerFn_handler, listCrawlerCredentials_createServerFn_handler, saveCrawlerCredential_createServerFn_handler };
