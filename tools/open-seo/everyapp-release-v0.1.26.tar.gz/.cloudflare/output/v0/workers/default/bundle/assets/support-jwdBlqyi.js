//#region src/client/lib/support.ts
var SUPPORT_EMAIL = "support@openseo.so";
//#endregion
export { SUPPORT_EMAIL as t };
