//#region src/shared/crawler-access.ts
/**
* Shopify crawler access.
*
* Shopify storefronts rate-limit (429) and sometimes block crawlers they
* haven't authorized. The merchant mints a domain-scoped signature in Shopify
* admin (Online Store -> Preferences -> Crawler access) and the crawler
* replays it as three static headers on every request to that domain.
*
* These helpers are pure so both the crawler and the input validation can use
* them.
*/
/** Constant Shopify expects, quotes included. We supply it; users never see it. */
var SHOPIFY_SIGNATURE_AGENT = "\"https://shopify.com\"";
var SHOPIFY_CRAWLER_ACCESS_DOC_URL = "https://help.shopify.com/en/manual/promoting-marketing/seo/crawling-your-store";
var MAX_SIGNATURE_VALUE_LENGTH = 4096;
function shopifyCrawlerHeaders(signatureInput, signature) {
	return {
		"Signature-Input": signatureInput,
		Signature: signature,
		"Signature-Agent": SHOPIFY_SIGNATURE_AGENT
	};
}
/**
* Normalize user input into a bare lowercase hostname. Accepts a full URL
* (people paste one) as well as a bare host. Null = not a usable hostname.
*/
function normalizeCrawlerHost(input) {
	const raw = input.trim().toLowerCase();
	if (!raw) return null;
	let url;
	try {
		url = new URL(raw.includes("://") ? raw : `https://${raw}`);
	} catch {
		return null;
	}
	if (url.protocol !== "https:" && url.protocol !== "http:") return null;
	const host = url.hostname.replace(/\.$/, "");
	if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(host)) return null;
	return host;
}
/**
* Shopify's `Signature-Input` is an RFC 9421 signature parameter list that may
* carry `;expires=<unix seconds>`. Nothing beyond that parameter is assumed.
*/
function parseSignatureExpiry(signatureInput) {
	const match = signatureInput.match(/expires=(\d+)/);
	if (!match) return null;
	const expiresAt = /* @__PURE__ */ new Date(Number(match[1]) * 1e3);
	return Number.isNaN(expiresAt.getTime()) ? null : expiresAt.toISOString();
}
/** Shopify rejects a signature past its `expires`, so it is never replayed. */
function isCrawlerAccessExpired(expiresAt, now = Date.now()) {
	return expiresAt !== null && new Date(expiresAt).getTime() <= now;
}
//#endregion
export { normalizeCrawlerHost as a, isCrawlerAccessExpired as i, SHOPIFY_CRAWLER_ACCESS_DOC_URL as n, parseSignatureExpiry as o, SHOPIFY_SIGNATURE_AGENT as r, shopifyCrawlerHeaders as s, MAX_SIGNATURE_VALUE_LENGTH as t };
