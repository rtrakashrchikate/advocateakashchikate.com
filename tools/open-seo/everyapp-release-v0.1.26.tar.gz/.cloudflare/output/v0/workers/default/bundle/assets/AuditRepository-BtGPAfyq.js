import { G as eq, U as desc, W as and, dt as getDatabaseProvider, t as db } from "./db-DhHkpZWI.js";
import { t as count } from "./aggregate-CkzWoiih.js";
import { R as projects, d as auditLighthouseResults, f as auditPages, p as audits, u as auditIssues } from "./schema-Cn_vcAkd.js";
import { n as runBatch, t as executeInBatches } from "./runBatch-CENJH-Sm.js";
import { t } from "./chunk-CYiqfj-i.js";
import { t as deterministicAuditRowId } from "./ids-BhLslNFj.js";
import { t as AUDIT_ISSUE_TYPES } from "./audit-issues-CVAgBn_i.js";
//#region src/server/features/audit/repositories/auditIssueWrites.ts
async function insertIssues(auditId, issues) {
	const isPostgres = getDatabaseProvider() === "postgres";
	const batchSize = isPostgres ? 500 : 100;
	for (let i = 0; i < issues.length; i += batchSize) {
		const issueRows = await Promise.all(issues.slice(i, i + batchSize).map(async (issue) => ({
			id: await deterministicAuditRowId(auditId, issue.pageUrl, issue.issueType, issue.dedupeKey ?? ""),
			auditId,
			pageId: issue.pageId,
			pageUrl: issue.pageUrl,
			issueType: issue.issueType,
			severity: AUDIT_ISSUE_TYPES[issue.issueType].severity,
			detailsJson: issue.details ? JSON.stringify(issue.details) : null
		})));
		if (isPostgres) await db.insert(auditIssues).values(issueRows).onConflictDoNothing();
		else await runBatch((tx) => t(issueRows, 14).map((rows) => tx.insert(auditIssues).values(rows).onConflictDoNothing()));
	}
}
//#endregion
//#region src/server/features/audit/repositories/AuditRepository.ts
/**
* Data access layer for site audit tables.
* Provider-aware (D1 or Postgres) via the `@/db` handle. Covers audits,
* audit_pages, audit_issues, and stored Lighthouse results. Link edges live
* in the per-audit scratchpad Durable Object, not here.
*/
async function createAudit(data) {
	await db.insert(audits).values({
		id: data.id,
		projectId: data.projectId,
		startedByUserId: data.startedByUserId,
		startUrl: data.startUrl,
		workflowInstanceId: data.workflowInstanceId,
		config: JSON.stringify(data.config),
		status: "running",
		pagesTotal: data.pagesTotal,
		lighthouseTotal: data.lighthouseTotal,
		currentPhase: "discovery"
	});
}
/** Records where the crawl really starts, once the workflow has probed the site. */
async function updateAuditStart(auditId, startUrl, config) {
	await db.update(audits).set({
		startUrl,
		config: JSON.stringify(config)
	}).where(eq(audits.id, auditId));
}
async function updateAuditProgress(auditId, workflowInstanceId, data) {
	await db.update(audits).set(data).where(and(eq(audits.id, auditId), eq(audits.workflowInstanceId, workflowInstanceId)));
}
async function completeAudit(auditId, workflowInstanceId, data) {
	await db.update(audits).set({
		status: "completed",
		completedAt: (/* @__PURE__ */ new Date()).toISOString(),
		currentPhase: "completed",
		...data
	}).where(and(eq(audits.id, auditId), eq(audits.workflowInstanceId, workflowInstanceId), eq(audits.status, "running")));
}
async function failAudit(auditId, workflowInstanceId, errorInfo) {
	await db.update(audits).set({
		status: "failed",
		completedAt: (/* @__PURE__ */ new Date()).toISOString(),
		currentPhase: "failed",
		...errorInfo && {
			errorCode: errorInfo.errorCode,
			errorDetail: errorInfo.errorDetail,
			failedPhase: errorInfo.failedPhase
		}
	}).where(and(eq(audits.id, auditId), eq(audits.workflowInstanceId, workflowInstanceId), eq(audits.status, "running")));
}
async function getAuditForWorkflow(auditId, workflowInstanceId) {
	return db.query.audits.findFirst({ where: and(eq(audits.id, auditId), eq(audits.workflowInstanceId, workflowInstanceId)) });
}
/**
* Persist one crawled sub-batch (pages + per-page issues). Called inside the
* crawl-chunk Workflow step so results land in the app DB incrementally
* instead of accumulating in memory until finalize. Link edges go to the
* audit's scratchpad DO, not here.
*
* Idempotent on step retry: callers assign deterministic page ids
* (deterministicAuditRowId) and issue ids are derived from stable content.
* Page rows upsert (a retried fetch may legitimately differ \u2014 last attempt
* wins); issues are insert-or-ignore.
*/
async function insertCrawledBatch(auditId, pages, issues) {
	await executeInBatches(pages, (tx, page) => {
		const dataColumns = {
			url: page.url,
			statusCode: page.statusCode,
			redirectUrl: page.redirectUrl,
			title: page.title,
			metaDescription: page.metaDescription,
			canonicalUrl: page.canonicalUrl,
			robotsMeta: page.robotsMeta,
			xRobotsTag: page.xRobotsTag,
			headerCanonicalUrl: page.headerCanonicalUrl,
			ogTitle: page.ogTitle,
			ogDescription: page.ogDescription,
			ogImage: page.ogImage,
			h1Count: page.h1Count,
			h2Count: page.h2Count,
			h3Count: page.h3Count,
			h4Count: page.h4Count,
			h5Count: page.h5Count,
			h6Count: page.h6Count,
			wordCount: page.wordCount,
			contentHash: page.contentHash,
			imagesTotal: page.imagesTotal,
			imagesMissingAlt: page.imagesMissingAlt,
			internalLinkCount: page.links.filter((l) => l.isInternal).length,
			externalLinkCount: page.links.filter((l) => !l.isInternal).length,
			hasStructuredData: page.hasStructuredData,
			isIndexable: page.isIndexable,
			fetchClass: page.fetchClass,
			crawlDepth: page.crawlDepth,
			inSitemap: page.inSitemap,
			responseTimeMs: page.responseTimeMs
		};
		return tx.insert(auditPages).values({
			id: page.id,
			auditId,
			...dataColumns
		}).onConflictDoUpdate({
			target: auditPages.id,
			set: dataColumns
		});
	});
	await insertIssues(auditId, issues);
}
async function insertLighthouseResults(auditId, lighthouseResults) {
	const rows = await Promise.all(lighthouseResults.map(async (result) => ({
		id: await deterministicAuditRowId(auditId, result.pageId, result.strategy),
		auditId,
		pageId: result.pageId,
		strategy: result.strategy,
		performanceScore: result.performanceScore,
		accessibilityScore: result.accessibilityScore,
		bestPracticesScore: result.bestPracticesScore,
		seoScore: result.seoScore,
		lcpMs: result.lcpMs,
		cls: result.cls,
		inpMs: result.inpMs,
		ttfbMs: result.ttfbMs,
		errorMessage: result.errorMessage ?? null,
		r2Key: result.r2Key ?? null,
		payloadSizeBytes: result.payloadSizeBytes ?? null
	})));
	await executeInBatches(rows, (tx, row) => {
		const { id: _id, auditId: _auditId, ...dataColumns } = row;
		return tx.insert(auditLighthouseResults).values(row).onConflictDoUpdate({
			target: auditLighthouseResults.id,
			set: dataColumns
		});
	});
}
async function getAuditForProject(auditId, projectId) {
	return db.query.audits.findFirst({ where: and(eq(audits.id, auditId), eq(audits.projectId, projectId)) });
}
async function getLatestAuditForProject(projectId) {
	return db.query.audits.findFirst({
		where: eq(audits.projectId, projectId),
		orderBy: desc(audits.startedAt)
	});
}
async function getPagesForAudit(auditId) {
	return db.select({
		id: auditPages.id,
		url: auditPages.url,
		statusCode: auditPages.statusCode,
		fetchClass: auditPages.fetchClass,
		redirectUrl: auditPages.redirectUrl,
		title: auditPages.title,
		metaDescription: auditPages.metaDescription,
		wordCount: auditPages.wordCount,
		isIndexable: auditPages.isIndexable,
		crawlDepth: auditPages.crawlDepth,
		inSitemap: auditPages.inSitemap,
		internalLinkCount: auditPages.internalLinkCount,
		responseTimeMs: auditPages.responseTimeMs
	}).from(auditPages).where(eq(auditPages.auditId, auditId));
}
async function countPagesByFetchClass(auditId, fetchClass) {
	return (await db.select({ pages: count() }).from(auditPages).where(and(eq(auditPages.auditId, auditId), eq(auditPages.fetchClass, fetchClass))))[0]?.pages ?? 0;
}
async function hasPagesForAudit(auditId) {
	return (await db.select({ id: auditPages.id }).from(auditPages).where(eq(auditPages.auditId, auditId)).limit(1)).length > 0;
}
async function getAuditsByProject(projectId) {
	return (await db.select({ audit: audits }).from(audits).where(eq(audits.projectId, projectId)).orderBy(desc(audits.startedAt))).map(({ audit }) => audit);
}
async function getAuditUsageForOrganization(organizationId) {
	const rows = await db.select({
		status: audits.status,
		pagesTotal: audits.pagesTotal,
		lighthouseTotal: audits.lighthouseTotal
	}).from(audits).innerJoin(projects, eq(audits.projectId, projects.id)).where(eq(projects.organizationId, organizationId));
	return {
		capacityUnits: rows.reduce((total, row) => total + row.pagesTotal + row.lighthouseTotal, 0),
		runningCount: rows.filter((row) => row.status === "running").length
	};
}
async function hasAuditInOrganization(organizationId) {
	return (await db.select({ id: audits.id }).from(audits).innerJoin(projects, eq(audits.projectId, projects.id)).where(eq(projects.organizationId, organizationId)).limit(1)).length > 0;
}
async function getLighthouseResultById(input) {
	const lighthouse = await db.query.auditLighthouseResults.findFirst({ where: eq(auditLighthouseResults.id, input.lighthouseResultId) });
	if (!lighthouse) return null;
	const [parentAudit, page] = await Promise.all([db.query.audits.findFirst({ where: and(eq(audits.id, lighthouse.auditId), eq(audits.projectId, input.projectId)) }), db.query.auditPages.findFirst({ where: eq(auditPages.id, lighthouse.pageId) })]);
	if (!parentAudit) return null;
	return {
		lighthouse,
		page,
		audit: parentAudit
	};
}
async function deleteAuditForProject(auditId, projectId) {
	await db.delete(audits).where(and(eq(audits.id, auditId), eq(audits.projectId, projectId)));
}
var AuditRepository = {
	createAudit,
	updateAuditStart,
	updateAuditProgress,
	completeAudit,
	failAudit,
	getAuditForWorkflow,
	insertCrawledBatch,
	insertIssues,
	insertLighthouseResults,
	getAuditForProject,
	getLatestAuditForProject,
	getPagesForAudit,
	countPagesByFetchClass,
	hasPagesForAudit,
	getAuditsByProject,
	getAuditUsageForOrganization,
	hasAuditInOrganization,
	getLighthouseResultById,
	deleteAuditForProject
};
//#endregion
export { AuditRepository as t };
