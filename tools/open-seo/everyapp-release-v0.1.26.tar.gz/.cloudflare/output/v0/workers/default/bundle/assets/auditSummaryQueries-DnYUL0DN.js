import { G as eq, J as gte, W as and, et as lt, t as db } from "./db-DhHkpZWI.js";
import { n as countDistinct } from "./aggregate-CkzWoiih.js";
import { Z as user, p as audits, u as auditIssues } from "./schema-Cn_vcAkd.js";
//#region src/server/features/audit/repositories/auditSummaryQueries.ts
/**
* Distinct-page counts per issue type for one audit \u2014 link-level issues
* write one row per occurrence, and consumers phrase this as "N pages".
* Lives beside AuditRepository (same pattern as rank-tracking's
* snapshotQueries) to keep the main repository under the file-size limit.
*/
async function getIssueTypePageCountsForAudit(auditId) {
	return db.select({
		issueType: auditIssues.issueType,
		severity: auditIssues.severity,
		pages: countDistinct(auditIssues.pageUrl)
	}).from(auditIssues).where(eq(auditIssues.auditId, auditId)).groupBy(auditIssues.issueType, auditIssues.severity);
}
async function getAuditsCompletedSince(since) {
	return db.select({
		id: audits.id,
		projectId: audits.projectId,
		startUrl: audits.startUrl,
		pagesCrawled: audits.pagesCrawled,
		completedAt: audits.completedAt,
		userId: user.id,
		email: user.email
	}).from(audits).innerJoin(user, eq(user.id, audits.startedByUserId)).where(and(eq(audits.status, "completed"), gte(audits.completedAt, since)));
}
async function hasCompletedAuditBefore(userId, before) {
	return (await db.select({ id: audits.id }).from(audits).where(and(eq(audits.startedByUserId, userId), eq(audits.status, "completed"), lt(audits.completedAt, before))).limit(1)).length > 0;
}
//#endregion
export { getIssueTypePageCountsForAudit as n, hasCompletedAuditBefore as r, getAuditsCompletedSince as t };
