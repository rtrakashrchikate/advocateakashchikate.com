import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useQuery } from "./useQuery-B93OR2NQ.js";
import { n as BackLink, r as PageHeader } from "./PageHeader-a3_4WaC8.js";
import { t as projectsQueryOptions } from "./projectQueries-CUURHKzv.js";
//#region src/client/features/projects/ProjectPageHeader.tsx
var import_jsx_runtime = require_jsx_runtime();
function ProjectPageHeader({ projectId, title, showBackLink = false }) {
	const project = useQuery(projectsQueryOptions()).data?.find((entry) => entry.id === projectId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		title,
		description: project?.name ?? " ",
		backLink: showBackLink ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackLink, {
			to: "/projects",
			children: "Projects"
		}) : void 0
	});
}
//#endregion
export { ProjectPageHeader as t };
