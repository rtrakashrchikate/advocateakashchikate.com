import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { f as usesBetterAuthClient, r as getClientAuthMode } from "./auth-mode-DhGCw2Bx.js";
import { a as getSignInHref, o as getSignInHrefForLocation } from "./auth-redirect-Dnh6pyWf.js";
import { n as getErrorCode, r as getStandardErrorMessage } from "./error-messages-D7nntGF_.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as ShieldAlert } from "./shield-alert-C6TCVoOy.js";
import { r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { a as CardFooter, o as CardHeader, r as CardContent, s as CardTitle, t as Card } from "./card-CqQO-5bL.js";
//#region src/client/components/AuthErrorCard.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
var CLOUDFLARE_SETUP_GUIDE_URL = "https://github.com/every-app/open-seo/blob/main/docs/SELF_HOSTING_CLOUDFLARE.md#2-configure-authentication-and-secrets";
/**
* The card for an auth failure, else `fallback`. The route error boundary and
* the landing redirect both render errors through this, so each auth error
* code shows the same card everywhere.
*/
function AuthErrorCard({ error, onRetry, fallback }) {
	const errorCode = getErrorCode(error);
	if (errorCode !== "AUTH_CONFIG_MISSING" && errorCode !== "UNAUTHENTICATED") return fallback;
	const message = getStandardErrorMessage(error, "Something went wrong. Please try again.");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-full min-w-0 flex-1 items-center justify-center p-4",
		children: errorCode === "AUTH_CONFIG_MISSING" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthConfigErrorCard, {
			message,
			onRetry
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UnauthenticatedErrorCard, {
			message,
			onRetry
		})
	});
}
function AuthConfigErrorCard({ message, onRetry }) {
	const clientAuthMode = getClientAuthMode();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "w-full max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, { className: "size-5 text-destructive" }), "Authentication setup required"]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Alert, {
						variant: "destructive",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: message })
					}),
					clientAuthMode === "hosted" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: [
							"Hosted mode requires",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "mx-1",
								children: "BETTER_AUTH_SECRET"
							}),
							"(32+ characters), ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "mx-1",
								children: "BETTER_AUTH_URL"
							}),
							", and Google OAuth credentials on the deployment."
						]
					}) : null,
					clientAuthMode === "everyapp" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: [
							"OpenSEO runs behind an Every App gateway, which signs people in. Install it with ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "mx-1",
								children: "pnpm everyapp install"
							}),
							" ",
							"so it gets the gateway's identity keys, and open it through the gateway."
						]
					}) : null,
					clientAuthMode === "cloudflare_access" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: [
							"Cloudflare Access mode requires",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "mx-1",
								children: "TEAM_DOMAIN"
							}),
							" (a full https URL) and",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "mx-1",
								children: "POLICY_AUD"
							}),
							" set on the deployment, with an Access application protecting this hostname."
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardFooter, {
				className: "justify-end gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: onRetry,
					children: "Try Again"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					nativeButton: false,
					render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: CLOUDFLARE_SETUP_GUIDE_URL,
						target: "_blank",
						rel: "noreferrer"
					}),
					children: "Open Setup Guide"
				})]
			})
		]
	});
}
function UnauthenticatedErrorCard({ message, onRetry }) {
	const hasSignIn = usesBetterAuthClient();
	const signInHref = typeof window === "undefined" ? getSignInHref("/") : getSignInHrefForLocation(window.location);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined" || !hasSignIn) return;
		window.location.replace(signInHref);
	}, [hasSignIn, signInHref]);
	if (hasSignIn) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
		className: "w-full max-w-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Authentication required" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "space-y-4 text-muted-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: message }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This deployment uses external authentication. Refresh your access session, then try again." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardFooter, {
				className: "justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: onRetry,
					children: "Try Again"
				})
			})
		]
	});
}
//#endregion
export { AuthErrorCard as t };
