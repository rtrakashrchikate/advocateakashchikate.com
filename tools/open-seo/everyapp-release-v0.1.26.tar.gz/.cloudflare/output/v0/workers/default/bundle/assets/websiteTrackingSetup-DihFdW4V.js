import { U as AppError } from "./onboarding-drip-B7bIbv_6.js";
import { t as DEFAULT_LOCATION_CODE } from "./keyword-locations-4GfvBtRY.js";
import { l as aiEnginesWithoutLocation } from "./ai-visibility-b7Nyzqt-.js";
import { t as normalizeAiSuggestion } from "./ai-prompt-suggestions-BlfcqfCk.js";
import { t as AiVisibilityRepository } from "./AiVisibilityRepository-BleS-LTq.js";
import { a as projectAiConfiguration } from "./aiVisibilityConfiguration-CFZNZFh5.js";
import { a as startRun } from "./aiVisibilityRuns-B45HeWFQ.js";
//#region src/server/features/ai-visibility/services/websiteTrackingSetup.ts
/** Seeds weekly tracking from website setup's first three suggested topics. */
async function prepareWebsiteTracking(input, market) {
	if (!input.suggestedTopics?.length || await AiVisibilityRepository.getConfiguration(input.projectId)) return null;
	const names = /* @__PURE__ */ new Set();
	const texts = /* @__PURE__ */ new Set();
	const prompts = input.suggestedTopics.slice(0, 3).flatMap((topic) => {
		const name = normalizeAiSuggestion(topic.name);
		if (names.has(name)) throw new AppError("VALIDATION_ERROR", "Generated topics must be unique.");
		names.add(name);
		return topic.prompts.map((text) => {
			const normalized = normalizeAiSuggestion(text);
			if (texts.has(normalized)) throw new AppError("VALIDATION_ERROR", "Generated prompts must be unique.");
			texts.add(normalized);
			return {
				text,
				topic: topic.name
			};
		});
	});
	return projectAiConfiguration({
		previous: null,
		projectId: input.projectId,
		projectMarket: aiEnginesWithoutLocation(["chatgpt"], market.locationCode).length ? {
			locationCode: DEFAULT_LOCATION_CODE,
			languageCode: "en"
		} : market,
		patch: {
			engines: ["chatgpt"],
			prompts
		},
		now: (/* @__PURE__ */ new Date()).toISOString()
	}).rows;
}
/**
* In-app onboarding collects the seeded prompts once, so Prompt Tracking
* opens on a run in progress rather than an empty tracker. The run is the
* tracker's baseline; collection checks credits before paid work. Setup is
* already saved, so a run that cannot start leaves the prompts ready to run.
*/
async function startWebsiteTrackingRun(projectId, billing) {
	const config = await AiVisibilityRepository.getConfiguration(projectId);
	if (!config) return;
	try {
		await startRun(config, "baseline", billing);
	} catch (error) {
		console.warn(`[ai-visibility] ${projectId} onboarding run:`, error);
	}
}
//#endregion
export { startWebsiteTrackingRun as n, prepareWebsiteTracking as t };
