import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { Et as _enum, Fn as object } from "./schemas-BPIpYT5n.js";
import { m as queryClient } from "./QueryState-Q8BZIblk.js";
import { f as aiRunResultsQueryOptions, m as aiTrendQueryOptions, p as aiTrackerQueryOptions } from "./shared-BW7GMYqD.js";
import { i as TabsTrigger } from "./tabs-Dm1Fimx3.js";
import { a as DataTableTabs } from "./DataTableToolbar-H0nNW-WC.js";
//#region src/client/features/ai-visibility/PromptTrackingTabs.tsx
var import_jsx_runtime = require_jsx_runtime();
var PROMPT_TRACKING_TABS = [
	{
		value: "prompts",
		label: "Prompts"
	},
	{
		value: "competitors",
		label: "Competitors"
	},
	{
		value: "citations",
		label: "Citations"
	}
];
/** The tab row above the tracking card's table, kept in the URL. */
function PromptTrackingTabs({ projectId, tab }) {
	const navigate = useNavigate();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "border-t border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableTabs, {
			value: tab,
			onValueChange: (value) => {
				const next = PROMPT_TRACKING_TABS.find((item) => item.value === value);
				if (next) navigate({
					to: "/p/$projectId/ai-visibility",
					params: { projectId },
					replace: true,
					search: { tab: next.value === "prompts" ? void 0 : next.value }
				});
			},
			children: PROMPT_TRACKING_TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
				value: item.value,
				children: item.label
			}, item.value))
		})
	});
}
//#endregion
//#region src/routes/_app/p/$projectId/ai-visibility/index.tsx
var $$splitComponentImporter = () => import("./ai-visibility-Ci32_hRu.js");
var tabs = PROMPT_TRACKING_TABS.map((item) => item.value);
var Route = createFileRoute("/_app/p/$projectId/ai-visibility/")({
	validateSearch: object({ tab: _enum(tabs).optional().catch(void 0) }),
	loader: ({ params: { projectId } }) => {
		queryClient.prefetchQuery(aiTrendQueryOptions(projectId, 28));
		queryClient.fetchQuery({
			...aiTrackerQueryOptions(projectId),
			staleTime: 0
		}).then((state) => {
			const runId = state.recentRuns[0]?.id;
			if (runId) return queryClient.prefetchQuery(aiRunResultsQueryOptions(projectId, runId));
		}).catch(() => void 0);
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { PromptTrackingTabs as n, Route as t };
