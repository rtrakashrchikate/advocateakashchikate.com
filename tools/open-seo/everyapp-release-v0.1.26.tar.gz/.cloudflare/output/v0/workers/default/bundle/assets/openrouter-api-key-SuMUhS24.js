import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { n as SecretHelpPage, r as helpLinkClassName, t as CommandBlock } from "./SecretHelpPage-DdRnF3DU.js";
//#region src/routes/_app/help/openrouter-api-key.tsx?tsr-split=component
var import_jsx_runtime = require_jsx_runtime();
var OPENROUTER_KEYS_URL = "https://openrouter.ai/settings/keys";
function OpenrouterApiKeyHelpPage() {
	const accountStep = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
		"Create an account at",
		" ",
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: helpLinkClassName,
			href: "https://openrouter.ai",
			target: "_blank",
			rel: "noreferrer",
			children: "openrouter.ai"
		}),
		" ",
		"and add credits (pay-as-you-go, like DataForSEO)."
	] });
	const keyStep = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
		"Go to",
		" ",
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			className: helpLinkClassName,
			href: OPENROUTER_KEYS_URL,
			target: "_blank",
			rel: "noreferrer",
			children: "OpenRouter API Keys"
		}),
		" ",
		"and click \"Create API Key\"."
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SecretHelpPage, {
		title: "Set up your OpenRouter API key",
		intro: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			"OpenSEO needs the ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "OPENROUTER_API_KEY" }),
			" secret before AI features like SAM, the in-app SEO agent, can run. It is optional \u2014 everything else in OpenSEO works without it."
		] }),
		everyAppIntro: "SAM, prompt suggestions and website research run on OpenRouter. On Every App the gateway holds the key once, for every app.",
		secretName: "OPENROUTER_API_KEY",
		steps: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			accountStep,
			keyStep,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
				"Save the key as the ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "OPENROUTER_API_KEY" }),
				" secret in your environment:",
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-2 list-disc space-y-1 pl-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Docker self-hosting: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: ".env" })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Cloudflare: set it in the Workers UI (see below)" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["Local development: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: ".env.local" })] })
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Restart OpenSEO." })
		] }),
		everyAppSteps: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			accountStep,
			keyStep,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["An owner or admin runs this from the Every App checkout and pastes the key:", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CommandBlock, { command: "pnpm everyapp secret set OPENROUTER_API_KEY" })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Reload OpenSEO." })
		] }),
		dashboardPasteStep: "Paste your OpenRouter API key and save.",
		terminalPromptHint: "Paste your OpenRouter API key when prompted."
	});
}
//#endregion
export { OpenrouterApiKeyHelpPage as component };
