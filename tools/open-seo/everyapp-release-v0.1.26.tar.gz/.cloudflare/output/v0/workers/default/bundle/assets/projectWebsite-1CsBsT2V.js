import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { n as getRequest } from "./server-DEvo1k0f.js";
import { C as MetaSetupEvent, E as captureMetaSetupStep } from "./resolve-DrNDcpX6.js";
import { n as researchProjectWebsiteSchema, r as saveProjectWebsiteSetupSchema } from "./projectWebsite-Co6Tcq0K.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { t as ProjectWebsiteService } from "./ProjectWebsiteService-CKvSJJf2.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/serverFunctions/projectWebsite.ts?tss-serverfn-split
var researchProjectWebsite_createServerFn_handler = createServerRpc({
	id: "c0d5e5c1596b1dc41fa32ed6200a9dbbe633ef4199e220331621e3971f30acac",
	name: "researchProjectWebsite",
	filename: "src/serverFunctions/projectWebsite.ts"
}, (opts) => researchProjectWebsite.__executeServer(opts));
var researchProjectWebsite = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(researchProjectWebsiteSchema).handler(researchProjectWebsite_createServerFn_handler, ({ data, context }) => ProjectWebsiteService.research(context.projectId, data.website, context));
var saveProjectWebsiteSetup_createServerFn_handler = createServerRpc({
	id: "fa7c2597b8b61de5f30f270445da8576902f377aea987bee964b0ae3ac137791",
	name: "saveProjectWebsiteSetup",
	filename: "src/serverFunctions/projectWebsite.ts"
}, (opts) => saveProjectWebsiteSetup.__executeServer(opts));
var saveProjectWebsiteSetup = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(saveProjectWebsiteSetupSchema).handler(saveProjectWebsiteSetup_createServerFn_handler, async ({ data, context }) => {
	const { project } = await ProjectWebsiteService.save({
		...data,
		projectId: context.projectId
	}, context, "user", { runSeededTracking: true });
	if (!context.project.domain) await captureMetaSetupStep(MetaSetupEvent.WebsiteAdded, context.organizationId, getRequest());
	return project;
});
//#endregion
export { researchProjectWebsite_createServerFn_handler, saveProjectWebsiteSetup_createServerFn_handler };
