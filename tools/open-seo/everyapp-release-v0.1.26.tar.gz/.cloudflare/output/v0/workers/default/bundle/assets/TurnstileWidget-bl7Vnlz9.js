import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
//#region src/client/features/auth/TurnstileWidget.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
require_jsx_runtime();
function useTurnstileCaptcha() {
	const tokenRef = (0, import_react.useRef)(null);
	const [hasToken, setHasToken] = (0, import_react.useState)(false);
	const [resetNonce, setResetNonce] = (0, import_react.useState)(0);
	return {
		tokenRef,
		hasToken,
		resetNonce,
		onToken: (0, import_react.useCallback)((token) => {
			tokenRef.current = token;
			setHasToken(Boolean(token));
		}, []),
		reset: (0, import_react.useCallback)(() => {
			tokenRef.current = null;
			setHasToken(false);
			setResetNonce((nonce) => nonce + 1);
		}, [])
	};
}
function TurnstileWidget({ onToken, resetNonce }) {
	(0, import_react.useRef)(null);
	const widgetIdRef = (0, import_react.useRef)(null);
	const onTokenRef = (0, import_react.useRef)(onToken);
	onTokenRef.current = onToken;
	const [scriptFailed, setScriptFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {}, []);
	(0, import_react.useEffect)(() => {
		if (resetNonce === 0) return;
		if (widgetIdRef.current !== null && window.turnstile) {
			window.turnstile.reset(widgetIdRef.current);
			onTokenRef.current(null);
		}
	}, [resetNonce]);
	return null;
}
//#endregion
export { useTurnstileCaptcha as n, TurnstileWidget as t };
