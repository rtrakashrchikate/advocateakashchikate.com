import { Et as _enum, Fn as object, Jn as string, Lt as boolean, Nt as array, Pn as number, Yt as discriminatedUnion, or as union, xn as literal } from "./schemas-BPIpYT5n.js";
import { p as researchScopeSchema } from "./researchScope-DHudUdg3.js";
import { t as WEB_SEARCH_COUNTRY_CODES } from "./prompt-search-countries-DwmF4BXn.js";
/** Maximum number of competitors compared in one Share-of-Voice lookup. */
var BRAND_LOOKUP_MAX_COMPETITORS = 5;
/**
* Canonicalize raw comma-separated competitor text: split, trim, drop empties,
* dedupe, cap. Shared by the `c` URL-param transform and the page form so the
* two never diverge.
*/
function parseCompetitorList(raw) {
	return Array.from(new Set(raw.split(",").map((part) => part.trim()).filter((part) => part.length > 0))).slice(0, BRAND_LOOKUP_MAX_COMPETITORS);
}
var brandLookupInputSchema = object({
	projectId: string().min(1),
	query: string().trim().min(1).max(250),
	competitors: array(string().trim().min(1).max(250)).max(BRAND_LOOKUP_MAX_COMPETITORS).default([]),
	scope: researchScopeSchema.optional()
});
var brandPlatformBreakdownSchema = object({
	platform: _enum(["chat_gpt", "google"]),
	status: _enum(["success", "error"]),
	mentions: number().int().nonnegative().nullable(),
	aiSearchVolume: number().int().nonnegative().nullable()
});
var brandShareOfVoiceSchema = object({
	platforms: array(_enum(["chat_gpt", "google"])),
	entries: array(object({
		label: string().max(250),
		isTarget: boolean(),
		mentions: number().int().nonnegative().nullable(),
		sharePct: number().nullable()
	}))
});
var brandTopPageKeywordSchema = object({
	question: string().max(500),
	aiSearchVolume: number().int().nonnegative().nullable()
});
var brandTopPageSchema = object({
	url: string().max(2048),
	domain: string().max(253).nullable(),
	platform: _enum(["chat_gpt", "google"]),
	mentions: number().int().nonnegative().nullable(),
	capturedVolume: number().int().nonnegative().nullable(),
	keywords: array(brandTopPageKeywordSchema).max(50)
});
var brandTopQuerySchema = object({
	question: string().max(500),
	platform: _enum(["chat_gpt", "google"]),
	aiSearchVolume: number().int().nonnegative().nullable(),
	firstSeenAt: string().nullable(),
	lastSeenAt: string().nullable(),
	citedSources: array(object({
		url: string().max(2048),
		domain: string().max(253).nullable(),
		title: string().max(300).nullable()
	})).max(10),
	brandsMentioned: array(string().max(200)).max(20)
});
var brandMonthlyVolumeSchema = object({
	year: number().int(),
	month: number().int().min(1).max(12),
	volume: number().int().nonnegative().nullable()
});
var brandLookupResultSchema = object({
	query: string(),
	detectedTargetType: _enum(["domain", "keyword"]),
	/** Hostname for domain scopes, hostname + path for URL scopes. */
	resolvedTarget: string(),
	scope: researchScopeSchema.nullable().default(null),
	/**
	* True under exact_url/subfolder scope: the LLM mentions API has no
	* URL-level targeting, so totals, per-platform counts, monthly volume and
	* Share of Voice stay domain-wide and the UI must say so. Page-level rows
	* are filtered to the scope.
	*/
	aggregatesAreDomainLevel: boolean().default(false),
	fetchedAt: string(),
	hasData: boolean(),
	totalMentions: number().int().nonnegative().nullable(),
	totalAiSearchVolume: number().int().nonnegative().nullable(),
	perPlatform: array(brandPlatformBreakdownSchema),
	shareOfVoice: brandShareOfVoiceSchema.nullable(),
	topPages: array(brandTopPageSchema).max(40),
	topQueries: array(brandTopQuerySchema).max(50),
	monthlyVolume: array(brandMonthlyVolumeSchema)
});
/** Stable identifiers for the four LLM models we expose. */
var PROMPT_EXPLORER_MODELS = [
	"chat_gpt",
	"claude",
	"gemini",
	"perplexity"
];
var promptExplorerModelSchema = _enum(PROMPT_EXPLORER_MODELS);
var webSearchCountryCodeSchema = _enum(WEB_SEARCH_COUNTRY_CODES);
var webSearchCountrySelectionSchema = union([webSearchCountryCodeSchema, literal("default")]);
var promptExplorerInputSchema = object({
	projectId: string().min(1),
	prompt: string().trim().min(1).max(500),
	models: array(promptExplorerModelSchema).min(1).max(4).default(["chat_gpt"]),
	highlightBrand: string().trim().min(1).max(250).optional(),
	webSearch: boolean().default(true),
	webSearchCountryCode: webSearchCountryCodeSchema.optional()
});
var promptExplorerCitationSchema = object({
	url: string(),
	domain: string().nullable(),
	title: string().nullable(),
	matchedBrand: boolean()
});
var promptExplorerModelResultSchema = discriminatedUnion("status", [object({
	status: literal("success"),
	model: promptExplorerModelSchema,
	modelName: string().nullable(),
	text: string(),
	citations: array(promptExplorerCitationSchema),
	fanOutQueries: array(string()),
	brandMentioned: boolean().nullable(),
	outputTokens: number().int().nonnegative().nullable(),
	webSearch: boolean(),
	webSearchCountryCode: webSearchCountryCodeSchema.nullable()
}), object({
	status: literal("error"),
	model: promptExplorerModelSchema,
	errorCode: _enum(["UPSTREAM_ERROR", "UNSUPPORTED_COUNTRY"]),
	message: string()
})]);
var promptExplorerResultSchema = object({
	prompt: string(),
	highlightBrand: string().nullable(),
	fetchedAt: string(),
	results: array(promptExplorerModelResultSchema)
});
/**
* /p/$projectId/brand-lookup query params. `q` keeps the lookup shareable; `c`
* is a comma-joined competitor list (route + page treat the parsed result as an
* opaque string array). `c` accepts a raw string (from the URL) OR an array
* (TanStack Router re-validates its own transformed output on navigate) \u2014 same
* union pattern as `models` below. `scope` is only present when it differs
* from the scope derived from `q`.
*/
var brandLookupSearchSchema = object({
	q: string().optional(),
	scope: researchScopeSchema.optional().catch(void 0),
	c: union([string(), array(string())]).optional().transform((value) => value === void 0 ? void 0 : parseCompetitorList(Array.isArray(value) ? value.join(",") : value))
});
/**
* /p/$projectId/prompt-explorer query params. The full prompt config is
* encoded in the URL so a search is shareable and cmd+click on a history
* item opens the same answer in a new tab.
*/
var promptExplorerSearchSchema = object({
	q: string().optional(),
	models: union([promptExplorerModelSchema, array(promptExplorerModelSchema)]).optional().transform((value) => value === void 0 ? void 0 : Array.isArray(value) ? value : [value]).catch(void 0),
	web: union([boolean(), _enum(["true", "false"])]).optional().transform((value) => value === void 0 ? void 0 : value === true || value === "true").catch(void 0),
	cc: webSearchCountrySelectionSchema.optional().catch("default"),
	hb: string().optional()
});
//#endregion
export { parseCompetitorList as a, promptExplorerModelSchema as c, webSearchCountrySelectionSchema as d, brandLookupSearchSchema as i, promptExplorerResultSchema as l, brandLookupInputSchema as n, promptExplorerInputSchema as o, brandLookupResultSchema as r, promptExplorerModelResultSchema as s, PROMPT_EXPLORER_MODELS as t, promptExplorerSearchSchema as u };
