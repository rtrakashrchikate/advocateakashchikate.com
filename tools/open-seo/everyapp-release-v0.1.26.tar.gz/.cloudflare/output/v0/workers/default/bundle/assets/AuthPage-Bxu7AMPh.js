import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
import { c as isHostedClientAuthMode, f as usesBetterAuthClient } from "./auth-mode-DhGCw2Bx.js";
import { h as TERMS_URL, i as getOAuthSignedQuery, m as PRIVACY_URL, n as getCurrentAuthRedirect } from "./auth-redirect-Dnh6pyWf.js";
import { t as Button } from "./button-DrcZrdio.js";
//#region src/client/features/auth/AuthPage.tsx
var import_jsx_runtime = require_jsx_runtime();
var authRedirectSearchSchema = object({ redirect: string().optional() });
var authInputClassName = "border-foreground/20 bg-card text-base md:text-base";
var authSubmitClassName = "w-full border-border bg-[color-mix(in_oklab,var(--card),var(--foreground)_8%)] font-semibold hover:bg-[color-mix(in_oklab,var(--card),var(--foreground)_12%)]";
function useAuthPageState(redirect) {
	return {
		redirectTo: getCurrentAuthRedirect(redirect),
		oauthQuery: typeof window !== "undefined" ? getOAuthSignedQuery(window.location.search) : null,
		isHostedMode: isHostedClientAuthMode(),
		isBetterAuthMode: usesBetterAuthClient()
	};
}
var termsLinkClassName = "text-foreground underline underline-offset-2 hover:text-foreground/80 transition-colors";
function TermsAgreementNotice({ action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-center text-sm leading-relaxed text-muted-foreground",
		children: [
			action,
			", you agree to our",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: TERMS_URL,
				target: "_blank",
				rel: "noreferrer",
				className: termsLinkClassName,
				children: "Terms"
			}),
			" ",
			"and",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: PRIVACY_URL,
				target: "_blank",
				rel: "noreferrer",
				className: termsLinkClassName,
				children: "Privacy Policy"
			}),
			"."
		]
	});
}
function AuthMethodChooser({ googleLabel, emailLabel = "Continue with email", isBusy, disabled, onContinueWithGoogle, onContinueWithEmail }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			type: "button",
			variant: "outline",
			className: "w-full border-black/10 !bg-white font-semibold !text-neutral-900 hover:border-black/20 hover:!bg-neutral-50",
			onClick: onContinueWithGoogle,
			disabled: disabled || isBusy,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GoogleLogo, {}), isBusy ? "Opening Google..." : googleLabel]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			type: "button",
			variant: "outline",
			className: "w-full bg-card font-semibold dark:border-border dark:bg-card",
			onClick: onContinueWithEmail,
			disabled: disabled || isBusy,
			children: emailLabel
		})]
	});
}
function GoogleLogo() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		"aria-hidden": "true",
		viewBox: "0 0 18 18",
		className: "size-4 shrink-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#4285F4",
				d: "M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.48h4.84a4.14 4.14 0 0 1-1.8 2.72v2.26h2.92c1.7-1.57 2.68-3.88 2.68-6.62Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#34A853",
				d: "M9 18c2.43 0 4.47-.8 5.96-2.18l-2.92-2.26c-.8.54-1.84.86-3.04.86-2.34 0-4.33-1.58-5.04-3.72H.94v2.34A9 9 0 0 0 9 18Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#FBBC05",
				d: "M3.96 10.7A5.4 5.4 0 0 1 3.68 9c0-.59.1-1.16.28-1.7V4.96H.94A9 9 0 0 0 0 9c0 1.45.34 2.82.94 4.04l3.02-2.34Z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#EA4335",
				d: "M9 3.58c1.32 0 2.5.45 3.44 1.35l2.58-2.58A8.64 8.64 0 0 0 9 0 9 9 0 0 0 .94 4.96L3.96 7.3C4.67 5.16 6.66 3.58 9 3.58Z"
			})
		]
	});
}
function AuthPageCard({ title, helperText, children, footer }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "w-full max-w-xs space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/transparent-logo.png",
					alt: "OpenSEO",
					className: "mx-auto size-10 rounded-lg"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold",
					children: title
				}), helperText ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: helperText
				}) : null] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-4",
				children
			}),
			footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-center",
				children: footer
			}) : null
		]
	});
}
function AuthPageShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-[100dvh] flex-col items-center overflow-y-auto bg-background p-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "m-auto flex w-full flex-col items-center",
			children
		})
	});
}
//#endregion
export { authInputClassName as a, useAuthPageState as c, TermsAgreementNotice as i, AuthPageCard as n, authRedirectSearchSchema as o, AuthPageShell as r, authSubmitClassName as s, AuthMethodChooser as t };
