import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { t as pageHead } from "./pageHead-BfhwMlwa.js";
import { r as auditSearchSchema } from "./audit-BJwJwQG7.js";
//#region src/routes/_app/p/$projectId/audit/index.tsx
var $$splitComponentImporter = () => import("./audit-BkFAxDFq.js");
var Route = createFileRoute("/_app/p/$projectId/audit/")({
	head: () => pageHead("Site Audit"),
	validateSearch: auditSearchSchema,
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
