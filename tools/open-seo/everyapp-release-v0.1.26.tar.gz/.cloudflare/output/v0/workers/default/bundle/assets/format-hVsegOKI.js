//#region src/shared/format.ts
/** Thousands separators for a count in server copy: "500,000". */
var formatCount = (n) => n.toLocaleString("en-US");
//#endregion
export { formatCount as t };
