import { t as createMiddleware } from "./createMiddleware-CRXSm-uH.js";
import { t as createCsrfMiddleware } from "./createCsrfMiddleware-D3HZHsrK.js";
import { t as globalServerFunctionMiddleware } from "./middleware-CAkDJtZb.js";
import { t as reloadForNewDeploy } from "./reloadForNewDeploy-CZaplaHi.js";
//#region node_modules/.pnpm/@tanstack+start-client-core@1.170.34/node_modules/@tanstack/start-client-core/dist/esm/createStart.js
function dedupeSerializationAdapters(deduped, serializationAdapters) {
	for (let i = 0, len = serializationAdapters.length; i < len; i++) {
		const current = serializationAdapters[i];
		if (!deduped.has(current)) {
			deduped.add(current);
			if (current.extends) dedupeSerializationAdapters(deduped, current.extends);
		}
	}
}
var createStart = (getOptions) => {
	return {
		getOptions: async () => {
			const options = await getOptions();
			if (options.serializationAdapters) {
				const deduped = /* @__PURE__ */ new Set();
				dedupeSerializationAdapters(deduped, options.serializationAdapters);
				options.serializationAdapters = Array.from(deduped);
			}
			return options;
		},
		createMiddleware
	};
};
//#endregion
//#region src/start.ts
var csrfMiddleware = createCsrfMiddleware({ filter: (ctx) => ctx.handlerType === "serverFn" });
var STALE_CLIENT_HEADER = "x-openseo-stale-client";
var staleClientMiddleware = createMiddleware().server(async ({ next }) => {
	try {
		return await next();
	} catch (error) {
		if (error instanceof Error && error.message.startsWith("Server function info not found")) return new Response("This page is out of date. Reload to continue.", {
			status: 409,
			headers: {
				"Content-Type": "text/plain",
				[STALE_CLIENT_HEADER]: "1"
			}
		});
		throw error;
	}
});
var startInstance = createStart(() => ({
	requestMiddleware: [csrfMiddleware, staleClientMiddleware],
	functionMiddleware: globalServerFunctionMiddleware,
	serverFns: { fetch: async (input, init) => {
		const response = await fetch(input, init);
		if (response.headers.has(STALE_CLIENT_HEADER)) reloadForNewDeploy();
		return response;
	} }
}));
//#endregion
export { startInstance };
