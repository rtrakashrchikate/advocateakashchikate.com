import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as Download } from "./download-B-49ilLV.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as X } from "./x-CPPij64W.js";
import { i as DropdownMenuItem, l as DropdownMenuTrigger, n as DropdownMenuContent, t as DropdownMenu } from "./dropdown-menu-DubRfxrI.js";
//#region src/client/components/table/TableBulkActionBar.tsx
var import_jsx_runtime = require_jsx_runtime();
function TableBulkActionBar({ selectedCount, selectedLabel = "selected", actions, onClear }) {
	if (selectedCount === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "pointer-events-none fixed inset-x-0 bottom-6 z-30 flex justify-center px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "toolbar",
			"aria-label": "Bulk actions",
			className: "pointer-events-auto flex items-stretch rounded-xl border border-border bg-popover/90 text-popover-foreground shadow-2xl backdrop-blur",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 border-r border-border py-2 pr-3 pl-2 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon-xs",
						"aria-label": "Clear selection",
						className: "text-muted-foreground",
						onClick: onClear,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium tabular-nums",
						children: selectedCount
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted-foreground",
						children: selectedLabel
					})
				]
			}), actions]
		})
	});
}
function TableBulkActionButton({ icon, children, onClick, disabled, variant = "default" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		variant: "ghost",
		size: "sm",
		onClick,
		disabled,
		className: variant === "danger" ? "text-destructive hover:bg-destructive/10 hover:text-destructive" : void 0,
		children: [icon, children]
	});
}
function TableBulkExportMenu({ actions, busy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuTrigger, {
		render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			size: "sm",
			pending: busy
		}),
		children: [busy ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { "data-icon": "inline-start" }), "Export"]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuContent, {
		side: "top",
		align: "end",
		className: "w-52",
		children: actions.map((action, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
			onClick: action.onClick,
			disabled: busy || action.disabled,
			children: [action.icon, action.label]
		}, index))
	})] });
}
//#endregion
export { TableBulkActionButton as n, TableBulkExportMenu as r, TableBulkActionBar as t };
