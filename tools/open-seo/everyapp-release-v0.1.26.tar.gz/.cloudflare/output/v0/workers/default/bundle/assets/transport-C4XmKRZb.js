import { Fn as object, Jn as string, Nt as array } from "./schemas-BPIpYT5n.js";
import { b as GuestAccountRepository, bt as resolveCloudflareAccessContext, et as getPublicOrigin, i as getHostedBaseUrl, xt as resolveLocalNoAuthContext } from "./resolve-DrNDcpX6.js";
import { s as CLIENT_CAPABILITIES_META_KEY } from "./internal-Dx9li7Qj.js";
import { G as describeError } from "./onboarding-drip-B7bIbv_6.js";
import { t as AuthRepository } from "./AuthRepository-tYELaN9C.js";
import { n as MCP_ROUTE, o as createWorkersOAuthMcpProps, s as hostedWorkersOAuthMcpPropsSchema, t as MCP_AUTH_CONTEXT_PROP } from "./context-CHGGA0Or.js";
import { a as hostHeaderValidationResponse, c as localhostAllowedOrigins, d as isJSONRPCRequest, i as createMcpHandler, l as originValidationResponse, o as isLegacyRequest, r as WebStandardStreamableHTTPServerTransport, s as localhostAllowedHostnames, t as createOpenSeoMcpServer, u as McpServer } from "./server-Cbh-v0o-.js";
import { AsyncLocalStorage } from "node:async_hooks";
//#region node_modules/.pnpm/agents@0.28.1_@ai-sdk+provider@4.0.4_@ai-sdk+react@3.0.211_react@19.2.4_zod@4.6.7__@bab_539d04cddbcc3adc73174759dfaafa16/node_modules/agents/dist/handler-stateless-Bly_nSH3.js
var VERIFIED_OAUTH_CONTEXT = Symbol.for("cloudflare.workers-oauth-provider.verified-context.v1");
var authContextStorage = new AsyncLocalStorage();
function runWithAuthContext(context, fn) {
	return authContextStorage.run(context, fn);
}
function isPlainRecord(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}
function invalidVerifiedContext() {
	throw new TypeError("Invalid verified OAuth request context");
}
function getVerifiedOAuthAuthInfo(ctx) {
	const symbolContext = ctx;
	if (!(VERIFIED_OAUTH_CONTEXT in symbolContext)) return void 0;
	const value = symbolContext[VERIFIED_OAUTH_CONTEXT];
	if (!isPlainRecord(value) || value.version !== 1) invalidVerifiedContext();
	const { token, clientId, scopes, expiresAt, resource, props } = value;
	if (typeof token !== "string" || token.length === 0 || typeof clientId !== "string" || clientId.length === 0 || !Array.isArray(scopes) || !scopes.every((scope) => typeof scope === "string") || !isPlainRecord(props)) invalidVerifiedContext();
	if (expiresAt !== void 0 && (typeof expiresAt !== "number" || !Number.isFinite(expiresAt) || expiresAt <= 0)) invalidVerifiedContext();
	let resourceUrl;
	if (resource !== void 0) {
		if (typeof resource !== "string") invalidVerifiedContext();
		try {
			resourceUrl = new URL(resource);
		} catch {
			invalidVerifiedContext();
		}
		if (resourceUrl.protocol !== "http:" && resourceUrl.protocol !== "https:") invalidVerifiedContext();
	}
	if (ctx.props !== props) invalidVerifiedContext();
	return {
		props,
		authInfo: {
			token,
			clientId,
			scopes: [...scopes],
			...expiresAt !== void 0 && { expiresAt },
			...resourceUrl !== void 0 && { resource: resourceUrl },
			extra: { props }
		}
	};
}
function internalErrorResponse(id = null) {
	return Response.json({
		jsonrpc: "2.0",
		error: {
			code: -32603,
			message: "Internal server error"
		},
		id
	}, { status: 500 });
}
function requestIdFromParsedBody(body) {
	if (typeof body !== "object" || body === null || Array.isArray(body) || !("method" in body) || typeof body.method !== "string" || !("id" in body)) return null;
	return typeof body.id === "string" || typeof body.id === "number" ? body.id : null;
}
function reportHandlerError(onerror, error) {
	try {
		onerror?.(error instanceof Error ? error : new Error(String(error)));
	} catch {}
}
/**
* Temporary adapter for Legacy compatibility on the SDK v2 transport.
*
* Local deltas from the upstream stateless fallback:
*
* - impossible stateless server-to-client requests fail immediately rather
*   than leaving the tool handler waiting for a session response.
* - a factory that returns an instance still serving another request is
*   rejected before this request takes ownership of it, so the error path
*   never closes the other request's instance (mirrors upstream's
*   `assertNotServing` on the modern path).
*
* Streaming and keepalive behavior remain delegated to the SDK transport.
* Remove this adapter once the SDK exposes the reverse-request policy directly.
*/
function createLegacyCompatibilityRequestHandler(factory, handlerOptions = {}) {
	const { keepAliveMs, onerror } = handlerOptions;
	const fetch = async (request, requestOptions) => {
		if (request.method.toUpperCase() !== "POST") return Response.json({
			jsonrpc: "2.0",
			error: {
				code: -32e3,
				message: "Method not allowed."
			},
			id: null
		}, { status: 405 });
		if (request.signal.aborted) return new Response(null, { status: 499 });
		let product;
		let transport;
		let teardownPromise;
		const teardown = () => teardownPromise ??= (async () => {
			await Promise.all([transport?.close().catch(() => {}), product?.close().catch(() => {})]);
		})();
		const onAbort = () => void teardown();
		try {
			const candidate = await factory({
				era: "legacy",
				...requestOptions?.authInfo !== void 0 && { authInfo: requestOptions.authInfo },
				requestInfo: request
			});
			assertNotServing(candidate);
			product = candidate;
			transport = new WebStandardStreamableHTTPServerTransport({
				keepAliveMs,
				sessionIdGenerator: void 0
			});
			const send = transport.send.bind(transport);
			transport.send = async (message, sendOptions) => {
				if (isJSONRPCRequest(message)) {
					transport?.onmessage?.({
						jsonrpc: "2.0",
						id: message.id,
						error: {
							code: -32603,
							message: "Server-to-client requests are unavailable in the Legacy compatibility lane. Use inputRequired(...) for Stateless clients, or route Legacy traffic to a sessionful transport."
						}
					});
					return;
				}
				await send(message, sendOptions);
			};
			await product.connect(transport);
			if (request.signal.aborted) {
				await teardown();
				return new Response(null, { status: 499 });
			}
			request.signal.addEventListener("abort", onAbort, { once: true });
			const response = await transport.handleRequest(request, {
				...requestOptions?.authInfo !== void 0 && { authInfo: requestOptions.authInfo },
				...requestOptions?.parsedBody !== void 0 && { parsedBody: requestOptions.parsedBody }
			});
			if (response.body === null || !response.headers.get("content-type")?.includes("text/event-stream")) {
				request.signal.removeEventListener("abort", onAbort);
				await teardown();
				return response;
			}
			const reader = response.body.getReader();
			const body = new ReadableStream({
				async pull(controller) {
					try {
						const { done, value } = await reader.read();
						if (done) {
							request.signal.removeEventListener("abort", onAbort);
							await teardown();
							controller.close();
						} else if (value !== void 0) controller.enqueue(value);
					} catch (error) {
						request.signal.removeEventListener("abort", onAbort);
						await teardown();
						controller.error(error);
					}
				},
				async cancel(reason) {
					request.signal.removeEventListener("abort", onAbort);
					await reader.cancel(reason).catch(() => {});
					await teardown();
				}
			});
			return new Response(body, {
				status: response.status,
				statusText: response.statusText,
				headers: response.headers
			});
		} catch (error) {
			request.signal.removeEventListener("abort", onAbort);
			await teardown();
			reportHandlerError(onerror, error);
			return internalErrorResponse(requestIdFromParsedBody(requestOptions?.parsedBody));
		}
	};
	return { fetch };
}
function assertNotServing(product) {
	if ((product instanceof McpServer ? product.server : product).transport !== void 0) throw new Error("The factory returned an instance that is still serving another request. Return a new instance for each request.");
}
var DEFAULT_CORS_OPTIONS = {
	origin: "*",
	headers: "Content-Type, Accept, Authorization, mcp-session-id, MCP-Protocol-Version, Mcp-Method, Mcp-Name",
	methods: "GET, POST, DELETE, OPTIONS",
	exposeHeaders: "mcp-session-id",
	maxAge: 86400
};
function corsHeaders(options = {}) {
	const merged = {
		...DEFAULT_CORS_OPTIONS,
		...options
	};
	return new Headers({
		"Access-Control-Allow-Headers": merged.headers,
		"Access-Control-Allow-Methods": merged.methods,
		"Access-Control-Allow-Origin": merged.origin,
		"Access-Control-Expose-Headers": merged.exposeHeaders,
		"Access-Control-Max-Age": String(merged.maxAge)
	});
}
function withCors(response, options) {
	const headers = new Headers(response.headers);
	if (options === false) {
		for (const name of Array.from(headers.keys())) if (name.toLowerCase().startsWith("access-control-")) headers.delete(name);
	} else for (const [name, value] of corsHeaders(options)) headers.set(name, value);
	return new Response(response.body, {
		status: response.status,
		statusText: response.statusText,
		headers
	});
}
function wrapResponseBodyWithAuthContext(response, authContext) {
	if (!authContext || !response.body) return response;
	const reader = response.body.getReader();
	const body = new ReadableStream({
		pull(controller) {
			return runWithAuthContext(authContext, async () => {
				try {
					const { done, value } = await reader.read();
					if (done) controller.close();
					else controller.enqueue(value);
				} catch (error) {
					controller.error(error);
				}
			});
		},
		cancel(reason) {
			return runWithAuthContext(authContext, () => reader.cancel(reason));
		}
	});
	return new Response(body, {
		status: response.status,
		statusText: response.statusText,
		headers: response.headers
	});
}
function createStatelessMcpHandler(factory, options = {}) {
	const optionRecord = options;
	if (optionRecord.bus !== void 0) throw new TypeError("createMcpHandler option \"bus\" is not exposed by the Agents SDK.");
	const legacyOnlyOption = [
		"transport",
		"storage",
		"sessionIdGenerator",
		"onsessioninitialized",
		"onsessionclosed",
		"enableJsonResponse",
		"eventStore",
		"allowedHosts",
		"allowedOrigins",
		"enableDnsRebindingProtection",
		"retryInterval"
	].find((key) => optionRecord[key] !== void 0);
	if (legacyOnlyOption) throw new TypeError(`createMcpHandler option "${legacyOnlyOption}" is only supported with an MCP SDK v1 server. The managed SDK v2 handler is stateless; remove this option or keep the v1 server during migration.`);
	const { route = "/mcp", corsOptions = {}, allowedHostnames, allowedOriginHostnames, authContext, legacy = "stateless", ...sdkOptions } = options;
	const sdkHandler = createMcpHandler(factory, {
		...sdkOptions,
		legacy: "reject"
	});
	const legacyCompatibilityHandler = legacy === "stateless" ? createLegacyCompatibilityRequestHandler(factory, {
		keepAliveMs: sdkOptions.keepAliveMs,
		onerror: sdkOptions.onerror
	}) : void 0;
	const serve = async (request, requestOptions, workerCtx) => {
		const requestUrl = new URL(request.url);
		if (requestUrl.pathname !== route) return withCors(new Response("Not Found", { status: 404 }), corsOptions);
		const localEndpoint = localhostAllowedHostnames().includes(requestUrl.hostname);
		const workersDevEndpoint = requestUrl.hostname.endsWith(".workers.dev");
		const acceptedHostnames = allowedHostnames ?? (localEndpoint ? localhostAllowedHostnames() : workersDevEndpoint ? [requestUrl.hostname] : void 0);
		const hostRejection = acceptedHostnames ? hostHeaderValidationResponse(request, acceptedHostnames) : void 0;
		if (hostRejection) return withCors(hostRejection, corsOptions);
		if (allowedOriginHostnames !== "*") {
			let acceptedOriginHostnames = allowedOriginHostnames;
			if (acceptedOriginHostnames === void 0) {
				const defaults = new Set(localhostAllowedOrigins());
				if (workersDevEndpoint) defaults.add(requestUrl.hostname);
				if (corsOptions !== false && corsOptions.origin !== void 0) try {
					const configuredOrigin = new URL(corsOptions.origin);
					if ((configuredOrigin.protocol === "http:" || configuredOrigin.protocol === "https:") && configuredOrigin.hostname) defaults.add(configuredOrigin.hostname);
				} catch {}
				acceptedOriginHostnames = [...defaults];
			}
			const originRejection = originValidationResponse(request, acceptedOriginHostnames ?? []);
			if (originRejection) return withCors(originRejection, corsOptions);
		}
		if (request.method === "OPTIONS" && corsOptions !== false) return new Response(null, { headers: corsHeaders(corsOptions) });
		const legacyRequest = legacyCompatibilityHandler !== void 0 && await isLegacyRequest(request, requestOptions?.parsedBody);
		try {
			const verified = workerCtx ? getVerifiedOAuthAuthInfo(workerCtx) : void 0;
			const explicitAuthInfo = requestOptions?.authInfo;
			if (verified && explicitAuthInfo && explicitAuthInfo.clientId !== verified.authInfo.clientId) throw new TypeError("Conflicting verified OAuth client identity");
			const authInfo = explicitAuthInfo ?? verified?.authInfo;
			const resolvedAuthContext = authContext ?? (verified ? { props: verified.props } : workerCtx?.props && Object.keys(workerCtx.props).length > 0 ? { props: workerCtx.props } : void 0);
			const upstreamOptions = requestOptions || authInfo ? {
				...requestOptions,
				...authInfo && { authInfo }
			} : void 0;
			const invoke = async () => {
				if (legacyRequest && legacyCompatibilityHandler) return legacyCompatibilityHandler.fetch(request, upstreamOptions);
				return sdkHandler.fetch(request, upstreamOptions);
			};
			return withCors(wrapResponseBodyWithAuthContext(resolvedAuthContext ? await runWithAuthContext(resolvedAuthContext, invoke) : await invoke(), resolvedAuthContext), corsOptions);
		} catch (error) {
			reportHandlerError(sdkOptions.onerror, error);
			return withCors(internalErrorResponse(), corsOptions);
		}
	};
	const callable = (request, _env, ctx) => serve(request, void 0, ctx);
	const fetch = (request, requestOptions) => serve(request, requestOptions);
	return Object.assign(callable, {
		fetch,
		notify: sdkHandler.notify
	});
}
var W = "io.modelcontextprotocol/ui";
function H(B) {
	if (!B) return;
	return B.extensions?.[W];
}
//#endregion
//#region src/server/mcp/ui-capabilities.ts
var requestSchema = object({ params: object({ _meta: object({ [CLIENT_CAPABILITIES_META_KEY]: object({ extensions: object({ [W]: object({ mimeTypes: array(string()) }).optional() }).optional() }).optional() }).optional() }).optional() });
async function supportsMcpApps(request) {
	if (!request || request.method !== "POST") return false;
	const parsed = requestSchema.safeParse(await request.clone().json().catch(() => null));
	return parsed.success && H(parsed.data.params?._meta?.["io.modelcontextprotocol/clientCapabilities"])?.mimeTypes?.includes("text/html;profile=mcp-app") === true;
}
//#endregion
//#region src/server/mcp/transport.ts
var MCP_CORS_HEADERS = {
	"Access-Control-Allow-Headers": "Content-Type, Accept, Authorization, mcp-session-id, MCP-Protocol-Version, Mcp-Method, Mcp-Name",
	"Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
	"Access-Control-Allow-Origin": "*",
	"Access-Control-Expose-Headers": "mcp-session-id",
	"Access-Control-Max-Age": "86400"
};
var SURFMIND_CHROME_EXTENSION_HOSTNAME = "pghallcbnfabbgfijhbcldaapmgidnaa";
var SURFMIND_CHROME_EXTENSION_ORIGIN = `chrome-extension://${SURFMIND_CHROME_EXTENSION_HOSTNAME}`;
function withMcpCors(response) {
	const headers = new Headers(response.headers);
	for (const [name, value] of Object.entries(MCP_CORS_HEADERS)) headers.set(name, value);
	return new Response(response.body, {
		status: response.status,
		statusText: response.statusText,
		headers
	});
}
function validateLegacyRequest(request, allowedOriginHostnames) {
	const url = new URL(request.url);
	const isLocal = localhostAllowedHostnames().includes(url.hostname);
	const isWorkersDev = url.hostname.endsWith(".workers.dev");
	const acceptedHostnames = isLocal ? localhostAllowedHostnames() : isWorkersDev ? [url.hostname] : void 0;
	const hostRejection = acceptedHostnames ? hostHeaderValidationResponse(request, acceptedHostnames) : void 0;
	if (hostRejection) return withMcpCors(hostRejection);
	const acceptedOrigins = allowedOriginHostnames ?? (isWorkersDev ? [...localhostAllowedOrigins(), url.hostname] : localhostAllowedOrigins());
	const originRejection = originValidationResponse(request, acceptedOrigins);
	return originRejection ? withMcpCors(originRejection) : void 0;
}
async function handleLegacyJsonRequest(request, props, supportsApps) {
	if (request.method !== "POST") return withMcpCors(Response.json({
		jsonrpc: "2.0",
		error: {
			code: -32e3,
			message: "Method not allowed."
		},
		id: null
	}, {
		status: 405,
		headers: { Allow: "POST, OPTIONS" }
	}));
	const server = createOpenSeoMcpServer(props, supportsApps);
	const transport = new WebStandardStreamableHTTPServerTransport({
		sessionIdGenerator: void 0,
		enableJsonResponse: true
	});
	try {
		await server.connect(transport);
		return withMcpCors(await transport.handleRequest(request));
	} finally {
		await Promise.all([transport.close().catch(() => {}), server.close().catch(() => {})]);
	}
}
function createRequestHandler(props, supportsApps, allowedOriginHostnames) {
	const modernHandler = createStatelessMcpHandler(() => createOpenSeoMcpServer(props, supportsApps), {
		route: MCP_ROUTE,
		allowedOriginHostnames,
		legacy: "reject",
		maxSubscriptions: 0
	});
	return async (request, env, ctx) => {
		if (request.method === "OPTIONS") return new Response(null, { headers: MCP_CORS_HEADERS });
		if (new URL(request.url).pathname !== "/mcp") return withMcpCors(new Response("Not Found", { status: 404 }));
		if (!await isLegacyRequest(request)) return modernHandler(request, env, ctx);
		return validateLegacyRequest(request, allowedOriginHostnames) ?? handleLegacyJsonRequest(request, props, supportsApps);
	};
}
async function actAsClaimingUser(authContext) {
	if (!authContext.guestClaimToken) return authContext;
	const claimer = await GuestAccountRepository.findClaimingUser(authContext.userId);
	if (!claimer) return authContext;
	return {
		...authContext,
		userId: claimer.userId,
		userEmail: claimer.email,
		guestClaimToken: void 0
	};
}
async function handleAuthenticatedOpenSeoMcpRequest(request, props, env, ctx) {
	const result = hostedWorkersOAuthMcpPropsSchema.safeParse(props);
	if (!result.success) return new Response("MCP auth context required", { status: 403 });
	if (!result.data["openSeoAuth"].scopes.includes("mcp")) return new Response("MCP scope required", { status: 403 });
	const hostedUrl = new URL(getHostedBaseUrl());
	const origin = request.headers.get("Origin");
	if (origin && origin !== hostedUrl.origin && origin !== SURFMIND_CHROME_EXTENSION_ORIGIN) return withMcpCors(new Response("Invalid Origin", { status: 403 }));
	const authContext = await actAsClaimingUser(result.data[MCP_AUTH_CONTEXT_PROP]);
	const membership = await AuthRepository.getMembership(authContext.userId, authContext.organizationId).catch((error) => {
		console.error(`mcp.auth membership lookup failed: ${describeError(error)}`);
		throw error;
	});
	if (!membership) return new Response("Organization access revoked", {
		status: 401,
		headers: { "WWW-Authenticate": "Bearer error=\"invalid_token\"" }
	});
	return createRequestHandler(createWorkersOAuthMcpProps({
		...authContext,
		role: membership.role,
		userAgent: request.headers.get("user-agent") ?? void 0
	}), await supportsMcpApps(request), [hostedUrl.hostname, SURFMIND_CHROME_EXTENSION_HOSTNAME])(request, env, ctx);
}
async function handleSelfHostedOpenSeoMcpRequest(request, authMode, env, ctx) {
	if (request.method === "OPTIONS") return new Response(null, { headers: MCP_CORS_HEADERS });
	const identity = authMode === "local_noauth" ? await resolveLocalNoAuthContext() : await resolveCloudflareAccessContext(request.headers);
	return createRequestHandler(createWorkersOAuthMcpProps({
		userId: identity.userId,
		userEmail: identity.userEmail,
		organizationId: identity.organizationId,
		baseUrl: getPublicOrigin(request),
		userAgent: request.headers.get("user-agent") ?? void 0
	}), await supportsMcpApps(request))(request, env, ctx);
}
//#endregion
export { handleAuthenticatedOpenSeoMcpRequest, handleSelfHostedOpenSeoMcpRequest };
