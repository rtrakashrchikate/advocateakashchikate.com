import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { t as pageHead } from "./pageHead-BfhwMlwa.js";
//#region src/routes/_app/p/$projectId/settings.tsx
var $$splitComponentImporter = () => import("./settings-UmYezA3_.js");
var Route = createFileRoute("/_app/p/$projectId/settings")({
	head: () => pageHead("Project settings"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
