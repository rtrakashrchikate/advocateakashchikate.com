import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { t as AuthRepository } from "./AuthRepository-tYELaN9C.js";
import { p as CURRENT_TERMS_VERSION } from "./auth-redirect-Dnh6pyWf.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/server/auth/terms-acceptance.ts
async function acceptCurrentTerms(userId) {
	await AuthRepository.setTermsAcceptance(userId, CURRENT_TERMS_VERSION, /* @__PURE__ */ new Date());
}
var TermsAcceptanceService = { acceptCurrentTerms };
//#endregion
//#region src/serverFunctions/terms.ts?tss-serverfn-split
var acceptTermsUpdate_createServerFn_handler = createServerRpc({
	id: "3d7f65dfdb19058c1c6e4e20c55a56e9a9dd4247087215febdb7d1a40508edfe",
	name: "acceptTermsUpdate",
	filename: "src/serverFunctions/terms.ts"
}, (opts) => acceptTermsUpdate.__executeServer(opts));
var acceptTermsUpdate = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).handler(acceptTermsUpdate_createServerFn_handler, async ({ context }) => TermsAcceptanceService.acceptCurrentTerms(context.userId));
//#endregion
export { acceptTermsUpdate_createServerFn_handler };
