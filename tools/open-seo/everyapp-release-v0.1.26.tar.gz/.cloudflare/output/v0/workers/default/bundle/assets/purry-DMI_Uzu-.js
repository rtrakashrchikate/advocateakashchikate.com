//#region node_modules/.pnpm/remeda@2.33.6/node_modules/remeda/dist/lazyDataLastImpl-DtF3cihj.js
function e(e, t, n) {
	let r = (n) => e(n, ...t);
	return n === void 0 ? r : Object.assign(r, {
		lazy: n,
		lazyArgs: t
	});
}
//#endregion
//#region node_modules/.pnpm/remeda@2.33.6/node_modules/remeda/dist/purry.js
function t(t, n, r) {
	let i = t.length - n.length;
	if (i === 0) return t(...n);
	if (i === 1) return e(t, n, r);
	throw Error(`Wrong number of arguments`);
}
//#endregion
export { t };
