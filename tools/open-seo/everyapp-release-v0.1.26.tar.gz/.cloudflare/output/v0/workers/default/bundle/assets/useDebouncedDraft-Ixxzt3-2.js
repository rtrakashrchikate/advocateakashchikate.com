import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
//#region src/client/hooks/useDebouncedDraft.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
/**
* Local draft of a URL-backed value for live-typed inputs. Edits stay local
* and commit after a pause, so each keystroke does not navigate. The draft
* follows URL changes it did not cause (back/forward, "Clear all").
*/
function useDebouncedDraft(applied, commit, normalize = (value) => value, delayMs = 350) {
	const [draft, setDraft] = (0, import_react.useState)(applied);
	const appliedKey = JSON.stringify(applied);
	const [syncedKey, setSyncedKey] = (0, import_react.useState)(appliedKey);
	const [awaitingCommit, setAwaitingCommit] = (0, import_react.useState)(false);
	const callbacksRef = (0, import_react.useRef)({
		commit,
		normalize
	});
	(0, import_react.useEffect)(() => {
		callbacksRef.current = {
			commit,
			normalize
		};
	});
	if (syncedKey !== appliedKey) {
		setSyncedKey(appliedKey);
		if (awaitingCommit) setAwaitingCommit(false);
		else setDraft(applied);
	}
	(0, import_react.useEffect)(() => {
		const next = callbacksRef.current.normalize(draft);
		if (JSON.stringify(next) === appliedKey) return;
		const timer = window.setTimeout(() => {
			setAwaitingCommit(true);
			callbacksRef.current.commit(next);
		}, delayMs);
		return () => window.clearTimeout(timer);
	}, [
		appliedKey,
		delayMs,
		draft
	]);
	return [draft, setDraft];
}
//#endregion
export { useDebouncedDraft as t };
