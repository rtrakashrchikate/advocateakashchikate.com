import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { Fn as object, Jn as string, Sn as looseObject } from "./schemas-BPIpYT5n.js";
import { c as isHostedClientAuthMode, f as usesBetterAuthClient, o as isEveryAppClientAuthMode } from "./auth-mode-DhGCw2Bx.js";
import { n as signOutAndRedirect, r as useSession, t as authClient } from "./auth-client-DstRenkx.js";
import { n as formatDeletionDate } from "./account-deletion-D5wVem-C.js";
import { t as version } from "./package-BwmBkp5F.js";
import { j as useQueryClient, t as useQuery } from "./useQuery-B93OR2NQ.js";
import { n as QueryState } from "./QueryState-Q8BZIblk.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { n as getErrorCode, r as getStandardErrorMessage } from "./error-messages-D7nntGF_.js";
import { n as createLucideIcon } from "./dist-fVOGIv0D.js";
import { t as Button } from "./button-DrcZrdio.js";
import { n as ThemePreferenceRadio } from "./ThemePreferenceMenuItems-DB5ujp3U.js";
import { t as Trash2 } from "./trash-2-B7Pu83CI.js";
import { t as TriangleAlert } from "./triangle-alert-C9SRPVjv.js";
import { i as AlertTitle, r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { n as captureClientEvent } from "./posthog-BMFJOGWd.js";
import { t as createSsrRpc } from "./createSsrRpc-Vp3C13VD.js";
import { n as requireAuthenticatedContext } from "./middleware-CAkDJtZb.js";
import { t as everyAppAccountQueryOptions } from "./everyAppAccountQueries-C9mjQ_j3.js";
import { t as organizationContextQueryOptions } from "./organizationQueries-BMLHGNAs.js";
import { t as Input } from "./input-B1cALAbz.js";
import { i as SectionHeader } from "./PageHeader-a3_4WaC8.js";
import { t as CopyButton } from "./CopyButton-BPiDtx7F.js";
import { a as TableHead, i as TableCell, n as TableBody, o as TableHeader, r as TableCard, s as TableRow, t as Table } from "./table-CqwvrC02.js";
import { t as Switch } from "./switch-BumBbmWp.js";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C8cX1CPK.js";
import { a as AlertDialogDescription, c as AlertDialogTitle, i as AlertDialogContent, n as AlertDialog, o as AlertDialogFooter, r as AlertDialogCancel, s as AlertDialogHeader, t as ConfirmDialog } from "./ConfirmDialog-CI0zpKxJ.js";
import { i as DropdownMenuItem } from "./dropdown-menu-DubRfxrI.js";
import { i as revalidateLogic } from "./useForm-B2StPr3w.js";
import { t as useAppForm } from "./useAppForm-DjX0VDRv.js";
import { n as revokeMcpConnection, t as listMcpConnections } from "./mcp-connections-DDCKqhQ_.js";
import { t as RowActionsMenu } from "./RowActionsMenu-zl2TiODR.js";
import { n as updatePrivacyChoices, r as usePrivacyChoices, t as setProductUpdatesOptIn } from "./product-updates-BzhKHy2D.js";
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var Unplug = createLucideIcon("unplug", [
	["path", {
		d: "m19 5 3-3",
		key: "yk6iyv"
	}],
	["path", {
		d: "m2 22 3-3",
		key: "19mgm9"
	}],
	["path", {
		d: "M6.3 20.3a2.4 2.4 0 0 0 3.4 0L12 18l-6-6-2.3 2.3a2.4 2.4 0 0 0 0 3.4Z",
		key: "goz73y"
	}],
	["path", {
		d: "M7.5 13.5 10 11",
		key: "7xgeeb"
	}],
	["path", {
		d: "M10.5 16.5 13 14",
		key: "10btkg"
	}],
	["path", {
		d: "m12 6 6 6 2.3-2.3a2.4 2.4 0 0 0 0-3.4l-2.6-2.6a2.4 2.4 0 0 0-3.4 0Z",
		key: "1snsnr"
	}]
]);
//#endregion
//#region src/client/features/settings/useOrganizations.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
function useOrganizations() {
	const { data } = useQuery(organizationContextQueryOptions());
	const organizations = data?.organizations ?? [];
	return {
		activeOrganizationName: data?.organizationName ?? null,
		hasMultiple: organizations.length > 1,
		organizationName: (organizationId) => organizations.find((o) => o.organizationId === organizationId)?.organizationName ?? null
	};
}
//#endregion
//#region src/client/features/settings/ApiKeySettings.tsx
var import_jsx_runtime = require_jsx_runtime();
var MAX_KEY_NAME_LENGTH = 32;
var createKeySchema = object({ name: string().trim().min(1, "Name is required") });
var apiKeyMetadataSchema = looseObject({ organizationId: string().optional() });
function ApiKeySettings() {
	const queryClient = useQueryClient();
	const [isCreateOpen, setIsCreateOpen] = (0, import_react.useState)(false);
	const [createdKey, setCreatedKey] = (0, import_react.useState)(null);
	const [revoking, setRevoking] = (0, import_react.useState)(null);
	const { hasMultiple: showOrganization, activeOrganizationName, organizationName } = useOrganizations();
	const mcpUrl = typeof window === "undefined" ? "https://app.openseo.so/mcp" : `${window.location.origin}/mcp`;
	const apiKeysQuery = useQuery({
		queryKey: ["apiKeys"],
		queryFn: async () => {
			const result = await authClient.apiKey.list();
			if (result.error) throw new Error(result.error.message ?? "Failed to load API keys");
			return result.data.apiKeys.map((key) => ({
				id: key.id,
				name: key.name,
				start: key.start,
				createdAt: new Date(key.createdAt),
				lastRequest: key.lastRequest ? new Date(key.lastRequest) : null,
				organizationId: apiKeyMetadataSchema.safeParse(key.metadata).data?.organizationId ?? null
			}));
		}
	});
	const createMutation = useMutation({
		mutationFn: async (keyName) => {
			const result = await authClient.apiKey.create({ name: keyName });
			if (result.error || !result.data?.key) throw new Error(result.error?.message ?? "Failed to create the key");
			return result.data.key;
		},
		onSuccess: (key) => {
			setCreatedKey(key);
			captureClientEvent("mcp:api_key_created");
			queryClient.invalidateQueries({ queryKey: ["apiKeys"] });
		}
	});
	const revokeMutation = useMutation({
		mutationFn: async (keyId) => {
			const result = await authClient.apiKey.delete({ keyId });
			if (result.error) throw new Error(result.error.message ?? "Failed to revoke the key");
		},
		onSuccess: () => {
			captureClientEvent("mcp:api_key_revoked");
			toast.success("API key revoked");
			setRevoking(null);
			queryClient.invalidateQueries({ queryKey: ["apiKeys"] });
		}
	});
	const form = useAppForm({
		defaultValues: { name: "" },
		validationLogic: revalidateLogic(),
		validators: { onDynamic: createKeySchema },
		onSubmit: async ({ value }) => {
			await createMutation.mutateAsync(value.name.trim());
		}
	});
	const closeCreateModal = () => {
		setIsCreateOpen(false);
		setCreatedKey(null);
		form.reset();
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { title: "API keys" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm",
						children: "Authenticate MCP clients when OAuth doesn't work"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted-foreground",
						children: "Use this for remote agents like Hermes where the normal login flow doesn't work."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "text-primary underline-offset-4 hover:underline",
							href: "https://openseo.so/docs/mcp",
							target: "_blank",
							rel: "noreferrer",
							children: "Setup guide"
						})
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					onClick: () => setIsCreateOpen(true),
					children: "Create API key"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
				query: apiKeysQuery,
				errorFallback: "We couldn't load your API keys.",
				children: (apiKeys) => apiKeys.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No API keys yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCard, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Name" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Key" }),
					showOrganization ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Organization" }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Created" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Last used" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "w-10" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: apiKeys.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "max-w-[220px] truncate font-medium",
						children: key.name || "Unnamed key"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCell, {
						className: "font-mono text-xs text-muted-foreground",
						"data-ph-mask": true,
						children: [key.start || "oseo_", "\u2026"]
					}),
					showOrganization ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "text-xs text-muted-foreground",
						children: organizationName(key.organizationId) ?? "\u2014"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "text-xs text-muted-foreground",
						children: key.createdAt.toLocaleDateString()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "text-xs text-muted-foreground",
						children: key.lastRequest ? key.lastRequest.toLocaleDateString() : "Never"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowActionsMenu, {
						label: `Actions for ${key.name || "API key"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
							variant: "destructive",
							onClick: () => setRevoking({
								id: key.id,
								name: key.name || "Unnamed key"
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Revoke key"]
						})
					}) })
				] }, key.id)) })] }) })
			}),
			revoking ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				title: `Revoke \u201c${revoking.name}\u201d?`,
				confirmLabel: "Revoke key",
				destructive: true,
				pending: revokeMutation.isPending,
				onClose: () => setRevoking(null),
				onConfirm: () => revokeMutation.mutate(revoking.id),
				children: "Clients using it will stop working."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: isCreateOpen,
				onOpenChange: (open) => {
					if (!open && createdKey == null) closeCreateModal();
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContent, {
					showCloseButton: false,
					className: "grid-cols-1 sm:max-w-md",
					children: createdKey ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Copy your new API key" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
							"It won't be shown again. Send it as",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs",
								children: "Authorization: Bearer"
							}),
							" ",
							"to",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs break-all",
								children: mcpUrl
							}),
							"."
						] })] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
								className: "min-w-0 flex-1 overflow-x-auto rounded bg-muted px-2.5 py-2 font-mono text-xs",
								"data-ph-mask": true,
								children: createdKey
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyButton, {
								value: createdKey,
								successMessage: "API key copied",
								label: "Copy API key",
								variant: "ghost",
								size: "icon-sm"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: closeCreateModal,
							children: "Done"
						}) })
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.AppForm, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(form.Form, {
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Create API key" }) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.AppField, {
								name: "name",
								children: (field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(field.TextField, {
									label: "Name",
									placeholder: "Claude Code on laptop",
									maxLength: MAX_KEY_NAME_LENGTH,
									required: true,
									autoFocus: true
								})
							}),
							showOrganization ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted-foreground",
								children: [
									"This key works in ",
									activeOrganizationName,
									"."
								]
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: closeCreateModal,
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(form.SubmitButton, { children: "Create" })] })
						]
					}) })
				})
			})
		]
	});
}
//#endregion
//#region src/serverFunctions/account-deletion.ts
var getAccountDeletionStatus = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).handler(createSsrRpc("1166d95317aec17ef180de12f84493aa962df45035a16135f0a4ed81f7b8a834"));
var requestAccountDeletion = createServerFn({ method: "POST" }).middleware(requireAuthenticatedContext).validator(object({ confirmEmail: string().max(320) })).handler(createSsrRpc("18dd16e01eb78552f527d11670fb1a36f78c7b1e6c94df5e63902f0ec18e649c"));
//#endregion
//#region src/client/features/settings/DeleteAccountSettings.tsx
function blockerText(blocker) {
	const others = blocker.otherMemberCount === 1 ? "1 other member" : `${blocker.otherMemberCount} other members`;
	return `You own \u201C${blocker.organizationName}\u201D, which has ${others}. Deleting your account would leave them without an owner. Remove them in Organization settings, or email support@openseo.so to hand the workspace to one of them.`;
}
function billingText(charge) {
	const stops = [charge.renewingPlan ? "cancel its paid plan" : null, charge.autoReload ? "turn off auto-reload" : null].filter(Boolean).join(" and ");
	return `\u201C${charge.organizationName}\u201D: we'll ${stops}.`;
}
function deletionErrorMessage(error) {
	switch (getErrorCode(error)) {
		case "FORBIDDEN": return "For your security, sign out and sign back in, then try again.";
		case "VALIDATION_ERROR": return "Your account can't be deleted yet. Click Delete account again to see why.";
		case "CONFLICT": return "Your account is already scheduled for deletion.";
		default: return getStandardErrorMessage(error);
	}
}
function DeleteAccountSettings() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const status = useQuery({
		queryKey: ["accountDeletionStatus"],
		queryFn: () => getAccountDeletionStatus(),
		staleTime: 0
	}).data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { title: "Delete account" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Permanently delete your account, and every workspace where you are the only member, with all its projects and data. You are signed out right away and the deletion happens",
					" ",
					status ? `${status.deletionDelayDays} days` : "two weeks",
					" later."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "sm",
				className: "-ml-2.5 text-destructive hover:bg-destructive/10 hover:text-destructive dark:hover:bg-destructive/20",
				disabled: !status,
				onClick: () => setOpen(true),
				children: "Delete account"
			}),
			open && status ? status.blockers.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BlockedDialog, {
				status,
				onClose: () => setOpen(false)
			}) : !status.signedInRecently ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignInAgainDialog, { onClose: () => setOpen(false) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteAccountDialog, {
				status,
				onClose: () => setOpen(false)
			}) : null
		]
	});
}
function BlockedDialog({ status, onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: true,
		onOpenChange: (next) => !next && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "You can't delete your account yet" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, {
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "list-disc space-y-1 pl-5 text-left",
				children: status.blockers.map((blocker) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: blockerText(blocker) }, blocker.organizationName))
			})
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Close" }) })] })
	});
}
function SignInAgainDialog({ onClose }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: true,
		onOpenChange: (next) => !next && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Sign in again to continue" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "For your security, sign out and sign back in before deleting your account." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, { children: "Cancel" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			onClick: () => signOutAndRedirect(),
			children: "Sign out"
		})] })] })
	});
}
function DeleteAccountDialog({ status, onClose }) {
	const queryClient = useQueryClient();
	const { data: session } = useSession();
	const [confirmEmail, setConfirmEmail] = (0, import_react.useState)("");
	const email = session?.user.email ?? "";
	const matches = email !== "" && confirmEmail.trim().toLowerCase() === email.toLowerCase();
	const mutation = useMutation({
		mutationFn: () => requestAccountDeletion({ data: { confirmEmail } }),
		onSuccess: ({ deleteAfter }) => {
			toast.success(`Your account will be deleted on ${formatDeletionDate(deleteAfter)}.`);
			signOutAndRedirect();
		},
		onError: (error) => {
			toast.error(deletionErrorMessage(error));
			queryClient.invalidateQueries({ queryKey: ["accountDeletionStatus"] });
			onClose();
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialog, {
		open: true,
		onOpenChange: (next) => {
			if (!next && !mutation.isPending) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogTitle, { children: "Delete your account?" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogDescription, { children: "You'll be signed out now, and any paid plan and auto-reload on the workspaces deleted with your account are canceled. This can't be undone after the deletion date. Type your email to confirm." })] }),
			status.billingToStop.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
				variant: "warning",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Deleting your account stops billing" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "list-disc space-y-1 pl-5",
						children: status.billingToStop.map((charge) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: billingText(charge) }, charge.organizationName))
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2",
						children: "A canceled plan doesn't renew, and you keep its credits until the deletion date."
					})] })
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: confirmEmail,
				onChange: (event) => setConfirmEmail(event.target.value),
				placeholder: email,
				"aria-label": "Your email",
				autoComplete: "off"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDialogCancel, {
				disabled: mutation.isPending,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "destructive",
				disabled: !matches,
				pending: mutation.isPending,
				onClick: () => mutation.mutate(),
				children: "Delete account"
			})] })
		] })
	});
}
//#endregion
//#region src/client/features/settings/McpConnectionsSettings.tsx
function McpConnectionsSettings() {
	const queryClient = useQueryClient();
	const [disconnecting, setDisconnecting] = (0, import_react.useState)(null);
	const { hasMultiple: showOrganization, organizationName } = useOrganizations();
	const connectionsQuery = useQuery({
		queryKey: ["mcpConnections"],
		queryFn: () => listMcpConnections()
	});
	const disconnectMutation = useMutation({
		mutationFn: (grantId) => revokeMcpConnection({ data: { grantId } }),
		onSuccess: () => {
			captureClientEvent("mcp:connection_revoked");
			toast.success("Agent disconnected");
			setDisconnecting(null);
			queryClient.invalidateQueries({ queryKey: ["mcpConnections"] });
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { title: "Connected agents" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm",
				children: "AI clients signed in to OpenSEO with OAuth."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
				query: connectionsQuery,
				errorFallback: "We couldn't load your connected agents.",
				children: (connections) => connections.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "No agents connected yet."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCard, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Client" }),
					showOrganization ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Organization" }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Connected" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { className: "w-10" })
				] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: connections.map((connection) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "max-w-[220px] truncate font-medium",
						children: connection.clientName
					}),
					showOrganization ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "text-xs text-muted-foreground",
						children: organizationName(connection.organizationId) ?? "\u2014"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
						className: "text-xs text-muted-foreground",
						children: new Date(connection.createdAt).toLocaleDateString()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowActionsMenu, {
						label: `Actions for ${connection.clientName}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
							variant: "destructive",
							onClick: () => setDisconnecting({
								id: connection.id,
								clientName: connection.clientName
							}),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Unplug, {}), "Disconnect"]
						})
					}) })
				] }, connection.id)) })] }) })
			}),
			disconnecting ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
				title: `Disconnect \u201C${disconnecting.clientName}\u201D?`,
				confirmLabel: "Disconnect",
				destructive: true,
				pending: disconnectMutation.isPending,
				onClose: () => setDisconnecting(null),
				onConfirm: () => disconnectMutation.mutate(disconnecting.id),
				children: "It will have to sign in to OpenSEO again."
			}) : null
		]
	});
}
//#endregion
//#region src/client/features/settings/PrivacySettings.tsx
function PrivacySettings() {
	const choices = usePrivacyChoices();
	const { data: session, refetch } = useSession();
	const productUpdates = useMutation({
		mutationFn: (optIn) => setProductUpdatesOptIn({ data: { optIn } }),
		onSuccess: () => refetch({ query: { disableCookieCache: true } }),
		onError: () => toast.error("We couldn't save your email choice.")
	});
	if (!choices || !session) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { title: "Privacy and emails" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "Usage analytics"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Share usage analytics and session replays to help improve OpenSEO."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: choices.analytics,
					onCheckedChange: (analytics) => void updatePrivacyChoices({
						...choices,
						analytics
					}, true),
					"aria-label": "Share usage analytics"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm",
					children: "Product updates"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: "Occasional emails about new features and tips. Unsubscribe anytime."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: productUpdates.isPending ? productUpdates.variables : session.user.productUpdatesOptIn === true,
					disabled: productUpdates.isPending,
					onCheckedChange: (optIn) => productUpdates.mutate(optIn),
					"aria-label": "Get product update emails"
				})]
			})
		]
	});
}
//#endregion
//#region src/routes/_app/settings/index.tsx?tsr-split=component
function PersonalSettings() {
	const isHosted = isHostedClientAuthMode();
	const hasAccounts = usesBetterAuthClient();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { title: "Appearance" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Theme"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemePreferenceRadio, {})]
				})]
			}),
			isEveryAppClientAuthMode() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EveryAppSettings, {}) : null,
			isHosted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(McpConnectionsSettings, {}) : null,
			hasAccounts ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApiKeySettings, {}) : null,
			isHosted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrivacySettings, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { title: "About" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-sm",
						children: "Version"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono text-sm text-muted-foreground",
						children: ["v", version]
					})]
				})]
			}),
			isHosted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeleteAccountSettings, {}) : null
		]
	});
}
function EveryAppSettings() {
	const { data: account } = useQuery(everyAppAccountQueryOptions());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "space-y-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHeader, { title: "Every App" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "Your account, teammates and AI connections are managed on Every App."
			}),
			account?.gatewayUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: account.gatewayUrl,
				className: "inline-block text-sm font-medium text-primary underline-offset-4 hover:underline",
				children: "Open Every App \u2192"
			}) : null
		]
	});
}
//#endregion
export { PersonalSettings as component };
