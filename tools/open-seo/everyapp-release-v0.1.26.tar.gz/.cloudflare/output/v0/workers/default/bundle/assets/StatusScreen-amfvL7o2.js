import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as cn } from "./dist-fVOGIv0D.js";
import { n as Spinner } from "./Spinner-NR-t-8YM.js";
//#region src/client/components/StatusScreen.tsx
var import_jsx_runtime = require_jsx_runtime();
var WIDTHS = {
	sm: "max-w-xs",
	md: "max-w-lg",
	lg: "max-w-3xl"
};
/**
* A state that fills the page: a spinner while the app finalizes or
* redirects, a failure, or a gate. It centers its content and scrolls when
* the content is taller than the page.
*/
function StatusScreen({ logo = false, title, description, pending = false, children, footer, size = "md" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex h-full w-full flex-col items-center overflow-y-auto p-4 md:p-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: cn("m-auto flex w-full flex-col items-center gap-4", WIDTHS[size]),
			children: [
				logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/transparent-logo.png",
					alt: "OpenSEO",
					className: "size-10 rounded-lg"
				}) : null,
				title ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-center text-xl font-semibold",
					children: title
				}) : null,
				pending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {}) : null,
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-center text-sm text-muted-foreground",
					children: description
				}) : null,
				children,
				footer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-center text-xs text-muted-foreground",
					children: footer
				}) : null
			]
		})
	});
}
//#endregion
export { StatusScreen as t };
