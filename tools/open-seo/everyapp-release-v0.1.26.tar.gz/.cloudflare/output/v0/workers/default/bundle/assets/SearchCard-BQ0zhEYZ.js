import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as cn } from "./dist-fVOGIv0D.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as Search } from "./search-8b-KxN4Z.js";
import { r as CardContent, t as Card } from "./card-CqQO-5bL.js";
import { i as InputGroupInput, n as InputGroupAddon, t as InputGroup } from "./input-group-CmFmGa25.js";
//#region src/client/components/SearchCard.tsx
var import_jsx_runtime = require_jsx_runtime();
/**
* The search form at the top of a research page: the fields in one row, the
* submit button at the end, the validation error below.
*/
function SearchCard({ onSubmit, pending = false, error, errorId, children, secondRow }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			noValidate: true,
			className: "space-y-3",
			onSubmit,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 lg:flex-row lg:items-center",
				children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					className: "px-6",
					pending,
					children: "Search"
				})]
			}), secondRow]
		}), error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			id: errorId,
			role: "alert",
			className: "text-sm text-destructive",
			children: error
		}) : null]
	}) });
}
/** The text input with a search icon that leads a SearchCard row. */
function SearchInput({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(InputGroup, {
		className: cn("lg:min-w-0 lg:flex-1", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupAddon, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InputGroupInput, { ...props })]
	});
}
//#endregion
export { SearchInput as n, SearchCard as t };
