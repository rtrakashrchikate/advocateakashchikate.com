import { B as AUTUMN_TRACK_RETRY_OPTIONS, N as creditsForProviderUsd, R as captureServerEvent, U as AppError, V as autumn, _ as AUTUMN_SEO_DATA_BALANCE_FEATURE_ID, k as applyBillingMarkupUsd, m as AUTUMN_PAID_PLAN_FEATURE_ID, n as sendCreditsExhaustedEvent, y as AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID } from "./onboarding-drip-B7bIbv_6.js";
import { env } from "cloudflare:workers";
//#region src/server/billing/subscription.ts
var CUSTOMER_ENSURED_TTL_SECONDS = 86400;
var customerEnsuredKey = (organizationId) => `autumn:customer-ensured:${organizationId}`;
async function getOrCreateOrganizationCustomer(context) {
	const cacheKey = customerEnsuredKey(context.organizationId);
	try {
		if (await env.KV.get(cacheKey)) return { id: context.organizationId };
	} catch (error) {
		console.warn("billing.customer-cache-read failed:", error);
	}
	const customer = await autumn.customers.getOrCreate({
		customerId: context.organizationId,
		email: context.userEmail
	});
	if (!customer.id) throw new AppError("INTERNAL_ERROR", "Failed to resolve billing customer");
	try {
		await env.KV.put(cacheKey, "1", { expirationTtl: CUSTOMER_ENSURED_TTL_SECONDS });
	} catch (error) {
		console.warn("billing.customer-cache-write failed:", error);
	}
	return { id: customer.id };
}
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
async function customerHasPaidPlan(customerId, opts = {}) {
	let result;
	try {
		result = await autumn.check({
			customerId,
			featureId: AUTUMN_PAID_PLAN_FEATURE_ID
		});
	} catch (error) {
		if (errorBodyIncludes(error, "customer_not_found")) return false;
		throw error;
	}
	if (result.allowed || !opts.retryDenied) return result.allowed;
	await sleep(300);
	return (await autumn.check({
		customerId,
		featureId: AUTUMN_PAID_PLAN_FEATURE_ID
	})).allowed;
}
async function getUsageCreditsRemaining(customerId) {
	const [monthlyCheck, topupCheck] = await Promise.all([autumn.check({
		customerId,
		featureId: AUTUMN_SEO_DATA_BALANCE_FEATURE_ID
	}), autumn.check({
		customerId,
		featureId: AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID
	})]);
	let monthlyBalance = monthlyCheck.balance;
	if (!monthlyBalance) {
		await sleep(300);
		monthlyBalance = (await autumn.check({
			customerId,
			featureId: AUTUMN_SEO_DATA_BALANCE_FEATURE_ID
		})).balance;
	}
	if (!monthlyBalance) throw new AppError("INTERNAL_ERROR", `Autumn check returned no ${AUTUMN_SEO_DATA_BALANCE_FEATURE_ID} balance for customer ${customerId}`);
	if (topupCheck.allowed && !topupCheck.balance) throw new AppError("INTERNAL_ERROR", `Autumn check returned no ${AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID} balance for customer ${customerId}`);
	const topupBudgetReached = !topupCheck.allowed && (topupCheck.balance?.remaining ?? 0) > 0;
	return {
		monthlyRemaining: monthlyBalance.remaining,
		topupRemaining: topupBudgetReached ? 0 : topupCheck.balance?.remaining ?? 0,
		topupBudgetReached
	};
}
/**
* Depletion check for the chat-agent gates. A /check reading \u2264 0 is not
* trusted on its own: Autumn has served a stale balance transiently
* (2026-07-20, minutes after a customer's free\u2192paid upgrade), and a false
* refusal locks the customer out of chat. When the check reads depleted,
* confirm against the full customer object \u2014 a separate Autumn read path \u2014
* and refuse only when both agree. A disagreement means Autumn served
* inconsistent balances: the turn proceeds on the confirmed reading and the
* inconsistency is logged at error level so it lands in Workers error
* tracking, not buried in analytics. Confirmed refusals emit a PostHog event (paywall
* analytics \u2014 refusals used to be invisible everywhere).
*/
async function checkUsageCreditsDepleted(customer) {
	const check = await getUsageCreditsRemaining(customer.organizationId);
	const notDepleted = {
		depleted: false,
		monthlyRemaining: check.monthlyRemaining,
		topupRemaining: check.topupRemaining,
		budgetReached: false
	};
	if (check.monthlyRemaining + check.topupRemaining > 0) return notDepleted;
	if (check.topupBudgetReached) {
		await captureServerEvent({
			distinctId: customer.userId,
			event: "usage:credits_gate_refused",
			organizationId: customer.organizationId,
			properties: {
				project_id: customer.projectId,
				reason: "monthly_budget_reached",
				monthly_remaining: check.monthlyRemaining
			}
		});
		return {
			...notDepleted,
			depleted: true,
			budgetReached: true
		};
	}
	const full = await autumn.customers.getOrCreate({
		customerId: customer.organizationId,
		email: customer.userEmail
	});
	const confirmed = {
		monthlyRemaining: full.balances["usage_credits"]?.remaining ?? 0,
		topupRemaining: full.balances["topup_credits"]?.remaining ?? 0
	};
	if (confirmed.monthlyRemaining + confirmed.topupRemaining > 0) {
		console.error("billing.credits-gate disagreement: /check read depleted but the customer object shows credits; proceeding on the customer reading", {
			organizationId: customer.organizationId,
			check,
			confirmed
		});
		return {
			...notDepleted,
			...confirmed
		};
	}
	await captureServerEvent({
		distinctId: customer.userId,
		event: "usage:credits_gate_refused",
		organizationId: customer.organizationId,
		properties: {
			project_id: customer.projectId,
			monthly_remaining: confirmed.monthlyRemaining,
			topup_remaining: confirmed.topupRemaining
		}
	});
	await sendCreditsExhaustedEvent(customer);
	return {
		...notDepleted,
		depleted: true
	};
}
var HOLD_TTL_MS = 18e5;
/**
* Atomically holds `credits` on one balance feature. Autumn refuses the hold
* (allowed: false) when the balance is short, so concurrent calls cannot all
* pass on the same reading the way a plain balance check lets them.
*
* The SDK fails open on a failed request (timeout, 5xx) with `allowed: true,
* balance: null`, including one Autumn actually processed; that is a broken
* read, not a wallet, so retry it once and then fail closed. The retry reuses
* the lockId: a 409 `lock_already_exists` means the first hold landed (a
* refusal creates no lock), so the call proceeds on it instead of stranding a
* second hold for HOLD_TTL_MS. The SDK's own 5xx retry is off
* (AUTUMN_TRACK_RETRY_OPTIONS): it would replay a lock Autumn already took
* and throw that 409 from the first attempt, where nothing catches it. An
* absent feature reads `allowed: false, balance: null` and is a genuine
* refusal.
*/
async function holdCredits(args) {
	const { customerId, featureId, estimatedCredits, callIndexes, properties, ttlMs = HOLD_TTL_MS, lockPrefix = "dfs" } = args;
	const lockId = `${lockPrefix}_${customerId}_${crypto.randomUUID()}`;
	const hold = {
		lockId,
		featureId,
		estimatedCredits,
		callIndexes
	};
	const attempt = () => autumn.check({
		customerId,
		featureId,
		requiredBalance: estimatedCredits,
		sendEvent: true,
		properties,
		lock: {
			lockId,
			enabled: true,
			expiresAt: Date.now() + ttlMs
		}
	}, AUTUMN_TRACK_RETRY_OPTIONS);
	let result = await attempt();
	if (result.allowed && !result.balance) {
		await sleep(300);
		try {
			result = await attempt();
		} catch (error) {
			if (!errorBodyIncludes(error, "lock_already_exists")) throw error;
			return {
				hold,
				allowed: true,
				balance: null
			};
		}
	}
	if (result.allowed && !result.balance) throw new AppError("INTERNAL_ERROR", `Autumn check returned no ${featureId} balance for customer ${customerId}`);
	return {
		hold,
		allowed: result.allowed,
		balance: result.balance
	};
}
var TASK_HOLD_CREDITS = 25;
/**
* Holds credits for one research task or SAM turn that
* `checkUsageCreditsDepleted` admitted, so a burst of them can't all start on
* the same balance: the reading that admitted each one is the same until
* their spend is billed. The hold is at most the pool's balance, so any
* positive balance still admits one task, however small, but Autumn refuses a
* hold once the balance is held by others. Returns null when refused.
* Release the hold with `releaseTaskCredits` once the work is billed.
*/
async function holdTaskCredits(customer, balance) {
	const onMonthly = balance.monthlyRemaining > 0;
	const { hold, allowed } = await holdCredits({
		customerId: customer.organizationId,
		featureId: onMonthly ? AUTUMN_SEO_DATA_BALANCE_FEATURE_ID : AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID,
		estimatedCredits: Math.min(TASK_HOLD_CREDITS, onMonthly ? balance.monthlyRemaining : balance.topupRemaining),
		callIndexes: [],
		properties: {
			projectId: customer.projectId,
			purpose: "task_admission"
		},
		lockPrefix: "task"
	});
	return allowed ? hold : null;
}
/** Releases a `holdTaskCredits` hold. Never throws: an unreleased hold
*  expires on its own at the hold TTL. */
async function releaseTaskCredits(customer, hold) {
	const { landed, error } = await finalizeHold(hold, 0, {
		projectId: customer.projectId,
		purpose: "task_admission"
	});
	if (!landed) console.error("[autumn] task hold release failed", {
		organizationId: customer.organizationId,
		lockId: hold.lockId,
		error
	});
}
/**
* Reserves credits for a batch of provider calls before they are made, from
* one estimate per call, and places each call where a hold of its own would
* land: in order, on monthly `usage_credits` while they cover it, else on
* `topup_credits`, else the call is refused. At most one hold per pool, so
* the common case (monthly covers the batch) is a single Autumn request.
*
* Throws INSUFFICIENT_CREDITS when no call fits; `refusedCalls` lists the
* ones that did not when some did. Either way the refusal event and the
* credits-exhausted email event are sent. A top-up balance that covers the
* estimate and still refuses is the organization's monthly auto-reload
* budget (Autumn's usage limit): the error says so, as nothing but raising
* it or the next cycle helps.
* The caller must settle every returned hold with `settleUsageCredits` once
* its calls' real cost is known.
*/
async function reserveUsageCredits(args) {
	const callCredits = args.callCredits.map((credits) => Math.max(1, credits));
	const allCalls = callCredits.map((_, index) => index);
	const creditsFor = (calls) => calls.reduce((sum, index) => sum + callCredits[index], 0);
	const properties = {
		creditFeature: args.creditFeature,
		projectId: args.customer.projectId,
		provider: "dataforseo",
		estimatedCredits: creditsFor(allCalls)
	};
	const holdFitting = async (featureId, calls, remaining = Infinity) => {
		const fitting = [];
		let credits = 0;
		for (const index of calls) {
			if (credits + callCredits[index] > remaining) continue;
			fitting.push(index);
			credits += callCredits[index];
		}
		if (fitting.length === 0) return null;
		return holdCredits({
			customerId: args.customerId,
			featureId,
			estimatedCredits: credits,
			callIndexes: fitting,
			properties,
			ttlMs: args.ttlMs
		});
	};
	const holds = [];
	let monthlyRemaining = 0;
	let topupRemaining = 0;
	let budgetReached = false;
	let refusedCalls = [];
	try {
		const monthly = await holdFitting(AUTUMN_SEO_DATA_BALANCE_FEATURE_ID, allCalls);
		if (monthly?.allowed) return {
			holds: [monthly.hold],
			refusedCalls
		};
		monthlyRemaining = monthly?.balance?.remaining ?? 0;
		const partial = await holdFitting(AUTUMN_SEO_DATA_BALANCE_FEATURE_ID, allCalls, monthlyRemaining);
		if (partial?.allowed) holds.push(partial.hold);
		const topupCalls = allCalls.filter((index) => !holds.some((hold) => hold.callIndexes.includes(index)));
		let topup = await holdFitting(AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID, topupCalls);
		if (topup && !topup.allowed) {
			topupRemaining = topup.balance?.remaining ?? 0;
			budgetReached = topupRemaining >= creditsFor(topupCalls);
			if (!budgetReached) {
				topup = await holdFitting(AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID, topupCalls, topupRemaining);
				if (topup && !topup.allowed) budgetReached = (topup.balance?.remaining ?? 0) >= topup.hold.estimatedCredits;
			}
		}
		if (topup?.allowed) holds.push(topup.hold);
		refusedCalls = allCalls.filter((index) => !holds.some((hold) => hold.callIndexes.includes(index)));
	} catch (error) {
		for (const hold of holds) await settleUsageCredits({
			customer: args.customer,
			hold,
			costs: []
		});
		throw error;
	}
	if (refusedCalls.length > 0) {
		await captureServerEvent({
			distinctId: args.customer.userId,
			event: "usage:credits_gate_refused",
			organizationId: args.customer.organizationId,
			properties: {
				project_id: args.customer.projectId,
				reason: budgetReached ? "monthly_budget_reached" : "estimate_exceeds_balance",
				source: "dataforseo",
				credit_feature: args.creditFeature,
				estimated_credits: creditsFor(refusedCalls),
				monthly_remaining: monthlyRemaining,
				topup_remaining: topupRemaining
			}
		});
		if (!budgetReached) await sendCreditsExhaustedEvent(args.customer);
	}
	if (holds.length === 0) throw new AppError("INSUFFICIENT_CREDITS", budgetReached ? "The organization has hit its monthly auto-reload budget, so its top-up credits are paused until the owner raises it or the billing cycle resets." : void 0);
	return {
		holds,
		refusedCalls
	};
}
function errorBodyIncludes(error, text) {
	return error instanceof Error && "body" in error && typeof error.body === "string" && error.body.includes(text);
}
/**
* Confirms `credits` against a hold (Autumn deducts that amount, above or
* below the hold, and returns the rest), or releases the hold when `credits`
* is 0. Retries once. `landed: false` means the deduction may be lost; the
* hold then expires at its TTL.
*/
async function finalizeHold(hold, credits, properties) {
	const finalize = () => autumn.balances.finalize({
		lockId: hold.lockId,
		...credits > 0 ? {
			action: "confirm",
			overrideValue: credits
		} : { action: "release" },
		properties
	}, AUTUMN_TRACK_RETRY_OPTIONS);
	let lastError;
	for (const attempt of [1, 2]) {
		if (attempt === 2) await sleep(250);
		try {
			if ((await finalize()).success) return { landed: true };
		} catch (error) {
			lastError = error;
			if (errorBodyIncludes(error, "Lock not found")) return attempt === 2 ? { landed: true } : {
				landed: false,
				error
			};
		}
	}
	return {
		landed: false,
		error: lastError
	};
}
/**
* Settles a hold on the provider's real cost: confirms the deduction at the
* actual credits (Autumn deducts the override, above or below the hold, and
* returns the rest) or releases the hold when nothing was billed. A hold can
* cover several provider calls; each is credited separately, so a batch is
* charged exactly what the same calls would cost one by one. Never
* throws: the customer already has the data, so a finalize that still fails
* after one retry is logged with everything needed to reconcile it and the
* hold expires at its TTL.
*/
async function settleUsageCredits(args) {
	const { customer, hold, creditFeature, costs } = args;
	let actualCredits = 0;
	let totalCostUsd = 0;
	for (const cost of costs) {
		actualCredits += creditsForProviderUsd(cost.costUsd);
		totalCostUsd += applyBillingMarkupUsd(cost.costUsd);
	}
	const paths = [...new Set(costs.map((cost) => cost.path.join("/")))];
	const { landed, error } = await finalizeHold(hold, actualCredits, {
		creditFeature,
		projectId: customer.projectId,
		provider: "dataforseo",
		paths,
		totalCostUsd,
		estimatedCredits: hold.estimatedCredits
	});
	if (!landed) {
		console.error("[autumn] finalize failed", {
			organizationId: customer.organizationId,
			lockId: hold.lockId,
			held: hold.estimatedCredits,
			actual: actualCredits,
			error
		});
		return;
	}
	if (actualCredits <= 0) return;
	const onMonthly = hold.featureId === AUTUMN_SEO_DATA_BALANCE_FEATURE_ID;
	await captureCreditsConsumed(customer, {
		credit_feature: creditFeature,
		monthly_credits: onMonthly ? actualCredits : 0,
		topup_credits: onMonthly ? 0 : actualCredits,
		total_credits: actualCredits,
		cost_usd: totalCostUsd,
		estimated_credits: hold.estimatedCredits,
		paths
	});
	if (actualCredits > hold.estimatedCredits) console.error("[billing] estimate undershoot", {
		paths,
		estimated: hold.estimatedCredits,
		actual: actualCredits
	});
}
function captureCreditsConsumed(customer, properties) {
	return captureServerEvent({
		distinctId: customer.userId,
		event: "usage:credits_consume",
		organizationId: customer.organizationId,
		properties: {
			project_id: customer.projectId,
			...properties
		}
	});
}
/**
* Deducts a USD provider cost from the org's shared usage-credit pool after
* the fact: applies the platform markup, converts to credits, spends monthly
* `usage_credits` first then `topup_credits`, and emits the
* usage:credits_consume event. LLM research uses this (token cost is
* unknowable up front); DataForSEO calls reserve-then-settle instead. Pass
* `monthlyRemaining` from the balance check that gated the call.
*/
async function trackUsageCreditSpend(args) {
	const totalCostUsd = applyBillingMarkupUsd(args.costUsd);
	const totalCostCredits = creditsForProviderUsd(args.costUsd);
	if (totalCostCredits <= 0) return {
		monthlyCredits: 0,
		topupCredits: 0
	};
	let monthlyDeduct = Math.min(Math.max(args.monthlyRemaining, 0), totalCostCredits);
	let topupDeduct = totalCostCredits - monthlyDeduct;
	if (args.overdraft) {
		topupDeduct = Math.min(topupDeduct, Math.max(args.overdraft.topupRemaining, 0));
		monthlyDeduct = totalCostCredits - topupDeduct;
	}
	const properties = {
		currency: "USD",
		creditFeature: args.creditFeature,
		projectId: args.customer.projectId,
		totalCostUsd,
		totalCostCredits,
		...args.properties
	};
	if (monthlyDeduct > 0) await autumn.track({
		customerId: args.customerId,
		featureId: AUTUMN_SEO_DATA_BALANCE_FEATURE_ID,
		value: monthlyDeduct,
		overageBehavior: args.overdraft ? "overflow" : void 0,
		properties: {
			...properties,
			balanceFeatureId: AUTUMN_SEO_DATA_BALANCE_FEATURE_ID
		}
	}, AUTUMN_TRACK_RETRY_OPTIONS);
	if (topupDeduct > 0) await autumn.track({
		customerId: args.customerId,
		featureId: AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID,
		value: topupDeduct,
		overageBehavior: args.overdraft ? "overflow" : void 0,
		properties: {
			...properties,
			balanceFeatureId: AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID
		}
	}, AUTUMN_TRACK_RETRY_OPTIONS);
	await captureCreditsConsumed(args.customer, {
		credit_feature: args.creditFeature,
		monthly_credits: monthlyDeduct,
		topup_credits: topupDeduct,
		total_credits: totalCostCredits,
		cost_usd: totalCostUsd
	});
	return {
		monthlyCredits: monthlyDeduct,
		topupCredits: topupDeduct
	};
}
//#endregion
export { getUsageCreditsRemaining as a, releaseTaskCredits as c, trackUsageCreditSpend as d, getOrCreateOrganizationCustomer as i, reserveUsageCredits as l, customerHasPaidPlan as n, holdCredits as o, finalizeHold as r, holdTaskCredits as s, checkUsageCreditsDepleted as t, settleUsageCredits as u };
