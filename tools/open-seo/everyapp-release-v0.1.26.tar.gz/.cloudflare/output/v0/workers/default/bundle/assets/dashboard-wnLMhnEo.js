import { Et as _enum, Fn as object, Jn as string, Lt as boolean } from "./schemas-BPIpYT5n.js";
//#region src/types/schemas/dashboard.ts
var dashboardProjectInputSchema = object({ projectId: string().min(1) });
var dashboardSetupStepSchema = _enum([
	"competitor",
	"keywords",
	"audit",
	"mcp",
	"team",
	"project"
]);
var dashboardStepDismissalSchema = dashboardProjectInputSchema.extend({
	step: dashboardSetupStepSchema,
	dismissed: boolean()
});
var dashboardSiteTabSchema = _enum([
	"overview",
	"keywords",
	"backlinks"
]);
var dashboardSearchSchema = object({ tab: dashboardSiteTabSchema.optional().catch(void 0) });
var dashboardBacklinksInputSchema = dashboardProjectInputSchema.extend({ kind: _enum([
	"new",
	"lost",
	"all"
]).default("new") });
//#endregion
export { dashboardStepDismissalSchema as a, dashboardSiteTabSchema as i, dashboardProjectInputSchema as n, dashboardSearchSchema as r, dashboardBacklinksInputSchema as t };
