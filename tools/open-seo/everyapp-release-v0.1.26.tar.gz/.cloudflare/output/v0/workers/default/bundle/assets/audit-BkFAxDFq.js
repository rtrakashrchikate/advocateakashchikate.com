import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as Link } from "./link-DGsnxXRN.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as useNavigate } from "./useNavigate-DrGAfT1Z.js";
import { O as SUBSCRIBE_ROUTE } from "./onboarding-drip-B7bIbv_6.js";
import { c as isHostedClientAuthMode, o as isEveryAppClientAuthMode } from "./auth-mode-DhGCw2Bx.js";
import { t } from "./sort-CLx_CHCb.js";
import { t as PAID_MAX_AUDIT_PAGES } from "./audit-limits-CeWL1lsV.js";
import { n as ISSUE_SEVERITY_ORDER, r as getIssueDescriptor } from "./audit-issues-CVAgBn_i.js";
import { i as isCrawlerAccessExpired, n as SHOPIFY_CRAWLER_ACCESS_DOC_URL } from "./crawler-access-fzg5Zt85.js";
import { a as renderingCostText, i as RENDERING_COST_NOTE, o as renderingCreditsNeededText, s as renderingEstimateText } from "./audit-rendering-DCHsGIuV.js";
import { j as useQueryClient, t as useQuery, x as keepPreviousData } from "./useQuery-B93OR2NQ.js";
import { _ as CircleAlert, c as Skeleton, g as EmptyState, i as SkeletonPage, n as QueryState, t as QueryError, u as InsufficientCreditsError } from "./QueryState-Q8BZIblk.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { t as useIsMutating } from "./useMutationState-DSh7j4rI.js";
import { n as getErrorCode, r as getStandardErrorMessage } from "./error-messages-D7nntGF_.js";
import { n as createLucideIcon } from "./dist-fVOGIv0D.js";
import { t as SortableHeader } from "./SortableHeader-DDZ6s-pV.js";
import { t as ChevronRight } from "./chevron-right-CMQSolKd.js";
import { _ as getAuditStatus, a as SeverityBadge, b as startAudit, c as extractPathname, d as scoreTone, f as useAuditCapabilities, g as getAuditPages, h as getAuditIssues, i as SCORE_TEXT_CLASS, l as formatDate, m as getAuditHistory, n as HttpStatusBadge, o as StatusBadge, p as deleteAudit, r as LighthouseScoreBadge, s as extractHostname, t as BotProtectionAdvice, u as formatStartedAt, v as getAuditSummary, y as getCrawlProgress } from "./shared-CP2Dudon.js";
import { t as ExternalLink } from "./external-link-HZIbqzY5.js";
import { t as ExportMenu } from "./ExportMenu-j2MeLhMC.js";
import { r as Spinner, t as Button } from "./button-DrcZrdio.js";
import { t as ScanSearch } from "./scan-search-BaVGvMBP.js";
import { t as ShieldAlert } from "./shield-alert-C6TCVoOy.js";
import { t as Trash2 } from "./trash-2-B7Pu83CI.js";
import { i as AlertTitle, r as AlertDescription, t as Alert } from "./alert-wNGd5VPQ.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { n as CardAction, o as CardHeader, r as CardContent, s as CardTitle, t as Card } from "./card-CqQO-5bL.js";
import { t as Badge } from "./badge-B9fV075d.js";
import { n as ProgressLabel, r as ProgressValue, t as Progress } from "./progress-DlqV_aCw.js";
import { t as Input } from "./input-B1cALAbz.js";
import { i as TabsTrigger } from "./tabs-Dm1Fimx3.js";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-KTe7DEy8.js";
import { a as DataTableTabs, i as DataTableRangeFilter, n as DataTableFilterPanel, o as DataTableToolbar, r as DataTableFilterToggle, t as DataTableFilterGroup } from "./DataTableToolbar-H0nNW-WC.js";
import { n as auditPagesSortFields, t as AUDIT_ROWS_MAX_PAGE_SIZE } from "./audit-BJwJwQG7.js";
import { t as Route } from "./audit-BuWrekQ1.js";
import { r as PageHeader, t as BackButton } from "./PageHeader-a3_4WaC8.js";
import { a as FieldLabel, i as FieldError, r as FieldDescription, t as Field } from "./field-CjRT_5Cr.js";
import "./support-jwdBlqyi.js";
import { a as TableHead, i as TableCell, n as TableBody, o as TableHeader, r as TableCard, s as TableRow, t as Table } from "./table-CqwvrC02.js";
import { t as Switch } from "./switch-BumBbmWp.js";
import { t as ConfirmDialog } from "./ConfirmDialog-CI0zpKxJ.js";
import { i as DropdownMenuItem } from "./dropdown-menu-DubRfxrI.js";
import { o as createColumnHelper, r as useDataTable, t as DataTable } from "./DataTable-CF1_e923.js";
import { t as TablePagination } from "./TablePagination-B6c_he8X.js";
import { t as useForm } from "./useForm-B2StPr3w.js";
import { t as useStore } from "./useStore-C_jD9-ce.js";
import { i as shouldValidateFieldOnChange, n as getFieldError, r as getFormError, t as createFormValidationErrors } from "./forms-t3Wjw9fZ.js";
import { t as MetricsTable } from "./MetricsTable-DmC294OB.js";
import { t as RowActionsMenu } from "./RowActionsMenu-zl2TiODR.js";
import { t as useHostedPlanGate } from "./HostedPlanGate-DjbmgzY5.js";
import { t as exportRows } from "./exportRows-CUVUVoFx.js";
import { t as useDebouncedDraft } from "./useDebouncedDraft-Ixxzt3-2.js";
import { a as useCrawlerAccessNeedsSetup, i as saveCrawlerCredentialMutationKey, n as CrawlerAccessSetupHint, r as crawlerCredentialsQueryKey, s as listCrawlerCredentials, t as CrawlerAccessForm } from "./CrawlerAccessForm-CU5xY_Qk.js";
import { n as stringNullsLast, t as numericNullsLast } from "./nullSafeSort-JPSearDD.js";
/**
* @license lucide-react v0.542.0 - ISC
*
* This source code is licensed under the ISC license.
* See the LICENSE file in the root directory of this source tree.
*/
var ShieldCheck = createLucideIcon("shield-check", [["path", {
	d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
	key: "oel41y"
}], ["path", {
	d: "m9 12 2 2 4-4",
	key: "dzmm74"
}]]);
//#endregion
//#region src/client/features/audit/launch/AuditHistorySection.tsx
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
function AuditHistorySection({ projectId, historyQuery, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
		query: historyQuery,
		errorFallback: "Failed to load audit history",
		children: (history) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditHistoryTable, {
			projectId,
			history,
			onDelete
		})
	});
}
function AuditHistoryTable({ projectId, history, onDelete }) {
	if (history.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
		icon: ScanSearch,
		title: "No audits yet"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableCard, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableToolbar, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: "text-sm font-semibold",
		children: "Previous Audits"
	}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Table, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Date" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "URL" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Status" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Pages" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, { children: "Lighthouse" }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableHead, {})
	] }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableBody, { children: history.map((audit) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRow, {
		className: "group",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "text-xs text-muted-foreground",
				children: formatDate(audit.startedAt)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, {
				className: "max-w-[220px] truncate",
				children: audit.startUrl
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: audit.status }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: audit.pagesTotal || audit.pagesCrawled }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: audit.ranLighthouse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "outline",
				size: "sm",
				children: "Yes"
			}) : null }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableCell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HistoryActions, {
				projectId,
				auditId: audit.id,
				onDelete
			}) })
		]
	}, audit.id)) })] })] });
}
function HistoryActions({ projectId, auditId, onDelete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-end gap-2 reveal-on-hover",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "xs",
			nativeButton: false,
			render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/p/$projectId/audit",
				params: { projectId },
				search: {
					auditId,
					tab: "pages"
				}
			}),
			children: "View"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RowActionsMenu, {
			label: "Audit actions",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
				variant: "destructive",
				onClick: () => onDelete(auditId),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Delete audit"]
			})
		})]
	});
}
//#endregion
//#region src/client/features/audit/launch/types.ts
var MIN_PAGES = 10;
function getMaxPagesLimit(isFreePlan) {
	return isFreePlan ? 50 : PAID_MAX_AUDIT_PAGES;
}
/** The page limit an audit runs with for what is typed in the form. */
function clampMaxPagesInput(input, maxPagesLimit) {
	const value = input ? Number.parseInt(input, 10) : MIN_PAGES;
	return Number.isFinite(value) ? Math.max(MIN_PAGES, Math.min(maxPagesLimit, Math.round(value))) : MIN_PAGES;
}
var DEFAULT_LAUNCH_FORM_VALUES = {
	url: "",
	maxPagesInput: String(50),
	runLighthouse: false,
	renderJavaScript: false
};
//#endregion
//#region src/client/features/audit/launch/LaunchFormCard.tsx
function LaunchFormCard({ commitMaxPagesInput, launchForm, maxPagesLimit, canRenderJavaScript, outOfCredits }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Start New Audit" }) }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid grid-cols-1 gap-3 lg:grid-cols-12 lg:items-center",
			onSubmit: (event) => {
				event.preventDefault();
				launchForm.handleSubmit();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(launchForm.Field, {
					name: "url",
					children: (field) => {
						const urlError = getFieldError(field.state.meta.errors);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							className: "lg:col-span-9",
							"aria-label": "Site URL",
							"aria-invalid": urlError ? true : void 0,
							placeholder: "https://example.com",
							value: field.state.value,
							onBlur: field.handleBlur,
							onChange: (event) => {
								field.handleChange(event.target.value);
								if (launchForm.state.errorMap.onSubmit) launchForm.setErrorMap({ onSubmit: void 0 });
							}
						});
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(launchForm.Subscribe, {
					selector: (state) => state.isSubmitting,
					children: (isSubmitting) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						className: "w-full lg:col-span-3",
						pending: isSubmitting,
						children: isSubmitting ? "Starting..." : "Start Audit"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid w-full grid-cols-1 gap-4 md:grid-cols-2 lg:col-span-12 lg:items-start",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LaunchOptions, {
						launchForm,
						commitMaxPagesInput,
						maxPagesLimit
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LighthouseOptions, { launchForm }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RenderingOptions, {
							launchForm,
							maxPagesLimit,
							canRenderJavaScript
						})]
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LaunchErrors, {
			launchForm,
			outOfCredits
		})]
	})] });
}
function LaunchOptions({ launchForm, commitMaxPagesInput, maxPagesLimit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
		className: "rounded-lg border border-border p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
				htmlFor: "audit-max-pages",
				children: "Max pages"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(launchForm.Field, {
				name: "maxPagesInput",
				children: (field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id: "audit-max-pages",
					type: "number",
					min: MIN_PAGES,
					max: maxPagesLimit,
					className: "w-28",
					value: field.state.value,
					onChange: (event) => {
						const next = event.target.value;
						if (!/^\d*$/.test(next)) return;
						field.handleChange(next);
						if (launchForm.state.errorMap.onSubmit) launchForm.setErrorMap({ onSubmit: void 0 });
					},
					onBlur: commitMaxPagesInput
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldDescription, { children: [
				"Enter any value from ",
				MIN_PAGES,
				" to ",
				maxPagesLimit.toLocaleString(),
				".",
				maxPagesLimit < 1e4 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: SUBSCRIBE_ROUTE,
						search: { upgrade: true },
						children: "Upgrade"
					}),
					" ",
					"to crawl up to ",
					PAID_MAX_AUDIT_PAGES.toLocaleString(),
					" pages."
				] }) : null
			] })
		]
	});
}
function LighthouseOptions({ launchForm }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
		className: "rounded-lg border border-border p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(launchForm.Field, {
				name: "runLighthouse",
				children: (field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					id: "audit-run-lighthouse",
					checked: Boolean(field.state.value),
					onCheckedChange: (checked) => field.handleChange(checked)
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
				htmlFor: "audit-run-lighthouse",
				title: "Lighthouse measures the performance of your pages and identifies issues.",
				children: "Include Lighthouse"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(launchForm.Subscribe, {
			selector: (snapshot) => snapshot.values.runLighthouse,
			children: (runLighthouse) => runLighthouse ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: "We choose a sample of 20 pages to audit, removing pages from duplicate templates." }) : null
		})]
	});
}
function RenderingOptions({ launchForm, maxPagesLimit, canRenderJavaScript }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
		className: "rounded-lg border border-border p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(launchForm.Field, {
					name: "renderJavaScript",
					children: (field) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
						id: "audit-render-javascript",
						checked: field.state.value,
						disabled: canRenderJavaScript !== true,
						onCheckedChange: (checked) => field.handleChange(checked)
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
					htmlFor: "audit-render-javascript",
					title: "Loads each page in a browser before auditing it. Slower.",
					children: "Render JavaScript"
				})]
			}),
			isHostedClientAuthMode() && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(launchForm.Subscribe, {
				selector: (state) => ({
					renderJavaScript: state.values.renderJavaScript,
					maxPagesInput: state.values.maxPagesInput
				}),
				children: ({ renderJavaScript, maxPagesInput }) => renderJavaScript ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, { children: renderingEstimateText(clampMaxPagesInput(maxPagesInput, maxPagesLimit)) }) : null
			}),
			canRenderJavaScript === false && isEveryAppClientAuthMode() && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldDescription, { children: [
				"JavaScript rendering isn't set up on your Every App gateway yet. An owner or admin sets it with",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "pnpm everyapp secret set CONTEXT_API_KEY" }),
				"."
			] }),
			canRenderJavaScript === false && !isEveryAppClientAuthMode() && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldDescription, { children: [
				"This deployment has no browser, so rendering needs a Context.dev API key. Set ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: "CONTEXT_API_KEY" }),
				", restart OpenSEO, then reload this page.",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://github.com/every-app/open-seo/blob/main/docs/SELF_HOSTING_CLOUDFLARE_OPERATIONS.md#render-javascript-in-site-audits",
					target: "_blank",
					rel: "noreferrer",
					children: "Setup guide"
				})
			] })
		]
	});
}
function LaunchErrors({ launchForm, outOfCredits }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(launchForm.Field, {
			name: "url",
			children: (field) => {
				const urlError = getFieldError(field.state.meta.errors);
				return urlError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { children: urlError }) : null;
			}
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(launchForm.Subscribe, {
			selector: (state) => state.errorMap.onSubmit,
			children: (submitError) => {
				const errorMessage = getFormError(submitError);
				if (errorMessage && outOfCredits) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InsufficientCreditsError, { title: errorMessage });
				return errorMessage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "destructive",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: errorMessage })]
				}) : null;
			}
		})]
	});
}
//#endregion
//#region src/client/features/audit/launch/useLaunchController.ts
function getLaunchValidationErrors(value, shouldValidateUntouchedField) {
	if (value.url.trim()) return null;
	if (!shouldValidateUntouchedField) return null;
	return createFormValidationErrors({ fields: { url: "Please enter a URL." } });
}
function useLaunchController({ projectId, initialUrl, isFreePlan, onAuditStarted }) {
	const capabilitiesQuery = useAuditCapabilities(projectId);
	const historyQuery = useQuery({
		queryKey: ["audit-history", projectId],
		queryFn: () => getAuditHistory({ data: { projectId } }),
		refetchInterval: (query) => query.state.data?.some((audit) => audit.status === "running") ? 5e3 : false
	});
	const { startMutation, deleteMutation } = useLaunchMutations({ projectId });
	const [largeCrawlPages, setLargeCrawlPages] = (0, import_react.useState)(null);
	const [outOfCredits, setOutOfCredits] = (0, import_react.useState)(false);
	const largeCrawlConfirmed = (0, import_react.useRef)(false);
	const launchForm = useForm({
		defaultValues: {
			...DEFAULT_LAUNCH_FORM_VALUES,
			url: initialUrl
		},
		validators: {
			onChange: ({ formApi, value }) => getLaunchValidationErrors(value, shouldValidateFieldOnChange(formApi, "url")),
			onSubmit: ({ value }) => getLaunchValidationErrors(value, true)
		},
		onSubmit: async ({ formApi, value }) => {
			const effectiveMaxPages = commitMaxPagesInput(launchForm, getMaxPagesLimit(isFreePlan));
			formApi.setErrorMap({ onSubmit: void 0 });
			if (effectiveMaxPages > 500 && !largeCrawlConfirmed.current) {
				setLargeCrawlPages(effectiveMaxPages);
				return;
			}
			largeCrawlConfirmed.current = false;
			try {
				const result = await startMutation.mutateAsync({
					projectId,
					startUrl: value.url,
					maxPages: effectiveMaxPages,
					lighthouseStrategy: value.runLighthouse ? "auto" : "none",
					renderJavaScript: value.renderJavaScript
				});
				toast.success("Audit started!");
				onAuditStarted(result.auditId);
			} catch (error) {
				const creditsShort = value.renderJavaScript && getErrorCode(error) === "INSUFFICIENT_CREDITS";
				setOutOfCredits(creditsShort);
				const message = creditsShort ? renderingCreditsNeededText(effectiveMaxPages) : getStandardErrorMessage(error, "Failed to start audit");
				formApi.setErrorMap({ onSubmit: createFormValidationErrors({ form: message }) });
			}
		}
	});
	const renderJavaScript = useStore(launchForm.store, (state) => state.values.renderJavaScript);
	const maxPagesLimit = getMaxPagesLimit(isFreePlan);
	return {
		launchForm,
		historyQuery,
		canRenderJavaScript: capabilitiesQuery.data?.canRenderJavaScript,
		maxPagesLimit,
		renderJavaScript,
		commitMaxPagesInput: () => commitMaxPagesInput(launchForm, maxPagesLimit),
		deleteAudit: (auditId) => deleteMutation.mutate(auditId),
		largeCrawlPages,
		outOfCredits,
		cancelLargeCrawl: () => setLargeCrawlPages(null),
		confirmLargeCrawl: () => {
			setLargeCrawlPages(null);
			largeCrawlConfirmed.current = true;
			launchForm.handleSubmit();
		}
	};
}
function useLaunchMutations({ projectId }) {
	const queryClient = useQueryClient();
	const invalidateHistory = () => queryClient.invalidateQueries({ queryKey: ["audit-history", projectId] });
	return {
		startMutation: useMutation({
			meta: { errorToast: false },
			mutationFn: (data) => startAudit({ data }),
			onSuccess: () => {
				invalidateHistory();
			}
		}),
		deleteMutation: useMutation({
			mutationFn: (auditId) => deleteAudit({ data: {
				projectId,
				auditId
			} }),
			onSuccess: () => {
				invalidateHistory();
				toast.success("Audit deleted");
			}
		})
	};
}
function commitMaxPagesInput(launchForm, maxPagesLimit) {
	const safeValue = clampMaxPagesInput(launchForm.state.values.maxPagesInput, maxPagesLimit);
	launchForm.setFieldValue("maxPagesInput", String(safeValue));
	return safeValue;
}
//#endregion
//#region src/client/features/audit/launch/LaunchView.tsx
function LaunchView({ projectId, initialUrl, onAuditStarted }) {
	const controller = useLaunchController({
		projectId,
		initialUrl,
		isFreePlan: useHostedPlanGate() === "free",
		onAuditStarted
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 py-4 md:px-6 md:py-6 pb-24 md:pb-8 overflow-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, { title: "Site Audit" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LaunchFormCard, {
					launchForm: controller.launchForm,
					commitMaxPagesInput: controller.commitMaxPagesInput,
					maxPagesLimit: controller.maxPagesLimit,
					canRenderJavaScript: controller.canRenderJavaScript,
					outOfCredits: controller.outOfCredits
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditHistorySection, {
					projectId,
					historyQuery: controller.historyQuery,
					onDelete: controller.deleteAudit
				}),
				controller.largeCrawlPages != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LargeCrawlDialog, {
					pages: controller.largeCrawlPages,
					renderJavaScript: controller.renderJavaScript,
					onConfirm: controller.confirmLargeCrawl,
					onClose: controller.cancelLargeCrawl
				}) : null
			]
		})
	});
}
function LargeCrawlDialog({ pages, renderJavaScript, onConfirm, onClose }) {
	const pageCount = pages.toLocaleString();
	const priced = renderJavaScript && isHostedClientAuthMode();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
		title: priced ? `Render up to ${pageCount} pages?` : "Start a large audit?",
		confirmLabel: priced ? "Start audit" : "Continue",
		onConfirm,
		onClose,
		children: priced ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			RENDERING_COST_NOTE,
			" Rendered audits can take longer than regular audits.",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-3 block font-semibold text-foreground",
				children: renderingCostText(pages)
			})
		] }) : `You are about to crawl ${pageCount} pages. This is okay, but it may take a while. Continue?`
	});
}
//#endregion
//#region src/client/features/audit/results/export.ts
/**
* Loads every row a page at a time. A large audit is too big for one Worker
* request, but small enough to assemble in the browser for a download.
*/
async function fetchAllRows(fetchPage) {
	const rows = [];
	for (let page = 1;; page += 1) {
		const batch = await fetchPage(page);
		rows.push(...batch);
		if (batch.length < 2e3) return rows;
	}
}
async function withExportToast(run) {
	const toastId = toast.loading("Preparing export\u2026");
	try {
		await run();
	} catch {
		toast.error("Could not export the audit results");
	} finally {
		toast.dismiss(toastId);
	}
}
var ISSUES_HEADERS = [
	"Severity",
	"Issue",
	"URL",
	"Details",
	"How To Fix"
];
function issuesRows(issues) {
	return issues.map((issue) => {
		const descriptor = getIssueDescriptor(issue.issueType);
		return [
			issue.severity,
			descriptor?.title ?? issue.issueType,
			issue.pageUrl,
			issue.detailsJson ?? "",
			descriptor?.howToFix ?? ""
		];
	});
}
function exportIssues(ref, format) {
	withExportToast(async () => {
		const issues = await fetchAllRows((page) => getAuditIssues({ data: {
			...ref,
			page,
			pageSize: AUDIT_ROWS_MAX_PAGE_SIZE
		} }));
		await exportRows({
			format,
			feature: "audit_issues",
			headers: ISSUES_HEADERS,
			rows: issuesRows(issues),
			filename: "audit-issues",
			records: format === "json" ? issues.map((issue) => {
				const descriptor = getIssueDescriptor(issue.issueType);
				return {
					severity: issue.severity,
					issueType: issue.issueType,
					issue: descriptor?.title ?? issue.issueType,
					url: issue.pageUrl,
					details: issue.detailsJson ? JSON.parse(issue.detailsJson) : null,
					howToFix: descriptor?.howToFix ?? null
				};
			}) : void 0
		});
	});
}
var PAGES_HEADERS = [
	"URL",
	"Status",
	"Title",
	"H1",
	"Words",
	"Images",
	"Missing Alt",
	"Response Time (ms)"
];
function pagesRows(pages) {
	return pages.map((page) => [
		page.url,
		page.statusCode,
		page.title ?? "",
		page.h1Count,
		page.wordCount,
		page.imagesTotal,
		page.imagesMissingAlt,
		page.responseTimeMs
	]);
}
function exportPages(ref, format) {
	withExportToast(async () => {
		const pages = await fetchAllRows(async (page) => {
			return (await getAuditPages({ data: {
				...ref,
				page,
				pageSize: AUDIT_ROWS_MAX_PAGE_SIZE
			} })).rows;
		});
		await exportRows({
			format,
			feature: "audit_pages",
			headers: PAGES_HEADERS,
			rows: pagesRows(pages),
			filename: "audit-pages",
			records: pages.map((page) => ({
				url: page.url,
				statusCode: page.statusCode,
				title: page.title ?? "",
				h1Count: page.h1Count,
				wordCount: page.wordCount,
				imagesTotal: page.imagesTotal,
				imagesMissingAlt: page.imagesMissingAlt,
				responseTimeMs: page.responseTimeMs
			}))
		});
	});
}
var PERFORMANCE_HEADERS = [
	"URL",
	"Device",
	"Performance",
	"Accessibility",
	"SEO",
	"LCP (ms)",
	"CLS",
	"INP (ms)",
	"TTFB (ms)"
];
function exportPerformance(lighthouse, format) {
	exportRows({
		format,
		feature: "audit_performance",
		headers: PERFORMANCE_HEADERS,
		rows: lighthouse.map((result) => [
			result.pageUrl ?? "",
			result.strategy,
			result.performanceScore,
			result.accessibilityScore,
			result.seoScore,
			result.lcpMs,
			result.cls,
			result.inpMs,
			result.ttfbMs
		]),
		filename: "audit-performance",
		records: lighthouse.map((result) => ({
			url: result.pageUrl ?? "",
			strategy: result.strategy,
			performance: result.performanceScore,
			accessibility: result.accessibilityScore,
			seo: result.seoScore,
			lcpMs: result.lcpMs,
			cls: result.cls,
			inpMs: result.inpMs,
			ttfbMs: result.ttfbMs
		}))
	});
}
//#endregion
//#region src/client/features/audit/results/AuditResultsTableFilterLogic.ts
var EMPTY_PAGES_FILTERS = {
	query: "",
	status: "all",
	fetchClass: "all",
	minWords: "",
	maxWords: "",
	minResponseMs: "",
	maxResponseMs: "",
	missingAlt: "all"
};
var EMPTY_PERFORMANCE_FILTERS = {
	query: "",
	device: "all",
	status: "all",
	minPerf: "",
	maxPerf: "",
	minSeo: "",
	maxSeo: "",
	maxLcpSeconds: ""
};
function hasMissingLighthouseScores(row) {
	return row.performanceScore == null && row.accessibilityScore == null && row.bestPracticesScore == null && row.seoScore == null;
}
function isLighthouseFailure(row) {
	return !!row.errorMessage || hasMissingLighthouseScores(row);
}
/** The pages filters as the server's query: blank bounds are left out. */
function toPagesQuery(filters) {
	return {
		query: filters.query.trim() || void 0,
		status: filters.status,
		fetchClass: filters.fetchClass,
		minWords: parseFilterNumber(filters.minWords),
		maxWords: parseFilterNumber(filters.maxWords),
		minResponseMs: parseFilterNumber(filters.minResponseMs),
		maxResponseMs: parseFilterNumber(filters.maxResponseMs),
		missingAlt: filters.missingAlt
	};
}
function filterPerformanceRows(rows, filters) {
	const query = filters.query.trim().toLowerCase();
	return rows.filter((row) => {
		if (query) {
			if (![row.pageUrl, row.pagePath].filter(Boolean).join(" ").toLowerCase().includes(query)) return false;
		}
		if (filters.device !== "all" && row.strategy !== filters.device) return false;
		if (filters.status === "ok" && isLighthouseFailure(row)) return false;
		if (filters.status === "failed" && !isLighthouseFailure(row)) return false;
		if (!matchesRange(row.performanceScore, filters.minPerf, filters.maxPerf)) return false;
		if (!matchesRange(row.seoScore, filters.minSeo, filters.maxSeo)) return false;
		const maxLcpSeconds = parseFilterNumber(filters.maxLcpSeconds);
		if (maxLcpSeconds != null && (row.lcpMs == null || row.lcpMs / 1e3 > maxLcpSeconds)) return false;
		return true;
	});
}
function matchesRange(value, minRaw, maxRaw) {
	const min = parseFilterNumber(minRaw);
	const max = parseFilterNumber(maxRaw);
	if (min == null && max == null) return true;
	if (value == null) return false;
	if (min != null && value < min) return false;
	if (max != null && value > max) return false;
	return true;
}
function parseFilterNumber(value) {
	const trimmed = value.trim();
	if (!trimmed) return null;
	const parsed = Number(trimmed);
	return Number.isFinite(parsed) ? parsed : null;
}
//#endregion
//#region src/client/features/audit/results/IssuesView.tsx
var MAX_RENDERED_URLS = 100;
var SEVERITY_RULE = {
	critical: "border-l-destructive/60",
	warning: "border-l-warning/60",
	info: "border-l-info/60"
};
var SEVERITY_LABEL = {
	critical: "Critical",
	warning: "Warning",
	info: "Info"
};
function resolveIssueSeverity(issue) {
	const descriptor = getIssueDescriptor(issue.issueType);
	if (descriptor) return descriptor.severity;
	return issue.severity === "critical" || issue.severity === "warning" ? issue.severity : "info";
}
function toIssueGroups(summaries) {
	const groups = summaries.map((summary) => {
		const descriptor = getIssueDescriptor(summary.issueType);
		return {
			issueType: summary.issueType,
			severity: resolveIssueSeverity(summary),
			title: descriptor?.title ?? summary.issueType,
			explanation: descriptor?.explanation ?? "",
			howToFix: descriptor?.howToFix ?? "",
			count: summary.count
		};
	});
	return t(groups, (a, b) => ISSUE_SEVERITY_ORDER[a.severity] - ISSUE_SEVERITY_ORDER[b.severity] || b.count - a.count);
}
function IssuesView({ auditRef, issueGroups, tabs }) {
	const groups = (0, import_react.useMemo)(() => toIssueGroups(issueGroups), [issueGroups]);
	const sections = (0, import_react.useMemo)(() => [
		"critical",
		"warning",
		"info"
	].map((severity) => ({
		severity,
		groups: groups.filter((group) => group.severity === severity)
	})).filter((section) => section.groups.length > 0), [groups]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-xl border border-border bg-card",
		children: [tabs, groups.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			variant: "plain",
			title: "No issues found.",
			description: "Every crawled page passed the issue checks."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: sections.map((section) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssueSection, {
			auditRef,
			section
		}, section.severity)) })]
	});
}
function IssueSection({ auditRef, section }) {
	const issueCount = section.groups.reduce((sum, group) => sum + group.count, 0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-border first:border-t-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center gap-2 bg-muted/50 px-4 py-1.5 border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SeverityBadge, {
				severity: section.severity,
				children: [SEVERITY_LABEL[section.severity], /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: issueCount
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "divide-y divide-border",
			children: section.groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssueRow, {
				auditRef,
				group
			}, group.issueType))
		})]
	});
}
function IssueRow({ auditRef, group }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: open ? `border-l-2 ${SEVERITY_RULE[group.severity]} bg-muted/30` : "border-l-2 border-l-transparent",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-muted/50 transition-colors",
			onClick: () => setOpen((value) => !value),
			"aria-expanded": open,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm font-medium flex-1 min-w-0 truncate",
					children: group.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs tabular-nums text-muted-foreground shrink-0",
					children: [
						group.count,
						" ",
						group.count === 1 ? "page" : "pages"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: `size-4 shrink-0 text-muted-foreground transition-transform ${open ? "rotate-90" : ""}` })
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "pl-4 pr-4 pb-4 pt-0.5 space-y-3",
			children: [
				group.explanation && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground max-w-prose",
					children: group.explanation
				}),
				group.howToFix && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm max-w-prose",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: "How to fix: "
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-foreground/80",
						children: group.howToFix
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AffectedUrlList, {
					auditRef,
					group
				})
			]
		})]
	});
}
/** Loads the group's first URLs only when it is opened. */
function AffectedUrlList({ auditRef, group }) {
	const query = useQuery({
		queryKey: [
			"audit-issues",
			auditRef,
			group.issueType
		],
		queryFn: () => getAuditIssues({ data: {
			...auditRef,
			issueType: group.issueType,
			pageSize: MAX_RENDERED_URLS
		} })
	});
	const remaining = group.count - MAX_RENDERED_URLS;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "max-h-[320px] overflow-y-auto rounded border border-border bg-card",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
			query,
			loading: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2 p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-3/4" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-2/3" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-1/2" })
				]
			}),
			errorFallback: "Could not load the affected URLs",
			children: (issues) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [issues.map((issue) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-3 py-1.5 text-sm flex flex-col gap-0.5 border-b border-border last:border-b-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					className: "text-foreground/80 truncate hover:underline",
					href: issue.pageUrl,
					target: "_blank",
					rel: "noreferrer",
					title: issue.pageUrl,
					children: issue.pageUrl
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssueDetails, { detailsJson: issue.detailsJson })]
			}, issue.id)), remaining > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-3 py-2 text-xs text-muted-foreground",
				children: [
					"\u2026and ",
					remaining,
					" more \u2014 export the issues CSV for the full list."
				]
			})] })
		})
	});
}
function parseDetails(detailsJson) {
	const parsed = JSON.parse(detailsJson);
	if (typeof parsed === "object" && parsed !== null && !Array.isArray(parsed)) return Object.entries(parsed);
	return null;
}
function IssueDetails({ detailsJson }) {
	const details = (0, import_react.useMemo)(() => detailsJson ? parseDetails(detailsJson) : null, [detailsJson]);
	if (!details) return null;
	const entries = details.filter(([, value]) => value !== null && value !== void 0);
	if (entries.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-xs text-muted-foreground truncate",
		children: entries.map(([key, value]) => {
			return `${key}: ${Array.isArray(value) ? value.join(" \u2192 ") : String(value)}`;
		}).join(" \u00B7 ")
	});
}
//#endregion
//#region src/client/features/audit/results/AuditResultsTableFilters.tsx
function PagesFilterBar({ filters, onChange, activeFilterCount, onReset }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataTableFilterPanel, {
		activeCount: activeFilterCount,
		onReset,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextFilter, {
					label: "Search",
					value: filters.query,
					placeholder: "URL, title, meta",
					onChange: (query) => onChange({
						...filters,
						query
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectFilter, {
					label: "Status",
					value: filters.status,
					onChange: (status) => onChange({
						...filters,
						status
					}),
					options: [
						["all", "All"],
						["ok", "2xx"],
						["redirect", "3xx"],
						["error", "4xx/5xx"],
						["missing", "Missing"]
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectFilter, {
					label: "Crawl result",
					value: filters.fetchClass,
					onChange: (fetchClass) => onChange({
						...filters,
						fetchClass
					}),
					options: [
						["all", "All"],
						["ok", "Read"],
						["error", "Failed"],
						["blocked", "Blocked"],
						["rate_limited", "Rate limited"]
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectFilter, {
					label: "Alt text",
					value: filters.missingAlt,
					onChange: (missingAlt) => onChange({
						...filters,
						missingAlt
					}),
					options: [
						["all", "All"],
						["yes", "Missing alt"],
						["no", "No missing alt"]
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-2 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RangeFilter, {
				label: "Words",
				min: filters.minWords,
				max: filters.maxWords,
				onMinChange: (minWords) => onChange({
					...filters,
					minWords
				}),
				onMaxChange: (maxWords) => onChange({
					...filters,
					maxWords
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RangeFilter, {
				label: "Speed ms",
				min: filters.minResponseMs,
				max: filters.maxResponseMs,
				onMinChange: (minResponseMs) => onChange({
					...filters,
					minResponseMs
				}),
				onMaxChange: (maxResponseMs) => onChange({
					...filters,
					maxResponseMs
				})
			})]
		})]
	});
}
function PerformanceFilterBar({ filters, onChange, activeFilterCount, onReset }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DataTableFilterPanel, {
		activeCount: activeFilterCount,
		onReset,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-3 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextFilter, {
					label: "Search",
					value: filters.query,
					placeholder: "URL",
					onChange: (query) => onChange({
						...filters,
						query
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectFilter, {
					label: "Device",
					value: filters.device,
					onChange: (device) => onChange({
						...filters,
						device
					}),
					options: [
						["all", "All"],
						["desktop", "Desktop"],
						["mobile", "Mobile"]
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectFilter, {
					label: "Status",
					value: filters.status,
					onChange: (status) => onChange({
						...filters,
						status
					}),
					options: [
						["all", "All"],
						["ok", "OK"],
						["failed", "Failed"]
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextFilter, {
					label: "Max LCP s",
					value: filters.maxLcpSeconds,
					placeholder: "2.5",
					type: "number",
					onChange: (maxLcpSeconds) => onChange({
						...filters,
						maxLcpSeconds
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid grid-cols-1 gap-2 lg:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RangeFilter, {
				label: "Perf",
				min: filters.minPerf,
				max: filters.maxPerf,
				onMinChange: (minPerf) => onChange({
					...filters,
					minPerf
				}),
				onMaxChange: (maxPerf) => onChange({
					...filters,
					maxPerf
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RangeFilter, {
				label: "SEO",
				min: filters.minSeo,
				max: filters.maxSeo,
				onMinChange: (minSeo) => onChange({
					...filters,
					minSeo
				}),
				onMaxChange: (maxSeo) => onChange({
					...filters,
					maxSeo
				})
			})]
		})]
	});
}
/** The toolbar above a results table: the filter toggle and the row count. */
function ResultsTableToolbar({ showFilters, onToggle, activeFilterCount, resultCount, totalCount }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableToolbar, {
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "text-sm tabular-nums text-muted-foreground",
			children: [
				resultCount.toLocaleString(),
				" of ",
				totalCount.toLocaleString()
			]
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFilterToggle, {
			open: showFilters,
			activeCount: activeFilterCount,
			onToggle
		})
	});
}
function countActiveFilters(filters, emptyFilters) {
	return Object.keys(filters).reduce((count, key) => {
		const filterKey = key;
		return filters[filterKey] !== emptyFilters[filterKey] ? count + 1 : count;
	}, 0);
}
function TextFilter({ label, value, placeholder, type = "text", onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFilterGroup, {
		label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			"aria-label": label,
			type,
			value,
			placeholder,
			onChange: (event) => onChange(event.target.value)
		})
	});
}
function RangeFilter({ label, min, max, onMinChange, onMaxChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableRangeFilter, {
		label,
		min: {
			value: min,
			onChange: (event) => onMinChange(event.target.value)
		},
		max: {
			value: max,
			onChange: (event) => onMaxChange(event.target.value)
		}
	});
}
function SelectFilter({ label, value, options, onChange }) {
	const items = options.map(([optionValue, optionLabel]) => ({
		value: optionValue,
		label: optionLabel
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableFilterGroup, {
		label,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
			items,
			value,
			onValueChange: (next) => {
				if (next !== null) onChange(next);
			},
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
				"aria-label": label,
				className: "w-full",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
				value: item.value,
				children: item.label
			}, item.value)) })]
		})
	});
}
//#endregion
//#region src/client/features/audit/results/PagesTable.tsx
var pageColumnHelper = createColumnHelper();
/**
* Path shown in the URL/redirect cells. Redirect sources on another host
* (e.g. the apex domain 301ing to www) would otherwise render identically
* to their target, so include the host whenever it differs from the
* site's canonical host.
*/
function displayPath(url, canonicalHost) {
	const host = extractHostname(url);
	const path = extractPathname(url);
	return host === canonicalHost ? path : host + path;
}
function isRedirect(row) {
	return row.statusCode !== null && row.statusCode >= 300 && row.statusCode < 400;
}
/** Redirects and blocked/errored fetches have no analyzed content \u2014 their
* zero H1/word/image counts are an artifact, not a finding. */
function hasAnalyzedContent(row) {
	return row.fetchClass === "ok" && !isRedirect(row);
}
var EmptyCell = () => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
	className: "text-xs text-muted-foreground",
	children: "-"
});
function buildPagesColumns(canonicalHost) {
	return [
		pageColumnHelper.accessor("url", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "URL"
			}),
			cell: ({ getValue }) => {
				const url = getValue();
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: url,
					target: "_blank",
					rel: "noopener noreferrer",
					className: "inline-flex items-center gap-1 text-xs text-primary hover:underline",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate",
						children: displayPath(url, canonicalHost)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "size-3 shrink-0" })]
				});
			},
			meta: { cellClassName: "max-w-[240px] truncate" }
		}),
		pageColumnHelper.accessor("statusCode", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "Status"
			}),
			cell: ({ getValue, row }) => row.original.fetchClass === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
				variant: "destructive",
				size: "sm",
				title: "Fetching or rendering failed, so this page was not checked for content issues.",
				children: "Failed"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HttpStatusBadge, { code: getValue() })
		}),
		pageColumnHelper.accessor("title", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "Title"
			}),
			cell: ({ getValue, row }) => {
				if (isRedirect(row.original)) {
					const target = row.original.redirectUrl;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs text-muted-foreground",
						children: ["\u2192 ", target ? displayPath(target, canonicalHost) : "redirect"]
					});
				}
				const title = getValue();
				if (title) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "break-words",
					children: title
				});
				return row.original.missingTitle ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-destructive text-xs",
					children: "missing"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCell, {});
			},
			meta: { cellClassName: "max-w-[360px]" }
		}),
		pageColumnHelper.accessor("h1Count", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "H1"
			}),
			cell: ({ getValue, row }) => hasAnalyzedContent(row.original) ? getValue() : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCell, {})
		}),
		pageColumnHelper.accessor("wordCount", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "Words"
			}),
			cell: ({ getValue, row }) => hasAnalyzedContent(row.original) ? getValue() : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCell, {})
		}),
		pageColumnHelper.display({
			id: "images",
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "Images"
			}),
			cell: ({ row }) => {
				if (!hasAnalyzedContent(row.original)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCell, {});
				return row.original.imagesMissingAlt > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-warning",
					children: [
						row.original.imagesMissingAlt,
						"/",
						row.original.imagesTotal
					]
				}) : row.original.imagesTotal;
			},
			enableSorting: true
		}),
		pageColumnHelper.accessor("responseTimeMs", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "Speed"
			}),
			cell: ({ getValue }) => {
				const value = getValue();
				return value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs",
					children: [value, "ms"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyCell, {});
			}
		})
	];
}
var PAGE_SIZE = 100;
function sortParams(sorting) {
	const [first] = sorting;
	return {
		sort: auditPagesSortFields.find((field) => field === first?.id) ?? "url",
		order: first?.desc ? "desc" : "asc"
	};
}
/**
* Filtering, sorting and paging run in the database: a 10,000-page audit is
* too big to send to the browser in one response.
*/
function PagesTable({ auditRef, canonicalHost, totalCount, tabs }) {
	const [page, setPage] = (0, import_react.useState)(1);
	const [filters, setFilters] = (0, import_react.useState)(EMPTY_PAGES_FILTERS);
	const [draftFilters, setDraftFilters] = useDebouncedDraft(filters, (next) => {
		setFilters(next);
		setPage(1);
	});
	const [showFilters, setShowFilters] = (0, import_react.useState)(false);
	const [sorting, setSorting] = (0, import_react.useState)([{
		id: "url",
		desc: false
	}]);
	const activeFilterCount = countActiveFilters(draftFilters, EMPTY_PAGES_FILTERS);
	const pagesQuery = useQuery({
		queryKey: [
			"audit-pages",
			auditRef,
			filters,
			sorting,
			page
		],
		queryFn: () => getAuditPages({ data: {
			...auditRef,
			...toPagesQuery(filters),
			...sortParams(sorting),
			page,
			pageSize: PAGE_SIZE
		} }),
		placeholderData: keepPreviousData
	});
	const columns = (0, import_react.useMemo)(() => buildPagesColumns(canonicalHost), [canonicalHost]);
	const table = useDataTable({
		data: pagesQuery.data?.rows ?? [],
		columns,
		state: { sorting },
		onSortingChange: (updater) => {
			setSorting(updater);
			setPage(1);
		},
		getRowId: (row) => row.id,
		manualSorting: true,
		enableSortingRemoval: false,
		enableMultiSort: false
	});
	const filteredCount = pagesQuery.data?.totalCount ?? 0;
	const resetFilters = () => setDraftFilters(EMPTY_PAGES_FILTERS);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
		table,
		isLoading: pagesQuery.isPending,
		isRefreshing: pagesQuery.isPlaceholderData,
		error: pagesQuery.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
			fallback: "Could not load the pages",
			onRetry: () => void pagesQuery.refetch(),
			isRetrying: pagesQuery.isFetching
		}) : void 0,
		empty: { title: "No pages crawled" },
		isFiltered: activeFilterCount > 0,
		onClearFilters: resetFilters,
		toolbar: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			tabs,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsTableToolbar, {
				showFilters,
				onToggle: () => setShowFilters((current) => !current),
				activeFilterCount,
				resultCount: filteredCount,
				totalCount
			}),
			showFilters ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PagesFilterBar, {
				filters: draftFilters,
				onChange: setDraftFilters,
				activeFilterCount,
				onReset: resetFilters
			}) : null
		] }),
		footer: filteredCount > PAGE_SIZE ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TablePagination, {
			page,
			pageSize: PAGE_SIZE,
			totalCount: filteredCount,
			isLoading: pagesQuery.isFetching,
			onPageChange: setPage
		}) : void 0
	});
}
//#endregion
//#region src/client/features/audit/results/ShopifyRateLimitAlert.tsx
/**
* Shown when Shopify rate limited an unrendered crawl that carried a crawler
* signature. Shopify's edge can still throttle Cloudflare Workers then, and a
* rendered audit reads throttled pages from outside Cloudflare.
*/
function ShopifyRateLimitAlert({ projectId, startUrl }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "warning",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "We ran into an error with your Shopify domain." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "Shopify is globally rate limiting, so this report is incomplete. To complete the audit, start a new one with Render JavaScript turned on." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "col-start-2 mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					size: "sm",
					nativeButton: false,
					render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/p/$projectId/audit",
						params: { projectId },
						search: { url: startUrl }
					}),
					children: "Start a new audit"
				})
			})
		]
	});
}
//#endregion
//#region src/client/features/audit/results/ShopifyCrawlWarning.tsx
/**
* Shown instead of the generic crawl warnings when a Shopify storefront
* throttled or refused the crawl. Shopify's own fix is a crawler-access
* signature the merchant creates in admin, so the report asks for it first.
*
* The setup steps only show while the domain has no usable signature. Once
* one is saved they collapse to a single line with the re-run button. An
* unrendered crawl Shopify still rate limited with the signature asks for
* rendering instead. Where CRAWLER_ACCESS_SECRET is optional (Every App and
* self-hosts), the warning says to set it first when it isn't: a signature
* created too early only runs down its expiry.
*/
function ShopifyCrawlWarning({ projectId, audit, throttled }) {
	const navigate = useNavigate();
	const host = extractHostname(audit.startUrl);
	const usedCredentialId = audit.config.crawlerCredentialId;
	const credentialsQuery = useQuery({
		queryKey: crawlerCredentialsQueryKey,
		queryFn: () => listCrawlerCredentials()
	});
	const canStoreCrawlerAccess = !useCrawlerAccessNeedsSetup(projectId);
	const setupHint = canStoreCrawlerAccess ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "text-muted-foreground",
		children: [
			"A signature can't be saved here until crawler access is set up.",
			" ",
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrawlerAccessSetupHint, {})
		]
	});
	const expiredCredential = credentialsQuery.data?.find((credential) => (usedCredentialId ? credential.id === usedCredentialId : credential.host === host) && isCrawlerAccessExpired(credential.expiresAt));
	const liveCredentials = (credentialsQuery.data ?? []).filter((credential) => credential.host === host && !isCrawlerAccessExpired(credential.expiresAt));
	const liveCredential = liveCredentials.find((credential) => credential.id === usedCredentialId) ?? liveCredentials[0];
	const isSaving = useIsMutating({ mutationKey: saveCrawlerCredentialMutationKey }) > 0;
	const rerunMutation = useMutation({
		mutationFn: () => startAudit({ data: {
			projectId,
			startUrl: audit.startUrl,
			maxPages: audit.config.maxPages,
			lighthouseStrategy: audit.config.lighthouseStrategy,
			renderJavaScript: audit.config.renderJavaScript
		} }),
		onSuccess: (result) => {
			navigate({
				to: "/p/$projectId/audit",
				params: { projectId },
				search: {
					auditId: result.auditId,
					tab: "issues"
				}
			});
		}
	});
	const rerunButton = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		variant: "outline",
		size: "sm",
		pending: rerunMutation.isPending,
		disabled: isSaving,
		onClick: () => rerunMutation.mutate(),
		children: rerunMutation.isPending ? "Starting\u2026" : "Re-run audit"
	});
	if (credentialsQuery.isPending) return null;
	if (liveCredential) {
		const signedAndStillLimited = liveCredential.id === usedCredentialId;
		if (signedAndStillLimited && throttled && !audit.config.renderJavaScript) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopifyRateLimitAlert, {
			projectId,
			startUrl: audit.startUrl
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
			variant: signedAndStillLimited ? "warning" : "success",
			children: [
				signedAndStillLimited ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, {
					className: "text-foreground",
					children: signedAndStillLimited ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"Shopify limited this crawl despite your signature. To check that it was created for ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: host
						}),
						", paste it again in",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/p/$projectId/settings/integrations",
							params: { projectId },
							children: "Project settings"
						}),
						". If it was, Shopify is still throttling this store: re-run the audit later or with fewer pages."
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						"Crawler access is saved for",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono",
							children: host
						}),
						". Re-run the audit to crawl with it."
					] })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "col-start-2 mt-2",
					children: rerunButton
				})
			]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
		variant: "warning",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 space-y-3",
			children: [
				expiredCredential?.expiresAt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Your Shopify signature for this store has expired." }),
					setupHint,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: [
							"It ran out on",
							" ",
							new Date(expiredCredential.expiresAt).toLocaleDateString(),
							", so requests after that went out unsigned and Shopify limited them.",
							canStoreCrawlerAccess ? " Signatures can't be renewed: create a fresh one in Shopify admin and paste it below to replace the stored values." : null
						]
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Shopify limited this crawl." }),
					setupHint,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-muted-foreground",
						children: ["Shopify rate-limits crawlers it hasn't authorized, so parts of this report are missing.", canStoreCrawlerAccess ? " If you own this store, authorizing OpenSEO takes about a minute." : null]
					})
				] }),
				canStoreCrawlerAccess ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
					className: "list-decimal space-y-1 pl-5 text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In Shopify admin, go to Online Store \u2192 Preferences \u2192 Crawler access and click Create signature." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Pick the domain ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono",
								children: host
							}),
							" and an expiry (up to 3 months)."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Paste the two values below." })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CrawlerAccessForm, {
					projectId,
					initialHost: host,
					lockHost: true
				}, host)] }) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-4",
					children: [rerunButton, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-primary underline underline-offset-3",
						href: SHOPIFY_CRAWLER_ACCESS_DOC_URL,
						target: "_blank",
						rel: "noreferrer",
						children: "Shopify's crawler access guide"
					})]
				})
			]
		})]
	});
}
//#endregion
//#region src/client/features/audit/results/RenderingWarnings.tsx
/** Report notices about JavaScript: app shells, and pages a render missed. */
function RenderingWarnings({ data }) {
	const rendered = data.audit.config.renderJavaScript;
	const hasShells = data.issueGroups.some((group) => group.issueType === "javascript-rendering-suspected");
	const unreadCount = data.fetchClassCounts.error;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		hasShells && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
			variant: "warning",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "Some pages may need JavaScript to show their content." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: rendered ? "They were still loading after rendering, so we couldn't check them." : "Turn on Render JavaScript and run the audit again to check them." })
			]
		}),
		rendered && unreadCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
			variant: "warning",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertTitle, { children: [
					"We couldn't read ",
					unreadCount,
					" ",
					unreadCount === 1 ? "page" : "pages",
					"."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: "To see them, open Pages and filter Crawl result by Failed." })
			]
		}),
		rendered && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted-foreground",
			children: "JavaScript rendering was enabled for this audit."
		})
	] });
}
//#endregion
//#region src/client/features/audit/results/ResultsTables.tsx
var performanceColumnHelper = createColumnHelper();
function PerformanceTable({ auditId, projectId, lighthouse, tabs }) {
	const [filters, setFilters] = (0, import_react.useState)(EMPTY_PERFORMANCE_FILTERS);
	const [showFilters, setShowFilters] = (0, import_react.useState)(false);
	const [sorting, setSorting] = (0, import_react.useState)([{
		id: "performanceScore",
		desc: false
	}]);
	const rows = (0, import_react.useMemo)(() => lighthouse.map((result) => ({
		...result,
		pagePath: result.pageUrl ? extractPathname(result.pageUrl) : null
	})), [lighthouse]);
	const filteredRows = (0, import_react.useMemo)(() => filterPerformanceRows(rows, filters), [filters, rows]);
	const activeFilterCount = countActiveFilters(filters, EMPTY_PERFORMANCE_FILTERS);
	const columns = (0, import_react.useMemo)(() => buildPerformanceColumns({
		auditId,
		projectId
	}), [auditId, projectId]);
	const table = useDataTable({
		data: filteredRows,
		columns,
		state: { sorting },
		onSortingChange: setSorting,
		withSorting: true
	});
	const resetFilters = () => setFilters(EMPTY_PERFORMANCE_FILTERS);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
		table,
		empty: { title: "No Lighthouse results" },
		isFiltered: activeFilterCount > 0,
		onClearFilters: resetFilters,
		toolbar: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			tabs,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsTableToolbar, {
				showFilters,
				onToggle: () => setShowFilters((current) => !current),
				activeFilterCount,
				resultCount: filteredRows.length,
				totalCount: rows.length
			}),
			showFilters ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PerformanceFilterBar, {
				filters,
				onChange: setFilters,
				activeFilterCount,
				onReset: resetFilters
			}) : null
		] })
	});
}
function buildPerformanceColumns({ auditId, projectId }) {
	return [
		performanceColumnHelper.accessor("pagePath", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "URL"
			}),
			cell: ({ getValue }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs",
				children: getValue() ?? "-"
			}),
			sortingFn: stringNullsLast,
			meta: { cellClassName: "max-w-[180px] truncate" }
		}),
		performanceColumnHelper.accessor("strategy", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "Device"
			}),
			cell: ({ getValue }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "capitalize text-xs",
				children: getValue()
			})
		}),
		performanceColumnHelper.display({
			id: "status",
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "Status"
			}),
			cell: ({ row }) => {
				const isFailed = isLighthouseFailure(row.original);
				const failureMessage = row.original.errorMessage ?? "Lighthouse returned no category scores";
				return isFailed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "destructive",
					title: failureMessage,
					children: "failed"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "success",
					children: "ok"
				});
			},
			enableSorting: true,
			sortingFn: (left, right) => Number(isLighthouseFailure(left.original)) - Number(isLighthouseFailure(right.original))
		}),
		performanceColumnHelper.accessor("performanceScore", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "Perf"
			}),
			cell: ({ getValue }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LighthouseScoreBadge, { score: getValue() }),
			sortingFn: numericNullsLast
		}),
		performanceColumnHelper.accessor("accessibilityScore", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "A11y"
			}),
			cell: ({ getValue }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LighthouseScoreBadge, { score: getValue() }),
			sortingFn: numericNullsLast
		}),
		performanceColumnHelper.accessor("seoScore", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "SEO"
			}),
			cell: ({ getValue }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LighthouseScoreBadge, { score: getValue() }),
			sortingFn: numericNullsLast
		}),
		performanceColumnHelper.accessor("lcpMs", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "LCP"
			}),
			cell: ({ getValue }) => {
				const value = getValue();
				return value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs",
					children: [(value / 1e3).toFixed(1), "s"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "-"
				});
			},
			sortingFn: numericNullsLast
		}),
		performanceColumnHelper.accessor("cls", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "CLS"
			}),
			cell: ({ getValue }) => {
				const value = getValue();
				return value != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs",
					children: value.toFixed(3)
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "-"
				});
			},
			sortingFn: numericNullsLast
		}),
		performanceColumnHelper.accessor("inpMs", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "INP"
			}),
			cell: ({ getValue }) => {
				const value = getValue();
				return value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs",
					children: [Math.round(value), "ms"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "-"
				});
			},
			sortingFn: numericNullsLast
		}),
		performanceColumnHelper.accessor("ttfbMs", {
			header: ({ column }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortableHeader, {
				column,
				label: "TTFB"
			}),
			cell: ({ getValue }) => {
				const value = getValue();
				return value ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-xs",
					children: [Math.round(value), "ms"]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-xs text-muted-foreground",
					children: "-"
				});
			},
			sortingFn: numericNullsLast
		}),
		performanceColumnHelper.display({
			id: "issues",
			header: () => "Issues",
			cell: ({ row }) => row.original.r2Key && !isLighthouseFailure(row.original) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "xs",
				nativeButton: false,
				render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/p/$projectId/audit/issues/$resultId",
					params: {
						projectId,
						resultId: row.original.id
					},
					search: {
						auditId,
						category: "performance"
					}
				}),
				children: "View issues"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted-foreground",
				children: "-"
			})
		})
	];
}
//#endregion
//#region src/client/features/audit/results/ResultsView.tsx
function ResultsView({ projectId, data, onTabChange, tab, siteBlocked }) {
	const { audit, lighthouse, issueGroups } = data;
	const auditRef = {
		projectId,
		auditId: audit.id
	};
	const crawlStopped = issueGroups.some((group) => group.issueType === "crawl-rate-limited");
	const hasPerformanceTab = lighthouse.length > 0;
	const activeTab = tab === "performance" && !hasPerformanceTab ? "issues" : tab;
	const lighthouseSummary = useLighthouseSummary(lighthouse);
	const blockedCount = data.fetchClassCounts.blocked;
	const rateLimitedCount = data.fetchClassCounts.rate_limited;
	const shopifyLimited = audit.config.sitePlatform === "shopify" && (blockedCount > 0 || rateLimitedCount > 0 || crawlStopped);
	const tabs = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsHeader, {
		issueCount: data.issueCount,
		pageCount: data.pageCount,
		lighthouseCount: lighthouse.length,
		hasPerformanceTab,
		activeTab,
		onTabChange,
		onExport: (format) => {
			if (activeTab === "performance") {
				exportPerformance(lighthouse, format);
				return;
			}
			if (activeTab === "issues") {
				exportIssues(auditRef, format);
				return;
			}
			exportPages(auditRef, format);
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		shopifyLimited && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShopifyCrawlWarning, {
			projectId,
			audit,
			throttled: rateLimitedCount > 0 || crawlStopped
		}),
		!shopifyLimited && !siteBlocked && blockedCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
			variant: "warning",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertTitle, { children: [
					"Bot protection blocked our crawler on ",
					blockedCount,
					" ",
					blockedCount === 1 ? "page" : "pages",
					"."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BotProtectionAdvice, {
					projectId,
					rendered: audit.config.renderJavaScript === true
				}) })
			]
		}),
		!shopifyLimited && (rateLimitedCount > 0 || crawlStopped) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
			variant: "warning",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldAlert, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: crawlStopped ? "The crawl stopped early because of the site\u2019s rate limit." : `The site rate limited us on ${rateLimitedCount} ${rateLimitedCount === 1 ? "page" : "pages"}.` }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, { children: [
					crawlStopped ? "The site kept refusing pages, so some URLs were left unvisited. This report is incomplete. " : "Pages that returned 429 Too Many Requests could not be audited. ",
					"Re-run the audit after the rate limit resets, or ask the site owner to allow the",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "underline underline-offset-4",
						href: "https://openseo.so/docs/crawler",
						target: "_blank",
						rel: "noreferrer",
						children: "OpenSEO-Audit crawler"
					}),
					"."
				] })
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RenderingWarnings, { data }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatsStrip, {
			pagesCrawled: audit.pagesCrawled,
			issueCount: data.issueCount,
			issueGroups,
			totalLighthouse: lighthouse.length,
			averageResponseMs: data.averageResponseMs,
			lighthouseSummary
		}),
		activeTab === "issues" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IssuesView, {
			auditRef,
			issueGroups,
			tabs
		}),
		activeTab === "pages" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PagesTable, {
			auditRef,
			canonicalHost: data.canonicalHost,
			totalCount: data.pageCount,
			tabs
		}),
		activeTab === "performance" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PerformanceTable, {
			auditId: audit.id,
			projectId,
			lighthouse,
			tabs
		})
	] });
}
function useLighthouseSummary(lighthouse) {
	return (0, import_react.useMemo)(() => {
		const failed = lighthouse.filter((row) => isLighthouseFailure(row)).length;
		const successful = lighthouse.filter((row) => !isLighthouseFailure(row));
		const averageScore = (key) => {
			const values = successful.map((row) => row[key]).filter((value) => value != null);
			if (values.length === 0) return null;
			const total = values.reduce((sum, value) => sum + value, 0);
			return Math.round(total / values.length);
		};
		return {
			failed,
			avgPerformance: averageScore("performanceScore"),
			avgSeo: averageScore("seoScore"),
			avgAccessibility: averageScore("accessibilityScore")
		};
	}, [lighthouse]);
}
function ResultsHeader({ issueCount, pageCount, lighthouseCount, hasPerformanceTab, activeTab, onTabChange, onExport }) {
	const tabs = [
		{
			tab: "issues",
			label: `Issues (${issueCount})`
		},
		{
			tab: "pages",
			label: `Pages (${pageCount})`
		},
		...hasPerformanceTab ? [{
			tab: "performance",
			label: `Performance (${lighthouseCount})`
		}] : []
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTableTabs, {
		value: activeTab,
		onValueChange: (value) => {
			const next = tabs.find((item) => item.tab === value);
			if (next) onTabChange(next.tab);
		},
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExportMenu, {
			actions: [
				"sheets",
				"csv",
				"json"
			],
			onExport
		}),
		children: tabs.map(({ label, tab }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
			value: tab,
			children: label
		}, tab))
	});
}
function StatsStrip({ pagesCrawled, issueCount, issueGroups, totalLighthouse, averageResponseMs, lighthouseSummary }) {
	const severityCounts = (0, import_react.useMemo)(() => {
		const counts = {
			critical: 0,
			warning: 0,
			info: 0
		};
		for (const group of issueGroups) counts[resolveIssueSeverity(group)] += group.count;
		return counts;
	}, [issueGroups]);
	const items = [
		{
			label: "Pages crawled",
			value: String(pagesCrawled)
		},
		{
			label: "Issues found",
			value: String(issueCount),
			valueClass: issueCount === 0 ? "text-success" : "",
			sub: issueCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex flex-wrap items-center gap-1",
				children: [
					"critical",
					"warning",
					"info"
				].map((severity) => severityCounts[severity] > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SeverityBadge, {
					severity,
					title: severity,
					children: [
						severity === "critical" ? "Critical" : severity === "warning" ? "Warning" : "Info",
						" ",
						severityCounts[severity]
					]
				}, severity) : null)
			})
		},
		{
			label: "Average response time",
			value: `${averageResponseMs}ms`
		}
	];
	if (totalLighthouse > 0) items.push({
		label: "Lighthouse tests",
		value: String(totalLighthouse)
	}, {
		label: "Lighthouse performance",
		value: lighthouseSummary.avgPerformance == null ? "-" : String(lighthouseSummary.avgPerformance),
		valueClass: scoreClass(lighthouseSummary.avgPerformance)
	}, {
		label: "Lighthouse SEO",
		value: lighthouseSummary.avgSeo == null ? "-" : String(lighthouseSummary.avgSeo),
		valueClass: scoreClass(lighthouseSummary.avgSeo)
	}, {
		label: "Lighthouse accessibility",
		value: lighthouseSummary.avgAccessibility == null ? "-" : String(lighthouseSummary.avgAccessibility),
		valueClass: scoreClass(lighthouseSummary.avgAccessibility)
	}, {
		label: "Lighthouse failures",
		value: String(lighthouseSummary.failed),
		valueClass: lighthouseSummary.failed > 0 ? "text-destructive" : "text-success"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "w-full max-w-xl rounded-lg border border-border bg-card p-3",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MetricsTable, { rows: items.map((item) => ({
			label: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [item.label, item.sub || null]
			}),
			value: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: item.valueClass,
				children: item.value
			})
		})) })
	});
}
function scoreClass(score) {
	const tone = scoreTone(score);
	return tone ? SCORE_TEXT_CLASS[tone] : "";
}
//#endregion
//#region src/client/features/audit/AuditDetail.tsx
function AuditDetail({ projectId, auditId, tab, onBack, onTabChange }) {
	const statusQuery = useQuery({
		queryKey: [
			"audit-status",
			projectId,
			auditId
		],
		queryFn: () => getAuditStatus({ data: {
			projectId,
			auditId
		} }),
		refetchInterval: (query) => {
			return query.state.data?.status === "running" ? 3e3 : false;
		}
	});
	const isComplete = statusQuery.data?.status === "completed";
	const isFailed = statusQuery.data?.status === "failed";
	const isRunning = statusQuery.data?.status === "running";
	const resultsQuery = useQuery({
		queryKey: [
			"audit-results",
			projectId,
			auditId
		],
		queryFn: () => getAuditSummary({ data: {
			projectId,
			auditId
		} }),
		enabled: isComplete || isFailed
	});
	if (statusQuery.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkeletonPage, {});
	if (statusQuery.isError) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 py-4 md:px-6 md:py-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl space-y-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {
				onClick: onBack,
				children: "All audits"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryError, {
				fallback: "We could not load this audit. It may have been deleted.",
				onRetry: () => void statusQuery.refetch(),
				isRetrying: statusQuery.isFetching
			})]
		})
	});
	const status = statusQuery.data;
	const partialPageCount = isFailed ? resultsQuery.data?.pageCount ?? 0 : 0;
	const failedWithResults = isFailed && partialPageCount > 0;
	const failedWithoutResults = isFailed && resultsQuery.isSuccess && !failedWithResults;
	const results = resultsQuery.data;
	const siteBlocked = isComplete && status.pagesCrawled <= 1 && results !== void 0 && !results.issueGroups.some((group) => group.issueType === "javascript-rendering-suspected") && results.fetchClassCounts.rate_limited === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "px-4 py-4 md:px-6 md:py-6 pb-24 md:pb-8 overflow-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackButton, {
						onClick: onBack,
						children: "All audits"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-x-3 gap-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-2xl font-semibold tracking-tight",
								children: extractHostname(status.startUrl)
							}), !isRunning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusBadge, { status: status.status })]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted-foreground",
							children: ["Site audit \u00B7 Started ", formatStartedAt(status.startedAt)]
						})]
					})]
				}),
				isRunning && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressCard, {
					projectId,
					auditId,
					status
				}),
				failedWithoutResults && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "destructive",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "This audit stopped before it crawled any pages." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"Run a new audit to try again, or email",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:support@openseo.so`,
								children: "support@openseo.so"
							}),
							" if this keeps happening."
						] }), status.errorCode ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs",
							children: ["Code: ", status.errorCode]
						}) : null] })
					]
				}),
				siteBlocked && results && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "warning",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertTitle, { children: "This site's bot protection blocked our crawler." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AlertDescription, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BotProtectionAdvice, {
							projectId,
							rendered: results.audit.config.renderJavaScript === true
						}) })
					]
				}),
				failedWithResults && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Alert, {
					variant: "warning",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertTitle, { children: [
							"This audit stopped early after ",
							partialPageCount,
							" page",
							partialPageCount === 1 ? "" : "s",
							"."
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AlertDescription, { children: [
							"The results below cover everything crawled before it stopped. Run a new audit to try again, or email",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: `mailto:support@openseo.so`,
								children: "support@openseo.so"
							}),
							" if this keeps happening."
						] })
					]
				}),
				(isComplete || isFailed) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryState, {
					query: resultsQuery,
					errorFallback: "Failed to load the audit results",
					children: (data) => (isComplete || failedWithResults) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsView, {
						projectId,
						data,
						tab,
						onTabChange,
						siteBlocked
					})
				})
			]
		})
	});
}
function ProgressCard({ projectId, auditId, status }) {
	const crawlProgress = status.pagesTotal > 0 ? Math.round(status.pagesCrawled / status.pagesTotal * 100) : 0;
	const lighthouseDone = status.lighthouseCompleted + status.lighthouseFailed;
	const lighthouseProgress = status.lighthouseTotal > 0 ? Math.round(lighthouseDone / status.lighthouseTotal * 100) : 0;
	const isLighthousePhase = status.currentPhase === "lighthouse";
	const phaseLabel = status.currentPhase === "discovery" ? "Discovery" : status.currentPhase === "crawling" ? "Crawling" : status.currentPhase === "lighthouse" ? "Lighthouse" : status.currentPhase === "finalizing" ? "Finalizing" : "Running";
	const progress = isLighthousePhase ? lighthouseProgress : crawlProgress;
	const crawledUrls = useQuery({
		queryKey: [
			"audit-crawl-progress",
			projectId,
			auditId
		],
		queryFn: () => getCrawlProgress({ data: {
			projectId,
			auditId
		} }),
		refetchInterval: 1500
	}).data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
			className: "flex items-center gap-2 font-medium",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {
				className: "text-primary",
				"aria-hidden": true
			}), isLighthousePhase ? "Running Lighthouse checks" : "Crawling pages"]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardAction, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
			variant: "secondary",
			children: phaseLabel
		}) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Progress, {
			value: progress,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressLabel, {
				className: "font-normal",
				children: isLighthousePhase ? `${lighthouseDone} / ${status.lighthouseTotal} checks${status.lighthouseFailed > 0 ? ` (${status.lighthouseFailed} failed)` : ""}` : `${status.pagesCrawled} / ${status.pagesTotal} pages`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressValue, {})]
		}) })] }), crawledUrls.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			size: "sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
				className: "font-medium text-muted-foreground",
				children: [
					"Crawled Pages (",
					crawledUrls.length,
					")"
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardAction, {
				className: "text-xs text-muted-foreground",
				children: ["Updated ", new Date(crawledUrls[0].crawledAt).toLocaleTimeString()]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "max-h-[400px] overflow-y-auto",
				children: crawledUrls.map((entry, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProgressRow, {
					entry,
					index: i
				}, `${entry.url}-${entry.crawledAt}`))
			})]
		})]
	});
}
function ProgressRow({ entry, index }) {
	const pathname = extractPathname(entry.url);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex items-center justify-between gap-3 px-2 py-1.5 rounded text-sm ${index === 0 ? "bg-primary/5 animate-in fade-in slide-in-from-top-1 duration-300" : ""}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2 min-w-0 flex-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HttpStatusBadge, { code: entry.statusCode }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "truncate text-foreground/80",
				title: entry.url,
				children: pathname
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex items-center gap-3 shrink-0",
			children: entry.title && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-xs text-muted-foreground truncate max-w-[260px] hidden md:block",
				title: entry.title,
				children: entry.title
			})
		})]
	});
}
//#endregion
//#region src/routes/_app/p/$projectId/audit/index.tsx?tsr-split=component
function SiteAuditPage() {
	const { projectId } = Route.useParams();
	const { auditId, tab, url } = Route.useSearch();
	const navigate = useNavigate({ from: Route.fullPath });
	const setSearchParams = (0, import_react.useCallback)((updates) => {
		navigate({
			search: (prev) => ({
				...prev,
				...updates
			}),
			replace: true
		});
	}, [navigate]);
	if (!auditId) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LaunchView, {
		projectId,
		initialUrl: url ?? "",
		onAuditStarted: (id) => setSearchParams({
			auditId: id,
			url: void 0
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuditDetail, {
		projectId,
		auditId,
		tab,
		onBack: () => setSearchParams({ auditId: void 0 }),
		onTabChange: (nextTab) => setSearchParams({ tab: nextTab })
	});
}
//#endregion
export { SiteAuditPage as component };
