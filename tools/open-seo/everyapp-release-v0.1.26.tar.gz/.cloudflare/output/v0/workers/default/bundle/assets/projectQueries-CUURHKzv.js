import { t as queryOptions } from "./queryOptions-Dji4xsRu.js";
import { o as getProjects } from "./projects-BLNM8KiA.js";
//#region src/client/features/projects/projectQueries.ts
var projectsQueryOptions = () => queryOptions({
	queryKey: ["projects"],
	queryFn: () => getProjects()
});
//#endregion
export { projectsQueryOptions as t };
