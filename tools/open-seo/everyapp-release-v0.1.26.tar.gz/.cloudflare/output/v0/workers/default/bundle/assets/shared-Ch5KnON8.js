import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { Fn as object, Jn as string, Pn as number } from "./schemas-BPIpYT5n.js";
import { j as useQueryClient } from "./useQuery-B93OR2NQ.js";
import { t as useMutation } from "./useMutation-CSMKPLuv.js";
import { r as getStandardErrorMessage } from "./error-messages-D7nntGF_.js";
import { t as Copy } from "./copy-BCHMWRty.js";
import { t as ExternalLink } from "./external-link-HZIbqzY5.js";
import { t as Button } from "./button-DrcZrdio.js";
import { t as toast } from "./dist-DVm-Qvek.js";
import { n as captureClientEvent } from "./posthog-BMFJOGWd.js";
import { t as createSsrRpc } from "./createSsrRpc-Vp3C13VD.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { t as formatRelativeTime } from "./relative-time-C7DmX3yX.js";
import { n as sharePath } from "./report-share-CEIbLpdX.js";
import { t as Input } from "./input-B1cALAbz.js";
import { a as FieldLabel, n as FieldContent, r as FieldDescription, t as Field } from "./field-CjRT_5Cr.js";
import { t as Switch } from "./switch-BumBbmWp.js";
import { a as DialogHeader, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-C8cX1CPK.js";
import { t as ConfirmDialog } from "./ConfirmDialog-CI0zpKxJ.js";
//#region src/serverFunctions/reports.ts
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var listReportsSchema = object({
	projectId: string().min(1),
	limit: number().int().min(1).max(100).optional(),
	offset: number().int().min(0).optional()
});
var reportRefSchema = object({
	projectId: string().min(1),
	reportId: string().min(1)
});
/**
* `summary` is dropped on the way out: it is written for agents, the app never
* renders it, and it is the one field here big enough to matter on the wire.
* MCP and the share page still read it.
*/
var listReports = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(listReportsSchema).handler(createSsrRpc("b694e15848bbfda53bac85dff1f870f149e6a0d751aec69fb3ac5ba8b92e5132"));
/** Metadata only. The document itself is served by /r/<reportId>. */
var getReport = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(reportRefSchema).handler(createSsrRpc("db353c04583ad0a099587b79c0a3518606b059e8ac631f4bd24d91f1ff34bc2a"));
/**
* Mints (or returns) the report's public link. The token alone comes back \u2014
* the app builds `<origin>/s/<token>` client-side, so the same server works on
* app.openseo.so and a self-hosted hostname without knowing either.
*/
var shareReport = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(reportRefSchema).handler(createSsrRpc("48d30e240455ab974c90d5defd14655146a5a189317efb46dfb6f240cbd157b4"));
var unshareReport = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(reportRefSchema).handler(createSsrRpc("55da6bb0f1efa6c7dab8088f8f282ab3d25d137bd67f9d333e7f90781a3dd032"));
var deleteReport = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(reportRefSchema).handler(createSsrRpc("4904ee1c0cc68d717399e853e8f38885a443e82e0ed6b6bfe992d1b21c3b6955"));
//#endregion
//#region src/client/features/reports/shared.tsx
var import_jsx_runtime = require_jsx_runtime();
var reportsQueryKey = (projectId) => ["reports", projectId];
var reportQueryKey = (projectId, reportId) => [
	"report",
	projectId,
	reportId
];
var reportTemplatesQueryKey = (projectId) => ["report-templates", projectId];
/**
* "Ben \u00b7 Claude Code". The person is the half that means something (it comes
* from the session); the client half is a self-reported hint, so it stands
* alone when the user cannot be resolved.
*/
function formatCreatedBy(report) {
	return report.createdByName ? `${report.createdByName} \u00B7 ${report.createdBy}` : report.createdBy;
}
/**
* One delete flow for both the list row and the detail page, so the toast, the
* event and the invalidation cannot drift apart.
*/
function useDeleteReport(projectId, onDeleted) {
	const queryClient = useQueryClient();
	return useMutation({
		mutationFn: (reportId) => deleteReport({ data: {
			projectId,
			reportId
		} }),
		onSuccess: (_result, reportId) => {
			captureClientEvent("report:deleted", {
				project_id: projectId,
				report_id: reportId
			});
			toast.success("Report deleted");
			queryClient.invalidateQueries({ queryKey: reportsQueryKey(projectId) });
			queryClient.removeQueries({ queryKey: reportQueryKey(projectId, reportId) });
			onDeleted?.();
		}
	});
}
/** Reports have no version history and no undo, so deletes are confirmed by name. */
function DeleteReportModal({ title, isPending, onClose, onConfirm }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConfirmDialog, {
		title: `Delete \u201c${title}\u201d?`,
		confirmLabel: "Delete report",
		destructive: true,
		pending: isPending,
		onClose,
		onConfirm,
		children: "This cannot be undone."
	});
}
/**
* The share toggle. The link is built from the browser's own origin, so the
* same report shares correctly from app.openseo.so and from a self-hosted
* hostname without the server knowing either.
*/
function ShareReportModal({ report, onClose }) {
	const queryClient = useQueryClient();
	const switchId = (0, import_react.useId)();
	const { projectId, id: reportId } = report;
	const mutation = useMutation({
		meta: { errorToast: false },
		mutationFn: (shared) => shared ? shareReport({ data: {
			projectId,
			reportId
		} }) : unshareReport({ data: {
			projectId,
			reportId
		} }),
		onSuccess: (result) => {
			queryClient.setQueryData(reportQueryKey(projectId, reportId), (previous) => previous ? {
				...previous,
				...result
			} : previous);
			queryClient.invalidateQueries({ queryKey: reportsQueryKey(projectId) });
		}
	});
	const shared = Boolean(report.shareToken);
	const url = report.shareToken ? `${window.location.origin}${sharePath(report.shareToken)}` : "";
	const copy = async () => {
		try {
			await navigator.clipboard.writeText(url);
			toast.success("Link copied");
		} catch {
			toast.error("Clipboard not available");
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => {
			if (!open) onClose();
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "sm:max-w-lg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
					className: "min-w-0 pr-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Share" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
						className: "truncate",
						children: report.title
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-lg border border-border",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						orientation: "horizontal",
						className: "p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(FieldContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldLabel, {
							htmlFor: switchId,
							children: "Public link"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldDescription, {
							id: `${switchId}-description`,
							children: shared ? "Anyone with the link can view. No sign-in needed." : "Only members of your organization can open it. A link that was open can keep loading for up to a minute."
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							id: switchId,
							"aria-describedby": `${switchId}-description`,
							checked: mutation.isPending ? mutation.variables : shared,
							disabled: mutation.isPending,
							onCheckedChange: (checked) => mutation.mutate(checked)
						})]
					}), shared ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 border-t border-border p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-stretch gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								readOnly: true,
								value: url,
								"aria-label": "Share link",
								onFocus: (event) => event.target.select(),
								className: "min-w-0 flex-1 basis-64"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "ml-auto flex items-stretch gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									nativeButton: false,
									"aria-label": "Open link",
									title: "Open",
									render: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: url,
										target: "_blank",
										rel: "noreferrer"
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => void copy(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { "data-icon": "inline-start" }), "Copy link"]
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: ["Shows the latest saved version. Hidden from search engines.", report.sharedAt ? ` Link created ${formatRelativeTime(report.sharedAt)}.` : ""]
						})]
					}) : null]
				}),
				mutation.isError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-destructive",
					children: getStandardErrorMessage(mutation.error, "Failed to update sharing")
				}) : null
			]
		})
	});
}
//#endregion
export { reportTemplatesQueryKey as a, getReport as c, reportQueryKey as i, listReports as l, ShareReportModal as n, reportsQueryKey as o, formatCreatedBy as r, useDeleteReport as s, DeleteReportModal as t };
