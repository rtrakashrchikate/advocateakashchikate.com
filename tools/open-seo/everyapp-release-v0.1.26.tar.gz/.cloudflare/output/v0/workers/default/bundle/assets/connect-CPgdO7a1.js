import { a as __toESM } from "./rolldown-runtime-oLLnCvco.js";
import { t as require_react } from "./react-CSJzK7Q0.js";
import { t as require_jsx_runtime } from "./jsx-runtime-e-vuvt4z.js";
import { Fn as object, Jn as string } from "./schemas-BPIpYT5n.js";
import { a as getSignInHref, t as OAUTH_AUTHORIZE_PATH } from "./auth-redirect-Dnh6pyWf.js";
import { n as AuthPageCard, r as AuthPageShell } from "./AuthPage-Bxu7AMPh.js";
import { n as Spinner } from "./Spinner-NR-t-8YM.js";
import { t as TurnstileWidget } from "./TurnstileWidget-bl7Vnlz9.js";
//#region src/routes/connect.tsx?tsr-split=component
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var guestResponseSchema = object({ redirectTo: string() });
var GIVE_UP_AFTER_MS = 2e4;
/**
* Where an AI app's sign-in window lands when the browser has no OpenSEO
* session (src/server/mcp/oauth-provider.ts). It passes Turnstile and asks the
* server for a guest account, which answers with where to go next: back to
* the AI app, or the normal sign-in page when it won't make a guest. Anything
* that goes wrong here also falls back to the sign-in page, so this page never
* leaves someone worse off than signing in. Navigations replace this page in
* history, so the back button can't replay it into a second guest.
*/
function ConnectPage() {
	const query = window.location.search.slice(1);
	const signInHref = getSignInHref(`${OAUTH_AUTHORIZE_PATH}?${query}`);
	const started = (0, import_react.useRef)(false);
	const connect = (turnstileToken) => {
		if (started.current) return;
		started.current = true;
		fetch("/api/oauth/guest", {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({
				query,
				turnstileToken
			})
		}).then(async (response) => {
			const body = guestResponseSchema.safeParse(await response.json());
			if (!response.ok || !body.success) throw new Error("Guest refused");
			window.location.replace(body.data.redirectTo);
		}).catch(() => window.location.replace(signInHref));
	};
	(0, import_react.useEffect)(() => {
		connect(void 0);
		const timer = setTimeout(() => {
			if (!started.current) window.location.replace(signInHref);
		}, GIVE_UP_AFTER_MS);
		return () => clearTimeout(timer);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPageShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthPageCard, {
		title: "Connecting OpenSEO",
		helperText: "This takes a few seconds. You'll go back to your AI app when it's done.",
		footer: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-center text-sm text-muted-foreground",
			children: [
				"Already have an OpenSEO account?",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: signInHref,
					className: "underline",
					children: "Sign in"
				})
			]
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col items-center gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spinner, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TurnstileWidget, {
				onToken: (token) => {
					if (token) connect(token);
				},
				resetNonce: 0
			})]
		})
	}) });
}
//#endregion
export { ConnectPage as component };
