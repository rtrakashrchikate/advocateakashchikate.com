import { n as createFileRoute, t as lazyRouteComponent } from "./lazyRouteComponent-C5WdHYzl.js";
import { t as pageHead } from "./pageHead-BfhwMlwa.js";
//#region src/routes/_app/p/$projectId/reports/templates.tsx
var $$splitComponentImporter = () => import("./templates-Cdfcq52d.js");
var Route = createFileRoute("/_app/p/$projectId/reports/templates")({
	head: () => pageHead("Report templates"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
