import { t as createServerFn } from "./createServerFn-LbQwuMn2.js";
import { Fn as object, Jn as string, Pn as number } from "./schemas-BPIpYT5n.js";
import { t as AuthRepository } from "./AuthRepository-tYELaN9C.js";
import { n, t as ReportService } from "./ReportService-B4ycMu8r.js";
import { r as requireProjectContext } from "./middleware-CAkDJtZb.js";
import { t as ReportTemplateService } from "./ReportTemplateService-4PL3hb_n.js";
import { t as createServerRpc } from "./createServerRpc-clVF8hjL.js";
//#region src/serverFunctions/reports.ts?tss-serverfn-split
var listReportsSchema = object({
	projectId: string().min(1),
	limit: number().int().min(1).max(100).optional(),
	offset: number().int().min(0).optional()
});
var reportRefSchema = object({
	projectId: string().min(1),
	reportId: string().min(1)
});
/**
* `summary` is dropped on the way out: it is written for agents, the app never
* renders it, and it is the one field here big enough to matter on the wire.
* MCP and the share page still read it.
*/
async function withDisplayNames(reports, projectId) {
	const userIds = [...new Set(reports.map((report) => report.createdByUserId))];
	const [users, { templates }] = await Promise.all([AuthRepository.getHostedUserNames(userIds), ReportTemplateService.listReportTemplates(projectId)]);
	const names = new Map(users.map((user) => [user.id, user.name]));
	const templateNames = new Map(templates.map((t) => [t.id, t.name]));
	return reports.map((report) => ({
		...n(report, ["summary"]),
		createdByName: names.get(report.createdByUserId) ?? null,
		templateName: report.templateId ? templateNames.get(report.templateId) ?? null : null
	}));
}
var listReports_createServerFn_handler = createServerRpc({
	id: "b694e15848bbfda53bac85dff1f870f149e6a0d751aec69fb3ac5ba8b92e5132",
	name: "listReports",
	filename: "src/serverFunctions/reports.ts"
}, (opts) => listReports.__executeServer(opts));
var listReports = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(listReportsSchema).handler(listReports_createServerFn_handler, async ({ data, context }) => {
	return { reports: await withDisplayNames((await ReportService.listReports({
		projectId: context.projectId,
		limit: data.limit ?? 20,
		offset: data.offset ?? 0
	})).reports, context.projectId) };
});
var getReport_createServerFn_handler = createServerRpc({
	id: "db353c04583ad0a099587b79c0a3518606b059e8ac631f4bd24d91f1ff34bc2a",
	name: "getReport",
	filename: "src/serverFunctions/reports.ts"
}, (opts) => getReport.__executeServer(opts));
var getReport = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(reportRefSchema).handler(getReport_createServerFn_handler, async ({ data, context }) => {
	const [withNames] = await withDisplayNames([await ReportService.getReport(context.projectId, data.reportId)], context.projectId);
	return withNames;
});
var shareReport_createServerFn_handler = createServerRpc({
	id: "48d30e240455ab974c90d5defd14655146a5a189317efb46dfb6f240cbd157b4",
	name: "shareReport",
	filename: "src/serverFunctions/reports.ts"
}, (opts) => shareReport.__executeServer(opts));
var shareReport = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(reportRefSchema).handler(shareReport_createServerFn_handler, async ({ data, context }) => {
	const report = await ReportService.shareReport({
		projectId: context.projectId,
		reportId: data.reportId,
		userId: context.userId,
		organizationId: context.organizationId
	});
	return {
		shareToken: report.shareToken,
		sharedAt: report.sharedAt
	};
});
var unshareReport_createServerFn_handler = createServerRpc({
	id: "55da6bb0f1efa6c7dab8088f8f282ab3d25d137bd67f9d333e7f90781a3dd032",
	name: "unshareReport",
	filename: "src/serverFunctions/reports.ts"
}, (opts) => unshareReport.__executeServer(opts));
var unshareReport = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(reportRefSchema).handler(unshareReport_createServerFn_handler, async ({ data, context }) => {
	const report = await ReportService.unshareReport({
		projectId: context.projectId,
		reportId: data.reportId,
		userId: context.userId,
		organizationId: context.organizationId
	});
	return {
		shareToken: report.shareToken,
		sharedAt: report.sharedAt
	};
});
var deleteReport_createServerFn_handler = createServerRpc({
	id: "4904ee1c0cc68d717399e853e8f38885a443e82e0ed6b6bfe992d1b21c3b6955",
	name: "deleteReport",
	filename: "src/serverFunctions/reports.ts"
}, (opts) => deleteReport.__executeServer(opts));
var deleteReport = createServerFn({ method: "POST" }).middleware(requireProjectContext).validator(reportRefSchema).handler(deleteReport_createServerFn_handler, async ({ data, context }) => {
	await ReportService.deleteReport(context.projectId, data.reportId);
	return { reportId: data.reportId };
});
//#endregion
export { deleteReport_createServerFn_handler, getReport_createServerFn_handler, listReports_createServerFn_handler, shareReport_createServerFn_handler, unshareReport_createServerFn_handler };
