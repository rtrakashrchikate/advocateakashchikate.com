import { A as app_schema_exports$1, C as ga4_schema_exports$1, D as report_templates_schema_exports$1, E as audit_schema_exports$1, O as reports_schema_exports$1, S as gsc_schema_exports$1, T as sam_schema_exports$1, _ as better_auth_schema_exports, a as local_seo_schema_exports, b as ai_visibility_schema_exports$1, c as gsc_schema_exports, d as sam_schema_exports, f as audit_schema_exports, g as app_schema_exports, h as project_context_schema_exports, j as better_auth_schema_exports$1, k as project_context_schema_exports$1, l as ga4_schema_exports, m as reports_schema_exports, o as ai_visibility_schema_exports, p as report_templates_schema_exports, q as getDatabaseProvider, r as pgDb, s as telemetry_schema_exports, u as billing_schema_exports, v as d1Db, w as billing_schema_exports$1, x as telemetry_schema_exports$1, y as local_seo_schema_exports$1 } from "./db-DUti_knk.js";
import "cloudflare:workers";
var { userOnboardingAnswers, userSignupCampaigns, accountDeletionRequests, guestAccounts, projects, savedKeywords, savedKeywordTags, savedKeywordTagAssignments, keywordMetrics, rankTrackingConfigs, rankTrackingKeywords, rankCheckRuns, rankSnapshots, organizationActivationState, projectActivationState, dashboardStepDismissals, backlinkSnapshots, dataRefreshClaims, crawlerCredentials, projectContextSections, projectCompetitors, projectKeyPages, projectResearchLog, reports, reportTemplates, audits, auditPages, auditIssues, auditLighthouseResults, samSessions, user, session, account, apikey, verification, organization, member, invitation, billingCustomerStatus, ga4Connections, gscConnections, telemetryState, aiTrackers, aiPrompts, aiRuns, aiObservations, aiSources, aiMatches, localRankTrackers, localRankChecks, localRankKeywords, localRankScans, localRankPoints, localRankBusinesses, localRankResults } = getDatabaseProvider() === "postgres" ? {
	...app_schema_exports,
	...project_context_schema_exports,
	...reports_schema_exports,
	...report_templates_schema_exports,
	...audit_schema_exports,
	...sam_schema_exports,
	...better_auth_schema_exports,
	...billing_schema_exports,
	...ga4_schema_exports,
	...gsc_schema_exports,
	...telemetry_schema_exports,
	...ai_visibility_schema_exports,
	...local_seo_schema_exports
} : {
	...app_schema_exports$1,
	...project_context_schema_exports$1,
	...reports_schema_exports$1,
	...report_templates_schema_exports$1,
	...audit_schema_exports$1,
	...sam_schema_exports$1,
	...better_auth_schema_exports$1,
	...billing_schema_exports$1,
	...ga4_schema_exports$1,
	...gsc_schema_exports$1,
	...telemetry_schema_exports$1,
	...ai_visibility_schema_exports$1,
	...local_seo_schema_exports$1
};
/**
* Run a set of write statements atomically on either backend.
*
* - D1: collected statements run via `db.batch([...])` (one atomic, ordered call).
* - Postgres: statements run sequentially inside `db.transaction(tx => ...)`
*   (atomic, and in array order to match D1's batch semantics).
*
* IMPORTANT: build statements from the `tx` handle the callback receives, NOT
* the module-level `db`. On Postgres, statements built from the outer `db` would
* execute outside the transaction. Returning the (unawaited) Drizzle query
* builders is enough; they are thenables on both dialects.
*/
async function runBatch(build) {
	if (getDatabaseProvider() === "postgres") {
		await pgDb.transaction(async (tx) => {
			for (const statement of build(tx)) await statement;
		});
		return;
	}
	const statements = build(d1Db);
	if (statements.length === 0) return;
	const batch = statements;
	await d1Db.batch(batch);
}
/**
* Chunk `items` into D1-safe batches and run each chunk atomically via
* `runBatch`. Shared by repositories that bulk-insert/update (audit pages,
* rank snapshots, etc.).
*/
async function executeInBatches(items, buildStatement) {
	for (let i = 0; i < items.length; i += 100) {
		const chunk = items.slice(i, i + 100);
		if (chunk.length === 0) continue;
		await runBatch((tx) => chunk.map((item) => buildStatement(tx, item)));
	}
}
//#endregion
export { auditPages as a, invitation as c, projects as d, user as f, auditLighthouseResults as i, member as l, runBatch as n, audits as o, userSignupCampaigns as p, auditIssues as r, crawlerCredentials as s, executeInBatches as t, organization as u };
