import { B as record, L as literal, R as number, V as string, c as MAX_HTML_BYTES, d as truncateToBytes, f as CLOUDFLARE_RENDER_TIMEOUT_MS, n as isCrawlableUrl, t as classifyFetch, u as readTextUpTo, z as object } from "./classify-fetch-YHmDctpP.js";
import { o as normalizeUrl } from "./url-utils-D6UsRC0J.js";
//#region src/server/lib/audit/rendered-page.ts
var cloudflareSchema = object({
	success: literal(true),
	result: string(),
	meta: object({
		status: number().int(),
		finalUrl: string().url(),
		headers: record(string(), string()).optional()
	})
});
var usageSchema = object({ key_metadata: object({ credits_consumed: number().nonnegative().optional() }).optional() });
var contextSchema = object({
	success: literal(true),
	type: literal("html"),
	html: string(),
	metadata: object({ finalUrl: string().url() }),
	finalDOMState: literal("loaded")
});
var MAX_RESPONSE_BYTES = 8 * MAX_HTML_BYTES;
async function readProviderJson(response) {
	return JSON.parse(await readTextUpTo(response, MAX_RESPONSE_BYTES));
}
/**
* The rendered HTML to analyze: the same first 1 MiB the direct crawl keeps,
* which still holds the metadata and navigation the audit reads.
*/
function usableHtml(url, finalUrl, html) {
	if (normalizeUrl(finalUrl, url) !== normalizeUrl(url, url)) throw new Error("Rendering returned a different URL");
	if (!html.trim()) throw new Error("Rendered HTML is empty");
	return truncateToBytes(html, MAX_HTML_BYTES);
}
/** Null when Cloudflare failed, was blocked, or saw an origin error. */
async function renderWithCloudflare(url, browser) {
	try {
		const response = await browser.quickAction("content", {
			url,
			cacheTTL: 0,
			gotoOptions: {
				waitUntil: "networkidle2",
				timeout: CLOUDFLARE_RENDER_TIMEOUT_MS
			}
		});
		if (!response.ok) {
			await response.body?.cancel();
			return null;
		}
		const data = cloudflareSchema.parse(await readProviderJson(response));
		const { status, finalUrl, headers } = data.meta;
		const html = usableHtml(url, finalUrl, data.result);
		const mitigated = Object.entries(headers ?? {}).some(([name, value]) => name.toLowerCase() === "cf-mitigated" && Boolean(value.trim()));
		if (status >= 400 || classifyFetch(status, mitigated, html.slice(0, 4e3)) !== "ok") return null;
		return {
			html,
			status
		};
	} catch {
		return null;
	}
}
async function renderWithContext(url, contextFetch) {
	const endpoint = new URL("https://api.context.dev/v1/web/scrape/html");
	endpoint.search = new URLSearchParams({
		url,
		maxAgeMs: "0",
		useMainContentOnly: "false",
		waitForMs: "1000",
		"pdf[shouldParse]": "false",
		"timeoutOpts[milliseconds]": "30000",
		"timeoutOpts[behavior]": "fail"
	}).toString();
	let html = null;
	let creditsUsed = null;
	let httpStatus = null;
	try {
		const response = await contextFetch(endpoint, { signal: AbortSignal.timeout(35e3) });
		httpStatus = response.status;
		const json = await readProviderJson(response);
		const usage = usageSchema.safeParse(json);
		creditsUsed = usage.success ? usage.data.key_metadata?.credits_consumed ?? null : null;
		if (!response.ok) throw new Error(`Rendering provider HTTP ${httpStatus}`);
		const data = contextSchema.parse(json);
		html = usableHtml(url, data.metadata.finalUrl, data.html);
	} catch {}
	return {
		html,
		credits: creditsUsed ?? (html ? 1 : 0),
		httpStatus
	};
}
/**
* Cloudflare Browser Run first, because it costs a fraction of Context. Context
* renders only the pages Cloudflare could not: a failure, a bot challenge, or
* an origin error.
*/
async function renderPage(url, options) {
	if (!isCrawlableUrl(url) || new URL(url).username || new URL(url).password) throw new Error("Invalid rendering target");
	if (options.browser) {
		const page = await renderWithCloudflare(url, options.browser);
		options.usage.cloudflareAttempts += 1;
		console.info("site_audit:render", {
			auditId: options.auditId,
			provider: "cloudflare",
			outcome: page ? "ok" : "fallback"
		});
		if (page) return page;
	}
	if (options.contextFetch) {
		const { html, credits, httpStatus } = await renderWithContext(url, options.contextFetch);
		options.usage.contextCredits += credits;
		console.info("site_audit:render", {
			auditId: options.auditId,
			provider: "context",
			httpStatus,
			creditsUsed: credits,
			outcome: html ? "ok" : "error"
		});
		if (html) return {
			html,
			status: null
		};
	}
	throw new Error("Unable to render this page");
}
var RenderedPageService = { renderPage };
//#endregion
export { RenderedPageService };
