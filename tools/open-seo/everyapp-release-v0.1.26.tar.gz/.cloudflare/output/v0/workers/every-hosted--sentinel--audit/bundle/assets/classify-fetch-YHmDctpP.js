import { $n as installLazyProp, $t as $ZodString, A as _length, At as $ZodISODate, Bn as $constructor, Bt as $ZodNever, C as _ipv6, Cn as _safeDecode, Ct as $ZodEmail, D as _isoTime, Dn as _safeParse, Dt as $ZodGUID, E as _isoDuration, En as _safeEncodeAsync, Et as $ZodExactOptional, F as _minLength, Fn as $ZodError, Ft as $ZodJWT, G as _slugify, Gn as NUMBER_FORMAT_RANGES, Gt as $ZodNumberFormat, H as _overwrite, Hn as config, I as _multipleOf, In as flattenError, It as $ZodKSUID, J as _superRefine, Jn as constantCatch, Jt as $ZodOptional, K as _startsWith, Kn as assignProp, L as _nanoid, Ln as formatError, M as _lt, Mt as $ZodISODuration, N as _lte, Nn as validate, Nt as $ZodISOTime, O as _jwt, On as _safeParseAsync, Ot as $ZodIPv4, P as _maxLength, Pn as validateAsync, Pt as $ZodIntersection, Q as _ulid, Qn as hide, Qt as $ZodRecord, R as _never, Rt as $ZodLiteral, S as _ipv4, Sn as _parseAsync, St as $ZodE164, T as _isoDateTime, Tn as _safeEncode, Tt as $ZodEnum, U as _refine, Un as globalConfig, Ut as $ZodNullable, V as _number, Vt as $ZodNonOptional, W as _regex, Wn as BIGINT_FORMAT_RANGES, Wt as $ZodNumber, X as _toUpperCase, Xn as extend, Xt as $ZodPrefault, Y as _toLowerCase, Yn as derived, Yt as $ZodPipe, Z as _trim, Zn as getEnumValues, Zt as $ZodReadonly, _ as _gt, _n as _decode, _t as $ZodCatch, a as _boolean, an as $ZodUUID, ar as normalizeParams, at as _uuidv6, b as _includes, bn as _encodeAsync, cn as $ZodUnknown, cr as parsedType, d as _custom, dn as base64urlCharset, dr as rawShape, dt as $ZodBase64URL, en as $ZodStringFormat, er as issue, et as _unknown, fn as standardProps, fr as required, ft as $ZodBoolean, g as _endsWith, gn as number$1, gt as $ZodCUID2, h as _emoji, hn as integer, hr as stringifyPrimitive, ht as $ZodCUID, i as _base64url, in as $ZodURL, ir as mergeDefs, it as _uuidv4, j as _lowercase, jt as $ZodISODateTime, k as _ksuid, kt as $ZodIPv6, l as _cuid, ln as $ZodXID, lr as partial, lt as $ZodArray, m as _email, mn as base64url, mr as shallowClone, mt as $ZodCIDRv6, n as _array, nn as $ZodType, nr as jsonStringifyReplacer, nt as _url, o as _cidrv4, or as omit, ot as _uuidv7, p as _e164, pn as base64$1, pr as safeExtend, pt as $ZodCIDRv4, q as _string, qn as clone, qt as $ZodObjectJIT, r as _base64, rn as $ZodULID, rr as merge, rt as _uuid, s as _cidrv6, sn as $ZodUnion, sr as own, st as _xid, tn as $ZodTransform, tr as joinValues, tt as _uppercase, u as _cuid2, un as base64Charset, ur as pick, ut as $ZodBase64, v as _gte, vn as _decodeAsync, vt as $ZodCodec, w as _isoDate, wn as _safeDecodeAsync, wt as $ZodEmoji, x as _int, xn as _parse, xt as $ZodDefault, y as _guid, yn as _encode, yt as $ZodCustom, z as _normalize, zn as $ZodEncodeError, zt as $ZodNanoID } from "./api-Cna0nU1W.js";
//#region node_modules/.pnpm/zod@4.6.7/node_modules/zod/v4/core/memoizer.js
var $ZodCyclicError = class extends Error {
	constructor() {
		super(`Cannot parse a reference cycle that closes through a transform`);
		this.name = "ZodCyclicError";
	}
};
/** Keyed off the context object every schema in one parse call already shares. */
var STATE = "~memo";
var NO_ISSUES = [];
function isRef(value) {
	return value !== null && typeof value === "object";
}
function cloneIssues(issues) {
	return issues.map((iss) => iss.path ? {
		...iss,
		path: iss.path.slice()
	} : { ...iss });
}
var recursive = /*@__PURE__*/ new WeakMap();
/** What the walk established, in order of certainty: ordered so the strongest answer among children wins. */
var NONE = 0;
var ASSUMED = 1;
var PROVEN = 2;
/** Whether this schema's subtree contains a cycle, so one parse can re-enter it. */
function isRecursive(inst, stack, resolve) {
	const cached = recursive.get(inst);
	if (cached !== void 0) return cached ? PROVEN : NONE;
	if (stack.has(inst)) return PROVEN;
	stack.add(inst);
	let result = NONE;
	const check = (child) => {
		if (result !== PROVEN && child?._zod) {
			const answer = isRecursive(child, stack, resolve);
			if (answer > result) result = answer;
		}
	};
	const shape = (sh, spread) => {
		let answer = NONE;
		for (const key of Reflect.ownKeys(sh)) {
			const desc = Object.getOwnPropertyDescriptor(sh, key);
			if (spread && !desc.enumerable) continue;
			const child = desc.get ? ASSUMED : desc.value?._zod ? isRecursive(desc.value, stack, resolve) : NONE;
			if (child > answer) answer = child;
		}
		return answer;
	};
	const merge = (answer) => {
		if (answer > result) result = answer;
	};
	const def = inst._zod.def;
	switch (def.type) {
		case "object": {
			const raw = rawShape(def);
			merge(raw ? shape(raw, true) : ASSUMED);
			check(def.catchall);
			break;
		}
		case "array":
			check(def.element);
			break;
		case "tuple":
			for (const el of def.items) check(el);
			check(def.rest);
			break;
		case "record":
		case "map":
			check(def.keyType);
			check(def.valueType);
			break;
		case "set":
			check(def.valueType);
			break;
		case "union":
			for (const el of def.options) check(el);
			break;
		case "intersection":
			check(def.left);
			check(def.right);
			break;
		case "optional":
		case "nullable":
		case "default":
		case "prefault":
		case "catch":
		case "readonly":
		case "nonoptional":
		case "promise":
		case "success":
			check(def.innerType);
			break;
		case "pipe":
			check(def.in);
			check(def.out);
			break;
		case "function":
			check(def.input);
			check(def.output);
			break;
		case "lazy": {
			const inner = def._cachedInner ?? (resolve ? inst._zod.innerType : void 0);
			merge(inner ? isRecursive(inner, stack, false) : ASSUMED);
			break;
		}
		case "template_literal":
		case "string":
		case "number":
		case "int":
		case "boolean":
		case "bigint":
		case "symbol":
		case "undefined":
		case "null":
		case "void":
		case "never":
		case "any":
		case "unknown":
		case "date":
		case "nan":
		case "enum":
		case "literal":
		case "file":
		case "transform":
		case "custom": break;
		default: for (const key in def) {
			const desc = Object.getOwnPropertyDescriptor(def, key);
			if (!desc || desc.get) continue;
			const value = desc.value;
			if (!value || typeof value !== "object") continue;
			if (value._zod) check(value);
			else if (Array.isArray(value)) for (const el of value) check(el);
		}
	}
	stack.delete(inst);
	return settle(inst, result);
}
/** An assumed answer must not outlive the resolution that settles it, so only a certain one is cached. */
function settle(inst, answer) {
	if (answer !== ASSUMED) recursive.set(inst, answer === PROVEN);
	return answer;
}
function bucketFor(state, inst) {
	let bucket = state.buckets.get(inst);
	if (!bucket) {
		bucket = /* @__PURE__ */ new WeakMap();
		state.buckets.set(inst, bucket);
	}
	return bucket;
}
var handoff;
var open = [];
var memo = {
	alloc(_inst, payload, empty) {
		const bucket = handoff;
		if (!bucket) return empty;
		handoff = void 0;
		const entry = {
			value: empty,
			issues: null
		};
		bucket.set(payload.value, entry);
		open.push(entry);
		return empty;
	},
	guard(inst) {
		var _a;
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred.push(() => {
			const base = inst._zod.parse;
			const wrapped = (payload, ctx) => {
				if (ctx.direction !== "backward" && isBackEdge(ctx, payload.value)) throw new $ZodCyclicError();
				return base(payload, ctx);
			};
			inst._zod.parse = wrapped;
			if (inst._zod.run === base) inst._zod.run = wrapped;
		});
	},
	attach(inst) {
		var _a;
		let isRecursiveInst;
		let rechecked = false;
		let lastCtx;
		let lastBucket;
		(_a = inst._zod).deferred ?? (_a.deferred = []);
		inst._zod.deferred.push(() => {
			const base = inst._zod.parse;
			const wrapped = (payload, ctx) => {
				if (isRecursiveInst === void 0) {
					const walked = isRecursive(inst, /* @__PURE__ */ new Set(), false);
					if (walked === NONE) {
						inst._zod.parse = base;
						if (inst._zod.run === wrapped) inst._zod.run = base;
						return base(payload, ctx);
					}
					if (walked === PROVEN || rechecked) isRecursiveInst = true;
					else rechecked = true;
				}
				const input = payload.value;
				if (!isRef(input)) return base(payload, ctx);
				let state = ctx[STATE];
				if (!state) {
					state = {
						buckets: /* @__PURE__ */ new WeakMap(),
						backEdges: void 0
					};
					ctx[STATE] = state;
				}
				let bucket;
				if (lastCtx === ctx) bucket = lastBucket;
				else {
					bucket = bucketFor(state, inst);
					lastCtx = ctx;
					lastBucket = bucket;
				}
				const hit = bucket.get(input);
				if (hit) {
					payload.value = hit.value;
					if (hit.issues) {
						if (hit.issues.length) payload.issues.push(...cloneIssues(hit.issues));
					} else {
						payload.memo = true;
						state.backEdges ?? (state.backEdges = /* @__PURE__ */ new WeakSet());
						state.backEdges.add(hit.value);
					}
					return payload;
				}
				handoff = bucket;
				const depth = open.length;
				const result = base(payload, ctx);
				handoff = void 0;
				const entry = open.length > depth ? open.pop() : void 0;
				if (result instanceof Promise) return result.then((r) => {
					if (entry) entry.issues = r.issues.length ? cloneIssues(r.issues) : NO_ISSUES;
					return r;
				});
				if (entry) entry.issues = result.issues.length ? cloneIssues(result.issues) : NO_ISSUES;
				return result;
			};
			inst._zod.parse = wrapped;
			if (inst._zod.run === base) inst._zod.run = wrapped;
		});
	}
};
/** The memoizer that gives containers cycle support. `zod` installs it by default; `zod/mini` opts in with `config({ memoizer: memoizer() })`. */
function memoizer() {
	return memo;
}
/** Whether this value is a node a back-edge resolved to before it finished. */
function isBackEdge(ctx, value) {
	const backEdges = ctx[STATE]?.backEdges;
	return backEdges !== void 0 && isRef(value) && backEdges.has(value);
}
//#endregion
//#region node_modules/.pnpm/zod@4.6.7/node_modules/zod/v4/locales/en.js
var error = () => {
	const Sizable = {
		string: {
			unit: "characters",
			verb: "to have"
		},
		file: {
			unit: "bytes",
			verb: "to have"
		},
		array: {
			unit: "items",
			verb: "to have"
		},
		set: {
			unit: "items",
			verb: "to have"
		},
		map: {
			unit: "entries",
			verb: "to have"
		}
	};
	function getSizing(origin) {
		return Sizable[origin] ?? null;
	}
	const FormatDictionary = {
		regex: "input",
		email: "email address",
		url: "URL",
		emoji: "emoji",
		uuid: "UUID",
		uuidv4: "UUIDv4",
		uuidv6: "UUIDv6",
		nanoid: "nanoid",
		guid: "GUID",
		cuid: "cuid",
		cuid2: "cuid2",
		ulid: "ULID",
		xid: "XID",
		ksuid: "KSUID",
		datetime: "ISO datetime",
		date: "ISO date",
		time: "ISO time",
		duration: "ISO duration",
		ipv4: "IPv4 address",
		ipv6: "IPv6 address",
		mac: "MAC address",
		cidrv4: "IPv4 range",
		cidrv6: "IPv6 range",
		base64: "base64-encoded string",
		base64url: "base64url-encoded string",
		json_string: "JSON string",
		e164: "E.164 number",
		currency_code: "currency code",
		credit_card: "credit card number",
		iban: "IBAN",
		jwt: "JWT",
		template_literal: "input"
	};
	const TypeDictionary = { nan: "NaN" };
	function getTypeName(type, input) {
		if (type === "number" && typeof input === "number" && !Number.isFinite(input)) return String(input);
		return TypeDictionary[type] ?? type;
	}
	return (issue) => {
		switch (issue.code) {
			case "invalid_type": return `Invalid input: expected ${getTypeName(issue.expected)}, received ${getTypeName(parsedType(issue.input), issue.input)}`;
			case "invalid_value":
				if (issue.values.length === 1) return `Invalid input: expected ${stringifyPrimitive(issue.values[0])}`;
				return `Invalid option: expected one of ${joinValues(issue.values, "|")}`;
			case "too_big": {
				const adj = issue.exact ? "exactly " : issue.inclusive ? "<=" : "<";
				const sizing = getSizing(issue.origin);
				if (sizing) return `Too big: expected ${issue.origin ?? "value"} to have ${adj}${issue.maximum.toString()} ${sizing.unit ?? "elements"}`;
				return `Too big: expected ${issue.origin ?? "value"} to be ${adj}${issue.maximum.toString()}`;
			}
			case "too_small": {
				const adj = issue.exact ? "exactly " : issue.inclusive ? ">=" : ">";
				const sizing = getSizing(issue.origin);
				if (sizing) return `Too small: expected ${issue.origin} to have ${adj}${issue.minimum.toString()} ${sizing.unit}`;
				return `Too small: expected ${issue.origin} to be ${adj}${issue.minimum.toString()}`;
			}
			case "invalid_format": {
				const _issue = issue;
				if (_issue.format === "starts_with") return `Invalid string: must start with "${_issue.prefix}"`;
				if (_issue.format === "ends_with") return `Invalid string: must end with "${_issue.suffix}"`;
				if (_issue.format === "includes") return `Invalid string: must include "${_issue.includes}"`;
				if (_issue.format === "regex") return `Invalid string: must match pattern ${_issue.pattern}`;
				return `Invalid ${FormatDictionary[_issue.format] ?? issue.format}`;
			}
			case "not_multiple_of": return `Invalid number: must be a multiple of ${issue.divisor}`;
			case "unrecognized_keys": return `Unrecognized key${issue.keys.length > 1 ? "s" : ""}: ${joinValues(issue.keys, ", ")}`;
			case "invalid_key": return `Invalid key in ${issue.origin}`;
			case "invalid_union":
				if (issue.options && Array.isArray(issue.options) && issue.options.length > 0) return `Invalid discriminator value. Expected ${issue.options.map((o) => `'${o}'`).join(" | ")}`;
				if (issue.inclusive === false) return "Invalid input: more than one option matched";
				return "Invalid input";
			case "invalid_element": return `Invalid value in ${issue.origin}`;
			default: return `Invalid input`;
		}
	};
};
function en_default() {
	return { localeError: error() };
}
//#endregion
//#region node_modules/.pnpm/zod@4.6.7/node_modules/zod/v4/core/registries.js
var _a;
var $ZodRegistry = class {
	constructor() {
		this._map = /* @__PURE__ */ new WeakMap();
		this._idmap = /* @__PURE__ */ new Map();
	}
	add(schema, ..._meta) {
		const meta = _meta[0];
		this._map.set(schema, meta);
		if (meta && typeof meta === "object" && "id" in meta) this._idmap.set(meta.id, schema);
		return this;
	}
	clear() {
		this._map = /* @__PURE__ */ new WeakMap();
		this._idmap = /* @__PURE__ */ new Map();
		return this;
	}
	remove(schema) {
		const meta = this._map.get(schema);
		if (meta && typeof meta === "object" && "id" in meta) this._idmap.delete(meta.id);
		this._map.delete(schema);
		return this;
	}
	get(schema) {
		const p = schema._zod.parent;
		if (p) {
			const pm = { ...this.get(p) ?? {} };
			delete pm.id;
			const f = {
				...pm,
				...this._map.get(schema)
			};
			return Object.keys(f).length ? f : void 0;
		}
		return this._map.get(schema);
	}
	has(schema) {
		return this._map.has(schema);
	}
};
function registry() {
	return new $ZodRegistry();
}
(_a = globalThis).__zod_globalRegistry ?? (_a.__zod_globalRegistry = registry());
var globalRegistry = globalThis.__zod_globalRegistry;
//#endregion
//#region node_modules/.pnpm/zod@4.6.7/node_modules/zod/v4/core/to-json-schema.js
function assignProps(target, ...sources) {
	for (const source of sources) for (const key of Reflect.ownKeys(source)) if (Object.prototype.propertyIsEnumerable.call(source, key)) assignProp(target, key, source[key]);
	return target;
}
function initializeContext(params) {
	let target = params?.target ?? "draft-2020-12";
	if (target === "draft-4") target = "draft-04";
	if (target === "draft-7") target = "draft-07";
	return {
		processors: params.processors ?? {},
		metadataRegistry: params?.metadata ?? globalRegistry,
		target,
		unrepresentable: params?.unrepresentable ?? "throw",
		override: params?.override ?? (() => {}),
		io: params?.io ?? "output",
		counter: 0,
		seen: /* @__PURE__ */ new Map(),
		sharedDefsExtractedFor: void 0,
		sharedEmitDoneFor: void 0,
		cycles: params?.cycles ?? "ref",
		reused: params?.reused ?? "inline",
		intersections: [],
		deferred: [],
		external: params?.external ?? void 0
	};
}
/**
* Applies the `unrepresentable` setting at a site that has no JSON Schema equivalent. Throws
* `message` unless the setting (or the handler's return value) says otherwise. Returns `true` if a
* custom JSON Schema was written into `json`, in which case the caller must not write its own.
*/
function handleUnrepresentable(schema, ctx, json, params, message) {
	const result = typeof ctx.unrepresentable === "function" ? ctx.unrepresentable({
		zodSchema: schema,
		path: params.path,
		message
	}) : ctx.unrepresentable;
	if (result === "any") return false;
	if (result === void 0 || result === "throw") throw new Error(message);
	Object.assign(json, result);
	return true;
}
function processSchema(schema, ctx, _params = {
	path: [],
	schemaPath: []
}) {
	var _a;
	const def = schema._zod.def;
	const seen = ctx.seen.get(schema);
	if (seen) {
		seen.count++;
		if (_params.schemaPath.includes(schema)) seen.cycle = _params.path;
		return seen.schema;
	}
	const result = {
		schema: {},
		count: 1,
		cycle: void 0,
		path: _params.path
	};
	ctx.seen.set(schema, result);
	ctx.sharedDefsExtractedFor = void 0;
	ctx.sharedEmitDoneFor = void 0;
	const overrideSchema = schema._zod.toJSONSchema?.();
	if (overrideSchema) result.schema = overrideSchema;
	else {
		const params = {
			..._params,
			schemaPath: [..._params.schemaPath, schema],
			path: _params.path
		};
		if (schema._zod.processJSONSchema) schema._zod.processJSONSchema(ctx, result.schema, params);
		else {
			const _json = result.schema;
			const processor = ctx.processors[def.type];
			if (!processor) throw new Error(`[toJSONSchema]: Non-representable type encountered: ${def.type}`);
			processor(schema, ctx, _json, params);
		}
		const parent = schema._zod.parent;
		if (parent) {
			if (!result.ref) result.ref = parent;
			processSchema(parent, ctx, params);
			ctx.seen.get(parent).isParent = true;
		}
	}
	const meta = ctx.metadataRegistry.get(schema);
	if (meta) assignProps(result.schema, meta);
	if (ctx.io === "input" && isTransforming(schema)) {
		delete result.schema.examples;
		delete result.schema.default;
	}
	if (ctx.io === "input" && "_prefault" in result.schema) (_a = result.schema).default ?? (_a.default = result.schema._prefault);
	delete result.schema._prefault;
	return ctx.seen.get(schema).schema;
}
function encodeJSONPointerSegment(segment) {
	return segment.replace(/~/g, "~0").replace(/\//g, "~1");
}
function extractDefs(ctx, schema) {
	const root = ctx.seen.get(schema);
	if (!root) throw new Error("Unprocessed schema. This is a bug in Zod.");
	if (ctx.external && ctx.sharedDefsExtractedFor === ctx.external) return;
	const idToSchema = /* @__PURE__ */ new Map();
	for (const entry of ctx.seen.entries()) {
		const id = ctx.metadataRegistry.get(entry[0])?.id;
		if (id) {
			const existing = idToSchema.get(id);
			if (existing && existing !== entry[0]) throw new Error(`Duplicate schema id "${id}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
			idToSchema.set(id, entry[0]);
		}
	}
	const makeURI = (entry) => {
		const defsSegment = ctx.target === "draft-2020-12" ? "$defs" : "definitions";
		if (ctx.external) {
			const externalId = ctx.external.registry.get(entry[0])?.id;
			const uriGenerator = ctx.external.uri ?? ((id) => id);
			if (externalId) return { ref: uriGenerator(externalId) };
			const id = entry[1].defId ?? entry[1].schema.id ?? `schema${ctx.counter++}`;
			entry[1].defId = id;
			return {
				defId: id,
				ref: `${uriGenerator("__shared")}#/${defsSegment}/${encodeJSONPointerSegment(id)}`
			};
		}
		const uriPrefix = `#`;
		const defUriPrefix = `${uriPrefix}/${defsSegment}/`;
		if (entry[1] === root && !entry[1].schema.id) return { ref: uriPrefix };
		const defId = entry[1].schema.id ?? `__schema${ctx.counter++}`;
		return {
			defId,
			ref: defUriPrefix + encodeJSONPointerSegment(defId)
		};
	};
	const extractToDef = (entry) => {
		if (entry[1].schema.$ref) return;
		const seen = entry[1];
		const { ref, defId } = makeURI(entry);
		seen.def = { ...seen.schema };
		if (defId) seen.defId = defId;
		const schema = seen.schema;
		for (const key in schema) delete schema[key];
		schema.$ref = ref;
	};
	if (ctx.cycles === "throw") for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (seen.cycle) throw new Error(`Cycle detected: #/${seen.cycle?.join("/")}/<root>

Set the \`cycles\` parameter to \`"ref"\` to resolve cyclical schemas with defs.`);
	}
	for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (schema === entry[0]) {
			extractToDef(entry);
			continue;
		}
		if (ctx.external) {
			const ext = ctx.external.registry.get(entry[0])?.id;
			if (schema !== entry[0] && ext) {
				extractToDef(entry);
				continue;
			}
		}
		if (ctx.metadataRegistry.get(entry[0])?.id) {
			extractToDef(entry);
			continue;
		}
		if (seen.cycle) {
			extractToDef(entry);
			continue;
		}
		if (seen.count > 1) {
			if (ctx.reused === "ref") extractToDef(entry);
		}
	}
	if (ctx.external) ctx.sharedDefsExtractedFor = ctx.external;
}
/** Rewrites `anyOf: [{type: "a"}, {type: "b"}]` to `type: ["a", "b"]`, which every JSON Schema draft treats as equivalent and most consumers render far better for the nullable case. Only branches that are a bare type assertion qualify \u2014 anything carrying a constraint, `$ref`, `const` or metadata is left alone. Runs after `flattenRef`, so a branch an override decorated or `$defs` extraction turned into a `$ref` is no longer bare and correctly stays in `anyOf`. `oneOf` is excluded: `integer` and `number` overlap, so "exactly one" and "at least one" are not the same there. OpenAPI 3.0 is excluded: its `type` must be a single string. */
function compactTypeUnion(schema) {
	const options = schema.anyOf;
	if (!Array.isArray(options) || options.length === 0 || schema.type !== void 0) return;
	const types = [];
	for (const option of options) {
		if (!option || typeof option !== "object") return;
		compactTypeUnion(option);
		const keys = Object.keys(option);
		if (keys.length !== 1 || keys[0] !== "type") return;
		const type = option.type;
		for (const member of Array.isArray(type) ? type : [type]) {
			if (typeof member !== "string") return;
			if (!types.includes(member)) types.push(member);
		}
	}
	delete schema.anyOf;
	schema.type = types.length === 1 ? types[0] : types;
}
/** Keywords `foldIntersection` knows how to combine. Anything else \u2014 `$ref`, `patternProperties`,
* an annotation like `description` \u2014 makes a member unfoldable, so a constraint this does not
* understand leaves the `allOf` alone instead of being silently dropped or misattributed. */
var FOLDABLE_KEYS = /* @__PURE__ */ new Set([
	"type",
	"properties",
	"required",
	"additionalProperties"
]);
var UNION_KEYS = ["oneOf", "anyOf"];
/** A member's constraint on a key it does not declare itself. A `catchall` states one; `false`, an absent `additionalProperties`, and the empty schema a loose object emits state nothing. */
function undeclaredConstraint(member) {
	const extra = member.additionalProperties;
	if (extra === void 0 || extra === false || typeof extra !== "object" || extra === null) return null;
	return Object.keys(extra).length ? extra : null;
}
/** Combines object members into the single object they describe together, or returns `null` if any of them carries a keyword outside {@link FOLDABLE_KEYS}. */
function foldObjects(members) {
	const objects = [];
	for (const member of members) {
		if (typeof member !== "object" || member.type !== "object") return null;
		for (const key in member) if (!FOLDABLE_KEYS.has(key)) return null;
		objects.push(member);
	}
	const properties = {};
	const required = /* @__PURE__ */ new Set();
	for (const object of objects) {
		for (const key in object.properties) {
			if (Object.prototype.hasOwnProperty.call(properties, key)) continue;
			const parts = [];
			for (const other of objects) {
				const part = other.properties?.[key] ?? undeclaredConstraint(other);
				if (part === null || part === void 0) continue;
				if (!parts.some((seen) => JSON.stringify(seen) === JSON.stringify(part))) parts.push(part);
			}
			const merged = parts.length === 1 ? parts[0] : foldObjects(parts) ?? { allOf: parts };
			assignProp(properties, key, merged);
		}
		for (const key of object.required ?? []) required.add(key);
	}
	const folded = {
		type: "object",
		properties
	};
	if (required.size) folded.required = [...required];
	if (objects.every((object) => object.additionalProperties === false)) folded.additionalProperties = false;
	else {
		const constraints = [];
		for (const object of objects) {
			const constraint = undeclaredConstraint(object);
			if (constraint && !constraints.some((seen) => JSON.stringify(seen) === JSON.stringify(constraint))) constraints.push(constraint);
		}
		if (constraints.length === 1) folded.additionalProperties = constraints[0];
		else if (constraints.length > 1) folded.additionalProperties = { allOf: constraints };
	}
	return folded;
}
/** `additionalProperties` in an `allOf` member sees only that member's own `properties`, so two
* closed object members reject each other's keys and the schema validates nothing. Zod's parser
* pools the key sets instead \u2014 `handleIntersectionResults` reports a key as unrecognized only when
* *every* side rejects it \u2014 so the emitted schema has to pool them too, and folding the members
* into one object is the encoding that says so on every target.
*
* This runs from `finalize`, after `extractDefs`, which is what keeps it clear of the `$ref`
* machinery: a member extracted into `$defs` is already a `$ref` by now and declines to fold, so it
* keeps its reference and its own closedness rather than being inlined as a stale copy. */
function foldIntersection(json) {
	const allOf = json.allOf;
	if (!Array.isArray(allOf) || allOf.length < 2) return;
	for (const key of FOLDABLE_KEYS) if (key in json) return;
	const unions = allOf.filter((m) => UNION_KEYS.some((k) => Array.isArray(m[k])));
	let folded = null;
	if (!unions.length) folded = foldObjects(allOf);
	else {
		const union = unions[0];
		const keyword = UNION_KEYS.find((k) => Array.isArray(union[k]));
		if (Object.keys(union).length !== 1) return;
		const rest = allOf.filter((m) => m !== union);
		const branches = union[keyword].map((branch) => foldObjects([...rest, branch]));
		if (branches.some((b) => !b)) return;
		folded = { [keyword]: branches };
	}
	if (!folded) return;
	delete json.allOf;
	assignProps(json, folded);
}
function finalize(ctx, schema) {
	const root = ctx.seen.get(schema);
	if (!root) throw new Error("Unprocessed schema. This is a bug in Zod.");
	const flattenRef = (zodSchema) => {
		const seen = ctx.seen.get(zodSchema);
		if (seen.ref === null) return;
		const schema = seen.def ?? seen.schema;
		const _cached = { ...schema };
		const ref = seen.ref;
		seen.ref = null;
		if (ref) {
			flattenRef(ref);
			const refSeen = ctx.seen.get(ref);
			const refSchema = refSeen.schema;
			if (refSchema.$ref && (ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0")) {
				schema.allOf = schema.allOf ?? [];
				schema.allOf.push(refSchema);
			} else assignProps(schema, refSchema);
			assignProps(schema, _cached);
			if (zodSchema._zod.parent === ref) for (const key in schema) {
				if (key === "$ref" || key === "allOf") continue;
				if (!(key in _cached)) delete schema[key];
			}
			if (refSchema.$ref && refSeen.def) for (const key in schema) {
				if (key === "$ref" || key === "allOf") continue;
				if (key in refSeen.def && JSON.stringify(schema[key]) === JSON.stringify(refSeen.def[key])) delete schema[key];
			}
		}
		const parent = zodSchema._zod.parent;
		if (parent && parent !== ref) {
			flattenRef(parent);
			const parentSeen = ctx.seen.get(parent);
			if (parentSeen?.schema.$ref) {
				schema.$ref = parentSeen.schema.$ref;
				if (parentSeen.def) for (const key in schema) {
					if (key === "$ref" || key === "allOf") continue;
					if (key in parentSeen.def && JSON.stringify(schema[key]) === JSON.stringify(parentSeen.def[key])) delete schema[key];
				}
			}
		}
		ctx.override({
			zodSchema,
			jsonSchema: schema,
			path: seen.path ?? []
		});
	};
	if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) {
		for (const entry of [...ctx.seen.entries()].reverse()) flattenRef(entry[0]);
		if (ctx.target !== "openapi-3.0") for (const entry of ctx.seen.entries()) compactTypeUnion(entry[1].def ?? entry[1].schema);
		for (const rewrite of ctx.deferred) rewrite();
		if (ctx.intersections.length) {
			const carriers = /* @__PURE__ */ new Map();
			for (const seen of ctx.seen.values()) for (const json of [seen.schema, seen.def]) {
				const allOf = json?.allOf;
				if (!Array.isArray(allOf)) continue;
				const existing = carriers.get(allOf);
				if (existing) existing.push(json);
				else carriers.set(allOf, [json]);
			}
			for (const allOf of ctx.intersections) for (const json of carriers.get(allOf) ?? []) foldIntersection(json);
		}
	}
	const result = {};
	if (ctx.target === "draft-2020-12") result.$schema = "https://json-schema.org/draft/2020-12/schema";
	else if (ctx.target === "draft-07") result.$schema = "http://json-schema.org/draft-07/schema#";
	else if (ctx.target === "draft-04") result.$schema = "http://json-schema.org/draft-04/schema#";
	else if (ctx.target === "openapi-3.0") {}
	if (ctx.external?.uri) {
		const id = ctx.external.registry.get(schema)?.id;
		if (!id) throw new Error("Schema is missing an `id` property");
		result.$id = ctx.external.uri(id);
	}
	assignProps(result, root.defId ? root.schema : root.def ?? root.schema);
	const rootMetaId = ctx.metadataRegistry.get(schema)?.id;
	if (rootMetaId !== void 0 && result.id === rootMetaId) delete result.id;
	const defs = ctx.external?.defs ?? {};
	if (!ctx.external || ctx.sharedEmitDoneFor !== ctx.external) for (const entry of ctx.seen.entries()) {
		const seen = entry[1];
		if (seen.def && seen.defId) {
			if (seen.def.id === seen.defId) delete seen.def.id;
			assignProp(defs, seen.defId, seen.def);
		}
	}
	if (ctx.external) ctx.sharedEmitDoneFor = ctx.external;
	if (ctx.external) {} else if (Object.keys(defs).length > 0) {
		if (ctx.target === "draft-2020-12") result.$defs = defs;
		else result.definitions = defs;
	}
	try {
		const finalized = JSON.parse(JSON.stringify(result));
		Object.defineProperty(finalized, "~standard", {
			value: {
				...schema["~standard"],
				jsonSchema: {
					input: createStandardJSONSchemaMethod(schema, "input", ctx.processors),
					output: createStandardJSONSchemaMethod(schema, "output", ctx.processors)
				}
			},
			enumerable: false,
			writable: false
		});
		return finalized;
	} catch (_err) {
		throw new Error("Error converting schema to JSON.");
	}
}
function isTransforming(_schema, _ctx) {
	const ctx = _ctx ?? { seen: /* @__PURE__ */ new Set() };
	if (ctx.seen.has(_schema)) return false;
	ctx.seen.add(_schema);
	const def = _schema._zod.def;
	if (def.type === "transform") return true;
	if (def.type === "array") return isTransforming(def.element, ctx);
	if (def.type === "set") return isTransforming(def.valueType, ctx);
	if (def.type === "lazy") return isTransforming(def.getter(), ctx);
	if (def.type === "promise" || def.type === "optional" || def.type === "nonoptional" || def.type === "nullable" || def.type === "readonly" || def.type === "default" || def.type === "prefault" || def.type === "catch") return isTransforming(def.innerType, ctx);
	if (def.type === "intersection") return isTransforming(def.left, ctx) || isTransforming(def.right, ctx);
	if (def.type === "record" || def.type === "map") return isTransforming(def.keyType, ctx) || isTransforming(def.valueType, ctx);
	if (def.type === "pipe") {
		if (_schema._zod.traits.has("$ZodCodec")) return true;
		return isTransforming(def.in, ctx) || isTransforming(def.out, ctx);
	}
	if (def.type === "object") {
		for (const key in def.shape) if (isTransforming(def.shape[key], ctx)) return true;
		return false;
	}
	if (def.type === "union") {
		for (const option of def.options) if (isTransforming(option, ctx)) return true;
		return false;
	}
	if (def.type === "tuple") {
		for (const item of def.items) if (isTransforming(item, ctx)) return true;
		if (def.rest && isTransforming(def.rest, ctx)) return true;
		return false;
	}
	return false;
}
/**
* Creates a toJSONSchema method for a schema instance.
* This encapsulates the logic of initializing context, processing, extracting defs, and finalizing.
*/
var createToJSONSchemaMethod = (schema, processors = {}) => (params) => {
	const ctx = initializeContext({
		...params,
		processors
	});
	processSchema(schema, ctx);
	extractDefs(ctx, schema);
	return finalize(ctx, schema);
};
var createStandardJSONSchemaMethod = (schema, io, processors = {}) => (params) => {
	const { libraryOptions, target } = params ?? {};
	const ctx = initializeContext({
		...libraryOptions ?? {},
		target,
		io,
		processors
	});
	processSchema(schema, ctx);
	extractDefs(ctx, schema);
	return finalize(ctx, schema);
};
//#endregion
//#region node_modules/.pnpm/zod@4.6.7/node_modules/zod/v4/core/json-schema-processors.js
var narrowMin = (agg, key, value) => {
	if (agg[key] === void 0 || value > agg[key]) agg[key] = value;
};
var narrowMax = (agg, key, value) => {
	if (agg[key] === void 0 || value < agg[key]) agg[key] = value;
};
var narrowBoth = (agg, value) => {
	narrowMin(agg, "minimum", value);
	narrowMax(agg, "maximum", value);
};
var addDivisor = (agg, value) => {
	agg.multipleOf ?? (agg.multipleOf = []);
	if (!agg.multipleOf.includes(value)) agg.multipleOf.push(value);
};
var addPattern = (agg, pattern) => {
	agg.patterns ?? (agg.patterns = /* @__PURE__ */ new Set());
	agg.patterns.add(pattern);
};
var intersectMime = (agg, mime) => {
	agg.mime = agg.mime ? agg.mime.filter((m) => mime.includes(m)) : [...mime];
};
var setFormat = (agg, format) => {
	agg.format = format;
	if (format.includes("int")) agg.isInt = true;
};
var minContributor = (agg, def) => narrowMin(agg, "minimum", def.minimum);
var maxContributor = (agg, def) => narrowMax(agg, "maximum", def.maximum);
var formatContributor = (ranges) => (agg, def) => {
	setFormat(agg, def.format);
	const [minimum, maximum] = ranges[def.format];
	narrowMin(agg, "minimum", minimum);
	narrowMax(agg, "maximum", maximum);
};
var contributors = {
	greater_than: (agg, def) => narrowMin(agg, def.inclusive ? "minimum" : "exclusiveMinimum", def.value),
	less_than: (agg, def) => narrowMax(agg, def.inclusive ? "maximum" : "exclusiveMaximum", def.value),
	multiple_of: (agg, def) => addDivisor(agg, def.value),
	number_format: formatContributor(NUMBER_FORMAT_RANGES),
	bigint_format: formatContributor(BIGINT_FORMAT_RANGES),
	min_length: minContributor,
	max_length: maxContributor,
	length_equals: (agg, def) => narrowBoth(agg, def.length),
	min_size: minContributor,
	max_size: maxContributor,
	size_equals: (agg, def) => narrowBoth(agg, def.size),
	string_format: (agg, def) => {
		setFormat(agg, def.format);
		if (def.pattern) addPattern(agg, def.pattern);
		if (def.format === "base64" || def.format === "base64url") agg.contentEncoding = def.format;
		if (def.local || def.precision === -1) agg.laxFormat = true;
	},
	mime_type: (agg, def) => intersectMime(agg, def.mime)
};
function aggregateChecks(schema) {
	const agg = {};
	const def = schema._zod.def;
	const list = schema._zod.traits.has("$ZodCheck") ? [schema, ...def.checks ?? []] : def.checks ?? [];
	for (const ch of list) contributors[ch._zod.def.check]?.(agg, ch._zod.def);
	const bag = schema._zod.bag;
	if (bag.minimum !== void 0) narrowMin(agg, "minimum", bag.minimum);
	if (bag.exclusiveMinimum !== void 0) narrowMin(agg, "exclusiveMinimum", bag.exclusiveMinimum);
	if (bag.maximum !== void 0) narrowMax(agg, "maximum", bag.maximum);
	if (bag.exclusiveMaximum !== void 0) narrowMax(agg, "exclusiveMaximum", bag.exclusiveMaximum);
	if (bag.multipleOf !== void 0) addDivisor(agg, bag.multipleOf);
	if (bag.format !== void 0) {
		agg.format ?? (agg.format = bag.format);
		if (bag.format.includes("int")) agg.isInt = true;
	}
	if (bag.mime) intersectMime(agg, bag.mime);
	for (const pattern of bag.patterns ?? []) addPattern(agg, pattern);
	return agg;
}
var formatMap = {
	guid: "uuid",
	url: "uri",
	datetime: "date-time",
	json_string: "json-string",
	regex: ""
};
var exactPatterns = /* @__PURE__ */ new Map([[base64Charset, base64$1], [base64urlCharset, base64url]]);
var exactPattern = (p) => exactPatterns.get(p) ?? p;
var stringProcessor = (schema, ctx, _json, _params) => {
	const json = _json;
	json.type = "string";
	const { minimum, maximum, format, patterns, contentEncoding, laxFormat } = aggregateChecks(schema);
	if (typeof minimum === "number") json.minLength = minimum;
	if (typeof maximum === "number") json.maxLength = maximum;
	if (format) {
		json.format = formatMap[format] ?? format;
		if (json.format === "") delete json.format;
		if (format === "time" || laxFormat) delete json.format;
	}
	if (contentEncoding) json.contentEncoding = contentEncoding;
	if (patterns && patterns.size > 0) {
		const patternList = [...patterns].map(exactPattern);
		if (patternList.length === 1) json.pattern = patternList[0].source;
		else if (patternList.length > 1) json.allOf = [...patternList.map((regex) => ({
			...ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0" ? { type: "string" } : {},
			pattern: regex.source
		}))];
	}
};
var numberProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const { minimum, maximum, multipleOf, exclusiveMaximum, exclusiveMinimum, isInt } = aggregateChecks(schema);
	json.type = isInt ? "integer" : "number";
	const exMin = typeof exclusiveMinimum === "number" && exclusiveMinimum >= (minimum ?? Number.NEGATIVE_INFINITY);
	const exMax = typeof exclusiveMaximum === "number" && exclusiveMaximum <= (maximum ?? Number.POSITIVE_INFINITY);
	const legacy = ctx.target === "draft-04" || ctx.target === "openapi-3.0";
	if (exMin) {
		if (legacy) {
			json.minimum = exclusiveMinimum;
			json.exclusiveMinimum = true;
		} else json.exclusiveMinimum = exclusiveMinimum;
	} else if (typeof minimum === "number") json.minimum = minimum;
	if (exMax) {
		if (legacy) {
			json.maximum = exclusiveMaximum;
			json.exclusiveMaximum = true;
		} else json.exclusiveMaximum = exclusiveMaximum;
	} else if (typeof maximum === "number") json.maximum = maximum;
	if (multipleOf) {
		const divisors = /* @__PURE__ */ new Set();
		for (const divisor of multipleOf) if (Number.isFinite(divisor) && divisor !== 0) divisors.add(Math.abs(divisor));
		else handleUnrepresentable(schema, ctx, json, params, `A multipleOf divisor of ${divisor} cannot be represented in JSON Schema`);
		const [first, ...rest] = divisors;
		if (first !== void 0) json.multipleOf = first;
		if (rest.length) json.allOf = [...json.allOf ?? [], ...rest.map((m) => ({ multipleOf: m }))];
	}
};
var booleanProcessor = (_schema, _ctx, json, _params) => {
	json.type = "boolean";
};
var neverProcessor = (_schema, _ctx, json, _params) => {
	json.not = {};
};
var enumProcessor = (schema, _ctx, json, _params) => {
	const def = schema._zod.def;
	const values = getEnumValues(def.entries);
	if (values.length === 0) {
		json.not = {};
		return;
	}
	if (values.every((v) => typeof v === "number")) json.type = "number";
	if (values.every((v) => typeof v === "string")) json.type = "string";
	json.enum = values;
};
var literalProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	if (def.values.length === 0) {
		json.not = {};
		return;
	}
	const vals = [];
	for (const val of def.values) if (val === void 0) {
		if (handleUnrepresentable(schema, ctx, json, params, "Literal `undefined` cannot be represented in JSON Schema")) return;
	} else if (typeof val === "bigint") {
		if (handleUnrepresentable(schema, ctx, json, params, "BigInt literals cannot be represented in JSON Schema")) return;
		vals.push(Number(val));
	} else vals.push(val);
	if (vals.length === 0) {} else if (vals.length === 1) {
		const val = vals[0];
		json.type = val === null ? "null" : typeof val;
		if (ctx.target === "draft-04" || ctx.target === "openapi-3.0") json.enum = [val];
		else json.const = val;
	} else {
		if (vals.every((v) => typeof v === "number")) json.type = "number";
		if (vals.every((v) => typeof v === "string")) json.type = "string";
		if (vals.every((v) => typeof v === "boolean")) json.type = "boolean";
		if (vals.every((v) => v === null)) json.type = "null";
		json.enum = vals;
	}
};
var customProcessor = (schema, ctx, json, params) => {
	handleUnrepresentable(schema, ctx, json, params, "Custom types cannot be represented in JSON Schema");
};
var transformProcessor = (schema, ctx, json, params) => {
	handleUnrepresentable(schema, ctx, json, params, "Transforms cannot be represented in JSON Schema");
};
var arrayProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	const { minimum, maximum } = aggregateChecks(schema);
	if (typeof minimum === "number") json.minItems = minimum;
	if (typeof maximum === "number") json.maxItems = maximum;
	json.type = "array";
	json.items = processSchema(def.element, ctx, {
		...params,
		path: [...params.path, "items"]
	});
};
function inputOptin(schema) {
	const def = schema._zod.def;
	if (def.type === "pipe" && def.in._zod.traits.has("$ZodTransform")) return inputOptin(def.out);
	if (def.type === "catch") return inputOptin(def.innerType);
	return schema._zod.optin;
}
var objectProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	const shape = def.shape;
	if (Object.getOwnPropertySymbols(shape).length && handleUnrepresentable(schema, ctx, json, params, "Symbol keys cannot be represented in JSON Schema")) return;
	json.type = "object";
	json.properties = {};
	for (const key in shape) assignProp(json.properties, key, processSchema(shape[key], ctx, {
		...params,
		path: [
			...params.path,
			"properties",
			key
		]
	}));
	const requiredKeys = [];
	for (const key of Object.keys(shape)) {
		const field = def.shape[key];
		if (ctx.io === "input" ? inputOptin(field) === void 0 : field._zod.optout === void 0) requiredKeys.push(key);
	}
	if (requiredKeys.length > 0) json.required = requiredKeys;
	if (def.catchall?._zod.def.type === "never") json.additionalProperties = false;
	else if (!def.catchall) {
		if (ctx.io === "output") json.additionalProperties = false;
	} else if (def.catchall) json.additionalProperties = processSchema(def.catchall, ctx, {
		...params,
		path: [...params.path, "additionalProperties"]
	});
};
var unionProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const isExclusive = def.inclusive === false;
	const options = def.options.map((x, i) => processSchema(x, ctx, {
		...params,
		path: [
			...params.path,
			isExclusive ? "oneOf" : "anyOf",
			i
		]
	}));
	if (isExclusive) json.oneOf = options;
	else json.anyOf = options;
};
var intersectionProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const a = processSchema(def.left, ctx, {
		...params,
		path: [
			...params.path,
			"allOf",
			0
		]
	});
	const b = processSchema(def.right, ctx, {
		...params,
		path: [
			...params.path,
			"allOf",
			1
		]
	});
	const isSimpleIntersection = (val) => "allOf" in val && Object.keys(val).length === 1;
	const allOf = [...isSimpleIntersection(a) ? a.allOf : [a], ...isSimpleIntersection(b) ? b.allOf : [b]];
	json.allOf = allOf;
	ctx.intersections.push(allOf);
};
/** JSON object keys are always strings, so a numeric record key schema is re-expressed over the
* numeric-string form the record parser matches. Deferred to `finalize`, after the flatten: a key
* behind a wrapper only carries its own `type` before then, and a union key only has its branches.
*
* A numeric bound cannot apply to a property name, so `minimum` and its siblings are dropped rather
* than carried over: keeping them beside `type: "string"` reproduces the match-nothing schema this
* exists to fix. A key that carries one therefore emits wider than the record parses \u2014 `z.record(z.number().min(5), V)`
* accepts `"3"` \u2014 which is the deliberate trade, since throwing on it would reject an ordinary schema
* outright. */
function stringifyKeyNames(bySchema, json, visited) {
	if (json.$ref) {
		if (visited.has(json)) return json;
		visited.add(json);
		const def = bySchema.get(json)?.def;
		if (!def) return json;
		const inlined = stringifyKeyNames(bySchema, def, visited);
		return inlined === def ? json : inlined;
	}
	for (const keyword of ["anyOf", "oneOf"]) {
		const branches = json[keyword];
		if (!Array.isArray(branches)) continue;
		const mapped = branches.map((branch) => stringifyKeyNames(bySchema, branch, visited));
		if (mapped.some((branch, i) => branch !== branches[i])) json = {
			...json,
			[keyword]: mapped
		};
	}
	const types = Array.isArray(json.type) ? json.type : [json.type];
	const numericType = !types.includes("string") && types.some((t) => t === "number" || t === "integer");
	const values = json.enum ?? (json.const !== void 0 ? [json.const] : void 0);
	if (!numericType && !values?.some((v) => typeof v === "number")) return json;
	const { minimum, maximum, exclusiveMinimum, exclusiveMaximum, multipleOf, format, id, ...rest } = json;
	if (rest.enum) rest.enum = rest.enum.map((v) => typeof v === "number" ? String(v) : v);
	else if (typeof rest.const === "number") rest.const = String(rest.const);
	if (!numericType) return rest;
	rest.type = "string";
	if (!values) rest.pattern = (types.includes("number") ? number$1 : integer).source;
	return rest;
}
/** Every record of one conversion, so the carriers are found in a single pass rather than once per record. */
var pendingRecords = /* @__PURE__ */ new WeakMap();
function rewriteKeyNames(ctx) {
	const bySchema = /* @__PURE__ */ new Map();
	for (const entry of ctx.seen.values()) if (entry.def && !bySchema.has(entry.schema)) bySchema.set(entry.schema, entry);
	const rewrites = /* @__PURE__ */ new Map();
	for (const record of pendingRecords.get(ctx) ?? []) {
		const seen = ctx.seen.get(record);
		const names = (seen?.def ?? seen?.schema)?.propertyNames;
		if (!names || names === true || rewrites.has(names)) continue;
		const rewritten = stringifyKeyNames(bySchema, names, /* @__PURE__ */ new Set());
		if (rewritten !== names) rewrites.set(names, rewritten);
	}
	if (!rewrites.size) return;
	for (const entry of ctx.seen.values()) for (const carrier of [entry.schema, entry.def]) {
		const rewritten = carrier && rewrites.get(carrier.propertyNames);
		if (rewritten) carrier.propertyNames = rewritten;
	}
}
var recordProcessor = (schema, ctx, _json, params) => {
	const json = _json;
	const def = schema._zod.def;
	json.type = "object";
	const keyType = def.keyType;
	const patterns = aggregateChecks(keyType).patterns;
	if (def.mode === "loose" && patterns && patterns.size > 0) {
		const valueSchema = processSchema(def.valueType, ctx, {
			...params,
			path: [
				...params.path,
				"patternProperties",
				"*"
			]
		});
		json.patternProperties = {};
		for (const pattern of patterns) assignProp(json.patternProperties, exactPattern(pattern).source, valueSchema);
	} else {
		if (ctx.target === "draft-07" || ctx.target === "draft-2020-12") {
			json.propertyNames = processSchema(def.keyType, ctx, {
				...params,
				path: [...params.path, "propertyNames"]
			});
			let pending = pendingRecords.get(ctx);
			if (!pending) {
				pending = [];
				pendingRecords.set(ctx, pending);
				ctx.deferred.push(() => rewriteKeyNames(ctx));
			}
			pending.push(schema);
		}
		json.additionalProperties = processSchema(def.valueType, ctx, {
			...params,
			path: [...params.path, "additionalProperties"]
		});
	}
	const keyValues = keyType._zod.values;
	const omittableOnInput = ctx.io === "input" && inputOptin(def.valueType) !== void 0;
	if (keyValues && !def.partial && !omittableOnInput) {
		const validKeyValues = [...keyValues].filter((v) => typeof v === "string" || typeof v === "number");
		if (validKeyValues.length > 0) json.required = validKeyValues.map(String);
	}
};
var nullableProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	const inner = processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	if (ctx.target === "openapi-3.0") {
		seen.ref = def.innerType;
		json.nullable = true;
	} else json.anyOf = [inner, { type: "null" }];
};
var nonoptionalProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
};
/** Round-trips a default value through JSON so the emitted schema is guaranteed to be valid JSON.
* A BigInt has no reliable encoding, so it goes through `unrepresentable` like any other
* unrepresentable value. Returns a sentinel when the caller must not write a default of its own. */
var UNREPRESENTABLE_DEFAULT = Symbol();
function serializeDefaultValue(value, schema, ctx, json, params) {
	let unrepresentable = false;
	const serialized = JSON.stringify(value, (_, val) => {
		if (typeof val !== "bigint") return val;
		unrepresentable = true;
		return null;
	});
	if (!unrepresentable) return JSON.parse(serialized);
	handleUnrepresentable(schema, ctx, json, params, "BigInt defaults cannot be represented in JSON Schema");
	return UNREPRESENTABLE_DEFAULT;
}
var defaultProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	const value = serializeDefaultValue(def.defaultValue, schema, ctx, json, params);
	if (value !== UNREPRESENTABLE_DEFAULT) json.default = value;
};
var prefaultProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	if (ctx.io !== "input") return;
	const value = serializeDefaultValue(def.defaultValue, schema, ctx, json, params);
	if (value !== UNREPRESENTABLE_DEFAULT) json._prefault = value;
};
var catchProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	let catchValue;
	try {
		catchValue = def.catchValue(void 0);
	} catch {
		handleUnrepresentable(schema, ctx, json, params, "Dynamic catch values are not supported in JSON Schema");
		return;
	}
	json.default = catchValue;
};
var pipeProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	const inIsTransform = def.in._zod.traits.has("$ZodTransform");
	const innerType = ctx.io === "input" ? inIsTransform ? def.out : def.in : def.out;
	processSchema(innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = innerType;
};
var readonlyProcessor = (schema, ctx, json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
	json.readOnly = true;
};
var optionalProcessor = (schema, ctx, _json, params) => {
	const def = schema._zod.def;
	processSchema(def.innerType, ctx, params);
	const seen = ctx.seen.get(schema);
	seen.ref = def.innerType;
};
//#endregion
//#region node_modules/.pnpm/zod@4.6.7/node_modules/zod/v4/classic/errors.js
var _installedErrorProtos = /* @__PURE__ */ new WeakSet([Object.prototype, Error.prototype]);
function _lazyMethod(proto, key, make) {
	Object.defineProperty(proto, key, {
		configurable: true,
		enumerable: false,
		get() {
			const value = make(this);
			Object.defineProperty(this, key, {
				value,
				configurable: true,
				writable: true
			});
			return value;
		},
		set(value) {
			Object.defineProperty(this, key, {
				value,
				configurable: true,
				writable: true
			});
		}
	});
}
var initializer = (inst, issues) => {
	$ZodError.init(inst, issues);
	inst.name = "ZodError";
	const proto = Object.getPrototypeOf(inst);
	if (_installedErrorProtos.has(proto)) return;
	_installedErrorProtos.add(proto);
	_lazyMethod(proto, "format", (self) => (mapper) => formatError(self, mapper));
	_lazyMethod(proto, "flatten", (self) => (mapper) => flattenError(self, mapper));
	_lazyMethod(proto, "addIssue", (self) => (issue) => {
		self.issues.push(issue);
		self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
	});
	_lazyMethod(proto, "addIssues", (self) => (issues) => {
		self.issues.push(...issues);
		self.message = JSON.stringify(self.issues, jsonStringifyReplacer, 2);
	});
	Object.defineProperty(proto, "isEmpty", {
		configurable: true,
		enumerable: false,
		get() {
			return this.issues.length === 0;
		}
	});
};
var ZodRealError = /*@__PURE__*/ $constructor("ZodError", initializer, void 0, { Parent: Error });
//#endregion
//#region node_modules/.pnpm/zod@4.6.7/node_modules/zod/v4/classic/parse.js
var parse = /* @__PURE__ */ _parse(ZodRealError);
var parseAsync = /* @__PURE__ */ _parseAsync(ZodRealError);
var safeParse = /* @__PURE__ */ _safeParse(ZodRealError);
var safeParseAsync = /* @__PURE__ */ _safeParseAsync(ZodRealError);
var encode = /* @__PURE__ */ _encode(ZodRealError);
var decode = /* @__PURE__ */ _decode(ZodRealError);
var encodeAsync = /* @__PURE__ */ _encodeAsync(ZodRealError);
var decodeAsync = /* @__PURE__ */ _decodeAsync(ZodRealError);
var safeEncode = /* @__PURE__ */ _safeEncode(ZodRealError);
var safeDecode = /* @__PURE__ */ _safeDecode(ZodRealError);
var safeEncodeAsync = /* @__PURE__ */ _safeEncodeAsync(ZodRealError);
var safeDecodeAsync = /* @__PURE__ */ _safeDecodeAsync(ZodRealError);
//#endregion
//#region node_modules/.pnpm/zod@4.6.7/node_modules/zod/v4/classic/schemas.js
function _ensureDefaultLocale() {
	if (!globalConfig.localeError) config(en_default());
}
function _ensureDefaultMemoizer() {
	if (!globalConfig.memoizer) config({ memoizer: memoizer() });
}
var ZodType = /*@__PURE__*/ $constructor("ZodType", (inst, def) => {
	_ensureDefaultLocale();
	$ZodType.init(inst, def);
	inst.def = def;
	inst.type = def.type;
	return inst;
}, {
	check(...chks) {
		const def = this.def;
		return this.clone(mergeDefs(def, { checks: [...def.checks ?? [], ...chks.map((ch) => typeof ch === "function" ? { _zod: {
			check: ch,
			def: { check: "custom" },
			onattach: []
		} } : ch)] }), { parent: true });
	},
	with(...chks) {
		return this.check(...chks);
	},
	clone(def, params) {
		return clone(this, def, params);
	},
	brand() {
		return this;
	},
	register(reg, meta) {
		reg.add(this, meta);
		return this;
	},
	refine(check, params) {
		return this.check(refine(check, params));
	},
	superRefine(refinement, params) {
		return this.check(superRefine(refinement, params));
	},
	overwrite(fn) {
		return this.check(_overwrite(fn));
	},
	optional() {
		return optional(this);
	},
	exactOptional() {
		return exactOptional(this);
	},
	nullable() {
		return nullable(this);
	},
	nullish() {
		return optional(nullable(this));
	},
	nonoptional(params) {
		return nonoptional(this, params);
	},
	array() {
		return array(this);
	},
	or(arg) {
		return union([this, arg]);
	},
	and(arg) {
		return intersection(this, arg);
	},
	transform(tx) {
		return pipe(this, transform(tx));
	},
	default(d) {
		return _default(this, d);
	},
	prefault(d) {
		return prefault(this, d);
	},
	catch(params) {
		return _catch(this, params);
	},
	pipe(target) {
		return pipe(this, target);
	},
	readonly() {
		return readonly(this);
	},
	describe(description) {
		const cl = this.clone();
		globalRegistry.add(cl, { description });
		return cl;
	},
	meta(...args) {
		if (args.length === 0) return globalRegistry.get(this);
		const cl = this.clone();
		globalRegistry.add(cl, args[0]);
		return cl;
	},
	isOptional() {
		return this.safeParse(void 0).success;
	},
	isNullable() {
		return this.safeParse(null).success;
	},
	apply(fn, ...args) {
		return args.length === 0 ? fn(this) : fn(this, ...args);
	},
	get "~standard"() {
		return hide(this, "~standard", {
			...standardProps(this),
			jsonSchema: {
				input: createStandardJSONSchemaMethod(this, "input"),
				output: createStandardJSONSchemaMethod(this, "output")
			}
		});
	},
	set "~standard"(value) {
		own(this, "~standard", value);
	},
	parse: function _parse(data, params) {
		return parse(this, data, params, { callee: _parse });
	},
	parseAsync: async function _parseAsync(data, params) {
		return await parseAsync(this, data, params, { callee: _parseAsync });
	},
	safeParse(data, params) {
		return safeParse(this, data, params);
	},
	async safeParseAsync(data, params) {
		return safeParseAsync(this, data, params);
	},
	get spa() {
		return this?.safeParseAsync;
	},
	set spa(value) {
		own(this, "spa", value);
	},
	validate(data, params) {
		return validate(this, data, params);
	},
	validateAsync(data, params) {
		return validateAsync(this, data, params);
	},
	encode: function _encode(data, params) {
		return encode(this, data, params, { callee: _encode });
	},
	decode: function _decode(data, params) {
		return decode(this, data, params, { callee: _decode });
	},
	encodeAsync: async function _encodeAsync(data, params) {
		return await encodeAsync(this, data, params, { callee: _encodeAsync });
	},
	decodeAsync: async function _decodeAsync(data, params) {
		return await decodeAsync(this, data, params, { callee: _decodeAsync });
	},
	safeEncode(data, params) {
		return safeEncode(this, data, params);
	},
	safeDecode(data, params) {
		return safeDecode(this, data, params);
	},
	async safeEncodeAsync(data, params) {
		return safeEncodeAsync(this, data, params);
	},
	async safeDecodeAsync(data, params) {
		return safeDecodeAsync(this, data, params);
	},
	toJSONSchema(params) {
		return createToJSONSchemaMethod(this, {})(params);
	},
	get description() {
		return globalRegistry.get(this)?.description;
	},
	get _def() {
		return this._zod.def;
	}
});
/** @internal */
var _ZodString = /*@__PURE__*/ $constructor("_ZodString", (inst, def) => {
	$ZodString.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => stringProcessor(inst, ctx, json, params);
}, /*@__PURE__*/ derived({
	format: (inst) => aggregateChecks(inst).format ?? null,
	minLength: (inst) => aggregateChecks(inst).minimum ?? null,
	maxLength: (inst) => aggregateChecks(inst).maximum ?? null
}, {
	regex(...args) {
		return this.check(_regex(...args));
	},
	includes(...args) {
		return this.check(_includes(...args));
	},
	startsWith(...args) {
		return this.check(_startsWith(...args));
	},
	endsWith(...args) {
		return this.check(_endsWith(...args));
	},
	min(...args) {
		return this.check(_minLength(...args));
	},
	max(...args) {
		return this.check(_maxLength(...args));
	},
	length(...args) {
		return this.check(_length(...args));
	},
	nonempty(...args) {
		return this.check(_minLength(1, ...args));
	},
	lowercase(params) {
		return this.check(_lowercase(params));
	},
	uppercase(params) {
		return this.check(_uppercase(params));
	},
	trim() {
		return this.check(_trim());
	},
	normalize(...args) {
		return this.check(_normalize(...args));
	},
	toLowerCase() {
		return this.check(_toLowerCase());
	},
	toUpperCase() {
		return this.check(_toUpperCase());
	},
	slugify() {
		return this.check(_slugify());
	}
}));
var ZodString = /*@__PURE__*/ $constructor("ZodString", (inst, def) => {
	$ZodString.init(inst, def);
	_ZodString.init(inst, def);
}, {
	email(params) {
		return this.check(_email(ZodEmail, params));
	},
	url(params) {
		return this.check(_url(ZodURL, params));
	},
	jwt(params) {
		return this.check(_jwt(ZodJWT, params));
	},
	emoji(params) {
		return this.check(_emoji(ZodEmoji, params));
	},
	guid(params) {
		return this.check(_guid(ZodGUID, params));
	},
	uuid(params) {
		return this.check(_uuid(ZodUUID, params));
	},
	uuidv4(params) {
		return this.check(_uuidv4(ZodUUID, params));
	},
	uuidv6(params) {
		return this.check(_uuidv6(ZodUUID, params));
	},
	uuidv7(params) {
		return this.check(_uuidv7(ZodUUID, params));
	},
	nanoid(params) {
		return this.check(_nanoid(ZodNanoID, params));
	},
	cuid(params) {
		return this.check(_cuid(ZodCUID, params));
	},
	cuid2(params) {
		return this.check(_cuid2(ZodCUID2, params));
	},
	ulid(params) {
		return this.check(_ulid(ZodULID, params));
	},
	base64(params) {
		return this.check(_base64(ZodBase64, params));
	},
	base64url(params) {
		return this.check(_base64url(ZodBase64URL, params));
	},
	xid(params) {
		return this.check(_xid(ZodXID, params));
	},
	ksuid(params) {
		return this.check(_ksuid(ZodKSUID, params));
	},
	ipv4(params) {
		return this.check(_ipv4(ZodIPv4, params));
	},
	ipv6(params) {
		return this.check(_ipv6(ZodIPv6, params));
	},
	cidrv4(params) {
		return this.check(_cidrv4(ZodCIDRv4, params));
	},
	cidrv6(params) {
		return this.check(_cidrv6(ZodCIDRv6, params));
	},
	e164(params) {
		return this.check(_e164(ZodE164, params));
	},
	datetime(params) {
		return this.check(_isoDateTime(ZodISODateTime, params));
	},
	date(params) {
		return this.check(_isoDate(ZodISODate, params));
	},
	time(params) {
		return this.check(_isoTime(ZodISOTime, params));
	},
	duration(params) {
		return this.check(_isoDuration(ZodISODuration, params));
	}
});
function string(params) {
	return _string(ZodString, params);
}
var ZodStringFormat = /*@__PURE__*/ $constructor("ZodStringFormat", (inst, def) => {
	$ZodStringFormat.init(inst, def);
	_ZodString.init(inst, def);
});
var ZodISODateTime = /*@__PURE__*/ $constructor("ZodISODateTime", (inst, def) => {
	$ZodISODateTime.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISODate = /*@__PURE__*/ $constructor("ZodISODate", (inst, def) => {
	$ZodISODate.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISOTime = /*@__PURE__*/ $constructor("ZodISOTime", (inst, def) => {
	$ZodISOTime.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodISODuration = /*@__PURE__*/ $constructor("ZodISODuration", (inst, def) => {
	$ZodISODuration.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodEmail = /*@__PURE__*/ $constructor("ZodEmail", (inst, def) => {
	$ZodEmail.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodGUID = /*@__PURE__*/ $constructor("ZodGUID", (inst, def) => {
	$ZodGUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodUUID = /*@__PURE__*/ $constructor("ZodUUID", (inst, def) => {
	$ZodUUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodURL = /*@__PURE__*/ $constructor("ZodURL", (inst, def) => {
	$ZodURL.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodEmoji = /*@__PURE__*/ $constructor("ZodEmoji", (inst, def) => {
	$ZodEmoji.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodNanoID = /*@__PURE__*/ $constructor("ZodNanoID", (inst, def) => {
	$ZodNanoID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
/**
* @deprecated CUID v1 is deprecated by its authors due to information leakage
* (timestamps embedded in the id). Use {@link ZodCUID2} instead.
* See https://github.com/paralleldrive/cuid.
*/
var ZodCUID = /*@__PURE__*/ $constructor("ZodCUID", (inst, def) => {
	$ZodCUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCUID2 = /*@__PURE__*/ $constructor("ZodCUID2", (inst, def) => {
	$ZodCUID2.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodULID = /*@__PURE__*/ $constructor("ZodULID", (inst, def) => {
	$ZodULID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodXID = /*@__PURE__*/ $constructor("ZodXID", (inst, def) => {
	$ZodXID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodKSUID = /*@__PURE__*/ $constructor("ZodKSUID", (inst, def) => {
	$ZodKSUID.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodIPv4 = /*@__PURE__*/ $constructor("ZodIPv4", (inst, def) => {
	$ZodIPv4.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodIPv6 = /*@__PURE__*/ $constructor("ZodIPv6", (inst, def) => {
	$ZodIPv6.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCIDRv4 = /*@__PURE__*/ $constructor("ZodCIDRv4", (inst, def) => {
	$ZodCIDRv4.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodCIDRv6 = /*@__PURE__*/ $constructor("ZodCIDRv6", (inst, def) => {
	$ZodCIDRv6.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodBase64 = /*@__PURE__*/ $constructor("ZodBase64", (inst, def) => {
	$ZodBase64.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodBase64URL = /*@__PURE__*/ $constructor("ZodBase64URL", (inst, def) => {
	$ZodBase64URL.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodE164 = /*@__PURE__*/ $constructor("ZodE164", (inst, def) => {
	$ZodE164.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodJWT = /*@__PURE__*/ $constructor("ZodJWT", (inst, def) => {
	$ZodJWT.init(inst, def);
	ZodStringFormat.init(inst, def);
});
var ZodNumber = /*@__PURE__*/ $constructor("ZodNumber", (inst, def) => {
	$ZodNumber.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => numberProcessor(inst, ctx, json, params);
	inst.isFinite = true;
}, /*@__PURE__*/ derived({
	minValue: (inst) => {
		const { minimum, exclusiveMinimum } = aggregateChecks(inst);
		return Math.max(minimum ?? Number.NEGATIVE_INFINITY, exclusiveMinimum ?? Number.NEGATIVE_INFINITY);
	},
	maxValue: (inst) => {
		const { maximum, exclusiveMaximum } = aggregateChecks(inst);
		return Math.min(maximum ?? Number.POSITIVE_INFINITY, exclusiveMaximum ?? Number.POSITIVE_INFINITY);
	},
	isInt: (inst) => {
		const { isInt, multipleOf } = aggregateChecks(inst);
		return !!isInt || !!multipleOf?.some(Number.isSafeInteger);
	},
	format: (inst) => aggregateChecks(inst).format ?? null
}, {
	gt(value, params) {
		return this.check(_gt(value, params));
	},
	gte(value, params) {
		return this.check(_gte(value, params));
	},
	min(value, params) {
		return this.check(_gte(value, params));
	},
	lt(value, params) {
		return this.check(_lt(value, params));
	},
	lte(value, params) {
		return this.check(_lte(value, params));
	},
	max(value, params) {
		return this.check(_lte(value, params));
	},
	int(params) {
		return this.check(int(params));
	},
	safe(params) {
		return this.check(int(params));
	},
	positive(params) {
		return this.check(_gt(0, params));
	},
	nonnegative(params) {
		return this.check(_gte(0, params));
	},
	negative(params) {
		return this.check(_lt(0, params));
	},
	nonpositive(params) {
		return this.check(_lte(0, params));
	},
	multipleOf(value, params) {
		return this.check(_multipleOf(value, params));
	},
	step(value, params) {
		return this.check(_multipleOf(value, params));
	},
	finite() {
		return this;
	}
}));
function number(params) {
	return _number(ZodNumber, params);
}
var ZodNumberFormat = /*@__PURE__*/ $constructor("ZodNumberFormat", (inst, def) => {
	$ZodNumberFormat.init(inst, def);
	ZodNumber.init(inst, def);
});
function int(params) {
	return _int(ZodNumberFormat, params);
}
var ZodBoolean = /*@__PURE__*/ $constructor("ZodBoolean", (inst, def) => {
	$ZodBoolean.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => booleanProcessor(inst, ctx, json, params);
});
function boolean(params) {
	return _boolean(ZodBoolean, params);
}
var ZodUnknown = /*@__PURE__*/ $constructor("ZodUnknown", (inst, def) => {
	$ZodUnknown.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => void 0;
});
function unknown() {
	return _unknown(ZodUnknown);
}
var ZodNever = /*@__PURE__*/ $constructor("ZodNever", (inst, def) => {
	$ZodNever.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => neverProcessor(inst, ctx, json, params);
});
function never(params) {
	return _never(ZodNever, params);
}
var ZodArray = /*@__PURE__*/ $constructor("ZodArray", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodArray.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => arrayProcessor(inst, ctx, json, params);
	inst.element = def.element;
}, {
	min(n, params) {
		return this.check(_minLength(n, params));
	},
	nonempty(params) {
		return this.check(_minLength(1, params));
	},
	max(n, params) {
		return this.check(_maxLength(n, params));
	},
	length(n, params) {
		return this.check(_length(n, params));
	},
	unwrap() {
		return this.element;
	}
});
function array(element, params) {
	return _array(ZodArray, element, params);
}
var ZodObject = /*@__PURE__*/ $constructor("ZodObject", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodObjectJIT.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => objectProcessor(inst, ctx, json, params);
	installLazyProp(inst, "shape", (self) => self._zod.def.shape, false);
}, {
	keyof() {
		return _enum(Object.keys(this._zod.def.shape));
	},
	catchall(catchall) {
		return this.clone(mergeDefs(this._zod.def, { catchall }));
	},
	passthrough() {
		return this.clone(mergeDefs(this._zod.def, { catchall: unknown() }));
	},
	loose() {
		return this.clone(mergeDefs(this._zod.def, { catchall: unknown() }));
	},
	strict() {
		return this.clone(mergeDefs(this._zod.def, { catchall: never() }));
	},
	strip() {
		return this.clone(mergeDefs(this._zod.def, { catchall: void 0 }));
	},
	extend(incoming) {
		return extend(this, incoming);
	},
	safeExtend(incoming) {
		return safeExtend(this, incoming);
	},
	merge(other) {
		return merge(this, other);
	},
	pick(mask) {
		return pick(this, mask);
	},
	omit(mask) {
		return omit(this, mask);
	},
	partial(...args) {
		return partial(ZodOptional, this, args[0]);
	},
	exactPartial(...args) {
		return partial(ZodExactOptional, this, args[0], "exactPartial");
	},
	required(...args) {
		return required(ZodNonOptional, this, args[0]);
	}
});
function object(shape, params) {
	return new ZodObject({
		type: "object",
		shape: shape ?? {},
		...normalizeParams(params)
	});
}
var ZodUnion = /*@__PURE__*/ $constructor("ZodUnion", (inst, def) => {
	$ZodUnion.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => unionProcessor(inst, ctx, json, params);
	inst.options = def.options;
});
function union(options, params) {
	return new ZodUnion({
		type: "union",
		options,
		...normalizeParams(params)
	});
}
var ZodIntersection = /*@__PURE__*/ $constructor("ZodIntersection", (inst, def) => {
	$ZodIntersection.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => intersectionProcessor(inst, ctx, json, params);
});
function intersection(left, right) {
	return new ZodIntersection({
		type: "intersection",
		left,
		right
	});
}
var ZodRecord = /*@__PURE__*/ $constructor("ZodRecord", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodRecord.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => recordProcessor(inst, ctx, json, params);
	inst.keyType = def.keyType;
	inst.valueType = def.valueType;
});
function record(keyType, valueType, params) {
	if (!valueType || !valueType._zod) return new ZodRecord({
		type: "record",
		keyType: string(),
		valueType: keyType,
		...normalizeParams(valueType)
	});
	return new ZodRecord({
		type: "record",
		keyType,
		valueType,
		...normalizeParams(params)
	});
}
var ZodEnum = /*@__PURE__*/ $constructor("ZodEnum", (inst, def) => {
	$ZodEnum.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => enumProcessor(inst, ctx, json, params);
	inst.enum = def.entries;
	inst.options = [...inst._zod.values];
	const keys = new Set(Object.keys(def.entries));
	inst.extract = (values, params) => {
		const newEntries = {};
		for (const value of values) if (keys.has(value)) newEntries[value] = def.entries[value];
		else throw new Error(`Key ${value} not found in enum`);
		return new ZodEnum({
			...def,
			checks: [],
			...normalizeParams(params),
			entries: newEntries
		});
	};
	inst.exclude = (values, params) => {
		const newEntries = { ...def.entries };
		for (const value of values) if (keys.has(value)) delete newEntries[value];
		else throw new Error(`Key ${value} not found in enum`);
		return new ZodEnum({
			...def,
			checks: [],
			...normalizeParams(params),
			entries: newEntries
		});
	};
});
function _enum(values, params) {
	return new ZodEnum({
		type: "enum",
		entries: Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values,
		...normalizeParams(params)
	});
}
var ZodLiteral = /*@__PURE__*/ $constructor("ZodLiteral", (inst, def) => {
	$ZodLiteral.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => literalProcessor(inst, ctx, json, params);
	inst.values = new Set(def.values);
	Object.defineProperty(inst, "value", { get() {
		if (def.values.length > 1) throw new Error("This schema contains multiple valid literal values. Use `.values` instead.");
		return def.values[0];
	} });
});
function literal(value, params) {
	return new ZodLiteral({
		type: "literal",
		values: Array.isArray(value) ? value : [value],
		...normalizeParams(params)
	});
}
var ZodTransform = /*@__PURE__*/ $constructor("ZodTransform", (inst, def) => {
	_ensureDefaultMemoizer();
	$ZodTransform.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => transformProcessor(inst, ctx, json, params);
	inst._zod.parse = (payload, _ctx) => {
		if (_ctx.direction === "backward") throw new $ZodEncodeError(inst.constructor.name);
		payload.addIssue = (issue$1) => {
			if (typeof issue$1 === "string") payload.issues.push(issue(issue$1, payload.value, def));
			else {
				const _issue = issue$1;
				if (_issue.fatal) _issue.continue = false;
				_issue.code ?? (_issue.code = "custom");
				if (!("input" in _issue)) _issue.input = payload.value;
				_issue.inst ?? (_issue.inst = inst);
				payload.issues.push(issue(_issue));
			}
		};
		const output = def.transform(payload.value, payload);
		if (output instanceof Promise) return output.then((output) => {
			payload.value = output;
			return payload;
		});
		payload.value = output;
		return payload;
	};
});
function transform(fn) {
	return new ZodTransform({
		type: "transform",
		transform: fn
	});
}
var ZodOptional = /*@__PURE__*/ $constructor("ZodOptional", (inst, def) => {
	$ZodOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function optional(innerType) {
	return new ZodOptional({
		type: "optional",
		innerType
	});
}
var ZodExactOptional = /*@__PURE__*/ $constructor("ZodExactOptional", (inst, def) => {
	$ZodExactOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function exactOptional(innerType) {
	return new ZodExactOptional({
		type: "optional",
		innerType
	});
}
var ZodNullable = /*@__PURE__*/ $constructor("ZodNullable", (inst, def) => {
	$ZodNullable.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => nullableProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function nullable(innerType) {
	return new ZodNullable({
		type: "nullable",
		innerType
	});
}
var ZodDefault = /*@__PURE__*/ $constructor("ZodDefault", (inst, def) => {
	$ZodDefault.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => defaultProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
	inst.removeDefault = inst.unwrap;
});
function _default(innerType, defaultValue) {
	return new ZodDefault({
		type: "default",
		innerType,
		get defaultValue() {
			return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
		}
	});
}
var ZodPrefault = /*@__PURE__*/ $constructor("ZodPrefault", (inst, def) => {
	$ZodPrefault.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => prefaultProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function prefault(innerType, defaultValue) {
	return new ZodPrefault({
		type: "prefault",
		innerType,
		get defaultValue() {
			return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
		}
	});
}
var ZodNonOptional = /*@__PURE__*/ $constructor("ZodNonOptional", (inst, def) => {
	$ZodNonOptional.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => nonoptionalProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function nonoptional(innerType, params) {
	return new ZodNonOptional({
		type: "nonoptional",
		innerType,
		...normalizeParams(params)
	});
}
var ZodCatch = /*@__PURE__*/ $constructor("ZodCatch", (inst, def) => {
	$ZodCatch.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => catchProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
	inst.removeCatch = inst.unwrap;
});
function _catch(innerType, catchValue) {
	return new ZodCatch({
		type: "catch",
		innerType,
		catchValue: typeof catchValue === "function" ? catchValue : constantCatch(catchValue)
	});
}
var ZodPipe = /*@__PURE__*/ $constructor("ZodPipe", (inst, def) => {
	$ZodPipe.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => pipeProcessor(inst, ctx, json, params);
	inst.in = def.in;
	inst.out = def.out;
});
function pipe(in_, out) {
	return new ZodPipe({
		type: "pipe",
		in: in_,
		out
	});
}
var ZodCodec = /*@__PURE__*/ $constructor("ZodCodec", (inst, def) => {
	ZodPipe.init(inst, def);
	$ZodCodec.init(inst, def);
});
function codec(in_, out, params) {
	return new ZodCodec({
		type: "pipe",
		in: in_,
		out,
		transform: params.decode,
		reverseTransform: params.encode
	});
}
var ZodReadonly = /*@__PURE__*/ $constructor("ZodReadonly", (inst, def) => {
	$ZodReadonly.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => readonlyProcessor(inst, ctx, json, params);
	inst.unwrap = () => inst._zod.def.innerType;
});
function readonly(innerType) {
	return new ZodReadonly({
		type: "readonly",
		innerType
	});
}
var ZodCustom = /*@__PURE__*/ $constructor("ZodCustom", (inst, def) => {
	$ZodCustom.init(inst, def);
	ZodType.init(inst, def);
	inst._zod.processJSONSchema = (ctx, json, params) => customProcessor(inst, ctx, json, params);
});
function custom(fn, _params) {
	return _custom(ZodCustom, fn ?? (() => true), _params);
}
function refine(fn, _params = {}) {
	return _refine(ZodCustom, fn, _params);
}
function superRefine(fn, params) {
	return _superRefine(fn, params);
}
//#endregion
//#region src/shared/crawler-access.ts
/**
* Shopify crawler access.
*
* Shopify storefronts rate-limit (429) and sometimes block crawlers they
* haven't authorized. The merchant mints a domain-scoped signature in Shopify
* admin (Online Store -> Preferences -> Crawler access) and the crawler
* replays it as three static headers on every request to that domain.
*
* These helpers are pure so both the crawler and the input validation can use
* them.
*/
/** Constant Shopify expects, quotes included. We supply it; users never see it. */
var SHOPIFY_SIGNATURE_AGENT = "\"https://shopify.com\"";
function shopifyCrawlerHeaders(signatureInput, signature) {
	return {
		"Signature-Input": signatureInput,
		Signature: signature,
		"Signature-Agent": SHOPIFY_SIGNATURE_AGENT
	};
}
/**
* Headers to send with a request to `url`, or `{}` when it isn't the host the
* signature was created for, over https, before its expiry. The host match is
* exact: Shopify scopes a signature to one domain, so `www.store.com` and
* `store.com` need their own. A redirect to plain http must not replay the
* signature in cleartext.
*/
function crawlerHeadersFor(url, access) {
	if (!access || isCrawlerAccessExpired(access.expiresAt)) return {};
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		return {};
	}
	return parsed.protocol === "https:" && parsed.hostname.toLowerCase() === access.host ? access.headers : {};
}
/**
* Shopify's `Signature-Input` is an RFC 9421 signature parameter list that may
* carry `;expires=<unix seconds>`. Nothing beyond that parameter is assumed.
*/
function parseSignatureExpiry(signatureInput) {
	const match = signatureInput.match(/expires=(\d+)/);
	if (!match) return null;
	const expiresAt = /* @__PURE__ */ new Date(Number(match[1]) * 1e3);
	return Number.isNaN(expiresAt.getTime()) ? null : expiresAt.toISOString();
}
/** Shopify rejects a signature past its `expires`, so it is never replayed. */
function isCrawlerAccessExpired(expiresAt, now = Date.now()) {
	return expiresAt !== null && new Date(expiresAt).getTime() <= now;
}
var errorCodeSchema = _enum([
	"UNAUTHENTICATED",
	"AUTH_CONFIG_MISSING",
	"PAYMENT_REQUIRED",
	"PAYMENT_METHOD_REQUIRED",
	"PAYMENT_ACTION_REQUIRED",
	"INSUFFICIENT_CREDITS",
	"FORBIDDEN",
	"NOT_FOUND",
	"AUDIT_CAPACITY_REACHED",
	"AUDIT_PAGE_LIMIT_EXCEEDED",
	"AUDIT_ALREADY_RUNNING",
	"AUDIT_RENDERING_UNAVAILABLE",
	"VALIDATION_ERROR",
	"UNKNOWN_LOCATION",
	"CRAWL_TARGET_BLOCKED",
	"BACKLINKS_BILLING_ISSUE",
	"AI_SEARCH_BILLING_ISSUE",
	"AI_VISIBILITY_ERROR",
	"DATAFORSEO_AUTH_FAILED",
	"RATE_LIMITED",
	"UPSTREAM_UNAVAILABLE",
	"CONFLICT",
	"INTERNAL_ERROR"
]);
function isErrorCode(value) {
	return errorCodeSchema.safeParse(value).success;
}
//#endregion
//#region src/server/lib/errors.ts
var AppError = class extends Error {
	code;
	details;
	constructor(code, message, details) {
		super(message ?? code);
		this.code = code;
		this.details = details;
		this.name = "AppError";
	}
};
function asAppError(error) {
	if (error instanceof AppError) return error;
	if (error instanceof Error && isErrorCode(error.message)) return new AppError(error.message, error.message);
	return null;
}
/**
* The error's name, message and code, then its causes, for a log line.
* Workers Logs render an Error passed to `console.error` as its stack frames
* alone, so a log keeps the message only when it is written out like this.
* An error the Workflows engine threw over RPC is marked remote.
*/
function describeError(error, depth = 0) {
	if (!(error instanceof Error)) return String(error);
	const code = asAppError(error)?.code;
	const parts = [`${error.name}: ${error.message}`];
	if (code && code !== error.message) parts.push(`(${code})`);
	if ("remote" in error && error.remote === true) parts.push("(remote)");
	if (error.cause !== void 0 && depth < 4) parts.push(`<- ${describeError(error.cause, depth + 1)}`);
	return parts.join(" ");
}
//#endregion
//#region src/lib/auth-mode.ts
var AUTH_MODES = [
	"cloudflare_access",
	"local_noauth",
	"hosted",
	"password",
	"everyapp"
];
var authModeSchema = _enum(AUTH_MODES);
var warnedInvalidAuthModes = /* @__PURE__ */ new Set();
function getAuthMode(value) {
	const parsed = authModeSchema.safeParse(value);
	if (parsed.success) return parsed.data;
	if (value && !warnedInvalidAuthModes.has(value)) {
		warnedInvalidAuthModes.add(value);
		console.error(`Invalid AUTH_MODE "${value}" \u2014 falling back to "cloudflare_access". Valid values: ${AUTH_MODES.join(", ")}.`);
	}
	return "cloudflare_access";
}
function isHostedAuthMode(value) {
	return getAuthMode(value) === "hosted";
}
function isEveryAppAuthMode(value) {
	return getAuthMode(value) === "everyapp";
}
//#endregion
//#region src/server/lib/runtime-env.ts
var workersEnvPromise = null;
async function getOptionalEnvValue(name) {
	return getEnvValueSync(await getWorkersEnv() ?? {}, name);
}
/**
* Sync variant for callers that already hold an env record (e.g. a Durable
* Object's `this.env`, needed because Think's `getModel()` hook is sync).
* Same policy as the async form: process.env first (where local `.env.local`
* secrets land in dev), skipping empty strings, then the given env.
*/
function getEnvValueSync(env, name) {
	const processValue = typeof process !== "undefined" ? process.env?.[name] : void 0;
	if (processValue) return processValue;
	const value = Reflect.get(env, name);
	return typeof value === "string" && value !== "" ? value : void 0;
}
async function getRequiredEnvValue(name) {
	const value = await getOptionalEnvValue(name);
	if (!value) throw new Error(`Missing required environment variable: ${name}`);
	return value;
}
async function isHostedServerAuthMode() {
	return isHostedAuthMode(await getOptionalEnvValue("AUTH_MODE"));
}
async function getWorkersEnv() {
	if (!workersEnvPromise) workersEnvPromise = loadWorkersEnv();
	return workersEnvPromise;
}
async function loadWorkersEnv() {
	try {
		const workersModule = await import("cloudflare:workers");
		return isRecord(workersModule.env) ? workersModule.env : null;
	} catch {
		return null;
	}
}
function isRecord(value) {
	return typeof value === "object" && value !== null;
}
//#endregion
//#region src/shared/billing.ts
var AUTUMN_SEO_DATA_BALANCE_FEATURE_ID = "usage_credits";
var AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID = "topup_credits";
var AUTUMN_SEO_DATA_CREDITS_PER_USD = 1e3;
var SEO_DATA_COST_MARKUP = 1.28;
object({
	amountUsd: number().int().min(10).max(99),
	/** The most the organization spends on top-up credits per billing
	*  cycle, in USD. Every top-up credit counts, not only reloaded ones. */
	monthlyLimitUsd: number().int().min(10).max(1e3)
}).refine((settings) => settings.monthlyLimitUsd >= settings.amountUsd, {
	message: "The monthly budget must be at least the reload amount.",
	path: ["monthlyLimitUsd"]
});
function roundUsdForBilling(value) {
	return Math.round(value * 1e5) / 1e5;
}
/**
* Convert a raw DataForSEO USD cost into the USD amount a hosted customer is
* actually billed, applying the platform markup. Use this when displaying
* cost estimates so the number matches what the user will be charged.
*
* Self-hosted deployments pay DataForSEO directly at the raw rate and should
* show the raw number \u2014 gate at the call site with `isHostedClientAuthMode`.
*/
function applyBillingMarkupUsd(rawUsd) {
	return roundUsdForBilling(rawUsd * SEO_DATA_COST_MARKUP);
}
/**
* Credits charged for one raw provider (DataForSEO) USD cost: marked-up,
* rounded, then ceiled per call. This is the single charging formula, so a
* pre-call estimate and the post-call deduction cannot drift apart.
*/
function creditsForProviderUsd(rawUsd) {
	return Math.ceil(applyBillingMarkupUsd(rawUsd) * AUTUMN_SEO_DATA_CREDITS_PER_USD);
}
//#endregion
//#region src/shared/audit-rendering.ts
var CLOUDFLARE_RENDER_TIMEOUT_MS = 2e4;
var CLOUDFLARE_USD_PER_ATTEMPT = CLOUDFLARE_RENDER_TIMEOUT_MS / 36e5 * .09;
var CONTEXT_USD_PER_CREDIT = .0025;
function renderUsageCredits(usage) {
	return creditsForProviderUsd(usage.cloudflareAttempts * CLOUDFLARE_USD_PER_ATTEMPT + usage.contextCredits * CONTEXT_USD_PER_CREDIT);
}
/**
* Usage-credit range for rendering up to `maxPages` pages. The low end renders
* every page on Cloudflare, which is what most sites cost. The high end is
* every page falling back to Context after its Cloudflare attempt.
*/
function estimateRenderingCredits(maxPages) {
	return {
		low: renderUsageCredits({
			cloudflareAttempts: maxPages,
			contextCredits: 0
		}),
		high: renderUsageCredits({
			cloudflareAttempts: maxPages,
			contextCredits: maxPages
		})
	};
}
//#endregion
//#region src/server/lib/audit/html-response.ts
var MAX_HTML_BYTES = 1048576;
async function readTextUpTo(response, maxBytes) {
	if (!response.body) return "";
	const reader = response.body.getReader();
	const decoder = new TextDecoder();
	const parts = [];
	let bytesRead = 0;
	try {
		while (bytesRead < maxBytes) {
			const result = await reader.read();
			if (result.done) break;
			const value = result.value;
			if (!(value instanceof Uint8Array)) throw new Error("Expected response bytes");
			const remaining = maxBytes - bytesRead;
			const chunk = value.byteLength > remaining ? value.subarray(0, remaining) : value;
			bytesRead += chunk.byteLength;
			parts.push(decoder.decode(chunk, { stream: true }));
			if (bytesRead >= maxBytes) {
				await reader.cancel();
				break;
			}
		}
	} finally {
		reader.releaseLock();
	}
	parts.push(decoder.decode());
	return parts.join("");
}
/** The first `maxBytes` of `text` as UTF-8, as readTextUpTo keeps from a body. */
function truncateToBytes(text, maxBytes) {
	const bytes = new TextEncoder().encode(text);
	return bytes.length <= maxBytes ? text : new TextDecoder().decode(bytes.subarray(0, maxBytes));
}
/** Read a response body up to maxBytes; null when the body exceeds it. */
async function readBodyCapped(response, maxBytes) {
	if (!response.body) return "";
	const reader = response.body.getReader();
	const chunks = [];
	let total = 0;
	for (;;) {
		const { done, value } = await reader.read();
		if (done) break;
		total += value.byteLength;
		if (total > maxBytes) {
			await reader.cancel();
			return null;
		}
		chunks.push(value);
	}
	const joined = new Uint8Array(total);
	let offset = 0;
	for (const chunk of chunks) {
		joined.set(chunk, offset);
		offset += chunk.byteLength;
	}
	return new TextDecoder().decode(joined);
}
//#endregion
//#region src/server/lib/public-fetch.ts
/**
* Fetch a user-supplied URL. On Workers the `global_fetch_strictly_public`
* compatibility flag already refuses private and reserved addresses, so this
* is plain `fetch`. The standalone Docker edition has no such guarantee and
* sets CRAWL_GATEWAY_URL instead: the request then goes through its
* DNS-pinning gateway (scripts/celld/runtime/crawl-gateway.mjs), so a target
* cannot rebind to an internal address between resolution and connect.
* Callers follow redirects themselves, re-validating each hop and sending it
* back through here, so the gateway request is always manual.
*/
async function publicFetch(input, init = {}) {
	const gateway = await getOptionalEnvValue("CRAWL_GATEWAY_URL");
	if (!gateway) return fetch(input, init);
	const secret = await getOptionalEnvValue("CRAWL_GATEWAY_SECRET");
	if (!secret) throw new Error("CRAWL_GATEWAY_SECRET is required");
	const headers = new Headers(init.headers);
	headers.set("x-crawl-url", new URL(input).href);
	headers.set("x-crawl-secret", secret);
	return fetch(gateway, {
		...init,
		headers,
		redirect: "manual"
	});
}
//#endregion
//#region node_modules/.pnpm/structured-headers@2.0.3/node_modules/structured-headers/dist/util.js
var asciiRe = /^[\x20-\x7E]*$/;
var tokenRe = /^[a-zA-Z*][:/!#$%&'*+\-.^_`|~A-Za-z0-9]*$/;
var keyRe = /^[a-z*][*\-_.a-z0-9]*$/;
function isAscii(str) {
	return asciiRe.test(str);
}
function isValidTokenStr(str) {
	return tokenRe.test(str);
}
function isValidKeyStr(str) {
	return keyRe.test(str);
}
function isInnerList(input) {
	return Array.isArray(input[0]);
}
function arrayBufferToBase64(ab) {
	const bytes = new Uint8Array(ab);
	let binary = "";
	for (const byte of bytes) binary += String.fromCharCode(byte);
	return btoa(binary);
}
function base64ToArrayBuffer(b64) {
	const binaryString = atob(b64);
	const len = binaryString.length;
	const bytes = new Uint8Array(len);
	for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
	return bytes.buffer;
}
//#endregion
//#region node_modules/.pnpm/structured-headers@2.0.3/node_modules/structured-headers/dist/token.js
var Token = class {
	constructor(value) {
		if (!isValidTokenStr(value)) throw new TypeError("Invalid character in Token string. Tokens must start with *, A-Z and the rest of the string may only contain a-z, A-Z, 0-9, :/!#$%&'*+-.^_`|~");
		this.value = value;
	}
	toString() {
		return this.value;
	}
};
//#endregion
//#region node_modules/.pnpm/structured-headers@2.0.3/node_modules/structured-headers/dist/displaystring.js
var DisplayString = class {
	constructor(value) {
		this.value = value;
	}
	toString() {
		return this.value;
	}
};
//#endregion
//#region node_modules/.pnpm/structured-headers@2.0.3/node_modules/structured-headers/dist/serializer.js
var SerializeError = class extends Error {};
function serializeDictionary(input) {
	const entries = input instanceof Map ? input.entries() : Object.entries(input);
	return Array.from(entries).map(([key, entry]) => {
		const keyStr = serializeKey(key);
		if (Array.isArray(entry)) {
			if (entry[0] === true) return keyStr + serializeParameters(entry[1]);
			else if (isInnerList(entry)) return keyStr + "=" + serializeInnerList(entry);
			else return keyStr + "=" + serializeItem(entry);
		} else if (entry === true) return keyStr;
		else return keyStr + "=" + serializeBareItem(entry);
	}).join(", ");
}
function serializeItem(input, params) {
	if (Array.isArray(input)) return serializeBareItem(input[0]) + serializeParameters(input[1]);
	else return serializeBareItem(input) + (params ? serializeParameters(params) : "");
}
function serializeInnerList(input) {
	return `(${input[0].map((value) => serializeItem(value)).join(" ")})${serializeParameters(input[1])}`;
}
function serializeBareItem(input) {
	if (typeof input === "number") {
		if (Number.isInteger(input)) return serializeInteger(input);
		return serializeDecimal(input);
	}
	if (typeof input === "string") return serializeString(input);
	if (input instanceof Token) return serializeToken(input);
	if (input instanceof ArrayBuffer) return serializeByteSequence(input);
	if (input instanceof DisplayString) return serializeDisplayString(input);
	if (input instanceof Date) return serializeDate(input);
	if (typeof input === "boolean") return serializeBoolean(input);
	throw new SerializeError(`Cannot serialize values of type ${typeof input}`);
}
function serializeInteger(input) {
	if (input < -999999999999999 || input > 999999999999999) throw new SerializeError("Structured headers can only encode integers in the range range of -999,999,999,999,999 to 999,999,999,999,999 inclusive");
	return input.toString();
}
function serializeDecimal(input) {
	const out = input.toFixed(3).replace(/0+$/, "");
	if (out.split(".")[0].replace("-", "").length > 12) throw new SerializeError("Fractional numbers are not allowed to have more than 12 significant digits before the decimal point");
	return out;
}
function serializeString(input) {
	if (!isAscii(input)) throw new SerializeError("Only ASCII strings may be serialized");
	return `"${input.replace(/("|\\)/g, (v) => "\\" + v)}"`;
}
function serializeDisplayString(input) {
	let out = "%\"";
	const textEncoder = new TextEncoder();
	for (const char of textEncoder.encode(input.toString())) if (char === 37 || char === 34 || char <= 31 || char >= 127) out += "%" + char.toString(16);
	else out += String.fromCharCode(char);
	return out + "\"";
}
function serializeBoolean(input) {
	return input ? "?1" : "?0";
}
function serializeByteSequence(input) {
	return `:${arrayBufferToBase64(input)}:`;
}
function serializeToken(input) {
	return input.toString();
}
function serializeDate(input) {
	return "@" + Math.floor(input.getTime() / 1e3);
}
function serializeParameters(input) {
	return Array.from(input).map(([key, value]) => {
		let out = ";" + serializeKey(key);
		if (value !== true) out += "=" + serializeBareItem(value);
		return out;
	}).join("");
}
function serializeKey(input) {
	if (!isValidKeyStr(input)) throw new SerializeError("Keys in dictionaries must only contain lowercase letter, numbers, _-*. and must start with a letter or *");
	return input;
}
//#endregion
//#region node_modules/.pnpm/structured-headers@2.0.3/node_modules/structured-headers/dist/parser.js
function parseDictionary(input) {
	return new Parser(input).parseDictionary();
}
function parseItem(input) {
	return new Parser(input).parseItem();
}
var ParseError = class extends Error {
	constructor(position, message) {
		super(`Parse error: ${message} at offset ${position}`);
	}
};
var Parser = class {
	constructor(input) {
		this.input = input;
		this.pos = 0;
	}
	parseDictionary() {
		this.skipWS();
		const dictionary = /* @__PURE__ */ new Map();
		while (!this.eof()) {
			const thisKey = this.parseKey();
			let member;
			if (this.lookChar() === "=") {
				this.pos++;
				member = this.parseItemOrInnerList();
			} else member = [true, this.parseParameters()];
			dictionary.set(thisKey, member);
			this.skipOWS();
			if (this.eof()) return dictionary;
			this.expectChar(",");
			this.pos++;
			this.skipOWS();
			if (this.eof()) throw new ParseError(this.pos, "Dictionary contained a trailing comma");
		}
		return dictionary;
	}
	parseList() {
		this.skipWS();
		const members = [];
		while (!this.eof()) {
			members.push(this.parseItemOrInnerList());
			this.skipOWS();
			if (this.eof()) return members;
			this.expectChar(",");
			this.pos++;
			this.skipOWS();
			if (this.eof()) throw new ParseError(this.pos, "A list may not end with a trailing comma");
		}
		return members;
	}
	parseItem(standaloneItem = true) {
		if (standaloneItem) this.skipWS();
		const result = [this.parseBareItem(), this.parseParameters()];
		if (standaloneItem) this.checkTrail();
		return result;
	}
	parseItemOrInnerList() {
		if (this.lookChar() === "(") return this.parseInnerList();
		else return this.parseItem(false);
	}
	parseInnerList() {
		this.expectChar("(");
		this.pos++;
		const innerList = [];
		while (!this.eof()) {
			this.skipWS();
			if (this.lookChar() === ")") {
				this.pos++;
				return [innerList, this.parseParameters()];
			}
			innerList.push(this.parseItem(false));
			const nextChar = this.lookChar();
			if (nextChar !== " " && nextChar !== ")") throw new ParseError(this.pos, "Expected a whitespace or ) after every item in an inner list");
		}
		throw new ParseError(this.pos, "Could not find end of inner list");
	}
	parseBareItem() {
		const char = this.lookChar();
		if (char === void 0) throw new ParseError(this.pos, "Unexpected end of string");
		if (char.match(/^[-0-9]/)) return this.parseIntegerOrDecimal();
		if (char === "\"") return this.parseString();
		if (char.match(/^[A-Za-z*]/)) return this.parseToken();
		if (char === ":") return this.parseByteSequence();
		if (char === "?") return this.parseBoolean();
		if (char === "@") return this.parseDate();
		if (char === "%") return this.parseDisplayString();
		throw new ParseError(this.pos, "Unexpected input");
	}
	parseParameters() {
		const parameters = /* @__PURE__ */ new Map();
		while (!this.eof()) {
			if (this.lookChar() !== ";") break;
			this.pos++;
			this.skipWS();
			const key = this.parseKey();
			let value = true;
			if (this.lookChar() === "=") {
				this.pos++;
				value = this.parseBareItem();
			}
			parameters.set(key, value);
		}
		return parameters;
	}
	parseIntegerOrDecimal() {
		let type = "integer";
		let sign = 1;
		let inputNumber = "";
		if (this.lookChar() === "-") {
			sign = -1;
			this.pos++;
		}
		if (!isDigit(this.lookChar())) throw new ParseError(this.pos, "Expected a digit (0-9)");
		while (!this.eof()) {
			const char = this.getChar();
			if (isDigit(char)) inputNumber += char;
			else if (type === "integer" && char === ".") {
				if (inputNumber.length > 12) throw new ParseError(this.pos, "Exceeded maximum decimal length");
				inputNumber += ".";
				type = "decimal";
			} else {
				this.pos--;
				break;
			}
			if (type === "integer" && inputNumber.length > 15) throw new ParseError(this.pos, "Exceeded maximum integer length");
			if (type === "decimal" && inputNumber.length > 16) throw new ParseError(this.pos, "Exceeded maximum decimal length");
		}
		if (type === "integer") return parseInt(inputNumber, 10) * sign;
		else {
			if (inputNumber.endsWith(".")) throw new ParseError(this.pos, "Decimal cannot end on a period");
			if (inputNumber.split(".")[1].length > 3) throw new ParseError(this.pos, "Number of digits after the decimal point cannot exceed 3");
			return parseFloat(inputNumber) * sign;
		}
	}
	parseString() {
		let outputString = "";
		this.expectChar("\"");
		this.pos++;
		while (!this.eof()) {
			const char = this.getChar();
			if (char === "\\") {
				if (this.eof()) throw new ParseError(this.pos, "Unexpected end of input");
				const nextChar = this.getChar();
				if (nextChar !== "\\" && nextChar !== "\"") throw new ParseError(this.pos, "A backslash must be followed by another backslash or double quote");
				outputString += nextChar;
			} else if (char === "\"") return outputString;
			else if (!isAscii(char)) throw new ParseError(this.pos, "Strings must be in the ASCII range");
			else outputString += char;
		}
		throw new ParseError(this.pos, "Unexpected end of input");
	}
	parseDisplayString() {
		if (this.getChars(2) !== "%\"") throw new ParseError(this.pos, "Unexpected character. Display strings should start with %=");
		const result = [];
		while (!this.eof()) {
			const char = this.getChar();
			if (char.charCodeAt(0) <= 31 || char.charCodeAt(0) >= 127 && char.charCodeAt(0) <= 255) throw new ParseError(this.pos, "Invalid char found in DisplayString. Did you forget to escape?");
			if (char === "%") {
				const hexChars = this.getChars(2);
				if (/^[0-9a-f]{2}$/.test(hexChars)) result.push(parseInt(hexChars, 16));
				else throw new ParseError(this.pos, `Unexpected sequence after % in DispalyString: "${hexChars}". Note that hexidecimals must be lowercase`);
				continue;
			}
			if (char === "\"") {
				const textDecoder = new TextDecoder("utf-8", { fatal: true });
				try {
					return new DisplayString(textDecoder.decode(new Uint8Array(result)));
				} catch {
					throw new ParseError(this.pos, "Fatal error decoding UTF-8 sequence in Display String");
				}
			}
			result.push(char.charCodeAt(0));
		}
		throw new ParseError(this.pos, "Unexpected end of input");
	}
	parseToken() {
		let outputString = "";
		while (!this.eof()) {
			const char = this.lookChar();
			if (char === void 0 || !/^[:/!#$%&'*+\-.^_`|~A-Za-z0-9]$/.test(char)) return new Token(outputString);
			outputString += this.getChar();
		}
		return new Token(outputString);
	}
	parseByteSequence() {
		this.expectChar(":");
		this.pos++;
		const endPos = this.input.indexOf(":", this.pos);
		if (endPos === -1) throw new ParseError(this.pos, "Could not find a closing \":\" character to mark end of Byte Sequence");
		const b64Content = this.input.substring(this.pos, endPos);
		this.pos += b64Content.length + 1;
		if (!/^[A-Za-z0-9+/=]*$/.test(b64Content)) throw new ParseError(this.pos, "ByteSequence does not contain a valid base64 string");
		try {
			return base64ToArrayBuffer(b64Content);
		} catch {
			throw new ParseError(this.pos, "ByteSequence does not contain a valid base64 string");
		}
	}
	parseBoolean() {
		this.expectChar("?");
		this.pos++;
		const char = this.getChar();
		if (char === "1") return true;
		if (char === "0") return false;
		throw new ParseError(this.pos, "Unexpected character. Expected a \"1\" or a \"0\"");
	}
	parseDate() {
		this.expectChar("@");
		this.pos++;
		let sign = 1;
		let inputNumber = "";
		if (this.lookChar() === "-") {
			sign = -1;
			this.pos++;
		}
		if (!isDigit(this.lookChar())) throw new ParseError(this.pos, "Expected a digit (0-9)");
		while (!this.eof()) {
			const char = this.getChar();
			if (isDigit(char)) inputNumber += char;
			else throw new ParseError(this.pos, "Expected a digit (0-9), whitespace or EOL");
		}
		if (inputNumber.length > 15) throw new ParseError(this.pos, "Exceeded max length for a date value");
		return /* @__PURE__ */ new Date(parseInt(inputNumber, 10) * sign * 1e3);
	}
	parseKey() {
		if (!this.lookChar()?.match(/^[a-z*]/)) throw new ParseError(this.pos, "A key must begin with an asterisk or letter (a-z)");
		let outputString = "";
		while (!this.eof()) {
			const char = this.lookChar();
			if (char === void 0 || !/^[a-z0-9_\-.*]$/.test(char)) return outputString;
			outputString += this.getChar();
		}
		return outputString;
	}
	/**
	* Looks at the next character without advancing the cursor.
	*
	* Returns undefined if we were at the end of the string.
	*/
	lookChar() {
		return this.input[this.pos];
	}
	/**
	* Checks if the next character is 'char', and fail otherwise.
	*/
	expectChar(char) {
		if (this.lookChar() !== char) throw new ParseError(this.pos, `Expected ${char}`);
	}
	getChar() {
		return this.input[this.pos++];
	}
	getChars(count) {
		const result = this.input.substr(this.pos, count);
		this.pos += count;
		return result;
	}
	eof() {
		return this.pos >= this.input.length;
	}
	skipOWS() {
		while (true) {
			const c = this.input.substr(this.pos, 1);
			if (c === " " || c === "	") this.pos++;
			else break;
		}
	}
	skipWS() {
		while (this.lookChar() === " ") this.pos++;
	}
	checkTrail() {
		this.skipWS();
		if (!this.eof()) throw new ParseError(this.pos, "Unexpected characters at end of input");
	}
};
var isDigitRegex = /^[0-9]$/;
function isDigit(char) {
	if (char === void 0) return false;
	return isDigitRegex.test(char);
}
//#endregion
//#region node_modules/.pnpm/http-message-sig@0.3.0/node_modules/http-message-sig/dist/index.mjs
var SignatureErrorCode = Object.freeze({
	MissingField: "MissingField",
	MalformedField: "MalformedField",
	LabelRequired: "LabelRequired",
	LabelMismatch: "LabelMismatch",
	DuplicateLabel: "DuplicateLabel",
	InvalidComponent: "InvalidComponent",
	DuplicateComponent: "DuplicateComponent",
	UnsupportedFeature: "UnsupportedFeature",
	AlgorithmMismatch: "AlgorithmMismatch",
	PolicyViolation: "PolicyViolation",
	VerificationFailed: "VerificationFailed",
	ResolverFailed: "ResolverFailed"
});
var SignatureError = class extends Error {
	constructor(code, message, cause) {
		super(message);
		this.name = "SignatureError";
		this.code = code;
		this.cause = cause;
	}
};
function rsaHashName(algorithm) {
	if (!("hash" in algorithm)) return void 0;
	const hash = algorithm.hash;
	if (typeof hash !== "object" || hash === null || !("name" in hash)) return;
	return typeof hash.name === "string" ? hash.name : void 0;
}
function signatureAlgorithm(key) {
	if (key.algorithm.name === "Ed25519") return "ed25519";
	if (key.algorithm.name === "RSA-PSS" && rsaHashName(key.algorithm) === "SHA-512") return "rsa-pss-sha512";
	throw new SignatureError(SignatureErrorCode.UnsupportedFeature, `Unsupported WebCrypto algorithm ${key.algorithm.name}`);
}
function cryptoParameters(key) {
	return key.algorithm.name === "RSA-PSS" ? {
		name: "RSA-PSS",
		saltLength: 64
	} : { name: key.algorithm.name };
}
function createWebCryptoSigner(key) {
	if (key.type !== "private" || !key.usages.includes("sign")) throw new SignatureError(SignatureErrorCode.PolicyViolation, "Signing requires a private key with sign usage");
	const algorithm = signatureAlgorithm(key);
	return Object.freeze({
		algorithm,
		async sign(data) {
			return new Uint8Array(await crypto.subtle.sign(cryptoParameters(key), key, data));
		}
	});
}
function createWebCryptoVerifier(key) {
	if (key.type !== "public" || !key.usages.includes("verify")) throw new SignatureError(SignatureErrorCode.PolicyViolation, "Verification requires a public key with verify usage");
	const algorithm = signatureAlgorithm(key);
	return Object.freeze({
		algorithm,
		verify(data, signature) {
			return crypto.subtle.verify(cryptoParameters(key), key, signature, data);
		}
	});
}
var encoder = new TextEncoder();
var fieldNamePattern = /^[!#$%&'*+.^_`|~0-9A-Za-z-]+$/;
var sfKeyPattern = /^[a-z*][a-z0-9_.*-]*$/;
var derivedComponents = /* @__PURE__ */ new Set([
	"@method",
	"@target-uri",
	"@authority",
	"@scheme",
	"@request-target",
	"@path",
	"@query",
	"@status"
]);
var unsupportedParameters = /* @__PURE__ */ new Set([
	"sf",
	"bs",
	"tr"
]);
function fail(code, message, cause) {
	throw new SignatureError(code, message, cause);
}
function cloneBareItem(value) {
	if (value instanceof ArrayBuffer) return value.slice(0);
	return value;
}
function validateParameterName(name) {
	if (!sfKeyPattern.test(name)) fail(SignatureErrorCode.MalformedField, `Invalid parameter name ${name}`);
}
function validateSerializableBareItem(value, location) {
	try {
		serializeItem(value);
	} catch (error) {
		fail(SignatureErrorCode.MalformedField, `Invalid ${location}`, error);
	}
}
function isRfc8941BareItem(value) {
	return !(value instanceof Date) && !(value instanceof DisplayString);
}
function validateBareItem(value, location) {
	if (!isRfc8941BareItem(value)) return fail(SignatureErrorCode.UnsupportedFeature, `${location} uses an RFC 9651-only value`);
	return cloneBareItem(value);
}
function copyParameters(input) {
	const output = {};
	for (const [name, value] of Object.entries(input)) {
		validateParameterName(name);
		if (value !== void 0) {
			validateSerializableBareItem(value, `parameter ${name}`);
			output[name] = cloneBareItem(value);
		}
	}
	validateKnownParameters(output);
	return Object.freeze(output);
}
function validateKnownParameters(parameters) {
	for (const name of ["created", "expires"]) {
		const value = parameters[name];
		if (value !== void 0 && (!Number.isInteger(value) || typeof value !== "number")) fail(SignatureErrorCode.MalformedField, `${name} must be an integer`);
	}
	for (const name of [
		"nonce",
		"alg",
		"keyid",
		"tag"
	]) {
		const value = parameters[name];
		if (value !== void 0 && typeof value !== "string") fail(SignatureErrorCode.MalformedField, `${name} must be a string`);
	}
}
function parametersToMap(parameters) {
	const output = /* @__PURE__ */ new Map();
	for (const [name, value] of Object.entries(parameters)) if (value !== void 0) output.set(name, cloneBareItem(value));
	return output;
}
function component(name, parameters = {}) {
	const normalizedName = normalizeComponentName(name);
	const copied = copyComponentParameters(parameters);
	validateComponent({
		name: normalizedName,
		parameters: copied
	});
	return Object.freeze({
		name: normalizedName,
		parameters: copied
	});
}
function copyComponentParameters(parameters) {
	const output = {};
	for (const [name, value] of Object.entries(parameters)) {
		validateParameterName(name);
		if (value !== void 0) {
			validateSerializableBareItem(value, `component parameter ${name}`);
			output[name] = cloneBareItem(value);
		}
	}
	return Object.freeze(output);
}
function normalizeComponentName(name) {
	const normalized = name.toLowerCase();
	if (normalized.startsWith("@")) {
		if (normalized === "@query-param") return fail(SignatureErrorCode.UnsupportedFeature, "@query-param is not supported");
		if (!derivedComponents.has(normalized)) return fail(SignatureErrorCode.UnsupportedFeature, `Unknown derived component ${normalized}`);
	} else if (!fieldNamePattern.test(normalized)) return fail(SignatureErrorCode.InvalidComponent, `Invalid field component ${name}`);
	return normalized;
}
function normalizeComponent(input) {
	return typeof input === "string" ? component(input) : component(input.name, input.parameters);
}
function validateComponent(value) {
	const entries = Object.entries(value.parameters);
	for (const [name, parameterValue] of entries) {
		if (unsupportedParameters.has(name)) fail(SignatureErrorCode.UnsupportedFeature, `${name} is not supported`);
		if (name !== "req" && name !== "key") fail(SignatureErrorCode.UnsupportedFeature, `Component parameter ${name} is not supported`);
		if (name === "req" && parameterValue !== true) fail(SignatureErrorCode.InvalidComponent, "req must be true");
		if (name === "key" && typeof parameterValue !== "string") fail(SignatureErrorCode.InvalidComponent, "key must be a string");
	}
	if (value.name.startsWith("@") && value.parameters.key !== void 0) fail(SignatureErrorCode.InvalidComponent, `key is invalid on derived component ${value.name}`);
}
function componentMap(value) {
	const output = /* @__PURE__ */ new Map();
	for (const [name, parameterValue] of Object.entries(value.parameters)) if (parameterValue !== void 0) output.set(name, parameterValue);
	return output;
}
function equivalentIdentity(input) {
	const ordered = Object.entries(input.parameters).filter((entry) => entry[1] !== void 0).sort(([left], [right]) => left.localeCompare(right));
	const parameters = /* @__PURE__ */ new Map();
	for (const [name, value] of ordered) if (value !== void 0) parameters.set(name, value);
	return serializeItem(input.name, parameters);
}
function normalizeComponents(inputs) {
	const output = [];
	const identities = /* @__PURE__ */ new Set();
	for (const input of inputs) {
		const value = normalizeComponent(input);
		const identity = equivalentIdentity(value);
		if (identities.has(identity)) fail(SignatureErrorCode.DuplicateComponent, `Duplicate component ${identity}`);
		identities.add(identity);
		output.push(value);
	}
	return Object.freeze(output);
}
function fieldsFromHeaders(headers) {
	const fields = [];
	headers.forEach((value, name) => fields.push(Object.freeze({
		name,
		value
	})));
	return Object.freeze(fields);
}
function copyFields(fields) {
	return Object.freeze(fields.map(({ name, value }) => {
		if (!fieldNamePattern.test(name)) fail(SignatureErrorCode.MalformedField, `Invalid field name ${name}`);
		const normalized = normalizeFieldValue(value);
		validateAscii(normalized, `Field ${name}`);
		return Object.freeze({
			name: name.toLowerCase(),
			value: normalized
		});
	}));
}
function isNativeRequest(message) {
	return typeof Request !== "undefined" && message instanceof Request;
}
function isNativeResponse(message) {
	return typeof Response !== "undefined" && message instanceof Response;
}
function snapshotRequest(message) {
	if (isNativeRequest(message)) return Object.freeze({
		kind: "request",
		method: message.method,
		targetUri: message.url,
		fields: fieldsFromHeaders(message.headers),
		trailers: Object.freeze([])
	});
	if (!fieldNamePattern.test(message.method)) fail(SignatureErrorCode.InvalidComponent, "Invalid request method");
	validateAscii(message.targetUri, "Target URI");
	if (message.requestTarget !== void 0) validateAscii(message.requestTarget, "Request target");
	return Object.freeze({
		kind: "request",
		method: message.method,
		targetUri: message.targetUri,
		requestTarget: message.requestTarget,
		fields: copyFields(message.fields),
		trailers: copyFields(message.trailers ?? [])
	});
}
function snapshotMessage(message) {
	if (isNativeRequest(message)) return snapshotRequest(message);
	if (isNativeResponse(message)) return Object.freeze({
		kind: "response",
		status: message.status,
		fields: fieldsFromHeaders(message.headers),
		trailers: Object.freeze([])
	});
	if (message.kind === "request") return snapshotRequest(message);
	if (!Number.isInteger(message.status) || message.status < 100 || message.status > 999) fail(SignatureErrorCode.InvalidComponent, "Invalid response status");
	return Object.freeze({
		kind: "response",
		status: message.status,
		fields: copyFields(message.fields),
		trailers: copyFields(message.trailers ?? []),
		request: message.request === void 0 ? void 0 : snapshotRequest(message.request)
	});
}
function normalizeFieldValue(value) {
	return value.replace(/\r\n[\t ]+/g, " ").replace(/^[\t ]+|[\t ]+$/g, "");
}
function validateAscii(value, location) {
	for (const character of value) {
		const code = character.charCodeAt(0);
		if (code > 126 || code < 32 || code === 127) {
			if (code === 9) continue;
			fail(SignatureErrorCode.MalformedField, `${location} is not ASCII field content`);
		}
	}
}
function extractField(snapshot, name, trailers) {
	const values = (trailers ? snapshot.trailers : snapshot.fields).filter((field) => field.name.toLowerCase() === name).map((field) => normalizeFieldValue(field.value));
	if (values.length === 0) return fail(SignatureErrorCode.MissingField, `Missing field ${name}`);
	return values.join(", ");
}
function requestForComponent(snapshot, value) {
	if (value.parameters.req === void 0) return snapshot;
	if (snapshot.kind !== "response" || snapshot.request === void 0) return fail(SignatureErrorCode.InvalidComponent, "req requires a response with a related request");
	return snapshot.request;
}
function requestUrl(snapshot, name) {
	try {
		return new URL(snapshot.targetUri);
	} catch (error) {
		return fail(SignatureErrorCode.InvalidComponent, `${name} requires an absolute target URI`, error);
	}
}
function requestTarget(snapshot, name) {
	const url = requestUrl(snapshot, name);
	if (url.hash !== "") return fail(SignatureErrorCode.InvalidComponent, `${name} target URI cannot contain a fragment`);
	const schemeEnd = snapshot.targetUri.indexOf("://");
	if (schemeEnd === -1) return fail(SignatureErrorCode.InvalidComponent, `${name} requires an HTTP target URI`);
	const pathStart = snapshot.targetUri.indexOf("/", schemeEnd + 3);
	const queryStart = snapshot.targetUri.indexOf("?", schemeEnd + 3);
	const start = pathStart !== -1 && (queryStart === -1 || pathStart < queryStart) ? pathStart : queryStart;
	const pathEnd = queryStart === -1 ? snapshot.targetUri.length : queryStart;
	return Object.freeze({
		url,
		path: start === -1 || start === queryStart ? "/" : snapshot.targetUri.slice(start, pathEnd),
		query: queryStart === -1 ? "?" : snapshot.targetUri.slice(queryStart)
	});
}
function extractDerived(snapshot, name) {
	if (name === "@status") {
		if (snapshot.kind !== "response") return fail(SignatureErrorCode.InvalidComponent, "@status requires a response");
		return snapshot.status.toString();
	}
	if (snapshot.kind !== "request") return fail(SignatureErrorCode.InvalidComponent, `${name} requires a request`);
	if (name === "@method") return snapshot.method;
	const target = requestTarget(snapshot, name);
	switch (name) {
		case "@target-uri": return snapshot.targetUri;
		case "@authority": return target.url.host;
		case "@scheme": return target.url.protocol.slice(0, -1);
		case "@request-target":
			if (snapshot.requestTarget === void 0) return fail(SignatureErrorCode.UnsupportedFeature, "@request-target requires a descriptor requestTarget");
			return snapshot.requestTarget;
		case "@path": return target.path;
		case "@query": return target.query;
		default: return fail(SignatureErrorCode.UnsupportedFeature, `Unknown derived component ${name}`);
	}
}
function extractComponentValue(snapshot, value) {
	const selected = requestForComponent(snapshot, value);
	if (value.name.startsWith("@")) return extractDerived(selected, value.name);
	const fieldValue = extractField(selected, value.name, false);
	const key = value.parameters.key;
	if (key === void 0) return fieldValue;
	if (typeof key !== "string") return fail(SignatureErrorCode.InvalidComponent, "key must be a string");
	const member = parseRfc8941Dictionary(fieldValue, `field ${value.name}`).get(key);
	if (member === void 0) return fail(SignatureErrorCode.MissingField, `Field ${value.name} has no dictionary member ${key}`);
	return isInnerList(member) ? serializeInnerList(member) : serializeItem(member);
}
function componentsToInnerList(components, parameters) {
	return [components.map((value) => [value.name, componentMap(value)]), parametersToMap(parameters)];
}
function buildSignatureBase(snapshot, components, signatureInput) {
	const lines = components.map((value) => `${serializeItem(value.name, componentMap(value))}: ${extractComponentValue(snapshot, value)}`);
	lines.push(`"@signature-params": ${serializeInnerList(signatureInput)}`);
	return encoder.encode(lines.join("\n"));
}
function assertAlgorithm(claimed, actual) {
	if (claimed !== void 0 && claimed !== actual) fail(SignatureErrorCode.AlgorithmMismatch, `Claimed algorithm ${String(claimed)} does not match ${actual}`);
}
function createInput(message, label, componentsInput, parametersInput, algorithm) {
	if (!sfKeyPattern.test(label)) fail(SignatureErrorCode.MalformedField, `Invalid signature label ${label}`);
	const snapshot = snapshotMessage(message);
	const components = normalizeComponents(componentsInput);
	const parameters = copyParameters(parametersInput);
	assertAlgorithm(parameters.alg, algorithm);
	const innerList = componentsToInnerList(components, parameters);
	const dictionary = /* @__PURE__ */ new Map([[label, innerList]]);
	return Object.freeze({
		base: buildSignatureBase(snapshot, components, innerList),
		signatureInput: serializeDictionary(dictionary)
	});
}
function signatureDictionary(label, signature) {
	const item = [Uint8Array.from(signature).buffer, /* @__PURE__ */ new Map()];
	return serializeDictionary(/* @__PURE__ */ new Map([[label, item]]));
}
async function createSignature(message, options) {
	const label = options.label ?? "sig1";
	const input = createInput(message, label, options.components, options.parameters, options.signer.algorithm);
	const signature = await options.signer.sign(input.base.slice());
	return Object.freeze({
		signature: signatureDictionary(label, signature),
		signatureInput: input.signatureInput
	});
}
function assertNoRfc9651Syntax(input, name) {
	let quoted = false;
	let escaped = false;
	for (let index = 0; index < input.length; index += 1) {
		const character = input[index];
		if (escaped) {
			escaped = false;
			continue;
		}
		if (quoted && character === "\\") {
			escaped = true;
			continue;
		}
		if (character === "\"") {
			quoted = !quoted;
			continue;
		}
		if (!quoted && (character === "@" || character === "%" && input[index + 1] === "\"")) fail(SignatureErrorCode.UnsupportedFeature, `${name} uses an RFC 9651-only value`);
	}
}
function parseRfc8941Dictionary(input, name) {
	assertNoRfc9651Syntax(input, name);
	let dictionary;
	try {
		dictionary = parseDictionary(input);
	} catch (error) {
		return fail(SignatureErrorCode.MalformedField, `Malformed ${name}`, error);
	}
	assertRfc8941Dictionary(dictionary, name);
	return dictionary;
}
function assertRfc8941Dictionary(dictionary, name) {
	for (const member of dictionary.values()) {
		if (isInnerList(member)) for (const [value, parameters] of member[0]) {
			validateBareItem(value, name);
			for (const parameter of parameters.values()) validateBareItem(parameter, name);
		}
		else validateBareItem(member[0], name);
		for (const parameter of member[1].values()) validateBareItem(parameter, name);
	}
}
var webcrypto = Object.freeze({
	signer: createWebCryptoSigner,
	verifier: createWebCryptoVerifier
});
//#endregion
//#region node_modules/.pnpm/jsonwebkey-thumbprint@0.1.0/node_modules/jsonwebkey-thumbprint/dist/index.mjs
var jwkThumbprintPreCompute = (jwk) => {
	const encoder = new TextEncoder();
	switch (jwk.kty) {
		case "EC": return encoder.encode(`{"crv":"${jwk.crv}","kty":"EC","x":"${jwk.x}","y":"${jwk.y}"}`);
		case "OKP": return encoder.encode(`{"crv":"${jwk.crv}","kty":"OKP","x":"${jwk.x}"}`);
		case "RSA": return encoder.encode(`{"e":"${jwk.e}","kty":"RSA","n":"${jwk.n}"}`);
		default: throw new Error("Unsupported key type");
	}
};
var jwkThumbprint = async (jwk, hash, decode) => {
	return decode(await hash(jwkThumbprintPreCompute(jwk)));
};
//#endregion
//#region node_modules/.pnpm/web-bot-auth@0.2.0/node_modules/web-bot-auth/dist/index.mjs
function discoveryType(value) {
	const typeName = value === void 0 ? "directory" : String(value);
	if (typeName === "directory") return "directory";
	if (typeName === "jwks_uri" || typeName === "cimd") return typeName;
	throw new Error(`unsupported Signature-Agent type ${typeName}`);
}
function validateDiscoveryURI(uri, type) {
	const url = new URL(uri);
	if (type === "directory") {
		if (url.protocol === "http:" || url.protocol === "https:") return;
		throw new Error("directory Signature-Agent must use http or https");
	}
	if (url.protocol !== "https:") throw new Error(`${type} Signature-Agent must use https`);
}
function parseSignatureAgentHeader(header) {
	try {
		const dictionary = parseDictionary(header);
		if (dictionary.size === 0) throw new Error("Signature-Agent header must not be empty");
		const entries = [];
		for (const [label, value] of dictionary) {
			const [uri, params] = value;
			if (typeof uri !== "string") throw new Error("Signature-Agent values must be strings");
			const type = discoveryType(params.get("type"));
			validateDiscoveryURI(uri, type);
			entries.push({
				label,
				uri,
				type
			});
		}
		return {
			kind: "current",
			entries
		};
	} catch (dictionaryError) {
		try {
			const [uri] = parseItem(header);
			if (typeof uri !== "string") throw new Error("legacy Signature-Agent must be a string", { cause: dictionaryError });
			validateDiscoveryURI(uri, "directory");
			return {
				kind: "legacy",
				entries: [{
					label: "",
					uri,
					type: "directory"
				}]
			};
		} catch (itemError) {
			throw new Error(`failed to parse Signature-Agent header: ${errorMessage(dictionaryError)}; ${errorMessage(itemError)}`, { cause: itemError });
		}
	}
}
function errorMessage(error) {
	return error instanceof Error ? error.message : String(error);
}
var HTTP_MESSAGE_SIGNATURE_TAG = "web-bot-auth";
var SIGNATURE_AGENT_HEADER = "signature-agent";
function policyError(message) {
	throw new SignatureError(SignatureErrorCode.PolicyViolation, message);
}
function seconds(date, name) {
	const milliseconds = date.getTime();
	if (!Number.isFinite(milliseconds)) return policyError(`${name} must be a valid date`);
	return Math.floor(milliseconds / 1e3);
}
function base64(bytes) {
	return btoa(String.fromCharCode(...bytes));
}
function base64Url$1(bytes) {
	return base64(bytes).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function decodeBase64(value) {
	const normalized = value.replace(/-/g, "+").replace(/_/g, "/");
	const remainder = normalized.length % 4;
	if (remainder === 1) return void 0;
	const padded = normalized + "=".repeat((4 - remainder) % 4);
	try {
		return Uint8Array.from(atob(padded), (character) => character.charCodeAt(0));
	} catch {
		return;
	}
}
function validateNonce(nonce) {
	if (typeof nonce !== "string") return false;
	const decoded = decodeBase64(nonce);
	return decoded !== void 0 && decoded.length === 64 && (base64(decoded) === nonce || base64Url$1(decoded) === nonce);
}
function requestHeader(request, name) {
	if ("kind" in request) {
		const values = request.fields.filter((field) => field.name.toLowerCase() === name).map((field) => field.value.trim());
		return values.length === 0 ? void 0 : values.join(", ");
	}
	return request.headers.get(name) ?? void 0;
}
function signingSignatureAgent(request, key) {
	const header = requestHeader(request, SIGNATURE_AGENT_HEADER);
	if (header === void 0) return void 0;
	const parsed = parseSignatureAgentHeader(header);
	if (parsed.kind === "legacy") {
		if (parsed.entries[0] === void 0) return policyError("Signature-Agent is empty");
		return Object.freeze({ component: SIGNATURE_AGENT_HEADER });
	}
	if (parsed.entries.find((candidate) => candidate.label === key) === void 0) return policyError(`Signature-Agent has no member ${key}`);
	return Object.freeze({ component: component(SIGNATURE_AGENT_HEADER, { key }) });
}
function signingOptions(request, options) {
	if (options.signer.algorithm !== "ed25519" && options.signer.algorithm !== "rsa-pss-sha512") return policyError("signer algorithm is unsupported");
	if (options.signer.keyid === "") return policyError("signer keyid must not be empty");
	const label = options.label ?? "sig1";
	const created = seconds(options.created ?? /* @__PURE__ */ new Date(), "created");
	const expires = seconds(options.expires, "expires");
	if (created > expires) return policyError("created must not be after expires");
	if (options.nonce !== void 0 && !validateNonce(options.nonce)) return policyError("nonce must be canonical base64 or unpadded base64url encoding of 64 bytes");
	const agent = signingSignatureAgent(request, options.signatureAgentKey ?? label);
	const components = [options.target ?? "@authority"];
	if (agent !== void 0) components.push(agent.component);
	components.push(...options.additionalComponents ?? []);
	return {
		label,
		components,
		parameters: {
			created,
			keyid: options.signer.keyid,
			alg: options.signer.algorithm,
			expires,
			nonce: options.nonce,
			tag: HTTP_MESSAGE_SIGNATURE_TAG
		}
	};
}
async function sign(request, options) {
	return createSignature(request, {
		...signingOptions(request, options),
		signer: options.signer
	});
}
//#endregion
//#region node_modules/.pnpm/web-bot-auth@0.2.0/node_modules/web-bot-auth/dist/crypto.mjs
function base64Url(buffer) {
	return btoa(String.fromCharCode(...new Uint8Array(buffer))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
async function keyid(jwk) {
	return jwkThumbprint(jwk, (value) => crypto.subtle.digest("SHA-256", value), base64Url);
}
function jwkAlgorithm(jwk) {
	if (jwk.kty === "OKP" && jwk.crv === "Ed25519") {
		if (jwk.alg !== void 0 && jwk.alg !== "EdDSA") throw new Error("Ed25519 JWK alg must be EdDSA when present");
		return "ed25519";
	}
	if (jwk.kty === "RSA" && jwk.alg === "PS512") return "rsa-pss-sha512";
	throw new Error("JWK must be Ed25519 or RSA-PSS/SHA-512");
}
function importAlgorithm(algorithm) {
	return algorithm === "ed25519" ? { name: "Ed25519" } : {
		name: "RSA-PSS",
		hash: "SHA-512"
	};
}
async function signerFromJWK(jwk) {
	const algorithm = jwkAlgorithm(jwk);
	const key = await crypto.subtle.importKey("jwk", jwk, importAlgorithm(algorithm), false, ["sign"]);
	const signer = webcrypto.signer(key);
	if (signer.algorithm !== algorithm) throw new Error("imported CryptoKey algorithm does not match JWK");
	return Object.freeze({
		algorithm,
		keyid: await keyid(jwk),
		sign(data) {
			return signer.sign(data);
		}
	});
}
//#endregion
//#region src/server/lib/audit/web-bot-auth.ts
var CRAWL_USER_AGENT = "OpenSEO-Audit/1.0";
/** Where verifiers fetch our public key: `<origin>/.well-known/http-message-signatures-directory`. */
var SIGNATURE_AGENT_ORIGIN = "https://app.openseo.so";
var SIGNATURE_LIFETIME_MS = 6e4;
var ed25519PrivateJwk = object({
	kty: literal("OKP"),
	crv: literal("Ed25519"),
	x: string(),
	d: string()
});
var signingKeyPromise;
/** Null when signing is off. A bad key must not take audits down: crawl unsigned. */
function getSigningKey() {
	signingKeyPromise ??= loadSigningKey().catch(() => {
		console.error("WEB_BOT_AUTH_JWK is unusable; crawling unsigned");
		return null;
	});
	return signingKeyPromise;
}
async function loadSigningKey() {
	const jwkText = await getOptionalEnvValue("WEB_BOT_AUTH_JWK");
	if (!jwkText) return null;
	const jwk = ed25519PrivateJwk.parse(JSON.parse(jwkText));
	return {
		signer: await signerFromJWK(jwk),
		publicJwk: {
			kty: jwk.kty,
			crv: jwk.crv,
			x: jwk.x
		}
	};
}
/**
* Headers for one crawler request to `url`. Shopify crawler access already
* carries its own `Signature*` headers for that store, so ours are only added
* when no crawler-access credential applies.
*/
async function auditRequestHeaders(url, access) {
	const headers = { "User-Agent": CRAWL_USER_AGENT };
	const accessHeaders = crawlerHeadersFor(url, access);
	if (Object.keys(accessHeaders).length > 0) return {
		...headers,
		...accessHeaders
	};
	const key = await getSigningKey();
	if (!key) return headers;
	headers["Signature-Agent"] = `"${SIGNATURE_AGENT_ORIGIN}"`;
	const now = /* @__PURE__ */ new Date();
	const fields = await sign({
		kind: "request",
		method: "GET",
		targetUri: url,
		fields: Object.entries(headers).map(([name, value]) => ({
			name,
			value
		}))
	}, {
		signer: key.signer,
		created: now,
		expires: new Date(now.getTime() + SIGNATURE_LIFETIME_MS)
	});
	headers.Signature = fields.signature;
	headers["Signature-Input"] = fields.signatureInput;
	return headers;
}
//#endregion
//#region src/server/lib/audit/url-policy.ts
var BLOCKED_HOSTS = /* @__PURE__ */ new Set([
	"localhost",
	"metadata.google.internal",
	"metadata",
	"169.254.169.254",
	"100.100.100.200"
]);
var BLOCKED_HOST_SUFFIXES = [
	".localhost",
	".local",
	".localdomain",
	".internal",
	".home.arpa"
];
var DOH_ENDPOINT = "https://cloudflare-dns.com/dns-query";
function normalizeHost(hostname) {
	let host = hostname.toLowerCase().trim();
	if (host.startsWith("[") && host.endsWith("]")) host = host.slice(1, -1);
	if (host.includes("%")) host = host.split("%", 1)[0];
	if (host.endsWith(".")) host = host.slice(0, -1);
	return host;
}
function isPrivateIpv4(host) {
	const parts = normalizeHost(host).split(".").map((x) => Number(x));
	if (parts.length !== 4 || parts.some((x) => !Number.isInteger(x) || x < 0 || x > 255)) return false;
	const [a, b] = parts;
	if (a === 10) return true;
	if (a === 127) return true;
	if (a === 0) return true;
	if (a === 169 && b === 254) return true;
	if (a === 172 && b >= 16 && b <= 31) return true;
	if (a === 192 && b === 168) return true;
	if (a === 100 && b >= 64 && b <= 127) return true;
	if (a === 198 && (b === 18 || b === 19)) return true;
	if (a >= 224) return true;
	return false;
}
function parseMappedIpv4FromIpv6(host) {
	const normalized = normalizeHost(host);
	if (!normalized.startsWith("::ffff:")) return null;
	const mapped = normalized.slice(7);
	if (/^\d+\.\d+\.\d+\.\d+$/.test(mapped)) return mapped;
	const segments = mapped.split(":").filter(Boolean);
	if (segments.length !== 2) return null;
	const high = Number.parseInt(segments[0], 16);
	const low = Number.parseInt(segments[1], 16);
	if (!Number.isFinite(high) || !Number.isFinite(low) || high < 0 || high > 65535 || low < 0 || low > 65535) return null;
	return `${high >> 8 & 255}.${high & 255}.${low >> 8 & 255}.${low & 255}`;
}
function isPrivateIpv6(host) {
	const value = normalizeHost(host);
	if (value === "::1" || value === "::") return true;
	if (value.startsWith("fc") || value.startsWith("fd")) return true;
	if (value.startsWith("fe8") || value.startsWith("fe9") || value.startsWith("fea") || value.startsWith("feb")) return true;
	const mappedIpv4 = parseMappedIpv4FromIpv6(value);
	if (mappedIpv4 && isPrivateIpv4(mappedIpv4)) return true;
	return false;
}
function isIpLiteral(host) {
	const normalized = normalizeHost(host);
	return /^\d+\.\d+\.\d+\.\d+$/.test(normalized) || normalized.includes(":");
}
function isBlockedHost(hostname) {
	const host = normalizeHost(hostname);
	if (!host) return true;
	if (BLOCKED_HOSTS.has(host)) return true;
	if (BLOCKED_HOST_SUFFIXES.some((suffix) => host.endsWith(suffix))) return true;
	if (isIpLiteral(host)) return isPrivateIpv4(host) || isPrivateIpv6(host);
	return false;
}
async function resolveAddressRecords(hostname, type) {
	const response = await fetch(`${DOH_ENDPOINT}?name=${encodeURIComponent(hostname)}&type=${type}`, {
		headers: { Accept: "application/dns-json" },
		signal: AbortSignal.timeout(2500)
	});
	if (!response.ok) return [];
	const body = await response.json();
	if (body.Status !== 0 || !Array.isArray(body.Answer)) return [];
	const expectedType = type === "A" ? 1 : 28;
	return body.Answer.filter((answer) => answer.type === expectedType && typeof answer.data === "string").map((answer) => normalizeHost(answer.data));
}
async function hostnameResolvesToBlockedAddress(hostname) {
	const host = normalizeHost(hostname);
	if (!host || isIpLiteral(host)) return false;
	try {
		const [v4, v6] = await Promise.all([resolveAddressRecords(host, "A"), resolveAddressRecords(host, "AAAA")]);
		const addresses = [...v4, ...v6];
		if (addresses.length === 0) return false;
		return addresses.some((address) => isPrivateIpv4(address) || isPrivateIpv6(address));
	} catch {
		return false;
	}
}
/**
* Shopify storefronts, custom domains included, resolve into Shopify's
* 23.227.38.0/24. This identifies a store even when its edge answers with a
* bare 429 that carries no `powered-by` header.
*/
async function isShopifyHost(hostname) {
	try {
		return (await resolveAddressRecords(normalizeHost(hostname), "A")).some((address) => address.startsWith("23.227.38."));
	} catch {
		return false;
	}
}
/**
* Synchronous SSRF check for URLs discovered mid-crawl (links, redirect
* targets, sitemap entries). Blocks non-http(s) schemes, private/loopback IP
* literals, and internal hostnames. DNS resolution is only performed for the
* start URL (see normalizeAndValidateStartUrl); per-link DoH lookups would be
* prohibitively slow.
*/
function isCrawlableUrl(url) {
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		return false;
	}
	if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return false;
	return !isBlockedHost(parsed.hostname);
}
async function normalizeAndValidateStartUrl(input) {
	let raw = input.trim();
	if (!raw) throw new AppError("VALIDATION_ERROR");
	if (!raw.startsWith("http://") && !raw.startsWith("https://")) raw = `https://${raw}`;
	let parsed;
	try {
		parsed = new URL(raw);
	} catch {
		throw new AppError("VALIDATION_ERROR");
	}
	if (parsed.protocol !== "http:" && parsed.protocol !== "https:") throw new AppError("VALIDATION_ERROR");
	if (isBlockedHost(parsed.hostname)) throw new AppError("CRAWL_TARGET_BLOCKED");
	if (await hostnameResolvesToBlockedAddress(parsed.hostname)) throw new AppError("CRAWL_TARGET_BLOCKED");
	parsed.hash = "";
	return parsed.toString();
}
var START_URL_REDIRECT_HOPS = 5;
var START_URL_PROBE_TIMEOUT_MS = 1e4;
/**
* Follow redirects on the audit's start URL so the audit anchors to the
* site's real origin. Without this, auditing a domain that 301s elsewhere
* (\u2026net -> \u2026com, apex -> www) dead-ends after one page: the redirect target
* is a different origin, so the same-origin crawl policy can't follow it.
*
* Every hop re-runs the full start-URL validation (SSRF, blocked hosts), so
* a redirect can't smuggle the audit somewhere the user couldn't have
* pointed it directly. Probe failures (timeouts, HEAD rejected) fall back
* to the last validated URL \u2014 the crawl records the real fetch result.
*
* Also reports the final response's `powered-by` header, which is how a
* Shopify storefront identifies itself.
*/
async function resolveStartUrlRedirects(startUrl, access) {
	let current = startUrl;
	for (let hop = 0; hop < START_URL_REDIRECT_HOPS; hop++) {
		let response;
		try {
			response = await publicFetch(current, {
				method: "HEAD",
				redirect: "manual",
				headers: await auditRequestHeaders(current, access),
				signal: AbortSignal.timeout(START_URL_PROBE_TIMEOUT_MS)
			});
		} catch {
			return {
				url: current,
				poweredBy: null
			};
		}
		if (response.status < 300 || response.status >= 400) return {
			url: current,
			poweredBy: response.headers.get("powered-by")
		};
		const location = response.headers.get("location");
		if (!location) return {
			url: current,
			poweredBy: response.headers.get("powered-by")
		};
		let next;
		try {
			next = new URL(location, current);
		} catch {
			return {
				url: current,
				poweredBy: null
			};
		}
		current = await normalizeAndValidateStartUrl(next.toString());
	}
	return {
		url: current,
		poweredBy: null
	};
}
//#endregion
//#region src/server/lib/audit/classify-fetch.ts
var CHALLENGE_2XX = /<title>\s*(?:just a moment\.\.\.|attention required! \| cloudflare)\s*<\/title>|\/\.well-known\/sgcaptcha\//i;
var CHALLENGE_BODY_MARKERS = [
	"just a moment...",
	"challenge-platform",
	"cf-browser-verification",
	"attention required! | cloudflare",
	"verifying you are human"
];
function classifyFetch(statusCode, mitigated, bodySnippet) {
	if (statusCode === 0) return "error";
	if (statusCode === 429) return "rate_limited";
	if (mitigated) return "blocked";
	if (statusCode === 401 || statusCode === 403) return "blocked";
	if (statusCode === 202) return "blocked";
	if (statusCode >= 200 && statusCode < 300 && CHALLENGE_2XX.test(bodySnippet)) return "blocked";
	if (statusCode === 503) {
		const snippet = bodySnippet.toLowerCase();
		if (CHALLENGE_BODY_MARKERS.some((marker) => snippet.includes(marker))) return "blocked";
	}
	return "ok";
}
//#endregion
export { parseSignatureExpiry as A, record as B, isEveryAppAuthMode as C, SHOPIFY_SIGNATURE_AGENT as D, describeError as E, codec as F, unknown as H, custom as I, literal as L, _enum as M, array as N, crawlerHeadersFor as O, boolean as P, number as R, isHostedServerAuthMode as S, asAppError as T, string as V, applyBillingMarkupUsd as _, CRAWL_USER_AGENT as a, getRequiredEnvValue as b, MAX_HTML_BYTES as c, truncateToBytes as d, CLOUDFLARE_RENDER_TIMEOUT_MS as f, AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID as g, AUTUMN_SEO_DATA_BALANCE_FEATURE_ID as h, resolveStartUrlRedirects as i, shopifyCrawlerHeaders as j, isCrawlerAccessExpired as k, readBodyCapped as l, renderUsageCredits as m, isCrawlableUrl as n, auditRequestHeaders as o, estimateRenderingCredits as p, isShopifyHost as r, publicFetch as s, classifyFetch as t, readTextUpTo as u, creditsForProviderUsd as v, AppError as w, getWorkersEnv as x, getOptionalEnvValue as y, object as z };
