import { B as isNull, F as and, G as getTableColumns, I as eq, J as __commonJSMin, K as sql, N as asc, P as desc, Y as __toESM, i as withPgClient, q as getDatabaseProvider, t as db, z as inArray } from "./assets/db-DUti_knk.js";
import { a as auditPages, d as projects, i as auditLighthouseResults, n as runBatch, o as audits, r as auditIssues, s as crawlerCredentials, t as executeInBatches } from "./assets/runBatch-DHGTu4fq.js";
import { Vn as NEVER } from "./assets/api-Cna0nU1W.js";
import { A as parseSignatureExpiry, B as record, C as isEveryAppAuthMode, D as SHOPIFY_SIGNATURE_AGENT, E as describeError, F as codec, H as unknown, I as custom, L as literal, M as _enum, N as array, O as crawlerHeadersFor, P as boolean, R as number, S as isHostedServerAuthMode, T as asAppError, V as string, _ as applyBillingMarkupUsd, b as getRequiredEnvValue, c as MAX_HTML_BYTES, g as AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID, h as AUTUMN_SEO_DATA_BALANCE_FEATURE_ID, i as resolveStartUrlRedirects, j as shopifyCrawlerHeaders, k as isCrawlerAccessExpired, l as readBodyCapped, m as renderUsageCredits, n as isCrawlableUrl, o as auditRequestHeaders, p as estimateRenderingCredits, r as isShopifyHost, s as publicFetch, t as classifyFetch, u as readTextUpTo, v as creditsForProviderUsd, w as AppError, x as getWorkersEnv, y as getOptionalEnvValue, z as object } from "./assets/classify-fetch-YHmDctpP.js";
import { a as isSameOrigin, i as isAuditablePageUrl, n as detectUrlTemplate, o as normalizeUrl, r as getOrigin, t as canonicalUrlKey } from "./assets/url-utils-D6UsRC0J.js";
import { EventEmitter } from "node:events";
import { Writable } from "node:stream";
import { DurableObject, WorkerEntrypoint, WorkflowEntrypoint, env, waitUntil } from "cloudflare:workers";
import { AsyncLocalStorage } from "node:async_hooks";
import { NonRetryableError } from "cloudflare:workflows";
//#region node_modules/.pnpm/unenv@2.0.0-rc.24/node_modules/unenv/dist/runtime/node/internal/process/hrtime.mjs
var hrtime$1 = /* @__PURE__ */ Object.assign(function hrtime(startTime) {
	const now = Date.now();
	const seconds = Math.trunc(now / 1e3);
	const nanos = now % 1e3 * 1e6;
	if (startTime) {
		let diffSeconds = seconds - startTime[0];
		let diffNanos = nanos - startTime[0];
		if (diffNanos < 0) {
			diffSeconds = diffSeconds - 1;
			diffNanos = 1e9 + diffNanos;
		}
		return [diffSeconds, diffNanos];
	}
	return [seconds, nanos];
}, { bigint: function bigint() {
	return BigInt(Date.now() * 1e6);
} });
//#endregion
//#region node_modules/.pnpm/unenv@2.0.0-rc.24/node_modules/unenv/dist/runtime/node/internal/tty/read-stream.mjs
var ReadStream = class {
	fd;
	isRaw = false;
	isTTY = false;
	constructor(fd) {
		this.fd = fd;
	}
	setRawMode(mode) {
		this.isRaw = mode;
		return this;
	}
};
//#endregion
//#region node_modules/.pnpm/unenv@2.0.0-rc.24/node_modules/unenv/dist/runtime/node/internal/tty/write-stream.mjs
var WriteStream = class {
	fd;
	columns = 80;
	rows = 24;
	isTTY = false;
	constructor(fd) {
		this.fd = fd;
	}
	clearLine(dir, callback) {
		callback && callback();
		return false;
	}
	clearScreenDown(callback) {
		callback && callback();
		return false;
	}
	cursorTo(x, y, callback) {
		callback && typeof callback === "function" && callback();
		return false;
	}
	moveCursor(dx, dy, callback) {
		callback && callback();
		return false;
	}
	getColorDepth(env) {
		return 1;
	}
	hasColors(count, env) {
		return false;
	}
	getWindowSize() {
		return [this.columns, this.rows];
	}
	write(str, encoding, cb) {
		if (str instanceof Uint8Array) str = new TextDecoder().decode(str);
		try {
			console.log(str);
		} catch {}
		cb && typeof cb === "function" && cb();
		return false;
	}
};
//#endregion
//#region node_modules/.pnpm/unenv@2.0.0-rc.24/node_modules/unenv/dist/runtime/_internal/utils.mjs
/* @__NO_SIDE_EFFECTS__ */
function createNotImplementedError(name) {
	return /* @__PURE__ */ new Error(`[unenv] ${name} is not implemented yet!`);
}
/* @__NO_SIDE_EFFECTS__ */
function notImplemented(name) {
	const fn = () => {
		throw /* @__PURE__ */ createNotImplementedError(name);
	};
	return Object.assign(fn, { __unenv__: true });
}
/* @__NO_SIDE_EFFECTS__ */
function notImplementedClass(name) {
	return class {
		__unenv__ = true;
		constructor() {
			throw new Error(`[unenv] ${name} is not implemented yet!`);
		}
	};
}
//#endregion
//#region node_modules/.pnpm/unenv@2.0.0-rc.24/node_modules/unenv/dist/runtime/node/internal/process/node-version.mjs
var NODE_VERSION = "22.14.0";
//#endregion
//#region node_modules/.pnpm/unenv@2.0.0-rc.24/node_modules/unenv/dist/runtime/node/internal/process/process.mjs
var Process = class Process extends EventEmitter {
	env;
	hrtime;
	nextTick;
	constructor(impl) {
		super();
		this.env = impl.env;
		this.hrtime = impl.hrtime;
		this.nextTick = impl.nextTick;
		for (const prop of [...Object.getOwnPropertyNames(Process.prototype), ...Object.getOwnPropertyNames(EventEmitter.prototype)]) {
			const value = this[prop];
			if (typeof value === "function") this[prop] = value.bind(this);
		}
	}
	emitWarning(warning, type, code) {
		console.warn(`${code ? `[${code}] ` : ""}${type ? `${type}: ` : ""}${warning}`);
	}
	emit(...args) {
		return super.emit(...args);
	}
	listeners(eventName) {
		return super.listeners(eventName);
	}
	#stdin;
	#stdout;
	#stderr;
	get stdin() {
		return this.#stdin ??= new ReadStream(0);
	}
	get stdout() {
		return this.#stdout ??= new WriteStream(1);
	}
	get stderr() {
		return this.#stderr ??= new WriteStream(2);
	}
	#cwd = "/";
	chdir(cwd) {
		this.#cwd = cwd;
	}
	cwd() {
		return this.#cwd;
	}
	arch = "";
	platform = "";
	argv = [];
	argv0 = "";
	execArgv = [];
	execPath = "";
	title = "";
	pid = 200;
	ppid = 100;
	get version() {
		return `v${NODE_VERSION}`;
	}
	get versions() {
		return { node: NODE_VERSION };
	}
	get allowedNodeEnvironmentFlags() {
		return /* @__PURE__ */ new Set();
	}
	get sourceMapsEnabled() {
		return false;
	}
	get debugPort() {
		return 0;
	}
	get throwDeprecation() {
		return false;
	}
	get traceDeprecation() {
		return false;
	}
	get features() {
		return {};
	}
	get release() {
		return {};
	}
	get connected() {
		return false;
	}
	get config() {
		return {};
	}
	get moduleLoadList() {
		return [];
	}
	constrainedMemory() {
		return 0;
	}
	availableMemory() {
		return 0;
	}
	uptime() {
		return 0;
	}
	resourceUsage() {
		return {};
	}
	ref() {}
	unref() {}
	umask() {
		throw /* @__PURE__ */ createNotImplementedError("process.umask");
	}
	getBuiltinModule() {}
	getActiveResourcesInfo() {
		throw /* @__PURE__ */ createNotImplementedError("process.getActiveResourcesInfo");
	}
	exit() {
		throw /* @__PURE__ */ createNotImplementedError("process.exit");
	}
	reallyExit() {
		throw /* @__PURE__ */ createNotImplementedError("process.reallyExit");
	}
	kill() {
		throw /* @__PURE__ */ createNotImplementedError("process.kill");
	}
	abort() {
		throw /* @__PURE__ */ createNotImplementedError("process.abort");
	}
	dlopen() {
		throw /* @__PURE__ */ createNotImplementedError("process.dlopen");
	}
	setSourceMapsEnabled() {
		throw /* @__PURE__ */ createNotImplementedError("process.setSourceMapsEnabled");
	}
	loadEnvFile() {
		throw /* @__PURE__ */ createNotImplementedError("process.loadEnvFile");
	}
	disconnect() {
		throw /* @__PURE__ */ createNotImplementedError("process.disconnect");
	}
	cpuUsage() {
		throw /* @__PURE__ */ createNotImplementedError("process.cpuUsage");
	}
	setUncaughtExceptionCaptureCallback() {
		throw /* @__PURE__ */ createNotImplementedError("process.setUncaughtExceptionCaptureCallback");
	}
	hasUncaughtExceptionCaptureCallback() {
		throw /* @__PURE__ */ createNotImplementedError("process.hasUncaughtExceptionCaptureCallback");
	}
	initgroups() {
		throw /* @__PURE__ */ createNotImplementedError("process.initgroups");
	}
	openStdin() {
		throw /* @__PURE__ */ createNotImplementedError("process.openStdin");
	}
	assert() {
		throw /* @__PURE__ */ createNotImplementedError("process.assert");
	}
	binding() {
		throw /* @__PURE__ */ createNotImplementedError("process.binding");
	}
	permission = { has: /* @__PURE__ */ notImplemented("process.permission.has") };
	report = {
		directory: "",
		filename: "",
		signal: "SIGUSR2",
		compact: false,
		reportOnFatalError: false,
		reportOnSignal: false,
		reportOnUncaughtException: false,
		getReport: /* @__PURE__ */ notImplemented("process.report.getReport"),
		writeReport: /* @__PURE__ */ notImplemented("process.report.writeReport")
	};
	finalization = {
		register: /* @__PURE__ */ notImplemented("process.finalization.register"),
		unregister: /* @__PURE__ */ notImplemented("process.finalization.unregister"),
		registerBeforeExit: /* @__PURE__ */ notImplemented("process.finalization.registerBeforeExit")
	};
	memoryUsage = Object.assign(() => ({
		arrayBuffers: 0,
		rss: 0,
		external: 0,
		heapTotal: 0,
		heapUsed: 0
	}), { rss: () => 0 });
	mainModule = void 0;
	domain = void 0;
	send = void 0;
	exitCode = void 0;
	channel = void 0;
	getegid = void 0;
	geteuid = void 0;
	getgid = void 0;
	getgroups = void 0;
	getuid = void 0;
	setegid = void 0;
	seteuid = void 0;
	setgid = void 0;
	setgroups = void 0;
	setuid = void 0;
	_events = void 0;
	_eventsCount = void 0;
	_exiting = void 0;
	_maxListeners = void 0;
	_debugEnd = void 0;
	_debugProcess = void 0;
	_fatalException = void 0;
	_getActiveHandles = void 0;
	_getActiveRequests = void 0;
	_kill = void 0;
	_preload_modules = void 0;
	_rawDebug = void 0;
	_startProfilerIdleNotifier = void 0;
	_stopProfilerIdleNotifier = void 0;
	_tickCallback = void 0;
	_disconnect = void 0;
	_handleQueue = void 0;
	_pendingMessage = void 0;
	_channel = void 0;
	_send = void 0;
	_linkedBinding = void 0;
};
//#endregion
//#region node_modules/.pnpm/@cloudflare+unenv-preset@2.16.2_unenv@2.0.0-rc.24_workerd@1.20261012.1/node_modules/@cloudflare/unenv-preset/dist/runtime/node/process.mjs
var globalProcess = globalThis["process"];
var getBuiltinModule = globalProcess.getBuiltinModule;
var workerdProcess = getBuiltinModule("node:process");
var unenvProcess = new Process({
	env: globalProcess.env,
	hrtime: hrtime$1,
	nextTick: workerdProcess.nextTick
});
var { exit, features, platform } = workerdProcess;
var { _channel, _debugEnd, _debugProcess, _disconnect, _events, _eventsCount, _exiting, _fatalException, _getActiveHandles, _getActiveRequests, _handleQueue, _kill, _linkedBinding, _maxListeners, _pendingMessage, _preload_modules, _rawDebug, _send, _startProfilerIdleNotifier, _stopProfilerIdleNotifier, _tickCallback, abort, addListener, allowedNodeEnvironmentFlags, arch, argv, argv0, assert: assert$1, availableMemory, binding, channel, chdir, config, connected, constrainedMemory, cpuUsage, cwd, debugPort, disconnect, dlopen, domain, emit, emitWarning, env: env$1, eventNames, execArgv, execPath, exitCode, finalization, getActiveResourcesInfo, getegid, geteuid, getgid, getgroups, getMaxListeners, getuid, hasUncaughtExceptionCaptureCallback, hrtime, initgroups, kill, listenerCount, listeners, loadEnvFile, mainModule, memoryUsage, moduleLoadList, nextTick, off, on, once, openStdin, permission, pid, ppid, prependListener, prependOnceListener, rawListeners, reallyExit, ref, release, removeAllListeners, removeListener, report, resourceUsage, send, setegid, seteuid, setgid, setgroups, setMaxListeners, setSourceMapsEnabled, setuid, setUncaughtExceptionCaptureCallback, sourceMapsEnabled, stderr, stdin, stdout, throwDeprecation, title, traceDeprecation, umask, unref, uptime, version: version$1, versions } = unenvProcess;
//#endregion
//#region \0virtual:cloudflare/nodejs-global-inject/@cloudflare/unenv-preset/node/process
globalThis.process = {
	abort,
	addListener,
	allowedNodeEnvironmentFlags,
	hasUncaughtExceptionCaptureCallback,
	setUncaughtExceptionCaptureCallback,
	loadEnvFile,
	sourceMapsEnabled,
	arch,
	argv,
	argv0,
	chdir,
	config,
	connected,
	constrainedMemory,
	availableMemory,
	cpuUsage,
	cwd,
	debugPort,
	dlopen,
	disconnect,
	emit,
	emitWarning,
	env: env$1,
	eventNames,
	execArgv,
	execPath,
	exit,
	finalization,
	features,
	getBuiltinModule,
	getActiveResourcesInfo,
	getMaxListeners,
	hrtime,
	kill,
	listeners,
	listenerCount,
	memoryUsage,
	nextTick,
	on,
	off,
	once,
	pid,
	platform,
	ppid,
	prependListener,
	prependOnceListener,
	rawListeners,
	release,
	removeAllListeners,
	removeListener,
	report,
	resourceUsage,
	setMaxListeners,
	setSourceMapsEnabled,
	stderr,
	stdin,
	stdout,
	title,
	throwDeprecation,
	traceDeprecation,
	umask,
	uptime,
	version: version$1,
	versions,
	domain,
	initgroups,
	moduleLoadList,
	reallyExit,
	openStdin,
	assert: assert$1,
	binding,
	send,
	exitCode,
	channel,
	getegid,
	geteuid,
	getgid,
	getgroups,
	getuid,
	setegid,
	seteuid,
	setgid,
	setgroups,
	setuid,
	permission,
	mainModule,
	_events,
	_eventsCount,
	_exiting,
	_maxListeners,
	_debugEnd,
	_debugProcess,
	_fatalException,
	_getActiveHandles,
	_getActiveRequests,
	_kill,
	_preload_modules,
	_rawDebug,
	_startProfilerIdleNotifier,
	_stopProfilerIdleNotifier,
	_tickCallback,
	_disconnect,
	_handleQueue,
	_pendingMessage,
	_channel,
	_send,
	_linkedBinding
};
//#endregion
//#region node_modules/.pnpm/unenv@2.0.0-rc.24/node_modules/unenv/dist/runtime/mock/noop.mjs
var noop_default = Object.assign(() => {}, { __unenv__: true });
//#endregion
//#region node_modules/.pnpm/unenv@2.0.0-rc.24/node_modules/unenv/dist/runtime/node/console.mjs
var _console = globalThis.console;
var _stderr = new Writable();
var _stdout = new Writable();
_console?.log;
_console?.info;
_console?.trace;
_console?.debug;
_console?.table;
_console?.error;
_console?.warn;
_console?.createTask;
_console?.clear;
_console?.count;
_console?.countReset;
_console?.dir;
_console?.dirxml;
_console?.group;
_console?.groupEnd;
_console?.groupCollapsed;
_console?.profile;
_console?.profileEnd;
_console?.time;
_console?.timeEnd;
_console?.timeLog;
_console?.timeStamp;
var Console = _console?.Console ?? /* @__PURE__ */ notImplementedClass("console.Console");
var _times = /* @__PURE__ */ new Map();
var _stdoutErrorHandler = noop_default;
var _stderrErrorHandler = noop_default;
//#endregion
//#region node_modules/.pnpm/@cloudflare+unenv-preset@2.16.2_unenv@2.0.0-rc.24_workerd@1.20261012.1/node_modules/@cloudflare/unenv-preset/dist/runtime/node/console.mjs
var workerdConsole = globalThis["console"];
var { assert, clear: clear$1, context, count: count$1, countReset, createTask, debug, dir, dirxml, error, group, groupCollapsed, groupEnd, info, log, profile, profileEnd, table, time, timeEnd, timeLog, timeStamp, trace, warn } = workerdConsole;
Object.assign(workerdConsole, {
	Console,
	_ignoreErrors: true,
	_stderr,
	_stderrErrorHandler,
	_stdout,
	_stdoutErrorHandler,
	_times
});
//#endregion
//#region \0virtual:cloudflare/nodejs-global-inject/@cloudflare/unenv-preset/node/console
globalThis.console = workerdConsole;
//#endregion
//#region node_modules/.pnpm/unenv@2.0.0-rc.24/node_modules/unenv/dist/runtime/node/internal/perf_hooks/performance.mjs
var _timeOrigin = globalThis.performance?.timeOrigin ?? Date.now();
var _performanceNow = globalThis.performance?.now ? globalThis.performance.now.bind(globalThis.performance) : () => Date.now() - _timeOrigin;
var nodeTiming = {
	name: "node",
	entryType: "node",
	startTime: 0,
	duration: 0,
	nodeStart: 0,
	v8Start: 0,
	bootstrapComplete: 0,
	environment: 0,
	loopStart: 0,
	loopExit: 0,
	idleTime: 0,
	uvMetricsInfo: {
		loopCount: 0,
		events: 0,
		eventsWaiting: 0
	},
	detail: void 0,
	toJSON() {
		return this;
	}
};
var PerformanceEntry = class {
	__unenv__ = true;
	detail;
	entryType = "event";
	name;
	startTime;
	constructor(name, options) {
		this.name = name;
		this.startTime = options?.startTime || _performanceNow();
		this.detail = options?.detail;
	}
	get duration() {
		return _performanceNow() - this.startTime;
	}
	toJSON() {
		return {
			name: this.name,
			entryType: this.entryType,
			startTime: this.startTime,
			duration: this.duration,
			detail: this.detail
		};
	}
};
var PerformanceMark = class PerformanceMark extends PerformanceEntry {
	entryType = "mark";
	constructor() {
		super(...arguments);
	}
	get duration() {
		return 0;
	}
};
var PerformanceMeasure = class extends PerformanceEntry {
	entryType = "measure";
};
var PerformanceResourceTiming = class extends PerformanceEntry {
	entryType = "resource";
	serverTiming = [];
	connectEnd = 0;
	connectStart = 0;
	decodedBodySize = 0;
	domainLookupEnd = 0;
	domainLookupStart = 0;
	encodedBodySize = 0;
	fetchStart = 0;
	initiatorType = "";
	name = "";
	nextHopProtocol = "";
	redirectEnd = 0;
	redirectStart = 0;
	requestStart = 0;
	responseEnd = 0;
	responseStart = 0;
	secureConnectionStart = 0;
	startTime = 0;
	transferSize = 0;
	workerStart = 0;
	responseStatus = 0;
};
var PerformanceObserverEntryList = class {
	__unenv__ = true;
	getEntries() {
		return [];
	}
	getEntriesByName(_name, _type) {
		return [];
	}
	getEntriesByType(type) {
		return [];
	}
};
var Performance = class {
	__unenv__ = true;
	timeOrigin = _timeOrigin;
	eventCounts = /* @__PURE__ */ new Map();
	_entries = [];
	_resourceTimingBufferSize = 0;
	navigation = void 0;
	timing = void 0;
	timerify(_fn, _options) {
		throw /* @__PURE__ */ createNotImplementedError("Performance.timerify");
	}
	get nodeTiming() {
		return nodeTiming;
	}
	eventLoopUtilization() {
		return {};
	}
	markResourceTiming() {
		return new PerformanceResourceTiming("");
	}
	onresourcetimingbufferfull = null;
	now() {
		if (this.timeOrigin === _timeOrigin) return _performanceNow();
		return Date.now() - this.timeOrigin;
	}
	clearMarks(markName) {
		this._entries = markName ? this._entries.filter((e) => e.name !== markName) : this._entries.filter((e) => e.entryType !== "mark");
	}
	clearMeasures(measureName) {
		this._entries = measureName ? this._entries.filter((e) => e.name !== measureName) : this._entries.filter((e) => e.entryType !== "measure");
	}
	clearResourceTimings() {
		this._entries = this._entries.filter((e) => e.entryType !== "resource" || e.entryType !== "navigation");
	}
	getEntries() {
		return this._entries;
	}
	getEntriesByName(name, type) {
		return this._entries.filter((e) => e.name === name && (!type || e.entryType === type));
	}
	getEntriesByType(type) {
		return this._entries.filter((e) => e.entryType === type);
	}
	mark(name, options) {
		const entry = new PerformanceMark(name, options);
		this._entries.push(entry);
		return entry;
	}
	measure(measureName, startOrMeasureOptions, endMark) {
		let start;
		let end;
		if (typeof startOrMeasureOptions === "string") {
			start = this.getEntriesByName(startOrMeasureOptions, "mark")[0]?.startTime;
			end = this.getEntriesByName(endMark, "mark")[0]?.startTime;
		} else {
			start = Number.parseFloat(startOrMeasureOptions?.start) || this.now();
			end = Number.parseFloat(startOrMeasureOptions?.end) || this.now();
		}
		const entry = new PerformanceMeasure(measureName, {
			startTime: start,
			detail: {
				start,
				end
			}
		});
		this._entries.push(entry);
		return entry;
	}
	setResourceTimingBufferSize(maxSize) {
		this._resourceTimingBufferSize = maxSize;
	}
	addEventListener(type, listener, options) {
		throw /* @__PURE__ */ createNotImplementedError("Performance.addEventListener");
	}
	removeEventListener(type, listener, options) {
		throw /* @__PURE__ */ createNotImplementedError("Performance.removeEventListener");
	}
	dispatchEvent(event) {
		throw /* @__PURE__ */ createNotImplementedError("Performance.dispatchEvent");
	}
	toJSON() {
		return this;
	}
};
var PerformanceObserver = class {
	__unenv__ = true;
	static supportedEntryTypes = [];
	_callback = null;
	constructor(callback) {
		this._callback = callback;
	}
	takeRecords() {
		return [];
	}
	disconnect() {
		throw /* @__PURE__ */ createNotImplementedError("PerformanceObserver.disconnect");
	}
	observe(options) {
		throw /* @__PURE__ */ createNotImplementedError("PerformanceObserver.observe");
	}
	bind(fn) {
		return fn;
	}
	runInAsyncScope(fn, thisArg, ...args) {
		return fn.call(thisArg, ...args);
	}
	asyncId() {
		return 0;
	}
	triggerAsyncId() {
		return 0;
	}
	emitDestroy() {
		return this;
	}
};
var performance = globalThis.performance && "addEventListener" in globalThis.performance ? globalThis.performance : new Performance();
//#endregion
//#region node_modules/.pnpm/@cloudflare+unenv-preset@2.16.2_unenv@2.0.0-rc.24_workerd@1.20261012.1/node_modules/@cloudflare/unenv-preset/dist/runtime/polyfill/performance.mjs
if (!("__unenv__" in performance)) {
	const proto = Performance.prototype;
	for (const key of Object.getOwnPropertyNames(proto)) if (key !== "constructor" && !(key in performance)) {
		const desc = Object.getOwnPropertyDescriptor(proto, key);
		if (desc) Object.defineProperty(performance, key, desc);
	}
}
globalThis.performance = performance;
globalThis.Performance = Performance;
globalThis.PerformanceEntry = PerformanceEntry;
globalThis.PerformanceMark = PerformanceMark;
globalThis.PerformanceMeasure = PerformanceMeasure;
globalThis.PerformanceObserver = PerformanceObserver;
globalThis.PerformanceObserverEntryList = PerformanceObserverEntryList;
globalThis.PerformanceResourceTiming = PerformanceResourceTiming;
//#endregion
//#region src/server/features/audit/scratchpad-sql.ts
/**
* The scratchpad's SQLite schema and its two finalize link queries, kept in a
* plain module (no `cloudflare:workers` import) so they can be exercised
* against a real SQLite engine in tests as well as inside the Durable Object.
*/
/**
* `page_links` holds one row per crawled page \u2014 its internal link targets as
* a JSON array of URL strings \u2014 instead of one row per edge. Rows written is
* the DO SQLite billing unit, and link edges dominate an audit's writes.
* WITHOUT ROWID keeps the TEXT primary key as the table itself, so a page
* costs exactly one row written rather than a row plus an autoindex entry.
*
* The legacy per-edge `links` table is still declared (without its target
* index, which nothing queries any more) so an audit that was mid-crawl when
* the JSON layout shipped can still be finalized from the rows its earlier
* chunks wrote. Delete the table and the UNION ALL branches in the queries
* below after 2026-09-10: the 7-day cleanup alarm guarantees every such
* object is finished or wiped by then.
*/
var SCRATCHPAD_SCHEMA_SQL = `
  CREATE TABLE IF NOT EXISTS frontier (
    url TEXT PRIMARY KEY,
    depth INTEGER,
    source TEXT NOT NULL,
    in_sitemap INTEGER NOT NULL DEFAULT 0,
    state TEXT NOT NULL DEFAULT 'pending',
    chunk_no INTEGER
  );
  CREATE INDEX IF NOT EXISTS frontier_claim_idx ON frontier (state, source);
  CREATE TABLE IF NOT EXISTS page_links (
    page_id TEXT PRIMARY KEY,
    url TEXT NOT NULL,
    targets_json TEXT NOT NULL
  ) WITHOUT ROWID;
  CREATE TABLE IF NOT EXISTS links (
    source_page_id TEXT NOT NULL,
    source_url TEXT NOT NULL,
    target_url TEXT NOT NULL,
    PRIMARY KEY (source_page_id, target_url)
  );
  CREATE TABLE IF NOT EXISTS page_mirror (
    page_id TEXT PRIMARY KEY,
    url TEXT NOT NULL UNIQUE,
    status_code INTEGER,
    fetch_class TEXT NOT NULL,
    redirect_url TEXT
  );
  CREATE INDEX IF NOT EXISTS page_mirror_redirect_idx ON page_mirror (redirect_url);
`;
/**
* Queue one link-discovered URL. Already-seen URLs keep their row (the
* global dedup), except that a pending row with no click depth yet \u2014 almost
* always a sitemap seed \u2014 takes the link's depth and link-queue priority
* while keeping its in-sitemap flag. Sitemap seeding covers the whole
* sitemap, so without this every linked sitemap page would crawl in sitemap
* order with no depth. Takes (url, depth).
*/
var FRONTIER_DISCOVER_SQL = `
  INSERT INTO frontier (url, depth, source, in_sitemap) VALUES (?, ?, 'link', 0)
  ON CONFLICT(url) DO UPDATE SET source = 'link', depth = excluded.depth
  WHERE frontier.state = 'pending' AND frontier.depth IS NULL
    AND excluded.depth IS NOT NULL
`;
/**
* Every internal link whose target we crawled and saw fail. `json_each`
* expands a page's target array into one row per edge; the join is on
* page_mirror's UNIQUE url, so it stays an index seek per link. CROSS JOIN
* pins that order \u2014 left to itself the planner drives page_mirror off
* `fetch_class` via an automatic index and re-expands the JSON array per
* candidate, which is quadratic in page count. Takes the issue cap as its
* only parameter.
*/
var BROKEN_LINKS_SQL = `
  SELECT source_page_id, source_url, target_url, target_status FROM (
    SELECT p.page_id AS source_page_id, p.url AS source_url, j.value AS target_url,
           m.status_code AS target_status
    FROM page_links p, json_each(p.targets_json) AS j
    CROSS JOIN page_mirror m ON m.url = j.value
    WHERE m.status_code >= 400 AND m.fetch_class = 'ok'
    UNION ALL
    SELECT l.source_page_id, l.source_url, l.target_url, m.status_code AS target_status
    FROM links l JOIN page_mirror m ON m.url = l.target_url
    WHERE m.status_code >= 400 AND m.fetch_class = 'ok'
  )
  ORDER BY source_page_id, target_url
  LIMIT ?
`;
/**
* Pages nothing links to. The inbound set is built once and anti-joined,
* rather than probed per page: without the old per-edge target index a
* correlated NOT EXISTS would rescan the whole edge set for every page.
* Self-links don't count (a page linking to itself doesn't rescue it), and
* page_id is 1:1 with url in page_mirror, so comparing URLs is the same test
* the per-edge form made on ids. Takes the start URL as its only parameter.
*/
var ORPHAN_PAGES_SQL = `
  SELECT m.page_id, m.url FROM page_mirror m
  LEFT JOIN (
    SELECT DISTINCT j.value AS target_url
    FROM page_links p, json_each(p.targets_json) AS j
    WHERE j.value != p.url
    UNION ALL
    SELECT DISTINCT l.target_url
    FROM links l
    WHERE l.target_url != l.source_url
  ) inbound ON inbound.target_url = m.url
  WHERE m.url != ?
    AND m.fetch_class = 'ok'
    AND m.status_code >= 200 AND m.status_code < 300
    AND inbound.target_url IS NULL
    AND NOT EXISTS (
      SELECT 1 FROM page_mirror r WHERE r.redirect_url = m.url
    )
`;
//#endregion
//#region src/server/features/audit/AuditScratchpad.ts
/**
* Per-audit crawl scratchpad \u2014 a SQLite-backed Durable Object.
*
* Holds all transient crawl state for one audit (id = auditId): the frontier
* (URL queue + seen-set), each page's internal link targets, and a slim
* mirror of page rows. This keeps chatty crawl-loop writes off Postgres,
* removes the ~1MiB Workflow step-output limits (nothing large flows through
* step returns anymore), and gives the finalize link checks a local SQL
* database.
*
* Lifecycle: seeded by the discover-urls step, read/written by every crawl
* chunk, queried once at finalize, then destroyed on success. A self-cleanup
* alarm set on every construction guarantees any instantiation \u2014 including a
* write racing in after destroy() \u2014 is wiped after 7 days (failed audits'
* state doubles as the resume/debug artifact until then).
*
* SQL mutations are synchronous; key-value checkpoints await durable writes.
* Writes are idempotent: the workflow retries steps, so
* every insert is OR IGNORE / OR REPLACE on a stable key.
*/
var BROKEN_LINK_ISSUE_CAP = 2e3;
var CLEANUP_AFTER_MS = 6048e5;
/**
* Stop storing link targets once the database reaches this size. The link
* arrays are the only unbounded-per-page data; a pathological link-dense site
* could otherwise hit the platform's per-object SQLite cap (1 GB on the free
* plan self-hosters may run on) and fail the crawl with SQLITE_FULL. Past the
* budget the crawl continues \u2014 the audit just loses link-graph issues.
*/
var LINK_STORAGE_BUDGET_BYTES = 524288e3;
var AuditScratchpad = class extends DurableObject {
	constructor(ctx, workerEnv) {
		super(ctx, workerEnv);
		this.ctx.storage.sql.exec(SCRATCHPAD_SCHEMA_SQL);
		this.ctx.blockConcurrencyWhile(() => this.ensureCleanupAlarm());
	}
	async seedStart(url) {
		this.ctx.storage.sql.exec(`INSERT OR IGNORE INTO frontier (url, depth, source, in_sitemap) VALUES (?, 0, 'link', 0)`, url);
	}
	async getCrawlThrottle() {
		return this.ctx.storage.get("crawl-throttle");
	}
	async saveCrawlThrottle(state) {
		await this.ctx.storage.put("crawl-throttle", state);
	}
	async seedSitemapUrls(urls) {
		for (const url of urls) this.ctx.storage.sql.exec(`INSERT INTO frontier (url, depth, source, in_sitemap) VALUES (?, NULL, 'sitemap', 1)
         ON CONFLICT(url) DO UPDATE SET in_sitemap = 1`, url);
	}
	/**
	* Lease the next batch of pending URLs for one crawl chunk. Idempotent per
	* chunkNo: a retried step gets back exactly the URLs its failed attempt
	* had leased (link-discovered URLs drain before sitemap-only ones, FIFO
	* within each class \u2014 same ordering as the old in-memory queues).
	*/
	async claimChunk(chunkNo, limit) {
		const existing = this.selectClaimed(`SELECT url, depth, in_sitemap FROM frontier WHERE state = 'leased' AND chunk_no = ?`, chunkNo);
		if (existing.length > 0) return {
			urls: existing,
			isRetry: true
		};
		if (this.ctx.storage.sql.exec(`SELECT COUNT(*) AS n FROM frontier WHERE chunk_no = ? AND state = 'crawled'`, chunkNo).one().n > 0) return {
			urls: [],
			isRetry: true
		};
		if (limit <= 0) return {
			urls: [],
			isRetry: false
		};
		const fresh = this.selectClaimed(`SELECT url, depth, in_sitemap FROM frontier WHERE state = 'pending'
       ORDER BY CASE source WHEN 'link' THEN 0 ELSE 1 END, rowid LIMIT ?`, limit);
		for (const row of fresh) this.ctx.storage.sql.exec(`UPDATE frontier SET state = 'leased', chunk_no = ? WHERE url = ?`, chunkNo, row.url);
		return {
			urls: fresh,
			isRetry: false
		};
	}
	/** Persist one crawled sub-batch: completions, mirror rows, links, frontier. */
	async recordBatch(input) {
		for (const url of input.crawledUrls) this.ctx.storage.sql.exec(`UPDATE frontier SET state = 'crawled' WHERE url = ?`, url);
		for (const page of input.pages) this.ctx.storage.sql.exec(`INSERT OR REPLACE INTO page_mirror (page_id, url, status_code, fetch_class, redirect_url)
         VALUES (?, ?, ?, ?, ?)`, page.pageId, page.url, page.statusCode, page.fetchClass, page.redirectUrl);
		if (this.ctx.storage.sql.databaseSize < LINK_STORAGE_BUDGET_BYTES) for (const page of input.links) this.ctx.storage.sql.exec(`INSERT OR REPLACE INTO page_links (page_id, url, targets_json) VALUES (?, ?, ?)`, page.pageId, page.url, JSON.stringify(page.targets));
		for (const found of input.discovered) this.ctx.storage.sql.exec(FRONTIER_DISCOVER_SQL, found.url, found.depth);
		return this.stats();
	}
	/** Return unattempted leases to the queue (chunk soft-deadline hit). */
	async releaseUrls(urls) {
		for (const url of urls) this.ctx.storage.sql.exec(`UPDATE frontier SET state = 'pending', chunk_no = NULL WHERE url = ? AND state = 'leased'`, url);
	}
	async getStats() {
		return this.stats();
	}
	/**
	* The two finalize checks that need link edges, as local SQL. Mirrors the
	* former Postgres implementations in multipage.ts exactly.
	*/
	async runFinalizeChecks(input) {
		const brokenLinks = this.ctx.storage.sql.exec(BROKEN_LINKS_SQL, BROKEN_LINK_ISSUE_CAP).toArray().map((row) => ({
			sourcePageId: row.source_page_id,
			sourceUrl: row.source_url,
			targetUrl: row.target_url,
			targetStatus: row.target_status
		}));
		const linkGraphComplete = this.ctx.storage.sql.databaseSize < LINK_STORAGE_BUDGET_BYTES;
		return {
			brokenLinks,
			orphanPages: input.crawlCompleted && linkGraphComplete ? this.ctx.storage.sql.exec(ORPHAN_PAGES_SQL, input.startUrl).toArray().map((row) => ({
				pageId: row.page_id,
				url: row.url
			})) : []
		};
	}
	/** Wipe all state (success path, or explicit audit deletion). */
	async destroy() {
		await this.ctx.storage.deleteAlarm();
		await this.ctx.storage.deleteAll();
	}
	/** Same wipe exposed under the common erasure RPC used by account deletion. */
	async destroyForErasure() {
		await this.destroy();
	}
	/**
	* Self-cleanup for audits whose workflow died without reaching finalize.
	* Full destroy(), not just deleteAll(): under our compatibility date,
	* deleteAll() does not clear alarm state, and a leftover alarm would keep
	* the object (and its billing) alive.
	*/
	async alarm() {
		await this.destroy();
	}
	async ensureCleanupAlarm() {
		if (await this.ctx.storage.getAlarm() === null) await this.ctx.storage.setAlarm(Date.now() + CLEANUP_AFTER_MS);
	}
	selectClaimed(query, param) {
		return this.ctx.storage.sql.exec(query, param).toArray().map((row) => ({
			url: row.url,
			depth: row.depth,
			inSitemap: row.in_sitemap === 1
		}));
	}
	stats() {
		const row = this.ctx.storage.sql.exec(`SELECT
           COUNT(*) FILTER (WHERE state = 'crawled') AS attempted,
           COUNT(*) FILTER (WHERE state = 'pending') AS pending,
           COUNT(*) AS seen
         FROM frontier`).one();
		return {
			attempted: row.attempted,
			pending: row.pending,
			seen: row.seen
		};
	}
};
/** Stub for the audit's scratchpad DO (one instance per audit id). */
function getAuditScratchpad(auditId) {
	const namespace = env.AUDIT_SCRATCHPAD;
	return namespace.get(namespace.idFromName(auditId));
}
//#endregion
//#region node_modules/.pnpm/drizzle-orm@0.45.2_@cloudflare+workers-types@4.20260702.1_@libsql+client@0.15.15_@opent_32a0e5972b1c06602dab796f7c935dd3/node_modules/drizzle-orm/sql/functions/aggregate.js
function count(expression) {
	return sql`count(${expression || sql.raw("*")})`.mapWith(Number);
}
//#endregion
//#region src/server/workflows/yieldingStep.ts
/**
* How long a workflow may run steps back to back before it pauses for a
* second. This, plus the longest step timeout (10 minutes), plus replaying
* the completed steps, must stay under the Docker image's
* CELLD_HANDLER_BUDGET_S (deploy/standalone/Dockerfile). Every workflow's
* run() wraps its step with yieldingStep.
*/
var YIELD_AFTER_MS = 12e4;
/**
* The Docker edition's runtime, celld, runs a workflow's steps inside one
* handler until the workflow waits, and stops that handler once it passes
* CELLD_HANDLER_BUDGET_S. The instance then stays "running" without making
* progress until the runtime restarts (denoland/celld#299). A short sleep
* after a stretch of steps ends the handler, so the next step starts in a
* fresh one. On Cloudflare the sleep is just a one-second pause.
*
* A replay skips steps that already completed in well under YIELD_AFTER_MS,
* so it never calls the sleeps an earlier run made, and the sleep before a
* step is named after that step, so a later run never reuses a completed one.
*/
function yieldingStep(step) {
	let since = Date.now();
	const pauseIfDue = async (name) => {
		if (Date.now() - since < YIELD_AFTER_MS) return;
		await step.sleep(`yield-before-${name}`, "1 second");
		since = Date.now();
	};
	async function stepDo(name, configOrCallback, callback) {
		await pauseIfDue(name);
		if (typeof configOrCallback === "function") return step.do(name, configOrCallback);
		if (!callback) throw new Error(`step ${name} has no callback`);
		return step.do(name, configOrCallback, callback);
	}
	return {
		do: stepDo,
		sleep: (name, duration) => step.sleep(name, duration),
		sleepUntil: (name, timestamp) => step.sleepUntil(name, timestamp),
		waitForEvent: (name, options) => step.waitForEvent(name, options)
	};
}
//#endregion
//#region node_modules/.pnpm/remeda@2.33.6/node_modules/remeda/dist/lazyDataLastImpl-DtF3cihj.js
function e$1(e, t, n) {
	let r = (n) => e(n, ...t);
	return n === void 0 ? r : Object.assign(r, {
		lazy: n,
		lazyArgs: t
	});
}
//#endregion
//#region node_modules/.pnpm/remeda@2.33.6/node_modules/remeda/dist/purry.js
function t$3(t, n, r) {
	let i = t.length - n.length;
	if (i === 0) return t(...n);
	if (i === 1) return e$1(t, n, r);
	throw Error(`Wrong number of arguments`);
}
//#endregion
//#region node_modules/.pnpm/remeda@2.33.6/node_modules/remeda/dist/chunk.js
function t$2(...t) {
	return t$3(n$1, t);
}
function n$1(e, t) {
	if (t < 1) throw RangeError(`chunk: A chunk size of '${t.toString()}' would result in an infinite array`);
	if (e.length === 0) return [];
	if (t >= e.length) return [[...e]];
	let n = Math.ceil(e.length / t), r = Array(n);
	if (t === 1) for (let [t, n] of e.entries()) r[t] = [n];
	else for (let i = 0; i < n; i += 1) {
		let n = i * t;
		r[i] = e.slice(n, n + t);
	}
	return r;
}
//#endregion
//#region node_modules/.pnpm/remeda@2.33.6/node_modules/remeda/dist/purryOrderRules-4JgY6z4X.js
var e = {
	asc: (e, t) => e > t,
	desc: (e, t) => e < t
};
function t$1(e, t) {
	let [n, ...a] = t;
	if (!i(n)) return e(n, r(...a));
	let o = r(n, ...a);
	return (t) => e(t, o);
}
function r(t, n, ...i) {
	let a = typeof t == `function` ? t : t[0], o = typeof t == `function` ? `asc` : t[1], { [o]: s } = e, c = n === void 0 ? void 0 : r(n, ...i);
	return (e, t) => {
		let n = a(e), r = a(t);
		return s(n, r) ? 1 : s(r, n) ? -1 : c?.(e, t) ?? 0;
	};
}
function i(t) {
	if (a(t)) return !0;
	if (typeof t != `object` || !Array.isArray(t)) return !1;
	let [n, r, ...i] = t;
	return a(n) && typeof r == `string` && r in e && i.length === 0;
}
var a = (e) => typeof e == `function` && e.length === 1;
//#endregion
//#region node_modules/.pnpm/remeda@2.33.6/node_modules/remeda/dist/sortBy.js
function t(...t) {
	return t$1(n, t);
}
var n = (e, t) => [...e].sort(t);
//#endregion
//#region src/server/lib/audit/ids.ts
/**
* Deterministic row ids for audit data.
*
* Crawl/lighthouse persistence happens inside Workflow steps, which retry on
* failure. Deriving ids from stable content (audit id + URL + ...) combined
* with `onConflictDoNothing` makes those writes idempotent across retries \u2014
* a partially-written batch is simply completed on the next attempt instead
* of duplicated under fresh random ids.
*/
async function sha256Hex(text) {
	const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
	return Array.from(new Uint8Array(digest)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function deterministicAuditRowId(...parts) {
	return (await sha256Hex(parts.join("|"))).slice(0, 36);
}
//#endregion
//#region src/shared/audit-issues.ts
/**
* Registry of site-audit issue types.
*
* Shared between the server (issue engine, MCP tools) and the client
* (issues UI, CSV export). Each issue row in `audit_issues` references one
* of these types by id.
*/
var AUDIT_ISSUE_TYPES = {
	"blocked-page": {
		severity: "critical",
		title: "Crawler was blocked",
		explanation: "The site returned a bot challenge or access denial (e.g. a Cloudflare challenge or a 403) instead of the page. We report this honestly rather than pretending the page is broken \u2014 but it means this page could not be audited, and other crawlers like search engines may face similar friction.",
		howToFix: "If you own this site, allowlist the \"OpenSEO-Audit\" user agent in your WAF/bot-protection settings (on Cloudflare: a WAF custom rule that skips bot protection when the user agent contains \"OpenSEO-Audit\"; on some free tiers you may need to relax bot protection). Then re-run the audit. On Shopify, use Crawler access instead (Online Store \u2192 Preferences \u2192 Crawler access) and paste the signature into OpenSEO under Settings \u2192 Crawler access. How to allow and verify the crawler: https://openseo.so/docs/crawler"
	},
	"javascript-rendering-suspected": {
		severity: "warning",
		title: "Content may require JavaScript",
		explanation: "The page's HTML contains a JavaScript app container with very little readable content and no headings, links, or images. The page may load its content in the browser, or it was still loading when rendered. Content checks were skipped because this HTML may not represent the complete page.",
		howToFix: "If this audit did not render JavaScript, start a new audit with \"Render JavaScript\" enabled to check the loaded content. For reliable crawling, serve important content and navigation in the initial HTML using server-side rendering or prerendering. This warning does not prove that search engines cannot index the page."
	},
	"rate-limited-page": {
		severity: "warning",
		title: "Rate limited (429)",
		explanation: "The server answered 429 Too Many Requests, so this page could not be audited. The crawler paused for the server's Retry-After and tried the page once more before moving on.",
		howToFix: "Raise the rate limit for crawlers, or allowlist the \"OpenSEO-Audit\" user agent in your rate-limiting rules (on Cloudflare: a rate-limiting rule exception matching that user agent). Then re-run the audit. Re-running with fewer pages also helps if the limit is strict. On Shopify, use Crawler access instead (Online Store \u2192 Preferences \u2192 Crawler access) and paste the signature into OpenSEO under Settings \u2192 Crawler access. How to allow and verify the crawler: https://openseo.so/docs/crawler"
	},
	"crawl-rate-limited": {
		severity: "warning",
		title: "Crawl stopped early: rate limit",
		explanation: "The site refused several pages in a row with 429 Too Many Requests, or kept the crawler waiting for too long, so we stopped requesting pages. This report is incomplete; URLs we did not fetch are not recorded as broken or rate limited.",
		howToFix: "Re-run the audit after the site's rate limit resets, or ask the site owner to allow the OpenSEO-Audit crawler (https://openseo.so/docs/crawler). On Shopify, use Crawler access instead (Online Store \u2192 Preferences \u2192 Crawler access) and paste the signature into OpenSEO under Settings \u2192 Crawler access."
	},
	"crawl-time-limit": {
		severity: "warning",
		title: "Crawl stopped early: time limit",
		explanation: `Audits that render JavaScript stop crawling after 22 hours, and this one reached that limit. This report is incomplete; URLs we did not fetch are not recorded as broken.`,
		howToFix: "Re-run the audit with a lower page limit, or without Render JavaScript if the site's content and links are in its HTML. Rendering is billed only for pages actually rendered."
	},
	"crawl-credits-exhausted": {
		severity: "warning",
		title: "Crawl stopped early: cost limit reached",
		explanation: "Many pages on this site needed our advanced renderer, so the audit reached its cost limit and stopped. You were only charged for the pages we rendered.",
		howToFix: "If the site doesn't need JavaScript to show its content, re-run with Render JavaScript off."
	},
	"server-error": {
		severity: "critical",
		title: "Server error (5xx)",
		explanation: "The page returned a 5xx server error. Search engines that repeatedly see server errors will crawl the site less and may drop the page from the index.",
		howToFix: "Check the server logs for this URL and fix the underlying error. If the page is gone, return a 404/410 or redirect it to a relevant page instead of erroring."
	},
	"broken-internal-link": {
		severity: "critical",
		title: "Broken internal link",
		explanation: "This page links to an internal URL that returns an error status (4xx/5xx). Broken links waste crawl budget, leak link equity, and frustrate users \u2014 they are among the most common and most damaging technical SEO issues.",
		howToFix: "Update the link to point at the correct live URL, or remove it. If the target was moved, prefer linking directly to the new URL rather than relying on a redirect."
	},
	"missing-title": {
		severity: "critical",
		title: "Missing title tag",
		explanation: "The page has no <title>. The title is the strongest on-page relevance signal and the headline shown in search results; without it search engines generate one themselves, usually badly.",
		howToFix: "Add a unique, descriptive <title> of roughly 50\u201360 characters that includes the page's primary topic."
	},
	"broken-page": {
		severity: "warning",
		title: "Page returns an error (4xx)",
		explanation: "This crawled URL returned a client error (e.g. 404). If it is referenced from your sitemap or other pages, crawlers keep wasting requests on it.",
		howToFix: "If the page should exist, restore it. If it is intentionally gone, remove it from the sitemap and internal links, and consider a 301 redirect to the closest live page."
	},
	"duplicate-title": {
		severity: "warning",
		title: "Duplicate title",
		explanation: "Multiple pages share the same title tag. Search engines use titles to differentiate pages; duplicates make pages compete with each other and depress click-through rates.",
		howToFix: "Write a unique title for each page describing its specific content. For templated pages, include the distinguishing attribute (name, category, location) in the template."
	},
	"duplicate-meta-description": {
		severity: "warning",
		title: "Duplicate meta description",
		explanation: "Multiple pages share the same meta description, so search results show identical snippets and users cannot tell the pages apart.",
		howToFix: "Write a unique meta description per page, or remove the duplicated one entirely \u2014 search engines will generate a snippet from page content, which beats a wrong duplicate."
	},
	"duplicate-content": {
		severity: "warning",
		title: "Duplicate page content",
		explanation: "Two or more URLs serve byte-identical visible text. Search engines pick one version to index and ignore the rest, and ranking signals get split across the duplicates.",
		howToFix: "Consolidate duplicates: pick the canonical URL, add rel=canonical from the others, and 301-redirect duplicate URLs where possible (common causes: trailing-slash variants, URL parameters, http/https or www variants)."
	},
	"missing-meta-description": {
		severity: "warning",
		title: "Missing meta description",
		explanation: "The page has no meta description. Search engines will assemble a snippet from page text, which is often less compelling and hurts click-through rate.",
		howToFix: "Add a meta description of roughly 70\u2013160 characters that summarizes the page and gives a reason to click."
	},
	"missing-h1": {
		severity: "warning",
		title: "Missing H1 heading",
		explanation: "The page has no H1. The H1 tells users and search engines what the page is about; pages without one tend to have weaker topical clarity.",
		howToFix: "Add a single H1 that states the page's main topic, consistent with the title tag."
	},
	"multiple-h1": {
		severity: "warning",
		title: "Multiple H1 headings",
		explanation: "The page has more than one H1, which dilutes the main-topic signal and usually indicates a templating mistake (e.g. a logo and a headline both marked up as H1).",
		howToFix: "Keep one H1 for the page's main heading and demote the others to H2/H3 (or unstyled elements for non-headings like logos)."
	},
	"redirect-chain": {
		severity: "warning",
		title: "Redirect chain",
		explanation: "Reaching the final page requires two or more consecutive redirects. Each hop adds latency, leaks link equity, and burns crawl budget; long chains may not be followed at all.",
		howToFix: "Point the first URL (and any internal links) directly at the final destination so there is at most one redirect."
	},
	"redirect-loop": {
		severity: "warning",
		title: "Redirect loop",
		explanation: "This redirect eventually points back to itself, so the URL never resolves. Browsers and crawlers give up with an error.",
		howToFix: "Trace the redirect rules for this URL and break the cycle so the chain terminates at a real 200 page."
	},
	"canonical-conflict": {
		severity: "warning",
		title: "Conflicting canonical signals",
		explanation: "The page declares different canonical URLs in its HTML <link rel=canonical> and its HTTP Link header. When signals conflict, search engines ignore both and choose their own canonical.",
		howToFix: "Pick one canonical URL and declare it in exactly one place (HTML head is the most common); remove or align the other declaration."
	},
	"thin-content": {
		severity: "warning",
		title: "Thin content",
		explanation: "The page has very little visible text. Thin pages rarely rank, can drag down sitewide quality assessments, and (if the site renders client-side) may indicate content invisible to plain-HTML crawlers.",
		howToFix: "Either expand the page with genuinely useful content, noindex it, or consolidate it into a stronger page. If the content exists but is rendered by JavaScript, ensure it is server-rendered or pre-rendered."
	},
	"images-missing-alt": {
		severity: "warning",
		title: "Images missing alt text",
		explanation: "One or more images on the page lack alt attributes. Alt text is an accessibility requirement and the main way search engines understand images.",
		howToFix: "Add descriptive alt text to meaningful images; use an empty alt (alt=\"\") only for purely decorative ones."
	},
	"orphan-page": {
		severity: "warning",
		title: "Orphan page",
		explanation: "No crawled page links to this URL \u2014 it was only discoverable via the sitemap. Pages without internal links receive little crawl attention and no internal link equity, and users can't find them by browsing.",
		howToFix: "Link to this page from relevant pages (navigation, related content, hub pages), or remove it from the sitemap if it shouldn't be indexed."
	},
	"no-outgoing-links": {
		severity: "warning",
		title: "Page has no outgoing links",
		explanation: "The page contains no links at all \u2014 a dead end. Link equity that flows into it stops there, crawlers have nowhere to go next, and users have to reach for the back button.",
		howToFix: "Add links to related pages, the parent category, or the homepage. If the page's navigation is rendered by JavaScript, make sure it also exists in the server-rendered HTML."
	},
	"title-too-long": {
		severity: "info",
		title: "Title too long",
		explanation: "The title exceeds ~60 characters, so search results will truncate it and the ending may be cut off mid-phrase.",
		howToFix: "Shorten the title to roughly 50\u201360 characters, front-loading the most important words."
	},
	"title-too-short": {
		severity: "info",
		title: "Title too short",
		explanation: "The title is under ~10 characters, which is usually too generic to describe the page or attract clicks.",
		howToFix: "Expand the title into a descriptive phrase (roughly 30\u201360 characters) that states what the page offers."
	},
	"meta-description-too-long": {
		severity: "info",
		title: "Meta description too long",
		explanation: "The meta description exceeds ~160 characters, so search engines will truncate the snippet.",
		howToFix: "Trim the description to roughly 70\u2013160 characters while keeping the core message and call to action."
	},
	"meta-description-too-short": {
		severity: "info",
		title: "Meta description too short",
		explanation: "The meta description is under ~70 characters. Short descriptions waste the snippet space search results give you, and search engines often ignore them in favor of text pulled from the page.",
		howToFix: "Expand the description to roughly 70\u2013160 characters that summarize the page and give a reason to click."
	},
	"heading-order-skip": {
		severity: "info",
		title: "Heading levels skip",
		explanation: "The heading hierarchy skips levels (e.g. an H4 directly after an H2). This weakens document structure for accessibility tools and content parsing.",
		howToFix: "Adjust heading levels so they descend one step at a time (H1 \u2192 H2 \u2192 H3) without skipping."
	},
	"slow-response": {
		severity: "info",
		title: "Slow server response",
		explanation: "The HTML response took over 1.5 seconds. Slow time-to-first-byte drags down every downstream performance metric and reduces crawl rate on large sites.",
		howToFix: "Investigate server/database time and caching for this route; serving cached or statically generated HTML usually fixes it."
	},
	"noindex-page": {
		severity: "info",
		title: "Page is noindex",
		explanation: "The page asks search engines not to index it (via robots meta tag or X-Robots-Tag header). That's often intentional \u2014 this is a heads-up, not an error.",
		howToFix: "If this page should rank, remove the noindex directive. If it's intentional (admin, thank-you, filter pages), no action is needed."
	},
	"canonicalized-page": {
		severity: "info",
		title: "Canonicalized to another URL",
		explanation: "The page declares a different URL as its canonical, telling search engines to index that URL instead. Fine when intentional (parameter pages, syndication) \u2014 a problem if this page was meant to rank.",
		howToFix: "If this page should rank on its own, set its canonical to itself. Otherwise no action is needed."
	},
	"deep-page": {
		severity: "info",
		title: "Page is deep in the site structure",
		explanation: "The page is 5+ clicks from the homepage. Deep pages get crawled less often and receive less link equity.",
		howToFix: "Add links from higher-level pages (hubs, category pages, navigation) to flatten the path to this page."
	}
};
//#endregion
//#region src/server/features/audit/repositories/auditIssueWrites.ts
async function insertIssues(auditId, issues) {
	const isPostgres = getDatabaseProvider() === "postgres";
	const batchSize = isPostgres ? 500 : 100;
	for (let i = 0; i < issues.length; i += batchSize) {
		const issueRows = await Promise.all(issues.slice(i, i + batchSize).map(async (issue) => ({
			id: await deterministicAuditRowId(auditId, issue.pageUrl, issue.issueType, issue.dedupeKey ?? ""),
			auditId,
			pageId: issue.pageId,
			pageUrl: issue.pageUrl,
			issueType: issue.issueType,
			severity: AUDIT_ISSUE_TYPES[issue.issueType].severity,
			detailsJson: issue.details ? JSON.stringify(issue.details) : null
		})));
		if (isPostgres) await db.insert(auditIssues).values(issueRows).onConflictDoNothing();
		else await runBatch((tx) => t$2(issueRows, 14).map((rows) => tx.insert(auditIssues).values(rows).onConflictDoNothing()));
	}
}
//#endregion
//#region src/server/features/audit/repositories/AuditRepository.ts
/**
* Data access layer for site audit tables.
* Provider-aware (D1 or Postgres) via the `@/db` handle. Covers audits,
* audit_pages, audit_issues, and stored Lighthouse results. Link edges live
* in the per-audit scratchpad Durable Object, not here.
*/
async function createAudit(data) {
	await db.insert(audits).values({
		id: data.id,
		projectId: data.projectId,
		startedByUserId: data.startedByUserId,
		startUrl: data.startUrl,
		workflowInstanceId: data.workflowInstanceId,
		config: JSON.stringify(data.config),
		status: "running",
		pagesTotal: data.pagesTotal,
		lighthouseTotal: data.lighthouseTotal,
		currentPhase: "discovery"
	});
}
/** Records where the crawl really starts, once the workflow has probed the site. */
async function updateAuditStart(auditId, startUrl, config) {
	await db.update(audits).set({
		startUrl,
		config: JSON.stringify(config)
	}).where(eq(audits.id, auditId));
}
async function updateAuditProgress(auditId, workflowInstanceId, data) {
	await db.update(audits).set(data).where(and(eq(audits.id, auditId), eq(audits.workflowInstanceId, workflowInstanceId)));
}
async function completeAudit(auditId, workflowInstanceId, data) {
	await db.update(audits).set({
		status: "completed",
		completedAt: (/* @__PURE__ */ new Date()).toISOString(),
		currentPhase: "completed",
		...data
	}).where(and(eq(audits.id, auditId), eq(audits.workflowInstanceId, workflowInstanceId), eq(audits.status, "running")));
}
async function failAudit(auditId, workflowInstanceId, errorInfo) {
	await db.update(audits).set({
		status: "failed",
		completedAt: (/* @__PURE__ */ new Date()).toISOString(),
		currentPhase: "failed",
		...errorInfo && {
			errorCode: errorInfo.errorCode,
			errorDetail: errorInfo.errorDetail,
			failedPhase: errorInfo.failedPhase
		}
	}).where(and(eq(audits.id, auditId), eq(audits.workflowInstanceId, workflowInstanceId), eq(audits.status, "running")));
}
async function getAuditForWorkflow(auditId, workflowInstanceId) {
	return db.query.audits.findFirst({ where: and(eq(audits.id, auditId), eq(audits.workflowInstanceId, workflowInstanceId)) });
}
/**
* Persist one crawled sub-batch (pages + per-page issues). Called inside the
* crawl-chunk Workflow step so results land in the app DB incrementally
* instead of accumulating in memory until finalize. Link edges go to the
* audit's scratchpad DO, not here.
*
* Idempotent on step retry: callers assign deterministic page ids
* (deterministicAuditRowId) and issue ids are derived from stable content.
* Page rows upsert (a retried fetch may legitimately differ \u2014 last attempt
* wins); issues are insert-or-ignore.
*/
async function insertCrawledBatch(auditId, pages, issues) {
	await executeInBatches(pages, (tx, page) => {
		const dataColumns = {
			url: page.url,
			statusCode: page.statusCode,
			redirectUrl: page.redirectUrl,
			title: page.title,
			metaDescription: page.metaDescription,
			canonicalUrl: page.canonicalUrl,
			robotsMeta: page.robotsMeta,
			xRobotsTag: page.xRobotsTag,
			headerCanonicalUrl: page.headerCanonicalUrl,
			ogTitle: page.ogTitle,
			ogDescription: page.ogDescription,
			ogImage: page.ogImage,
			h1Count: page.h1Count,
			h2Count: page.h2Count,
			h3Count: page.h3Count,
			h4Count: page.h4Count,
			h5Count: page.h5Count,
			h6Count: page.h6Count,
			wordCount: page.wordCount,
			contentHash: page.contentHash,
			imagesTotal: page.imagesTotal,
			imagesMissingAlt: page.imagesMissingAlt,
			internalLinkCount: page.links.filter((l) => l.isInternal).length,
			externalLinkCount: page.links.filter((l) => !l.isInternal).length,
			hasStructuredData: page.hasStructuredData,
			isIndexable: page.isIndexable,
			fetchClass: page.fetchClass,
			crawlDepth: page.crawlDepth,
			inSitemap: page.inSitemap,
			responseTimeMs: page.responseTimeMs
		};
		return tx.insert(auditPages).values({
			id: page.id,
			auditId,
			...dataColumns
		}).onConflictDoUpdate({
			target: auditPages.id,
			set: dataColumns
		});
	});
	await insertIssues(auditId, issues);
}
async function insertLighthouseResults(auditId, lighthouseResults) {
	const rows = await Promise.all(lighthouseResults.map(async (result) => ({
		id: await deterministicAuditRowId(auditId, result.pageId, result.strategy),
		auditId,
		pageId: result.pageId,
		strategy: result.strategy,
		performanceScore: result.performanceScore,
		accessibilityScore: result.accessibilityScore,
		bestPracticesScore: result.bestPracticesScore,
		seoScore: result.seoScore,
		lcpMs: result.lcpMs,
		cls: result.cls,
		inpMs: result.inpMs,
		ttfbMs: result.ttfbMs,
		errorMessage: result.errorMessage ?? null,
		r2Key: result.r2Key ?? null,
		payloadSizeBytes: result.payloadSizeBytes ?? null
	})));
	await executeInBatches(rows, (tx, row) => {
		const { id: _id, auditId: _auditId, ...dataColumns } = row;
		return tx.insert(auditLighthouseResults).values(row).onConflictDoUpdate({
			target: auditLighthouseResults.id,
			set: dataColumns
		});
	});
}
async function getAuditForProject(auditId, projectId) {
	return db.query.audits.findFirst({ where: and(eq(audits.id, auditId), eq(audits.projectId, projectId)) });
}
async function getLatestAuditForProject(projectId) {
	return db.query.audits.findFirst({
		where: eq(audits.projectId, projectId),
		orderBy: desc(audits.startedAt)
	});
}
async function getPagesForAudit(auditId) {
	return db.select({
		id: auditPages.id,
		url: auditPages.url,
		statusCode: auditPages.statusCode,
		fetchClass: auditPages.fetchClass,
		redirectUrl: auditPages.redirectUrl,
		title: auditPages.title,
		metaDescription: auditPages.metaDescription,
		wordCount: auditPages.wordCount,
		isIndexable: auditPages.isIndexable,
		crawlDepth: auditPages.crawlDepth,
		inSitemap: auditPages.inSitemap,
		internalLinkCount: auditPages.internalLinkCount,
		responseTimeMs: auditPages.responseTimeMs
	}).from(auditPages).where(eq(auditPages.auditId, auditId));
}
async function countPagesByFetchClass(auditId, fetchClass) {
	return (await db.select({ pages: count() }).from(auditPages).where(and(eq(auditPages.auditId, auditId), eq(auditPages.fetchClass, fetchClass))))[0]?.pages ?? 0;
}
async function hasPagesForAudit(auditId) {
	return (await db.select({ id: auditPages.id }).from(auditPages).where(eq(auditPages.auditId, auditId)).limit(1)).length > 0;
}
async function getAuditsByProject(projectId) {
	return (await db.select({ audit: audits }).from(audits).where(eq(audits.projectId, projectId)).orderBy(desc(audits.startedAt))).map(({ audit }) => audit);
}
async function getAuditUsageForOrganization(organizationId) {
	const rows = await db.select({
		status: audits.status,
		pagesTotal: audits.pagesTotal,
		lighthouseTotal: audits.lighthouseTotal
	}).from(audits).innerJoin(projects, eq(audits.projectId, projects.id)).where(eq(projects.organizationId, organizationId));
	return {
		capacityUnits: rows.reduce((total, row) => total + row.pagesTotal + row.lighthouseTotal, 0),
		runningCount: rows.filter((row) => row.status === "running").length
	};
}
async function hasAuditInOrganization(organizationId) {
	return (await db.select({ id: audits.id }).from(audits).innerJoin(projects, eq(audits.projectId, projects.id)).where(eq(projects.organizationId, organizationId)).limit(1)).length > 0;
}
async function getLighthouseResultById(input) {
	const lighthouse = await db.query.auditLighthouseResults.findFirst({ where: eq(auditLighthouseResults.id, input.lighthouseResultId) });
	if (!lighthouse) return null;
	const [parentAudit, page] = await Promise.all([db.query.audits.findFirst({ where: and(eq(audits.id, lighthouse.auditId), eq(audits.projectId, input.projectId)) }), db.query.auditPages.findFirst({ where: eq(auditPages.id, lighthouse.pageId) })]);
	if (!parentAudit) return null;
	return {
		lighthouse,
		page,
		audit: parentAudit
	};
}
async function deleteAuditForProject(auditId, projectId) {
	await db.delete(audits).where(and(eq(audits.id, auditId), eq(audits.projectId, projectId)));
}
var AuditRepository = {
	createAudit,
	updateAuditStart,
	updateAuditProgress,
	completeAudit,
	failAudit,
	getAuditForWorkflow,
	insertCrawledBatch,
	insertIssues,
	insertLighthouseResults,
	getAuditForProject,
	getLatestAuditForProject,
	getPagesForAudit,
	countPagesByFetchClass,
	hasPagesForAudit,
	getAuditsByProject,
	getAuditUsageForOrganization,
	hasAuditInOrganization,
	getLighthouseResultById,
	deleteAuditForProject
};
//#endregion
//#region node_modules/.pnpm/@better-auth+utils@0.4.2/node_modules/@better-auth/utils/dist/index.mjs
function getWebcryptoSubtle() {
	const cr = typeof globalThis !== "undefined" && globalThis.crypto;
	if (cr && typeof cr.subtle === "object" && cr.subtle != null) return cr.subtle;
	throw new Error("crypto.subtle must be defined");
}
//#endregion
//#region node_modules/.pnpm/@better-auth+utils@0.4.2/node_modules/@better-auth/utils/dist/base64.mjs
function getAlphabet(urlSafe) {
	return urlSafe ? "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_" : "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
}
function base64Encode(data, alphabet, padding) {
	let result = "";
	let buffer = 0;
	let shift = 0;
	for (const byte of data) {
		buffer = buffer << 8 | byte;
		shift += 8;
		while (shift >= 6) {
			shift -= 6;
			result += alphabet[buffer >> shift & 63];
		}
	}
	if (shift > 0) result += alphabet[buffer << 6 - shift & 63];
	if (padding) {
		const padCount = (4 - result.length % 4) % 4;
		result += "=".repeat(padCount);
	}
	return result;
}
function base64Decode(data, alphabet) {
	const decodeMap = /* @__PURE__ */ new Map();
	for (let i = 0; i < alphabet.length; i++) decodeMap.set(alphabet[i], i);
	const result = [];
	let buffer = 0;
	let bitsCollected = 0;
	for (const char of data) {
		if (char === "=") break;
		const value = decodeMap.get(char);
		if (value === void 0) throw new Error(`Invalid Base64 character: ${char}`);
		buffer = buffer << 6 | value;
		bitsCollected += 6;
		if (bitsCollected >= 8) {
			bitsCollected -= 8;
			result.push(buffer >> bitsCollected & 255);
		}
	}
	return Uint8Array.from(result);
}
var base64 = {
	encode(data, options = {}) {
		const alphabet = getAlphabet(false);
		return base64Encode(typeof data === "string" ? new TextEncoder().encode(data) : new Uint8Array(data), alphabet, options.padding ?? true);
	},
	decode(data) {
		if (typeof data !== "string") data = new TextDecoder().decode(data);
		const alphabet = getAlphabet(data.includes("-") || data.includes("_"));
		return base64Decode(data, alphabet);
	}
};
var base64Url = {
	encode(data, options = {}) {
		const alphabet = getAlphabet(true);
		return base64Encode(typeof data === "string" ? new TextEncoder().encode(data) : new Uint8Array(data), alphabet, options.padding ?? true);
	},
	decode(data) {
		return base64Decode(data, getAlphabet(data.includes("-") || data.includes("_")));
	}
};
//#endregion
//#region node_modules/.pnpm/@better-auth+utils@0.4.2/node_modules/@better-auth/utils/dist/hash.mjs
function createHash(algorithm, encoding) {
	return { digest: async (input) => {
		const encoder = new TextEncoder();
		const data = typeof input === "string" ? encoder.encode(input) : input;
		const hashBuffer = await getWebcryptoSubtle().digest(algorithm, data);
		if (encoding === "hex") return Array.from(new Uint8Array(hashBuffer)).map((b) => b.toString(16).padStart(2, "0")).join("");
		if (encoding === "base64" || encoding === "base64url" || encoding === "base64urlnopad") {
			if (encoding.includes("url")) return base64Url.encode(hashBuffer, { padding: encoding !== "base64urlnopad" });
			return base64.encode(hashBuffer);
		}
		return hashBuffer;
	} };
}
//#endregion
//#region node_modules/.pnpm/@noble+ciphers@2.1.1/node_modules/@noble/ciphers/utils.js
/**
* Utilities for hex, bytes, CSPRNG.
* @module
*/
/*! noble-ciphers - MIT License (c) 2023 Paul Miller (paulmillr.com) */
/** Checks if something is Uint8Array. Be careful: nodejs Buffer will return true. */
function isBytes(a) {
	return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array";
}
/** Asserts something is boolean. */
function abool(b) {
	if (typeof b !== "boolean") throw new Error(`boolean expected, not ${b}`);
}
/** Asserts something is positive integer. */
function anumber(n) {
	if (!Number.isSafeInteger(n) || n < 0) throw new Error("positive integer expected, got " + n);
}
/** Asserts something is Uint8Array. */
function abytes(value, length, title = "") {
	const bytes = isBytes(value);
	const len = value?.length;
	const needsLen = length !== void 0;
	if (!bytes || needsLen && len !== length) {
		const prefix = title && `"${title}" `;
		const ofLen = needsLen ? ` of length ${length}` : "";
		const got = bytes ? `length=${len}` : `type=${typeof value}`;
		throw new Error(prefix + "expected Uint8Array" + ofLen + ", got " + got);
	}
	return value;
}
/** Asserts a hash instance has not been destroyed / finished */
function aexists(instance, checkFinished = true) {
	if (instance.destroyed) throw new Error("Hash instance has been destroyed");
	if (checkFinished && instance.finished) throw new Error("Hash#digest() has already been called");
}
/** Asserts output is properly-sized byte array */
function aoutput(out, instance) {
	abytes(out, void 0, "output");
	const min = instance.outputLen;
	if (out.length < min) throw new Error("digestInto() expects output buffer of length at least " + min);
}
/** Cast u8 / u16 / u32 to u32. */
function u32(arr) {
	return new Uint32Array(arr.buffer, arr.byteOffset, Math.floor(arr.byteLength / 4));
}
/** Zeroize a byte array. Warning: JS provides no guarantees. */
function clean(...arrays) {
	for (let i = 0; i < arrays.length; i++) arrays[i].fill(0);
}
/** Create DataView of an array for easy byte-level manipulation. */
function createView(arr) {
	return new DataView(arr.buffer, arr.byteOffset, arr.byteLength);
}
/** Is current platform little-endian? Most are. Big-Endian platform: IBM */
var isLE = /* @__PURE__ */ (() => new Uint8Array(new Uint32Array([287454020]).buffer)[0] === 68)();
var hasHexBuiltin = /* @__PURE__ */ (() => typeof Uint8Array.from([]).toHex === "function" && typeof Uint8Array.fromHex === "function")();
var hexes = /* @__PURE__ */ Array.from({ length: 256 }, (_, i) => i.toString(16).padStart(2, "0"));
/**
* Convert byte array to hex string. Uses built-in function, when available.
* @example bytesToHex(Uint8Array.from([0xca, 0xfe, 0x01, 0x23])) // 'cafe0123'
*/
function bytesToHex(bytes) {
	abytes(bytes);
	if (hasHexBuiltin) return bytes.toHex();
	let hex = "";
	for (let i = 0; i < bytes.length; i++) hex += hexes[bytes[i]];
	return hex;
}
var asciis = {
	_0: 48,
	_9: 57,
	A: 65,
	F: 70,
	a: 97,
	f: 102
};
function asciiToBase16(ch) {
	if (ch >= asciis._0 && ch <= asciis._9) return ch - asciis._0;
	if (ch >= asciis.A && ch <= asciis.F) return ch - (asciis.A - 10);
	if (ch >= asciis.a && ch <= asciis.f) return ch - (asciis.a - 10);
}
/**
* Convert hex string to byte array. Uses built-in function, when available.
* @example hexToBytes('cafe0123') // Uint8Array.from([0xca, 0xfe, 0x01, 0x23])
*/
function hexToBytes(hex) {
	if (typeof hex !== "string") throw new Error("hex string expected, got " + typeof hex);
	if (hasHexBuiltin) return Uint8Array.fromHex(hex);
	const hl = hex.length;
	const al = hl / 2;
	if (hl % 2) throw new Error("hex string expected, got unpadded hex of length " + hl);
	const array = new Uint8Array(al);
	for (let ai = 0, hi = 0; ai < al; ai++, hi += 2) {
		const n1 = asciiToBase16(hex.charCodeAt(hi));
		const n2 = asciiToBase16(hex.charCodeAt(hi + 1));
		if (n1 === void 0 || n2 === void 0) {
			const char = hex[hi] + hex[hi + 1];
			throw new Error("hex string expected, got non-hex character \"" + char + "\" at index " + hi);
		}
		array[ai] = n1 * 16 + n2;
	}
	return array;
}
/**
* Converts string to bytes using UTF8 encoding.
* @example utf8ToBytes('abc') // new Uint8Array([97, 98, 99])
*/
function utf8ToBytes(str) {
	if (typeof str !== "string") throw new Error("string expected");
	return new Uint8Array(new TextEncoder().encode(str));
}
/**
* Copies several Uint8Arrays into one.
*/
function concatBytes(...arrays) {
	let sum = 0;
	for (let i = 0; i < arrays.length; i++) {
		const a = arrays[i];
		abytes(a);
		sum += a.length;
	}
	const res = new Uint8Array(sum);
	for (let i = 0, pad = 0; i < arrays.length; i++) {
		const a = arrays[i];
		res.set(a, pad);
		pad += a.length;
	}
	return res;
}
function checkOpts(defaults, opts) {
	if (opts == null || typeof opts !== "object") throw new Error("options must be defined");
	return Object.assign(defaults, opts);
}
/** Compares 2 uint8array-s in kinda constant time. */
function equalBytes(a, b) {
	if (a.length !== b.length) return false;
	let diff = 0;
	for (let i = 0; i < a.length; i++) diff |= a[i] ^ b[i];
	return diff === 0;
}
/**
* Wraps a cipher: validates args, ensures encrypt() can only be called once.
* @__NO_SIDE_EFFECTS__
*/
var wrapCipher = (params, constructor) => {
	function wrappedCipher(key, ...args) {
		abytes(key, void 0, "key");
		if (!isLE) throw new Error("Non little-endian hardware is not yet supported");
		if (params.nonceLength !== void 0) {
			const nonce = args[0];
			abytes(nonce, params.varSizeNonce ? void 0 : params.nonceLength, "nonce");
		}
		const tagl = params.tagLength;
		if (tagl && args[1] !== void 0) abytes(args[1], void 0, "AAD");
		const cipher = constructor(key, ...args);
		const checkOutput = (fnLength, output) => {
			if (output !== void 0) {
				if (fnLength !== 2) throw new Error("cipher output not supported");
				abytes(output, void 0, "output");
			}
		};
		let called = false;
		return {
			encrypt(data, output) {
				if (called) throw new Error("cannot encrypt() twice with same key + nonce");
				called = true;
				abytes(data);
				checkOutput(cipher.encrypt.length, output);
				return cipher.encrypt(data, output);
			},
			decrypt(data, output) {
				abytes(data);
				if (tagl && data.length < tagl) throw new Error("\"ciphertext\" expected length bigger than tagLength=" + tagl);
				checkOutput(cipher.decrypt.length, output);
				return cipher.decrypt(data, output);
			}
		};
	}
	Object.assign(wrappedCipher, params);
	return wrappedCipher;
};
/**
* By default, returns u8a of length.
* When out is available, it checks it for validity and uses it.
*/
function getOutput(expectedLength, out, onlyAligned = true) {
	if (out === void 0) return new Uint8Array(expectedLength);
	if (out.length !== expectedLength) throw new Error("\"output\" expected Uint8Array of length " + expectedLength + ", got: " + out.length);
	if (onlyAligned && !isAligned32$1(out)) throw new Error("invalid output, must be aligned");
	return out;
}
function u64Lengths(dataLength, aadLength, isLE) {
	abool(isLE);
	const num = /* @__PURE__ */ new Uint8Array(16);
	const view = createView(num);
	view.setBigUint64(0, BigInt(aadLength), isLE);
	view.setBigUint64(8, BigInt(dataLength), isLE);
	return num;
}
function isAligned32$1(bytes) {
	return bytes.byteOffset % 4 === 0;
}
function copyBytes(bytes) {
	return Uint8Array.from(bytes);
}
/** Cryptographically secure PRNG. Uses internal OS-level `crypto.getRandomValues`. */
function randomBytes(bytesLength = 32) {
	const cr = typeof globalThis === "object" ? globalThis.crypto : null;
	if (typeof cr?.getRandomValues !== "function") throw new Error("crypto.getRandomValues must be defined");
	return cr.getRandomValues(new Uint8Array(bytesLength));
}
/**
* Uses CSPRG for nonce, nonce injected in ciphertext.
* For `encrypt`, a `nonceBytes`-length buffer is fetched from CSPRNG and
* prepended to encrypted ciphertext. For `decrypt`, first `nonceBytes` of ciphertext
* are treated as nonce.
*
* NOTE: Under the same key, using random nonces (e.g. `managedNonce`) with AES-GCM and ChaCha
* should be limited to `2**23` (8M) messages to get a collision chance of `2**-50`. Stretching to  * `2**32` (4B) messages, chance would become `2**-33` - still negligible, but creeping up.
* @example
* const gcm = managedNonce(aes.gcm);
* const ciphr = gcm(key).encrypt(data);
* const plain = gcm(key).decrypt(ciph);
*/
function managedNonce(fn, randomBytes_ = randomBytes) {
	const { nonceLength } = fn;
	anumber(nonceLength);
	const addNonce = (nonce, ciphertext) => {
		const out = concatBytes(nonce, ciphertext);
		ciphertext.fill(0);
		return out;
	};
	return ((key, ...args) => ({
		encrypt(plaintext) {
			abytes(plaintext);
			const nonce = randomBytes_(nonceLength);
			const encrypted = fn(key, nonce, ...args).encrypt(plaintext);
			if (encrypted instanceof Promise) return encrypted.then((ct) => addNonce(nonce, ct));
			return addNonce(nonce, encrypted);
		},
		decrypt(ciphertext) {
			abytes(ciphertext);
			const nonce = ciphertext.subarray(0, nonceLength);
			const decrypted = ciphertext.subarray(nonceLength);
			return fn(key, nonce, ...args).decrypt(decrypted);
		}
	}));
}
//#endregion
//#region node_modules/.pnpm/@noble+ciphers@2.1.1/node_modules/@noble/ciphers/_arx.js
/**
* Basic utils for ARX (add-rotate-xor) salsa and chacha ciphers.

RFC8439 requires multi-step cipher stream, where
authKey starts with counter: 0, actual msg with counter: 1.

For this, we need a way to re-use nonce / counter:

const counter = new Uint8Array(4);
chacha(..., counter, ...); // counter is now 1
chacha(..., counter, ...); // counter is now 2

This is complicated:

- 32-bit counters are enough, no need for 64-bit: max ArrayBuffer size in JS is 4GB
- Original papers don't allow mutating counters
- Counter overflow is undefined [^1]
- Idea A: allow providing (nonce | counter) instead of just nonce, re-use it
- Caveat: Cannot be re-used through all cases:
- * chacha has (counter | nonce)
- * xchacha has (nonce16 | counter | nonce16)
- Idea B: separate nonce / counter and provide separate API for counter re-use
- Caveat: there are different counter sizes depending on an algorithm.
- salsa & chacha also differ in structures of key & sigma:
salsa20:      s[0] | k(4) | s[1] | nonce(2) | cnt(2) | s[2] | k(4) | s[3]
chacha:       s(4) | k(8) | cnt(1) | nonce(3)
chacha20orig: s(4) | k(8) | cnt(2) | nonce(2)
- Idea C: helper method such as `setSalsaState(key, nonce, sigma, data)`
- Caveat: we can't re-use counter array

xchacha [^2] uses the subkey and remaining 8 byte nonce with ChaCha20 as normal
(prefixed by 4 NUL bytes, since [RFC8439] specifies a 12-byte nonce).

[^1]: https://mailarchive.ietf.org/arch/msg/cfrg/gsOnTJzcbgG6OqD8Sc0GO5aR_tU/
[^2]: https://datatracker.ietf.org/doc/html/draft-irtf-cfrg-xchacha#appendix-A.2

* @module
*/
var encodeStr = (str) => Uint8Array.from(str.split(""), (c) => c.charCodeAt(0));
var sigma16 = encodeStr("expand 16-byte k");
var sigma32 = encodeStr("expand 32-byte k");
var sigma16_32 = u32(sigma16);
var sigma32_32 = u32(sigma32);
/** Rotate left. */
function rotl(a, b) {
	return a << b | a >>> 32 - b;
}
function isAligned32(b) {
	return b.byteOffset % 4 === 0;
}
var BLOCK_LEN = 64;
var BLOCK_LEN32 = 16;
var MAX_COUNTER = 2 ** 32 - 1;
var U32_EMPTY = Uint32Array.of();
function runCipher(core, sigma, key, nonce, data, output, counter, rounds) {
	const len = data.length;
	const block = new Uint8Array(BLOCK_LEN);
	const b32 = u32(block);
	const isAligned = isAligned32(data) && isAligned32(output);
	const d32 = isAligned ? u32(data) : U32_EMPTY;
	const o32 = isAligned ? u32(output) : U32_EMPTY;
	for (let pos = 0; pos < len; counter++) {
		core(sigma, key, nonce, b32, counter, rounds);
		if (counter >= MAX_COUNTER) throw new Error("arx: counter overflow");
		const take = Math.min(BLOCK_LEN, len - pos);
		if (isAligned && take === BLOCK_LEN) {
			const pos32 = pos / 4;
			if (pos % 4 !== 0) throw new Error("arx: invalid block position");
			for (let j = 0, posj; j < BLOCK_LEN32; j++) {
				posj = pos32 + j;
				o32[posj] = d32[posj] ^ b32[j];
			}
			pos += BLOCK_LEN;
			continue;
		}
		for (let j = 0, posj; j < take; j++) {
			posj = pos + j;
			output[posj] = data[posj] ^ block[j];
		}
		pos += take;
	}
}
/** Creates ARX-like (ChaCha, Salsa) cipher stream from core function. */
function createCipher(core, opts) {
	const { allowShortKeys, extendNonceFn, counterLength, counterRight, rounds } = checkOpts({
		allowShortKeys: false,
		counterLength: 8,
		counterRight: false,
		rounds: 20
	}, opts);
	if (typeof core !== "function") throw new Error("core must be a function");
	anumber(counterLength);
	anumber(rounds);
	abool(counterRight);
	abool(allowShortKeys);
	return (key, nonce, data, output, counter = 0) => {
		abytes(key, void 0, "key");
		abytes(nonce, void 0, "nonce");
		abytes(data, void 0, "data");
		const len = data.length;
		if (output === void 0) output = new Uint8Array(len);
		abytes(output, void 0, "output");
		anumber(counter);
		if (counter < 0 || counter >= MAX_COUNTER) throw new Error("arx: counter overflow");
		if (output.length < len) throw new Error(`arx: output (${output.length}) is shorter than data (${len})`);
		const toClean = [];
		let l = key.length;
		let k;
		let sigma;
		if (l === 32) {
			toClean.push(k = copyBytes(key));
			sigma = sigma32_32;
		} else if (l === 16 && allowShortKeys) {
			k = /* @__PURE__ */ new Uint8Array(32);
			k.set(key);
			k.set(key, 16);
			sigma = sigma16_32;
			toClean.push(k);
		} else {
			abytes(key, 32, "arx key");
			throw new Error("invalid key size");
		}
		if (!isAligned32(nonce)) toClean.push(nonce = copyBytes(nonce));
		const k32 = u32(k);
		if (extendNonceFn) {
			if (nonce.length !== 24) throw new Error(`arx: extended nonce must be 24 bytes`);
			extendNonceFn(sigma, k32, u32(nonce.subarray(0, 16)), k32);
			nonce = nonce.subarray(16);
		}
		const nonceNcLen = 16 - counterLength;
		if (nonceNcLen !== nonce.length) throw new Error(`arx: nonce must be ${nonceNcLen} or 16 bytes`);
		if (nonceNcLen !== 12) {
			const nc = /* @__PURE__ */ new Uint8Array(12);
			nc.set(nonce, counterRight ? 0 : 12 - nonce.length);
			nonce = nc;
			toClean.push(nonce);
		}
		const n32 = u32(nonce);
		runCipher(core, sigma, k32, n32, data, output, counter, rounds);
		clean(...toClean);
		return output;
	};
}
//#endregion
//#region node_modules/.pnpm/@noble+ciphers@2.1.1/node_modules/@noble/ciphers/_poly1305.js
/**
* Poly1305 ([PDF](https://cr.yp.to/mac/poly1305-20050329.pdf),
* [wiki](https://en.wikipedia.org/wiki/Poly1305))
* is a fast and parallel secret-key message-authentication code suitable for
* a wide variety of applications. It was standardized in
* [RFC 8439](https://www.rfc-editor.org/rfc/rfc8439) and is now used in TLS 1.3.
*
* Polynomial MACs are not perfect for every situation:
* they lack Random Key Robustness: the MAC can be forged, and can't be used in PAKE schemes.
* See [invisible salamanders attack](https://keymaterial.net/2020/09/07/invisible-salamanders-in-aes-gcm-siv/).
* To combat invisible salamanders, `hash(key)` can be included in ciphertext,
* however, this would violate ciphertext indistinguishability:
* an attacker would know which key was used - so `HKDF(key, i)`
* could be used instead.
*
* Check out [original website](https://cr.yp.to/mac.html).
* Based on Public Domain [poly1305-donna](https://github.com/floodyberry/poly1305-donna).
* @module
*/
function u8to16(a, i) {
	return a[i++] & 255 | (a[i++] & 255) << 8;
}
/** Poly1305 class. Prefer poly1305() function instead. */
var Poly1305 = class {
	blockLen = 16;
	outputLen = 16;
	buffer = /* @__PURE__ */ new Uint8Array(16);
	r = /* @__PURE__ */ new Uint16Array(10);
	h = /* @__PURE__ */ new Uint16Array(10);
	pad = /* @__PURE__ */ new Uint16Array(8);
	pos = 0;
	finished = false;
	constructor(key) {
		key = copyBytes(abytes(key, 32, "key"));
		const t0 = u8to16(key, 0);
		const t1 = u8to16(key, 2);
		const t2 = u8to16(key, 4);
		const t3 = u8to16(key, 6);
		const t4 = u8to16(key, 8);
		const t5 = u8to16(key, 10);
		const t6 = u8to16(key, 12);
		const t7 = u8to16(key, 14);
		this.r[0] = t0 & 8191;
		this.r[1] = (t0 >>> 13 | t1 << 3) & 8191;
		this.r[2] = (t1 >>> 10 | t2 << 6) & 7939;
		this.r[3] = (t2 >>> 7 | t3 << 9) & 8191;
		this.r[4] = (t3 >>> 4 | t4 << 12) & 255;
		this.r[5] = t4 >>> 1 & 8190;
		this.r[6] = (t4 >>> 14 | t5 << 2) & 8191;
		this.r[7] = (t5 >>> 11 | t6 << 5) & 8065;
		this.r[8] = (t6 >>> 8 | t7 << 8) & 8191;
		this.r[9] = t7 >>> 5 & 127;
		for (let i = 0; i < 8; i++) this.pad[i] = u8to16(key, 16 + 2 * i);
	}
	process(data, offset, isLast = false) {
		const hibit = isLast ? 0 : 2048;
		const { h, r } = this;
		const r0 = r[0];
		const r1 = r[1];
		const r2 = r[2];
		const r3 = r[3];
		const r4 = r[4];
		const r5 = r[5];
		const r6 = r[6];
		const r7 = r[7];
		const r8 = r[8];
		const r9 = r[9];
		const t0 = u8to16(data, offset + 0);
		const t1 = u8to16(data, offset + 2);
		const t2 = u8to16(data, offset + 4);
		const t3 = u8to16(data, offset + 6);
		const t4 = u8to16(data, offset + 8);
		const t5 = u8to16(data, offset + 10);
		const t6 = u8to16(data, offset + 12);
		const t7 = u8to16(data, offset + 14);
		let h0 = h[0] + (t0 & 8191);
		let h1 = h[1] + ((t0 >>> 13 | t1 << 3) & 8191);
		let h2 = h[2] + ((t1 >>> 10 | t2 << 6) & 8191);
		let h3 = h[3] + ((t2 >>> 7 | t3 << 9) & 8191);
		let h4 = h[4] + ((t3 >>> 4 | t4 << 12) & 8191);
		let h5 = h[5] + (t4 >>> 1 & 8191);
		let h6 = h[6] + ((t4 >>> 14 | t5 << 2) & 8191);
		let h7 = h[7] + ((t5 >>> 11 | t6 << 5) & 8191);
		let h8 = h[8] + ((t6 >>> 8 | t7 << 8) & 8191);
		let h9 = h[9] + (t7 >>> 5 | hibit);
		let c = 0;
		let d0 = c + h0 * r0 + h1 * (5 * r9) + h2 * (5 * r8) + h3 * (5 * r7) + h4 * (5 * r6);
		c = d0 >>> 13;
		d0 &= 8191;
		d0 += h5 * (5 * r5) + h6 * (5 * r4) + h7 * (5 * r3) + h8 * (5 * r2) + h9 * (5 * r1);
		c += d0 >>> 13;
		d0 &= 8191;
		let d1 = c + h0 * r1 + h1 * r0 + h2 * (5 * r9) + h3 * (5 * r8) + h4 * (5 * r7);
		c = d1 >>> 13;
		d1 &= 8191;
		d1 += h5 * (5 * r6) + h6 * (5 * r5) + h7 * (5 * r4) + h8 * (5 * r3) + h9 * (5 * r2);
		c += d1 >>> 13;
		d1 &= 8191;
		let d2 = c + h0 * r2 + h1 * r1 + h2 * r0 + h3 * (5 * r9) + h4 * (5 * r8);
		c = d2 >>> 13;
		d2 &= 8191;
		d2 += h5 * (5 * r7) + h6 * (5 * r6) + h7 * (5 * r5) + h8 * (5 * r4) + h9 * (5 * r3);
		c += d2 >>> 13;
		d2 &= 8191;
		let d3 = c + h0 * r3 + h1 * r2 + h2 * r1 + h3 * r0 + h4 * (5 * r9);
		c = d3 >>> 13;
		d3 &= 8191;
		d3 += h5 * (5 * r8) + h6 * (5 * r7) + h7 * (5 * r6) + h8 * (5 * r5) + h9 * (5 * r4);
		c += d3 >>> 13;
		d3 &= 8191;
		let d4 = c + h0 * r4 + h1 * r3 + h2 * r2 + h3 * r1 + h4 * r0;
		c = d4 >>> 13;
		d4 &= 8191;
		d4 += h5 * (5 * r9) + h6 * (5 * r8) + h7 * (5 * r7) + h8 * (5 * r6) + h9 * (5 * r5);
		c += d4 >>> 13;
		d4 &= 8191;
		let d5 = c + h0 * r5 + h1 * r4 + h2 * r3 + h3 * r2 + h4 * r1;
		c = d5 >>> 13;
		d5 &= 8191;
		d5 += h5 * r0 + h6 * (5 * r9) + h7 * (5 * r8) + h8 * (5 * r7) + h9 * (5 * r6);
		c += d5 >>> 13;
		d5 &= 8191;
		let d6 = c + h0 * r6 + h1 * r5 + h2 * r4 + h3 * r3 + h4 * r2;
		c = d6 >>> 13;
		d6 &= 8191;
		d6 += h5 * r1 + h6 * r0 + h7 * (5 * r9) + h8 * (5 * r8) + h9 * (5 * r7);
		c += d6 >>> 13;
		d6 &= 8191;
		let d7 = c + h0 * r7 + h1 * r6 + h2 * r5 + h3 * r4 + h4 * r3;
		c = d7 >>> 13;
		d7 &= 8191;
		d7 += h5 * r2 + h6 * r1 + h7 * r0 + h8 * (5 * r9) + h9 * (5 * r8);
		c += d7 >>> 13;
		d7 &= 8191;
		let d8 = c + h0 * r8 + h1 * r7 + h2 * r6 + h3 * r5 + h4 * r4;
		c = d8 >>> 13;
		d8 &= 8191;
		d8 += h5 * r3 + h6 * r2 + h7 * r1 + h8 * r0 + h9 * (5 * r9);
		c += d8 >>> 13;
		d8 &= 8191;
		let d9 = c + h0 * r9 + h1 * r8 + h2 * r7 + h3 * r6 + h4 * r5;
		c = d9 >>> 13;
		d9 &= 8191;
		d9 += h5 * r4 + h6 * r3 + h7 * r2 + h8 * r1 + h9 * r0;
		c += d9 >>> 13;
		d9 &= 8191;
		c = (c << 2) + c | 0;
		c = c + d0 | 0;
		d0 = c & 8191;
		c = c >>> 13;
		d1 += c;
		h[0] = d0;
		h[1] = d1;
		h[2] = d2;
		h[3] = d3;
		h[4] = d4;
		h[5] = d5;
		h[6] = d6;
		h[7] = d7;
		h[8] = d8;
		h[9] = d9;
	}
	finalize() {
		const { h, pad } = this;
		const g = /* @__PURE__ */ new Uint16Array(10);
		let c = h[1] >>> 13;
		h[1] &= 8191;
		for (let i = 2; i < 10; i++) {
			h[i] += c;
			c = h[i] >>> 13;
			h[i] &= 8191;
		}
		h[0] += c * 5;
		c = h[0] >>> 13;
		h[0] &= 8191;
		h[1] += c;
		c = h[1] >>> 13;
		h[1] &= 8191;
		h[2] += c;
		g[0] = h[0] + 5;
		c = g[0] >>> 13;
		g[0] &= 8191;
		for (let i = 1; i < 10; i++) {
			g[i] = h[i] + c;
			c = g[i] >>> 13;
			g[i] &= 8191;
		}
		g[9] -= 8192;
		let mask = (c ^ 1) - 1;
		for (let i = 0; i < 10; i++) g[i] &= mask;
		mask = ~mask;
		for (let i = 0; i < 10; i++) h[i] = h[i] & mask | g[i];
		h[0] = (h[0] | h[1] << 13) & 65535;
		h[1] = (h[1] >>> 3 | h[2] << 10) & 65535;
		h[2] = (h[2] >>> 6 | h[3] << 7) & 65535;
		h[3] = (h[3] >>> 9 | h[4] << 4) & 65535;
		h[4] = (h[4] >>> 12 | h[5] << 1 | h[6] << 14) & 65535;
		h[5] = (h[6] >>> 2 | h[7] << 11) & 65535;
		h[6] = (h[7] >>> 5 | h[8] << 8) & 65535;
		h[7] = (h[8] >>> 8 | h[9] << 5) & 65535;
		let f = h[0] + pad[0];
		h[0] = f & 65535;
		for (let i = 1; i < 8; i++) {
			f = (h[i] + pad[i] | 0) + (f >>> 16) | 0;
			h[i] = f & 65535;
		}
		clean(g);
	}
	update(data) {
		aexists(this);
		abytes(data);
		data = copyBytes(data);
		const { buffer, blockLen } = this;
		const len = data.length;
		for (let pos = 0; pos < len;) {
			const take = Math.min(blockLen - this.pos, len - pos);
			if (take === blockLen) {
				for (; blockLen <= len - pos; pos += blockLen) this.process(data, pos);
				continue;
			}
			buffer.set(data.subarray(pos, pos + take), this.pos);
			this.pos += take;
			pos += take;
			if (this.pos === blockLen) {
				this.process(buffer, 0, false);
				this.pos = 0;
			}
		}
		return this;
	}
	destroy() {
		clean(this.h, this.r, this.buffer, this.pad);
	}
	digestInto(out) {
		aexists(this);
		aoutput(out, this);
		this.finished = true;
		const { buffer, h } = this;
		let { pos } = this;
		if (pos) {
			buffer[pos++] = 1;
			for (; pos < 16; pos++) buffer[pos] = 0;
			this.process(buffer, 0, true);
		}
		this.finalize();
		let opos = 0;
		for (let i = 0; i < 8; i++) {
			out[opos++] = h[i] >>> 0;
			out[opos++] = h[i] >>> 8;
		}
		return out;
	}
	digest() {
		const { buffer, outputLen } = this;
		this.digestInto(buffer);
		const res = buffer.slice(0, outputLen);
		this.destroy();
		return res;
	}
};
function wrapConstructorWithKey(hashCons) {
	const hashC = (msg, key) => hashCons(key).update(msg).digest();
	const tmp = hashCons(/* @__PURE__ */ new Uint8Array(32));
	hashC.outputLen = tmp.outputLen;
	hashC.blockLen = tmp.blockLen;
	hashC.create = (key) => hashCons(key);
	return hashC;
}
/** Poly1305 MAC from RFC 8439. */
var poly1305 = (() => wrapConstructorWithKey((key) => new Poly1305(key)))();
//#endregion
//#region node_modules/.pnpm/@noble+ciphers@2.1.1/node_modules/@noble/ciphers/chacha.js
/**
* ChaCha stream cipher, released
* in 2008. Developed after Salsa20, ChaCha aims to increase diffusion per round.
* It was standardized in [RFC 8439](https://www.rfc-editor.org/rfc/rfc8439) and
* is now used in TLS 1.3.
*
* [XChaCha20](https://datatracker.ietf.org/doc/html/draft-irtf-cfrg-xchacha)
* extended-nonce variant is also provided. Similar to XSalsa, it's safe to use with
* randomly-generated nonces.
*
* Check out [PDF](http://cr.yp.to/chacha/chacha-20080128.pdf) and
* [wiki](https://en.wikipedia.org/wiki/Salsa20) and
* [website](https://cr.yp.to/chacha.html).
*
* @module
*/
/** Identical to `chachaCore_small`. Unused. */
function chachaCore(s, k, n, out, cnt, rounds = 20) {
	let y00 = s[0], y01 = s[1], y02 = s[2], y03 = s[3], y04 = k[0], y05 = k[1], y06 = k[2], y07 = k[3], y08 = k[4], y09 = k[5], y10 = k[6], y11 = k[7], y12 = cnt, y13 = n[0], y14 = n[1], y15 = n[2];
	let x00 = y00, x01 = y01, x02 = y02, x03 = y03, x04 = y04, x05 = y05, x06 = y06, x07 = y07, x08 = y08, x09 = y09, x10 = y10, x11 = y11, x12 = y12, x13 = y13, x14 = y14, x15 = y15;
	for (let r = 0; r < rounds; r += 2) {
		x00 = x00 + x04 | 0;
		x12 = rotl(x12 ^ x00, 16);
		x08 = x08 + x12 | 0;
		x04 = rotl(x04 ^ x08, 12);
		x00 = x00 + x04 | 0;
		x12 = rotl(x12 ^ x00, 8);
		x08 = x08 + x12 | 0;
		x04 = rotl(x04 ^ x08, 7);
		x01 = x01 + x05 | 0;
		x13 = rotl(x13 ^ x01, 16);
		x09 = x09 + x13 | 0;
		x05 = rotl(x05 ^ x09, 12);
		x01 = x01 + x05 | 0;
		x13 = rotl(x13 ^ x01, 8);
		x09 = x09 + x13 | 0;
		x05 = rotl(x05 ^ x09, 7);
		x02 = x02 + x06 | 0;
		x14 = rotl(x14 ^ x02, 16);
		x10 = x10 + x14 | 0;
		x06 = rotl(x06 ^ x10, 12);
		x02 = x02 + x06 | 0;
		x14 = rotl(x14 ^ x02, 8);
		x10 = x10 + x14 | 0;
		x06 = rotl(x06 ^ x10, 7);
		x03 = x03 + x07 | 0;
		x15 = rotl(x15 ^ x03, 16);
		x11 = x11 + x15 | 0;
		x07 = rotl(x07 ^ x11, 12);
		x03 = x03 + x07 | 0;
		x15 = rotl(x15 ^ x03, 8);
		x11 = x11 + x15 | 0;
		x07 = rotl(x07 ^ x11, 7);
		x00 = x00 + x05 | 0;
		x15 = rotl(x15 ^ x00, 16);
		x10 = x10 + x15 | 0;
		x05 = rotl(x05 ^ x10, 12);
		x00 = x00 + x05 | 0;
		x15 = rotl(x15 ^ x00, 8);
		x10 = x10 + x15 | 0;
		x05 = rotl(x05 ^ x10, 7);
		x01 = x01 + x06 | 0;
		x12 = rotl(x12 ^ x01, 16);
		x11 = x11 + x12 | 0;
		x06 = rotl(x06 ^ x11, 12);
		x01 = x01 + x06 | 0;
		x12 = rotl(x12 ^ x01, 8);
		x11 = x11 + x12 | 0;
		x06 = rotl(x06 ^ x11, 7);
		x02 = x02 + x07 | 0;
		x13 = rotl(x13 ^ x02, 16);
		x08 = x08 + x13 | 0;
		x07 = rotl(x07 ^ x08, 12);
		x02 = x02 + x07 | 0;
		x13 = rotl(x13 ^ x02, 8);
		x08 = x08 + x13 | 0;
		x07 = rotl(x07 ^ x08, 7);
		x03 = x03 + x04 | 0;
		x14 = rotl(x14 ^ x03, 16);
		x09 = x09 + x14 | 0;
		x04 = rotl(x04 ^ x09, 12);
		x03 = x03 + x04 | 0;
		x14 = rotl(x14 ^ x03, 8);
		x09 = x09 + x14 | 0;
		x04 = rotl(x04 ^ x09, 7);
	}
	let oi = 0;
	out[oi++] = y00 + x00 | 0;
	out[oi++] = y01 + x01 | 0;
	out[oi++] = y02 + x02 | 0;
	out[oi++] = y03 + x03 | 0;
	out[oi++] = y04 + x04 | 0;
	out[oi++] = y05 + x05 | 0;
	out[oi++] = y06 + x06 | 0;
	out[oi++] = y07 + x07 | 0;
	out[oi++] = y08 + x08 | 0;
	out[oi++] = y09 + x09 | 0;
	out[oi++] = y10 + x10 | 0;
	out[oi++] = y11 + x11 | 0;
	out[oi++] = y12 + x12 | 0;
	out[oi++] = y13 + x13 | 0;
	out[oi++] = y14 + x14 | 0;
	out[oi++] = y15 + x15 | 0;
}
/**
* hchacha hashes key and nonce into key' and nonce' for xchacha20.
* Identical to `hchacha_small`.
* Need to find a way to merge it with `chachaCore` without 25% performance hit.
*/
function hchacha(s, k, i, out) {
	let x00 = s[0], x01 = s[1], x02 = s[2], x03 = s[3], x04 = k[0], x05 = k[1], x06 = k[2], x07 = k[3], x08 = k[4], x09 = k[5], x10 = k[6], x11 = k[7], x12 = i[0], x13 = i[1], x14 = i[2], x15 = i[3];
	for (let r = 0; r < 20; r += 2) {
		x00 = x00 + x04 | 0;
		x12 = rotl(x12 ^ x00, 16);
		x08 = x08 + x12 | 0;
		x04 = rotl(x04 ^ x08, 12);
		x00 = x00 + x04 | 0;
		x12 = rotl(x12 ^ x00, 8);
		x08 = x08 + x12 | 0;
		x04 = rotl(x04 ^ x08, 7);
		x01 = x01 + x05 | 0;
		x13 = rotl(x13 ^ x01, 16);
		x09 = x09 + x13 | 0;
		x05 = rotl(x05 ^ x09, 12);
		x01 = x01 + x05 | 0;
		x13 = rotl(x13 ^ x01, 8);
		x09 = x09 + x13 | 0;
		x05 = rotl(x05 ^ x09, 7);
		x02 = x02 + x06 | 0;
		x14 = rotl(x14 ^ x02, 16);
		x10 = x10 + x14 | 0;
		x06 = rotl(x06 ^ x10, 12);
		x02 = x02 + x06 | 0;
		x14 = rotl(x14 ^ x02, 8);
		x10 = x10 + x14 | 0;
		x06 = rotl(x06 ^ x10, 7);
		x03 = x03 + x07 | 0;
		x15 = rotl(x15 ^ x03, 16);
		x11 = x11 + x15 | 0;
		x07 = rotl(x07 ^ x11, 12);
		x03 = x03 + x07 | 0;
		x15 = rotl(x15 ^ x03, 8);
		x11 = x11 + x15 | 0;
		x07 = rotl(x07 ^ x11, 7);
		x00 = x00 + x05 | 0;
		x15 = rotl(x15 ^ x00, 16);
		x10 = x10 + x15 | 0;
		x05 = rotl(x05 ^ x10, 12);
		x00 = x00 + x05 | 0;
		x15 = rotl(x15 ^ x00, 8);
		x10 = x10 + x15 | 0;
		x05 = rotl(x05 ^ x10, 7);
		x01 = x01 + x06 | 0;
		x12 = rotl(x12 ^ x01, 16);
		x11 = x11 + x12 | 0;
		x06 = rotl(x06 ^ x11, 12);
		x01 = x01 + x06 | 0;
		x12 = rotl(x12 ^ x01, 8);
		x11 = x11 + x12 | 0;
		x06 = rotl(x06 ^ x11, 7);
		x02 = x02 + x07 | 0;
		x13 = rotl(x13 ^ x02, 16);
		x08 = x08 + x13 | 0;
		x07 = rotl(x07 ^ x08, 12);
		x02 = x02 + x07 | 0;
		x13 = rotl(x13 ^ x02, 8);
		x08 = x08 + x13 | 0;
		x07 = rotl(x07 ^ x08, 7);
		x03 = x03 + x04 | 0;
		x14 = rotl(x14 ^ x03, 16);
		x09 = x09 + x14 | 0;
		x04 = rotl(x04 ^ x09, 12);
		x03 = x03 + x04 | 0;
		x14 = rotl(x14 ^ x03, 8);
		x09 = x09 + x14 | 0;
		x04 = rotl(x04 ^ x09, 7);
	}
	let oi = 0;
	out[oi++] = x00;
	out[oi++] = x01;
	out[oi++] = x02;
	out[oi++] = x03;
	out[oi++] = x12;
	out[oi++] = x13;
	out[oi++] = x14;
	out[oi++] = x15;
}
/**
* XChaCha eXtended-nonce ChaCha. With 24-byte nonce, it's safe to make it random (CSPRNG).
* See [IRTF draft](https://datatracker.ietf.org/doc/html/draft-irtf-cfrg-xchacha).
*/
var xchacha20 = /* @__PURE__ */ createCipher(chachaCore, {
	counterRight: false,
	counterLength: 8,
	extendNonceFn: hchacha,
	allowShortKeys: false
});
var ZEROS16 = /* @__PURE__ */ new Uint8Array(16);
var updatePadded = (h, msg) => {
	h.update(msg);
	const leftover = msg.length % 16;
	if (leftover) h.update(ZEROS16.subarray(leftover));
};
var ZEROS32 = /* @__PURE__ */ new Uint8Array(32);
function computeTag(fn, key, nonce, ciphertext, AAD) {
	if (AAD !== void 0) abytes(AAD, void 0, "AAD");
	const authKey = fn(key, nonce, ZEROS32);
	const lengths = u64Lengths(ciphertext.length, AAD ? AAD.length : 0, true);
	const h = poly1305.create(authKey);
	if (AAD) updatePadded(h, AAD);
	updatePadded(h, ciphertext);
	h.update(lengths);
	const res = h.digest();
	clean(authKey, lengths);
	return res;
}
/**
* AEAD algorithm from RFC 8439.
* Salsa20 and chacha (RFC 8439) use poly1305 differently.
* We could have composed them, but it's hard because of authKey:
* In salsa20, authKey changes position in salsa stream.
* In chacha, authKey can't be computed inside computeTag, it modifies the counter.
*/
var _poly1305_aead = (xorStream) => (key, nonce, AAD) => {
	const tagLength = 16;
	return {
		encrypt(plaintext, output) {
			const plength = plaintext.length;
			output = getOutput(plength + tagLength, output, false);
			output.set(plaintext);
			const oPlain = output.subarray(0, -16);
			xorStream(key, nonce, oPlain, oPlain, 1);
			const tag = computeTag(xorStream, key, nonce, oPlain, AAD);
			output.set(tag, plength);
			clean(tag);
			return output;
		},
		decrypt(ciphertext, output) {
			output = getOutput(ciphertext.length - tagLength, output, false);
			const data = ciphertext.subarray(0, -16);
			const passedTag = ciphertext.subarray(-16);
			const tag = computeTag(xorStream, key, nonce, data, AAD);
			if (!equalBytes(passedTag, tag)) throw new Error("invalid tag");
			output.set(ciphertext.subarray(0, -16));
			xorStream(key, nonce, output, output, 1);
			clean(tag);
			return output;
		}
	};
};
/**
* XChaCha20-Poly1305 extended-nonce chacha.
*
* Can be safely used with random nonces (CSPRNG).
* See [IRTF draft](https://datatracker.ietf.org/doc/html/draft-irtf-cfrg-xchacha).
*/
var xchacha20poly1305 = /* @__PURE__ */ wrapCipher({
	blockSize: 64,
	nonceLength: 24,
	tagLength: 16
}, _poly1305_aead(xchacha20));
//#endregion
//#region node_modules/.pnpm/better-auth@1.6.22_@cloudflare+workers-types@4.20260702.1_@opentelemetry+api@1.9.1_@tan_c64da104bf565ea1fd6d317ee311b5ed/node_modules/better-auth/dist/crypto/index.mjs
var ENVELOPE_PREFIX = "$ba$";
function parseEnvelope(data) {
	if (!data.startsWith(ENVELOPE_PREFIX)) return null;
	const firstSep = 4;
	const secondSep = data.indexOf("$", firstSep);
	if (secondSep === -1) return null;
	const version = parseInt(data.slice(firstSep, secondSep), 10);
	if (!Number.isInteger(version) || version < 0) return null;
	return {
		version,
		ciphertext: data.slice(secondSep + 1)
	};
}
function formatEnvelope(version, ciphertext) {
	return `${ENVELOPE_PREFIX}${version}$${ciphertext}`;
}
async function rawEncrypt(secret, data) {
	const keyAsBytes = await createHash("SHA-256").digest(secret);
	const dataAsBytes = utf8ToBytes(data);
	return bytesToHex(managedNonce(xchacha20poly1305)(new Uint8Array(keyAsBytes)).encrypt(dataAsBytes));
}
async function rawDecrypt(secret, hex) {
	const keyAsBytes = await createHash("SHA-256").digest(secret);
	const dataAsBytes = hexToBytes(hex);
	const chacha = managedNonce(xchacha20poly1305)(new Uint8Array(keyAsBytes));
	return new TextDecoder().decode(chacha.decrypt(dataAsBytes));
}
var symmetricEncrypt = async ({ key, data }) => {
	if (typeof key === "string") return rawEncrypt(key, data);
	const secret = key.keys.get(key.currentVersion);
	if (!secret) throw new Error(`Secret version ${key.currentVersion} not found in keys`);
	const ciphertext = await rawEncrypt(secret, data);
	return formatEnvelope(key.currentVersion, ciphertext);
};
var symmetricDecrypt = async ({ key, data }) => {
	if (typeof key === "string") return rawDecrypt(key, data);
	const envelope = parseEnvelope(data);
	if (envelope) {
		const secret = key.keys.get(envelope.version);
		if (!secret) throw new Error(`Secret version ${envelope.version} not found in keys (key may have been retired)`);
		return rawDecrypt(secret, envelope.ciphertext);
	}
	if (key.legacySecret) return rawDecrypt(key.legacySecret, data);
	throw new Error("Cannot decrypt legacy bare-hex payload: no legacy secret available. Set BETTER_AUTH_SECRET for backwards compatibility.");
};
//#endregion
//#region src/server/features/audit/repositories/CrawlerCredentialRepository.ts
function inOrganization(organizationId) {
	return and(eq(projects.organizationId, organizationId), isNull(projects.archivedAt));
}
/**
* Looks across every project in the organization, so a store audited from a
* second project still finds the signature saved on the first. The host match
* is exact, because Shopify scopes a signature to one domain. Returns every
* match, the audited project's own row first, so the caller can skip an
* expired row in favour of a live one on another project.
*/
async function findForOrganizationAndHost(organizationId, projectId, host) {
	return t(await db.select(getTableColumns(crawlerCredentials)).from(crawlerCredentials).innerJoin(projects, eq(projects.id, crawlerCredentials.projectId)).where(and(inOrganization(organizationId), eq(crawlerCredentials.host, host))), (row) => row.projectId !== projectId);
}
async function listForOrganization(organizationId) {
	return db.select(getTableColumns(crawlerCredentials)).from(crawlerCredentials).innerJoin(projects, eq(projects.id, crawlerCredentials.projectId)).where(inOrganization(organizationId)).orderBy(asc(crawlerCredentials.host));
}
async function upsert(input) {
	const createdAt = (/* @__PURE__ */ new Date()).toISOString();
	await db.insert(crawlerCredentials).values({
		...input,
		createdAt
	}).onConflictDoUpdate({
		target: [crawlerCredentials.projectId, crawlerCredentials.host],
		set: {
			provider: input.provider,
			signatureInput: input.signatureInput,
			signature: input.signature,
			expiresAt: input.expiresAt,
			createdByUserId: input.createdByUserId,
			createdAt
		}
	});
}
async function remove(organizationId, id) {
	await db.delete(crawlerCredentials).where(and(eq(crawlerCredentials.id, id), inArray(crawlerCredentials.projectId, db.select({ id: projects.id }).from(projects).where(eq(projects.organizationId, organizationId)))));
}
var CrawlerCredentialRepository = {
	findForOrganizationAndHost,
	listForOrganization,
	upsert,
	remove
};
//#endregion
//#region src/server/features/audit/services/shopifySignature.ts
/**
* Checks a Shopify crawler-access signature against the domain it will be
* sent to, before it is saved.
*
* Shopify signs two things with the key it publishes: the domain picked in
* Shopify admin (`@authority`) and the `Signature-Agent` value. Shopify
* ignores a signature made for another domain (`www.` versus the bare domain
* is the usual slip) or pasted incompletely, and rate-limits the crawl as if
* it were unsigned. Checking here tells the merchant why at save time.
*/
var SHOPIFY_KEY_DIRECTORY_URL = "https://shopify.com/.well-known/http-message-signatures-directory";
var directoryKeySchema = object({
	kid: string(),
	x: string()
});
/**
* Null means the signature is fine for `host`, or couldn't be checked: an
* unreachable key directory must not block a save.
*/
async function checkShopifySignature(input) {
	const { host, signatureInput } = input;
	const params = /^\w+=(\(.+)$/.exec(signatureInput)?.[1];
	const keyId = /;keyid="([^"]+)"/.exec(signatureInput)?.[1];
	const signatureBytes = decodeSignature(input.signature);
	if (!params || !keyId || !signatureBytes) return {
		reason: "invalid",
		host
	};
	const key = await importShopifyKey(keyId);
	if (!key) return null;
	const verifiesFor = (domain) => crypto.subtle.verify("Ed25519", key, signatureBytes, new TextEncoder().encode(`"@authority": ${domain}\n"signature-agent": ${SHOPIFY_SIGNATURE_AGENT}\n"@signature-params": ${params}`));
	if (await verifiesFor(host)) return null;
	const twinHost = host.startsWith("www.") ? host.slice(4) : `www.${host}`;
	if (await verifiesFor(twinHost)) return {
		reason: "wrong_domain",
		host,
		signedHost: twinHost
	};
	return {
		reason: "invalid",
		host
	};
}
/** The bytes of a `sig1=:<base64>:` value, or null if it isn't one. */
function decodeSignature(signature) {
	const base64 = /^\w+=:([A-Za-z0-9+/]+={0,2}):$/.exec(signature)?.[1];
	if (!base64) return null;
	try {
		const bytes = Uint8Array.from(atob(base64), (char) => char.charCodeAt(0));
		return bytes.length === 64 ? bytes : null;
	} catch {
		return null;
	}
}
async function importShopifyKey(keyId) {
	try {
		const response = await fetch(SHOPIFY_KEY_DIRECTORY_URL, { signal: AbortSignal.timeout(5e3) });
		const { kid, x } = directoryKeySchema.parse(await response.json());
		if (kid !== keyId) return null;
		return await crypto.subtle.importKey("jwk", {
			kty: "OKP",
			crv: "Ed25519",
			x
		}, "Ed25519", false, ["verify"]);
	} catch (error) {
		console.warn("Skipped the Shopify signature check:", error);
		return null;
	}
}
//#endregion
//#region src/server/features/audit/services/CrawlerCredentialService.ts
async function readEncryptionKey() {
	const secret = (await getOptionalEnvValue("CRAWLER_ACCESS_SECRET"))?.trim();
	return secret && secret.length >= 32 ? secret : null;
}
/**
* Whether crawler access can be saved and replayed here: the optional
* CRAWLER_ACCESS_SECRET is set. The crawler-access form asks before it
* offers to save a signature.
*/
async function hasEncryptionKey() {
	return await readEncryptionKey() !== null;
}
async function getEncryptionKey() {
	const secret = await readEncryptionKey();
	if (!secret) throw new AppError("AUTH_CONFIG_MISSING", `Set CRAWLER_ACCESS_SECRET to at least 32 characters to store crawler access signatures. It encrypts them.`);
	return secret;
}
function toSummary(row) {
	return {
		id: row.id,
		projectId: row.projectId,
		host: row.host,
		provider: row.provider,
		createdAt: row.createdAt,
		expiresAt: row.expiresAt
	};
}
async function listCrawlerCredentials(organizationId) {
	return (await CrawlerCredentialRepository.listForOrganization(organizationId)).map(toSummary);
}
/**
* A signature Shopify would ignore on this host comes back as a problem to
* show next to the form, instead of being stored and failing as 429s.
*/
async function saveCrawlerCredential(input) {
	const key = await getEncryptionKey();
	const problem = await checkShopifySignature({
		host: input.host,
		signatureInput: input.signatureInput,
		signature: input.signature
	});
	if (problem) return { problem };
	await CrawlerCredentialRepository.upsert({
		id: crypto.randomUUID(),
		projectId: input.projectId,
		host: input.host,
		provider: "shopify",
		signatureInput: await symmetricEncrypt({
			key,
			data: input.signatureInput
		}),
		signature: await symmetricEncrypt({
			key,
			data: input.signature
		}),
		expiresAt: parseSignatureExpiry(input.signatureInput),
		createdByUserId: input.userId
	});
	const saved = (await CrawlerCredentialRepository.listForOrganization(input.organizationId)).find((row) => row.projectId === input.projectId && row.host === input.host);
	if (!saved) throw new AppError("INTERNAL_ERROR");
	return { credential: toSummary(saved) };
}
async function deleteCrawlerCredential(input) {
	await CrawlerCredentialRepository.remove(input.organizationId, input.id);
}
/**
* The credential the audit crawler should replay for this host, if any. An
* expired one is skipped: Shopify rejects it, and the report names the expiry.
*/
async function resolveCrawlerAccess(organizationId, projectId, host) {
	const row = (await CrawlerCredentialRepository.findForOrganizationAndHost(organizationId, projectId, host)).find((candidate) => !isCrawlerAccessExpired(candidate.expiresAt));
	if (!row) return null;
	return {
		id: row.id,
		sealed: {
			host: row.host,
			signatureInput: row.signatureInput,
			signature: row.signature,
			expiresAt: row.expiresAt
		}
	};
}
/** Decrypts in memory only. The result must never be persisted or logged. */
async function openCrawlerAccess(sealed) {
	if (!sealed) return null;
	const key = await getEncryptionKey();
	try {
		return {
			host: sealed.host,
			expiresAt: sealed.expiresAt,
			headers: shopifyCrawlerHeaders(await symmetricDecrypt({
				key,
				data: sealed.signatureInput
			}), await symmetricDecrypt({
				key,
				data: sealed.signature
			}))
		};
	} catch {
		console.warn(`Could not decrypt crawler access for ${sealed.host}`);
		return null;
	}
}
var CrawlerCredentialService = {
	hasEncryptionKey,
	listCrawlerCredentials,
	saveCrawlerCredential,
	deleteCrawlerCredential,
	resolveCrawlerAccess,
	openCrawlerAccess
};
//#endregion
//#region src/server/lib/audit/audit-errors.ts
var ERROR_DETAIL_MAX_CHARS = 500;
/**
* Classify an error (thrown in the workflow, or read back from a dead
* Workflows instance) into an AuditErrorCode. Matches the exact failure
* messages observed in production instances.
*/
function classifyAuditError(error) {
	const message = error instanceof Error ? error.message : typeof error === "string" ? error : String(error);
	return {
		errorCode: classifyMessage(message),
		errorDetail: message.slice(0, ERROR_DETAIL_MAX_CHARS)
	};
}
function classifyMessage(message) {
	if (message.includes("exceeded memory limit")) return "oom";
	if (message.includes("exceeded CPU time limit")) return "cpu_limit";
	if (message.includes("WorkflowTimeoutError") || message.includes("Execution timed out")) return "step_timeout";
	if (message.includes("output is too large")) return "step_output_too_large";
	if (message.includes("WorkflowInternalError")) return "workflow_internal";
	if (message.startsWith("Failed query:") || message.includes("D1_ERROR") || message.includes("Postgres database accessed outside a request scope")) return "db_error";
	return "unknown";
}
//#endregion
//#region src/server/billing/autumn.ts
var autumnPromise;
function loadAutumn() {
	return autumnPromise ??= import("./assets/sdk-CZDW7yqk.js").then(({ Autumn }) => new Autumn({
		secretKey: () => getRequiredEnvValue("AUTUMN_SECRET_KEY"),
		timeoutMs: 1e4,
		retryConfig: {
			strategy: "backoff",
			backoff: {
				initialInterval: 250,
				maxInterval: 1e3,
				exponent: 1.5,
				maxElapsedTime: 2500
			},
			retryConnectionErrors: true
		}
	}));
}
/** Shape-preserving lazy facade over the SDK client: call sites keep the
*  plain `autumn.check(...)` form. Covers only the methods we use \u2014 add a
*  line here when adopting a new one. */
var autumn = {
	check: (...args) => loadAutumn().then((client) => client.check(...args)),
	track: (...args) => loadAutumn().then((client) => client.track(...args)),
	customers: {
		getOrCreate: (...args) => loadAutumn().then((client) => client.customers.getOrCreate(...args)),
		get: (...args) => loadAutumn().then((client) => client.customers.get(...args)),
		update: (...args) => loadAutumn().then((client) => client.customers.update(...args)),
		delete: (...args) => loadAutumn().then((client) => client.customers.delete(...args))
	},
	events: { aggregate: (...args) => loadAutumn().then((client) => client.events.aggregate(...args)) },
	invoices: { list: (...args) => loadAutumn().then((client) => client.invoices.list(...args)) },
	balances: {
		finalize: (...args) => loadAutumn().then((client) => client.balances.finalize(...args)),
		update: (...args) => loadAutumn().then((client) => client.balances.update(...args))
	},
	billing: {
		attach: (...args) => loadAutumn().then((client) => client.billing.attach(...args)),
		previewAttach: (...args) => loadAutumn().then((client) => client.billing.previewAttach(...args)),
		openCustomerPortal: (...args) => loadAutumn().then((client) => client.billing.openCustomerPortal(...args)),
		update: (...args) => loadAutumn().then((client) => client.billing.update(...args))
	}
};
var AUTUMN_TRACK_RETRY_OPTIONS = {
	retryCodes: ["429"],
	retries: {
		strategy: "backoff",
		backoff: {
			initialInterval: 250,
			maxInterval: 2e3,
			exponent: 1.5,
			maxElapsedTime: 8e3
		},
		retryConnectionErrors: false
	}
};
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/version.mjs
var version = "5.38.6";
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/featureFlagUtils.mjs
var normalizeFlagsResponse = (flagsResponse) => {
	if ("flags" in flagsResponse) {
		const featureFlags = getFlagValuesFromFlags(flagsResponse.flags);
		const featureFlagPayloads = getPayloadsFromFlags(flagsResponse.flags);
		return {
			...flagsResponse,
			featureFlags,
			featureFlagPayloads
		};
	}
	{
		const featureFlags = flagsResponse.featureFlags ?? {};
		const featureFlagPayloads = Object.fromEntries(Object.entries(flagsResponse.featureFlagPayloads || {}).map(([k, v]) => [k, parsePayload(v)]));
		const flags = Object.fromEntries(Object.entries(featureFlags).map(([key, value]) => [key, getFlagDetailFromFlagAndPayload(key, value, featureFlagPayloads[key])]));
		return {
			...flagsResponse,
			featureFlags,
			featureFlagPayloads,
			flags
		};
	}
};
function getFlagDetailFromFlagAndPayload(key, value, payload) {
	return {
		key,
		enabled: "string" == typeof value ? true : value,
		variant: "string" == typeof value ? value : void 0,
		reason: void 0,
		metadata: {
			id: void 0,
			version: void 0,
			payload: payload ? JSON.stringify(payload) : void 0,
			description: void 0
		}
	};
}
var getFlagValuesFromFlags = (flags) => Object.fromEntries(Object.entries(flags ?? {}).map(([key, detail]) => [key, getFeatureFlagValue(detail)]).filter(([, value]) => void 0 !== value));
var getPayloadsFromFlags = (flags) => {
	const safeFlags = flags ?? {};
	return Object.fromEntries(Object.keys(safeFlags).filter((flag) => {
		const details = safeFlags[flag];
		return details.enabled && details.metadata && void 0 !== details.metadata.payload;
	}).map((flag) => {
		const payload = safeFlags[flag].metadata?.payload;
		return [flag, payload ? parsePayload(payload) : void 0];
	}));
};
var getFeatureFlagValue = (detail) => void 0 === detail ? void 0 : detail.variant ?? detail.enabled;
var parsePayload = (response) => {
	if ("string" != typeof response) return response;
	try {
		return JSON.parse(response);
	} catch {
		return response;
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/types.mjs
var types_PostHogPersistedProperty = /*#__PURE__*/ function(PostHogPersistedProperty) {
	PostHogPersistedProperty["AnonymousId"] = "anonymous_id";
	PostHogPersistedProperty["DistinctId"] = "distinct_id";
	PostHogPersistedProperty["Props"] = "props";
	PostHogPersistedProperty["EnablePersonProcessing"] = "enable_person_processing";
	PostHogPersistedProperty["PersonMode"] = "person_mode";
	PostHogPersistedProperty["FeatureFlagDetails"] = "feature_flag_details";
	PostHogPersistedProperty["FeatureFlags"] = "feature_flags";
	PostHogPersistedProperty["FeatureFlagPayloads"] = "feature_flag_payloads";
	PostHogPersistedProperty["BootstrapFeatureFlagDetails"] = "bootstrap_feature_flag_details";
	PostHogPersistedProperty["BootstrapFeatureFlags"] = "bootstrap_feature_flags";
	PostHogPersistedProperty["BootstrapFeatureFlagPayloads"] = "bootstrap_feature_flag_payloads";
	PostHogPersistedProperty["OverrideFeatureFlags"] = "override_feature_flags";
	PostHogPersistedProperty["Queue"] = "queue";
	PostHogPersistedProperty["LogsQueue"] = "logs_queue";
	PostHogPersistedProperty["OptedOut"] = "opted_out";
	PostHogPersistedProperty["SessionId"] = "session_id";
	PostHogPersistedProperty["SessionStartTimestamp"] = "session_start_timestamp";
	PostHogPersistedProperty["SessionLastTimestamp"] = "session_timestamp";
	PostHogPersistedProperty["PersonProperties"] = "person_properties";
	PostHogPersistedProperty["GroupProperties"] = "group_properties";
	PostHogPersistedProperty["InstalledAppBuild"] = "installed_app_build";
	PostHogPersistedProperty["InstalledAppVersion"] = "installed_app_version";
	PostHogPersistedProperty["SessionReplay"] = "session_replay";
	PostHogPersistedProperty["SessionReplayEventTriggerActivatedSession"] = "session_replay_event_trigger_activated_session";
	PostHogPersistedProperty["SurveyLastSeenDate"] = "survey_last_seen_date";
	PostHogPersistedProperty["SurveysSeen"] = "surveys_seen";
	PostHogPersistedProperty["Surveys"] = "surveys";
	PostHogPersistedProperty["RemoteConfig"] = "remote_config";
	PostHogPersistedProperty["FlagsEndpointWasHit"] = "flags_endpoint_was_hit";
	PostHogPersistedProperty["DeviceId"] = "device_id";
	return PostHogPersistedProperty;
}({});
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/gzip.mjs
function isGzipSupported() {
	return "CompressionStream" in globalThis && "TextEncoder" in globalThis && "Response" in globalThis && "function" == typeof Response.prototype.blob;
}
var NATIVE_GZIP_VALIDATION_ERROR = "NativeGzipValidationError";
var GZIP_MAGIC_FIRST_BYTE = 31;
var GZIP_MAGIC_SECOND_BYTE = 139;
var GZIP_DEFLATE_METHOD = 8;
var hasGzipMagic = (bytes) => bytes.length >= 2 && bytes[0] === GZIP_MAGIC_FIRST_BYTE && bytes[1] === GZIP_MAGIC_SECOND_BYTE;
var crc32Table;
var getCrc32Table = () => {
	if (crc32Table) return crc32Table;
	crc32Table = [];
	for (let i = 0; i < 256; i++) {
		let crc = i;
		for (let j = 0; j < 8; j++) crc = 1 & crc ? 3988292384 ^ crc >>> 1 : crc >>> 1;
		crc32Table[i] = crc >>> 0;
	}
	return crc32Table;
};
var crc32 = (bytes) => {
	const table = getCrc32Table();
	let crc = 4294967295;
	for (let i = 0; i < bytes.length; i++) crc = table[(crc ^ bytes[i]) & 255] ^ crc >>> 8;
	return (4294967295 ^ crc) >>> 0;
};
var throwNativeGzipValidationError = (reason) => {
	const error = /* @__PURE__ */ new Error(`Native gzip produced invalid output: ${reason}`);
	error.name = NATIVE_GZIP_VALIDATION_ERROR;
	throw error;
};
var validateNativeGzip = async (compressed, inputBytes) => {
	if (compressed.size < 18) throwNativeGzipValidationError("too-short");
	const header = new Uint8Array(await compressed.slice(0, 10).arrayBuffer());
	if (!hasGzipMagic(header) || header[2] !== GZIP_DEFLATE_METHOD) throwNativeGzipValidationError("invalid-header");
	const trailer = new DataView(await compressed.slice(compressed.size - 8).arrayBuffer());
	if (trailer.getUint32(0, true) !== crc32(inputBytes)) throwNativeGzipValidationError("invalid-crc");
	const inputSize = inputBytes.length >>> 0;
	if (trailer.getUint32(4, true) !== inputSize) throwNativeGzipValidationError("invalid-size");
};
async function gzipCompress(input, isDebug = true, options) {
	try {
		const inputBytes = new TextEncoder().encode(input);
		const compressedStream = new CompressionStream("gzip");
		const writer = compressedStream.writable.getWriter();
		const writePromise = writer.write(inputBytes).then(() => writer.close()).catch(async (err) => {
			try {
				await writer.abort(err);
			} catch {}
			throw err;
		});
		const responsePromise = new Response(compressedStream.readable).blob();
		const [compressed] = await Promise.all([responsePromise, writePromise]);
		await validateNativeGzip(compressed, inputBytes);
		return compressed;
	} catch (error) {
		if (options?.rethrow) throw error;
		if (isDebug) console.error("Failed to gzip compress data", error);
		return null;
	}
}
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/utils/bot-detection.mjs
var DEFAULT_BLOCKED_UA_STRS = [
	"amazonbot",
	"amazonproductbot",
	"app.hypefactors.com",
	"applebot",
	"archive.org_bot",
	"awariobot",
	"backlinksextendedbot",
	"baiduspider",
	"bingbot",
	"bingpreview",
	"chrome-lighthouse",
	"dataforseobot",
	"deepscan",
	"duckduckbot",
	"facebookexternal",
	"facebookcatalog",
	"http://yandex.com/bots",
	"hubspot",
	"ia_archiver",
	"leikibot",
	"linkedinbot",
	"meta-externalagent",
	"mj12bot",
	"msnbot",
	"nessus",
	"petalbot",
	"pinterest",
	"prerender",
	"rogerbot",
	"screaming frog",
	"sebot-wa",
	"sitebulb",
	"slackbot",
	"slurp",
	"trendictionbot",
	"turnitin",
	"twitterbot",
	"vercel-screenshot",
	"vercelbot",
	"yahoo! slurp",
	"yandexbot",
	"zoombot",
	"bot.htm",
	"bot.php",
	"(bot;",
	"bot/",
	"crawler",
	"ahrefsbot",
	"ahrefssiteaudit",
	"semrushbot",
	"siteauditbot",
	"splitsignalbot",
	"gptbot",
	"oai-searchbot",
	"chatgpt-user",
	"perplexitybot",
	"better uptime bot",
	"sentryuptimebot",
	"uptimerobot",
	"headlesschrome",
	"cypress",
	"google-hoteladsverifier",
	"adsbot-google",
	"apis-google",
	"duplexweb-google",
	"feedfetcher-google",
	"google favicon",
	"google web preview",
	"google-read-aloud",
	"googlebot",
	"googleother",
	"google-cloudvertexbot",
	"googleweblight",
	"mediapartners-google",
	"storebot-google",
	"google-inspectiontool",
	"bytespider"
];
var isBlockedUA = function(ua, customBlockedUserAgents = []) {
	if (!ua) return false;
	const uaLower = ua.toLowerCase();
	return DEFAULT_BLOCKED_UA_STRS.concat(customBlockedUserAgents).some((blockedUA) => {
		const blockedUaLower = blockedUA.toLowerCase();
		return -1 !== uaLower.indexOf(blockedUaLower);
	});
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/utils/type-utils.mjs
var nativeIsArray = Array.isArray;
var ObjProto = Object.prototype;
ObjProto.hasOwnProperty;
var type_utils_toString = ObjProto.toString;
var isArray = nativeIsArray || function(obj) {
	return "[object Array]" === type_utils_toString.call(obj);
};
var isObject = (x) => x === Object(x) && !isArray(x);
var isUndefined = (x) => void 0 === x;
var isString = (x) => "[object String]" == type_utils_toString.call(x);
var isEmptyString = (x) => isString(x) && 0 === x.trim().length;
var isNumber = (x) => "[object Number]" == type_utils_toString.call(x) && x === x;
var isPlainError = (x) => x instanceof Error;
function isPrimitive(value) {
	return null === value || "object" != typeof value;
}
function isBuiltin(candidate, className) {
	return Object.prototype.toString.call(candidate) === `[object ${className}]`;
}
function isEvent(candidate) {
	return "undefined" != typeof Event && isInstanceOf(candidate, Event);
}
function isPlainObject(candidate) {
	return isBuiltin(candidate, "Object");
}
function isInstanceOf(candidate, base) {
	try {
		return candidate instanceof base;
	} catch {
		return false;
	}
}
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/utils/number-utils.mjs
function clampToRange(value, min, max, logger, fallbackValue) {
	if (min > max) {
		logger.warn("min cannot be greater than max.");
		min = max;
	}
	if (isNumber(value)) if (value > max) {
		logger.warn(" cannot be  greater than max: " + max + ". Using max value instead.");
		return max;
	} else {
		if (!(value < min)) return value;
		logger.warn(" cannot be less than min: " + min + ". Using min value instead.");
		return min;
	}
	logger.warn(" must be a number. using max or fallback. max: " + max + ", fallback: " + fallbackValue);
	return clampToRange(fallbackValue || max, min, max, logger);
}
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/utils/bucketed-rate-limiter.mjs
var ONE_DAY_IN_MS = 864e5;
var BucketedRateLimiter = class {
	constructor(options) {
		this._buckets = {};
		this._onBucketRateLimited = options._onBucketRateLimited;
		this._bucketSize = clampToRange(options.bucketSize, 0, 100, options._logger);
		this._refillRate = clampToRange(options.refillRate, 0, this._bucketSize, options._logger);
		this._refillInterval = clampToRange(options.refillInterval, 0, ONE_DAY_IN_MS, options._logger);
	}
	_applyRefill(bucket, now) {
		const elapsedMs = now - bucket.lastAccess;
		const refillIntervals = Math.floor(elapsedMs / this._refillInterval);
		if (refillIntervals > 0) {
			const tokensToAdd = refillIntervals * this._refillRate;
			bucket.tokens = Math.min(bucket.tokens + tokensToAdd, this._bucketSize);
			bucket.lastAccess = bucket.lastAccess + refillIntervals * this._refillInterval;
		}
	}
	consumeRateLimit(key) {
		const now = Date.now();
		const keyStr = String(key);
		let bucket = this._buckets[keyStr];
		if (bucket) this._applyRefill(bucket, now);
		else {
			bucket = {
				tokens: this._bucketSize,
				lastAccess: now
			};
			this._buckets[keyStr] = bucket;
		}
		if (0 === bucket.tokens) return true;
		bucket.tokens--;
		if (0 === bucket.tokens) this._onBucketRateLimited?.(key);
		return 0 === bucket.tokens;
	}
	stop() {
		this._buckets = {};
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/vendor/uuidv7.mjs
/*! For license information please see uuidv7.mjs.LICENSE.txt */
/**
* uuidv7: An experimental implementation of the proposed UUID Version 7
*
* @license Apache-2.0
* @copyright 2021-2023 LiosK
* @packageDocumentation
*/ var DIGITS = "0123456789abcdef";
var UUID = class UUID {
	constructor(bytes) {
		this.bytes = bytes;
	}
	static ofInner(bytes) {
		if (16 === bytes.length) return new UUID(bytes);
		throw new TypeError("not 128-bit length");
	}
	static fromFieldsV7(unixTsMs, randA, randBHi, randBLo) {
		if (!Number.isInteger(unixTsMs) || !Number.isInteger(randA) || !Number.isInteger(randBHi) || !Number.isInteger(randBLo) || unixTsMs < 0 || randA < 0 || randBHi < 0 || randBLo < 0 || unixTsMs > 0xffffffffffff || randA > 4095 || randBHi > 1073741823 || randBLo > 4294967295) throw new RangeError("invalid field value");
		const bytes = /* @__PURE__ */ new Uint8Array(16);
		bytes[0] = unixTsMs / 2 ** 40;
		bytes[1] = unixTsMs / 2 ** 32;
		bytes[2] = unixTsMs / 2 ** 24;
		bytes[3] = unixTsMs / 2 ** 16;
		bytes[4] = unixTsMs / 256;
		bytes[5] = unixTsMs;
		bytes[6] = 112 | randA >>> 8;
		bytes[7] = randA;
		bytes[8] = 128 | randBHi >>> 24;
		bytes[9] = randBHi >>> 16;
		bytes[10] = randBHi >>> 8;
		bytes[11] = randBHi;
		bytes[12] = randBLo >>> 24;
		bytes[13] = randBLo >>> 16;
		bytes[14] = randBLo >>> 8;
		bytes[15] = randBLo;
		return new UUID(bytes);
	}
	static parse(uuid) {
		let hex;
		switch (uuid.length) {
			case 32:
				hex = /^[0-9a-f]{32}$/i.exec(uuid)?.[0];
				break;
			case 36:
				hex = /^([0-9a-f]{8})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{12})$/i.exec(uuid)?.slice(1, 6).join("");
				break;
			case 38:
				hex = /^\{([0-9a-f]{8})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{12})\}$/i.exec(uuid)?.slice(1, 6).join("");
				break;
			case 45: hex = /^urn:uuid:([0-9a-f]{8})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{4})-([0-9a-f]{12})$/i.exec(uuid)?.slice(1, 6).join("");
		}
		if (hex) {
			const inner = /* @__PURE__ */ new Uint8Array(16);
			for (let i = 0; i < 16; i += 4) {
				const n = parseInt(hex.substring(2 * i, 2 * i + 8), 16);
				inner[i + 0] = n >>> 24;
				inner[i + 1] = n >>> 16;
				inner[i + 2] = n >>> 8;
				inner[i + 3] = n;
			}
			return new UUID(inner);
		}
		throw new SyntaxError("could not parse UUID string");
	}
	toString() {
		let text = "";
		for (let i = 0; i < this.bytes.length; i++) {
			text += DIGITS.charAt(this.bytes[i] >>> 4);
			text += DIGITS.charAt(15 & this.bytes[i]);
			if (3 === i || 5 === i || 7 === i || 9 === i) text += "-";
		}
		return text;
	}
	toHex() {
		let text = "";
		for (let i = 0; i < this.bytes.length; i++) {
			text += DIGITS.charAt(this.bytes[i] >>> 4);
			text += DIGITS.charAt(15 & this.bytes[i]);
		}
		return text;
	}
	toJSON() {
		return this.toString();
	}
	getVariant() {
		const n = this.bytes[8] >>> 4;
		if (n < 0) throw new Error("unreachable");
		if (n <= 7) return this.bytes.every((e) => 0 === e) ? "NIL" : "VAR_0";
		if (n <= 11) return "VAR_10";
		if (n <= 13) return "VAR_110";
		if (n <= 15) return this.bytes.every((e) => 255 === e) ? "MAX" : "VAR_RESERVED";
		else throw new Error("unreachable");
	}
	getVersion() {
		return "VAR_10" === this.getVariant() ? this.bytes[6] >>> 4 : void 0;
	}
	clone() {
		return new UUID(this.bytes.slice(0));
	}
	equals(other) {
		return 0 === this.compareTo(other);
	}
	compareTo(other) {
		for (let i = 0; i < 16; i++) {
			const diff = this.bytes[i] - other.bytes[i];
			if (0 !== diff) return Math.sign(diff);
		}
		return 0;
	}
};
var V7Generator = class {
	constructor(randomNumberGenerator) {
		this.timestamp = 0;
		this.counter = 0;
		this.random = randomNumberGenerator ?? getDefaultRandom();
	}
	generate() {
		return this.generateOrResetCore(Date.now(), 1e4);
	}
	generateOrAbort() {
		return this.generateOrAbortCore(Date.now(), 1e4);
	}
	generateOrResetCore(unixTsMs, rollbackAllowance) {
		let value = this.generateOrAbortCore(unixTsMs, rollbackAllowance);
		if (void 0 === value) {
			this.timestamp = 0;
			value = this.generateOrAbortCore(unixTsMs, rollbackAllowance);
		}
		return value;
	}
	generateOrAbortCore(unixTsMs, rollbackAllowance) {
		const MAX_COUNTER = 4398046511103;
		if (!Number.isInteger(unixTsMs) || unixTsMs < 1 || unixTsMs > 0xffffffffffff) throw new RangeError("`unixTsMs` must be a 48-bit positive integer");
		if (rollbackAllowance < 0 || rollbackAllowance > 0xffffffffffff) throw new RangeError("`rollbackAllowance` out of reasonable range");
		if (unixTsMs > this.timestamp) {
			this.timestamp = unixTsMs;
			this.resetCounter();
		} else {
			if (!(unixTsMs + rollbackAllowance >= this.timestamp)) return;
			this.counter++;
			if (this.counter > MAX_COUNTER) {
				this.timestamp++;
				this.resetCounter();
			}
		}
		return UUID.fromFieldsV7(this.timestamp, Math.trunc(this.counter / 2 ** 30), this.counter & 2 ** 30 - 1, this.random.nextUint32());
	}
	resetCounter() {
		this.counter = 1024 * this.random.nextUint32() + (1023 & this.random.nextUint32());
	}
	generateV4() {
		const bytes = new Uint8Array(Uint32Array.of(this.random.nextUint32(), this.random.nextUint32(), this.random.nextUint32(), this.random.nextUint32()).buffer);
		bytes[6] = 64 | bytes[6] >>> 4;
		bytes[8] = 128 | bytes[8] >>> 2;
		return UUID.ofInner(bytes);
	}
};
var getDefaultRandom = () => ({ nextUint32: () => 65536 * Math.trunc(65536 * Math.random()) + Math.trunc(65536 * Math.random()) });
var defaultGenerator;
var uuidv7 = () => uuidv7obj().toString();
var uuidv7obj = () => (defaultGenerator || (defaultGenerator = new V7Generator())).generate();
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/utils/promise-queue.mjs
var PromiseQueue = class {
	add(promise) {
		const promiseUUID = uuidv7();
		this.promiseByIds[promiseUUID] = promise;
		promise.catch(() => {}).finally(() => {
			delete this.promiseByIds[promiseUUID];
		});
		return promise;
	}
	async join() {
		let promises = Object.values(this.promiseByIds);
		let length = promises.length;
		while (length > 0) {
			await Promise.all(promises);
			promises = Object.values(this.promiseByIds);
			length = promises.length;
		}
	}
	get length() {
		return Object.keys(this.promiseByIds).length;
	}
	constructor() {
		this.promiseByIds = {};
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/utils/logger.mjs
function createConsole(consoleLike = console) {
	return {
		log: consoleLike.log.bind(consoleLike),
		warn: consoleLike.warn.bind(consoleLike),
		error: consoleLike.error.bind(consoleLike),
		debug: consoleLike.debug.bind(consoleLike)
	};
}
var _createLogger = (prefix, maybeCall, consoleLike) => {
	function _log(level, ...args) {
		maybeCall(() => {
			const consoleMethod = consoleLike[level];
			consoleMethod(prefix, ...args);
		});
	}
	return {
		debug: (...args) => {
			_log("debug", ...args);
		},
		info: (...args) => {
			_log("log", ...args);
		},
		warn: (...args) => {
			_log("warn", ...args);
		},
		error: (...args) => {
			_log("error", ...args);
		},
		critical: (...args) => {
			consoleLike["error"](prefix, ...args);
		},
		createLogger: (additionalPrefix) => _createLogger(`${prefix} ${additionalPrefix}`, maybeCall, consoleLike)
	};
};
var passThrough = (fn) => fn();
function createLogger(prefix, maybeCall = passThrough) {
	return _createLogger(prefix, maybeCall, createConsole());
}
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/utils/user-agent-utils.mjs
var MOBILE = "Mobile";
var TABLET = "Tablet";
var NINTENDO = "Nintendo";
var PLAYSTATION = "PlayStation";
var XBOX = "Xbox";
var WINDOWS = "Windows";
"" + MOBILE.toLowerCase();
"" + TABLET.toLowerCase();
new RegExp(XBOX, "i");
new RegExp(NINTENDO, "i"), new RegExp(PLAYSTATION, "i"), new RegExp(WINDOWS, "i");
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/utils/index.mjs
var STRING_FORMAT = "utf8";
var UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function isValidUUID(value) {
	return "string" == typeof value && UUID_REGEX.test(value);
}
function getEventUuid(uuid, generateUuid) {
	return isValidUUID(uuid) ? uuid : generateUuid();
}
function removeTrailingSlash(url) {
	return url?.replace(/\/+$/, "");
}
async function retriable(fn, props) {
	let lastError = null;
	for (let i = 0; i < props.retryCount + 1; i++) {
		if (i > 0) await new Promise((r) => setTimeout(r, props.retryDelay));
		try {
			return await fn();
		} catch (e) {
			lastError = e;
			if (!props.retryCheck(e)) throw e;
		}
	}
	throw lastError;
}
function currentISOTime() {
	return (/* @__PURE__ */ new Date()).toISOString();
}
function safeSetTimeout(fn, timeout) {
	const t = setTimeout(fn, timeout);
	t?.unref && t?.unref();
	return t;
}
var isError = (x) => x instanceof Error;
function allSettled(promises) {
	return Promise.all(promises.map((p) => (p ?? Promise.resolve()).then((value) => ({
		status: "fulfilled",
		value
	}), (reason) => ({
		status: "rejected",
		reason
	}))));
}
({
	trace: {
		text: "TRACE",
		number: 1
	},
	debug: {
		text: "DEBUG",
		number: 5
	},
	info: {
		text: "INFO",
		number: 9
	},
	warn: {
		text: "WARN",
		number: 13
	},
	error: {
		text: "ERROR",
		number: 17
	},
	fatal: {
		text: "FATAL",
		number: 21
	}
}).info;
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/eventemitter.mjs
var SimpleEventEmitter = class {
	constructor() {
		this.events = {};
		this.events = {};
	}
	on(event, listener) {
		if (!this.events[event]) this.events[event] = [];
		this.events[event].push(listener);
		return () => {
			this.events[event] = this.events[event].filter((x) => x !== listener);
		};
	}
	emit(event, payload) {
		for (const listener of this.events[event] || []) listener(payload);
		for (const listener of this.events["*"] || []) listener(event, payload);
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/chunk-ids.mjs
var parsedStackResults;
var lastKeysCount;
var cachedFilenameChunkIds;
function getFilenameToChunkIdMap(stackParser) {
	const chunkIdMap = globalThis._posthogChunkIds;
	if (!chunkIdMap) return;
	const chunkIdKeys = Object.keys(chunkIdMap);
	if (cachedFilenameChunkIds && chunkIdKeys.length === lastKeysCount) return cachedFilenameChunkIds;
	lastKeysCount = chunkIdKeys.length;
	cachedFilenameChunkIds = chunkIdKeys.reduce((acc, stackKey) => {
		if (!parsedStackResults) parsedStackResults = {};
		const result = parsedStackResults[stackKey];
		if (result) acc[result[0]] = result[1];
		else {
			const parsedStack = stackParser(stackKey);
			for (let i = parsedStack.length - 1; i >= 0; i--) {
				const filename = parsedStack[i]?.filename;
				const chunkId = chunkIdMap[stackKey];
				if (filename && chunkId) {
					acc[filename] = chunkId;
					parsedStackResults[stackKey] = [filename, chunkId];
					break;
				}
			}
		}
		return acc;
	}, {});
	return cachedFilenameChunkIds;
}
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/error-properties-builder.mjs
var MAX_CAUSE_RECURSION = 4;
var ErrorPropertiesBuilder = class {
	constructor(coercers, stackParser, modifiers = []) {
		this.coercers = coercers;
		this.stackParser = stackParser;
		this.modifiers = modifiers;
	}
	buildFromUnknown(input, hint = {}) {
		const mechanism = hint && hint.mechanism || {
			handled: true,
			type: "generic"
		};
		const exceptionWithCause = this.buildCoercingContext(mechanism, hint, 0).apply(input);
		const parsingContext = this.buildParsingContext(hint);
		const exceptionWithStack = this.parseStacktrace(exceptionWithCause, parsingContext);
		return {
			$exception_list: this.convertToExceptionList(exceptionWithStack, mechanism),
			$exception_level: "error"
		};
	}
	async modifyFrames(exceptionList) {
		for (const exc of exceptionList) if (exc.stacktrace && exc.stacktrace.frames && isArray(exc.stacktrace.frames)) exc.stacktrace.frames = await this.applyModifiers(exc.stacktrace.frames);
		return exceptionList;
	}
	coerceFallback(ctx) {
		return {
			type: "Error",
			value: "Unknown error",
			stack: ctx.syntheticException?.stack,
			synthetic: true
		};
	}
	parseStacktrace(err, ctx) {
		let cause;
		if (null != err.cause) cause = this.parseStacktrace(err.cause, ctx);
		let stack;
		if ("" != err.stack && null != err.stack) stack = this.applyChunkIds(this.stackParser(err.stack, err.synthetic ? ctx.skipFirstLines : 0), ctx.chunkIdMap);
		return {
			...err,
			cause,
			stack
		};
	}
	applyChunkIds(frames, chunkIdMap) {
		return frames.map((frame) => {
			if (frame.filename && chunkIdMap) frame.chunk_id = chunkIdMap[frame.filename];
			return frame;
		});
	}
	applyCoercers(input, ctx) {
		for (const adapter of this.coercers) if (adapter.match(input)) return adapter.coerce(input, ctx);
		return this.coerceFallback(ctx);
	}
	async applyModifiers(frames) {
		let newFrames = frames;
		for (const modifier of this.modifiers) newFrames = await modifier(newFrames);
		return newFrames;
	}
	convertToExceptionList(exceptionWithStack, mechanism) {
		const currentException = {
			type: exceptionWithStack.type,
			value: exceptionWithStack.value,
			mechanism: {
				type: mechanism.type ?? "generic",
				handled: mechanism.handled ?? true,
				synthetic: exceptionWithStack.synthetic ?? false
			}
		};
		if (exceptionWithStack.stack) currentException.stacktrace = {
			type: "raw",
			frames: exceptionWithStack.stack
		};
		const exceptionList = [currentException];
		if (null != exceptionWithStack.cause) exceptionList.push(...this.convertToExceptionList(exceptionWithStack.cause, {
			...mechanism,
			handled: true
		}));
		return exceptionList;
	}
	buildParsingContext(hint) {
		return {
			chunkIdMap: getFilenameToChunkIdMap(this.stackParser),
			skipFirstLines: hint.skipFirstLines ?? 1
		};
	}
	buildCoercingContext(mechanism, hint, depth = 0) {
		const coerce = (input, depth) => {
			if (!(depth <= MAX_CAUSE_RECURSION)) return;
			{
				const ctx = this.buildCoercingContext(mechanism, hint, depth);
				return this.applyCoercers(input, ctx);
			}
		};
		return {
			...hint,
			syntheticException: 0 == depth ? hint.syntheticException : void 0,
			mechanism,
			apply: (input) => coerce(input, depth),
			next: (input) => coerce(input, depth + 1)
		};
	}
};
function createFrame(platform, filename, func, lineno, colno) {
	const frame = {
		platform,
		filename,
		function: "<anonymous>" === func ? "?" : func,
		in_app: true
	};
	if (!isUndefined(lineno)) frame.lineno = lineno;
	if (!isUndefined(colno)) frame.colno = colno;
	return frame;
}
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/parsers/safari.mjs
var extractSafariExtensionDetails = (func, filename) => {
	const isSafariExtension = -1 !== func.indexOf("safari-extension");
	const isSafariWebExtension = -1 !== func.indexOf("safari-web-extension");
	return isSafariExtension || isSafariWebExtension ? [-1 !== func.indexOf("@") ? func.split("@")[0] : "?", isSafariExtension ? `safari-extension:${filename}` : `safari-web-extension:${filename}`] : [func, filename];
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/parsers/chrome.mjs
var chromeRegexNoFnName = /^\s*at (\S+?)(?::(\d+))(?::(\d+))\s*$/i;
var chromeRegex = /^\s*at (?:(.+?\)(?: \[.+\])?|.*?) ?\((?:address at )?)?(?:async )?((?:<anonymous>|[-a-z]+:|.*bundle|\/)?.*?)(?::(\d+))?(?::(\d+))?\)?\s*$/i;
var chromeEvalRegex = /\((\S*)(?::(\d+))(?::(\d+))\)/;
var chromeStackLineParser = (line, platform) => {
	const noFnParts = chromeRegexNoFnName.exec(line);
	if (noFnParts) {
		const [, filename, line, col] = noFnParts;
		return createFrame(platform, filename, "?", +line, +col);
	}
	const parts = chromeRegex.exec(line);
	if (parts) {
		if (parts[2] && 0 === parts[2].indexOf("eval")) {
			const subMatch = chromeEvalRegex.exec(parts[2]);
			if (subMatch) {
				parts[2] = subMatch[1];
				parts[3] = subMatch[2];
				parts[4] = subMatch[3];
			}
		}
		const [func, filename] = extractSafariExtensionDetails(parts[1] || "?", parts[2]);
		return createFrame(platform, filename, func, parts[3] ? +parts[3] : void 0, parts[4] ? +parts[4] : void 0);
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/parsers/gecko.mjs
var geckoREgex = /^\s*(.*?)(?:\((.*?)\))?(?:^|@)?((?:[-a-z]+)?:\/.*?|\[native code\]|[^@]*(?:bundle|\d+\.js)|\/[\w\-. /=]+)(?::(\d+))?(?::(\d+))?\s*$/i;
var geckoEvalRegex = /(\S+) line (\d+)(?: > eval line \d+)* > eval/i;
var geckoStackLineParser = (line, platform) => {
	const parts = geckoREgex.exec(line);
	if (parts) {
		if (parts[3] && parts[3].indexOf(" > eval") > -1) {
			const subMatch = geckoEvalRegex.exec(parts[3]);
			if (subMatch) {
				parts[1] = parts[1] || "eval";
				parts[3] = subMatch[1];
				parts[4] = subMatch[2];
				parts[5] = "";
			}
		}
		let filename = parts[3];
		let func = parts[1] || "?";
		[func, filename] = extractSafariExtensionDetails(func, filename);
		return createFrame(platform, filename, func, parts[4] ? +parts[4] : void 0, parts[5] ? +parts[5] : void 0);
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/parsers/node.mjs
var FILENAME_MATCH = /^\s*[-]{4,}$/;
var FULL_MATCH = /at (?:async )?(?:(.+?)\s+\()?(?:(.+):(\d+):(\d+)?|([^)]+))\)?/;
var nodeStackLineParser = (line, platform) => {
	const lineMatch = line.match(FULL_MATCH);
	if (lineMatch) {
		let object;
		let method;
		let functionName;
		let typeName;
		let methodName;
		if (lineMatch[1]) {
			functionName = lineMatch[1];
			let methodStart = functionName.lastIndexOf(".");
			if ("." === functionName[methodStart - 1]) methodStart--;
			if (methodStart > 0) {
				object = functionName.slice(0, methodStart);
				method = functionName.slice(methodStart + 1);
				const objectEnd = object.indexOf(".Module");
				if (objectEnd > 0) {
					functionName = functionName.slice(objectEnd + 1);
					object = object.slice(0, objectEnd);
				}
			}
			typeName = void 0;
		}
		if (method) {
			typeName = object;
			methodName = method;
		}
		if ("<anonymous>" === method) {
			methodName = void 0;
			functionName = void 0;
		}
		if (void 0 === functionName) {
			methodName = methodName || "?";
			functionName = typeName ? `${typeName}.${methodName}` : methodName;
		}
		let filename = lineMatch[2]?.startsWith("file://") ? lineMatch[2].slice(7) : lineMatch[2];
		const isNative = "native" === lineMatch[5];
		if (filename?.match(/\/[A-Z]:/)) filename = filename.slice(1);
		if (!filename && lineMatch[5] && !isNative) filename = lineMatch[5];
		return {
			filename: filename ? decodeURI(filename) : void 0,
			module: void 0,
			function: functionName,
			lineno: _parseIntOrUndefined(lineMatch[3]),
			colno: _parseIntOrUndefined(lineMatch[4]),
			in_app: filenameIsInApp(filename || "", isNative),
			platform
		};
	}
	if (line.match(FILENAME_MATCH)) return {
		filename: line,
		platform
	};
};
function filenameIsInApp(filename, isNative = false) {
	return !(isNative || filename && !filename.startsWith("/") && !filename.match(/^[A-Z]:/) && !filename.startsWith(".") && !filename.match(/^[a-zA-Z]([a-zA-Z0-9.\-+])*:\/\//)) && void 0 !== filename && !filename.includes("node_modules/");
}
function _parseIntOrUndefined(input) {
	return parseInt(input || "", 10) || void 0;
}
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/parsers/index.mjs
var WEBPACK_ERROR_REGEXP = /\(error: (.*)\)/;
var STACKTRACE_FRAME_LIMIT = 50;
function reverseAndStripFrames(stack) {
	if (!stack.length) return [];
	const localStack = Array.from(stack);
	localStack.reverse();
	return localStack.slice(0, STACKTRACE_FRAME_LIMIT).map((frame) => ({
		...frame,
		filename: frame.filename || getLastStackFrame(localStack).filename,
		function: frame.function || "?"
	}));
}
function getLastStackFrame(arr) {
	return arr[arr.length - 1] || {};
}
function createDefaultStackParser() {
	return createStackParser("web:javascript", chromeStackLineParser, geckoStackLineParser);
}
function createStackParser(platform, ...parsers) {
	return (stack, skipFirstLines = 0) => {
		const frames = [];
		const lines = stack.split("\n");
		for (let i = skipFirstLines; i < lines.length; i++) {
			const line = lines[i];
			if (line.length > 1024) continue;
			const cleanedLine = WEBPACK_ERROR_REGEXP.test(line) ? line.replace(WEBPACK_ERROR_REGEXP, "$1") : line;
			if (!cleanedLine.match(/\S*Error: /)) {
				for (const parser of parsers) {
					const frame = parser(cleanedLine, platform);
					if (frame) {
						frames.push(frame);
						break;
					}
				}
				if (frames.length >= STACKTRACE_FRAME_LIMIT) break;
			}
		}
		return reverseAndStripFrames(frames);
	};
}
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/coercers/error-coercer.mjs
var ErrorCoercer = class {
	match(err) {
		return isPlainError(err);
	}
	coerce(err, ctx) {
		return {
			type: this.getType(err),
			value: this.getMessage(err, ctx),
			stack: this.getStack(err),
			cause: err.cause ? ctx.next(err.cause) : void 0,
			synthetic: false
		};
	}
	getType(err) {
		return err.name || err.constructor.name;
	}
	getMessage(err, _ctx) {
		const message = err.message;
		if (message.error && "string" == typeof message.error.message) return String(message.error.message);
		return String(message);
	}
	getStack(err) {
		return err.stacktrace || err.stack || void 0;
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/coercers/string-coercer.mjs
var ERROR_TYPES_PATTERN = /^(?:[Uu]ncaught (?:exception: )?)?(?:((?:Eval|Internal|Range|Reference|Syntax|Type|URI|)Error): )?(.*)$/i;
var StringCoercer = class {
	match(input) {
		return "string" == typeof input;
	}
	coerce(input, ctx) {
		const [type, value] = this.getInfos(input);
		return {
			type: type ?? "Error",
			value: value ?? input,
			stack: ctx.syntheticException?.stack,
			synthetic: true
		};
	}
	getInfos(candidate) {
		let type = "Error";
		let value = candidate;
		const groups = candidate.match(ERROR_TYPES_PATTERN);
		if (groups) {
			type = groups[1];
			value = groups[2];
		}
		return [type, value];
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/types.mjs
var severityLevels = [
	"fatal",
	"error",
	"warning",
	"log",
	"info",
	"debug"
];
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/coercers/utils.mjs
function extractExceptionKeysForMessage(err, maxLength = 40) {
	const keys = Object.keys(err);
	keys.sort();
	if (!keys.length) return "[object has no keys]";
	for (let i = keys.length; i > 0; i--) {
		const serialized = keys.slice(0, i).join(", ");
		if (!(serialized.length > maxLength)) {
			if (i === keys.length) return serialized;
			return serialized.length <= maxLength ? serialized : `${serialized.slice(0, maxLength)}...`;
		}
	}
	return "";
}
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/coercers/object-coercer.mjs
var ObjectCoercer = class {
	match(candidate) {
		return "object" == typeof candidate && null !== candidate;
	}
	coerce(candidate, ctx) {
		const errorProperty = this.getErrorPropertyFromObject(candidate);
		if (errorProperty) return ctx.apply(errorProperty);
		return {
			type: this.getType(candidate),
			value: this.getValue(candidate),
			stack: ctx.syntheticException?.stack,
			level: this.isSeverityLevel(candidate.level) ? candidate.level : "error",
			synthetic: true
		};
	}
	getType(err) {
		return isEvent(err) ? err.constructor.name : "Error";
	}
	getValue(err) {
		if ("name" in err && "string" == typeof err.name) {
			let message = `'${err.name}' captured as exception`;
			if ("message" in err && "string" == typeof err.message) message += ` with message: '${err.message}'`;
			return message;
		}
		if ("message" in err && "string" == typeof err.message) return err.message;
		const className = this.getObjectClassName(err);
		const keys = extractExceptionKeysForMessage(err);
		return `${className && "Object" !== className ? `'${className}'` : "Object"} captured as exception with keys: ${keys}`;
	}
	isSeverityLevel(x) {
		return isString(x) && !isEmptyString(x) && severityLevels.indexOf(x) >= 0;
	}
	getErrorPropertyFromObject(obj) {
		for (const prop in obj) if (Object.prototype.hasOwnProperty.call(obj, prop)) {
			const value = obj[prop];
			if (isError(value)) return value;
		}
	}
	getObjectClassName(obj) {
		try {
			const prototype = Object.getPrototypeOf(obj);
			return prototype ? prototype.constructor.name : void 0;
		} catch (e) {
			return;
		}
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/coercers/event-coercer.mjs
var EventCoercer = class {
	match(err) {
		return isEvent(err);
	}
	coerce(evt, ctx) {
		const constructorName = evt.constructor.name;
		return {
			type: constructorName,
			value: `${constructorName} captured as exception with keys: ${extractExceptionKeysForMessage(evt)}`,
			stack: ctx.syntheticException?.stack,
			synthetic: true
		};
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/coercers/primitive-coercer.mjs
var PrimitiveCoercer = class {
	match(candidate) {
		return isPrimitive(candidate);
	}
	coerce(value, ctx) {
		return {
			type: "Error",
			value: `Primitive value captured as exception: ${String(value)}`,
			stack: ctx.syntheticException?.stack,
			synthetic: true
		};
	}
};
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/error-tracking/exception-steps.mjs
var EXCEPTION_STEP_INTERNAL_FIELDS = {
	MESSAGE: "$message",
	TIMESTAMP: "$timestamp"
};
EXCEPTION_STEP_INTERNAL_FIELDS.MESSAGE, EXCEPTION_STEP_INTERNAL_FIELDS.TIMESTAMP;
//#endregion
//#region node_modules/.pnpm/@posthog+core@1.38.0/node_modules/@posthog/core/dist/posthog-core-stateless.mjs
var PostHogFetchHttpError = class extends Error {
	constructor(response, reqByteLength) {
		super("HTTP error while fetching PostHog: status=" + response.status + ", reqByteLength=" + reqByteLength), this.response = response, this.reqByteLength = reqByteLength, this.name = "PostHogFetchHttpError";
	}
	get status() {
		return this.response.status;
	}
	get text() {
		return this.response.text();
	}
	get json() {
		return this.response.json();
	}
};
var PostHogFetchNetworkError = class extends Error {
	constructor(error) {
		super("Network error while fetching PostHog", error instanceof Error ? { cause: error } : {}), this.error = error, this.name = "PostHogFetchNetworkError";
	}
};
async function logFlushError(err) {
	if (err instanceof PostHogFetchHttpError) {
		let text = "";
		try {
			text = await err.text;
		} catch {}
		console.error(`Error while flushing PostHog: message=${err.message}, response body=${text}`, err);
	} else console.error("Error while flushing PostHog", err);
	return Promise.resolve();
}
function isPostHogFetchError(err) {
	return "object" == typeof err && (err instanceof PostHogFetchHttpError || isPostHogFetchNetworkError(err));
}
function isPostHogFetchNetworkError(err) {
	return err instanceof PostHogFetchNetworkError;
}
function isPostHogFetchContentTooLargeError(err) {
	return "object" == typeof err && err instanceof PostHogFetchHttpError && 413 === err.status;
}
function isPostHogEventProperties(value) {
	return null !== value && "object" == typeof value && !Array.isArray(value);
}
var PostHogCoreStateless = class {
	getErrorPropertiesBuilder() {
		if (!this._errorPropertiesBuilder) this._errorPropertiesBuilder = this.createErrorPropertiesBuilder();
		return this._errorPropertiesBuilder;
	}
	createErrorPropertiesBuilder() {
		return new ErrorPropertiesBuilder([
			new ErrorCoercer(),
			new ObjectCoercer(),
			new StringCoercer(),
			new PrimitiveCoercer()
		], createDefaultStackParser());
	}
	constructor(apiKey, options = {}) {
		this.flushPromise = null;
		this.shutdownPromise = null;
		this.promiseQueue = new PromiseQueue();
		this._events = new SimpleEventEmitter();
		this._isInitialized = false;
		const normalizedApiKey = "string" == typeof apiKey ? apiKey.trim() : "";
		const normalizedHost = "string" == typeof options.host ? options.host.trim() : "";
		const missingApiKey = !normalizedApiKey;
		this._logger = createLogger("[PostHog]", this.logMsgIfDebug.bind(this));
		if (missingApiKey) this._logger.error("You must pass your PostHog project's api key. The client will be disabled.");
		this.apiKey = normalizedApiKey;
		this.host = removeTrailingSlash(normalizedHost || "https://us.i.posthog.com");
		this.flushAt = options.flushAt ? Math.max(options.flushAt, 1) : 20;
		this.maxBatchSize = Math.max(this.flushAt, options.maxBatchSize ?? 100);
		this.maxQueueSize = Math.max(this.flushAt, options.maxQueueSize ?? 1e3);
		this.flushInterval = options.flushInterval ?? 1e4;
		this.preloadFeatureFlags = options.preloadFeatureFlags ?? true;
		this.defaultOptIn = options.defaultOptIn ?? true;
		this.disableSurveys = options.disableSurveys ?? false;
		this._retryOptions = {
			retryCount: options.fetchRetryCount ?? 3,
			retryDelay: options.fetchRetryDelay ?? 3e3,
			retryCheck: isPostHogFetchError
		};
		this.requestTimeout = options.requestTimeout ?? 1e4;
		this.featureFlagsRequestTimeoutMs = options.featureFlagsRequestTimeoutMs ?? 3e3;
		this.remoteConfigRequestTimeoutMs = options.remoteConfigRequestTimeoutMs ?? 3e3;
		this.disableGeoip = options.disableGeoip ?? true;
		this.disabled = (options.disabled ?? false) || missingApiKey;
		this.historicalMigration = options?.historicalMigration ?? false;
		this._initPromise = Promise.resolve();
		this._isInitialized = true;
		this.evaluationContexts = options?.evaluationContexts ?? options?.evaluationEnvironments;
		if (options?.evaluationEnvironments && !options?.evaluationContexts) this._logger.warn("evaluationEnvironments is deprecated. Use evaluationContexts instead. This property will be removed in a future version.");
		this.disableCompression = !isGzipSupported() || (options?.disableCompression ?? false);
	}
	logMsgIfDebug(fn) {
		if (this.isDebug) fn();
	}
	wrap(fn) {
		if (this.disabled) return void this._logger.warn("The client is disabled");
		if (this._isInitialized) return fn();
		this._initPromise.then(() => fn());
	}
	getCommonEventProperties() {
		return {
			$lib: this.getLibraryId(),
			$lib_version: this.getLibraryVersion()
		};
	}
	get optedOut() {
		return this.getPersistedProperty(types_PostHogPersistedProperty.OptedOut) ?? !this.defaultOptIn;
	}
	async optIn() {
		this.wrap(() => {
			this.setPersistedProperty(types_PostHogPersistedProperty.OptedOut, false);
		});
	}
	async optOut() {
		this.wrap(() => {
			this.setPersistedProperty(types_PostHogPersistedProperty.OptedOut, true);
		});
	}
	on(event, cb) {
		return this._events.on(event, cb);
	}
	debug(enabled = true) {
		this.removeDebugCallback?.();
		if (enabled) {
			const removeDebugCallback = this.on("*", (event, payload) => this._logger.info(event, payload));
			this.removeDebugCallback = () => {
				removeDebugCallback();
				this.removeDebugCallback = void 0;
			};
		}
	}
	get isDebug() {
		return !!this.removeDebugCallback;
	}
	get isDisabled() {
		return this.disabled;
	}
	buildPayload(payload) {
		return {
			distinct_id: payload.distinct_id,
			event: payload.event,
			properties: {
				...payload.properties || {},
				...this.getCommonEventProperties()
			}
		};
	}
	addPendingPromise(promise) {
		return this.promiseQueue.add(promise);
	}
	identifyStateless(distinctId, properties, options) {
		this.wrap(() => {
			const payload = { ...this.buildPayload({
				distinct_id: distinctId,
				event: "$identify",
				properties
			}) };
			this.enqueue("identify", payload, options);
		});
	}
	async identifyStatelessImmediate(distinctId, properties, options) {
		const payload = { ...this.buildPayload({
			distinct_id: distinctId,
			event: "$identify",
			properties
		}) };
		await this.sendImmediate("identify", payload, options);
	}
	captureStateless(distinctId, event, properties, options) {
		this.wrap(() => {
			const payload = this.buildPayload({
				distinct_id: distinctId,
				event,
				properties
			});
			this.enqueue("capture", payload, options);
		});
	}
	async captureStatelessImmediate(distinctId, event, properties, options) {
		const payload = this.buildPayload({
			distinct_id: distinctId,
			event,
			properties
		});
		await this.sendImmediate("capture", payload, options);
	}
	aliasStateless(alias, distinctId, properties, options) {
		this.wrap(() => {
			const payload = this.buildPayload({
				event: "$create_alias",
				distinct_id: distinctId,
				properties: {
					...properties || {},
					distinct_id: distinctId,
					alias
				}
			});
			this.enqueue("alias", payload, options);
		});
	}
	async aliasStatelessImmediate(alias, distinctId, properties, options) {
		const payload = this.buildPayload({
			event: "$create_alias",
			distinct_id: distinctId,
			properties: {
				...properties || {},
				distinct_id: distinctId,
				alias
			}
		});
		await this.sendImmediate("alias", payload, options);
	}
	groupIdentifyStateless(groupType, groupKey, groupProperties, options, distinctId, eventProperties) {
		this.wrap(() => {
			const payload = this.buildPayload({
				distinct_id: distinctId || `$${groupType}_${groupKey}`,
				event: "$groupidentify",
				properties: {
					$group_type: groupType,
					$group_key: groupKey,
					$group_set: groupProperties || {},
					...eventProperties || {}
				}
			});
			this.enqueue("capture", payload, options);
		});
	}
	async getRemoteConfig() {
		await this._initPromise;
		let host = this.host;
		if ("https://us.i.posthog.com" === host) host = "https://us-assets.i.posthog.com";
		else if ("https://eu.i.posthog.com" === host) host = "https://eu-assets.i.posthog.com";
		const url = `${host}/array/${this.apiKey}/config`;
		const fetchOptions = {
			method: "GET",
			headers: {
				...this.getCustomHeaders(),
				"Content-Type": "application/json"
			}
		};
		return this.fetchWithRetry(url, fetchOptions, { retryCount: 0 }, this.remoteConfigRequestTimeoutMs).then((response) => response.json()).catch((error) => {
			this._logger.error("Remote config could not be loaded", error);
			this._events.emit("error", error);
		});
	}
	async getFlags(distinctId, groups = {}, personProperties = {}, groupProperties = {}, extraPayload = {}, fetchConfig = false) {
		await this._initPromise;
		const configParam = fetchConfig ? "&config=true" : "";
		const url = `${this.host}/flags/?v=2${configParam}`;
		const requestData = {
			token: this.apiKey,
			distinct_id: distinctId,
			groups,
			person_properties: personProperties,
			group_properties: groupProperties,
			...extraPayload
		};
		if (personProperties.$device_id) requestData.$device_id = personProperties.$device_id;
		if (this.evaluationContexts && this.evaluationContexts.length > 0) requestData.evaluation_contexts = this.evaluationContexts;
		const fetchOptions = {
			method: "POST",
			headers: {
				...this.getCustomHeaders(),
				"Content-Type": "application/json"
			},
			body: JSON.stringify(requestData)
		};
		this._logger.info("Flags URL", url);
		return this.fetchWithRetry(url, fetchOptions, { retryCount: 0 }, this.featureFlagsRequestTimeoutMs).then((response) => response.json()).then((response) => ({
			success: true,
			response: normalizeFlagsResponse(response)
		})).catch((error) => {
			this._events.emit("error", error);
			return {
				success: false,
				error: this.categorizeRequestError(error)
			};
		});
	}
	categorizeRequestError(error) {
		if (error instanceof PostHogFetchHttpError) return {
			type: "api_error",
			statusCode: error.status
		};
		if (error instanceof PostHogFetchNetworkError) {
			const cause = error.error;
			if (cause instanceof Error && ("AbortError" === cause.name || "TimeoutError" === cause.name)) return { type: "timeout" };
			return { type: "connection_error" };
		}
		return { type: "unknown_error" };
	}
	async getFeatureFlagStateless(key, distinctId, groups = {}, personProperties = {}, groupProperties = {}, disableGeoip) {
		await this._initPromise;
		const flagDetailResponse = await this.getFeatureFlagDetailStateless(key, distinctId, groups, personProperties, groupProperties, disableGeoip);
		if (void 0 === flagDetailResponse) return {
			response: void 0,
			requestId: void 0
		};
		let response = getFeatureFlagValue(flagDetailResponse.response);
		if (void 0 === response) response = false;
		return {
			response,
			requestId: flagDetailResponse.requestId
		};
	}
	async getFeatureFlagDetailStateless(key, distinctId, groups = {}, personProperties = {}, groupProperties = {}, disableGeoip) {
		await this._initPromise;
		const flagsResponse = await this.getFeatureFlagDetailsStateless(distinctId, groups, personProperties, groupProperties, disableGeoip, [key]);
		if (void 0 === flagsResponse) return;
		return {
			response: flagsResponse.flags[key],
			requestId: flagsResponse.requestId,
			evaluatedAt: flagsResponse.evaluatedAt
		};
	}
	async getFeatureFlagPayloadStateless(key, distinctId, groups = {}, personProperties = {}, groupProperties = {}, disableGeoip) {
		await this._initPromise;
		const payloads = await this.getFeatureFlagPayloadsStateless(distinctId, groups, personProperties, groupProperties, disableGeoip, [key]);
		if (!payloads) return;
		const response = payloads[key];
		if (void 0 === response) return null;
		return response;
	}
	async getFeatureFlagPayloadsStateless(distinctId, groups = {}, personProperties = {}, groupProperties = {}, disableGeoip, flagKeysToEvaluate) {
		await this._initPromise;
		return (await this.getFeatureFlagsAndPayloadsStateless(distinctId, groups, personProperties, groupProperties, disableGeoip, flagKeysToEvaluate)).payloads;
	}
	async getFeatureFlagsStateless(distinctId, groups = {}, personProperties = {}, groupProperties = {}, disableGeoip, flagKeysToEvaluate) {
		await this._initPromise;
		return await this.getFeatureFlagsAndPayloadsStateless(distinctId, groups, personProperties, groupProperties, disableGeoip, flagKeysToEvaluate);
	}
	async getFeatureFlagsAndPayloadsStateless(distinctId, groups = {}, personProperties = {}, groupProperties = {}, disableGeoip, flagKeysToEvaluate) {
		await this._initPromise;
		const featureFlagDetails = await this.getFeatureFlagDetailsStateless(distinctId, groups, personProperties, groupProperties, disableGeoip, flagKeysToEvaluate);
		if (!featureFlagDetails) return {
			flags: void 0,
			payloads: void 0,
			requestId: void 0
		};
		return {
			flags: featureFlagDetails.featureFlags,
			payloads: featureFlagDetails.featureFlagPayloads,
			requestId: featureFlagDetails.requestId
		};
	}
	async getFeatureFlagDetailsStateless(distinctId, groups = {}, personProperties = {}, groupProperties = {}, disableGeoip, flagKeysToEvaluate) {
		await this._initPromise;
		const extraPayload = {};
		if (disableGeoip ?? this.disableGeoip) extraPayload["geoip_disable"] = true;
		if (flagKeysToEvaluate) extraPayload["flag_keys_to_evaluate"] = flagKeysToEvaluate;
		const result = await this.getFlags(distinctId, groups, personProperties, groupProperties, extraPayload);
		if (!result.success) return;
		const flagsResponse = result.response;
		if (flagsResponse.errorsWhileComputingFlags) console.error("[FEATURE FLAGS] Error while computing feature flags, some flags may be missing or incorrect. Learn more at https://posthog.com/docs/feature-flags/best-practices");
		if (flagsResponse.quotaLimited?.includes("feature_flags")) {
			console.warn("[FEATURE FLAGS] Feature flags quota limit exceeded - feature flags unavailable. Learn more about billing limits at https://posthog.com/docs/billing/limits-alerts");
			return {
				flags: {},
				featureFlags: {},
				featureFlagPayloads: {},
				requestId: flagsResponse?.requestId,
				quotaLimited: flagsResponse.quotaLimited
			};
		}
		return flagsResponse;
	}
	async getSurveysStateless() {
		await this._initPromise;
		if (this.disabled) return [];
		if (true === this.disableSurveys) {
			this._logger.info("Loading surveys is disabled.");
			return [];
		}
		const url = `${this.host}/api/surveys/?token=${this.apiKey}`;
		const fetchOptions = {
			method: "GET",
			headers: {
				...this.getCustomHeaders(),
				"Content-Type": "application/json"
			}
		};
		const newSurveys = (await this.fetchWithRetry(url, fetchOptions).then((response) => {
			if (200 !== response.status || !response.json) {
				const msg = `Surveys API could not be loaded: ${response.status}`;
				const error = new Error(msg);
				this._logger.error(error);
				this._events.emit("error", new Error(msg));
				return;
			}
			return response.json();
		}).catch((error) => {
			this._logger.error("Surveys API could not be loaded", error);
			this._events.emit("error", error);
		}))?.surveys;
		if (newSurveys) this._logger.info("Surveys fetched from API: ", JSON.stringify(newSurveys));
		return newSurveys ?? [];
	}
	get props() {
		if (!this._props) this._props = this.getPersistedProperty(types_PostHogPersistedProperty.Props);
		return this._props || {};
	}
	set props(val) {
		this._props = val;
	}
	async register(properties) {
		this.wrap(() => {
			this.props = {
				...this.props,
				...properties
			};
			this.setPersistedProperty(types_PostHogPersistedProperty.Props, this.props);
		});
	}
	async unregister(property) {
		this.wrap(() => {
			delete this.props[property];
			this.setPersistedProperty(types_PostHogPersistedProperty.Props, this.props);
		});
	}
	processBeforeEnqueue(message) {
		return message;
	}
	async flushStorage() {}
	enqueue(type, _message, options) {
		this.wrap(() => {
			if (this.optedOut) return void this._events.emit(type, "Library is disabled. Not sending event. To re-enable, call posthog.optIn()");
			let message = this.prepareMessage(_message, options);
			message = this.processBeforeEnqueue(message);
			if (null === message) return;
			message = this.normalizeMessage(message);
			const queue = this.getPersistedProperty(types_PostHogPersistedProperty.Queue) || [];
			if (queue.length >= this.maxQueueSize) {
				queue.shift();
				this._logger.info("Queue is full, the oldest event is dropped.");
			}
			queue.push({ message });
			this.setPersistedProperty(types_PostHogPersistedProperty.Queue, queue);
			this._events.emit(type, message);
			if (queue.length >= this.flushAt) this.flushBackground();
			if (this.flushInterval && !this._flushTimer) this._flushTimer = safeSetTimeout(() => this.flushBackground(), this.flushInterval);
		});
	}
	async sendImmediate(type, _message, options) {
		if (this.disabled) return void this._logger.warn("The client is disabled");
		if (!this._isInitialized) await this._initPromise;
		if (this.optedOut) return void this._events.emit(type, "Library is disabled. Not sending event. To re-enable, call posthog.optIn()");
		let message = this.prepareMessage(_message, options);
		message = this.processBeforeEnqueue(message);
		if (null === message) return;
		message = this.normalizeMessage(message);
		const data = {
			api_key: this.apiKey,
			batch: [message],
			sent_at: currentISOTime()
		};
		if (this.historicalMigration) data.historical_migration = true;
		const payload = JSON.stringify(data);
		const url = `${this.host}/batch/`;
		const gzippedPayload = this.disableCompression ? null : await gzipCompress(payload, this.isDebug);
		const fetchOptions = {
			method: "POST",
			headers: {
				...this.getCustomHeaders(),
				"Content-Type": "application/json",
				...null !== gzippedPayload && { "Content-Encoding": "gzip" }
			},
			body: gzippedPayload || payload
		};
		try {
			await (await this.fetchWithRetry(url, fetchOptions)).body?.cancel()?.catch(() => {});
		} catch (err) {
			this._events.emit("error", err);
		}
	}
	normalizeMessage(message) {
		const { type: _type, library, library_version, ...sanitizedMessage } = message;
		let properties = isPostHogEventProperties(sanitizedMessage.properties) ? sanitizedMessage.properties : void 0;
		if (void 0 !== library && properties?.$lib === void 0) properties = {
			...properties || {},
			$lib: library
		};
		if (void 0 !== library_version && properties?.$lib_version === void 0) properties = {
			...properties || {},
			$lib_version: library_version
		};
		if (properties) sanitizedMessage.properties = properties;
		sanitizedMessage.uuid = getEventUuid(sanitizedMessage.uuid, uuidv7);
		return sanitizedMessage;
	}
	prepareMessage(_message, options) {
		const message = {
			..._message,
			timestamp: options?.timestamp ? options?.timestamp : currentISOTime(),
			uuid: getEventUuid(options?.uuid, uuidv7)
		};
		if (options?.disableGeoip ?? this.disableGeoip) {
			if (!isPostHogEventProperties(message.properties)) message.properties = {};
			message.properties["$geoip_disable"] = true;
		}
		if (message.distinctId) {
			message.distinct_id = message.distinctId;
			delete message.distinctId;
		}
		return message;
	}
	clearFlushTimer() {
		if (this._flushTimer) {
			clearTimeout(this._flushTimer);
			this._flushTimer = void 0;
		}
	}
	flushBackground() {
		this.flush().catch(async (err) => {
			await logFlushError(err);
		});
	}
	async flush() {
		if (this.disabled) return;
		const nextFlushPromise = allSettled([this.flushPromise]).then(() => this._flush());
		this.flushPromise = nextFlushPromise;
		this.addPendingPromise(nextFlushPromise);
		allSettled([nextFlushPromise]).then(() => {
			if (this.flushPromise === nextFlushPromise) this.flushPromise = null;
		});
		return nextFlushPromise;
	}
	getCustomHeaders() {
		const customUserAgent = this.getCustomUserAgent();
		const headers = {};
		if (customUserAgent && "" !== customUserAgent) headers["User-Agent"] = customUserAgent;
		return headers;
	}
	async _flush() {
		this.clearFlushTimer();
		await this._initPromise;
		let queue = this.getPersistedProperty(types_PostHogPersistedProperty.Queue) || [];
		if (!queue.length) return;
		const sentMessages = [];
		const originalQueueLength = queue.length;
		while (queue.length > 0 && sentMessages.length < originalQueueLength) {
			const batchItems = queue.slice(0, this.maxBatchSize);
			const batchMessages = batchItems.map((item) => void 0 === item.message ? item.message : this.normalizeMessage(item.message));
			const persistQueueChange = async () => {
				const newQueue = (this.getPersistedProperty(types_PostHogPersistedProperty.Queue) || []).slice(batchItems.length);
				this.setPersistedProperty(types_PostHogPersistedProperty.Queue, newQueue);
				queue = newQueue;
				await this.flushStorage();
			};
			const data = {
				api_key: this.apiKey,
				batch: batchMessages,
				sent_at: currentISOTime()
			};
			if (this.historicalMigration) data.historical_migration = true;
			const payload = JSON.stringify(data);
			const url = `${this.host}/batch/`;
			const gzippedPayload = this.disableCompression ? null : await gzipCompress(payload, this.isDebug);
			const fetchOptions = {
				method: "POST",
				headers: {
					...this.getCustomHeaders(),
					"Content-Type": "application/json",
					...null !== gzippedPayload && { "Content-Encoding": "gzip" }
				},
				body: gzippedPayload || payload
			};
			const retryOptions = { retryCheck: (err) => {
				if (isPostHogFetchContentTooLargeError(err)) return false;
				return isPostHogFetchError(err);
			} };
			try {
				await (await this.fetchWithRetry(url, fetchOptions, retryOptions)).body?.cancel()?.catch(() => {});
			} catch (err) {
				if (isPostHogFetchContentTooLargeError(err) && batchMessages.length > 1) {
					this.maxBatchSize = Math.max(1, Math.floor(batchMessages.length / 2));
					this._logger.warn(`Received 413 when sending batch of size ${batchMessages.length}, reducing batch size to ${this.maxBatchSize}`);
					continue;
				}
				if (!(err instanceof PostHogFetchNetworkError)) await persistQueueChange();
				this._events.emit("error", err);
				throw err;
			}
			await persistQueueChange();
			sentMessages.push(...batchMessages);
		}
		this._events.emit("flush", sentMessages);
	}
	async _sendLogsBatch(payload) {
		if (this.disabled) return {
			kind: "fatal",
			error: /* @__PURE__ */ new Error("The client is disabled")
		};
		const serialized = JSON.stringify(payload);
		const url = `${this.host}/i/v1/logs?token=${encodeURIComponent(this.apiKey)}`;
		const gzippedPayload = this.disableCompression ? null : await gzipCompress(serialized, this.isDebug);
		const fetchOptions = {
			method: "POST",
			headers: {
				...this.getCustomHeaders(),
				"Content-Type": "application/json",
				...null !== gzippedPayload && { "Content-Encoding": "gzip" }
			},
			body: gzippedPayload || serialized
		};
		try {
			await this.fetchWithRetry(url, fetchOptions, { retryCheck: (err) => {
				if (isPostHogFetchContentTooLargeError(err)) return false;
				return isPostHogFetchError(err);
			} });
			return { kind: "ok" };
		} catch (err) {
			if (isPostHogFetchContentTooLargeError(err)) return { kind: "too-large" };
			if (err instanceof PostHogFetchNetworkError) return {
				kind: "retry-later",
				error: err
			};
			return {
				kind: "fatal",
				error: err
			};
		}
	}
	async fetchWithRetry(url, options, retryOptions, requestTimeout) {
		const body = options.body ? options.body : "";
		let reqByteLength = -1;
		try {
			reqByteLength = body instanceof Blob ? body.size : Buffer.byteLength(body, STRING_FORMAT);
		} catch {
			if (body instanceof Blob) reqByteLength = body.size;
			else reqByteLength = new TextEncoder().encode(body).length;
		}
		return await retriable(async () => {
			const ctrl = new AbortController();
			const timer = safeSetTimeout(() => ctrl.abort(), requestTimeout ?? this.requestTimeout);
			let res = null;
			try {
				res = await this.fetch(url, {
					signal: ctrl.signal,
					...options
				});
			} catch (e) {
				throw new PostHogFetchNetworkError(e);
			} finally {
				clearTimeout(timer);
			}
			if (!("no-cors" === options.mode) && (res.status < 200 || res.status >= 400)) throw new PostHogFetchHttpError(res, reqByteLength);
			return res;
		}, {
			...this._retryOptions,
			...retryOptions
		});
	}
	async _shutdown(shutdownTimeoutMs = 3e4) {
		await this._initPromise;
		let hasTimedOut = false;
		this.clearFlushTimer();
		if (this.disabled) return;
		const doShutdown = async () => {
			try {
				await this.promiseQueue.join();
				while (true) {
					if (0 === (this.getPersistedProperty(types_PostHogPersistedProperty.Queue) || []).length) break;
					await this.flush();
					if (hasTimedOut) break;
				}
			} catch (e) {
				if (!isPostHogFetchError(e)) throw e;
				await logFlushError(e);
			}
		};
		let timeoutHandle;
		try {
			return await Promise.race([new Promise((_, reject) => {
				timeoutHandle = safeSetTimeout(() => {
					this._logger.error("Timed out while shutting down PostHog");
					hasTimedOut = true;
					reject("Timeout while shutting down PostHog. Some events may not have been sent.");
				}, shutdownTimeoutMs);
			}), doShutdown()]);
		} finally {
			clearTimeout(timeoutHandle);
		}
	}
	async shutdown(shutdownTimeoutMs = 3e4) {
		if (this.shutdownPromise) this._logger.warn("shutdown() called while already shutting down. shutdown() is meant to be called once before process exit - use flush() for per-request cleanup");
		else this.shutdownPromise = this._shutdown(shutdownTimeoutMs).finally(() => {
			this.shutdownPromise = null;
		});
		return this.shutdownPromise;
	}
};
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/types.mjs
var FeatureFlagError = {
	ERRORS_WHILE_COMPUTING: "errors_while_computing_flags",
	FLAG_MISSING: "flag_missing",
	QUOTA_LIMITED: "quota_limited",
	UNKNOWN_ERROR: "unknown_error"
};
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/feature-flag-evaluations.mjs
var FeatureFlagEvaluations = class FeatureFlagEvaluations {
	constructor(init) {
		this._host = init.host;
		this._distinctId = init.distinctId;
		this._groups = init.groups;
		this._disableGeoip = init.disableGeoip;
		this._flags = init.flags;
		this._requestId = init.requestId;
		this._evaluatedAt = init.evaluatedAt;
		this._flagDefinitionsLoadedAt = init.flagDefinitionsLoadedAt;
		this._errorsWhileComputing = init.errorsWhileComputing ?? false;
		this._quotaLimited = init.quotaLimited ?? false;
		this._accessed = init.accessed ?? /* @__PURE__ */ new Set();
		this._isSlice = init.isSlice ?? false;
	}
	isEnabled(key) {
		const flag = this._flags[key];
		this._recordAccess(key);
		return flag?.enabled ?? false;
	}
	getFlag(key) {
		const flag = this._flags[key];
		this._recordAccess(key);
		if (!flag) return;
		if (!flag.enabled) return false;
		return flag.variant ?? true;
	}
	getFlagPayload(key) {
		return this._flags[key]?.payload;
	}
	onlyAccessed() {
		const filtered = {};
		for (const key of this._accessed) {
			const flag = this._flags[key];
			if (flag) filtered[key] = flag;
		}
		return this._cloneWith(filtered);
	}
	only(keys) {
		const filtered = {};
		const missing = [];
		for (const key of keys) {
			const flag = this._flags[key];
			if (flag) filtered[key] = flag;
			else missing.push(key);
		}
		if (missing.length > 0) this._host.logWarning(`FeatureFlagEvaluations.only() was called with flag keys that are not in the evaluation set and will be dropped: ${missing.join(", ")}`);
		return this._cloneWith(filtered);
	}
	get keys() {
		return Object.keys(this._flags);
	}
	_getEventProperties() {
		const properties = {};
		const activeFlags = [];
		for (const [key, flag] of Object.entries(this._flags)) {
			const value = false === flag.enabled ? false : flag.variant ?? true;
			properties[`$feature/${key}`] = value;
			if (flag.enabled) activeFlags.push(key);
		}
		if (activeFlags.length > 0) {
			activeFlags.sort();
			properties["$active_feature_flags"] = activeFlags;
		}
		return properties;
	}
	_cloneWith(flags) {
		return new FeatureFlagEvaluations({
			host: this._host,
			distinctId: this._distinctId,
			groups: this._groups,
			disableGeoip: this._disableGeoip,
			flags,
			requestId: this._requestId,
			evaluatedAt: this._evaluatedAt,
			flagDefinitionsLoadedAt: this._flagDefinitionsLoadedAt,
			errorsWhileComputing: this._errorsWhileComputing,
			quotaLimited: this._quotaLimited,
			accessed: new Set(this._accessed),
			isSlice: true
		});
	}
	_recordAccess(key) {
		this._accessed.add(key);
		if ("" === this._distinctId) return;
		if (this._isSlice && !(key in this._flags)) return;
		const flag = this._flags[key];
		const response = void 0 === flag ? void 0 : false === flag.enabled ? false : flag.variant ?? true;
		const properties = {
			$feature_flag: key,
			$feature_flag_response: response,
			$feature_flag_id: flag?.id,
			$feature_flag_version: flag?.version,
			$feature_flag_reason: flag?.reason,
			locally_evaluated: flag?.locallyEvaluated ?? false,
			[`$feature/${key}`]: response,
			$feature_flag_request_id: this._requestId,
			$feature_flag_evaluated_at: flag?.locallyEvaluated ? Date.now() : this._evaluatedAt
		};
		if (flag?.locallyEvaluated && void 0 !== this._flagDefinitionsLoadedAt) properties.$feature_flag_definitions_loaded_at = this._flagDefinitionsLoadedAt;
		const errors = [];
		if (this._errorsWhileComputing) errors.push(FeatureFlagError.ERRORS_WHILE_COMPUTING);
		if (this._quotaLimited) errors.push(FeatureFlagError.QUOTA_LIMITED);
		if (void 0 === flag) errors.push(FeatureFlagError.FLAG_MISSING);
		if (errors.length > 0) properties.$feature_flag_error = errors.join(",");
		this._host.captureFlagCalledEventIfNeeded({
			distinctId: this._distinctId,
			key,
			response,
			groups: this._groups,
			disableGeoip: this._disableGeoip,
			properties
		});
	}
};
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/extensions/feature-flags/crypto.mjs
async function hashSHA1(text) {
	const subtle = globalThis.crypto?.subtle;
	if (!subtle) throw new Error("SubtleCrypto API not available");
	const hashBuffer = await subtle.digest("SHA-1", new TextEncoder().encode(text));
	return Array.from(new Uint8Array(hashBuffer)).map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/extensions/feature-flags/feature-flags.mjs
var SIXTY_SECONDS = 6e4;
var LONG_SCALE = 0x1000000000000000;
var NULL_VALUES_ALLOWED_OPERATORS = ["is_not", "is_set"];
var ClientError = class ClientError extends Error {
	constructor(message) {
		super();
		Error.captureStackTrace(this, this.constructor);
		this.name = "ClientError";
		this.message = message;
		Object.setPrototypeOf(this, ClientError.prototype);
	}
};
function setCustomErrorPrototype(error, constructor) {
	error.name = constructor.name;
	Error.captureStackTrace(error, constructor);
	Object.setPrototypeOf(error, constructor.prototype);
}
var InconclusiveMatchError = class InconclusiveMatchError extends Error {
	constructor(message) {
		super(message);
		setCustomErrorPrototype(this, InconclusiveMatchError);
	}
};
var RequiresServerEvaluation = class RequiresServerEvaluation extends Error {
	constructor(message) {
		super(message);
		setCustomErrorPrototype(this, RequiresServerEvaluation);
	}
};
var FeatureFlagsPoller = class {
	constructor({ pollingInterval, personalApiKey, projectApiKey, timeout, host, customHeaders, ...options }) {
		this.debugMode = false;
		this.shouldBeginExponentialBackoff = false;
		this.backOffCount = 0;
		this.pollingInterval = pollingInterval;
		this.personalApiKey = personalApiKey;
		this.featureFlags = [];
		this.featureFlagsByKey = {};
		this.groupTypeMapping = {};
		this.cohorts = {};
		this.loadedSuccessfullyOnce = false;
		this.timeout = timeout;
		this.projectApiKey = projectApiKey;
		this.host = host;
		this.poller = void 0;
		this.fetch = options.fetch || fetch;
		this.onError = options.onError;
		this.customHeaders = customHeaders;
		this.onLoad = options.onLoad;
		this.cacheProvider = options.cacheProvider;
		this.strictLocalEvaluation = options.strictLocalEvaluation ?? false;
		this.loadFeatureFlags();
	}
	debug(enabled = true) {
		this.debugMode = enabled;
	}
	logMsgIfDebug(fn) {
		if (this.debugMode) fn();
	}
	createEvaluationContext(distinctId, groups = {}, personProperties = {}, groupProperties = {}, evaluationCache = {}) {
		return {
			distinctId,
			groups,
			personProperties,
			groupProperties,
			evaluationCache
		};
	}
	async getFeatureFlag(key, distinctId, groups = {}, personProperties = {}, groupProperties = {}) {
		await this.loadFeatureFlags();
		let response;
		let featureFlag;
		if (!this.loadedSuccessfullyOnce) return response;
		featureFlag = this.featureFlagsByKey[key];
		if (void 0 !== featureFlag) {
			const evaluationContext = this.createEvaluationContext(distinctId, groups, personProperties, groupProperties);
			try {
				response = (await this.computeFlagAndPayloadLocally(featureFlag, evaluationContext)).value;
				this.logMsgIfDebug(() => console.debug(`Successfully computed flag locally: ${key} -> ${response}`));
			} catch (e) {
				if (e instanceof RequiresServerEvaluation || e instanceof InconclusiveMatchError) this.logMsgIfDebug(() => console.debug(`${e.name} when computing flag locally: ${key}: ${e.message}`));
				else if (e instanceof Error) this.onError?.(/* @__PURE__ */ new Error(`Error computing flag locally: ${key}: ${e}`));
			}
		}
		return response;
	}
	async getAllFlagsAndPayloads(evaluationContext, flagKeysToExplicitlyEvaluate) {
		await this.loadFeatureFlags();
		const response = {};
		const payloads = {};
		let fallbackToFlags = 0 == this.featureFlags.length;
		const flagsToEvaluate = flagKeysToExplicitlyEvaluate ? flagKeysToExplicitlyEvaluate.map((key) => this.featureFlagsByKey[key]).filter(Boolean) : this.featureFlags;
		const sharedEvaluationContext = {
			...evaluationContext,
			evaluationCache: evaluationContext.evaluationCache ?? {}
		};
		await Promise.all(flagsToEvaluate.map(async (flag) => {
			try {
				const { value: matchValue, payload: matchPayload } = await this.computeFlagAndPayloadLocally(flag, sharedEvaluationContext);
				response[flag.key] = matchValue;
				if (matchPayload) payloads[flag.key] = matchPayload;
			} catch (e) {
				if (e instanceof RequiresServerEvaluation || e instanceof InconclusiveMatchError) this.logMsgIfDebug(() => console.debug(`${e.name} when computing flag locally: ${flag.key}: ${e.message}`));
				else if (e instanceof Error) this.onError?.(/* @__PURE__ */ new Error(`Error computing flag locally: ${flag.key}: ${e}`));
				fallbackToFlags = true;
			}
		}));
		return {
			response,
			payloads,
			fallbackToFlags
		};
	}
	async computeFlagAndPayloadLocally(flag, evaluationContext, options = {}) {
		const { matchValue, skipLoadCheck = false } = options;
		if (!skipLoadCheck) await this.loadFeatureFlags();
		if (!this.loadedSuccessfullyOnce) return {
			value: false,
			payload: null
		};
		let flagValue;
		flagValue = void 0 !== matchValue ? matchValue : await this.computeFlagValueLocally(flag, evaluationContext);
		const payload = this.getFeatureFlagPayload(flag.key, flagValue);
		return {
			value: flagValue,
			payload
		};
	}
	async computeFlagValueLocally(flag, evaluationContext) {
		const { distinctId, groups, personProperties, groupProperties } = evaluationContext;
		if (!flag.active) return false;
		if (flag.ensure_experience_continuity) throw new InconclusiveMatchError("Flag has experience continuity enabled");
		const aggregation_group_type_index = (flag.filters || {}).aggregation_group_type_index;
		if (void 0 != aggregation_group_type_index) {
			const groupName = this.groupTypeMapping[String(aggregation_group_type_index)];
			if (!groupName) {
				this.logMsgIfDebug(() => console.warn(`[FEATURE FLAGS] Unknown group type index ${aggregation_group_type_index} for feature flag ${flag.key}`));
				throw new InconclusiveMatchError("Flag has unknown group type index");
			}
			if (!(groupName in groups)) {
				this.logMsgIfDebug(() => console.warn(`[FEATURE FLAGS] Can't compute group feature flag: ${flag.key} without group names passed in`));
				return false;
			}
			if ("device_id" === flag.bucketing_identifier && (personProperties?.$device_id === void 0 || personProperties?.$device_id === null || personProperties?.$device_id === "")) this.logMsgIfDebug(() => console.warn(`[FEATURE FLAGS] Ignoring bucketing_identifier for group flag: ${flag.key}`));
			const focusedGroupProperties = groupProperties[groupName];
			return await this.matchFeatureFlagProperties(flag, groups[groupName], focusedGroupProperties, evaluationContext);
		}
		{
			const bucketingValue = this.getBucketingValueForFlag(flag, distinctId, personProperties);
			if (void 0 === bucketingValue) {
				this.logMsgIfDebug(() => console.warn(`[FEATURE FLAGS] Can't compute feature flag: ${flag.key} without $device_id, falling back to server evaluation`));
				throw new InconclusiveMatchError(`Can't compute feature flag: ${flag.key} without $device_id`);
			}
			return await this.matchFeatureFlagProperties(flag, bucketingValue, personProperties, evaluationContext);
		}
	}
	getBucketingValueForFlag(flag, distinctId, properties) {
		if (flag.filters?.aggregation_group_type_index != void 0) return distinctId;
		if ("device_id" === flag.bucketing_identifier) {
			const deviceId = properties?.$device_id;
			if (null == deviceId || "" === deviceId) return;
			return deviceId;
		}
		return distinctId;
	}
	getFeatureFlagPayload(key, flagValue) {
		let payload = null;
		if (false !== flagValue && null != flagValue) {
			if ("boolean" == typeof flagValue) payload = this.featureFlagsByKey?.[key]?.filters?.payloads?.[flagValue.toString()] || null;
			else if ("string" == typeof flagValue) payload = this.featureFlagsByKey?.[key]?.filters?.payloads?.[flagValue] || null;
			if (null != payload) {
				if ("object" == typeof payload) return payload;
				if ("string" == typeof payload) try {
					return JSON.parse(payload);
				} catch {}
				return payload;
			}
		}
		return null;
	}
	async evaluateFlagDependency(property, properties, evaluationContext) {
		const { evaluationCache } = evaluationContext;
		const targetFlagKey = property.key;
		if (!this.featureFlagsByKey) throw new InconclusiveMatchError("Feature flags not available for dependency evaluation");
		if (!("dependency_chain" in property)) throw new InconclusiveMatchError(`Flag dependency property for '${targetFlagKey}' is missing required 'dependency_chain' field`);
		const dependencyChain = property.dependency_chain;
		if (!Array.isArray(dependencyChain)) throw new InconclusiveMatchError(`Flag dependency property for '${targetFlagKey}' has an invalid 'dependency_chain' (expected array, got ${typeof dependencyChain})`);
		if (0 === dependencyChain.length) throw new InconclusiveMatchError(`Circular dependency detected for flag '${targetFlagKey}' (empty dependency chain)`);
		for (const depFlagKey of dependencyChain) {
			if (!(depFlagKey in evaluationCache)) {
				const depFlag = this.featureFlagsByKey[depFlagKey];
				if (depFlag) if (depFlag.active) try {
					evaluationCache[depFlagKey] = await this.computeFlagValueLocally(depFlag, evaluationContext);
				} catch (error) {
					throw new InconclusiveMatchError(`Error evaluating flag dependency '${depFlagKey}' for flag '${targetFlagKey}': ${error}`);
				}
				else evaluationCache[depFlagKey] = false;
				else throw new InconclusiveMatchError(`Missing flag dependency '${depFlagKey}' for flag '${targetFlagKey}'`);
			}
			if (null == evaluationCache[depFlagKey]) throw new InconclusiveMatchError(`Dependency '${depFlagKey}' could not be evaluated`);
		}
		const targetFlagValue = evaluationCache[targetFlagKey];
		return this.flagEvaluatesToExpectedValue(property.value, targetFlagValue);
	}
	flagEvaluatesToExpectedValue(expectedValue, flagValue) {
		if ("boolean" == typeof expectedValue) return expectedValue === flagValue || "string" == typeof flagValue && "" !== flagValue && true === expectedValue;
		if ("string" == typeof expectedValue) return flagValue === expectedValue;
		return false;
	}
	async matchFeatureFlagProperties(flag, bucketingValue, properties, evaluationContext) {
		const flagFilters = flag.filters || {};
		const flagConditions = flagFilters.groups || [];
		const flagAggregation = flagFilters.aggregation_group_type_index;
		const earlyExitEnabled = flagFilters.early_exit ?? false;
		const { groups, groupProperties } = evaluationContext;
		let isInconclusive = false;
		let result;
		for (const condition of flagConditions) try {
			const conditionAggregation = void 0 !== condition.aggregation_group_type_index ? condition.aggregation_group_type_index : flagAggregation;
			let effectiveProperties = properties;
			let effectiveBucketingValue = bucketingValue;
			if (conditionAggregation !== flagAggregation) {
				if (null != conditionAggregation) {
					const groupName = this.groupTypeMapping[String(conditionAggregation)];
					if (!groupName || !(groupName in groups)) {
						this.logMsgIfDebug(() => console.debug(`[FEATURE FLAGS] Skipping group condition for flag '${flag.key}': group type index ${conditionAggregation} not available`));
						continue;
					}
					if (!(groupName in groupProperties)) {
						isInconclusive = true;
						continue;
					}
					effectiveProperties = groupProperties[groupName];
					effectiveBucketingValue = groups[groupName];
				}
			}
			const matchResult = await this.isConditionMatch(flag, effectiveBucketingValue, condition, effectiveProperties, evaluationContext);
			if ("match" === matchResult) {
				const variantOverride = condition.variant;
				const flagVariants = flagFilters.multivariate?.variants || [];
				result = variantOverride && flagVariants.some((variant) => variant.key === variantOverride) ? variantOverride : await this.getMatchingVariant(flag, effectiveBucketingValue) || true;
				break;
			}
			if (earlyExitEnabled && "out_of_rollout_bound" === matchResult) return false;
		} catch (e) {
			if (e instanceof RequiresServerEvaluation) throw e;
			if (e instanceof InconclusiveMatchError) isInconclusive = true;
			else throw e;
		}
		if (void 0 !== result) return result;
		if (isInconclusive) throw new InconclusiveMatchError("Can't determine if feature flag is enabled or not with given properties");
		return false;
	}
	async isConditionMatch(flag, bucketingValue, condition, properties, evaluationContext) {
		const rolloutPercentage = condition.rollout_percentage;
		const warnFunction = (msg) => {
			this.logMsgIfDebug(() => console.warn(msg));
		};
		if ((condition.properties || []).length > 0) {
			for (const prop of condition.properties) {
				const propertyType = prop.type;
				let matches = false;
				matches = "cohort" === propertyType ? await matchCohort(prop, properties, this.cohorts, this.debugMode, (depProp) => this.evaluateFlagDependency(depProp, properties, evaluationContext)) : "flag" === propertyType ? await this.evaluateFlagDependency(prop, properties, evaluationContext) : matchProperty(prop, properties, warnFunction);
				if (!matches) return "no_match";
			}
			if (void 0 == rolloutPercentage) return "match";
		}
		if (void 0 != rolloutPercentage && await _hash(flag.key, bucketingValue) > rolloutPercentage / 100) return "out_of_rollout_bound";
		return "match";
	}
	async getMatchingVariant(flag, bucketingValue) {
		const hashValue = await _hash(flag.key, bucketingValue, "variant");
		const matchingVariant = this.variantLookupTable(flag).find((variant) => hashValue >= variant.valueMin && hashValue < variant.valueMax);
		if (matchingVariant) return matchingVariant.key;
	}
	variantLookupTable(flag) {
		const lookupTable = [];
		let valueMin = 0;
		let valueMax = 0;
		((flag.filters || {}).multivariate?.variants || []).forEach((variant) => {
			valueMax = valueMin + variant.rollout_percentage / 100;
			lookupTable.push({
				valueMin,
				valueMax,
				key: variant.key
			});
			valueMin = valueMax;
		});
		return lookupTable;
	}
	updateFlagState(flagData) {
		this.featureFlags = flagData.flags;
		this.featureFlagsByKey = flagData.flags.reduce((acc, curr) => (acc[curr.key] = curr, acc), {});
		this.groupTypeMapping = flagData.groupTypeMapping;
		this.cohorts = flagData.cohorts;
		this.loadedSuccessfullyOnce = true;
	}
	warnAboutExperienceContinuityFlags(flags) {
		if (this.strictLocalEvaluation) return;
		const experienceContinuityFlags = flags.filter((f) => f.ensure_experience_continuity);
		if (experienceContinuityFlags.length > 0) console.warn(`[PostHog] You are using local evaluation but ${experienceContinuityFlags.length} flag(s) have experience continuity enabled: ${experienceContinuityFlags.map((f) => f.key).join(", ")}. Experience continuity is incompatible with local evaluation and will cause a server request on every flag evaluation, negating local evaluation cost savings. To avoid server requests and unexpected costs, either disable experience continuity on these flags in PostHog, use strictLocalEvaluation: true in client init, or pass onlyEvaluateLocally: true per flag call (flags that cannot be evaluated locally will return undefined).`);
	}
	async loadFromCache(debugMessage) {
		if (!this.cacheProvider) return false;
		try {
			const cached = await this.cacheProvider.getFlagDefinitions();
			if (cached) {
				this.updateFlagState(cached);
				this.logMsgIfDebug(() => console.debug(`[FEATURE FLAGS] ${debugMessage} (${cached.flags.length} flags)`));
				this.onLoad?.(this.featureFlags.length);
				this.warnAboutExperienceContinuityFlags(cached.flags);
				return true;
			}
			return false;
		} catch (err) {
			this.onError?.(/* @__PURE__ */ new Error(`Failed to load from cache: ${err}`));
			return false;
		}
	}
	async loadFeatureFlags(forceReload = false) {
		if (this.loadedSuccessfullyOnce && !forceReload) return;
		if (!forceReload && this.nextFetchAllowedAt && Date.now() < this.nextFetchAllowedAt) return void this.logMsgIfDebug(() => console.debug("[FEATURE FLAGS] Skipping fetch, in backoff period"));
		if (!this.loadingPromise) this.loadingPromise = this._loadFeatureFlags().catch((err) => this.logMsgIfDebug(() => console.debug(`[FEATURE FLAGS] Failed to load feature flags: ${err}`))).finally(() => {
			this.loadingPromise = void 0;
		});
		return this.loadingPromise;
	}
	isLocalEvaluationReady() {
		return (this.loadedSuccessfullyOnce ?? false) && (this.featureFlags?.length ?? 0) > 0;
	}
	getFlagDefinitionsLoadedAt() {
		return this.flagDefinitionsLoadedAt;
	}
	getPollingInterval() {
		if (!this.shouldBeginExponentialBackoff) return this.pollingInterval;
		return Math.min(SIXTY_SECONDS, this.pollingInterval * 2 ** this.backOffCount);
	}
	beginBackoff() {
		this.shouldBeginExponentialBackoff = true;
		this.backOffCount += 1;
		this.nextFetchAllowedAt = Date.now() + this.getPollingInterval();
	}
	clearBackoff() {
		this.shouldBeginExponentialBackoff = false;
		this.backOffCount = 0;
		this.nextFetchAllowedAt = void 0;
	}
	async _loadFeatureFlags() {
		if (this.poller) {
			clearTimeout(this.poller);
			this.poller = void 0;
		}
		this.poller = setTimeout(() => this.loadFeatureFlags(true), this.getPollingInterval());
		try {
			let shouldFetch = true;
			if (this.cacheProvider) try {
				shouldFetch = await this.cacheProvider.shouldFetchFlagDefinitions();
			} catch (err) {
				this.onError?.(/* @__PURE__ */ new Error(`Error in shouldFetchFlagDefinitions: ${err}`));
			}
			if (!shouldFetch) {
				if (await this.loadFromCache("Loaded flags from cache (skipped fetch)")) return;
				if (this.loadedSuccessfullyOnce) return;
			}
			const res = await this._requestFeatureFlagDefinitions();
			if (!res) return;
			switch (res.status) {
				case 304:
					this.logMsgIfDebug(() => console.debug("[FEATURE FLAGS] Flags not modified (304), using cached data"));
					this.flagsEtag = res.headers?.get("ETag") ?? this.flagsEtag;
					this.loadedSuccessfullyOnce = true;
					this.clearBackoff();
					return;
				case 401:
					this.beginBackoff();
					throw new ClientError(`Your project key or personal API key is invalid. Setting next polling interval to ${this.getPollingInterval()}ms. More information: https://posthog.com/docs/api#rate-limiting`);
				case 402:
					console.warn("[FEATURE FLAGS] Feature flags quota limit exceeded - unsetting all local flags. Learn more about billing limits at https://posthog.com/docs/billing/limits-alerts");
					this.featureFlags = [];
					this.featureFlagsByKey = {};
					this.groupTypeMapping = {};
					this.cohorts = {};
					return;
				case 403:
					this.beginBackoff();
					throw new ClientError(`Your personal API key does not have permission to fetch feature flag definitions for local evaluation. Setting next polling interval to ${this.getPollingInterval()}ms. Are you sure you're using the correct personal and Project API key pair? More information: https://posthog.com/docs/api/overview`);
				case 429:
					this.beginBackoff();
					throw new ClientError(`You are being rate limited. Setting next polling interval to ${this.getPollingInterval()}ms. More information: https://posthog.com/docs/api#rate-limiting`);
				case 200: {
					const responseJson = await res.json() ?? {};
					if (!("flags" in responseJson)) return void this.onError?.(/* @__PURE__ */ new Error(`Invalid response when getting feature flags: ${JSON.stringify(responseJson)}`));
					this.flagsEtag = res.headers?.get("ETag") ?? void 0;
					const flagData = {
						flags: responseJson.flags ?? [],
						groupTypeMapping: responseJson.group_type_mapping || {},
						cohorts: responseJson.cohorts || {}
					};
					this.updateFlagState(flagData);
					this.flagDefinitionsLoadedAt = Date.now();
					this.clearBackoff();
					if (this.cacheProvider && shouldFetch) try {
						await this.cacheProvider.onFlagDefinitionsReceived(flagData);
					} catch (err) {
						this.onError?.(/* @__PURE__ */ new Error(`Failed to store in cache: ${err}`));
					}
					this.onLoad?.(this.featureFlags.length);
					this.warnAboutExperienceContinuityFlags(flagData.flags);
					break;
				}
				default: return;
			}
		} catch (err) {
			if (err instanceof ClientError) this.onError?.(err);
		}
	}
	getPersonalApiKeyRequestOptions(method = "GET", etag) {
		const headers = {
			...this.customHeaders,
			"Content-Type": "application/json",
			Authorization: `Bearer ${this.personalApiKey}`
		};
		if (etag) headers["If-None-Match"] = etag;
		return {
			method,
			headers
		};
	}
	_requestFeatureFlagDefinitions() {
		const url = `${this.host}/flags/definitions?token=${this.projectApiKey}&send_cohorts`;
		const options = this.getPersonalApiKeyRequestOptions("GET", this.flagsEtag);
		let abortTimeout = null;
		if (this.timeout && "number" == typeof this.timeout) {
			const controller = new AbortController();
			abortTimeout = safeSetTimeout(() => {
				controller.abort();
			}, this.timeout);
			options.signal = controller.signal;
		}
		try {
			const fetch1 = this.fetch;
			return fetch1(url, options);
		} finally {
			clearTimeout(abortTimeout);
		}
	}
	async stopPoller(timeoutMs = 3e4) {
		clearTimeout(this.poller);
		if (this.cacheProvider) try {
			const shutdownResult = this.cacheProvider.shutdown();
			if (shutdownResult instanceof Promise) await Promise.race([shutdownResult, new Promise((_, reject) => setTimeout(() => reject(/* @__PURE__ */ new Error(`Cache shutdown timeout after ${timeoutMs}ms`)), timeoutMs))]);
		} catch (err) {
			this.onError?.(/* @__PURE__ */ new Error(`Error during cache shutdown: ${err}`));
		}
	}
};
async function _hash(key, bucketingValue, salt = "") {
	const hashString = await hashSHA1(`${key}.${bucketingValue}${salt}`);
	return parseInt(hashString.slice(0, 15), 16) / LONG_SCALE;
}
function matchProperty(property, propertyValues, warnFunction) {
	const key = property.key;
	const value = property.value;
	const operator = property.operator || "exact";
	if (key in propertyValues) {
		if ("is_not_set" === operator) return false;
	} else {
		if ("is_not_set" === operator) return true;
		throw new InconclusiveMatchError(`Property ${key} not found in propertyValues`);
	}
	const overrideValue = propertyValues[key];
	if (null == overrideValue && !NULL_VALUES_ALLOWED_OPERATORS.includes(operator)) {
		if (warnFunction) warnFunction(`Property ${key} cannot have a value of null/undefined with the ${operator} operator`);
		return false;
	}
	function computeExactMatch(value, overrideValue) {
		if (Array.isArray(value)) return value.map((val) => String(val).toLowerCase()).includes(String(overrideValue).toLowerCase());
		return String(value).toLowerCase() === String(overrideValue).toLowerCase();
	}
	function compare(lhs, rhs, operator) {
		if ("gt" === operator) return lhs > rhs;
		if ("gte" === operator) return lhs >= rhs;
		if ("lt" === operator) return lhs < rhs;
		if ("lte" === operator) return lhs <= rhs;
		throw new Error(`Invalid operator: ${operator}`);
	}
	switch (operator) {
		case "exact": return computeExactMatch(value, overrideValue);
		case "is_not": return !computeExactMatch(value, overrideValue);
		case "is_set": return key in propertyValues;
		case "icontains": return String(overrideValue).toLowerCase().includes(String(value).toLowerCase());
		case "not_icontains": return !String(overrideValue).toLowerCase().includes(String(value).toLowerCase());
		case "regex": return isValidRegex(String(value)) && null !== String(overrideValue).match(String(value));
		case "not_regex": return isValidRegex(String(value)) && null === String(overrideValue).match(String(value));
		case "gt":
		case "gte":
		case "lt":
		case "lte": {
			const parsedValue = "number" == typeof value ? value : parseFloat(String(value));
			let parsedOverride;
			parsedOverride = "number" == typeof overrideValue ? overrideValue : null != overrideValue ? parseFloat(String(overrideValue)) : NaN;
			if (Number.isFinite(parsedValue) && Number.isFinite(parsedOverride)) return compare(parsedOverride, parsedValue, operator);
			return compare(String(overrideValue), String(value), operator);
		}
		case "is_date_after":
		case "is_date_before": {
			if ("boolean" == typeof value) throw new InconclusiveMatchError("Date operations cannot be performed on boolean values");
			let parsedDate = relativeDateParseForFeatureFlagMatching(String(value));
			if (null == parsedDate) parsedDate = convertToDateTime(value);
			if (null == parsedDate) throw new InconclusiveMatchError(`Invalid date: ${value}`);
			const overrideDate = convertToDateTime(overrideValue);
			if (["is_date_before"].includes(operator)) return overrideDate < parsedDate;
			return overrideDate > parsedDate;
		}
		case "semver_eq": return 0 === compareSemverTuples(parseSemver(String(overrideValue)), parseSemver(String(value)));
		case "semver_neq": return 0 !== compareSemverTuples(parseSemver(String(overrideValue)), parseSemver(String(value)));
		case "semver_gt": return compareSemverTuples(parseSemver(String(overrideValue)), parseSemver(String(value))) > 0;
		case "semver_gte": return compareSemverTuples(parseSemver(String(overrideValue)), parseSemver(String(value))) >= 0;
		case "semver_lt": return compareSemverTuples(parseSemver(String(overrideValue)), parseSemver(String(value))) < 0;
		case "semver_lte": return compareSemverTuples(parseSemver(String(overrideValue)), parseSemver(String(value))) <= 0;
		case "semver_tilde": {
			const overrideParsed = parseSemver(String(overrideValue));
			const { lower, upper } = computeTildeBounds(String(value));
			return compareSemverTuples(overrideParsed, lower) >= 0 && compareSemverTuples(overrideParsed, upper) < 0;
		}
		case "semver_caret": {
			const overrideParsed = parseSemver(String(overrideValue));
			const { lower, upper } = computeCaretBounds(String(value));
			return compareSemverTuples(overrideParsed, lower) >= 0 && compareSemverTuples(overrideParsed, upper) < 0;
		}
		case "semver_wildcard": {
			const overrideParsed = parseSemver(String(overrideValue));
			const { lower, upper } = computeWildcardBounds(String(value));
			return compareSemverTuples(overrideParsed, lower) >= 0 && compareSemverTuples(overrideParsed, upper) < 0;
		}
		default: throw new InconclusiveMatchError(`Unknown operator: ${operator}`);
	}
}
function checkCohortExists(cohortId, cohortProperties) {
	if (!(cohortId in cohortProperties)) throw new RequiresServerEvaluation(`cohort ${cohortId} not found in local cohorts - likely a static cohort that requires server evaluation`);
}
async function matchCohort(property, propertyValues, cohortProperties, debugMode = false, flagDependencyEvaluator) {
	const cohortId = String(property.value);
	checkCohortExists(cohortId, cohortProperties);
	const propertyGroup = cohortProperties[cohortId];
	return matchPropertyGroup(propertyGroup, propertyValues, cohortProperties, debugMode, flagDependencyEvaluator);
}
async function matchPropertyGroup(propertyGroup, propertyValues, cohortProperties, debugMode = false, flagDependencyEvaluator) {
	if (!propertyGroup) return true;
	const propertyGroupType = propertyGroup.type;
	const properties = propertyGroup.values;
	if (!properties || 0 === properties.length) return true;
	let errorMatchingLocally = false;
	if ("values" in properties[0]) {
		for (const prop of properties) try {
			const matches = await matchPropertyGroup(prop, propertyValues, cohortProperties, debugMode, flagDependencyEvaluator);
			if ("AND" === propertyGroupType) {
				if (!matches) return false;
			} else if (matches) return true;
		} catch (err) {
			if (err instanceof RequiresServerEvaluation) throw err;
			if (err instanceof InconclusiveMatchError) {
				if (debugMode) console.debug(`Failed to compute property ${prop} locally: ${err}`);
				errorMatchingLocally = true;
			} else throw err;
		}
		if (errorMatchingLocally) throw new InconclusiveMatchError("Can't match cohort without a given cohort property value");
		return "AND" === propertyGroupType;
	}
	for (const prop of properties) try {
		let matches;
		if ("cohort" === prop.type) matches = await matchCohort(prop, propertyValues, cohortProperties, debugMode, flagDependencyEvaluator);
		else if ("flag" === prop.type) {
			if (!flagDependencyEvaluator) throw new InconclusiveMatchError(`Flag dependency '${prop.key || "unknown"}' cannot be evaluated without a flag dependency evaluator`);
			matches = await flagDependencyEvaluator(prop);
		} else matches = matchProperty(prop, propertyValues);
		const negation = prop.negation || false;
		if ("AND" === propertyGroupType) {
			if (!matches && !negation) return false;
			if (matches && negation) return false;
		} else {
			if (matches && !negation) return true;
			if (!matches && negation) return true;
		}
	} catch (err) {
		if (err instanceof RequiresServerEvaluation) throw err;
		if (err instanceof InconclusiveMatchError) {
			if (debugMode) console.debug(`Failed to compute property ${prop} locally: ${err}`);
			errorMatchingLocally = true;
		} else throw err;
	}
	if (errorMatchingLocally) throw new InconclusiveMatchError("can't match cohort without a given cohort property value");
	return "AND" === propertyGroupType;
}
function isValidRegex(regex) {
	try {
		new RegExp(regex);
		return true;
	} catch (err) {
		return false;
	}
}
function parseSemverNumericIdentifier(part, raw) {
	if (!/^\d+$/.test(part)) throw new InconclusiveMatchError(`Invalid semver: ${raw}`);
	if (part.length > 1 && "0" === part[0]) throw new InconclusiveMatchError(`Invalid semver: ${raw}`);
	return parseInt(part, 10);
}
function parseSemver(value) {
	const baseVersion = String(value).trim().replace(/^[vV]/, "").split("-")[0].split("+")[0];
	if (!baseVersion || baseVersion.startsWith(".")) throw new InconclusiveMatchError(`Invalid semver: ${value}`);
	const parts = baseVersion.split(".");
	const parsePart = (part) => {
		if (void 0 === part || "" === part) return 0;
		return parseSemverNumericIdentifier(part, value);
	};
	return [
		parsePart(parts[0]),
		parsePart(parts[1]),
		parsePart(parts[2])
	];
}
function compareSemverTuples(a, b) {
	for (let i = 0; i < 3; i++) {
		if (a[i] < b[i]) return -1;
		if (a[i] > b[i]) return 1;
	}
	return 0;
}
function computeTildeBounds(value) {
	const parsed = parseSemver(value);
	return {
		lower: [
			parsed[0],
			parsed[1],
			parsed[2]
		],
		upper: [
			parsed[0],
			parsed[1] + 1,
			0
		]
	};
}
function computeCaretBounds(value) {
	const [major, minor, patch] = parseSemver(value);
	const lower = [
		major,
		minor,
		patch
	];
	let upper;
	upper = major > 0 ? [
		major + 1,
		0,
		0
	] : minor > 0 ? [
		0,
		minor + 1,
		0
	] : [
		0,
		0,
		patch + 1
	];
	return {
		lower,
		upper
	};
}
function computeWildcardBounds(value) {
	const cleanedText = String(value).trim().replace(/^[vV]/, "").replace(/\.\*$/, "").replace(/\*$/, "");
	if (!cleanedText) throw new InconclusiveMatchError(`Invalid wildcard semver: ${value}`);
	const parts = cleanedText.split(".");
	const parseWildcardPart = (part) => {
		try {
			return parseSemverNumericIdentifier(part, value);
		} catch {
			throw new InconclusiveMatchError(`Invalid wildcard semver: ${value}`);
		}
	};
	const major = parseWildcardPart(parts[0]);
	let lower;
	let upper;
	if (1 === parts.length) {
		lower = [
			major,
			0,
			0
		];
		upper = [
			major + 1,
			0,
			0
		];
	} else {
		const minor = parseWildcardPart(parts[1]);
		lower = [
			major,
			minor,
			0
		];
		upper = [
			major,
			minor + 1,
			0
		];
	}
	return {
		lower,
		upper
	};
}
function convertToDateTime(value) {
	if (value instanceof Date) return value;
	if ("string" == typeof value || "number" == typeof value) {
		const date = new Date(value);
		if (!isNaN(date.valueOf())) return date;
		throw new InconclusiveMatchError(`${value} is in an invalid date format`);
	}
	throw new InconclusiveMatchError(`The date provided ${value} must be a string, number, or date object`);
}
function relativeDateParseForFeatureFlagMatching(value) {
	const match = value.match(/^-?(?<number>[0-9]+)(?<interval>[a-z])$/);
	const parsedDt = new Date((/* @__PURE__ */ new Date()).toISOString());
	if (!match) return null;
	{
		if (!match.groups) return null;
		const number = parseInt(match.groups["number"]);
		if (number >= 1e4) return null;
		const interval = match.groups["interval"];
		if ("h" == interval) parsedDt.setUTCHours(parsedDt.getUTCHours() - number);
		else if ("d" == interval) parsedDt.setUTCDate(parsedDt.getUTCDate() - number);
		else if ("w" == interval) parsedDt.setUTCDate(parsedDt.getUTCDate() - 7 * number);
		else if ("m" == interval) parsedDt.setUTCMonth(parsedDt.getUTCMonth() - number);
		else {
			if ("y" != interval) return null;
			parsedDt.setUTCFullYear(parsedDt.getUTCFullYear() - number);
		}
		return parsedDt;
	}
}
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/extensions/error-tracking/autocapture.mjs
function makeUncaughtExceptionHandler(captureFn, onFatalFn) {
	let calledFatalError = false;
	return Object.assign((error) => {
		const processWouldExit = 0 === global.process.listeners("uncaughtException").filter((listener) => "domainUncaughtExceptionClear" !== listener.name && true !== listener._posthogErrorHandler).length;
		captureFn(error, { mechanism: {
			type: "onuncaughtexception",
			handled: false
		} });
		if (!calledFatalError && processWouldExit) {
			calledFatalError = true;
			onFatalFn(error);
		}
	}, { _posthogErrorHandler: true });
}
function addUncaughtExceptionListener(captureFn, onFatalFn) {
	globalThis.process?.on("uncaughtException", makeUncaughtExceptionHandler(captureFn, onFatalFn));
}
function addUnhandledRejectionListener(captureFn) {
	globalThis.process?.on("unhandledRejection", (reason) => captureFn(reason, { mechanism: {
		type: "onunhandledrejection",
		handled: false
	} }));
}
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/extensions/error-tracking/index.mjs
var SHUTDOWN_TIMEOUT = 2e3;
var ErrorTracking = class ErrorTracking {
	constructor(client, options, _logger) {
		this.client = client;
		this._exceptionAutocaptureEnabled = options.enableExceptionAutocapture || false;
		this._logger = _logger;
		this._rateLimiter = new BucketedRateLimiter({
			refillRate: 1,
			bucketSize: 10,
			refillInterval: 1e4,
			_logger: this._logger
		});
		this.startAutocaptureIfEnabled();
	}
	static isPreviouslyCapturedError(x) {
		return isObject(x) && "__posthog_previously_captured_error" in x && true === x.__posthog_previously_captured_error;
	}
	static async buildEventMessage(builder, error, hint, distinctId, additionalProperties) {
		const properties = { ...additionalProperties };
		const exceptionProperties = builder.buildFromUnknown(error, hint);
		exceptionProperties.$exception_list = await builder.modifyFrames(exceptionProperties.$exception_list);
		return {
			event: "$exception",
			distinctId,
			properties: {
				...exceptionProperties,
				...properties
			},
			_originatedFromCaptureException: true
		};
	}
	startAutocaptureIfEnabled() {
		if (this.isEnabled()) {
			addUncaughtExceptionListener(this.onException.bind(this), this.onFatalError.bind(this));
			addUnhandledRejectionListener(this.onException.bind(this));
		}
	}
	onException(exception, hint) {
		this.client.addPendingPromise((async () => {
			if (!ErrorTracking.isPreviouslyCapturedError(exception)) {
				const eventMessage = await ErrorTracking.buildEventMessage(this.client.getErrorPropertiesBuilder(), exception, hint);
				const exceptionType = eventMessage.properties?.$exception_list[0]?.type ?? "Exception";
				if (this._rateLimiter.consumeRateLimit(exceptionType)) return void this._logger.info("Skipping exception capture because of client rate limiting.", { exception: exceptionType });
				return this.client.capture(eventMessage);
			}
		})());
	}
	async onFatalError(exception) {
		console.error(exception);
		await this.client.shutdown(SHUTDOWN_TIMEOUT);
		process.exit(1);
	}
	isEnabled() {
		return !this.client.isDisabled && this._exceptionAutocaptureEnabled;
	}
	shutdown() {
		this._rateLimiter.stop();
	}
};
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/storage-memory.mjs
var PostHogMemoryStorage = class {
	getProperty(key) {
		return this._memoryStorage[key];
	}
	setProperty(key, value) {
		this._memoryStorage[key] = null !== value ? value : void 0;
	}
	constructor() {
		this._memoryStorage = {};
	}
};
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/client.mjs
var MINIMUM_POLLING_INTERVAL = 100;
var THIRTY_SECONDS = 3e4;
var MAX_CACHE_SIZE = 5e4;
var WAITUNTIL_DEBOUNCE_MS = 50;
var WAITUNTIL_MAX_WAIT_MS = 500;
var DEFAULT_NODE_HOST = "https://us.i.posthog.com";
var _emittedDeprecations = /* @__PURE__ */ new Set();
function emitDeprecationWarningOnce(id, message) {
	if (_emittedDeprecations.has(id)) return;
	_emittedDeprecations.add(id);
	console.warn(`[PostHog] ${message}`);
}
function normalizeApiKey(value) {
	return "string" == typeof value ? value.trim() : "";
}
function normalizePersonalApiKey(value) {
	return ("string" == typeof value ? value.trim() : "") || void 0;
}
function normalizeHost(value) {
	return ("string" == typeof value ? value.trim() : "") || DEFAULT_NODE_HOST;
}
function normalizeUnsetPersonProperties(value) {
	return (Array.isArray(value) ? value : [value]).filter((propertyName) => "string" == typeof propertyName && propertyName.trim().length > 0);
}
function buildFlagEventProperties(flagValues) {
	if (!flagValues) return {};
	const additionalProperties = {};
	for (const [feature, variant] of Object.entries(flagValues)) additionalProperties[`$feature/${feature}`] = variant;
	const activeFlags = Object.keys(flagValues).filter((flag) => false !== flagValues[flag]).sort();
	if (activeFlags.length > 0) additionalProperties["$active_feature_flags"] = activeFlags;
	return additionalProperties;
}
var PostHogBackendClient = class extends PostHogCoreStateless {
	constructor(apiKey, options = {}) {
		const normalizedApiKey = normalizeApiKey(apiKey);
		const normalizedOptions = {
			...options,
			host: normalizeHost(options.host),
			personalApiKey: normalizePersonalApiKey(options.personalApiKey)
		};
		super(normalizedApiKey, normalizedOptions), this._memoryStorage = new PostHogMemoryStorage();
		this.options = normalizedOptions;
		this.context = this.initializeContext();
		this.options.featureFlagsPollingInterval = "number" == typeof normalizedOptions.featureFlagsPollingInterval ? Math.max(normalizedOptions.featureFlagsPollingInterval, MINIMUM_POLLING_INTERVAL) : THIRTY_SECONDS;
		if ("number" == typeof normalizedOptions.waitUntilDebounceMs) this.options.waitUntilDebounceMs = Math.max(normalizedOptions.waitUntilDebounceMs, 0);
		if ("number" == typeof normalizedOptions.waitUntilMaxWaitMs) this.options.waitUntilMaxWaitMs = Math.max(normalizedOptions.waitUntilMaxWaitMs, 0);
		if (!this.disabled && normalizedOptions.personalApiKey) {
			if (normalizedOptions.personalApiKey.includes("phc_")) throw new Error("Your Personal API key is invalid. These keys are prefixed with \"phx_\" and can be created in PostHog project settings.");
			if (false !== normalizedOptions.enableLocalEvaluation) this.featureFlagsPoller = new FeatureFlagsPoller({
				pollingInterval: this.options.featureFlagsPollingInterval,
				personalApiKey: normalizedOptions.personalApiKey,
				projectApiKey: normalizedApiKey,
				timeout: normalizedOptions.requestTimeout ?? 1e4,
				host: this.host,
				fetch: normalizedOptions.fetch,
				onError: (err) => {
					this._events.emit("error", err);
				},
				onLoad: (count) => {
					this._events.emit("localEvaluationFlagsLoaded", count);
				},
				customHeaders: this.getCustomHeaders(),
				cacheProvider: normalizedOptions.flagDefinitionCacheProvider,
				strictLocalEvaluation: normalizedOptions.strictLocalEvaluation
			});
		}
		this.errorTracking = new ErrorTracking(this, normalizedOptions, this._logger);
		this.distinctIdHasSentFlagCalls = {};
		this.maxCacheSize = normalizedOptions.maxCacheSize || MAX_CACHE_SIZE;
	}
	enqueue(type, message, options) {
		super.enqueue(type, message, options);
		this.scheduleDebouncedFlush();
	}
	async flush() {
		const flushPromise = super.flush();
		const waitUntil = this.options.waitUntil;
		if (waitUntil && !this._waitUntilCycle) try {
			waitUntil(flushPromise.catch(() => {}));
		} catch {}
		return flushPromise;
	}
	scheduleDebouncedFlush() {
		const waitUntil = this.options.waitUntil;
		if (!waitUntil) return;
		if (this.disabled || this.optedOut) return;
		if (!this._waitUntilCycle) {
			let resolve;
			const promise = new Promise((r) => {
				resolve = r;
			});
			try {
				waitUntil(promise);
			} catch {
				return;
			}
			this._waitUntilCycle = {
				resolve,
				startedAt: Date.now(),
				timer: void 0
			};
		}
		const flushNow = Date.now() - this._waitUntilCycle.startedAt >= (this.options.waitUntilMaxWaitMs ?? WAITUNTIL_MAX_WAIT_MS);
		if (void 0 !== this._waitUntilCycle.timer) clearTimeout(this._waitUntilCycle.timer);
		if (flushNow) return void this.resolveWaitUntilFlush();
		const debounceMs = this.options.waitUntilDebounceMs ?? WAITUNTIL_DEBOUNCE_MS;
		this._waitUntilCycle.timer = safeSetTimeout(() => {
			this.resolveWaitUntilFlush();
		}, debounceMs);
	}
	_consumeWaitUntilCycle() {
		const cycle = this._waitUntilCycle;
		if (cycle) {
			clearTimeout(cycle.timer);
			this._waitUntilCycle = void 0;
		}
		return cycle?.resolve;
	}
	async resolveWaitUntilFlush() {
		const resolve = this._consumeWaitUntilCycle();
		try {
			await super.flush();
		} catch {} finally {
			resolve?.();
		}
	}
	getPersistedProperty(key) {
		return this._memoryStorage.getProperty(key);
	}
	setPersistedProperty(key, value) {
		return this._memoryStorage.setProperty(key, value);
	}
	fetch(url, options) {
		return this.options.fetch ? this.options.fetch(url, options) : fetch(url, options);
	}
	getLibraryVersion() {
		return version;
	}
	getCustomUserAgent() {
		return `${this.getLibraryId()}/${this.getLibraryVersion()}`;
	}
	getCommonEventProperties() {
		const commonProperties = super.getCommonEventProperties();
		if (this.options.isServer ?? true) commonProperties.$is_server = true;
		return commonProperties;
	}
	enable() {
		return super.optIn();
	}
	disable() {
		return super.optOut();
	}
	debug(enabled = true) {
		super.debug(enabled);
		this.featureFlagsPoller?.debug(enabled);
	}
	_warnIfInvalidCapture(props, stringArgumentWarning, exceptionCaptureWarning) {
		if ("string" == typeof props) this._logger.warn(stringArgumentWarning);
		if ("$exception" === props.event && !props._originatedFromCaptureException) this._logger.warn(exceptionCaptureWarning);
	}
	_capturePreparedEvent(props, immediate) {
		return this.addPendingPromise(this.prepareEventMessage(props).then(({ distinctId, event, properties, options }) => {
			const captureOptions = {
				timestamp: options.timestamp,
				disableGeoip: options.disableGeoip,
				uuid: options.uuid
			};
			return immediate ? super.captureStatelessImmediate(distinctId, event, properties, captureOptions) : super.captureStateless(distinctId, event, properties, captureOptions);
		}).catch((err) => {
			if (err) console.error(err);
		}));
	}
	capture(props) {
		this._warnIfInvalidCapture(props, "Called capture() with a string as the first argument when an object was expected.", "Using `posthog.capture('$exception')` is unreliable because it does not attach required metadata. Use `posthog.captureException(error)` instead, which attaches required metadata automatically.");
		this._capturePreparedEvent(props, false);
	}
	async captureImmediate(props) {
		this._warnIfInvalidCapture(props, "Called captureImmediate() with a string as the first argument when an object was expected.", "Capturing a `$exception` event via `posthog.captureImmediate('$exception')` is unreliable because it does not attach required metadata. Use `posthog.captureExceptionImmediate(error)` instead, which attaches this metadata by default.");
		return this._capturePreparedEvent(props, true);
	}
	identify({ distinctId, properties = {}, disableGeoip }) {
		const { $set, $set_once, $anon_distinct_id, ...rest } = properties;
		const eventProperties = {
			$set: $set || rest,
			$set_once: $set_once || {},
			$anon_distinct_id: $anon_distinct_id ?? void 0
		};
		super.identifyStateless(distinctId, eventProperties, { disableGeoip });
	}
	async identifyImmediate({ distinctId, properties = {}, disableGeoip }) {
		const { $set, $set_once, $anon_distinct_id, ...rest } = properties;
		const eventProperties = {
			$set: $set || rest,
			$set_once: $set_once || {},
			$anon_distinct_id: $anon_distinct_id ?? void 0
		};
		await super.identifyStatelessImmediate(distinctId, eventProperties, { disableGeoip });
	}
	setPersonProperties({ distinctId, properties = {}, propertiesOnce = {} }) {
		if (0 === Object.keys(properties).length && 0 === Object.keys(propertiesOnce).length) return;
		const eventProperties = {};
		if (Object.keys(properties).length > 0) eventProperties.$set = properties;
		if (Object.keys(propertiesOnce).length > 0) eventProperties.$set_once = propertiesOnce;
		this.capture({
			distinctId,
			event: "$set",
			properties: eventProperties
		});
	}
	unsetPersonProperties({ distinctId, properties }) {
		const propertyNames = normalizeUnsetPersonProperties(properties);
		if (0 === propertyNames.length) return;
		this.capture({
			distinctId,
			event: "$set",
			properties: { $unset: propertyNames }
		});
	}
	alias(data) {
		super.aliasStateless(data.alias, data.distinctId, void 0, { disableGeoip: data.disableGeoip });
	}
	async aliasImmediate(data) {
		await super.aliasStatelessImmediate(data.alias, data.distinctId, void 0, { disableGeoip: data.disableGeoip });
	}
	isLocalEvaluationReady() {
		return this.featureFlagsPoller?.isLocalEvaluationReady() ?? false;
	}
	async waitForLocalEvaluationReady(timeoutMs = THIRTY_SECONDS) {
		if (this.isLocalEvaluationReady()) return true;
		if (void 0 === this.featureFlagsPoller) return false;
		return new Promise((resolve) => {
			const timeout = setTimeout(() => {
				cleanup();
				resolve(false);
			}, timeoutMs);
			const cleanup = this._events.on("localEvaluationFlagsLoaded", (count) => {
				clearTimeout(timeout);
				cleanup();
				resolve(count > 0);
			});
		});
	}
	_resolveDistinctId(distinctIdOrOptions, options) {
		if ("string" == typeof distinctIdOrOptions) return {
			distinctId: distinctIdOrOptions,
			options
		};
		return {
			distinctId: this.context?.get()?.distinctId,
			options: distinctIdOrOptions
		};
	}
	async _getFeatureFlagResult(key, distinctId, options = {}, matchValue) {
		if (this.disabled) return void this._logger.warn("The client is disabled");
		const sendFeatureFlagEvents = options.sendFeatureFlagEvents ?? true;
		if (void 0 !== this._flagOverrides && key in this._flagOverrides) {
			const overrideValue = this._flagOverrides[key];
			if (void 0 === overrideValue) return;
			const overridePayload = this._payloadOverrides?.[key];
			return {
				key,
				enabled: false !== overrideValue,
				variant: "string" == typeof overrideValue ? overrideValue : void 0,
				payload: overridePayload
			};
		}
		const { groups, disableGeoip } = options;
		let { onlyEvaluateLocally, personProperties, groupProperties } = options;
		const adjustedProperties = this.addLocalPersonAndGroupProperties(distinctId, groups, personProperties, groupProperties);
		personProperties = adjustedProperties.allPersonProperties;
		groupProperties = adjustedProperties.allGroupProperties;
		const evaluationContext = this.createFeatureFlagEvaluationContext(distinctId, groups, personProperties, groupProperties);
		if (void 0 == onlyEvaluateLocally) onlyEvaluateLocally = this.options.strictLocalEvaluation ?? false;
		let result;
		let flagWasLocallyEvaluated = false;
		let requestId;
		let evaluatedAt;
		let featureFlagError;
		let flagId;
		let flagVersion;
		let flagReason;
		if (void 0 !== this.featureFlagsPoller) {
			await this.featureFlagsPoller?.loadFeatureFlags();
			const flag = this.featureFlagsPoller?.featureFlagsByKey[key];
			if (flag) try {
				const localResult = await this.featureFlagsPoller?.computeFlagAndPayloadLocally(flag, evaluationContext, { matchValue });
				if (localResult) {
					flagWasLocallyEvaluated = true;
					const value = localResult.value;
					flagId = flag.id;
					flagReason = "Evaluated locally";
					result = {
						key,
						enabled: false !== value,
						variant: "string" == typeof value ? value : void 0,
						payload: localResult.payload ?? void 0
					};
				}
			} catch (e) {
				if (e instanceof RequiresServerEvaluation || e instanceof InconclusiveMatchError) this._logger?.info(`${e.name} when computing flag locally: ${key}: ${e.message}`);
				else throw e;
			}
		}
		if (!flagWasLocallyEvaluated && !onlyEvaluateLocally) {
			const flagsResponse = await super.getFeatureFlagDetailsStateless(evaluationContext.distinctId, evaluationContext.groups, evaluationContext.personProperties, evaluationContext.groupProperties, disableGeoip, [key]);
			if (void 0 === flagsResponse) featureFlagError = FeatureFlagError.UNKNOWN_ERROR;
			else {
				requestId = flagsResponse.requestId;
				evaluatedAt = flagsResponse.evaluatedAt;
				const errors = [];
				if (flagsResponse.errorsWhileComputingFlags) errors.push(FeatureFlagError.ERRORS_WHILE_COMPUTING);
				if (flagsResponse.quotaLimited?.includes("feature_flags")) errors.push(FeatureFlagError.QUOTA_LIMITED);
				const flagDetail = flagsResponse.flags[key];
				if (void 0 === flagDetail) errors.push(FeatureFlagError.FLAG_MISSING);
				else {
					flagId = flagDetail.metadata?.id;
					flagVersion = flagDetail.metadata?.version;
					flagReason = flagDetail.reason?.description ?? flagDetail.reason?.code;
					let parsedPayload;
					if (flagDetail.metadata?.payload !== void 0) try {
						parsedPayload = JSON.parse(flagDetail.metadata.payload);
					} catch {
						parsedPayload = flagDetail.metadata.payload;
					}
					result = {
						key,
						enabled: flagDetail.enabled,
						variant: flagDetail.variant,
						payload: parsedPayload
					};
				}
				if (errors.length > 0) featureFlagError = errors.join(",");
			}
		}
		if (sendFeatureFlagEvents) {
			const response = void 0 === result ? void 0 : false === result.enabled ? false : result.variant ?? true;
			const properties = {
				$feature_flag: key,
				$feature_flag_response: response,
				$feature_flag_id: flagId,
				$feature_flag_version: flagVersion,
				$feature_flag_reason: flagReason,
				locally_evaluated: flagWasLocallyEvaluated,
				[`$feature/${key}`]: response,
				$feature_flag_request_id: requestId,
				$feature_flag_evaluated_at: flagWasLocallyEvaluated ? Date.now() : evaluatedAt
			};
			if (flagWasLocallyEvaluated && this.featureFlagsPoller) {
				const flagDefinitionsLoadedAt = this.featureFlagsPoller.getFlagDefinitionsLoadedAt();
				if (void 0 !== flagDefinitionsLoadedAt) properties.$feature_flag_definitions_loaded_at = flagDefinitionsLoadedAt;
			}
			if (featureFlagError) properties.$feature_flag_error = featureFlagError;
			this._captureFlagCalledEventIfNeeded({
				distinctId,
				key,
				response,
				groups,
				disableGeoip,
				properties
			});
		}
		if (void 0 !== result && void 0 !== this._payloadOverrides && key in this._payloadOverrides) result = {
			...result,
			payload: this._payloadOverrides[key]
		};
		return result;
	}
	async getFeatureFlag(key, distinctId, options) {
		emitDeprecationWarningOnce("getFeatureFlag", "`getFeatureFlag` is deprecated and will be removed in a future major version. Use `posthog.evaluateFlags(distinctId, ...)` and call `flags.getFlag(key)` instead \u2014 this consolidates flag evaluation into a single `/flags` request per incoming request.");
		const result = await this._getFeatureFlagResult(key, distinctId, {
			...options,
			sendFeatureFlagEvents: options?.sendFeatureFlagEvents ?? this.options.sendFeatureFlagEvent ?? true
		});
		if (void 0 === result) return;
		if (false === result.enabled) return false;
		return result.variant ?? true;
	}
	async getFeatureFlagPayload(key, distinctId, matchValue, options) {
		emitDeprecationWarningOnce("getFeatureFlagPayload", "`getFeatureFlagPayload` is deprecated and will be removed in a future major version. Use `posthog.evaluateFlags(distinctId, ...)` and call `flags.getFlagPayload(key)` instead \u2014 this consolidates flag evaluation into a single `/flags` request per incoming request.");
		if (void 0 !== this._payloadOverrides && key in this._payloadOverrides) return this._payloadOverrides[key];
		const result = await this._getFeatureFlagResult(key, distinctId, {
			...options,
			sendFeatureFlagEvents: false
		}, matchValue);
		if (void 0 === result) return;
		return result.payload ?? null;
	}
	async getFeatureFlagResult(key, distinctIdOrOptions, options) {
		const { distinctId: resolvedDistinctId, options: resolvedOptions } = this._resolveDistinctId(distinctIdOrOptions, options);
		if (!resolvedDistinctId) return void this._logger.warn("[PostHog] distinctId is required \u2014 pass it explicitly or use withContext()");
		return this._getFeatureFlagResult(key, resolvedDistinctId, {
			...resolvedOptions,
			sendFeatureFlagEvents: resolvedOptions?.sendFeatureFlagEvents ?? this.options.sendFeatureFlagEvent ?? true
		});
	}
	async getRemoteConfigPayload(flagKey) {
		if (this.disabled) return void this._logger.warn("The client is disabled");
		if (!this.options.personalApiKey) throw new Error("Personal API key is required for remote config payload decryption");
		const response = await this._requestRemoteConfigPayload(flagKey);
		if (!response) return;
		const parsed = await response.json();
		if ("string" == typeof parsed) try {
			return JSON.parse(parsed);
		} catch (e) {}
		return parsed;
	}
	async isFeatureEnabled(key, distinctId, options) {
		emitDeprecationWarningOnce("isFeatureEnabled", "`isFeatureEnabled` is deprecated and will be removed in a future major version. Use `posthog.evaluateFlags(distinctId, ...)` and call `flags.isEnabled(key)` instead \u2014 this consolidates flag evaluation into a single `/flags` request per incoming request.");
		const result = await this._getFeatureFlagResult(key, distinctId, {
			...options,
			sendFeatureFlagEvents: options?.sendFeatureFlagEvents ?? this.options.sendFeatureFlagEvent ?? true
		});
		if (void 0 === result) return;
		if (false === result.enabled) return false;
		return !!(result.variant ?? true) || false;
	}
	async getAllFlags(distinctIdOrOptions, options) {
		const { distinctId: resolvedDistinctId, options: resolvedOptions } = this._resolveDistinctId(distinctIdOrOptions, options);
		if (!resolvedDistinctId) {
			this._logger.warn("[PostHog] distinctId is required to get feature flags \u2014 pass it explicitly or use withContext()");
			return {};
		}
		return (await this.getAllFlagsAndPayloads(resolvedDistinctId, resolvedOptions)).featureFlags || {};
	}
	async getAllFlagsAndPayloads(distinctIdOrOptions, options) {
		const { distinctId: resolvedDistinctId, options: resolvedOptions } = this._resolveDistinctId(distinctIdOrOptions, options);
		if (!resolvedDistinctId) {
			this._logger.warn("[PostHog] distinctId is required to get feature flags and payloads \u2014 pass it explicitly or use withContext()");
			return {
				featureFlags: {},
				featureFlagPayloads: {}
			};
		}
		if (this.disabled) {
			this._logger.warn("The client is disabled");
			return {
				featureFlags: {},
				featureFlagPayloads: {}
			};
		}
		const { groups, disableGeoip, flagKeys } = resolvedOptions || {};
		let { onlyEvaluateLocally, personProperties, groupProperties } = resolvedOptions || {};
		const adjustedProperties = this.addLocalPersonAndGroupProperties(resolvedDistinctId, groups, personProperties, groupProperties);
		personProperties = adjustedProperties.allPersonProperties;
		groupProperties = adjustedProperties.allGroupProperties;
		const evaluationContext = this.createFeatureFlagEvaluationContext(resolvedDistinctId, groups, personProperties, groupProperties);
		if (void 0 == onlyEvaluateLocally) onlyEvaluateLocally = this.options.strictLocalEvaluation ?? false;
		const localEvaluationResult = await this.featureFlagsPoller?.getAllFlagsAndPayloads(evaluationContext, flagKeys);
		let featureFlags = {};
		let featureFlagPayloads = {};
		let fallbackToFlags = true;
		if (localEvaluationResult) {
			featureFlags = localEvaluationResult.response;
			featureFlagPayloads = localEvaluationResult.payloads;
			fallbackToFlags = localEvaluationResult.fallbackToFlags;
		}
		if (fallbackToFlags && !onlyEvaluateLocally) {
			const remoteEvaluationResult = await super.getFeatureFlagsAndPayloadsStateless(evaluationContext.distinctId, evaluationContext.groups, evaluationContext.personProperties, evaluationContext.groupProperties, disableGeoip, flagKeys);
			featureFlags = {
				...featureFlags,
				...remoteEvaluationResult.flags || {}
			};
			featureFlagPayloads = {
				...featureFlagPayloads,
				...remoteEvaluationResult.payloads || {}
			};
		}
		if (void 0 !== this._flagOverrides) featureFlags = {
			...featureFlags,
			...this._flagOverrides
		};
		if (void 0 !== this._payloadOverrides) featureFlagPayloads = {
			...featureFlagPayloads,
			...this._payloadOverrides
		};
		return {
			featureFlags,
			featureFlagPayloads
		};
	}
	async evaluateFlags(distinctIdOrOptions, options) {
		const { distinctId: resolvedDistinctId, options: resolvedOptions } = this._resolveDistinctId(distinctIdOrOptions, options);
		if (!resolvedDistinctId) {
			this._logger.warn("[PostHog] distinctId is required to evaluate feature flags \u2014 pass it explicitly or use withContext()");
			return new FeatureFlagEvaluations({
				host: this._getFeatureFlagEvaluationsHost(),
				distinctId: "",
				flags: {}
			});
		}
		if (this.disabled) {
			this._logger.warn("The client is disabled");
			return new FeatureFlagEvaluations({
				host: this._getFeatureFlagEvaluationsHost(),
				distinctId: resolvedDistinctId,
				flags: {}
			});
		}
		const { groups, disableGeoip, flagKeys } = resolvedOptions || {};
		let { onlyEvaluateLocally, personProperties, groupProperties } = resolvedOptions || {};
		const adjustedProperties = this.addLocalPersonAndGroupProperties(resolvedDistinctId, groups, personProperties, groupProperties);
		personProperties = adjustedProperties.allPersonProperties;
		groupProperties = adjustedProperties.allGroupProperties;
		const evaluationContext = this.createFeatureFlagEvaluationContext(resolvedDistinctId, groups, personProperties, groupProperties);
		if (void 0 == onlyEvaluateLocally) onlyEvaluateLocally = this.options.strictLocalEvaluation ?? false;
		const records = {};
		let requestId;
		let evaluatedAt;
		let errorsWhileComputing = false;
		let quotaLimited = false;
		const localResult = await this.featureFlagsPoller?.getAllFlagsAndPayloads(evaluationContext, flagKeys);
		const locallyEvaluatedKeys = /* @__PURE__ */ new Set();
		if (localResult) for (const [key, value] of Object.entries(localResult.response)) {
			const flagDef = this.featureFlagsPoller?.featureFlagsByKey[key];
			records[key] = {
				key,
				enabled: false !== value,
				variant: "string" == typeof value ? value : void 0,
				payload: localResult.payloads[key],
				id: flagDef?.id,
				version: void 0,
				reason: "Evaluated locally",
				locallyEvaluated: true
			};
			locallyEvaluatedKeys.add(key);
		}
		if ((localResult ? localResult.fallbackToFlags : true) && !onlyEvaluateLocally) {
			const details = await super.getFeatureFlagDetailsStateless(evaluationContext.distinctId, evaluationContext.groups, evaluationContext.personProperties, evaluationContext.groupProperties, disableGeoip, flagKeys);
			if (details) {
				requestId = details.requestId;
				evaluatedAt = details.evaluatedAt;
				errorsWhileComputing = Boolean(details.errorsWhileComputingFlags);
				quotaLimited = Array.isArray(details.quotaLimited) && details.quotaLimited.includes("feature_flags");
				for (const [key, detail] of Object.entries(details.flags)) {
					if (locallyEvaluatedKeys.has(key)) continue;
					let parsedPayload;
					if (detail.metadata?.payload !== void 0) try {
						parsedPayload = JSON.parse(detail.metadata.payload);
					} catch {
						parsedPayload = detail.metadata.payload;
					}
					records[key] = {
						key,
						enabled: detail.enabled,
						variant: detail.variant,
						payload: parsedPayload,
						id: detail.metadata?.id,
						version: detail.metadata?.version,
						reason: detail.reason?.description ?? detail.reason?.code,
						locallyEvaluated: false
					};
				}
			}
		}
		if (void 0 !== this._flagOverrides) for (const [key, value] of Object.entries(this._flagOverrides)) {
			if (void 0 === value) {
				delete records[key];
				continue;
			}
			const existing = records[key];
			records[key] = {
				key,
				enabled: false !== value,
				variant: "string" == typeof value ? value : void 0,
				payload: existing?.payload,
				id: existing?.id,
				version: existing?.version,
				reason: existing?.reason,
				locallyEvaluated: existing?.locallyEvaluated ?? false
			};
		}
		if (void 0 !== this._payloadOverrides) for (const [key, payload] of Object.entries(this._payloadOverrides)) {
			const existing = records[key];
			if (existing) records[key] = {
				...existing,
				payload
			};
		}
		return new FeatureFlagEvaluations({
			host: this._getFeatureFlagEvaluationsHost(),
			distinctId: resolvedDistinctId,
			groups,
			disableGeoip,
			flags: records,
			requestId,
			evaluatedAt,
			flagDefinitionsLoadedAt: this.featureFlagsPoller?.getFlagDefinitionsLoadedAt(),
			errorsWhileComputing,
			quotaLimited
		});
	}
	_captureFlagCalledEventIfNeeded(params) {
		const { distinctId, key, response, groups, disableGeoip, properties } = params;
		const featureFlagReportedKey = `${key}_${response}${groups && Object.keys(groups).length > 0 ? `_${JSON.stringify(Object.entries(groups).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0))}` : ""}`;
		if (distinctId in this.distinctIdHasSentFlagCalls && this.distinctIdHasSentFlagCalls[distinctId].has(featureFlagReportedKey)) return;
		if (Object.keys(this.distinctIdHasSentFlagCalls).length >= this.maxCacheSize) this.distinctIdHasSentFlagCalls = {};
		if (this.distinctIdHasSentFlagCalls[distinctId] instanceof Set) this.distinctIdHasSentFlagCalls[distinctId].add(featureFlagReportedKey);
		else this.distinctIdHasSentFlagCalls[distinctId] = /* @__PURE__ */ new Set([featureFlagReportedKey]);
		this.capture({
			distinctId,
			event: "$feature_flag_called",
			properties,
			groups,
			disableGeoip
		});
	}
	_getFeatureFlagEvaluationsHost() {
		if (!this._featureFlagEvaluationsHost) this._featureFlagEvaluationsHost = {
			captureFlagCalledEventIfNeeded: (params) => this._captureFlagCalledEventIfNeeded(params),
			logWarning: (message) => {
				if (false !== this.options.featureFlagsLogWarnings) console.warn(`[PostHog] ${message}`);
			}
		};
		return this._featureFlagEvaluationsHost;
	}
	groupIdentify({ groupType, groupKey, properties, distinctId, disableGeoip }) {
		super.groupIdentifyStateless(groupType, groupKey, properties, { disableGeoip }, distinctId);
	}
	async reloadFeatureFlags() {
		await this.featureFlagsPoller?.loadFeatureFlags(true);
	}
	overrideFeatureFlags(overrides) {
		const flagArrayToRecord = (flags) => Object.fromEntries(flags.map((f) => [f, true]));
		if (false === overrides) {
			this._flagOverrides = void 0;
			this._payloadOverrides = void 0;
			return;
		}
		if (Array.isArray(overrides)) {
			this._flagOverrides = flagArrayToRecord(overrides);
			return;
		}
		if (this._isFeatureFlagOverrideOptions(overrides)) {
			if ("flags" in overrides) {
				if (false === overrides.flags) this._flagOverrides = void 0;
				else if (Array.isArray(overrides.flags)) this._flagOverrides = flagArrayToRecord(overrides.flags);
				else if (void 0 !== overrides.flags) this._flagOverrides = { ...overrides.flags };
			}
			if ("payloads" in overrides) {
				if (false === overrides.payloads) this._payloadOverrides = void 0;
				else if (void 0 !== overrides.payloads) this._payloadOverrides = { ...overrides.payloads };
			}
			return;
		}
		this._flagOverrides = { ...overrides };
	}
	_isFeatureFlagOverrideOptions(overrides) {
		if ("object" != typeof overrides || null === overrides || Array.isArray(overrides)) return false;
		const obj = overrides;
		if ("flags" in obj) {
			const flagsValue = obj["flags"];
			if (false === flagsValue || Array.isArray(flagsValue) || "object" == typeof flagsValue && null !== flagsValue) return true;
		}
		if ("payloads" in obj) {
			const payloadsValue = obj["payloads"];
			if (false === payloadsValue || "object" == typeof payloadsValue && null !== payloadsValue) return true;
		}
		return false;
	}
	withContext(data, fn, options) {
		if (!this.context) return fn();
		return this.context.run(data, fn, options);
	}
	getContext() {
		return this.context?.get();
	}
	enterContext(data, options) {
		this.context?.enter(data, options);
	}
	async _shutdown(shutdownTimeoutMs) {
		const resolve = this._consumeWaitUntilCycle();
		await this.featureFlagsPoller?.stopPoller(shutdownTimeoutMs);
		this.errorTracking.shutdown();
		try {
			return await super._shutdown(shutdownTimeoutMs);
		} finally {
			this.distinctIdHasSentFlagCalls = {};
			resolve?.();
		}
	}
	async _requestRemoteConfigPayload(flagKey) {
		if (this.disabled || !this.apiKey || !this.options.personalApiKey) return;
		const url = `${this.host}/api/projects/@current/feature_flags/${flagKey}/remote_config?token=${encodeURIComponent(this.apiKey)}`;
		const options = {
			method: "GET",
			headers: {
				...this.getCustomHeaders(),
				"Content-Type": "application/json",
				Authorization: `Bearer ${this.options.personalApiKey}`
			}
		};
		let abortTimeout = null;
		if (this.options.requestTimeout && "number" == typeof this.options.requestTimeout) {
			const controller = new AbortController();
			abortTimeout = safeSetTimeout(() => {
				controller.abort();
			}, this.options.requestTimeout);
			options.signal = controller.signal;
		}
		try {
			return await this.fetch(url, options);
		} catch (error) {
			this._events.emit("error", error);
			return;
		} finally {
			if (abortTimeout) clearTimeout(abortTimeout);
		}
	}
	extractPropertiesFromEvent(eventProperties, groups) {
		if (!eventProperties) return {
			personProperties: {},
			groupProperties: {}
		};
		const personProperties = {};
		const groupProperties = {};
		for (const [key, value] of Object.entries(eventProperties)) if (isPlainObject(value) && groups && key in groups) {
			const groupProps = {};
			for (const [groupKey, groupValue] of Object.entries(value)) groupProps[String(groupKey)] = String(groupValue);
			groupProperties[String(key)] = groupProps;
		} else personProperties[String(key)] = String(value);
		return {
			personProperties,
			groupProperties
		};
	}
	async getFeatureFlagsForEvent(distinctId, groups, disableGeoip, sendFeatureFlagsOptions) {
		if (this.disabled || !this.apiKey) return void this._logger.warn("The client is disabled");
		const finalPersonProperties = sendFeatureFlagsOptions?.personProperties || {};
		const finalGroupProperties = sendFeatureFlagsOptions?.groupProperties || {};
		const flagKeys = sendFeatureFlagsOptions?.flagKeys;
		if (sendFeatureFlagsOptions?.onlyEvaluateLocally ?? this.options.strictLocalEvaluation ?? false) if (!((this.featureFlagsPoller?.featureFlags?.length || 0) > 0)) return {};
		else {
			const groupsWithStringValues = {};
			for (const [key, value] of Object.entries(groups || {})) groupsWithStringValues[key] = String(value);
			return await this.getAllFlags(distinctId, {
				groups: groupsWithStringValues,
				personProperties: finalPersonProperties,
				groupProperties: finalGroupProperties,
				disableGeoip,
				onlyEvaluateLocally: true,
				flagKeys
			});
		}
		if ((this.featureFlagsPoller?.featureFlags?.length || 0) > 0) {
			const groupsWithStringValues = {};
			for (const [key, value] of Object.entries(groups || {})) groupsWithStringValues[key] = String(value);
			return await this.getAllFlags(distinctId, {
				groups: groupsWithStringValues,
				personProperties: finalPersonProperties,
				groupProperties: finalGroupProperties,
				disableGeoip,
				onlyEvaluateLocally: true,
				flagKeys
			});
		}
		return (await super.getFeatureFlagsStateless(distinctId, groups, finalPersonProperties, finalGroupProperties, disableGeoip)).flags;
	}
	addLocalPersonAndGroupProperties(distinctId, groups, personProperties, groupProperties) {
		const allPersonProperties = {
			distinct_id: distinctId,
			...personProperties || {}
		};
		const allGroupProperties = {};
		if (groups) for (const groupName of Object.keys(groups)) allGroupProperties[groupName] = {
			$group_key: groups[groupName],
			...groupProperties?.[groupName] || {}
		};
		return {
			allPersonProperties,
			allGroupProperties
		};
	}
	createFeatureFlagEvaluationContext(distinctId, groups, personProperties, groupProperties) {
		return {
			distinctId,
			groups: groups || {},
			personProperties: personProperties || {},
			groupProperties: groupProperties || {},
			evaluationCache: {}
		};
	}
	captureException(error, distinctId, additionalProperties, uuid, flags) {
		if (!ErrorTracking.isPreviouslyCapturedError(error)) {
			const syntheticException = /* @__PURE__ */ new Error("PostHog syntheticException");
			this.addPendingPromise(ErrorTracking.buildEventMessage(this.getErrorPropertiesBuilder(), error, { syntheticException }, distinctId, additionalProperties).then((msg) => this.capture({
				...msg,
				uuid,
				flags
			})));
		}
	}
	async captureExceptionImmediate(error, distinctId, additionalProperties, flags) {
		if (!ErrorTracking.isPreviouslyCapturedError(error)) {
			const syntheticException = /* @__PURE__ */ new Error("PostHog syntheticException");
			return this.addPendingPromise(ErrorTracking.buildEventMessage(this.getErrorPropertiesBuilder(), error, { syntheticException }, distinctId, additionalProperties).then((msg) => this.captureImmediate({
				...msg,
				flags
			})));
		}
	}
	async prepareEventMessage(props) {
		const { distinctId, event, properties, groups, flags, sendFeatureFlags, timestamp, disableGeoip, uuid } = props;
		const contextData = this.context?.get();
		let mergedDistinctId = distinctId || contextData?.distinctId;
		const mergedProperties = {
			...this.props,
			...contextData?.properties || {},
			...properties || {}
		};
		if (!mergedDistinctId) {
			mergedDistinctId = uuidv7();
			mergedProperties.$process_person_profile = false;
		}
		if (contextData?.sessionId && !mergedProperties.$session_id) mergedProperties.$session_id = contextData.sessionId;
		const eventMessage = this._runBeforeSend({
			distinctId: mergedDistinctId,
			event,
			properties: mergedProperties,
			groups,
			flags,
			sendFeatureFlags,
			timestamp,
			disableGeoip,
			uuid
		});
		if (!eventMessage) return Promise.reject(null);
		const eventProperties = await Promise.resolve().then(async () => {
			if (flags) {
				if (sendFeatureFlags) console.warn("[PostHog] Both `flags` and `sendFeatureFlags` were passed to capture(); using `flags` and ignoring `sendFeatureFlags`.");
				return flags._getEventProperties();
			}
			if (sendFeatureFlags) {
				emitDeprecationWarningOnce("sendFeatureFlags", "`sendFeatureFlags` is deprecated and will be removed in a future major version. Pass a `flags` snapshot from `posthog.evaluateFlags(...)` instead \u2014 it avoids a second `/flags` request per capture and guarantees the event carries the exact flag values your code branched on.");
				const sendFeatureFlagsOptions = "object" == typeof sendFeatureFlags ? sendFeatureFlags : void 0;
				return buildFlagEventProperties(await this.getFeatureFlagsForEvent(eventMessage.distinctId, groups, disableGeoip, sendFeatureFlagsOptions));
			}
			return {};
		}).catch(() => ({})).then((additionalProperties) => {
			const resolvedGroups = eventMessage.groups || groups;
			return {
				...additionalProperties,
				...eventMessage.properties || {},
				...void 0 !== resolvedGroups && Object.keys(resolvedGroups).length > 0 ? { $groups: resolvedGroups } : {}
			};
		});
		if ("$pageview" === eventMessage.event && this.options.__preview_capture_bot_pageviews && "string" == typeof eventProperties.$raw_user_agent) {
			if (isBlockedUA(eventProperties.$raw_user_agent, this.options.custom_blocked_useragents || [])) {
				eventMessage.event = "$bot_pageview";
				eventProperties.$browser_type = "bot";
			}
		}
		return {
			distinctId: eventMessage.distinctId,
			event: eventMessage.event,
			properties: eventProperties,
			options: {
				timestamp: eventMessage.timestamp,
				disableGeoip: eventMessage.disableGeoip,
				uuid: eventMessage.uuid
			}
		};
	}
	_runBeforeSend(eventMessage) {
		const beforeSend = this.options.before_send;
		if (!beforeSend) return eventMessage;
		const fns = Array.isArray(beforeSend) ? beforeSend : [beforeSend];
		let result = eventMessage;
		for (const fn of fns) {
			result = fn(result);
			if (!result) {
				this._logger.info(`Event '${eventMessage.event}' was rejected in beforeSend function`);
				return null;
			}
			if (!result.properties || 0 === Object.keys(result.properties).length) {
				const message = `Event '${result.event}' has no properties after beforeSend function, this is likely an error.`;
				this._logger.warn(message);
			}
		}
		return result;
	}
};
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/extensions/sentry-integration.mjs
var NAME = "posthog-node";
function createEventProcessor(_posthog, { organization, projectId, prefix, severityAllowList = ["error"], sendExceptionsToPostHog = true } = {}) {
	return (event) => {
		if (!("*" === severityAllowList || severityAllowList.includes(event.level))) return event;
		if (!event.tags) event.tags = {};
		const userId = event.tags[PostHogSentryIntegration.POSTHOG_ID_TAG];
		if (void 0 === userId) return event;
		const uiHost = _posthog.options.host ?? "https://us.i.posthog.com";
		const personUrl = new URL(`/project/${_posthog.apiKey}/person/${userId}`, uiHost).toString();
		event.tags["PostHog Person URL"] = personUrl;
		const exceptions = event.exception?.values || [];
		const exceptionList = exceptions.map((exception) => ({
			...exception,
			stacktrace: exception.stacktrace ? {
				...exception.stacktrace,
				type: "raw",
				frames: (exception.stacktrace.frames || []).map((frame) => ({
					...frame,
					platform: "node:javascript"
				}))
			} : void 0
		}));
		const properties = {
			$exception_message: exceptions[0]?.value || event.message,
			$exception_type: exceptions[0]?.type,
			$exception_level: event.level,
			$exception_list: exceptionList,
			$sentry_event_id: event.event_id,
			$sentry_exception: event.exception,
			$sentry_exception_message: exceptions[0]?.value || event.message,
			$sentry_exception_type: exceptions[0]?.type,
			$sentry_tags: event.tags
		};
		if (organization && projectId) properties["$sentry_url"] = (prefix || "https://sentry.io/organizations/") + organization + "/issues/?project=" + projectId + "&query=" + event.event_id;
		if (sendExceptionsToPostHog) _posthog.capture({
			event: "$exception",
			distinctId: userId,
			properties
		});
		return event;
	};
}
var PostHogSentryIntegration = class {
	static #_ = this.POSTHOG_ID_TAG = "posthog_distinct_id";
	constructor(_posthog, organization, prefix, severityAllowList, sendExceptionsToPostHog) {
		this.name = NAME;
		this.name = NAME;
		this.setupOnce = function(addGlobalEventProcessor, getCurrentHub) {
			const projectId = getCurrentHub()?.getClient()?.getDsn()?.projectId;
			addGlobalEventProcessor(createEventProcessor(_posthog, {
				organization,
				projectId,
				prefix,
				severityAllowList,
				sendExceptionsToPostHog: sendExceptionsToPostHog ?? true
			}));
		};
	}
};
//#endregion
//#region node_modules/.pnpm/posthog-node@5.38.6/node_modules/posthog-node/dist/entrypoints/index.edge.mjs
var PostHog = class extends PostHogBackendClient {
	getLibraryId() {
		return "posthog-edge";
	}
	initializeContext() {}
	createErrorPropertiesBuilder() {
		return new ErrorPropertiesBuilder([
			new EventCoercer(),
			new ErrorCoercer(),
			new ObjectCoercer(),
			new StringCoercer(),
			new PrimitiveCoercer()
		], createStackParser("node:javascript", nodeStackLineParser));
	}
};
//#endregion
//#region src/server/lib/posthog.ts
/** Returns a one-shot PostHog client, or null if the key is missing. Caller must shut down after use.
*  A new instance per call is fine \u2014 this runs on Cloudflare Workers where construction cost is negligible. */
function getServerPostHogClient() {
	const apiKey = env.POSTHOG_PUBLIC_KEY?.trim();
	const host = env.POSTHOG_HOST?.trim();
	if (!apiKey || !host) return null;
	return new PostHog(apiKey, {
		host,
		flushAt: 1,
		flushInterval: 0
	});
}
/**
* The error as error tracking receives it: its type, AppError code and stack
* frames, never its message. Messages can quote customer content (DataForSEO
* echoes request params, failed queries print their values, model errors
* include output), so call sites log the full error to Cloudflare instead.
* In the message's place goes a code safe to show: the AppError code, else
* the status or code the error carries (GscApiError's 403, a Postgres
* SQLSTATE), else the cause's, so issues and their alerts never read blank.
*/
function withoutMessage(error, depth = 0) {
	if (!(error instanceof Error)) {
		const redacted = new Error(asAppError(error)?.code ?? REDACTED);
		redacted.stack = `Error: ${redacted.message}`;
		return redacted;
	}
	const cause = error.cause !== void 0 && depth < 4 ? withoutMessage(error.cause, depth + 1) : void 0;
	const redacted = new Error(asAppError(error)?.code ?? safeCode(error) ?? cause?.message ?? REDACTED);
	redacted.name = error.name;
	const frames = (error.stack ?? "").split("\n").filter((line) => /^\s+at /.test(line));
	redacted.stack = [`${error.name}: ${redacted.message}`, ...frames].join("\n");
	if (cause) redacted.cause = cause;
	return redacted;
}
var REDACTED = "message redacted";
function safeCode(error) {
	for (const key of ["code", "status"]) {
		const value = Reflect.get(error, key);
		if (typeof value === "number") return String(value);
		if (typeof value === "string" && /^[A-Z0-9_]{1,40}$/.test(value)) return value;
	}
}
/**
* `distinctId` must be the better-auth user id, the same identity
* identifyAnalyticsUser and captureServerEvent send, so exceptions land on the
* existing person profile. Omitting it makes posthog-node mint a fresh anonymous
* id per event, so every error reports as many users affected as it has events.
*/
async function captureServerError(error, properties = {}, distinctId) {
	if (!await isHostedServerAuthMode()) return;
	const client = getServerPostHogClient();
	if (!client) return;
	try {
		await client.captureExceptionImmediate(withoutMessage(error), distinctId, {
			source: "server",
			...properties
		});
	} catch (posthogError) {
		console.error("posthog server capture failed", posthogError);
	} finally {
		await client.shutdown().catch(() => {});
	}
}
async function captureServerEvent(args) {
	if (!await isHostedServerAuthMode()) return;
	const client = getServerPostHogClient();
	if (!client) return;
	try {
		const [{ withPgClient }, { AuthRepository }] = await Promise.all([import("./assets/db-DUti_knk.js").then((n) => n.n), import("./assets/AuthRepository-FUwYaI8k.js")]);
		if (await withPgClient(() => AuthRepository.isAnalyticsOptedOut(args.distinctId))) return;
		client.capture({
			distinctId: args.distinctId,
			event: args.event,
			properties: args.properties,
			groups: args.organizationId ? { organization: args.organizationId } : void 0
		});
	} catch (posthogError) {
		console.error("posthog server capture failed", posthogError);
	} finally {
		await client.shutdown().catch(() => {});
	}
}
//#endregion
//#region src/shared/guest-account.ts
var GUEST_EMAIL_DOMAIN = "guest.openseo.invalid";
function isGuestEmail(email) {
	return Boolean(email?.toLowerCase().endsWith(`@${GUEST_EMAIL_DOMAIN}`));
}
//#endregion
//#region src/server/email/loops-client.ts
var LOOPS_EVENT_SEND_URL = "https://app.loops.so/api/v1/events/send";
/** Sends a Loops event, which triggers any workflow listening for it. Loops
*  honours the idempotency key for 24 hours and answers a replay with 409,
*  which is a success here: the email was already queued. Returns whether
*  this call was such a replay. */
async function sendLoopsEvent({ apiKey, payload, idempotencyKey, logContext }) {
	return { duplicate: await loopsRequest({
		apiKey,
		method: "POST",
		url: LOOPS_EVENT_SEND_URL,
		payload,
		headers: { "Idempotency-Key": idempotencyKey },
		okStatuses: [409],
		label: "send Loops event",
		logContext: {
			...logContext,
			eventName: payload.eventName
		}
	}) === 409 };
}
async function loopsRequest({ apiKey, method, url, payload, headers, okStatuses = [], label, logContext }) {
	if (isGuestEmail(payload.email)) return 200;
	const response = await fetch(url, {
		method,
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`,
			...headers
		},
		body: JSON.stringify(payload),
		signal: AbortSignal.timeout(1e4)
	});
	if (response.ok || okStatuses.includes(response.status)) return response.status;
	const errorPayload = await response.json().catch(() => null);
	console.warn(`Loops error (${label}):`, {
		status: response.status,
		email: payload.email,
		userId: payload.userId,
		...logContext,
		errorPayload
	});
	throw new Error(`Failed to ${label} (${response.status})`);
}
//#endregion
//#region src/server/email/onboarding-drip.ts
var SCHEDULED_RUN_USER_ID = "system";
async function sendCreditsExhaustedEvent(customer) {
	const recipient = customer.userId === SCHEDULED_RUN_USER_ID ? await findOrganizationOwner(customer.organizationId) : customer;
	if (!recipient) return;
	const key = `credits_exhausted:${recipient.userId}:${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}`;
	await sendOnce(key, (apiKey) => sendLoopsEvent({
		apiKey,
		idempotencyKey: key,
		payload: {
			email: recipient.userEmail,
			userId: recipient.userId,
			eventName: "credits_exhausted"
		}
	}));
}
async function findOrganizationOwner(organizationId) {
	try {
		const [{ withPgClient }, { AuthRepository }] = await Promise.all([import("./assets/db-DUti_knk.js").then((n) => n.n), import("./assets/AuthRepository-FUwYaI8k.js")]);
		const owner = await withPgClient(() => AuthRepository.getOrganizationOwner(organizationId));
		return owner ? {
			userId: owner.id,
			userEmail: owner.email
		} : null;
	} catch (error) {
		console.error("onboarding drip: organization owner lookup failed", error);
		return null;
	}
}
var sentKeys = /* @__PURE__ */ new Set();
async function sendOnce(key, send) {
	if (sentKeys.has(key)) return;
	const apiKey = await getOptionalEnvValue("LOOPS_API_KEY");
	if (!apiKey) return;
	sentKeys.add(key);
	const work = send(apiKey).catch((error) => {
		console.error(`onboarding drip: ${key} failed`, error);
	});
	try {
		waitUntil(work);
	} catch {
		await work;
	}
}
//#endregion
//#region src/server/billing/subscription.ts
var CUSTOMER_ENSURED_TTL_SECONDS = 86400;
var customerEnsuredKey = (organizationId) => `autumn:customer-ensured:${organizationId}`;
async function getOrCreateOrganizationCustomer(context) {
	const cacheKey = customerEnsuredKey(context.organizationId);
	try {
		if (await env.KV.get(cacheKey)) return { id: context.organizationId };
	} catch (error) {
		console.warn("billing.customer-cache-read failed:", error);
	}
	const customer = await autumn.customers.getOrCreate({
		customerId: context.organizationId,
		email: context.userEmail
	});
	if (!customer.id) throw new AppError("INTERNAL_ERROR", "Failed to resolve billing customer");
	try {
		await env.KV.put(cacheKey, "1", { expirationTtl: CUSTOMER_ENSURED_TTL_SECONDS });
	} catch (error) {
		console.warn("billing.customer-cache-write failed:", error);
	}
	return { id: customer.id };
}
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
var HOLD_TTL_MS = 18e5;
/**
* Atomically holds `credits` on one balance feature. Autumn refuses the hold
* (allowed: false) when the balance is short, so concurrent calls cannot all
* pass on the same reading the way a plain balance check lets them.
*
* The SDK fails open on a failed request (timeout, 5xx) with `allowed: true,
* balance: null`, including one Autumn actually processed; that is a broken
* read, not a wallet, so retry it once and then fail closed. The retry reuses
* the lockId: a 409 `lock_already_exists` means the first hold landed (a
* refusal creates no lock), so the call proceeds on it instead of stranding a
* second hold for HOLD_TTL_MS. The SDK's own 5xx retry is off
* (AUTUMN_TRACK_RETRY_OPTIONS): it would replay a lock Autumn already took
* and throw that 409 from the first attempt, where nothing catches it. An
* absent feature reads `allowed: false, balance: null` and is a genuine
* refusal.
*/
async function holdCredits(args) {
	const { customerId, featureId, estimatedCredits, callIndexes, properties, ttlMs = HOLD_TTL_MS, lockPrefix = "dfs" } = args;
	const lockId = `${lockPrefix}_${customerId}_${crypto.randomUUID()}`;
	const hold = {
		lockId,
		featureId,
		estimatedCredits,
		callIndexes
	};
	const attempt = () => autumn.check({
		customerId,
		featureId,
		requiredBalance: estimatedCredits,
		sendEvent: true,
		properties,
		lock: {
			lockId,
			enabled: true,
			expiresAt: Date.now() + ttlMs
		}
	}, AUTUMN_TRACK_RETRY_OPTIONS);
	let result = await attempt();
	if (result.allowed && !result.balance) {
		await sleep(300);
		try {
			result = await attempt();
		} catch (error) {
			if (!errorBodyIncludes(error, "lock_already_exists")) throw error;
			return {
				hold,
				allowed: true,
				balance: null
			};
		}
	}
	if (result.allowed && !result.balance) throw new AppError("INTERNAL_ERROR", `Autumn check returned no ${featureId} balance for customer ${customerId}`);
	return {
		hold,
		allowed: result.allowed,
		balance: result.balance
	};
}
/**
* Reserves credits for a batch of provider calls before they are made, from
* one estimate per call, and places each call where a hold of its own would
* land: in order, on monthly `usage_credits` while they cover it, else on
* `topup_credits`, else the call is refused. At most one hold per pool, so
* the common case (monthly covers the batch) is a single Autumn request.
*
* Throws INSUFFICIENT_CREDITS when no call fits; `refusedCalls` lists the
* ones that did not when some did. Either way the refusal event and the
* credits-exhausted email event are sent. A top-up balance that covers the
* estimate and still refuses is the organization's monthly auto-reload
* budget (Autumn's usage limit): the error says so, as nothing but raising
* it or the next cycle helps.
* The caller must settle every returned hold with `settleUsageCredits` once
* its calls' real cost is known.
*/
async function reserveUsageCredits(args) {
	const callCredits = args.callCredits.map((credits) => Math.max(1, credits));
	const allCalls = callCredits.map((_, index) => index);
	const creditsFor = (calls) => calls.reduce((sum, index) => sum + callCredits[index], 0);
	const properties = {
		creditFeature: args.creditFeature,
		projectId: args.customer.projectId,
		provider: "dataforseo",
		estimatedCredits: creditsFor(allCalls)
	};
	const holdFitting = async (featureId, calls, remaining = Infinity) => {
		const fitting = [];
		let credits = 0;
		for (const index of calls) {
			if (credits + callCredits[index] > remaining) continue;
			fitting.push(index);
			credits += callCredits[index];
		}
		if (fitting.length === 0) return null;
		return holdCredits({
			customerId: args.customerId,
			featureId,
			estimatedCredits: credits,
			callIndexes: fitting,
			properties,
			ttlMs: args.ttlMs
		});
	};
	const holds = [];
	let monthlyRemaining = 0;
	let topupRemaining = 0;
	let budgetReached = false;
	let refusedCalls = [];
	try {
		const monthly = await holdFitting(AUTUMN_SEO_DATA_BALANCE_FEATURE_ID, allCalls);
		if (monthly?.allowed) return {
			holds: [monthly.hold],
			refusedCalls
		};
		monthlyRemaining = monthly?.balance?.remaining ?? 0;
		const partial = await holdFitting(AUTUMN_SEO_DATA_BALANCE_FEATURE_ID, allCalls, monthlyRemaining);
		if (partial?.allowed) holds.push(partial.hold);
		const topupCalls = allCalls.filter((index) => !holds.some((hold) => hold.callIndexes.includes(index)));
		let topup = await holdFitting(AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID, topupCalls);
		if (topup && !topup.allowed) {
			topupRemaining = topup.balance?.remaining ?? 0;
			budgetReached = topupRemaining >= creditsFor(topupCalls);
			if (!budgetReached) {
				topup = await holdFitting(AUTUMN_SEO_DATA_TOPUP_BALANCE_FEATURE_ID, topupCalls, topupRemaining);
				if (topup && !topup.allowed) budgetReached = (topup.balance?.remaining ?? 0) >= topup.hold.estimatedCredits;
			}
		}
		if (topup?.allowed) holds.push(topup.hold);
		refusedCalls = allCalls.filter((index) => !holds.some((hold) => hold.callIndexes.includes(index)));
	} catch (error) {
		for (const hold of holds) await settleUsageCredits({
			customer: args.customer,
			hold,
			costs: []
		});
		throw error;
	}
	if (refusedCalls.length > 0) {
		await captureServerEvent({
			distinctId: args.customer.userId,
			event: "usage:credits_gate_refused",
			organizationId: args.customer.organizationId,
			properties: {
				project_id: args.customer.projectId,
				reason: budgetReached ? "monthly_budget_reached" : "estimate_exceeds_balance",
				source: "dataforseo",
				credit_feature: args.creditFeature,
				estimated_credits: creditsFor(refusedCalls),
				monthly_remaining: monthlyRemaining,
				topup_remaining: topupRemaining
			}
		});
		if (!budgetReached) await sendCreditsExhaustedEvent(args.customer);
	}
	if (holds.length === 0) throw new AppError("INSUFFICIENT_CREDITS", budgetReached ? "The organization has hit its monthly auto-reload budget, so its top-up credits are paused until the owner raises it or the billing cycle resets." : void 0);
	return {
		holds,
		refusedCalls
	};
}
function errorBodyIncludes(error, text) {
	return error instanceof Error && "body" in error && typeof error.body === "string" && error.body.includes(text);
}
/**
* Confirms `credits` against a hold (Autumn deducts that amount, above or
* below the hold, and returns the rest), or releases the hold when `credits`
* is 0. Retries once. `landed: false` means the deduction may be lost; the
* hold then expires at its TTL.
*/
async function finalizeHold(hold, credits, properties) {
	const finalize = () => autumn.balances.finalize({
		lockId: hold.lockId,
		...credits > 0 ? {
			action: "confirm",
			overrideValue: credits
		} : { action: "release" },
		properties
	}, AUTUMN_TRACK_RETRY_OPTIONS);
	let lastError;
	for (const attempt of [1, 2]) {
		if (attempt === 2) await sleep(250);
		try {
			if ((await finalize()).success) return { landed: true };
		} catch (error) {
			lastError = error;
			if (errorBodyIncludes(error, "Lock not found")) return attempt === 2 ? { landed: true } : {
				landed: false,
				error
			};
		}
	}
	return {
		landed: false,
		error: lastError
	};
}
/**
* Settles a hold on the provider's real cost: confirms the deduction at the
* actual credits (Autumn deducts the override, above or below the hold, and
* returns the rest) or releases the hold when nothing was billed. A hold can
* cover several provider calls; each is credited separately, so a batch is
* charged exactly what the same calls would cost one by one. Never
* throws: the customer already has the data, so a finalize that still fails
* after one retry is logged with everything needed to reconcile it and the
* hold expires at its TTL.
*/
async function settleUsageCredits(args) {
	const { customer, hold, creditFeature, costs } = args;
	let actualCredits = 0;
	let totalCostUsd = 0;
	for (const cost of costs) {
		actualCredits += creditsForProviderUsd(cost.costUsd);
		totalCostUsd += applyBillingMarkupUsd(cost.costUsd);
	}
	const paths = [...new Set(costs.map((cost) => cost.path.join("/")))];
	const { landed, error } = await finalizeHold(hold, actualCredits, {
		creditFeature,
		projectId: customer.projectId,
		provider: "dataforseo",
		paths,
		totalCostUsd,
		estimatedCredits: hold.estimatedCredits
	});
	if (!landed) {
		console.error("[autumn] finalize failed", {
			organizationId: customer.organizationId,
			lockId: hold.lockId,
			held: hold.estimatedCredits,
			actual: actualCredits,
			error
		});
		return;
	}
	if (actualCredits <= 0) return;
	const onMonthly = hold.featureId === AUTUMN_SEO_DATA_BALANCE_FEATURE_ID;
	await captureCreditsConsumed(customer, {
		credit_feature: creditFeature,
		monthly_credits: onMonthly ? actualCredits : 0,
		topup_credits: onMonthly ? 0 : actualCredits,
		total_credits: actualCredits,
		cost_usd: totalCostUsd,
		estimated_credits: hold.estimatedCredits,
		paths
	});
	if (actualCredits > hold.estimatedCredits) console.error("[billing] estimate undershoot", {
		paths,
		estimated: hold.estimatedCredits,
		actual: actualCredits
	});
}
function captureCreditsConsumed(customer, properties) {
	return captureServerEvent({
		distinctId: customer.userId,
		event: "usage:credits_consume",
		organizationId: customer.organizationId,
		properties: {
			project_id: customer.projectId,
			...properties
		}
	});
}
//#endregion
//#region src/server/lib/audit/rendering-billing.ts
/**
* Charges the credits the audit used against its locks, monthly first, and
* releases the rest. Never throws: a settlement that fails leaves the hold to
* expire, which returns it to the customer.
*/
async function settleRenderingLocks(input) {
	let remaining = renderUsageCredits(input.usage);
	const charged = {
		monthly: 0,
		topup: 0
	};
	for (const lock of input.locks) {
		const charge = Math.min(remaining, lock.estimatedCredits);
		remaining -= charge;
		const { landed, error } = await finalizeHold(lock, charge, {
			source: "site_audit_rendering",
			projectId: input.customer.projectId,
			auditId: input.auditId,
			...input.usage
		});
		if (!landed) {
			console.error("site_audit:render_settle_failed", {
				auditId: input.auditId,
				lockId: lock.lockId,
				charge,
				error
			});
			continue;
		}
		if (lock.featureId === "usage_credits") charged.monthly += charge;
		else charged.topup += charge;
	}
	const total = charged.monthly + charged.topup;
	if (total <= 0) return;
	await captureServerEvent({
		distinctId: input.customer.userId,
		event: "usage:credits_consume",
		organizationId: input.customer.organizationId,
		properties: {
			project_id: input.customer.projectId,
			credit_feature: "site_audit",
			source: "site_audit_rendering",
			monthly_credits: charged.monthly,
			topup_credits: charged.topup,
			total_credits: total,
			cloudflare_attempts: input.usage.cloudflareAttempts,
			context_credits: input.usage.contextCredits
		}
	});
}
//#endregion
//#region node_modules/.pnpm/robots-parser@3.0.1/node_modules/robots-parser/Robots.js
var require_Robots = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	/**
	* Trims the white space from the start and end of the line.
	*
	* If the line is an array it will strip the white space from
	* the start and end of each element of the array.
	*
	* @param  {string|Array} line
	* @return {string|Array}
	* @private
	*/
	function trimLine(line) {
		if (!line) return null;
		if (Array.isArray(line)) return line.map(trimLine);
		return String(line).trim();
	}
	/**
	* Remove comments from lines
	*
	* @param {string} line
	* @return {string}
	* @private
	*/
	function removeComments(line) {
		var commentStartIndex = line.indexOf("#");
		if (commentStartIndex > -1) return line.substr(0, commentStartIndex);
		return line;
	}
	/**
	* Splits a line at the first occurrence of :
	*
	* @param  {string} line
	* @return {Array.<string>}
	* @private
	*/
	function splitLine(line) {
		var idx = String(line).indexOf(":");
		if (!line || idx < 0) return null;
		return [line.slice(0, idx), line.slice(idx + 1)];
	}
	/**
	* Normalises the user-agent string by converting it to
	* lower case and removing any version numbers.
	*
	* @param  {string} userAgent
	* @return {string}
	* @private
	*/
	function formatUserAgent(userAgent) {
		var formattedUserAgent = userAgent.toLowerCase();
		var idx = formattedUserAgent.indexOf("/");
		if (idx > -1) formattedUserAgent = formattedUserAgent.substr(0, idx);
		return formattedUserAgent.trim();
	}
	/**
	* Normalises the URL encoding of a path by encoding
	* unicode characters.
	*
	* @param {string} path
	* @return {string}
	* @private
	*/
	function normaliseEncoding(path) {
		try {
			return urlEncodeToUpper(encodeURI(path).replace(/%25/g, "%"));
		} catch (e) {
			return path;
		}
	}
	/**
	* Convert URL encodings to support case.
	*
	* e.g.: %2a%ef becomes %2A%EF
	*
	* @param {string} path
	* @return {string}
	* @private
	*/
	function urlEncodeToUpper(path) {
		return path.replace(/%[0-9a-fA-F]{2}/g, function(match) {
			return match.toUpperCase();
		});
	}
	/**
	* Matches a pattern with the specified path
	*
	* Uses same algorithm to match patterns as the Google implementation in
	* google/robotstxt so it should be consistent with the spec.
	*
	* @see https://github.com/google/robotstxt/blob/f465f0ede81099dd8bc4aeb2966b3a892bd488b3/robots.cc#L74
	* @param {string} pattern
	* @param {string} path
	* @return {boolean}
	* @private
	*/
	function matches(pattern, path) {
		var matchingLengths = new Array(path.length + 1);
		var numMatchingLengths = 1;
		matchingLengths[0] = 0;
		for (var p = 0; p < pattern.length; p++) {
			if (pattern[p] === "$" && p + 1 === pattern.length) return matchingLengths[numMatchingLengths - 1] === path.length;
			if (pattern[p] == "*") {
				numMatchingLengths = path.length - matchingLengths[0] + 1;
				for (var i = 1; i < numMatchingLengths; i++) matchingLengths[i] = matchingLengths[i - 1] + 1;
			} else {
				var numMatches = 0;
				for (var i = 0; i < numMatchingLengths; i++) if (matchingLengths[i] < path.length && path[matchingLengths[i]] === pattern[p]) matchingLengths[numMatches++] = matchingLengths[i] + 1;
				if (numMatches == 0) return false;
				numMatchingLengths = numMatches;
			}
		}
		return true;
	}
	function parseRobots(contents, robots) {
		var lines = contents.split(/\r\n|\r|\n/).map(removeComments).map(splitLine).map(trimLine);
		var currentUserAgents = [];
		var isNoneUserAgentState = true;
		for (var i = 0; i < lines.length; i++) {
			var line = lines[i];
			if (!line || !line[0]) continue;
			switch (line[0].toLowerCase()) {
				case "user-agent":
					if (isNoneUserAgentState) currentUserAgents.length = 0;
					if (line[1]) currentUserAgents.push(formatUserAgent(line[1]));
					break;
				case "disallow":
					robots.addRule(currentUserAgents, line[1], false, i + 1);
					break;
				case "allow":
					robots.addRule(currentUserAgents, line[1], true, i + 1);
					break;
				case "crawl-delay":
					robots.setCrawlDelay(currentUserAgents, line[1]);
					break;
				case "sitemap":
					if (line[1]) robots.addSitemap(line[1]);
					break;
				case "host": if (line[1]) robots.setPreferredHost(line[1].toLowerCase());
			}
			isNoneUserAgentState = line[0].toLowerCase() !== "user-agent";
		}
	}
	/**
	* Returns if a pattern is allowed by the specified rules.
	*
	* @param  {string}  path
	* @param  {Array.<Object>}  rules
	* @return {Object?}
	* @private
	*/
	function findRule(path, rules) {
		var matchedRule = null;
		for (var i = 0; i < rules.length; i++) {
			var rule = rules[i];
			if (!matches(rule.pattern, path)) continue;
			if (!matchedRule || rule.pattern.length > matchedRule.pattern.length) matchedRule = rule;
			else if (rule.pattern.length == matchedRule.pattern.length && rule.allow && !matchedRule.allow) matchedRule = rule;
		}
		return matchedRule;
	}
	/**
	* Converts provided string into an URL object.
	*
	* Will return null if provided string is not a valid URL.
	*
	* @param {string} url
	* @return {?URL}
	* @private
	*/
	function parseUrl(url) {
		try {
			var url = new URL(url, "http://robots-relative.samclarke.com/");
			if (!url.port) url.port = url.protocol === "https:" ? 443 : 80;
			return url;
		} catch (e) {
			return null;
		}
	}
	function Robots(url, contents) {
		this._url = parseUrl(url) || {};
		this._rules = Object.create(null);
		this._sitemaps = [];
		this._preferredHost = null;
		parseRobots(contents || "", this);
	}
	/**
	* Adds the specified allow/deny rule to the rules
	* for the specified user-agents.
	*
	* @param {Array.<string>} userAgents
	* @param {string} pattern
	* @param {boolean} allow
	* @param {number} [lineNumber] Should use 1-based indexing
	*/
	Robots.prototype.addRule = function(userAgents, pattern, allow, lineNumber) {
		var rules = this._rules;
		userAgents.forEach(function(userAgent) {
			rules[userAgent] = rules[userAgent] || [];
			if (!pattern) return;
			rules[userAgent].push({
				pattern: normaliseEncoding(pattern),
				allow,
				lineNumber
			});
		});
	};
	/**
	* Adds the specified delay to the specified user agents.
	*
	* @param {Array.<string>} userAgents
	* @param {string} delayStr
	*/
	Robots.prototype.setCrawlDelay = function(userAgents, delayStr) {
		var rules = this._rules;
		var delay = Number(delayStr);
		userAgents.forEach(function(userAgent) {
			rules[userAgent] = rules[userAgent] || [];
			if (isNaN(delay)) return;
			rules[userAgent].crawlDelay = delay;
		});
	};
	/**
	* Add a sitemap
	*
	* @param {string} url
	*/
	Robots.prototype.addSitemap = function(url) {
		this._sitemaps.push(url);
	};
	/**
	* Sets the preferred host name
	*
	* @param {string} url
	*/
	Robots.prototype.setPreferredHost = function(url) {
		this._preferredHost = url;
	};
	Robots.prototype._getRule = function(url, ua) {
		var parsedUrl = parseUrl(url) || {};
		var userAgent = formatUserAgent(ua || "*");
		if (parsedUrl.protocol !== this._url.protocol || parsedUrl.hostname !== this._url.hostname || parsedUrl.port !== this._url.port) return;
		var rules = this._rules[userAgent] || this._rules["*"] || [];
		return findRule(urlEncodeToUpper(parsedUrl.pathname + parsedUrl.search), rules);
	};
	/**
	* Returns true if allowed, false if not allowed.
	*
	* Will return undefined if the URL is not valid for
	* this robots.txt file.
	*
	* @param  {string}  url
	* @param  {string?}  ua
	* @return {boolean?}
	*/
	Robots.prototype.isAllowed = function(url, ua) {
		var rule = this._getRule(url, ua);
		if (typeof rule === "undefined") return;
		return !rule || rule.allow;
	};
	/**
	* Returns the line number of the matching directive for the specified
	* URL and user-agent if any.
	*
	* The line numbers start at 1 and go up (1-based indexing).
	*
	* Return -1 if there is no matching directive. If a rule is manually
	* added without a lineNumber then this will return undefined for that
	* rule.
	*
	* @param  {string}  url
	* @param  {string?}  ua
	* @return {number?}
	*/
	Robots.prototype.getMatchingLineNumber = function(url, ua) {
		var rule = this._getRule(url, ua);
		return rule ? rule.lineNumber : -1;
	};
	/**
	* Returns the opposite of isAllowed()
	*
	* @param  {string}  url
	* @param  {string}  ua
	* @return {boolean}
	*/
	Robots.prototype.isDisallowed = function(url, ua) {
		return !this.isAllowed(url, ua);
	};
	/**
	* Gets the crawl delay if there is one.
	*
	* Will return undefined if there is no crawl delay set.
	*
	* @param  {string} ua
	* @return {number?}
	*/
	Robots.prototype.getCrawlDelay = function(ua) {
		var userAgent = formatUserAgent(ua || "*");
		return (this._rules[userAgent] || this._rules["*"] || {}).crawlDelay;
	};
	/**
	* Returns the preferred host if there is one.
	*
	* @return {string?}
	*/
	Robots.prototype.getPreferredHost = function() {
		return this._preferredHost;
	};
	/**
	* Returns an array of sitemap URLs if there are any.
	*
	* @return {Array.<string>}
	*/
	Robots.prototype.getSitemaps = function() {
		return this._sitemaps.slice(0);
	};
	module.exports = Robots;
}));
//#endregion
//#region node_modules/.pnpm/robots-parser@3.0.1/node_modules/robots-parser/index.js
var require_robots_parser = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var Robots = require_Robots();
	module.exports = function(url, contents) {
		return new Robots(url, contents);
	};
}));
//#endregion
//#region node_modules/.pnpm/fast-xml-parser@5.8.0/node_modules/fast-xml-parser/src/util.js
var regexName = /* @__PURE__ */ new RegExp("^[:A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Za-z_\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.\\d\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$");
function getAllMatches(string, regex) {
	const matches = [];
	let match = regex.exec(string);
	while (match) {
		const allmatches = [];
		allmatches.startIndex = regex.lastIndex - match[0].length;
		const len = match.length;
		for (let index = 0; index < len; index++) allmatches.push(match[index]);
		matches.push(allmatches);
		match = regex.exec(string);
	}
	return matches;
}
var isName = function(string) {
	const match = regexName.exec(string);
	return !(match === null || typeof match === "undefined");
};
function isExist(v) {
	return typeof v !== "undefined";
}
/**
* Dangerous property names that could lead to prototype pollution or security issues
*/
var DANGEROUS_PROPERTY_NAMES = [
	"hasOwnProperty",
	"toString",
	"valueOf",
	"__defineGetter__",
	"__defineSetter__",
	"__lookupGetter__",
	"__lookupSetter__"
];
var criticalProperties = [
	"__proto__",
	"constructor",
	"prototype"
];
//#endregion
//#region node_modules/.pnpm/fast-xml-parser@5.8.0/node_modules/fast-xml-parser/src/validator.js
var defaultOptions$1 = {
	allowBooleanAttributes: false,
	unpairedTags: []
};
function validate(xmlData, options) {
	options = Object.assign({}, defaultOptions$1, options);
	const tags = [];
	let tagFound = false;
	let reachedRoot = false;
	if (xmlData[0] === "\uFEFF") xmlData = xmlData.substr(1);
	for (let i = 0; i < xmlData.length; i++) if (xmlData[i] === "<" && xmlData[i + 1] === "?") {
		i += 2;
		i = readPI(xmlData, i);
		if (i.err) return i;
	} else if (xmlData[i] === "<") {
		let tagStartPos = i;
		i++;
		if (xmlData[i] === "!") {
			i = readCommentAndCDATA(xmlData, i);
			continue;
		} else {
			let closingTag = false;
			if (xmlData[i] === "/") {
				closingTag = true;
				i++;
			}
			let tagName = "";
			for (; i < xmlData.length && xmlData[i] !== ">" && xmlData[i] !== " " && xmlData[i] !== "	" && xmlData[i] !== "\n" && xmlData[i] !== "\r"; i++) tagName += xmlData[i];
			tagName = tagName.trim();
			if (tagName[tagName.length - 1] === "/") {
				tagName = tagName.substring(0, tagName.length - 1);
				i--;
			}
			if (!validateTagName(tagName)) {
				let msg;
				if (tagName.trim().length === 0) msg = "Invalid space after '<'.";
				else msg = "Tag '" + tagName + "' is an invalid name.";
				return getErrorObject("InvalidTag", msg, getLineNumberForPosition(xmlData, i));
			}
			const result = readAttributeStr(xmlData, i);
			if (result === false) return getErrorObject("InvalidAttr", "Attributes for '" + tagName + "' have open quote.", getLineNumberForPosition(xmlData, i));
			let attrStr = result.value;
			i = result.index;
			if (attrStr[attrStr.length - 1] === "/") {
				const attrStrStart = i - attrStr.length;
				attrStr = attrStr.substring(0, attrStr.length - 1);
				const isValid = validateAttributeString(attrStr, options);
				if (isValid === true) tagFound = true;
				else return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, attrStrStart + isValid.err.line));
			} else if (closingTag) {
				if (!result.tagClosed) return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' doesn't have proper closing.", getLineNumberForPosition(xmlData, i));
				else if (attrStr.trim().length > 0) return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' can't have attributes or invalid starting.", getLineNumberForPosition(xmlData, tagStartPos));
				else if (tags.length === 0) return getErrorObject("InvalidTag", "Closing tag '" + tagName + "' has not been opened.", getLineNumberForPosition(xmlData, tagStartPos));
				else {
					const otg = tags.pop();
					if (tagName !== otg.tagName) {
						let openPos = getLineNumberForPosition(xmlData, otg.tagStartPos);
						return getErrorObject("InvalidTag", "Expected closing tag '" + otg.tagName + "' (opened in line " + openPos.line + ", col " + openPos.col + ") instead of closing tag '" + tagName + "'.", getLineNumberForPosition(xmlData, tagStartPos));
					}
					if (tags.length == 0) reachedRoot = true;
				}
			} else {
				const isValid = validateAttributeString(attrStr, options);
				if (isValid !== true) return getErrorObject(isValid.err.code, isValid.err.msg, getLineNumberForPosition(xmlData, i - attrStr.length + isValid.err.line));
				if (reachedRoot === true) return getErrorObject("InvalidXml", "Multiple possible root nodes found.", getLineNumberForPosition(xmlData, i));
				else if (options.unpairedTags.indexOf(tagName) !== -1) {} else tags.push({
					tagName,
					tagStartPos
				});
				tagFound = true;
			}
			for (i++; i < xmlData.length; i++) if (xmlData[i] === "<") {
				if (xmlData[i + 1] === "!") {
					i++;
					i = readCommentAndCDATA(xmlData, i);
					continue;
				} else if (xmlData[i + 1] === "?") {
					i = readPI(xmlData, ++i);
					if (i.err) return i;
				} else break;
			} else if (xmlData[i] === "&") {
				const afterAmp = validateAmpersand(xmlData, i);
				if (afterAmp == -1) return getErrorObject("InvalidChar", "char '&' is not expected.", getLineNumberForPosition(xmlData, i));
				i = afterAmp;
			} else if (reachedRoot === true && !isWhiteSpace(xmlData[i])) return getErrorObject("InvalidXml", "Extra text at the end", getLineNumberForPosition(xmlData, i));
			if (xmlData[i] === "<") i--;
		}
	} else {
		if (isWhiteSpace(xmlData[i])) continue;
		return getErrorObject("InvalidChar", "char '" + xmlData[i] + "' is not expected.", getLineNumberForPosition(xmlData, i));
	}
	if (!tagFound) return getErrorObject("InvalidXml", "Start tag expected.", 1);
	else if (tags.length == 1) return getErrorObject("InvalidTag", "Unclosed tag '" + tags[0].tagName + "'.", getLineNumberForPosition(xmlData, tags[0].tagStartPos));
	else if (tags.length > 0) return getErrorObject("InvalidXml", "Invalid '" + JSON.stringify(tags.map((t) => t.tagName), null, 4).replace(/\r?\n/g, "") + "' found.", {
		line: 1,
		col: 1
	});
	return true;
}
function isWhiteSpace(char) {
	return char === " " || char === "	" || char === "\n" || char === "\r";
}
/**
* Read Processing insstructions and skip
* @param {*} xmlData
* @param {*} i
*/
function readPI(xmlData, i) {
	const start = i;
	for (; i < xmlData.length; i++) if (xmlData[i] == "?" || xmlData[i] == " ") {
		const tagname = xmlData.substr(start, i - start);
		if (i > 5 && tagname === "xml") return getErrorObject("InvalidXml", "XML declaration allowed only at the start of the document.", getLineNumberForPosition(xmlData, i));
		else if (xmlData[i] == "?" && xmlData[i + 1] == ">") {
			i++;
			break;
		} else continue;
	}
	return i;
}
function readCommentAndCDATA(xmlData, i) {
	if (xmlData.length > i + 5 && xmlData[i + 1] === "-" && xmlData[i + 2] === "-") {
		for (i += 3; i < xmlData.length; i++) if (xmlData[i] === "-" && xmlData[i + 1] === "-" && xmlData[i + 2] === ">") {
			i += 2;
			break;
		}
	} else if (xmlData.length > i + 8 && xmlData[i + 1] === "D" && xmlData[i + 2] === "O" && xmlData[i + 3] === "C" && xmlData[i + 4] === "T" && xmlData[i + 5] === "Y" && xmlData[i + 6] === "P" && xmlData[i + 7] === "E") {
		let angleBracketsCount = 1;
		for (i += 8; i < xmlData.length; i++) if (xmlData[i] === "<") angleBracketsCount++;
		else if (xmlData[i] === ">") {
			angleBracketsCount--;
			if (angleBracketsCount === 0) break;
		}
	} else if (xmlData.length > i + 9 && xmlData[i + 1] === "[" && xmlData[i + 2] === "C" && xmlData[i + 3] === "D" && xmlData[i + 4] === "A" && xmlData[i + 5] === "T" && xmlData[i + 6] === "A" && xmlData[i + 7] === "[") {
		for (i += 8; i < xmlData.length; i++) if (xmlData[i] === "]" && xmlData[i + 1] === "]" && xmlData[i + 2] === ">") {
			i += 2;
			break;
		}
	}
	return i;
}
var doubleQuote = "\"";
var singleQuote = "'";
/**
* Keep reading xmlData until '<' is found outside the attribute value.
* @param {string} xmlData
* @param {number} i
*/
function readAttributeStr(xmlData, i) {
	let attrStr = "";
	let startChar = "";
	let tagClosed = false;
	for (; i < xmlData.length; i++) {
		if (xmlData[i] === doubleQuote || xmlData[i] === singleQuote) {
			if (startChar === "") startChar = xmlData[i];
			else if (startChar !== xmlData[i]) {} else startChar = "";
		} else if (xmlData[i] === ">") {
			if (startChar === "") {
				tagClosed = true;
				break;
			}
		}
		attrStr += xmlData[i];
	}
	if (startChar !== "") return false;
	return {
		value: attrStr,
		index: i,
		tagClosed
	};
}
/**
* Select all the attributes whether valid or invalid.
*/
var validAttrStrRegxp = /* @__PURE__ */ new RegExp("(\\s*)([^\\s=]+)(\\s*=)?(\\s*(['\"])(([\\s\\S])*?)\\5)?", "g");
function validateAttributeString(attrStr, options) {
	const matches = getAllMatches(attrStr, validAttrStrRegxp);
	const attrNames = {};
	for (let i = 0; i < matches.length; i++) {
		if (matches[i][1].length === 0) return getErrorObject("InvalidAttr", "Attribute '" + matches[i][2] + "' has no space in starting.", getPositionFromMatch(matches[i]));
		else if (matches[i][3] !== void 0 && matches[i][4] === void 0) return getErrorObject("InvalidAttr", "Attribute '" + matches[i][2] + "' is without value.", getPositionFromMatch(matches[i]));
		else if (matches[i][3] === void 0 && !options.allowBooleanAttributes) return getErrorObject("InvalidAttr", "boolean attribute '" + matches[i][2] + "' is not allowed.", getPositionFromMatch(matches[i]));
		const attrName = matches[i][2];
		if (!validateAttrName(attrName)) return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is an invalid name.", getPositionFromMatch(matches[i]));
		if (!Object.prototype.hasOwnProperty.call(attrNames, attrName)) attrNames[attrName] = 1;
		else return getErrorObject("InvalidAttr", "Attribute '" + attrName + "' is repeated.", getPositionFromMatch(matches[i]));
	}
	return true;
}
function validateNumberAmpersand(xmlData, i) {
	let re = /\d/;
	if (xmlData[i] === "x") {
		i++;
		re = /[\da-fA-F]/;
	}
	for (; i < xmlData.length; i++) {
		if (xmlData[i] === ";") return i;
		if (!xmlData[i].match(re)) break;
	}
	return -1;
}
function validateAmpersand(xmlData, i) {
	i++;
	if (xmlData[i] === ";") return -1;
	if (xmlData[i] === "#") {
		i++;
		return validateNumberAmpersand(xmlData, i);
	}
	let count = 0;
	for (; i < xmlData.length; i++, count++) {
		if (xmlData[i].match(/\w/) && count < 20) continue;
		if (xmlData[i] === ";") break;
		return -1;
	}
	return i;
}
function getErrorObject(code, message, lineNumber) {
	return { err: {
		code,
		msg: message,
		line: lineNumber.line || lineNumber,
		col: lineNumber.col
	} };
}
function validateAttrName(attrName) {
	return isName(attrName);
}
function validateTagName(tagname) {
	return isName(tagname);
}
function getLineNumberForPosition(xmlData, index) {
	const lines = xmlData.substring(0, index).split(/\r?\n/);
	return {
		line: lines.length,
		col: lines[lines.length - 1].length + 1
	};
}
function getPositionFromMatch(match) {
	return match.startIndex + match[1].length;
}
//#endregion
//#region node_modules/.pnpm/@nodable+entities@2.1.1/node_modules/@nodable/entities/src/entities.js
/**
* Basic Latin & Special Characters
* @type {Record<string, string>}
*/
var BASIC_LATIN = {
	amp: "&",
	AMP: "&",
	lt: "<",
	LT: "<",
	gt: ">",
	GT: ">",
	quot: "\"",
	QUOT: "\"",
	apos: "'",
	lsquo: "\u2018",
	rsquo: "\u2019",
	ldquo: "\u201C",
	rdquo: "\u201D",
	lsquor: "\u201A",
	rsquor: "\u2019",
	ldquor: "\u201E",
	bdquo: "\u201E",
	comma: ",",
	period: ".",
	colon: ":",
	semi: ";",
	excl: "!",
	quest: "?",
	num: "#",
	dollar: "$",
	percent: "%",
	ast: "*",
	commat: "@",
	lowbar: "_",
	verbar: "|",
	vert: "|",
	sol: "/",
	bsol: "\\",
	lbrace: "{",
	rbrace: "}",
	lbrack: "[",
	rbrack: "]",
	lpar: "(",
	rpar: ")",
	nbsp: "\u00A0",
	iexcl: "\u00A1",
	cent: "\u00A2",
	pound: "\u00A3",
	curren: "\u00A4",
	yen: "\u00A5",
	brvbar: "\u00A6",
	sect: "\u00A7",
	uml: "\u00A8",
	copy: "\u00A9",
	COPY: "\u00A9",
	ordf: "\u00AA",
	laquo: "\u00AB",
	not: "\u00AC",
	shy: "\u00AD",
	reg: "\u00AE",
	REG: "\u00AE",
	macr: "\u00AF",
	deg: "\u00B0",
	plusmn: "\u00B1",
	sup2: "\u00B2",
	sup3: "\u00B3",
	acute: "\u00B4",
	micro: "\u00B5",
	para: "\u00B6",
	middot: "\u00B7",
	cedil: "\u00B8",
	sup1: "\u00B9",
	ordm: "\u00BA",
	raquo: "\u00BB",
	frac14: "\u00BC",
	frac12: "\u00BD",
	half: "\u00BD",
	frac34: "\u00BE",
	iquest: "\u00BF",
	times: "\u00D7",
	div: "\u00F7",
	divide: "\u00F7"
};
/**
* Latin Extended & Accented Letters (A-Z)
* @type {Record<string, string>}
*/
var LATIN_ACCENTS = {
	Agrave: "\u00C0",
	agrave: "\u00E0",
	Aacute: "\u00C1",
	aacute: "\u00E1",
	Acirc: "\u00C2",
	acirc: "\u00E2",
	Atilde: "\u00C3",
	atilde: "\u00E3",
	Auml: "\u00C4",
	auml: "\u00E4",
	Aring: "\u00C5",
	aring: "\u00E5",
	AElig: "\u00C6",
	aelig: "\u00E6",
	Ccedil: "\u00C7",
	ccedil: "\u00E7",
	Egrave: "\u00C8",
	egrave: "\u00E8",
	Eacute: "\u00C9",
	eacute: "\u00E9",
	Ecirc: "\u00CA",
	ecirc: "\u00EA",
	Euml: "\u00CB",
	euml: "\u00EB",
	Igrave: "\u00CC",
	igrave: "\u00EC",
	Iacute: "\u00CD",
	iacute: "\u00ED",
	Icirc: "\u00CE",
	icirc: "\u00EE",
	Iuml: "\u00CF",
	iuml: "\u00EF",
	ETH: "\u00D0",
	eth: "\u00F0",
	Ntilde: "\u00D1",
	ntilde: "\u00F1",
	Ograve: "\u00D2",
	ograve: "\u00F2",
	Oacute: "\u00D3",
	oacute: "\u00F3",
	Ocirc: "\u00D4",
	ocirc: "\u00F4",
	Otilde: "\u00D5",
	otilde: "\u00F5",
	Ouml: "\u00D6",
	ouml: "\u00F6",
	Oslash: "\u00D8",
	oslash: "\u00F8",
	Ugrave: "\u00D9",
	ugrave: "\u00F9",
	Uacute: "\u00DA",
	uacute: "\u00FA",
	Ucirc: "\u00DB",
	ucirc: "\u00FB",
	Uuml: "\u00DC",
	uuml: "\u00FC",
	Yacute: "\u00DD",
	yacute: "\u00FD",
	THORN: "\u00DE",
	thorn: "\u00FE",
	szlig: "\u00DF",
	yuml: "\u00FF",
	Yuml: "\u0178"
};
/**
* Latin Extended (Letters with diacritics)
* @type {Record<string, string>}
*/
var LATIN_EXTENDED = {
	Amacr: "\u0100",
	amacr: "\u0101",
	Abreve: "\u0102",
	abreve: "\u0103",
	Aogon: "\u0104",
	aogon: "\u0105",
	Cacute: "\u0106",
	cacute: "\u0107",
	Ccirc: "\u0108",
	ccirc: "\u0109",
	Cdot: "\u010A",
	cdot: "\u010B",
	Ccaron: "\u010C",
	ccaron: "\u010D",
	Dcaron: "\u010E",
	dcaron: "\u010F",
	Dstrok: "\u0110",
	dstrok: "\u0111",
	Emacr: "\u0112",
	emacr: "\u0113",
	Ecaron: "\u011A",
	ecaron: "\u011B",
	Edot: "\u0116",
	edot: "\u0117",
	Eogon: "\u0118",
	eogon: "\u0119",
	Gcirc: "\u011C",
	gcirc: "\u011D",
	Gbreve: "\u011E",
	gbreve: "\u011F",
	Gdot: "\u0120",
	gdot: "\u0121",
	Gcedil: "\u0122",
	Hcirc: "\u0124",
	hcirc: "\u0125",
	Hstrok: "\u0126",
	hstrok: "\u0127",
	Itilde: "\u0128",
	itilde: "\u0129",
	Imacr: "\u012A",
	imacr: "\u012B",
	Iogon: "\u012E",
	iogon: "\u012F",
	Idot: "\u0130",
	IJlig: "\u0132",
	ijlig: "\u0133",
	Jcirc: "\u0134",
	jcirc: "\u0135",
	Kcedil: "\u0136",
	kcedil: "\u0137",
	kgreen: "\u0138",
	Lacute: "\u0139",
	lacute: "\u013A",
	Lcedil: "\u013B",
	lcedil: "\u013C",
	Lcaron: "\u013D",
	lcaron: "\u013E",
	Lmidot: "\u013F",
	lmidot: "\u0140",
	Lstrok: "\u0141",
	lstrok: "\u0142",
	Nacute: "\u0143",
	nacute: "\u0144",
	Ncaron: "\u0147",
	ncaron: "\u0148",
	Ncedil: "\u0145",
	ncedil: "\u0146",
	ENG: "\u014A",
	eng: "\u014B",
	Omacr: "\u014C",
	omacr: "\u014D",
	Odblac: "\u0150",
	odblac: "\u0151",
	OElig: "\u0152",
	oelig: "\u0153",
	Racute: "\u0154",
	racute: "\u0155",
	Rcaron: "\u0158",
	rcaron: "\u0159",
	Rcedil: "\u0156",
	rcedil: "\u0157",
	Sacute: "\u015A",
	sacute: "\u015B",
	Scirc: "\u015C",
	scirc: "\u015D",
	Scedil: "\u015E",
	scedil: "\u015F",
	Scaron: "\u0160",
	scaron: "\u0161",
	Tcedil: "\u0162",
	tcedil: "\u0163",
	Tcaron: "\u0164",
	tcaron: "\u0165",
	Tstrok: "\u0166",
	tstrok: "\u0167",
	Utilde: "\u0168",
	utilde: "\u0169",
	Umacr: "\u016A",
	umacr: "\u016B",
	Ubreve: "\u016C",
	ubreve: "\u016D",
	Uring: "\u016E",
	uring: "\u016F",
	Udblac: "\u0170",
	udblac: "\u0171",
	Uogon: "\u0172",
	uogon: "\u0173",
	Wcirc: "\u0174",
	wcirc: "\u0175",
	Ycirc: "\u0176",
	ycirc: "\u0177",
	Zacute: "\u0179",
	zacute: "\u017A",
	Zdot: "\u017B",
	zdot: "\u017C",
	Zcaron: "\u017D",
	zcaron: "\u017E"
};
/**
* Greek Letters
* @type {Record<string, string>}
*/
var GREEK = {
	Alpha: "\u0391",
	alpha: "\u03B1",
	Beta: "\u0392",
	beta: "\u03B2",
	Gamma: "\u0393",
	gamma: "\u03B3",
	Delta: "\u0394",
	delta: "\u03B4",
	Epsilon: "\u0395",
	epsilon: "\u03B5",
	epsiv: "\u03F5",
	varepsilon: "\u03F5",
	Zeta: "\u0396",
	zeta: "\u03B6",
	Eta: "\u0397",
	eta: "\u03B7",
	Theta: "\u0398",
	theta: "\u03B8",
	thetasym: "\u03D1",
	vartheta: "\u03D1",
	Iota: "\u0399",
	iota: "\u03B9",
	Kappa: "\u039A",
	kappa: "\u03BA",
	kappav: "\u03F0",
	varkappa: "\u03F0",
	Lambda: "\u039B",
	lambda: "\u03BB",
	Mu: "\u039C",
	mu: "\u03BC",
	Nu: "\u039D",
	nu: "\u03BD",
	Xi: "\u039E",
	xi: "\u03BE",
	Omicron: "\u039F",
	omicron: "\u03BF",
	Pi: "\u03A0",
	pi: "\u03C0",
	piv: "\u03D6",
	varpi: "\u03D6",
	Rho: "\u03A1",
	rho: "\u03C1",
	rhov: "\u03F1",
	varrho: "\u03F1",
	Sigma: "\u03A3",
	sigma: "\u03C3",
	sigmaf: "\u03C2",
	sigmav: "\u03C2",
	varsigma: "\u03C2",
	Tau: "\u03A4",
	tau: "\u03C4",
	Upsilon: "\u03A5",
	upsilon: "\u03C5",
	upsi: "\u03C5",
	Upsi: "\u03D2",
	upsih: "\u03D2",
	Phi: "\u03A6",
	phi: "\u03C6",
	phiv: "\u03D5",
	varphi: "\u03D5",
	Chi: "\u03A7",
	chi: "\u03C7",
	Psi: "\u03A8",
	psi: "\u03C8",
	Omega: "\u03A9",
	omega: "\u03C9",
	ohm: "\u03A9",
	Gammad: "\u03DC",
	gammad: "\u03DD",
	digamma: "\u03DD"
};
/**
* Cyrillic Letters
* @type {Record<string, string>}
*/
var CYRILLIC = {
	Afr: "\u{1D504}",
	afr: "\u{1D51E}",
	Acy: "\u0410",
	acy: "\u0430",
	Bcy: "\u0411",
	bcy: "\u0431",
	Vcy: "\u0412",
	vcy: "\u0432",
	Gcy: "\u0413",
	gcy: "\u0433",
	Dcy: "\u0414",
	dcy: "\u0434",
	IEcy: "\u0415",
	iecy: "\u0435",
	IOcy: "\u0401",
	iocy: "\u0451",
	ZHcy: "\u0416",
	zhcy: "\u0436",
	Zcy: "\u0417",
	zcy: "\u0437",
	Icy: "\u0418",
	icy: "\u0438",
	Jcy: "\u0419",
	jcy: "\u0439",
	Kcy: "\u041A",
	kcy: "\u043A",
	Lcy: "\u041B",
	lcy: "\u043B",
	Mcy: "\u041C",
	mcy: "\u043C",
	Ncy: "\u041D",
	ncy: "\u043D",
	Ocy: "\u041E",
	ocy: "\u043E",
	Pcy: "\u041F",
	pcy: "\u043F",
	Rcy: "\u0420",
	rcy: "\u0440",
	Scy: "\u0421",
	scy: "\u0441",
	Tcy: "\u0422",
	tcy: "\u0442",
	Ucy: "\u0423",
	ucy: "\u0443",
	Fcy: "\u0424",
	fcy: "\u0444",
	KHcy: "\u0425",
	khcy: "\u0445",
	TScy: "\u0426",
	tscy: "\u0446",
	CHcy: "\u0427",
	chcy: "\u0447",
	SHcy: "\u0428",
	shcy: "\u0448",
	SHCHcy: "\u0429",
	shchcy: "\u0449",
	HARDcy: "\u042A",
	hardcy: "\u044A",
	Ycy: "\u042B",
	ycy: "\u044B",
	SOFTcy: "\u042C",
	softcy: "\u044C",
	Ecy: "\u042D",
	ecy: "\u044D",
	YUcy: "\u042E",
	yucy: "\u044E",
	YAcy: "\u042F",
	yacy: "\u044F",
	DJcy: "\u0402",
	djcy: "\u0452",
	GJcy: "\u0403",
	gjcy: "\u0453",
	Jukcy: "\u0404",
	jukcy: "\u0454",
	DScy: "\u0405",
	dscy: "\u0455",
	Iukcy: "\u0406",
	iukcy: "\u0456",
	YIcy: "\u0407",
	yicy: "\u0457",
	Jsercy: "\u0408",
	jsercy: "\u0458",
	LJcy: "\u0409",
	ljcy: "\u0459",
	NJcy: "\u040A",
	njcy: "\u045A",
	TSHcy: "\u040B",
	tshcy: "\u045B",
	KJcy: "\u040C",
	kjcy: "\u045C",
	Ubrcy: "\u040E",
	ubrcy: "\u045E",
	DZcy: "\u040F",
	dzcy: "\u045F"
};
/**
* Mathematical Operators & Relations
* @type {Record<string, string>}
*/
var MATH = {
	plus: "+",
	pm: "\u00B1",
	times: "\u00D7",
	div: "\u00F7",
	divide: "\u00F7",
	sdot: "\u22C5",
	star: "\u2606",
	starf: "\u2605",
	bigstar: "\u2605",
	lowast: "\u2217",
	ast: "*",
	midast: "*",
	compfn: "\u2218",
	smallcircle: "\u2218",
	bullet: "\u2022",
	bull: "\u2022",
	nbsp: "\u00A0",
	hellip: "\u2026",
	mldr: "\u2026",
	prime: "\u2032",
	Prime: "\u2033",
	tprime: "\u2034",
	bprime: "\u2035",
	backprime: "\u2035",
	minus: "\u2212",
	minusd: "\u2238",
	dotminus: "\u2238",
	plusdo: "\u2214",
	dotplus: "\u2214",
	plusmn: "\u00B1",
	minusplus: "\u2213",
	mnplus: "\u2213",
	mp: "\u2213",
	setminus: "\u2216",
	smallsetminus: "\u2216",
	Backslash: "\u2216",
	setmn: "\u2216",
	ssetmn: "\u2216",
	lowbar: "_",
	verbar: "|",
	vert: "|",
	VerticalLine: "|",
	colon: ":",
	Colon: "\u2237",
	Proportion: "\u2237",
	ratio: "\u2236",
	equals: "=",
	ne: "\u2260",
	nequiv: "\u2262",
	equiv: "\u2261",
	Congruent: "\u2261",
	sim: "\u223C",
	thicksim: "\u223C",
	thksim: "\u223C",
	sime: "\u2243",
	simeq: "\u2243",
	TildeEqual: "\u2243",
	asymp: "\u2248",
	approx: "\u2248",
	thickapprox: "\u2248",
	thkap: "\u2248",
	TildeTilde: "\u2248",
	ncong: "\u2247",
	cong: "\u2245",
	TildeFullEqual: "\u2245",
	asympeq: "\u224D",
	CupCap: "\u224D",
	bump: "\u224E",
	Bumpeq: "\u224E",
	HumpDownHump: "\u224E",
	bumpe: "\u224F",
	bumpeq: "\u224F",
	HumpEqual: "\u224F",
	le: "\u2264",
	LessEqual: "\u2264",
	ge: "\u2265",
	GreaterEqual: "\u2265",
	lesseqgtr: "\u22DA",
	lesseqqgtr: "\u2A8B",
	greater: ">",
	less: "<"
};
/**
* Mathematical Operators (Advanced)
* @type {Record<string, string>}
*/
var MATH_ADVANCED = {
	alefsym: "\u2135",
	aleph: "\u2135",
	beth: "\u2136",
	gimel: "\u2137",
	daleth: "\u2138",
	forall: "\u2200",
	ForAll: "\u2200",
	part: "\u2202",
	PartialD: "\u2202",
	exist: "\u2203",
	Exists: "\u2203",
	nexist: "\u2204",
	nexists: "\u2204",
	empty: "\u2205",
	emptyset: "\u2205",
	emptyv: "\u2205",
	varnothing: "\u2205",
	nabla: "\u2207",
	Del: "\u2207",
	isin: "\u2208",
	isinv: "\u2208",
	in: "\u2208",
	Element: "\u2208",
	notin: "\u2209",
	notinva: "\u2209",
	ni: "\u220B",
	niv: "\u220B",
	SuchThat: "\u220B",
	ReverseElement: "\u220B",
	notni: "\u220C",
	notniva: "\u220C",
	prod: "\u220F",
	Product: "\u220F",
	coprod: "\u2210",
	Coproduct: "\u2210",
	sum: "\u2211",
	Sum: "\u2211",
	minus: "\u2212",
	mp: "\u2213",
	plusdo: "\u2214",
	dotplus: "\u2214",
	setminus: "\u2216",
	lowast: "\u2217",
	radic: "\u221A",
	Sqrt: "\u221A",
	prop: "\u221D",
	propto: "\u221D",
	Proportional: "\u221D",
	varpropto: "\u221D",
	infin: "\u221E",
	infintie: "\u29DD",
	ang: "\u2220",
	angle: "\u2220",
	angmsd: "\u2221",
	measuredangle: "\u2221",
	angsph: "\u2222",
	mid: "\u2223",
	VerticalBar: "\u2223",
	nmid: "\u2224",
	nsmid: "\u2224",
	npar: "\u2226",
	parallel: "\u2225",
	spar: "\u2225",
	nparallel: "\u2226",
	nspar: "\u2226",
	and: "\u2227",
	wedge: "\u2227",
	or: "\u2228",
	vee: "\u2228",
	cap: "\u2229",
	cup: "\u222A",
	int: "\u222B",
	Integral: "\u222B",
	conint: "\u222E",
	ContourIntegral: "\u222E",
	Conint: "\u222F",
	DoubleContourIntegral: "\u222F",
	Cconint: "\u2230",
	there4: "\u2234",
	therefore: "\u2234",
	Therefore: "\u2234",
	becaus: "\u2235",
	because: "\u2235",
	Because: "\u2235",
	ratio: "\u2236",
	Proportion: "\u2237",
	minusd: "\u2238",
	dotminus: "\u2238",
	mDDot: "\u223A",
	homtht: "\u223B",
	sim: "\u223C",
	bsimg: "\u223D",
	backsim: "\u223D",
	ac: "\u223E",
	mstpos: "\u223E",
	acd: "\u223F",
	VerticalTilde: "\u2240",
	wr: "\u2240",
	wreath: "\u2240",
	nsime: "\u2244",
	nsimeq: "\u2244",
	ncong: "\u2247",
	simne: "\u2246",
	ncongdot: "\u2A6D\u0338",
	ngsim: "\u2275",
	nsim: "\u2241",
	napprox: "\u2249",
	nap: "\u2249",
	ngeq: "\u2271",
	nge: "\u2271",
	nleq: "\u2270",
	nle: "\u2270",
	ngtr: "\u226F",
	ngt: "\u226F",
	nless: "\u226E",
	nlt: "\u226E",
	nprec: "\u2280",
	npr: "\u2280",
	nsucc: "\u2281",
	nsc: "\u2281"
};
/**
* Arrows
* @type {Record<string, string>}
*/
var ARROWS = {
	larr: "\u2190",
	leftarrow: "\u2190",
	LeftArrow: "\u2190",
	uarr: "\u2191",
	uparrow: "\u2191",
	UpArrow: "\u2191",
	rarr: "\u2192",
	rightarrow: "\u2192",
	RightArrow: "\u2192",
	darr: "\u2193",
	downarrow: "\u2193",
	DownArrow: "\u2193",
	harr: "\u2194",
	leftrightarrow: "\u2194",
	LeftRightArrow: "\u2194",
	varr: "\u2195",
	updownarrow: "\u2195",
	UpDownArrow: "\u2195",
	nwarr: "\u2196",
	nwarrow: "\u2196",
	UpperLeftArrow: "\u2196",
	nearr: "\u2197",
	nearrow: "\u2197",
	UpperRightArrow: "\u2197",
	searr: "\u2198",
	searrow: "\u2198",
	LowerRightArrow: "\u2198",
	swarr: "\u2199",
	swarrow: "\u2199",
	LowerLeftArrow: "\u2199",
	lArr: "\u21D0",
	Leftarrow: "\u21D0",
	uArr: "\u21D1",
	Uparrow: "\u21D1",
	rArr: "\u21D2",
	Rightarrow: "\u21D2",
	dArr: "\u21D3",
	Downarrow: "\u21D3",
	hArr: "\u21D4",
	Leftrightarrow: "\u21D4",
	iff: "\u21D4",
	vArr: "\u21D5",
	Updownarrow: "\u21D5",
	lAarr: "\u21DA",
	Lleftarrow: "\u21DA",
	rAarr: "\u21DB",
	Rrightarrow: "\u21DB",
	lrarr: "\u21C6",
	leftrightarrows: "\u21C6",
	rlarr: "\u21C4",
	rightleftarrows: "\u21C4",
	lrhar: "\u21CB",
	leftrightharpoons: "\u21CB",
	ReverseEquilibrium: "\u21CB",
	rlhar: "\u21CC",
	rightleftharpoons: "\u21CC",
	Equilibrium: "\u21CC",
	udarr: "\u21C5",
	UpArrowDownArrow: "\u21C5",
	duarr: "\u21F5",
	DownArrowUpArrow: "\u21F5",
	llarr: "\u21C7",
	leftleftarrows: "\u21C7",
	rrarr: "\u21C9",
	rightrightarrows: "\u21C9",
	ddarr: "\u21CA",
	downdownarrows: "\u21CA",
	har: "\u21BD",
	lhard: "\u21BD",
	leftharpoondown: "\u21BD",
	lharu: "\u21BC",
	leftharpoonup: "\u21BC",
	rhard: "\u21C1",
	rightharpoondown: "\u21C1",
	rharu: "\u21C0",
	rightharpoonup: "\u21C0",
	lsh: "\u21B0",
	Lsh: "\u21B0",
	rsh: "\u21B1",
	Rsh: "\u21B1",
	ldsh: "\u21B2",
	rdsh: "\u21B3",
	hookleftarrow: "\u21A9",
	hookrightarrow: "\u21AA",
	mapstoleft: "\u21A4",
	mapstoup: "\u21A5",
	map: "\u21A6",
	mapsto: "\u21A6",
	mapstodown: "\u21A7",
	crarr: "\u21B5",
	nleftarrow: "\u219A",
	nleftrightarrow: "\u21AE",
	nrightarrow: "\u219B",
	nrarr: "\u219B",
	larrtl: "\u21A2",
	rarrtl: "\u21A3",
	leftarrowtail: "\u21A2",
	rightarrowtail: "\u21A3",
	twoheadleftarrow: "\u219E",
	twoheadrightarrow: "\u21A0",
	Larr: "\u219E",
	Rarr: "\u21A0",
	larrhk: "\u21A9",
	rarrhk: "\u21AA",
	larrlp: "\u21AB",
	looparrowleft: "\u21AB",
	rarrlp: "\u21AC",
	looparrowright: "\u21AC",
	harrw: "\u21AD",
	leftrightsquigarrow: "\u21AD",
	nrarrw: "\u219D\u0338",
	rarrw: "\u219D",
	rightsquigarrow: "\u219D",
	larrbfs: "\u291F",
	rarrbfs: "\u2920",
	nvHarr: "\u2904",
	nvlArr: "\u2902",
	nvrArr: "\u2903",
	larrfs: "\u291D",
	rarrfs: "\u291E",
	Map: "\u2905",
	larrsim: "\u2973",
	rarrsim: "\u2974",
	harrcir: "\u2948",
	Uarrocir: "\u2949",
	lurdshar: "\u294A",
	ldrdhar: "\u2967",
	ldrushar: "\u294B",
	rdldhar: "\u2969",
	lrhard: "\u296D",
	uharr: "\u21BE",
	uharl: "\u21BF",
	dharr: "\u21C2",
	dharl: "\u21C3",
	Uarr: "\u219F",
	Darr: "\u21A1",
	zigrarr: "\u21DD",
	nwArr: "\u21D6",
	neArr: "\u21D7",
	seArr: "\u21D8",
	swArr: "\u21D9",
	nharr: "\u21AE",
	nhArr: "\u21CE",
	nlarr: "\u219A",
	nlArr: "\u21CD",
	nrArr: "\u21CF",
	larrb: "\u21E4",
	LeftArrowBar: "\u21E4",
	rarrb: "\u21E5",
	RightArrowBar: "\u21E5"
};
/**
* Geometric Shapes
* @type {Record<string, string>}
*/
var SHAPES = {
	square: "\u25A1",
	Square: "\u25A1",
	squ: "\u25A1",
	squf: "\u25AA",
	squarf: "\u25AA",
	blacksquar: "\u25AA",
	blacksquare: "\u25AA",
	FilledVerySmallSquare: "\u25AA",
	blk34: "\u2593",
	blk12: "\u2592",
	blk14: "\u2591",
	block: "\u2588",
	srect: "\u25AD",
	rect: "\u25AD",
	sdot: "\u22C5",
	sdotb: "\u22A1",
	dotsquare: "\u22A1",
	triangle: "\u25B5",
	tri: "\u25B5",
	trine: "\u25B5",
	utri: "\u25B5",
	triangledown: "\u25BF",
	dtri: "\u25BF",
	tridown: "\u25BF",
	triangleleft: "\u25C3",
	ltri: "\u25C3",
	triangleright: "\u25B9",
	rtri: "\u25B9",
	blacktriangle: "\u25B4",
	utrif: "\u25B4",
	blacktriangledown: "\u25BE",
	dtrif: "\u25BE",
	blacktriangleleft: "\u25C2",
	ltrif: "\u25C2",
	blacktriangleright: "\u25B8",
	rtrif: "\u25B8",
	loz: "\u25CA",
	lozenge: "\u25CA",
	blacklozenge: "\u29EB",
	lozf: "\u29EB",
	bigcirc: "\u25EF",
	xcirc: "\u25EF",
	circ: "\u02C6",
	Circle: "\u25CB",
	cir: "\u25CB",
	o: "\u25CB",
	bullet: "\u2022",
	bull: "\u2022",
	hellip: "\u2026",
	mldr: "\u2026",
	nldr: "\u2025",
	boxh: "\u2500",
	HorizontalLine: "\u2500",
	boxv: "\u2502",
	boxdr: "\u250C",
	boxdl: "\u2510",
	boxur: "\u2514",
	boxul: "\u2518",
	boxvr: "\u251C",
	boxvl: "\u2524",
	boxhd: "\u252C",
	boxhu: "\u2534",
	boxvh: "\u253C",
	boxH: "\u2550",
	boxV: "\u2551",
	boxdR: "\u2552",
	boxDr: "\u2553",
	boxDR: "\u2554",
	boxDl: "\u2555",
	boxdL: "\u2556",
	boxDL: "\u2557",
	boxuR: "\u2558",
	boxUr: "\u2559",
	boxUR: "\u255A",
	boxUl: "\u255C",
	boxuL: "\u255B",
	boxUL: "\u255D",
	boxvR: "\u255E",
	boxVr: "\u255F",
	boxVR: "\u2560",
	boxVl: "\u2562",
	boxvL: "\u2561",
	boxVL: "\u2563",
	boxHd: "\u2564",
	boxhD: "\u2565",
	boxHD: "\u2566",
	boxHu: "\u2567",
	boxhU: "\u2568",
	boxHU: "\u2569",
	boxvH: "\u256A",
	boxVh: "\u256B",
	boxVH: "\u256C"
};
/**
* Punctuation & Diacritics
* @type {Record<string, string>}
*/
var PUNCTUATION = {
	excl: "!",
	iexcl: "\u00A1",
	brvbar: "\u00A6",
	sect: "\u00A7",
	uml: "\u00A8",
	copy: "\u00A9",
	ordf: "\u00AA",
	laquo: "\u00AB",
	not: "\u00AC",
	shy: "\u00AD",
	reg: "\u00AE",
	macr: "\u00AF",
	deg: "\u00B0",
	plusmn: "\u00B1",
	sup2: "\u00B2",
	sup3: "\u00B3",
	acute: "\u00B4",
	micro: "\u00B5",
	para: "\u00B6",
	middot: "\u00B7",
	cedil: "\u00B8",
	sup1: "\u00B9",
	ordm: "\u00BA",
	raquo: "\u00BB",
	frac14: "\u00BC",
	frac12: "\u00BD",
	frac34: "\u00BE",
	iquest: "\u00BF",
	nbsp: "\u00A0",
	comma: ",",
	period: ".",
	colon: ":",
	semi: ";",
	vert: "|",
	Verbar: "\u2016",
	verbar: "|",
	dblac: "\u02DD",
	circ: "\u02C6",
	caron: "\u02C7",
	breve: "\u02D8",
	dot: "\u02D9",
	ring: "\u02DA",
	ogon: "\u02DB",
	tilde: "\u02DC",
	DiacriticalGrave: "`",
	DiacriticalAcute: "\u00B4",
	DiacriticalTilde: "\u02DC",
	DiacriticalDot: "\u02D9",
	DiacriticalDoubleAcute: "\u02DD",
	grave: "`"
};
/**
* Currency Symbols
* @type {Record<string, string>}
*/
var CURRENCY = {
	cent: "\u00A2",
	pound: "\u00A3",
	curren: "\u00A4",
	yen: "\u00A5",
	euro: "\u20AC",
	dollar: "$",
	fnof: "\u0192",
	inr: "\u20B9",
	af: "\u060B",
	birr: "\u1265\u122D",
	peso: "\u20B1",
	rub: "\u20BD",
	won: "\u20A9",
	yuan: "\u00A5",
	cedil: "\u00B8"
};
/**
* Fractions
* @type {Record<string, string>}
*/
var FRACTIONS = {
	frac12: "\u00BD",
	half: "\u00BD",
	frac13: "\u2153",
	frac14: "\u00BC",
	frac15: "\u2155",
	frac16: "\u2159",
	frac18: "\u215B",
	frac23: "\u2154",
	frac25: "\u2156",
	frac34: "\u00BE",
	frac35: "\u2157",
	frac38: "\u215C",
	frac45: "\u2158",
	frac56: "\u215A",
	frac58: "\u215D",
	frac78: "\u215E",
	frasl: "\u2044"
};
/**
* Miscellaneous Symbols
* @type {Record<string, string>}
*/
var MISC_SYMBOLS = {
	trade: "\u2122",
	TRADE: "\u2122",
	telrec: "\u2315",
	target: "\u2316",
	ulcorn: "\u231C",
	ulcorner: "\u231C",
	urcorn: "\u231D",
	urcorner: "\u231D",
	dlcorn: "\u231E",
	llcorner: "\u231E",
	drcorn: "\u231F",
	lrcorner: "\u231F",
	intercal: "\u22BA",
	intcal: "\u22BA",
	oplus: "\u2295",
	CirclePlus: "\u2295",
	ominus: "\u2296",
	CircleMinus: "\u2296",
	otimes: "\u2297",
	CircleTimes: "\u2297",
	osol: "\u2298",
	odot: "\u2299",
	CircleDot: "\u2299",
	oast: "\u229B",
	circledast: "\u229B",
	odash: "\u229D",
	circleddash: "\u229D",
	ocirc: "\u229A",
	circledcirc: "\u229A",
	boxplus: "\u229E",
	plusb: "\u229E",
	boxminus: "\u229F",
	minusb: "\u229F",
	boxtimes: "\u22A0",
	timesb: "\u22A0",
	boxdot: "\u22A1",
	sdotb: "\u22A1",
	veebar: "\u22BB",
	vee: "\u2228",
	barvee: "\u22BD",
	and: "\u2227",
	wedge: "\u2227",
	Cap: "\u22D2",
	Cup: "\u22D3",
	Fork: "\u22D4",
	pitchfork: "\u22D4",
	epar: "\u22D5",
	ltlarr: "\u2976",
	nvap: "\u224D\u20D2",
	nvsim: "\u223C\u20D2",
	nvge: "\u2265\u20D2",
	nvle: "\u2264\u20D2",
	nvlt: "<\u20D2",
	nvgt: ">\u20D2",
	nvltrie: "\u22B4\u20D2",
	nvrtrie: "\u22B5\u20D2",
	Vdash: "\u22A9",
	dashv: "\u22A3",
	vDash: "\u22A8",
	Vvdash: "\u22AA",
	nvdash: "\u22AC",
	nvDash: "\u22AD",
	nVdash: "\u22AE",
	nVDash: "\u22AF"
};
({
	...BASIC_LATIN,
	...LATIN_ACCENTS,
	...LATIN_EXTENDED,
	...GREEK,
	...CYRILLIC,
	...MATH,
	...MATH_ADVANCED,
	...ARROWS,
	...SHAPES,
	...PUNCTUATION,
	...CURRENCY,
	...FRACTIONS,
	...MISC_SYMBOLS
});
var XML = {
	amp: "&",
	apos: "'",
	gt: ">",
	lt: "<",
	quot: "\""
};
var COMMON_HTML = {
	nbsp: "\u00A0",
	copy: "\u00A9",
	reg: "\u00AE",
	trade: "\u2122",
	mdash: "\u2014",
	ndash: "\u2013",
	hellip: "\u2026",
	laquo: "\u00AB",
	raquo: "\u00BB",
	lsquo: "\u2018",
	rsquo: "\u2019",
	ldquo: "\u201C",
	rdquo: "\u201D",
	bull: "\u2022",
	para: "\u00B6",
	sect: "\u00A7",
	deg: "\u00B0",
	frac12: "\u00BD",
	frac14: "\u00BC",
	frac34: "\u00BE"
};
//#endregion
//#region node_modules/.pnpm/@nodable+entities@2.1.1/node_modules/@nodable/entities/src/EntityDecoder.js
var SPECIAL_CHARS = /* @__PURE__ */ new Set("!?\\\\/[]$%{}^&*()<>|+");
/**
* Validate that an entity name contains no dangerous characters.
* @param {string} name
* @returns {string} the name, unchanged
* @throws {Error} on invalid characters
*/
function validateEntityName$1(name) {
	if (name[0] === "#") throw new Error(`[EntityReplacer] Invalid character '#' in entity name: "${name}"`);
	for (const ch of name) if (SPECIAL_CHARS.has(ch)) throw new Error(`[EntityReplacer] Invalid character '${ch}' in entity name: "${name}"`);
	return name;
}
/**
* Merge one or more entity maps into a flat name\u2192string map.
* Accepts either:
*   - plain string values:             { amp: '&' }
*   - legacy {regex,val} / {regx,val}: { lt: { regex: /.../, val: '<' } }
*
* Values containing '&' are skipped (recursive expansion risk).
*
* @param {...object} maps
* @returns {Record<string, string>}
*/
function mergeEntityMaps(...maps) {
	const out = Object.create(null);
	for (const map of maps) {
		if (!map) continue;
		for (const key of Object.keys(map)) {
			const raw = map[key];
			if (typeof raw === "string") out[key] = raw;
			else if (raw && typeof raw === "object" && raw.val !== void 0) {
				const val = raw.val;
				if (typeof val === "string") out[key] = val;
			}
		}
	}
	return out;
}
var LIMIT_TIER_EXTERNAL = "external";
var LIMIT_TIER_BASE = "base";
var LIMIT_TIER_ALL = "all";
/**
* Resolve `applyLimitsTo` option into a normalised Set of tier strings.
* Accepted values: 'external' | 'base' | 'all' | string[]
* Default: 'external' (only untrusted injected entities are counted).
* @param {string|string[]|undefined} raw
* @returns {Set<string>}
*/
function parseLimitTiers(raw) {
	if (!raw || raw === LIMIT_TIER_EXTERNAL) return /* @__PURE__ */ new Set([LIMIT_TIER_EXTERNAL]);
	if (raw === LIMIT_TIER_ALL) return /* @__PURE__ */ new Set([LIMIT_TIER_ALL]);
	if (raw === LIMIT_TIER_BASE) return /* @__PURE__ */ new Set([LIMIT_TIER_BASE]);
	if (Array.isArray(raw)) return new Set(raw);
	return /* @__PURE__ */ new Set([LIMIT_TIER_EXTERNAL]);
}
var NCR_LEVEL = Object.freeze({
	allow: 0,
	leave: 1,
	remove: 2,
	throw: 3
});
var XML10_ALLOWED_C0 = /* @__PURE__ */ new Set([
	9,
	10,
	13
]);
/**
* Parse the `ncr` constructor option into flat, hot-path-friendly fields.
* @param {object|undefined} ncr
* @returns {{ xmlVersion: number, onLevel: number, nullLevel: number }}
*/
function parseNCRConfig(ncr) {
	if (!ncr) return {
		xmlVersion: 1,
		onLevel: NCR_LEVEL.allow,
		nullLevel: NCR_LEVEL.remove
	};
	const xmlVersion = ncr.xmlVersion === 1.1 ? 1.1 : 1;
	const onLevel = NCR_LEVEL[ncr.onNCR] ?? NCR_LEVEL.allow;
	const nullLevel = NCR_LEVEL[ncr.nullNCR] ?? NCR_LEVEL.remove;
	return {
		xmlVersion,
		onLevel,
		nullLevel: Math.max(nullLevel, NCR_LEVEL.remove)
	};
}
/**
* Single-pass, zero-regex entity replacer for XML/HTML content.
*
* Algorithm: scan the string once for '&', read to ';', resolve via map
* or direct codepoint conversion, build output chunks, join once at the end.
*
* Entity lookup priority (highest \u2192 lowest):
*   1. input / runtime  (DOCTYPE entities for current document)
*   2. persistent external (survive across documents)
*   3. base named map   (DEFAULT_XML_ENTITIES + user-supplied namedEntities)
*
* Both input and external resolve as the 'external' tier for limit purposes.
* Base map entities resolve as the 'base' tier.
*
* Numeric / hex references (&#NNN; / &#xHH;) are resolved directly via
* String.fromCodePoint() \u2014 no map needed. They count as 'base' tier.
*
* @example
* const replacer = new EntityReplacer({ namedEntities: COMMON_HTML });
* replacer.setExternalEntities({ brand: 'Acme' });
*
* const instance = replacer.reset();
* instance.addInputEntities({ version: '1.0' });
* instance.encode('&brand; v&version; &lt;'); // 'Acme v1.0 <'
*/
var EntityDecoder = class {
	/**
	* @param {object} [options]
	* @param {object|null}  [options.namedEntities]        \u2014 extra named entities merged into base map
	* @param {object}  [options.limit]                 \u2014 security limits
	* @param {number}       [options.limit.maxTotalExpansions=0]  \u2014 0 = unlimited
	* @param {number}       [options.limit.maxExpandedLength=0]   \u2014 0 = unlimited
	* @param {'external'|'base'|'all'|string[]} [options.limit.applyLimitsTo='external']
	*   Which entity tiers count against the security limits:
	*   - 'external' (default) \u2014 only input/runtime + persistent external entities
	*   - 'base'               \u2014 only DEFAULT_XML_ENTITIES + namedEntities
	*   - 'all'                \u2014 every entity regardless of tier
	*   - string[]             \u2014 explicit combination, e.g. ['external', 'base']
	* @param {((resolved: string, original: string) => string)|null} [options.postCheck=null]
	* @param {string[]} [options.remove=[]] \u2014 entity names (e.g. ['nbsp', '#13']) to delete (replace with empty string)
	* @param {string[]} [options.leave=[]]  \u2014 entity names to keep as literal (unchanged in output)
	* @param {object}   [options.ncr]       \u2014 Numeric Character Reference controls
	* @param {1.0|1.1}  [options.ncr.xmlVersion=1.0]
	*   XML version governing which codepoint ranges are restricted:
	*   - 1.0 \u2014 C0 controls U+0001\u2013U+001F (except U+0009/000A/000D) are prohibited
	*   - 1.1 \u2014 C0 controls are allowed when written as NCRs; C1 (U+007F\u2013U+009F) decoded as-is
	* @param {'allow'|'leave'|'remove'|'throw'} [options.ncr.onNCR='allow']
	*   Base action for numeric references. Severity order: allow < leave < remove < throw.
	*   For codepoint ranges that carry a minimum level (surrogates \u2192 remove, XML 1.0 C0 \u2192 remove),
	*   the effective action is max(onNCR, rangeMinimum).
	* @param {'remove'|'throw'} [options.ncr.nullNCR='remove']
	*   Action for U+0000 (null). 'allow' and 'leave' are clamped to 'remove' since null is never safe.
	*/
	constructor(options = {}) {
		this._limit = options.limit || {};
		this._maxTotalExpansions = this._limit.maxTotalExpansions || 0;
		this._maxExpandedLength = this._limit.maxExpandedLength || 0;
		this._postCheck = typeof options.postCheck === "function" ? options.postCheck : (r) => r;
		this._limitTiers = parseLimitTiers(this._limit.applyLimitsTo ?? LIMIT_TIER_EXTERNAL);
		this._numericAllowed = options.numericAllowed ?? true;
		this._baseMap = mergeEntityMaps(XML, options.namedEntities || null);
		/** @type {Record<string, string>} */
		this._externalMap = Object.create(null);
		/** @type {Record<string, string>} */
		this._inputMap = Object.create(null);
		this._totalExpansions = 0;
		this._expandedLength = 0;
		/** @type {Set<string>} */
		this._removeSet = new Set(options.remove && Array.isArray(options.remove) ? options.remove : []);
		/** @type {Set<string>} */
		this._leaveSet = new Set(options.leave && Array.isArray(options.leave) ? options.leave : []);
		const ncrCfg = parseNCRConfig(options.ncr);
		this._ncrXmlVersion = ncrCfg.xmlVersion;
		this._ncrOnLevel = ncrCfg.onLevel;
		this._ncrNullLevel = ncrCfg.nullLevel;
	}
	/**
	* Replace the full set of persistent external entities.
	* All keys are validated \u2014 throws on invalid characters.
	* @param {Record<string, string | { regex?: RegExp, val: string }>} map
	*/
	setExternalEntities(map) {
		if (map) for (const key of Object.keys(map)) validateEntityName$1(key);
		this._externalMap = mergeEntityMaps(map);
	}
	/**
	* Add a single persistent external entity.
	* @param {string} key
	* @param {string} value
	*/
	addExternalEntity(key, value) {
		validateEntityName$1(key);
		if (typeof value === "string" && value.indexOf("&") === -1) this._externalMap[key] = value;
	}
	/**
	* Inject DOCTYPE entities for the current document.
	* Also resets per-document expansion counters.
	* @param {Record<string, string | { regx?: RegExp, regex?: RegExp, val: string }>} map
	*/
	addInputEntities(map) {
		this._totalExpansions = 0;
		this._expandedLength = 0;
		this._inputMap = mergeEntityMaps(map);
	}
	/**
	* Wipe input/runtime entities and reset counters.
	* Call this before processing each new document.
	* @returns {this}
	*/
	reset() {
		this._inputMap = Object.create(null);
		this._totalExpansions = 0;
		this._expandedLength = 0;
		return this;
	}
	/**
	* Update the XML version used for NCR classification.
	* Call this as soon as the document's `<?xml version="...">` declaration is parsed.
	* @param {1.0|1.1|number} version
	*/
	setXmlVersion(version) {
		this._ncrXmlVersion = version === 1.1 ? 1.1 : 1;
	}
	/**
	* Replace all entity references in `str` in a single pass.
	*
	* @param {string} str
	* @returns {string}
	*/
	decode(str) {
		if (typeof str !== "string" || str.length === 0) return str;
		if (str.indexOf("&") === -1) return str;
		const original = str;
		const chunks = [];
		const len = str.length;
		let last = 0;
		let i = 0;
		const limitExpansions = this._maxTotalExpansions > 0;
		const limitLength = this._maxExpandedLength > 0;
		const checkLimits = limitExpansions || limitLength;
		while (i < len) {
			if (str.charCodeAt(i) !== 38) {
				i++;
				continue;
			}
			let j = i + 1;
			while (j < len && str.charCodeAt(j) !== 59 && j - i <= 32) j++;
			if (j >= len || str.charCodeAt(j) !== 59) {
				i++;
				continue;
			}
			const token = str.slice(i + 1, j);
			if (token.length === 0) {
				i++;
				continue;
			}
			let replacement;
			let tier;
			if (this._removeSet.has(token)) {
				replacement = "";
				if (tier === void 0) tier = LIMIT_TIER_EXTERNAL;
			} else if (this._leaveSet.has(token)) {
				i++;
				continue;
			} else if (token.charCodeAt(0) === 35) {
				const ncrResult = this._resolveNCR(token);
				if (ncrResult === void 0) {
					i++;
					continue;
				}
				replacement = ncrResult;
				tier = LIMIT_TIER_BASE;
			} else {
				const resolved = this._resolveName(token);
				replacement = resolved?.value;
				tier = resolved?.tier;
			}
			if (replacement === void 0) {
				i++;
				continue;
			}
			if (i > last) chunks.push(str.slice(last, i));
			chunks.push(replacement);
			last = j + 1;
			i = last;
			if (checkLimits && this._tierCounts(tier)) {
				if (limitExpansions) {
					this._totalExpansions++;
					if (this._totalExpansions > this._maxTotalExpansions) throw new Error(`[EntityReplacer] Entity expansion count limit exceeded: ${this._totalExpansions} > ${this._maxTotalExpansions}`);
				}
				if (limitLength) {
					const delta = replacement.length - (token.length + 2);
					if (delta > 0) {
						this._expandedLength += delta;
						if (this._expandedLength > this._maxExpandedLength) throw new Error(`[EntityReplacer] Expanded content length limit exceeded: ${this._expandedLength} > ${this._maxExpandedLength}`);
					}
				}
			}
		}
		if (last < len) chunks.push(str.slice(last));
		const result = chunks.length === 0 ? str : chunks.join("");
		return this._postCheck(result, original);
	}
	/**
	* Returns true if a resolved entity of the given tier should count
	* against the expansion/length limits.
	* @param {string} tier  \u2014 LIMIT_TIER_EXTERNAL | LIMIT_TIER_BASE
	* @returns {boolean}
	*/
	_tierCounts(tier) {
		if (this._limitTiers.has(LIMIT_TIER_ALL)) return true;
		return this._limitTiers.has(tier);
	}
	/**
	* Resolve a named entity token (without & and ;).
	* Priority: inputMap > externalMap > baseMap
	* Returns the resolved value tagged with its limit tier.
	*
	* @param {string} name
	* @returns {{ value: string, tier: string }|undefined}
	*/
	_resolveName(name) {
		if (name in this._inputMap) return {
			value: this._inputMap[name],
			tier: LIMIT_TIER_EXTERNAL
		};
		if (name in this._externalMap) return {
			value: this._externalMap[name],
			tier: LIMIT_TIER_EXTERNAL
		};
		if (name in this._baseMap) return {
			value: this._baseMap[name],
			tier: LIMIT_TIER_BASE
		};
	}
	/**
	* Classify a codepoint and return the minimum action level that must be applied.
	* Returns -1 when no minimum is imposed (normal allow path).
	*
	* Ranges checked (in priority order):
	*   1. U+0000            \u2014 null, governed by nullNCR (always \u2265 remove)
	*   2. U+D800\u2013U+DFFF     \u2014 surrogates, always prohibited (min: remove)
	*   3. U+0001\u2013U+001F \ {0x09,0x0A,0x0D}  \u2014 XML 1.0 restricted C0 (min: remove)
	*      (skipped in XML 1.1 \u2014 C0 controls are allowed when written as NCRs)
	*
	* @param {number} cp  \u2014 codepoint
	* @returns {number}   \u2014 minimum NCR_LEVEL value, or -1 for no restriction
	*/
	_classifyNCR(cp) {
		if (cp === 0) return this._ncrNullLevel;
		if (cp >= 55296 && cp <= 57343) return NCR_LEVEL.remove;
		if (this._ncrXmlVersion === 1) {
			if (cp >= 1 && cp <= 31 && !XML10_ALLOWED_C0.has(cp)) return NCR_LEVEL.remove;
		}
		return -1;
	}
	/**
	* Execute a resolved NCR action.
	*
	* @param {number} action   \u2014 NCR_LEVEL value
	* @param {string} token    \u2014 raw token (e.g. '#38') for error messages
	* @param {number} cp       \u2014 codepoint, used only for error messages
	* @returns {string|undefined}
	*   - decoded character string  \u2192 'allow'
	*   - ''                        \u2192 'remove'
	*   - undefined                 \u2192 'leave' (caller must skip past '&' only)
	*   - throws Error              \u2192 'throw'
	*/
	_applyNCRAction(action, token, cp) {
		switch (action) {
			case NCR_LEVEL.allow: return String.fromCodePoint(cp);
			case NCR_LEVEL.remove: return "";
			case NCR_LEVEL.leave: return;
			case NCR_LEVEL.throw: throw new Error(`[EntityDecoder] Prohibited numeric character reference &${token}; (U+${cp.toString(16).toUpperCase().padStart(4, "0")})`);
			default: return String.fromCodePoint(cp);
		}
	}
	/**
	* Full NCR resolution pipeline for a numeric token.
	*
	* Steps:
	*   1. Parse the codepoint (decimal or hex).
	*   2. Validate the raw codepoint range (NaN, <0, >0x10FFFF).
	*   3. If numericAllowed is false and no minimum restriction applies \u2192 leave as-is.
	*   4. Classify the codepoint to find the minimum required action level.
	*   5. Resolve effective action = max(onNCR, minimum).
	*   6. Apply and return.
	*
	* @param {string} token  \u2014 e.g. '#38', '#x26', '#X26'
	* @returns {string|undefined}
	*   - string (incl. '')  \u2014 replacement ('' = remove)
	*   - undefined          \u2014 leave original &token; as-is
	*/
	_resolveNCR(token) {
		const second = token.charCodeAt(1);
		let cp;
		if (second === 120 || second === 88) cp = parseInt(token.slice(2), 16);
		else cp = parseInt(token.slice(1), 10);
		if (Number.isNaN(cp) || cp < 0 || cp > 1114111) return void 0;
		const minimum = this._classifyNCR(cp);
		if (!this._numericAllowed && minimum < NCR_LEVEL.remove) return void 0;
		const effective = minimum === -1 ? this._ncrOnLevel : Math.max(this._ncrOnLevel, minimum);
		return this._applyNCRAction(effective, token, cp);
	}
};
//#endregion
//#region node_modules/.pnpm/fast-xml-parser@5.8.0/node_modules/fast-xml-parser/src/xmlparser/OptionsBuilder.js
var defaultOnDangerousProperty = (name) => {
	if (DANGEROUS_PROPERTY_NAMES.includes(name)) return "__" + name;
	return name;
};
var defaultOptions = {
	preserveOrder: false,
	attributeNamePrefix: "@_",
	attributesGroupName: false,
	textNodeName: "#text",
	ignoreAttributes: true,
	removeNSPrefix: false,
	allowBooleanAttributes: false,
	parseTagValue: true,
	parseAttributeValue: false,
	trimValues: true,
	cdataPropName: false,
	numberParseOptions: {
		hex: true,
		leadingZeros: true,
		eNotation: true
	},
	tagValueProcessor: function(tagName, val) {
		return val;
	},
	attributeValueProcessor: function(attrName, val) {
		return val;
	},
	stopNodes: [],
	alwaysCreateTextNode: false,
	isArray: () => false,
	commentPropName: false,
	unpairedTags: [],
	processEntities: true,
	htmlEntities: false,
	entityDecoder: null,
	ignoreDeclaration: false,
	ignorePiTags: false,
	transformTagName: false,
	transformAttributeName: false,
	updateTag: function(tagName, jPath, attrs) {
		return tagName;
	},
	captureMetaData: false,
	maxNestedTags: 100,
	strictReservedNames: true,
	jPath: true,
	onDangerousProperty: defaultOnDangerousProperty
};
/**
* Validates that a property name is safe to use
* @param {string} propertyName - The property name to validate
* @param {string} optionName - The option field name (for error message)
* @throws {Error} If property name is dangerous
*/
function validatePropertyName(propertyName, optionName) {
	if (typeof propertyName !== "string") return;
	const normalized = propertyName.toLowerCase();
	if (DANGEROUS_PROPERTY_NAMES.some((dangerous) => normalized === dangerous.toLowerCase())) throw new Error(`[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`);
	if (criticalProperties.some((dangerous) => normalized === dangerous.toLowerCase())) throw new Error(`[SECURITY] Invalid ${optionName}: "${propertyName}" is a reserved JavaScript keyword that could cause prototype pollution`);
}
/**
* Normalizes processEntities option for backward compatibility
* @param {boolean|object} value 
* @returns {object} Always returns normalized object
*/
function normalizeProcessEntities(value, htmlEntities) {
	if (typeof value === "boolean") return {
		enabled: value,
		maxEntitySize: 1e4,
		maxExpansionDepth: 1e4,
		maxTotalExpansions: Infinity,
		maxExpandedLength: 1e5,
		maxEntityCount: 1e3,
		allowedTags: null,
		tagFilter: null,
		appliesTo: "all"
	};
	if (typeof value === "object" && value !== null) return {
		enabled: value.enabled !== false,
		maxEntitySize: Math.max(1, value.maxEntitySize ?? 1e4),
		maxExpansionDepth: Math.max(1, value.maxExpansionDepth ?? 1e4),
		maxTotalExpansions: Math.max(1, value.maxTotalExpansions ?? Infinity),
		maxExpandedLength: Math.max(1, value.maxExpandedLength ?? 1e5),
		maxEntityCount: Math.max(1, value.maxEntityCount ?? 1e3),
		allowedTags: value.allowedTags ?? null,
		tagFilter: value.tagFilter ?? null,
		appliesTo: value.appliesTo ?? "all"
	};
	return normalizeProcessEntities(true);
}
var buildOptions = function(options) {
	const built = Object.assign({}, defaultOptions, options);
	const propertyNameOptions = [
		{
			value: built.attributeNamePrefix,
			name: "attributeNamePrefix"
		},
		{
			value: built.attributesGroupName,
			name: "attributesGroupName"
		},
		{
			value: built.textNodeName,
			name: "textNodeName"
		},
		{
			value: built.cdataPropName,
			name: "cdataPropName"
		},
		{
			value: built.commentPropName,
			name: "commentPropName"
		}
	];
	for (const { value, name } of propertyNameOptions) if (value) validatePropertyName(value, name);
	if (built.onDangerousProperty === null) built.onDangerousProperty = defaultOnDangerousProperty;
	built.processEntities = normalizeProcessEntities(built.processEntities, built.htmlEntities);
	built.unpairedTagsSet = new Set(built.unpairedTags);
	if (built.stopNodes && Array.isArray(built.stopNodes)) built.stopNodes = built.stopNodes.map((node) => {
		if (typeof node === "string" && node.startsWith("*.")) return ".." + node.substring(2);
		return node;
	});
	return built;
};
//#endregion
//#region node_modules/.pnpm/fast-xml-parser@5.8.0/node_modules/fast-xml-parser/src/xmlparser/xmlNode.js
var METADATA_SYMBOL$1;
if (typeof Symbol !== "function") METADATA_SYMBOL$1 = "@@xmlMetadata";
else METADATA_SYMBOL$1 = Symbol("XML Node Metadata");
var XmlNode = class {
	constructor(tagname) {
		this.tagname = tagname;
		this.child = [];
		this[":@"] = Object.create(null);
	}
	add(key, val) {
		if (key === "__proto__") key = "#__proto__";
		this.child.push({ [key]: val });
	}
	addChild(node, startIndex) {
		if (node.tagname === "__proto__") node.tagname = "#__proto__";
		if (node[":@"] && Object.keys(node[":@"]).length > 0) this.child.push({
			[node.tagname]: node.child,
			[":@"]: node[":@"]
		});
		else this.child.push({ [node.tagname]: node.child });
		if (startIndex !== void 0) this.child[this.child.length - 1][METADATA_SYMBOL$1] = { startIndex };
	}
	/** symbol used for metadata */
	static getMetaDataSymbol() {
		return METADATA_SYMBOL$1;
	}
};
//#endregion
//#region node_modules/.pnpm/xml-naming@0.1.0/node_modules/xml-naming/src/index.js
/**
* xml-naming
* Validates XML Name productions as defined in the XML 1.0 and 1.1 specifications.
* Covers: Name, NCName, QName, NMToken, NMTokens
*
* XML 1.0 spec: https://www.w3.org/TR/xml/#NT-Name
* XML 1.1 spec: https://www.w3.org/TR/xml11/#NT-NameStartChar
* XML NS spec:  https://www.w3.org/TR/xml-names/#NT-NCName
*/
var nameStartChar10 = ":A-Za-z_\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u0486\u0488-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD";
var nameChar10 = nameStartChar10 + "\\-\\.\\d\u00B7\u0300-\u036F\u203F-\u2040";
var nameStartChar11 = ":A-Za-z_\u00C0-\u02FF\u0370-\u037D\u037F-\u0486\u0488-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\u{10000}-\u{EFFFF}";
var nameChar11 = nameStartChar11 + "\\-\\.\\d\u00B7\u0300-\u036F\u0487\u203F-\u2040";
var buildRegexes = (startChar, char, flags = "") => {
	const ncNamePat = `[${startChar.replace(":", "")}][${char.replace(":", "")}]*`;
	return {
		name: new RegExp(`^[${startChar}][${char}]*$`, flags),
		ncName: new RegExp(`^${ncNamePat}$`, flags),
		qName: new RegExp(`^${ncNamePat}(?::${ncNamePat})?$`, flags),
		nmToken: new RegExp(`^[${char}]+$`, flags),
		nmTokens: new RegExp(`^[${char}]+(?:\\s+[${char}]+)*$`, flags)
	};
};
var regexes10 = buildRegexes(nameStartChar10, nameChar10);
var regexes11 = buildRegexes(nameStartChar11, nameChar11, "u");
var getRegexes = (xmlVersion = "1.0") => xmlVersion === "1.1" ? regexes11 : regexes10;
/**
* Returns true if the string is a valid QName (Qualified Name).
* Allows exactly one colon as a prefix separator: prefix:localName.
* Used for: element and attribute names in namespace-aware XML/SVG.
*/
var qName = (str, { xmlVersion = "1.0" } = {}) => getRegexes(xmlVersion).qName.test(str);
//#endregion
//#region node_modules/.pnpm/fast-xml-parser@5.8.0/node_modules/fast-xml-parser/src/xmlparser/DocTypeReader.js
var DocTypeReader = class {
	constructor(options, xmlVersion) {
		this.suppressValidationErr = !options;
		this.options = options;
		this.xmlVersion = xmlVersion || 1;
	}
	setXmlVersion(xmlVersion = 1) {
		this.xmlVersion = xmlVersion;
	}
	readDocType(xmlData, i) {
		const entities = Object.create(null);
		let entityCount = 0;
		if (xmlData[i + 3] === "O" && xmlData[i + 4] === "C" && xmlData[i + 5] === "T" && xmlData[i + 6] === "Y" && xmlData[i + 7] === "P" && xmlData[i + 8] === "E") {
			i = i + 9;
			let angleBracketsCount = 1;
			let hasBody = false, comment = false;
			let exp = "";
			for (; i < xmlData.length; i++) if (xmlData[i] === "<" && !comment) {
				if (hasBody && hasSeq(xmlData, "!ENTITY", i)) {
					i += 7;
					let entityName, val;
					[entityName, val, i] = this.readEntityExp(xmlData, i + 1, this.suppressValidationErr);
					if (val.indexOf("&") === -1) {
						if (this.options.enabled !== false && this.options.maxEntityCount != null && entityCount >= this.options.maxEntityCount) throw new Error(`Entity count (${entityCount + 1}) exceeds maximum allowed (${this.options.maxEntityCount})`);
						entities[entityName] = val;
						entityCount++;
					}
				} else if (hasBody && hasSeq(xmlData, "!ELEMENT", i)) {
					i += 8;
					const { index } = this.readElementExp(xmlData, i + 1);
					i = index;
				} else if (hasBody && hasSeq(xmlData, "!ATTLIST", i)) i += 8;
				else if (hasBody && hasSeq(xmlData, "!NOTATION", i)) {
					i += 9;
					const { index } = this.readNotationExp(xmlData, i + 1, this.suppressValidationErr);
					i = index;
				} else if (hasSeq(xmlData, "!--", i)) comment = true;
				else throw new Error(`Invalid DOCTYPE`);
				angleBracketsCount++;
				exp = "";
			} else if (xmlData[i] === ">") {
				if (comment) {
					if (xmlData[i - 1] === "-" && xmlData[i - 2] === "-") {
						comment = false;
						angleBracketsCount--;
					}
				} else angleBracketsCount--;
				if (angleBracketsCount === 0) break;
			} else if (xmlData[i] === "[") hasBody = true;
			else exp += xmlData[i];
			if (angleBracketsCount !== 0) throw new Error(`Unclosed DOCTYPE`);
		} else throw new Error(`Invalid Tag instead of DOCTYPE`);
		return {
			entities,
			i
		};
	}
	readEntityExp(xmlData, i) {
		i = skipWhitespace(xmlData, i);
		const startIndex = i;
		while (i < xmlData.length && !/\s/.test(xmlData[i]) && xmlData[i] !== "\"" && xmlData[i] !== "'") i++;
		let entityName = xmlData.substring(startIndex, i);
		validateEntityName(entityName, { xmlVersion: this.xmlVersion });
		i = skipWhitespace(xmlData, i);
		if (!this.suppressValidationErr) {
			if (xmlData.substring(i, i + 6).toUpperCase() === "SYSTEM") throw new Error("External entities are not supported");
			else if (xmlData[i] === "%") throw new Error("Parameter entities are not supported");
		}
		let entityValue = "";
		[i, entityValue] = this.readIdentifierVal(xmlData, i, "entity");
		if (this.options.enabled !== false && this.options.maxEntitySize != null && entityValue.length > this.options.maxEntitySize) throw new Error(`Entity "${entityName}" size (${entityValue.length}) exceeds maximum allowed size (${this.options.maxEntitySize})`);
		i--;
		return [
			entityName,
			entityValue,
			i
		];
	}
	readNotationExp(xmlData, i) {
		i = skipWhitespace(xmlData, i);
		const startIndex = i;
		while (i < xmlData.length && !/\s/.test(xmlData[i])) i++;
		let notationName = xmlData.substring(startIndex, i);
		!this.suppressValidationErr && validateEntityName(notationName, { xmlVersion: this.xmlVersion });
		i = skipWhitespace(xmlData, i);
		const identifierType = xmlData.substring(i, i + 6).toUpperCase();
		if (!this.suppressValidationErr && identifierType !== "SYSTEM" && identifierType !== "PUBLIC") throw new Error(`Expected SYSTEM or PUBLIC, found "${identifierType}"`);
		i += identifierType.length;
		i = skipWhitespace(xmlData, i);
		let publicIdentifier = null;
		let systemIdentifier = null;
		if (identifierType === "PUBLIC") {
			[i, publicIdentifier] = this.readIdentifierVal(xmlData, i, "publicIdentifier");
			i = skipWhitespace(xmlData, i);
			if (xmlData[i] === "\"" || xmlData[i] === "'") [i, systemIdentifier] = this.readIdentifierVal(xmlData, i, "systemIdentifier");
		} else if (identifierType === "SYSTEM") {
			[i, systemIdentifier] = this.readIdentifierVal(xmlData, i, "systemIdentifier");
			if (!this.suppressValidationErr && !systemIdentifier) throw new Error("Missing mandatory system identifier for SYSTEM notation");
		}
		return {
			notationName,
			publicIdentifier,
			systemIdentifier,
			index: --i
		};
	}
	readIdentifierVal(xmlData, i, type) {
		let identifierVal = "";
		const startChar = xmlData[i];
		if (startChar !== "\"" && startChar !== "'") throw new Error(`Expected quoted string, found "${startChar}"`);
		i++;
		const startIndex = i;
		while (i < xmlData.length && xmlData[i] !== startChar) i++;
		identifierVal = xmlData.substring(startIndex, i);
		if (xmlData[i] !== startChar) throw new Error(`Unterminated ${type} value`);
		i++;
		return [i, identifierVal];
	}
	readElementExp(xmlData, i) {
		i = skipWhitespace(xmlData, i);
		const startIndex = i;
		while (i < xmlData.length && !/\s/.test(xmlData[i])) i++;
		let elementName = xmlData.substring(startIndex, i);
		if (!this.suppressValidationErr && !qName(elementName, { xmlVersion: this.xmlVersion })) throw new Error(`Invalid element name: "${elementName}"`);
		i = skipWhitespace(xmlData, i);
		let contentModel = "";
		if (xmlData[i] === "E" && hasSeq(xmlData, "MPTY", i)) i += 4;
		else if (xmlData[i] === "A" && hasSeq(xmlData, "NY", i)) i += 2;
		else if (xmlData[i] === "(") {
			i++;
			const startIndex = i;
			while (i < xmlData.length && xmlData[i] !== ")") i++;
			contentModel = xmlData.substring(startIndex, i);
			if (xmlData[i] !== ")") throw new Error("Unterminated content model");
		} else if (!this.suppressValidationErr) throw new Error(`Invalid Element Expression, found "${xmlData[i]}"`);
		return {
			elementName,
			contentModel: contentModel.trim(),
			index: i
		};
	}
	readAttlistExp(xmlData, i) {
		i = skipWhitespace(xmlData, i);
		let startIndex = i;
		while (i < xmlData.length && !/\s/.test(xmlData[i])) i++;
		let elementName = xmlData.substring(startIndex, i);
		validateEntityName(elementName, { xmlVersion: this.xmlVersion });
		i = skipWhitespace(xmlData, i);
		startIndex = i;
		while (i < xmlData.length && !/\s/.test(xmlData[i])) i++;
		let attributeName = xmlData.substring(startIndex, i);
		if (!validateEntityName(attributeName, { xmlVersion: this.xmlVersion })) throw new Error(`Invalid attribute name: "${attributeName}"`);
		i = skipWhitespace(xmlData, i);
		let attributeType = "";
		if (xmlData.substring(i, i + 8).toUpperCase() === "NOTATION") {
			attributeType = "NOTATION";
			i += 8;
			i = skipWhitespace(xmlData, i);
			if (xmlData[i] !== "(") throw new Error(`Expected '(', found "${xmlData[i]}"`);
			i++;
			let allowedNotations = [];
			while (i < xmlData.length && xmlData[i] !== ")") {
				const startIndex = i;
				while (i < xmlData.length && xmlData[i] !== "|" && xmlData[i] !== ")") i++;
				let notation = xmlData.substring(startIndex, i);
				notation = notation.trim();
				if (!validateEntityName(notation, { xmlVersion: this.xmlVersion })) throw new Error(`Invalid notation name: "${notation}"`);
				allowedNotations.push(notation);
				if (xmlData[i] === "|") {
					i++;
					i = skipWhitespace(xmlData, i);
				}
			}
			if (xmlData[i] !== ")") throw new Error("Unterminated list of notations");
			i++;
			attributeType += " (" + allowedNotations.join("|") + ")";
		} else {
			const startIndex = i;
			while (i < xmlData.length && !/\s/.test(xmlData[i])) i++;
			attributeType += xmlData.substring(startIndex, i);
			if (!this.suppressValidationErr && ![
				"CDATA",
				"ID",
				"IDREF",
				"IDREFS",
				"ENTITY",
				"ENTITIES",
				"NMTOKEN",
				"NMTOKENS"
			].includes(attributeType.toUpperCase())) throw new Error(`Invalid attribute type: "${attributeType}"`);
		}
		i = skipWhitespace(xmlData, i);
		let defaultValue = "";
		if (xmlData.substring(i, i + 8).toUpperCase() === "#REQUIRED") {
			defaultValue = "#REQUIRED";
			i += 8;
		} else if (xmlData.substring(i, i + 7).toUpperCase() === "#IMPLIED") {
			defaultValue = "#IMPLIED";
			i += 7;
		} else [i, defaultValue] = this.readIdentifierVal(xmlData, i, "ATTLIST");
		return {
			elementName,
			attributeName,
			attributeType,
			defaultValue,
			index: i
		};
	}
};
var skipWhitespace = (data, index) => {
	while (index < data.length && /\s/.test(data[index])) index++;
	return index;
};
function hasSeq(data, seq, i) {
	for (let j = 0; j < seq.length; j++) if (seq[j] !== data[i + j + 1]) return false;
	return true;
}
function validateEntityName(name, xmlVersion) {
	if (qName(name, { xmlVersion })) return name;
	else throw new Error(`Invalid entity name ${name}`);
}
//#endregion
//#region node_modules/.pnpm/anynum@1.0.0/node_modules/anynum/digitTable.js
/**
* Flat lookup table: maps Unicode code point \u2192 ASCII digit (0-9).
* Only decimal digit characters (Unicode category Nd) are included.
*
* Strategy: Int32Array of size (maxCodePoint - minCodePoint + 1).
* Value 0xFF means "not a digit". Value 0-9 is the ASCII digit value.
* This gives O(1) lookup with no branching, no bisect, no loop.
*
* Memory: range is 0x0660 to 0x1FBF0 \u2192 ~129,936 entries \u00d7 1 byte = ~127 KB.
* Acceptable for a one-time init; lookup is a single array index.
*/
var SCRIPT_ZEROS = [
	48,
	1632,
	1776,
	2406,
	2534,
	2662,
	2790,
	2918,
	3046,
	3174,
	3302,
	3430,
	3558,
	3664,
	3792,
	3872,
	4160,
	4240,
	6112,
	6160,
	6470,
	6608,
	6784,
	6800,
	6992,
	7088,
	7232,
	7248,
	65296,
	120782,
	120792,
	120802,
	120812,
	120822,
	66720,
	68912,
	69734,
	69872,
	69942,
	70096,
	70384,
	70736,
	70864,
	71248,
	71360,
	71472,
	71904,
	72016,
	72688,
	72784,
	73040,
	73120,
	73552,
	92768,
	92864,
	93008,
	123200,
	123632,
	124144,
	125264,
	130032
];
var HIGH_MAP = /* @__PURE__ */ new Map();
var LOW_MAX = 65535;
var TABLE_OFFSET = 1632;
var TABLE = (/* @__PURE__ */ new Uint8Array(63904)).fill(255);
for (const zero of SCRIPT_ZEROS) for (let d = 0; d < 10; d++) {
	const cp = zero + d;
	if (cp <= LOW_MAX) TABLE[cp - TABLE_OFFSET] = d;
	else HIGH_MAP.set(cp, d);
}
//#endregion
//#region node_modules/.pnpm/anynum@1.0.0/node_modules/anynum/anynum.js
var CHAR_0 = 48;
var CHAR_9 = 57;
var CHAR_MINUS = 45;
var MINUS_SET = /* @__PURE__ */ new Set([
	8722,
	65293,
	65123
]);
/**
* Normalize all Unicode decimal digit characters in a string to ASCII (0-9),
* and normalize Unicode minus variants to ASCII '-' (U+002D).
*
* Non-digit, non-minus characters are passed through unchanged.
*
* Performance design:
* - Fast path: if the string has no convertible characters, return it unchanged
*   (zero allocation).
* - BMP digits (0x0660..0xFFFF excl. surrogates): flat Uint8Array lookup (O(1)).
* - Supplementary plane digits (> 0xFFFF, encoded as surrogate pairs): Map lookup.
* - Minus variants: checked inline with a small fixed Set.
*
* @param {string} str
* @returns {string}
*/
function anynum(str) {
	if (typeof str !== "string") return str;
	const len = str.length;
	if (len === 0) return str;
	let firstHit = -1;
	for (let i = 0; i < len; i++) {
		const cc = str.charCodeAt(i);
		if (cc >= CHAR_0 && cc <= CHAR_9 || cc === CHAR_MINUS) continue;
		if (cc < 1632) {
			if (MINUS_SET.has(cc)) {
				firstHit = i;
				break;
			}
			continue;
		}
		if (cc >= 55296 && cc <= 56319) {
			if (i + 1 < len) {
				const low = str.charCodeAt(i + 1);
				if (low >= 56320 && low <= 57343) {
					const cp = 65536 + (cc - 55296 << 10) + (low - 56320);
					if (HIGH_MAP.has(cp)) {
						firstHit = i;
						break;
					}
				}
			}
			continue;
		}
		if (TABLE[cc - 1632] !== 255 || MINUS_SET.has(cc)) {
			firstHit = i;
			break;
		}
	}
	if (firstHit === -1) return str;
	const chars = [];
	if (firstHit > 0) chars.push(str.slice(0, firstHit));
	for (let i = firstHit; i < len; i++) {
		const cc = str.charCodeAt(i);
		if (cc >= CHAR_0 && cc <= CHAR_9 || cc === CHAR_MINUS) {
			chars.push(str[i]);
			continue;
		}
		if (cc < 1632) {
			chars.push(MINUS_SET.has(cc) ? "-" : str[i]);
			continue;
		}
		if (cc >= 55296 && cc <= 56319) {
			if (i + 1 < len) {
				const low = str.charCodeAt(i + 1);
				if (low >= 56320 && low <= 57343) {
					const cp = 65536 + (cc - 55296 << 10) + (low - 56320);
					const d = HIGH_MAP.get(cp);
					if (d !== void 0) {
						chars.push(String.fromCharCode(d + 48));
						i++;
						continue;
					}
				}
			}
			chars.push(str[i]);
			continue;
		}
		if (MINUS_SET.has(cc)) {
			chars.push("-");
			continue;
		}
		const d = TABLE[cc - TABLE_OFFSET];
		chars.push(d !== 255 ? String.fromCharCode(d + 48) : str[i]);
	}
	return chars.join("");
}
//#endregion
//#region node_modules/.pnpm/strnum@2.4.0/node_modules/strnum/strnum.js
var hexRegex = /^[-+]?0x[a-fA-F0-9]+$/;
var binRegex = /^0b[01]+$/;
var octRegex = /^0o[0-7]+$/;
var numRegex = /^([\-\+])?(0*)([0-9]*(\.[0-9]*)?)$/;
var consider = {
	hex: true,
	binary: false,
	octal: false,
	leadingZeros: true,
	decimalPoint: ".",
	eNotation: true,
	infinity: "original",
	unicode: false
};
function toNumber(str, options = {}) {
	options = Object.assign({}, consider, options);
	if (!str || typeof str !== "string") return str;
	let trimmedStr = str.trim();
	if (trimmedStr.length === 0) return str;
	else if (options.skipLike !== void 0 && options.skipLike.test(trimmedStr)) return str;
	else if (trimmedStr === "0") return 0;
	if (options.unicode) {
		trimmedStr = anynum(trimmedStr);
		if (trimmedStr === "0") return 0;
	}
	if (options.hex && hexRegex.test(trimmedStr)) return parse_int(trimmedStr, 16);
	else if (options.binary && binRegex.test(trimmedStr)) return parse_int(trimmedStr, 2);
	else if (options.octal && octRegex.test(trimmedStr)) return parse_int(trimmedStr, 8);
	else if (!isFinite(trimmedStr)) return handleInfinity(str, Number(trimmedStr), options);
	else if (trimmedStr.includes("e") || trimmedStr.includes("E")) return resolveEnotation(str, trimmedStr, options);
	else {
		const match = numRegex.exec(trimmedStr);
		if (match) {
			const sign = match[1] || "";
			const leadingZeros = match[2];
			let numTrimmedByZeros = trimZeros(match[3]);
			const decimalAdjacentToLeadingZeros = sign ? str[leadingZeros.length + 1] === "." : str[leadingZeros.length] === ".";
			if (!options.leadingZeros && (leadingZeros.length > 1 || leadingZeros.length === 1 && !decimalAdjacentToLeadingZeros)) return str;
			else {
				const num = Number(trimmedStr);
				const parsedStr = String(num);
				if (num === 0) return num;
				if (parsedStr.search(/[eE]/) !== -1) {
					if (options.eNotation) return num;
					else return str;
				} else if (trimmedStr.indexOf(".") !== -1) {
					if (parsedStr === "0") return num;
					else if (parsedStr === numTrimmedByZeros) return num;
					else if (parsedStr === `${sign}${numTrimmedByZeros}`) return num;
					else return str;
				}
				let n = leadingZeros ? numTrimmedByZeros : trimmedStr;
				if (leadingZeros) return n === parsedStr || sign + n === parsedStr ? num : str;
				else return n === parsedStr || n === sign + parsedStr ? num : str;
			}
		} else return str;
	}
}
var eNotationRegx = /^([-+])?(0*)(\d*(\.\d*)?[eE][-\+]?\d+)$/;
function resolveEnotation(str, trimmedStr, options) {
	if (!options.eNotation) return str;
	const notation = trimmedStr.match(eNotationRegx);
	if (notation) {
		let sign = notation[1] || "";
		const eChar = notation[3].indexOf("e") === -1 ? "E" : "e";
		const leadingZeros = notation[2];
		const eAdjacentToLeadingZeros = sign ? str[leadingZeros.length + 1] === eChar : str[leadingZeros.length] === eChar;
		if (leadingZeros.length > 1 && eAdjacentToLeadingZeros) return str;
		else if (leadingZeros.length === 1 && (notation[3].startsWith(`.${eChar}`) || notation[3][0] === eChar)) return Number(trimmedStr);
		else if (leadingZeros.length > 0) {
			if (options.leadingZeros && !eAdjacentToLeadingZeros) {
				trimmedStr = (notation[1] || "") + notation[3];
				return Number(trimmedStr);
			} else return str;
		} else return Number(trimmedStr);
	} else return str;
}
/**
* 
* @param {string} numStr without leading zeros
* @returns 
*/
function trimZeros(numStr) {
	if (numStr && numStr.indexOf(".") !== -1) {
		numStr = numStr.replace(/0+$/, "");
		if (numStr === ".") numStr = "0";
		else if (numStr[0] === ".") numStr = "0" + numStr;
		else if (numStr[numStr.length - 1] === ".") numStr = numStr.substring(0, numStr.length - 1);
		return numStr;
	}
	return numStr;
}
function parse_int(numStr, base) {
	const str = numStr.trim();
	if (base === 2 || base === 8) numStr = str.substring(2);
	if (parseInt) return parseInt(numStr, base);
	else if (Number.parseInt) return Number.parseInt(numStr, base);
	else if (window && window.parseInt) return window.parseInt(numStr, base);
	else throw new Error("parseInt, Number.parseInt, window.parseInt are not supported");
}
/**
* Handle infinite values based on user option
* @param {string} str - original input string
* @param {number} num - parsed number (Infinity or -Infinity)
* @param {object} options - user options
* @returns {string|number|null} based on infinity option
*/
function handleInfinity(str, num, options) {
	const isPositive = num === Infinity;
	switch (options.infinity.toLowerCase()) {
		case "null": return null;
		case "infinity": return num;
		case "string": return isPositive ? "Infinity" : "-Infinity";
		default: return str;
	}
}
//#endregion
//#region node_modules/.pnpm/fast-xml-parser@5.8.0/node_modules/fast-xml-parser/src/ignoreAttributes.js
function getIgnoreAttributesFn(ignoreAttributes) {
	if (typeof ignoreAttributes === "function") return ignoreAttributes;
	if (Array.isArray(ignoreAttributes)) return (attrName) => {
		for (const pattern of ignoreAttributes) {
			if (typeof pattern === "string" && attrName === pattern) return true;
			if (pattern instanceof RegExp && pattern.test(attrName)) return true;
		}
	};
	return () => false;
}
//#endregion
//#region node_modules/.pnpm/path-expression-matcher@1.5.0/node_modules/path-expression-matcher/src/Expression.js
/**
* Expression - Parses and stores a tag pattern expression
* 
* Patterns are parsed once and stored in an optimized structure for fast matching.
* 
* @example
* const expr = new Expression("root.users.user");
* const expr2 = new Expression("..user[id]:first");
* const expr3 = new Expression("root/users/user", { separator: '/' });
*/
var Expression = class {
	/**
	* Create a new Expression
	* @param {string} pattern - Pattern string (e.g., "root.users.user", "..user[id]")
	* @param {Object} options - Configuration options
	* @param {string} options.separator - Path separator (default: '.')
	*/
	constructor(pattern, options = {}, data) {
		this.pattern = pattern;
		this.separator = options.separator || ".";
		this.segments = this._parse(pattern);
		this.data = data;
		this._hasDeepWildcard = this.segments.some((seg) => seg.type === "deep-wildcard");
		this._hasAttributeCondition = this.segments.some((seg) => seg.attrName !== void 0);
		this._hasPositionSelector = this.segments.some((seg) => seg.position !== void 0);
	}
	/**
	* Parse pattern string into segments
	* @private
	* @param {string} pattern - Pattern to parse
	* @returns {Array} Array of segment objects
	*/
	_parse(pattern) {
		const segments = [];
		let i = 0;
		let currentPart = "";
		while (i < pattern.length) if (pattern[i] === this.separator) {
			if (i + 1 < pattern.length && pattern[i + 1] === this.separator) {
				if (currentPart.trim()) {
					segments.push(this._parseSegment(currentPart.trim()));
					currentPart = "";
				}
				segments.push({ type: "deep-wildcard" });
				i += 2;
			} else {
				if (currentPart.trim()) segments.push(this._parseSegment(currentPart.trim()));
				currentPart = "";
				i++;
			}
		} else {
			currentPart += pattern[i];
			i++;
		}
		if (currentPart.trim()) segments.push(this._parseSegment(currentPart.trim()));
		return segments;
	}
	/**
	* Parse a single segment
	* @private
	* @param {string} part - Segment string (e.g., "user", "ns::user", "user[id]", "ns::user:first")
	* @returns {Object} Segment object
	*/
	_parseSegment(part) {
		const segment = { type: "tag" };
		let bracketContent = null;
		let withoutBrackets = part;
		const bracketMatch = part.match(/^([^\[]+)(\[[^\]]*\])(.*)$/);
		if (bracketMatch) {
			withoutBrackets = bracketMatch[1] + bracketMatch[3];
			if (bracketMatch[2]) {
				const content = bracketMatch[2].slice(1, -1);
				if (content) bracketContent = content;
			}
		}
		let namespace = void 0;
		let tagAndPosition = withoutBrackets;
		if (withoutBrackets.includes("::")) {
			const nsIndex = withoutBrackets.indexOf("::");
			namespace = withoutBrackets.substring(0, nsIndex).trim();
			tagAndPosition = withoutBrackets.substring(nsIndex + 2).trim();
			if (!namespace) throw new Error(`Invalid namespace in pattern: ${part}`);
		}
		let tag = void 0;
		let positionMatch = null;
		if (tagAndPosition.includes(":")) {
			const colonIndex = tagAndPosition.lastIndexOf(":");
			const tagPart = tagAndPosition.substring(0, colonIndex).trim();
			const posPart = tagAndPosition.substring(colonIndex + 1).trim();
			if ([
				"first",
				"last",
				"odd",
				"even"
			].includes(posPart) || /^nth\(\d+\)$/.test(posPart)) {
				tag = tagPart;
				positionMatch = posPart;
			} else tag = tagAndPosition;
		} else tag = tagAndPosition;
		if (!tag) throw new Error(`Invalid segment pattern: ${part}`);
		segment.tag = tag;
		if (namespace) segment.namespace = namespace;
		if (bracketContent) {
			if (bracketContent.includes("=")) {
				const eqIndex = bracketContent.indexOf("=");
				segment.attrName = bracketContent.substring(0, eqIndex).trim();
				segment.attrValue = bracketContent.substring(eqIndex + 1).trim();
			} else segment.attrName = bracketContent.trim();
		}
		if (positionMatch) {
			const nthMatch = positionMatch.match(/^nth\((\d+)\)$/);
			if (nthMatch) {
				segment.position = "nth";
				segment.positionValue = parseInt(nthMatch[1], 10);
			} else segment.position = positionMatch;
		}
		return segment;
	}
	/**
	* Get the number of segments
	* @returns {number}
	*/
	get length() {
		return this.segments.length;
	}
	/**
	* Check if expression contains deep wildcard
	* @returns {boolean}
	*/
	hasDeepWildcard() {
		return this._hasDeepWildcard;
	}
	/**
	* Check if expression has attribute conditions
	* @returns {boolean}
	*/
	hasAttributeCondition() {
		return this._hasAttributeCondition;
	}
	/**
	* Check if expression has position selectors
	* @returns {boolean}
	*/
	hasPositionSelector() {
		return this._hasPositionSelector;
	}
	/**
	* Get string representation
	* @returns {string}
	*/
	toString() {
		return this.pattern;
	}
};
//#endregion
//#region node_modules/.pnpm/path-expression-matcher@1.5.0/node_modules/path-expression-matcher/src/ExpressionSet.js
/**
* ExpressionSet - An indexed collection of Expressions for efficient bulk matching
*
* Instead of iterating all expressions on every tag, ExpressionSet pre-indexes
* them at insertion time by depth and terminal tag name. At match time, only
* the relevant bucket is evaluated \u2014 typically reducing checks from O(E) to O(1)
* lookup plus O(small bucket) matches.
*
* Three buckets are maintained:
*  - `_byDepthAndTag`  \u2014 exact depth + exact tag name  (tightest, used first)
*  - `_wildcardByDepth` \u2014 exact depth + wildcard tag `*` (depth-matched only)
*  - `_deepWildcards`  \u2014 expressions containing `..`  (cannot be depth-indexed)
*
* @example
* import { Expression, ExpressionSet } from 'fast-xml-tagger';
*
* // Build once at config time
* const stopNodes = new ExpressionSet();
* stopNodes.add(new Expression('root.users.user'));
* stopNodes.add(new Expression('root.config.setting'));
* stopNodes.add(new Expression('..script'));
*
* // Query on every tag \u2014 hot path
* if (stopNodes.matchesAny(matcher)) { ... }
*/
var ExpressionSet = class {
	constructor() {
		/** @type {Map<string, import('./Expression.js').default[]>} depth:tag \u2192 expressions */
		this._byDepthAndTag = /* @__PURE__ */ new Map();
		/** @type {Map<number, import('./Expression.js').default[]>} depth \u2192 wildcard-tag expressions */
		this._wildcardByDepth = /* @__PURE__ */ new Map();
		/** @type {import('./Expression.js').default[]} expressions containing deep wildcard (..) */
		this._deepWildcards = [];
		/** @type {Set<string>} pattern strings already added \u2014 used for deduplication */
		this._patterns = /* @__PURE__ */ new Set();
		/** @type {boolean} whether the set is sealed against further additions */
		this._sealed = false;
	}
	/**
	* Add an Expression to the set.
	* Duplicate patterns (same pattern string) are silently ignored.
	*
	* @param {import('./Expression.js').default} expression - A pre-constructed Expression instance
	* @returns {this} for chaining
	* @throws {TypeError} if called after seal()
	*
	* @example
	* set.add(new Expression('root.users.user'));
	* set.add(new Expression('..script'));
	*/
	add(expression) {
		if (this._sealed) throw new TypeError("ExpressionSet is sealed. Create a new ExpressionSet to add more expressions.");
		if (this._patterns.has(expression.pattern)) return this;
		this._patterns.add(expression.pattern);
		if (expression.hasDeepWildcard()) {
			this._deepWildcards.push(expression);
			return this;
		}
		const depth = expression.length;
		const tag = expression.segments[expression.segments.length - 1]?.tag;
		if (!tag || tag === "*") {
			if (!this._wildcardByDepth.has(depth)) this._wildcardByDepth.set(depth, []);
			this._wildcardByDepth.get(depth).push(expression);
		} else {
			const key = `${depth}:${tag}`;
			if (!this._byDepthAndTag.has(key)) this._byDepthAndTag.set(key, []);
			this._byDepthAndTag.get(key).push(expression);
		}
		return this;
	}
	/**
	* Add multiple expressions at once.
	*
	* @param {import('./Expression.js').default[]} expressions - Array of Expression instances
	* @returns {this} for chaining
	*
	* @example
	* set.addAll([
	*   new Expression('root.users.user'),
	*   new Expression('root.config.setting'),
	* ]);
	*/
	addAll(expressions) {
		for (const expr of expressions) this.add(expr);
		return this;
	}
	/**
	* Check whether a pattern string is already present in the set.
	*
	* @param {import('./Expression.js').default} expression
	* @returns {boolean}
	*/
	has(expression) {
		return this._patterns.has(expression.pattern);
	}
	/**
	* Number of expressions in the set.
	* @type {number}
	*/
	get size() {
		return this._patterns.size;
	}
	/**
	* Seal the set against further modifications.
	* Useful to prevent accidental mutations after config is built.
	* Calling add() or addAll() on a sealed set throws a TypeError.
	*
	* @returns {this}
	*/
	seal() {
		this._sealed = true;
		return this;
	}
	/**
	* Whether the set has been sealed.
	* @type {boolean}
	*/
	get isSealed() {
		return this._sealed;
	}
	/**
	* Test whether the matcher's current path matches any expression in the set.
	*
	* Evaluation order (cheapest \u2192 most expensive):
	*  1. Exact depth + tag bucket  \u2014 O(1) lookup, typically 0\u20132 expressions
	*  2. Depth-only wildcard bucket \u2014 O(1) lookup, rare
	*  3. Deep-wildcard list         \u2014 always checked, but usually small
	*
	* @param {import('./Matcher.js').default} matcher - Matcher instance (or readOnly view)
	* @returns {boolean} true if any expression matches the current path
	*
	* @example
	* if (stopNodes.matchesAny(matcher)) {
	*   // handle stop node
	* }
	*/
	matchesAny(matcher) {
		return this.findMatch(matcher) !== null;
	}
	/**
	* Find and return the first Expression that matches the matcher's current path.
	*
	* Uses the same evaluation order as matchesAny (cheapest \u2192 most expensive):
	*  1. Exact depth + tag bucket
	*  2. Depth-only wildcard bucket
	*  3. Deep-wildcard list
	*
	* @param {import('./Matcher.js').default} matcher - Matcher instance (or readOnly view)
	* @returns {import('./Expression.js').default | null} the first matching Expression, or null
	*
	* @example
	* const expr = stopNodes.findMatch(matcher);
	* if (expr) {
	*   // access expr.config, expr.pattern, etc.
	* }
	*/
	findMatch(matcher) {
		const depth = matcher.getDepth();
		const exactKey = `${depth}:${matcher.getCurrentTag()}`;
		const exactBucket = this._byDepthAndTag.get(exactKey);
		if (exactBucket) {
			for (let i = 0; i < exactBucket.length; i++) if (matcher.matches(exactBucket[i])) return exactBucket[i];
		}
		const wildcardBucket = this._wildcardByDepth.get(depth);
		if (wildcardBucket) {
			for (let i = 0; i < wildcardBucket.length; i++) if (matcher.matches(wildcardBucket[i])) return wildcardBucket[i];
		}
		for (let i = 0; i < this._deepWildcards.length; i++) if (matcher.matches(this._deepWildcards[i])) return this._deepWildcards[i];
		return null;
	}
};
//#endregion
//#region node_modules/.pnpm/path-expression-matcher@1.5.0/node_modules/path-expression-matcher/src/Matcher.js
/**
* MatcherView - A lightweight read-only view over a Matcher's internal state.
*
* Created once by Matcher and reused across all callbacks. Holds a direct
* reference to the parent Matcher so it always reflects current parser state
* with zero copying or freezing overhead.
*
* Users receive this via {@link Matcher#readOnly} or directly from parser
* callbacks. It exposes all query and matching methods but has no mutation
* methods \u2014 misuse is caught at the TypeScript level rather than at runtime.
*
* @example
* const matcher = new Matcher();
* const view = matcher.readOnly();
*
* matcher.push("root", {});
* view.getCurrentTag(); // "root"
* view.getDepth();      // 1
*/
var MatcherView = class {
	/**
	* @param {Matcher} matcher - The parent Matcher instance to read from.
	*/
	constructor(matcher) {
		this._matcher = matcher;
	}
	/**
	* Get the path separator used by the parent matcher.
	* @returns {string}
	*/
	get separator() {
		return this._matcher.separator;
	}
	/**
	* Get current tag name.
	* @returns {string|undefined}
	*/
	getCurrentTag() {
		const path = this._matcher.path;
		return path.length > 0 ? path[path.length - 1].tag : void 0;
	}
	/**
	* Get current namespace.
	* @returns {string|undefined}
	*/
	getCurrentNamespace() {
		const path = this._matcher.path;
		return path.length > 0 ? path[path.length - 1].namespace : void 0;
	}
	/**
	* Get current node's attribute value.
	* @param {string} attrName
	* @returns {*}
	*/
	getAttrValue(attrName) {
		const path = this._matcher.path;
		if (path.length === 0) return void 0;
		return path[path.length - 1].values?.[attrName];
	}
	/**
	* Check if current node has an attribute.
	* @param {string} attrName
	* @returns {boolean}
	*/
	hasAttr(attrName) {
		const path = this._matcher.path;
		if (path.length === 0) return false;
		const current = path[path.length - 1];
		return current.values !== void 0 && attrName in current.values;
	}
	/**
	* Get current node's sibling position (child index in parent).
	* @returns {number}
	*/
	getPosition() {
		const path = this._matcher.path;
		if (path.length === 0) return -1;
		return path[path.length - 1].position ?? 0;
	}
	/**
	* Get current node's repeat counter (occurrence count of this tag name).
	* @returns {number}
	*/
	getCounter() {
		const path = this._matcher.path;
		if (path.length === 0) return -1;
		return path[path.length - 1].counter ?? 0;
	}
	/**
	* Get current node's sibling index (alias for getPosition).
	* @returns {number}
	* @deprecated Use getPosition() or getCounter() instead
	*/
	getIndex() {
		return this.getPosition();
	}
	/**
	* Get current path depth.
	* @returns {number}
	*/
	getDepth() {
		return this._matcher.path.length;
	}
	/**
	* Get path as string.
	* @param {string} [separator] - Optional separator (uses default if not provided)
	* @param {boolean} [includeNamespace=true]
	* @returns {string}
	*/
	toString(separator, includeNamespace = true) {
		return this._matcher.toString(separator, includeNamespace);
	}
	/**
	* Get path as array of tag names.
	* @returns {string[]}
	*/
	toArray() {
		return this._matcher.path.map((n) => n.tag);
	}
	/**
	* Match current path against an Expression.
	* @param {Expression} expression
	* @returns {boolean}
	*/
	matches(expression) {
		return this._matcher.matches(expression);
	}
	/**
	* Match any expression in the given set against the current path.
	* @param {ExpressionSet} exprSet
	* @returns {boolean}
	*/
	matchesAny(exprSet) {
		return exprSet.matchesAny(this._matcher);
	}
};
/**
* Matcher - Tracks current path in XML/JSON tree and matches against Expressions.
*
* The matcher maintains a stack of nodes representing the current path from root to
* current tag. It only stores attribute values for the current (top) node to minimize
* memory usage. Sibling tracking is used to auto-calculate position and counter.
*
* Use {@link Matcher#readOnly} to obtain a {@link MatcherView} safe to pass to
* user callbacks \u2014 it always reflects current state with no Proxy overhead.
*
* @example
* const matcher = new Matcher();
* matcher.push("root", {});
* matcher.push("users", {});
* matcher.push("user", { id: "123", type: "admin" });
*
* const expr = new Expression("root.users.user");
* matcher.matches(expr); // true
*/
var Matcher = class {
	/**
	* Create a new Matcher.
	* @param {Object} [options={}]
	* @param {string} [options.separator='.'] - Default path separator
	*/
	constructor(options = {}) {
		this.separator = options.separator || ".";
		this.path = [];
		this.siblingStacks = [];
		this._pathStringCache = null;
		this._view = new MatcherView(this);
	}
	/**
	* Push a new tag onto the path.
	* @param {string} tagName
	* @param {Object|null} [attrValues=null]
	* @param {string|null} [namespace=null]
	*/
	push(tagName, attrValues = null, namespace = null) {
		this._pathStringCache = null;
		if (this.path.length > 0) this.path[this.path.length - 1].values = void 0;
		const currentLevel = this.path.length;
		if (!this.siblingStacks[currentLevel]) this.siblingStacks[currentLevel] = /* @__PURE__ */ new Map();
		const siblings = this.siblingStacks[currentLevel];
		const siblingKey = namespace ? `${namespace}:${tagName}` : tagName;
		const counter = siblings.get(siblingKey) || 0;
		let position = 0;
		for (const count of siblings.values()) position += count;
		siblings.set(siblingKey, counter + 1);
		const node = {
			tag: tagName,
			position,
			counter
		};
		if (namespace !== null && namespace !== void 0) node.namespace = namespace;
		if (attrValues !== null && attrValues !== void 0) node.values = attrValues;
		this.path.push(node);
	}
	/**
	* Pop the last tag from the path.
	* @returns {Object|undefined} The popped node
	*/
	pop() {
		if (this.path.length === 0) return void 0;
		this._pathStringCache = null;
		const node = this.path.pop();
		if (this.siblingStacks.length > this.path.length + 1) this.siblingStacks.length = this.path.length + 1;
		return node;
	}
	/**
	* Update current node's attribute values.
	* Useful when attributes are parsed after push.
	* @param {Object} attrValues
	*/
	updateCurrent(attrValues) {
		if (this.path.length > 0) {
			const current = this.path[this.path.length - 1];
			if (attrValues !== null && attrValues !== void 0) current.values = attrValues;
		}
	}
	/**
	* Get current tag name.
	* @returns {string|undefined}
	*/
	getCurrentTag() {
		return this.path.length > 0 ? this.path[this.path.length - 1].tag : void 0;
	}
	/**
	* Get current namespace.
	* @returns {string|undefined}
	*/
	getCurrentNamespace() {
		return this.path.length > 0 ? this.path[this.path.length - 1].namespace : void 0;
	}
	/**
	* Get current node's attribute value.
	* @param {string} attrName
	* @returns {*}
	*/
	getAttrValue(attrName) {
		if (this.path.length === 0) return void 0;
		return this.path[this.path.length - 1].values?.[attrName];
	}
	/**
	* Check if current node has an attribute.
	* @param {string} attrName
	* @returns {boolean}
	*/
	hasAttr(attrName) {
		if (this.path.length === 0) return false;
		const current = this.path[this.path.length - 1];
		return current.values !== void 0 && attrName in current.values;
	}
	/**
	* Get current node's sibling position (child index in parent).
	* @returns {number}
	*/
	getPosition() {
		if (this.path.length === 0) return -1;
		return this.path[this.path.length - 1].position ?? 0;
	}
	/**
	* Get current node's repeat counter (occurrence count of this tag name).
	* @returns {number}
	*/
	getCounter() {
		if (this.path.length === 0) return -1;
		return this.path[this.path.length - 1].counter ?? 0;
	}
	/**
	* Get current node's sibling index (alias for getPosition).
	* @returns {number}
	* @deprecated Use getPosition() or getCounter() instead
	*/
	getIndex() {
		return this.getPosition();
	}
	/**
	* Get current path depth.
	* @returns {number}
	*/
	getDepth() {
		return this.path.length;
	}
	/**
	* Get path as string.
	* @param {string} [separator] - Optional separator (uses default if not provided)
	* @param {boolean} [includeNamespace=true]
	* @returns {string}
	*/
	toString(separator, includeNamespace = true) {
		const sep = separator || this.separator;
		if (sep === this.separator && includeNamespace === true) {
			if (this._pathStringCache !== null) return this._pathStringCache;
			const result = this.path.map((n) => n.namespace ? `${n.namespace}:${n.tag}` : n.tag).join(sep);
			this._pathStringCache = result;
			return result;
		}
		return this.path.map((n) => includeNamespace && n.namespace ? `${n.namespace}:${n.tag}` : n.tag).join(sep);
	}
	/**
	* Get path as array of tag names.
	* @returns {string[]}
	*/
	toArray() {
		return this.path.map((n) => n.tag);
	}
	/**
	* Reset the path to empty.
	*/
	reset() {
		this._pathStringCache = null;
		this.path = [];
		this.siblingStacks = [];
	}
	/**
	* Match current path against an Expression.
	* @param {Expression} expression
	* @returns {boolean}
	*/
	matches(expression) {
		const segments = expression.segments;
		if (segments.length === 0) return false;
		if (expression.hasDeepWildcard()) return this._matchWithDeepWildcard(segments);
		return this._matchSimple(segments);
	}
	/**
	* @private
	*/
	_matchSimple(segments) {
		if (this.path.length !== segments.length) return false;
		for (let i = 0; i < segments.length; i++) if (!this._matchSegment(segments[i], this.path[i], i === this.path.length - 1)) return false;
		return true;
	}
	/**
	* @private
	*/
	_matchWithDeepWildcard(segments) {
		let pathIdx = this.path.length - 1;
		let segIdx = segments.length - 1;
		while (segIdx >= 0 && pathIdx >= 0) {
			const segment = segments[segIdx];
			if (segment.type === "deep-wildcard") {
				segIdx--;
				if (segIdx < 0) return true;
				const nextSeg = segments[segIdx];
				let found = false;
				for (let i = pathIdx; i >= 0; i--) if (this._matchSegment(nextSeg, this.path[i], i === this.path.length - 1)) {
					pathIdx = i - 1;
					segIdx--;
					found = true;
					break;
				}
				if (!found) return false;
			} else {
				if (!this._matchSegment(segment, this.path[pathIdx], pathIdx === this.path.length - 1)) return false;
				pathIdx--;
				segIdx--;
			}
		}
		return segIdx < 0;
	}
	/**
	* @private
	*/
	_matchSegment(segment, node, isCurrentNode) {
		if (segment.tag !== "*" && segment.tag !== node.tag) return false;
		if (segment.namespace !== void 0) {
			if (segment.namespace !== "*" && segment.namespace !== node.namespace) return false;
		}
		if (segment.attrName !== void 0) {
			if (!isCurrentNode) return false;
			if (!node.values || !(segment.attrName in node.values)) return false;
			if (segment.attrValue !== void 0) {
				if (String(node.values[segment.attrName]) !== String(segment.attrValue)) return false;
			}
		}
		if (segment.position !== void 0) {
			if (!isCurrentNode) return false;
			const counter = node.counter ?? 0;
			if (segment.position === "first" && counter !== 0) return false;
			else if (segment.position === "odd" && counter % 2 !== 1) return false;
			else if (segment.position === "even" && counter % 2 !== 0) return false;
			else if (segment.position === "nth" && counter !== segment.positionValue) return false;
		}
		return true;
	}
	/**
	* Match any expression in the given set against the current path.
	* @param {ExpressionSet} exprSet
	* @returns {boolean}
	*/
	matchesAny(exprSet) {
		return exprSet.matchesAny(this);
	}
	/**
	* Create a snapshot of current state.
	* @returns {Object}
	*/
	snapshot() {
		return {
			path: this.path.map((node) => ({ ...node })),
			siblingStacks: this.siblingStacks.map((map) => new Map(map))
		};
	}
	/**
	* Restore state from snapshot.
	* @param {Object} snapshot
	*/
	restore(snapshot) {
		this._pathStringCache = null;
		this.path = snapshot.path.map((node) => ({ ...node }));
		this.siblingStacks = snapshot.siblingStacks.map((map) => new Map(map));
	}
	/**
	* Return the read-only {@link MatcherView} for this matcher.
	*
	* The same instance is returned on every call \u2014 no allocation occurs.
	* It always reflects the current parser state and is safe to pass to
	* user callbacks without risk of accidental mutation.
	*
	* @returns {MatcherView}
	*
	* @example
	* const view = matcher.readOnly();
	* // pass view to callbacks \u2014 it stays in sync automatically
	* view.matches(expr);       // \u2713
	* view.getCurrentTag();     // \u2713
	* // view.push(...)         // \u2717 method does not exist \u2014 caught by TypeScript
	*/
	readOnly() {
		return this._view;
	}
};
//#endregion
//#region node_modules/.pnpm/fast-xml-parser@5.8.0/node_modules/fast-xml-parser/src/xmlparser/OrderedObjParser.js
/**
* Extract raw attributes (without prefix) from prefixed attribute map
* @param {object} prefixedAttrs - Attributes with prefix from buildAttributesMap
* @param {object} options - Parser options containing attributeNamePrefix
* @returns {object} Raw attributes for matcher
*/
function extractRawAttributes(prefixedAttrs, options) {
	if (!prefixedAttrs) return {};
	const attrs = options.attributesGroupName ? prefixedAttrs[options.attributesGroupName] : prefixedAttrs;
	if (!attrs) return {};
	const rawAttrs = {};
	for (const key in attrs) if (key.startsWith(options.attributeNamePrefix)) {
		const rawName = key.substring(options.attributeNamePrefix.length);
		rawAttrs[rawName] = attrs[key];
	} else rawAttrs[key] = attrs[key];
	return rawAttrs;
}
/**
* Extract namespace from raw tag name
* @param {string} rawTagName - Tag name possibly with namespace (e.g., "soap:Envelope")
* @returns {string|undefined} Namespace or undefined
*/
function extractNamespace(rawTagName) {
	if (!rawTagName || typeof rawTagName !== "string") return void 0;
	const colonIndex = rawTagName.indexOf(":");
	if (colonIndex !== -1 && colonIndex > 0) {
		const ns = rawTagName.substring(0, colonIndex);
		if (ns !== "xmlns") return ns;
	}
}
var OrderedObjParser = class {
	constructor(options, externalEntities) {
		this.options = options;
		this.currentNode = null;
		this.tagsNodeStack = [];
		this.parseXml = parseXml;
		this.parseTextData = parseTextData;
		this.resolveNameSpace = resolveNameSpace;
		this.buildAttributesMap = buildAttributesMap;
		this.isItStopNode = isItStopNode;
		this.replaceEntitiesValue = replaceEntitiesValue;
		this.readStopNodeData = readStopNodeData;
		this.saveTextToParentTag = saveTextToParentTag;
		this.addChild = addChild;
		this.ignoreAttributesFn = getIgnoreAttributesFn(this.options.ignoreAttributes);
		this.entityExpansionCount = 0;
		this.currentExpandedLength = 0;
		let namedEntities = { ...XML };
		if (this.options.entityDecoder) this.entityDecoder = this.options.entityDecoder;
		else {
			if (typeof this.options.htmlEntities === "object") namedEntities = this.options.htmlEntities;
			else if (this.options.htmlEntities === true) namedEntities = {
				...COMMON_HTML,
				...CURRENCY
			};
			this.entityDecoder = new EntityDecoder({
				namedEntities: {
					...namedEntities,
					...externalEntities
				},
				numericAllowed: this.options.htmlEntities,
				limit: {
					maxTotalExpansions: this.options.processEntities.maxTotalExpansions,
					maxExpandedLength: this.options.processEntities.maxExpandedLength,
					applyLimitsTo: this.options.processEntities.appliesTo
				}
			});
		}
		this.matcher = new Matcher();
		this.readonlyMatcher = this.matcher.readOnly();
		this.isCurrentNodeStopNode = false;
		this.stopNodeExpressionsSet = new ExpressionSet();
		const stopNodesOpts = this.options.stopNodes;
		if (stopNodesOpts && stopNodesOpts.length > 0) {
			for (let i = 0; i < stopNodesOpts.length; i++) {
				const stopNodeExp = stopNodesOpts[i];
				if (typeof stopNodeExp === "string") this.stopNodeExpressionsSet.add(new Expression(stopNodeExp));
				else if (stopNodeExp instanceof Expression) this.stopNodeExpressionsSet.add(stopNodeExp);
			}
			this.stopNodeExpressionsSet.seal();
		}
	}
};
/**
* @param {string} val
* @param {string} tagName
* @param {string|Matcher} jPath - jPath string or Matcher instance based on options.jPath
* @param {boolean} dontTrim
* @param {boolean} hasAttributes
* @param {boolean} isLeafNode
* @param {boolean} escapeEntities
*/
function parseTextData(val, tagName, jPath, dontTrim, hasAttributes, isLeafNode, escapeEntities) {
	const options = this.options;
	if (val !== void 0) {
		if (options.trimValues && !dontTrim) val = val.trim();
		if (val.length > 0) {
			if (!escapeEntities) val = this.replaceEntitiesValue(val, tagName, jPath);
			const jPathOrMatcher = options.jPath ? jPath.toString() : jPath;
			const newval = options.tagValueProcessor(tagName, val, jPathOrMatcher, hasAttributes, isLeafNode);
			if (newval === null || newval === void 0) return val;
			else if (typeof newval !== typeof val || newval !== val) return newval;
			else if (options.trimValues) return parseValue(val, options.parseTagValue, options.numberParseOptions);
			else if (val.trim() === val) return parseValue(val, options.parseTagValue, options.numberParseOptions);
			else return val;
		}
	}
}
function resolveNameSpace(tagname) {
	if (this.options.removeNSPrefix) {
		const tags = tagname.split(":");
		const prefix = tagname.charAt(0) === "/" ? "/" : "";
		if (tags[0] === "xmlns") return "";
		if (tags.length === 2) tagname = prefix + tags[1];
	}
	return tagname;
}
var attrsRegx = /* @__PURE__ */ new RegExp("([^\\s=]+)\\s*(=\\s*(['\"])([\\s\\S]*?)\\3)?", "gm");
function buildAttributesMap(attrStr, jPath, tagName, force = false) {
	const options = this.options;
	if (force === true || options.ignoreAttributes !== true && typeof attrStr === "string") {
		const matches = getAllMatches(attrStr, attrsRegx);
		const len = matches.length;
		const attrs = {};
		const processedVals = new Array(len);
		let hasRawAttrs = false;
		const rawAttrsForMatcher = {};
		for (let i = 0; i < len; i++) {
			const attrName = this.resolveNameSpace(matches[i][1]);
			const oldVal = matches[i][4];
			if (attrName.length && oldVal !== void 0) {
				let val = oldVal;
				if (options.trimValues) val = val.trim();
				val = this.replaceEntitiesValue(val, tagName, this.readonlyMatcher);
				processedVals[i] = val;
				rawAttrsForMatcher[attrName] = val;
				hasRawAttrs = true;
			}
		}
		if (hasRawAttrs && typeof jPath === "object" && jPath.updateCurrent) jPath.updateCurrent(rawAttrsForMatcher);
		const jPathStr = options.jPath ? jPath.toString() : this.readonlyMatcher;
		let hasAttrs = false;
		for (let i = 0; i < len; i++) {
			const attrName = this.resolveNameSpace(matches[i][1]);
			if (this.ignoreAttributesFn(attrName, jPathStr)) continue;
			let aName = options.attributeNamePrefix + attrName;
			if (attrName.length) {
				if (options.transformAttributeName) aName = options.transformAttributeName(aName);
				aName = sanitizeName(aName, options);
				if (matches[i][4] !== void 0) {
					const oldVal = processedVals[i];
					const newVal = options.attributeValueProcessor(attrName, oldVal, jPathStr);
					if (newVal === null || newVal === void 0) attrs[aName] = oldVal;
					else if (typeof newVal !== typeof oldVal || newVal !== oldVal) attrs[aName] = newVal;
					else attrs[aName] = parseValue(oldVal, options.parseAttributeValue, options.numberParseOptions);
					hasAttrs = true;
				} else if (options.allowBooleanAttributes) {
					attrs[aName] = true;
					hasAttrs = true;
				}
			}
		}
		if (!hasAttrs) return;
		if (options.attributesGroupName && !options.preserveOrder) {
			const attrCollection = {};
			attrCollection[options.attributesGroupName] = attrs;
			return attrCollection;
		}
		return attrs;
	}
}
var parseXml = function(xmlData) {
	xmlData = xmlData.replace(/\r\n?/g, "\n");
	const xmlObj = new XmlNode("!xml");
	let currentNode = xmlObj;
	let textData = "";
	this.matcher.reset();
	this.entityDecoder.reset();
	this.entityExpansionCount = 0;
	this.currentExpandedLength = 0;
	const options = this.options;
	const docTypeReader = new DocTypeReader(options.processEntities);
	const xmlLen = xmlData.length;
	for (let i = 0; i < xmlLen; i++) if (xmlData[i] === "<") {
		const c1 = xmlData.charCodeAt(i + 1);
		if (c1 === 47) {
			const closeIndex = findClosingIndex(xmlData, ">", i, "Closing Tag is not closed.");
			let tagName = xmlData.substring(i + 2, closeIndex).trim();
			if (options.removeNSPrefix) {
				const colonIndex = tagName.indexOf(":");
				if (colonIndex !== -1) tagName = tagName.substr(colonIndex + 1);
			}
			tagName = transformTagName(options.transformTagName, tagName, "", options).tagName;
			if (currentNode) textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
			const lastTagName = this.matcher.getCurrentTag();
			if (tagName && options.unpairedTagsSet.has(tagName)) throw new Error(`Unpaired tag can not be used as closing tag: </${tagName}>`);
			if (lastTagName && options.unpairedTagsSet.has(lastTagName)) {
				this.matcher.pop();
				this.tagsNodeStack.pop();
			}
			this.matcher.pop();
			this.isCurrentNodeStopNode = false;
			currentNode = this.tagsNodeStack.pop();
			textData = "";
			i = closeIndex;
		} else if (c1 === 63) {
			let tagData = readTagExp(xmlData, i, false, "?>");
			if (!tagData) throw new Error("Pi Tag is not closed.");
			textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
			const attsMap = this.buildAttributesMap(tagData.tagExp, this.matcher, tagData.tagName, true);
			if (attsMap) {
				const ver = attsMap[this.options.attributeNamePrefix + "version"];
				this.entityDecoder.setXmlVersion(Number(ver) || 1);
				docTypeReader.setXmlVersion(Number(ver) || 1);
			}
			if (options.ignoreDeclaration && tagData.tagName === "?xml" || options.ignorePiTags) {} else {
				const childNode = new XmlNode(tagData.tagName);
				childNode.add(options.textNodeName, "");
				if (tagData.tagName !== tagData.tagExp && tagData.attrExpPresent && options.ignoreAttributes !== true) childNode[":@"] = attsMap;
				this.addChild(currentNode, childNode, this.readonlyMatcher, i);
			}
			i = tagData.closeIndex + 1;
		} else if (c1 === 33 && xmlData.charCodeAt(i + 2) === 45 && xmlData.charCodeAt(i + 3) === 45) {
			const endIndex = findClosingIndex(xmlData, "-->", i + 4, "Comment is not closed.");
			if (options.commentPropName) {
				const comment = xmlData.substring(i + 4, endIndex - 2);
				textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
				currentNode.add(options.commentPropName, [{ [options.textNodeName]: comment }]);
			}
			i = endIndex;
		} else if (c1 === 33 && xmlData.charCodeAt(i + 2) === 68) {
			const result = docTypeReader.readDocType(xmlData, i);
			this.entityDecoder.addInputEntities(result.entities);
			i = result.i;
		} else if (c1 === 33 && xmlData.charCodeAt(i + 2) === 91) {
			const closeIndex = findClosingIndex(xmlData, "]]>", i, "CDATA is not closed.") - 2;
			const tagExp = xmlData.substring(i + 9, closeIndex);
			textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher);
			let val = this.parseTextData(tagExp, currentNode.tagname, this.readonlyMatcher, true, false, true, true);
			if (val == void 0) val = "";
			if (options.cdataPropName) currentNode.add(options.cdataPropName, [{ [options.textNodeName]: tagExp }]);
			else currentNode.add(options.textNodeName, val);
			i = closeIndex + 2;
		} else {
			let result = readTagExp(xmlData, i, options.removeNSPrefix);
			if (!result) {
				const context = xmlData.substring(Math.max(0, i - 50), Math.min(xmlLen, i + 50));
				throw new Error(`readTagExp returned undefined at position ${i}. Context: "${context}"`);
			}
			let tagName = result.tagName;
			const rawTagName = result.rawTagName;
			let tagExp = result.tagExp;
			let attrExpPresent = result.attrExpPresent;
			let closeIndex = result.closeIndex;
			({tagName, tagExp} = transformTagName(options.transformTagName, tagName, tagExp, options));
			if (options.strictReservedNames && (tagName === options.commentPropName || tagName === options.cdataPropName || tagName === options.textNodeName || tagName === options.attributesGroupName)) throw new Error(`Invalid tag name: ${tagName}`);
			if (currentNode && textData) {
				if (currentNode.tagname !== "!xml") textData = this.saveTextToParentTag(textData, currentNode, this.readonlyMatcher, false);
			}
			const lastTag = currentNode;
			if (lastTag && options.unpairedTagsSet.has(lastTag.tagname)) {
				currentNode = this.tagsNodeStack.pop();
				this.matcher.pop();
			}
			let isSelfClosing = false;
			if (tagExp.length > 0 && tagExp.lastIndexOf("/") === tagExp.length - 1) {
				isSelfClosing = true;
				if (tagName[tagName.length - 1] === "/") {
					tagName = tagName.substr(0, tagName.length - 1);
					tagExp = tagName;
				} else tagExp = tagExp.substr(0, tagExp.length - 1);
				attrExpPresent = tagName !== tagExp;
			}
			let prefixedAttrs = null;
			let namespace = void 0;
			namespace = extractNamespace(rawTagName);
			if (tagName !== xmlObj.tagname) this.matcher.push(tagName, {}, namespace);
			if (tagName !== tagExp && attrExpPresent) {
				prefixedAttrs = this.buildAttributesMap(tagExp, this.matcher, tagName);
				if (prefixedAttrs) extractRawAttributes(prefixedAttrs, options);
			}
			if (tagName !== xmlObj.tagname) this.isCurrentNodeStopNode = this.isItStopNode();
			const startIndex = i;
			if (this.isCurrentNodeStopNode) {
				let tagContent = "";
				if (isSelfClosing) i = result.closeIndex;
				else if (options.unpairedTagsSet.has(tagName)) i = result.closeIndex;
				else {
					const result = this.readStopNodeData(xmlData, rawTagName, closeIndex + 1);
					if (!result) throw new Error(`Unexpected end of ${rawTagName}`);
					i = result.i;
					tagContent = result.tagContent;
				}
				const childNode = new XmlNode(tagName);
				if (prefixedAttrs) childNode[":@"] = prefixedAttrs;
				childNode.add(options.textNodeName, tagContent);
				this.matcher.pop();
				this.isCurrentNodeStopNode = false;
				this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
			} else {
				if (isSelfClosing) {
					({tagName, tagExp} = transformTagName(options.transformTagName, tagName, tagExp, options));
					const childNode = new XmlNode(tagName);
					if (prefixedAttrs) childNode[":@"] = prefixedAttrs;
					this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
					this.matcher.pop();
					this.isCurrentNodeStopNode = false;
				} else if (options.unpairedTagsSet.has(tagName)) {
					const childNode = new XmlNode(tagName);
					if (prefixedAttrs) childNode[":@"] = prefixedAttrs;
					this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
					this.matcher.pop();
					this.isCurrentNodeStopNode = false;
					i = result.closeIndex;
					continue;
				} else {
					const childNode = new XmlNode(tagName);
					if (this.tagsNodeStack.length > options.maxNestedTags) throw new Error("Maximum nested tags exceeded");
					this.tagsNodeStack.push(currentNode);
					if (prefixedAttrs) childNode[":@"] = prefixedAttrs;
					this.addChild(currentNode, childNode, this.readonlyMatcher, startIndex);
					currentNode = childNode;
				}
				textData = "";
				i = closeIndex;
			}
		}
	} else textData += xmlData[i];
	return xmlObj.child;
};
function addChild(currentNode, childNode, matcher, startIndex) {
	if (!this.options.captureMetaData) startIndex = void 0;
	const jPathOrMatcher = this.options.jPath ? matcher.toString() : matcher;
	const result = this.options.updateTag(childNode.tagname, jPathOrMatcher, childNode[":@"]);
	if (result === false) {} else if (typeof result === "string") {
		childNode.tagname = result;
		currentNode.addChild(childNode, startIndex);
	} else currentNode.addChild(childNode, startIndex);
}
/**
* @param {object} val - Entity object with regex and val properties
* @param {string} tagName - Tag name
* @param {string|Matcher} jPath - jPath string or Matcher instance based on options.jPath
*/
function replaceEntitiesValue(val, tagName, jPath) {
	const entityConfig = this.options.processEntities;
	if (!entityConfig || !entityConfig.enabled) return val;
	if (entityConfig.allowedTags) {
		const jPathOrMatcher = this.options.jPath ? jPath.toString() : jPath;
		if (!(Array.isArray(entityConfig.allowedTags) ? entityConfig.allowedTags.includes(tagName) : entityConfig.allowedTags(tagName, jPathOrMatcher))) return val;
	}
	if (entityConfig.tagFilter) {
		const jPathOrMatcher = this.options.jPath ? jPath.toString() : jPath;
		if (!entityConfig.tagFilter(tagName, jPathOrMatcher)) return val;
	}
	return this.entityDecoder.decode(val);
}
function saveTextToParentTag(textData, parentNode, matcher, isLeafNode) {
	if (textData) {
		if (isLeafNode === void 0) isLeafNode = parentNode.child.length === 0;
		textData = this.parseTextData(textData, parentNode.tagname, matcher, false, parentNode[":@"] ? Object.keys(parentNode[":@"]).length !== 0 : false, isLeafNode);
		if (textData !== void 0 && textData !== "") parentNode.add(this.options.textNodeName, textData);
		textData = "";
	}
	return textData;
}
/**
* @param {Array<Expression>} stopNodeExpressions - Array of compiled Expression objects
* @param {Matcher} matcher - Current path matcher
*/
function isItStopNode() {
	if (this.stopNodeExpressionsSet.size === 0) return false;
	return this.matcher.matchesAny(this.stopNodeExpressionsSet);
}
/**
* Returns the tag Expression and where it is ending handling single-double quotes situation
* @param {string} xmlData 
* @param {number} i starting index
* @returns 
*/
function tagExpWithClosingIndex(xmlData, i, closingChar = ">") {
	let attrBoundary = 0;
	const len = xmlData.length;
	const closeCode0 = closingChar.charCodeAt(0);
	const closeCode1 = closingChar.length > 1 ? closingChar.charCodeAt(1) : -1;
	let result = "";
	let segmentStart = i;
	for (let index = i; index < len; index++) {
		const code = xmlData.charCodeAt(index);
		if (attrBoundary) {
			if (code === attrBoundary) attrBoundary = 0;
		} else if (code === 34 || code === 39) attrBoundary = code;
		else if (code === closeCode0) {
			if (closeCode1 !== -1) {
				if (xmlData.charCodeAt(index + 1) === closeCode1) {
					result += xmlData.substring(segmentStart, index);
					return {
						data: result,
						index
					};
				}
			} else {
				result += xmlData.substring(segmentStart, index);
				return {
					data: result,
					index
				};
			}
		} else if (code === 9 && !attrBoundary) {
			result += xmlData.substring(segmentStart, index) + " ";
			segmentStart = index + 1;
		}
	}
}
function findClosingIndex(xmlData, str, i, errMsg) {
	const closingIndex = xmlData.indexOf(str, i);
	if (closingIndex === -1) throw new Error(errMsg);
	else return closingIndex + str.length - 1;
}
function findClosingChar(xmlData, char, i, errMsg) {
	const closingIndex = xmlData.indexOf(char, i);
	if (closingIndex === -1) throw new Error(errMsg);
	return closingIndex;
}
function readTagExp(xmlData, i, removeNSPrefix, closingChar = ">") {
	const result = tagExpWithClosingIndex(xmlData, i + 1, closingChar);
	if (!result) return;
	let tagExp = result.data;
	const closeIndex = result.index;
	const separatorIndex = tagExp.search(/\s/);
	let tagName = tagExp;
	let attrExpPresent = true;
	if (separatorIndex !== -1) {
		tagName = tagExp.substring(0, separatorIndex);
		tagExp = tagExp.substring(separatorIndex + 1).trimStart();
	}
	const rawTagName = tagName;
	if (removeNSPrefix) {
		const colonIndex = tagName.indexOf(":");
		if (colonIndex !== -1) {
			tagName = tagName.substr(colonIndex + 1);
			attrExpPresent = tagName !== result.data.substr(colonIndex + 1);
		}
	}
	return {
		tagName,
		tagExp,
		closeIndex,
		attrExpPresent,
		rawTagName
	};
}
/**
* find paired tag for a stop node
* @param {string} xmlData 
* @param {string} tagName 
* @param {number} i 
*/
function readStopNodeData(xmlData, tagName, i) {
	const startIndex = i;
	let openTagCount = 1;
	const xmllen = xmlData.length;
	for (; i < xmllen; i++) if (xmlData[i] === "<") {
		const c1 = xmlData.charCodeAt(i + 1);
		if (c1 === 47) {
			const closeIndex = findClosingChar(xmlData, ">", i, `${tagName} is not closed`);
			if (xmlData.substring(i + 2, closeIndex).trim() === tagName) {
				openTagCount--;
				if (openTagCount === 0) return {
					tagContent: xmlData.substring(startIndex, i),
					i: closeIndex
				};
			}
			i = closeIndex;
		} else if (c1 === 63) i = findClosingIndex(xmlData, "?>", i + 1, "StopNode is not closed.");
		else if (c1 === 33 && xmlData.charCodeAt(i + 2) === 45 && xmlData.charCodeAt(i + 3) === 45) i = findClosingIndex(xmlData, "-->", i + 3, "StopNode is not closed.");
		else if (c1 === 33 && xmlData.charCodeAt(i + 2) === 91) i = findClosingIndex(xmlData, "]]>", i, "StopNode is not closed.") - 2;
		else {
			const tagData = readTagExp(xmlData, i, false);
			if (tagData) {
				if ((tagData && tagData.tagName) === tagName && tagData.tagExp[tagData.tagExp.length - 1] !== "/") openTagCount++;
				i = tagData.closeIndex;
			}
		}
	}
}
function parseValue(val, shouldParse, options) {
	if (shouldParse && typeof val === "string") {
		const newval = val.trim();
		if (newval === "true") return true;
		else if (newval === "false") return false;
		else return toNumber(val, options);
	} else if (isExist(val)) return val;
	else return "";
}
function transformTagName(fn, tagName, tagExp, options) {
	if (fn) {
		const newTagName = fn(tagName);
		if (tagExp === tagName) tagExp = newTagName;
		tagName = newTagName;
	}
	tagName = sanitizeName(tagName, options);
	return {
		tagName,
		tagExp
	};
}
function sanitizeName(name, options) {
	if (criticalProperties.includes(name)) throw new Error(`[SECURITY] Invalid name: "${name}" is a reserved JavaScript keyword that could cause prototype pollution`);
	else if (DANGEROUS_PROPERTY_NAMES.includes(name)) return options.onDangerousProperty(name);
	return name;
}
//#endregion
//#region node_modules/.pnpm/fast-xml-parser@5.8.0/node_modules/fast-xml-parser/src/xmlparser/node2json.js
var METADATA_SYMBOL = XmlNode.getMetaDataSymbol();
/**
* Helper function to strip attribute prefix from attribute map
* @param {object} attrs - Attributes with prefix (e.g., {"@_class": "code"})
* @param {string} prefix - Attribute prefix to remove (e.g., "@_")
* @returns {object} Attributes without prefix (e.g., {"class": "code"})
*/
function stripAttributePrefix(attrs, prefix) {
	if (!attrs || typeof attrs !== "object") return {};
	if (!prefix) return attrs;
	const rawAttrs = {};
	for (const key in attrs) if (key.startsWith(prefix)) {
		const rawName = key.substring(prefix.length);
		rawAttrs[rawName] = attrs[key];
	} else rawAttrs[key] = attrs[key];
	return rawAttrs;
}
/**
* 
* @param {array} node 
* @param {any} options 
* @param {Matcher} matcher - Path matcher instance
* @returns 
*/
function prettify(node, options, matcher, readonlyMatcher) {
	return compress(node, options, matcher, readonlyMatcher);
}
/**
* @param {array} arr 
* @param {object} options 
* @param {Matcher} matcher - Path matcher instance
* @returns object
*/
function compress(arr, options, matcher, readonlyMatcher) {
	let text;
	const compressedObj = {};
	for (let i = 0; i < arr.length; i++) {
		const tagObj = arr[i];
		const property = propName(tagObj);
		if (property !== void 0 && property !== options.textNodeName) {
			const rawAttrs = stripAttributePrefix(tagObj[":@"] || {}, options.attributeNamePrefix);
			matcher.push(property, rawAttrs);
		}
		if (property === options.textNodeName) {
			if (text === void 0) text = tagObj[property];
			else text += "" + tagObj[property];
		} else if (property === void 0) continue;
		else if (tagObj[property]) {
			let val = compress(tagObj[property], options, matcher, readonlyMatcher);
			const isLeaf = isLeafTag(val, options);
			if (Object.keys(val).length === 0 && options.alwaysCreateTextNode) val[options.textNodeName] = "";
			if (tagObj[":@"]) assignAttributes(val, tagObj[":@"], readonlyMatcher, options);
			else if (Object.keys(val).length === 1 && val[options.textNodeName] !== void 0 && !options.alwaysCreateTextNode) val = val[options.textNodeName];
			else if (Object.keys(val).length === 0) {
				if (options.alwaysCreateTextNode) val[options.textNodeName] = "";
				else val = "";
			}
			if (tagObj[METADATA_SYMBOL] !== void 0 && typeof val === "object" && val !== null) val[METADATA_SYMBOL] = tagObj[METADATA_SYMBOL];
			if (compressedObj[property] !== void 0 && Object.prototype.hasOwnProperty.call(compressedObj, property)) {
				if (!Array.isArray(compressedObj[property])) compressedObj[property] = [compressedObj[property]];
				compressedObj[property].push(val);
			} else {
				const jPathOrMatcher = options.jPath ? readonlyMatcher.toString() : readonlyMatcher;
				if (options.isArray(property, jPathOrMatcher, isLeaf)) compressedObj[property] = [val];
				else compressedObj[property] = val;
			}
			if (property !== void 0 && property !== options.textNodeName) matcher.pop();
		}
	}
	if (typeof text === "string") {
		if (text.length > 0) compressedObj[options.textNodeName] = text;
	} else if (text !== void 0) compressedObj[options.textNodeName] = text;
	return compressedObj;
}
function propName(obj) {
	const keys = Object.keys(obj);
	for (let i = 0; i < keys.length; i++) {
		const key = keys[i];
		if (key !== ":@") return key;
	}
}
function assignAttributes(obj, attrMap, readonlyMatcher, options) {
	if (attrMap) {
		const keys = Object.keys(attrMap);
		const len = keys.length;
		for (let i = 0; i < len; i++) {
			const atrrName = keys[i];
			const rawAttrName = atrrName.startsWith(options.attributeNamePrefix) ? atrrName.substring(options.attributeNamePrefix.length) : atrrName;
			const jPathOrMatcher = options.jPath ? readonlyMatcher.toString() + "." + rawAttrName : readonlyMatcher;
			if (options.isArray(atrrName, jPathOrMatcher, true, true)) obj[atrrName] = [attrMap[atrrName]];
			else obj[atrrName] = attrMap[atrrName];
		}
	}
}
function isLeafTag(obj, options) {
	const { textNodeName } = options;
	const propCount = Object.keys(obj).length;
	if (propCount === 0) return true;
	if (propCount === 1 && (obj[textNodeName] || typeof obj[textNodeName] === "boolean" || obj[textNodeName] === 0)) return true;
	return false;
}
//#endregion
//#region node_modules/.pnpm/fast-xml-parser@5.8.0/node_modules/fast-xml-parser/src/xmlparser/XMLParser.js
var XMLParser = class {
	constructor(options) {
		this.externalEntities = {};
		this.options = buildOptions(options);
	}
	/**
	* Parse XML dats to JS object 
	* @param {string|Uint8Array} xmlData 
	* @param {boolean|Object} validationOption 
	*/
	parse(xmlData, validationOption) {
		if (typeof xmlData !== "string" && xmlData.toString) xmlData = xmlData.toString();
		else if (typeof xmlData !== "string") throw new Error("XML data is accepted in String or Bytes[] form.");
		if (validationOption) {
			if (validationOption === true) validationOption = {};
			const result = validate(xmlData, validationOption);
			if (result !== true) throw Error(`${result.err.msg}:${result.err.line}:${result.err.col}`);
		}
		const orderedObjParser = new OrderedObjParser(this.options, this.externalEntities);
		const orderedResult = orderedObjParser.parseXml(xmlData);
		if (this.options.preserveOrder || orderedResult === void 0) return orderedResult;
		else return prettify(orderedResult, this.options, orderedObjParser.matcher, orderedObjParser.readonlyMatcher);
	}
	/**
	* Add Entity which is not by default supported by this library
	* @param {string} key 
	* @param {string} value 
	*/
	addEntity(key, value) {
		if (value.indexOf("&") !== -1) throw new Error("Entity value can't have '&'");
		else if (key.indexOf("&") !== -1 || key.indexOf(";") !== -1) throw new Error("An entity must be set without '&' and ';'. Eg. use '#xD' for '&#xD;'");
		else if (value === "&") throw new Error("An entity with value '&' is not permitted");
		else this.externalEntities[key] = value;
	}
	/**
	* Returns a Symbol that can be used to access the metadata
	* property on a node.
	* 
	* If Symbol is not available in the environment, an ordinary property is used
	* and the name of the property is here returned.
	* 
	* The XMLMetaData property is only present when `captureMetaData`
	* is true in the options.
	*/
	static getMetaDataSymbol() {
		return XmlNode.getMetaDataSymbol();
	}
};
//#endregion
//#region src/server/lib/audit/crawl-throttle.ts
var import_robots_parser = /* @__PURE__ */ __toESM(require_robots_parser(), 1);
/**
* Pacing and 429 handling for one audit's origin.
*
* Every 429 pauses the whole crawl for the server's Retry-After (or an
* escalating default), and the refused URL gets one more try after the pause.
* A URL refused again is recorded as rate limited and the crawl moves on.
* Shopify's edge, for one, refuses individual listing pages to crawlers while
* serving everything around them, and a single such URL used to end audits
* thousands of pages in. The crawl stops only when the site refuses several
* URLs in a row without serving any, or has kept the crawler waiting for hours
* in total.
*/
/** Retries per URL after its first 429. Every 429 still pauses new URLs. */
var MAX_429_RETRIES = 1;
/** URLs given up on in a row, with no page served between them, before the crawl stops. */
var MAX_REFUSED_URLS = 3;
var FIRST_DELAY_MS = 3e4;
var MIN_INTERVAL_MS = 1e3;
var MAX_INTERVAL_MS = 1e4;
/** Pages served in a row before pacing returns to normal. */
var RECOVERY_PAGES = 20;
/**
* Waiting on 429s one audit may do in total. Cumulative, never reset: a site
* that interleaves refusals with served pages must still end, and a rendered
* audit must settle inside its 24-hour credit lock. Room for about sixty
* refused URLs at Shopify's 60-second Retry-After.
*/
var MAX_COOLDOWN_MS = 72e5;
/** Longest single wait on a 429 during discovery. */
var DISCOVERY_WAIT_MS = 6e4;
/** All the waiting on 429s one discovery run may do, inside its step timeout. */
var DISCOVERY_WAIT_BUDGET_MS = 12e4;
/** `Retry-After` is either delay-seconds or an HTTP-date. */
function parseRetryAfterMs(header) {
	if (!header) return null;
	const value = header.trim();
	if (/^\d+$/.test(value)) return Math.min(Number(value) * 1e3, 7200001);
	const at = Date.parse(value);
	return Number.isNaN(at) ? null : Math.max(0, at - Date.now());
}
/** One audit's origin pacing. Long waits are resumed by the workflow. */
function createCrawlThrottle(deadlineAt, previous, persist) {
	const state = {
		intervalMs: MIN_INTERVAL_MS,
		nextRequestAt: 0,
		pausedUntil: 0,
		givenUpRun: 0,
		served: 0,
		cooldownMs: 0,
		...previous,
		refusals: { ...previous?.refusals }
	};
	let checkpointFailed = false;
	let checkpoint = Promise.resolve();
	const snapshot = () => ({
		...state,
		refusals: { ...state.refusals }
	});
	const save = () => {
		const saved = snapshot();
		checkpoint = checkpoint.then(() => persist?.(saved)).catch((error) => {
			checkpointFailed = true;
			throw error;
		});
		return checkpoint;
	};
	const stopped = () => checkpointFailed || state.givenUpRun >= MAX_REFUSED_URLS || state.cooldownMs > MAX_COOLDOWN_MS;
	/** Record the `count`th 429 of `url` and pause the origin. */
	const pause = async (url, count, retryAfter) => {
		state.served = 0;
		if (count === 1) state.intervalMs = Math.min(MAX_INTERVAL_MS, state.intervalMs * 2);
		if (count > MAX_429_RETRIES) {
			delete state.refusals[url];
			state.givenUpRun += 1;
		} else state.refusals[url] = count;
		const delayMs = Math.max(state.intervalMs, parseRetryAfterMs(retryAfter) ?? FIRST_DELAY_MS * 2 ** state.givenUpRun);
		const now = Date.now();
		const pausedUntil = Math.max(state.pausedUntil, now + delayMs);
		state.cooldownMs += pausedUntil - Math.max(now, state.pausedUntil);
		state.pausedUntil = pausedUntil;
		await save();
	};
	return {
		async ready() {
			while (!stopped()) {
				await checkpoint;
				const now = Date.now();
				const readyAt = Math.max(state.pausedUntil, state.nextRequestAt);
				if (now >= deadlineAt || readyAt >= deadlineAt) return false;
				if (readyAt <= now) {
					state.nextRequestAt = now + state.intervalMs;
					return true;
				}
				await new Promise((resolve) => setTimeout(resolve, readyAt - now));
			}
			return false;
		},
		async backoff(url, retryAfter) {
			const count = (state.refusals[url] ?? 0) + 1;
			await pause(url, count, retryAfter);
			return !stopped() && count <= MAX_429_RETRIES;
		},
		async refuse(url, retryAfter) {
			await pause(url, 2, retryAfter);
		},
		async recovered(url) {
			state.served += 1;
			delete state.refusals[url];
			const normalPace = state.served >= RECOVERY_PAGES && state.intervalMs > MIN_INTERVAL_MS;
			if (normalPace) state.intervalMs = MIN_INTERVAL_MS;
			if (state.givenUpRun === 0 && !normalPace) return;
			state.givenUpRun = 0;
			await save();
		},
		get checkpointFailed() {
			return checkpointFailed;
		},
		get stopped() {
			return stopped();
		},
		get state() {
			return snapshot();
		}
	};
}
/**
* One discovery run's shared wait on 429s. A refused robots.txt or sitemap is
* retried once after the server's Retry-After. Refusals that arrive together
* share one pause, and the run waits at most DISCOVERY_WAIT_BUDGET_MS in all
* so the discovery step keeps to its timeout. Before this, a sitemap shard
* refused at first contact was silently dropped with every URL in it, and a
* refused robots.txt read as "everything allowed".
*/
function createRateLimitWait() {
	let pausedUntil = 0;
	let waitedMs = 0;
	return async (response) => {
		const now = Date.now();
		const delayMs = Math.min(parseRetryAfterMs(response.headers.get("retry-after")) ?? DISCOVERY_WAIT_MS, DISCOVERY_WAIT_MS);
		const until = Math.max(pausedUntil, now + delayMs);
		const added = until - Math.max(now, pausedUntil);
		if (waitedMs + added > DISCOVERY_WAIT_BUDGET_MS) return false;
		waitedMs += added;
		pausedUntil = until;
		await response.body?.cancel();
		await new Promise((resolve) => setTimeout(resolve, until - now));
		return true;
	};
}
//#endregion
//#region src/server/lib/audit/discovery.ts
/**
* robots.txt and sitemap.xml discovery for the site audit crawler.
*/
var SITEMAP_FETCH_TIMEOUT_MS = 15e3;
var MAX_ROBOTS_TXT_BYTES = 512e3;
var MAX_SITEMAP_DEPTH = 3;
var MAX_SITEMAP_DOCS = 300;
var SITEMAP_CONCURRENCY = 5;
var SITEMAP_RETRIES = 1;
var MAX_SITEMAP_BYTES = 10485760;
var xmlParser = new XMLParser({
	ignoreAttributes: false,
	isArray: (name) => name === "sitemap" || name === "url"
});
/**
* Fetch the raw robots.txt body (null = missing/unreachable). Kept separate
* from parsing so Workflows can checkpoint the text as durable step state and
* re-derive the parsed result deterministically on replay.
*/
async function fetchRobotsTxtText(origin, access, waitForRateLimit) {
	try {
		const fetchRobots = () => fetchFollowingRedirects(`${origin}/robots.txt`, 1e4, access);
		let fetched = await fetchRobots();
		if (fetched?.response.status === 429 && await waitForRateLimit(fetched.response)) fetched = await fetchRobots();
		if (!fetched?.response.ok) return null;
		return (await fetched.response.text()).slice(0, MAX_ROBOTS_TXT_BYTES);
	} catch (error) {
		console.warn("Failed to fetch robots.txt:", error);
		return null;
	}
}
var MAX_DISCOVERY_REDIRECT_HOPS = 5;
/**
* Redirects are followed by hand so each hop is revalidated against the crawl
* policy and crawler-access headers \u2014 bot-protection credentials \u2014 are
* re-matched against the hop's host instead of riding along to another site.
*/
async function fetchFollowingRedirects(url, timeoutMs, access) {
	const deadline = Date.now() + timeoutMs;
	let current = url;
	for (let hop = 0; hop <= MAX_DISCOVERY_REDIRECT_HOPS; hop++) {
		const response = await publicFetch(current, {
			headers: await auditRequestHeaders(current, access),
			redirect: "manual",
			signal: AbortSignal.timeout(Math.max(1, deadline - Date.now()))
		});
		if (response.status < 300 || response.status >= 400) return {
			response,
			finalUrl: current
		};
		const location = response.headers.get("location");
		await response.body?.cancel();
		if (!location) return null;
		let next;
		try {
			next = new URL(location, current).toString();
		} catch {
			return null;
		}
		if (!isCrawlableUrl(next)) return null;
		current = next;
	}
	return null;
}
/** Deterministic: same text in, same result out. Null = everything allowed. */
function parseRobotsTxt(origin, text) {
	if (text === null) return {
		isAllowed: () => true,
		sitemapUrls: []
	};
	const robots = (0, import_robots_parser.default)(`${origin}/robots.txt`, text);
	return {
		isAllowed: (url) => robots.isAllowed(url, "OpenSEO-Audit/1.0") ?? true,
		sitemapUrls: robots.getSitemaps()
	};
}
/**
* Fetch and parse a sitemap (supports sitemap index recursion).
* Returns a flat list of page URLs found.
*/
function isProbablySitemapXml(contentType, body) {
	if (contentType?.toLowerCase().includes("xml")) return true;
	const trimmed = body.trimStart().toLowerCase();
	return trimmed.startsWith("<?xml") || trimmed.startsWith("<urlset") || trimmed.startsWith("<sitemapindex");
}
function getSitemapLocations(input) {
	if (!input) return [];
	return (Array.isArray(input) ? input : [input]).map((entry) => {
		if (isRecord$6(entry)) {
			const loc = entry["loc"];
			return typeof loc === "string" ? loc : null;
		}
		return null;
	}).filter((loc) => typeof loc === "string");
}
function isRecord$6(value) {
	return !!value && typeof value === "object";
}
function getParsedSitemapSections(parsed) {
	if (!parsed || typeof parsed !== "object") return {
		sitemap: void 0,
		url: void 0
	};
	const root = parsed;
	return {
		sitemap: root.sitemapindex?.sitemap,
		url: root.urlset?.url
	};
}
function isTimeoutError(error) {
	if (!error || typeof error !== "object") return false;
	return "name" in error && error.name === "TimeoutError";
}
async function fetchSitemapDocumentWithRetry(sitemapUrl, access, waitForRateLimit) {
	const normalizedSitemapUrl = normalizeUrl(sitemapUrl);
	if (!normalizedSitemapUrl) return {
		nestedSitemaps: [],
		pageUrls: [],
		timedOut: false
	};
	let lastError = null;
	for (let attempt = 0; attempt <= SITEMAP_RETRIES; attempt++) try {
		const fetched = await fetchFollowingRedirects(normalizedSitemapUrl, SITEMAP_FETCH_TIMEOUT_MS, access);
		if (!fetched) return {
			nestedSitemaps: [],
			pageUrls: [],
			timedOut: false
		};
		const { response } = fetched;
		const finalUrl = normalizeUrl(fetched.finalUrl, normalizedSitemapUrl);
		if (!finalUrl || !isSameOrigin(finalUrl, normalizedSitemapUrl)) return {
			nestedSitemaps: [],
			pageUrls: [],
			timedOut: false
		};
		if (response.status === 429 && attempt < SITEMAP_RETRIES && await waitForRateLimit(response)) continue;
		if (!response.ok) return {
			nestedSitemaps: [],
			pageUrls: [],
			timedOut: false
		};
		const body = await readBodyCapped(response, MAX_SITEMAP_BYTES);
		if (body === null || !isProbablySitemapXml(response.headers.get("content-type"), body)) return {
			nestedSitemaps: [],
			pageUrls: [],
			timedOut: false
		};
		const sections = getParsedSitemapSections(xmlParser.parse(body));
		return {
			nestedSitemaps: getSitemapLocations(sections.sitemap).map((loc) => normalizeUrl(loc, finalUrl)).filter((loc) => loc !== null),
			pageUrls: getSitemapLocations(sections.url).map((loc) => normalizeUrl(loc, finalUrl)).filter((loc) => loc !== null),
			timedOut: false
		};
	} catch (error) {
		lastError = error;
		if (!isTimeoutError(error) || attempt === SITEMAP_RETRIES) break;
	}
	return {
		nestedSitemaps: [],
		pageUrls: [],
		timedOut: isTimeoutError(lastError)
	};
}
/**
* Discover all page URLs from robots.txt + sitemaps for an origin.
* Also tries the default /sitemap.xml if not listed in robots.txt.
*/
async function discoverUrls(origin, maxPages = 50, access) {
	const waitForRateLimit = createRateLimitWait();
	const robotsText = await fetchRobotsTxtText(origin, access, waitForRateLimit);
	const robots = parseRobotsTxt(origin, robotsText);
	const sitemapSources = new Set(robots.sitemapUrls);
	sitemapSources.add(`${origin}/sitemap.xml`);
	const maxDiscoveredUrls = Math.min(Math.max(maxPages * 20, 500), 5e4);
	const allUrls = /* @__PURE__ */ new Set();
	const queue = Array.from(sitemapSources).map((url) => normalizeUrl(url, origin)).filter((url) => url !== null).filter((url) => isSameOrigin(url, origin)).map((url) => ({
		url,
		depth: MAX_SITEMAP_DEPTH
	}));
	const seenSitemapDocs = /* @__PURE__ */ new Set();
	let fetchedDocs = 0;
	let failedDocs = 0;
	let timedOutDocs = 0;
	while (queue.length > 0 && allUrls.size < maxDiscoveredUrls) {
		if (fetchedDocs >= MAX_SITEMAP_DOCS) break;
		const batch = queue.splice(0, SITEMAP_CONCURRENCY);
		await Promise.all(batch.map(async ({ url, depth }) => {
			const normalizedUrl = normalizeUrl(url);
			if (!normalizedUrl || !isSameOrigin(normalizedUrl, origin) || depth <= 0 || seenSitemapDocs.has(normalizedUrl)) return;
			seenSitemapDocs.add(normalizedUrl);
			fetchedDocs += 1;
			const result = await fetchSitemapDocumentWithRetry(normalizedUrl, access, waitForRateLimit);
			if (result.pageUrls.length === 0 && result.nestedSitemaps.length === 0) {
				failedDocs += 1;
				if (result.timedOut) timedOutDocs += 1;
				return;
			}
			for (const pageUrl of result.pageUrls) {
				if (!isSameOrigin(pageUrl, origin)) continue;
				if (allUrls.size >= maxDiscoveredUrls) break;
				allUrls.add(pageUrl);
			}
			if (depth <= 1) return;
			for (const nestedUrl of result.nestedSitemaps) {
				if (!isSameOrigin(nestedUrl, origin)) continue;
				if (!seenSitemapDocs.has(nestedUrl)) queue.push({
					url: nestedUrl,
					depth: depth - 1
				});
			}
		}));
	}
	if (failedDocs > 0) console.warn(`Sitemap discovery completed with partial failures for ${origin}: fetched=${fetchedDocs}, failed=${failedDocs}, timedOut=${timedOutDocs}, discoveredUrls=${allUrls.size}`);
	return {
		urls: Array.from(allUrls),
		robotsText
	};
}
//#endregion
//#region src/server/lib/dataforseo/envelope.ts
/**
* Thrown when a DataForSEO task fails *after* it was billed (cost + path are
* present). meterDataforseoCall catches this to charge the customer for the
* failed-but-charged call before rethrowing. Do not throw this for access /
* balance failures; classify those first even when DataForSEO includes billing
* metadata on the failed task.
*/
var DataforseoChargedTaskError = class extends AppError {
	billing;
	isInvalidField;
	constructor(message, billing, isInvalidField = false, code = "INTERNAL_ERROR") {
		super(code, message);
		this.billing = billing;
		this.isInvalidField = isInvalidField;
		this.name = "DataforseoChargedTaskError";
	}
};
var billingMetadataSchema = object({
	path: array(string()),
	cost: number(),
	result_count: number().nullable().optional()
});
function tryBuildTaskBilling(task) {
	const parsed = billingMetadataSchema.safeParse(task);
	if (!parsed.success) return null;
	return {
		path: parsed.data.path,
		costUsd: parsed.data.cost
	};
}
function buildTaskBilling(task) {
	const billing = tryBuildTaskBilling(task);
	if (!billing) throw new AppError("INTERNAL_ERROR", "DataForSEO task is missing billing metadata (path/cost)");
	return billing;
}
var INVALID_FIELD_MESSAGE_RE = /Invalid Field:\s*'([^']+)'/i;
/** The request field a DataForSEO validation rejection names, if any. */
function invalidFieldName(message) {
	return message.match(INVALID_FIELD_MESSAGE_RE)?.[1] ?? null;
}
/**
* DataForSEO echoes the posted request params back on `task.data`. Its
* validation rejections are opaque ("Invalid Field: 'target'.") and name the
* field but not the value we sent \u2014 and these tasks are charged, so we want to
* know exactly what tripped them. Append the offending value so the charged
* failure is diagnosable from the captured message alone.
*/
function describeInvalidField(message, task) {
	const field = invalidFieldName(message);
	if (!field || !isRecord$5(task.data)) return message;
	const value = task.data[field];
	if (value === void 0) return message;
	return `${message} (sent ${field}=${JSON.stringify(value)})`;
}
/**
* DataForSEO's "No Search Results" (40501) \u2014 a successful empty result, not a
* failure. Match on the status message, not the code alone: 40501 also covers
* validation rejections like "Invalid Field: 'target'.", which are real charged
* failures we must surface rather than mask as empty results.
*/
function isNoResultsTask(task) {
	return task.status_message?.toLowerCase().includes("no search results") ?? false;
}
/**
* Status codes where DataForSEO's own backend failed, returned on an HTTP 200
* with a failed task. These are provider flakes, not our bug, so they classify
* as UPSTREAM_UNAVAILABLE: the customer gets the retry-in-a-moment message
* instead of a generic "unexpected error", and the flake isn't captured.
*
* An explicit list, not a `>= 50000` range: 40101 "Internal SE Server Error."
* is the one that actually fires (by far our loudest captured exception) and it
* sits in the 40000 family, while 50100 "Not Implemented." means we posted a
* non-existing task or parameter \u2014 our bug, and it must stay reportable.
* Likewise 50001 "Error While Checking the Balance." stays visible.
* @see https://docs.dataforseo.com/v3/appendix/errors/
*/
var UPSTREAM_FAILURE_STATUS_CODES = /* @__PURE__ */ new Set([
	40101,
	40103,
	5e4,
	50301,
	50302,
	50303,
	50304,
	50401,
	50402
]);
function isUpstreamFailureStatus(statusCode) {
	return statusCode !== void 0 && UPSTREAM_FAILURE_STATUS_CODES.has(statusCode);
}
/**
* Error for a response whose top-level status isn't a success. DataForSEO
* reports whole-request outages there too (a top-level 50000 "Internal Server
* Error."), so those classify as UPSTREAM_UNAVAILABLE exactly like a failed
* task does.
*/
function failedResponseError(response, fallbackMessage) {
	const message = response?.status_message || fallbackMessage;
	return new AppError(isUpstreamFailureStatus(response?.status_code) ? "UPSTREAM_UNAVAILABLE" : "INTERNAL_ERROR", message);
}
/**
* Warns when DataForSEO's own backend failed the whole request, for the same
* reason as the task-level branch in assertOk. Called where the response is
* parsed, since only the request knows its endpoint: a failed response carries
* no task path. Observability shows the object's `message` in place of the
* label, so the label is repeated as `event`.
*/
function warnIfUpstreamResponseFailed(response, path) {
	if (!isUpstreamFailureStatus(response?.status_code)) return;
	console.warn("dataforseo.upstream-response-failed", {
		event: "dataforseo.upstream-response-failed",
		path,
		status: response?.status_code,
		message: response?.status_message
	});
}
/**
* Validates that the top-level response and its first task both succeeded, and
* returns that (SDK-typed) task. The single status / billing ladder shared by
* every endpoint:
*  - access / balance failure -> classified AppError
*  - DataForSEO's own backend erring, on the response or the task ->
*    UPSTREAM_UNAVAILABLE
*  - charged-but-failed task (cost present) -> DataforseoChargedTaskError
*/
function assertOk(response, options = {}) {
	if (!response) throw new AppError("INTERNAL_ERROR", "DataForSEO returned an empty response");
	const { classify, classifyPath, treatNoResultsAsEmpty, okTaskStatusCode } = options;
	if (response.status_code !== 2e4) {
		const message = response.status_message || "DataForSEO request failed";
		throw classify?.(response.status_code, message, classifyPath ?? "") ?? failedResponseError(response, message);
	}
	const task = response.tasks?.[0];
	if (!task) throw new AppError("INTERNAL_ERROR", "DataForSEO response missing task");
	if (task.status_code !== (okTaskStatusCode ?? 2e4)) {
		if (treatNoResultsAsEmpty && isNoResultsTask(task)) return task;
		const message = task.status_message || "DataForSEO task failed";
		const path = classifyPath ?? (task.path ? `/${task.path.join("/")}` : "");
		const classified = classify?.(task.status_code, message, path);
		if (classified) throw classified;
		const detailedMessage = describeInvalidField(message, task);
		const isUpstreamFailure = isUpstreamFailureStatus(task.status_code);
		if (isUpstreamFailure) console.warn("dataforseo.upstream-task-failed", {
			event: "dataforseo.upstream-task-failed",
			path,
			taskId: task.id,
			status: task.status_code,
			message: task.status_message
		});
		const code = isUpstreamFailure ? "UPSTREAM_UNAVAILABLE" : "INTERNAL_ERROR";
		const billing = tryBuildTaskBilling(task);
		if (billing) throw new DataforseoChargedTaskError(detailedMessage, billing, INVALID_FIELD_MESSAGE_RE.test(message), code);
		throw new AppError(code, detailedMessage);
	}
	return task;
}
function isRecord$5(value) {
	return typeof value === "object" && value !== null;
}
/** Reads `task.result[0].total_count` for paginated list endpoints. */
function parseTaskTotalCount(task) {
	const first = task.result?.[0];
	if (!isRecord$5(first)) return null;
	return typeof first.total_count === "number" ? first.total_count : null;
}
/** Reads `task.result[0].items`, validating against a Zod schema for loosely-typed endpoints. */
function parseTaskItems(endpoint, task, itemSchema) {
	const first = task.result?.[0];
	const items = isRecord$5(first) ? first.items : [];
	const parsed = array(itemSchema).safeParse(items ?? []);
	if (!parsed.success) {
		console.error(`dataforseo.${endpoint}.invalid-payload`, parsed.error.issues.slice(0, 5));
		throw new AppError("INTERNAL_ERROR", `DataForSEO ${endpoint} returned an invalid response shape`);
	}
	return parsed.data;
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/protocol.js
var IDENTITY_HEADER = "x-everyapp-identity";
/**
* On a refusal the AppGateway binding makes itself (the app's manifest lacks
* the capability, the gateway holds no key), as opposed to the provider's
* own answer passed through: the refusal's code, also in the JSON body.
*/
var GATEWAY_ERROR_HEADER = "x-everyapp-error";
/**
* On a shared app's call to the AppGateway binding for work no request
* started (a cron, a Workflow step): the organization the work is for. The
* gateway believes it only from a shared app's Worker, and only for an
* active organization with a live member; an organization's own app may
* only name its own. The perimeter strips it, with every `x-everyapp-*`,
* from what browsers send.
*/
var ORG_HEADER = "x-everyapp-org";
/**
* On background work's call to an OAuth provider's API: the member whose
* connection to this app the call uses. Set by `for: { background: true,
* userId }`; the gateway reads it on the held-token branch only, for an
* organization's own app, and the perimeter strips it, with every
* `x-everyapp-*`, from browsers. It addresses a connection; it is not a
* permission: connecting in the app already lets the app use it.
*/
var USER_HEADER = "x-everyapp-user";
/** Env var carrying the app's manifest id. */
var APP_ID_ENV = "EVERYAPP_APP_ID";
/**
* Env var set to `1` on a shared app's Workers (one Worker for every
* organization): a gateway call from them must say whom it is for.
*/
var SHARED_ENV = "EVERYAPP_SHARED";
/**
* Linked dev (`everyapp dev --gateway`, docs/design/linked-dev.md): the
* dev Worker's env names the gateway-lite's loopback forwarder and the
* run's nonce, and the SDK builds a `{ fetch }` in place of the missing
* `EVERY_APP_GATEWAY` binding from them. Set by `everyAppWorker()` in a
* development build from the process environment `everyapp dev` starts
* the app with; never deployed.
*/
var LINKED_DEV_URL_ENV = "EVERYAPP_LINKED_DEV_URL";
var LINKED_DEV_NONCE_ENV = "EVERYAPP_LINKED_DEV_NONCE";
/** The header the forwarder requires, with the run's nonce: no simple cross-origin request can send it. */
var LINKED_DEV_HEADER = "x-everyapp-linked-dev";
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/catalog/commerce.js
var COMMERCE = {
	stripe: {
		mode: "api_key",
		label: "Stripe",
		description: "Payments: customers, subscriptions, invoices, charges and payouts.",
		auth: {
			kind: "bearer",
			secret: "STRIPE_API_KEY"
		},
		docs: "https://dashboard.stripe.com/apikeys",
		api: "https://docs.stripe.com/api",
		hosts: ["api.stripe.com", "files.stripe.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: ["POST", "DELETE"],
		accountWidePaths: [
			["v1", "account"],
			["v1", "accounts"],
			[
				"v2",
				"core",
				"accounts"
			],
			["v1", "webhook_endpoints"],
			[
				"v2",
				"core",
				"event_destinations"
			],
			[
				"v1",
				"apps",
				"secrets"
			]
		],
		hint: "A restricted API key from the API keys page of the Stripe dashboard, with only the permissions the app needs. The Gateway sends it as a bearer token.",
		secrets: [{
			name: "STRIPE_API_KEY",
			hint: "A restricted key (rk_live_...) with only the permissions the app needs; a sandbox key (rk_test_... or sk_test_...) to try it."
		}],
		smoke: {
			method: "GET",
			path: "/v1/balance",
			expect: [200],
			free: true,
			note: "A restricted key needs Balance read for this one."
		},
		cost: {
			unit: "call",
			note: "No per-call price; reads should average under 500 per transaction over 30 days, with at least 10,000 a month allowed."
		},
		rate: {
			perSecond: 100,
			note: "Live mode, per account; sandbox 25/s; most single endpoints 25/s; Search 20/s."
		},
		example: "list my latest customers and their subscriptions",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["payments", "billing"]
	},
	lemonsqueezy: {
		mode: "api_key",
		label: "Lemon Squeezy",
		description: "Merchant of record for software: stores, products, orders, subscriptions, license keys.",
		auth: {
			kind: "bearer",
			secret: "LEMONSQUEEZY_API_KEY"
		},
		docs: "https://app.lemonsqueezy.com/settings/api",
		api: "https://docs.lemonsqueezy.com/api",
		hosts: ["api.lemonsqueezy.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [["v1", "users"], ["v1", "webhooks"]],
		hint: "An API key from Settings > API in Lemon Squeezy; the Gateway sends it as a bearer token. The API is JSON:API, so the app sends Accept and Content-Type application/vnd.api+json.",
		secrets: [{
			name: "LEMONSQUEEZY_API_KEY",
			hint: "An API key from Settings > API; a test mode key reaches test mode store data only."
		}],
		smoke: {
			method: "GET",
			path: "/v1/users/me",
			expect: [200],
			free: true,
			note: "Account-wide, so the Gateway refuses it for apps; run it from the person's terminal."
		},
		rate: {
			perMinute: 300,
			note: "300 API calls per minute."
		},
		example: "list this month's orders and active subscriptions",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["payments", "billing"]
	},
	paddle: {
		mode: "api_key",
		label: "Paddle",
		description: "Paddle Billing: products, prices, customers, subscriptions and transactions.",
		auth: {
			kind: "bearer",
			secret: "PADDLE_API_KEY"
		},
		docs: "https://developer.paddle.com/api-reference/about/authentication/",
		api: "https://developer.paddle.com/api-reference/",
		hosts: ["api.paddle.com", "sandbox-api.paddle.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["account"],
			["settings"],
			["notification-settings"],
			["notifications"],
			["simulations"],
			["simulation-runs"],
			["client-tokens"],
			["checkout-domains"],
			["verifications"]
		],
		hint: "An API key from Paddle > My account > Settings > Authentication (API keys tab), with only the permissions the app needs; the Gateway sends it as a bearer token. Live and sandbox are separate hosts with separate keys.",
		secrets: [{
			name: "PADDLE_API_KEY",
			hint: "An API key (pdl_live_apikey_... or pdl_sdbx_apikey_...) with only the permissions the app needs; a sandbox key works on the sandbox host only."
		}],
		smoke: {
			method: "GET",
			path: "/event-types",
			expect: [200],
			free: true,
			note: "Paddle's own first request: needs no permissions. Send it to sandbox-api.paddle.com with a sandbox key."
		},
		rate: {
			perMinute: 240,
			note: "Per IP address; pricing previews 1,000 a minute; 20 immediate-charge updates per subscription an hour."
		},
		example: "list the active subscriptions that renew this week",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["payments", "billing"]
	},
	shopify: {
		mode: "api_key",
		label: "Shopify",
		description: "One store's Admin API (GraphQL): products, orders, customers and inventory.",
		auth: {
			kind: "header",
			secret: "SHOPIFY_API_TOKEN",
			header: "X-Shopify-Access-Token"
		},
		docs: "https://shopify.dev/docs/apps/build/authentication-authorization/legacy/admin-custom-apps",
		api: "https://shopify.dev/docs/api/admin-graphql",
		hosts: [],
		hostSetting: "SHOPIFY_HOST",
		data: "account",
		access: ["write"],
		readMethods: [],
		writeMethods: ["POST"],
		accountWidePaths: [["webhooks"], ["storefront_access_tokens"]],
		hint: "An Admin API access token from a custom app created in the store's admin, sent in the X-Shopify-Access-Token header to the store's myshopify.com host. Shopify no longer lets stores create new admin custom apps, and Dev Dashboard tokens expire after 24 hours, which the Gateway can't refresh yet.",
		secrets: [{
			name: "SHOPIFY_API_TOKEN",
			hint: "The Admin API access token of a custom app made in the store's admin (Apps > Develop apps > the app > API credentials); it is shown once."
		}, {
			name: "SHOPIFY_HOST",
			hint: "The store's own host, like your-store.myshopify.com."
		}],
		smoke: {
			method: "GET",
			path: "/admin/api/2026-10/shop.json",
			expect: [200],
			free: true,
			note: "The legacy REST read of the store; the Gateway forwards no GET for this entry, so run it from the person's terminal."
		},
		rate: { note: "GraphQL cost points per second by plan: Standard 100, Advanced 200, Plus 1,000, enterprise 2,000." },
		example: "list the ten newest orders and what was in them",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["ecommerce"]
	},
	plaid: {
		mode: "api_key",
		label: "Plaid",
		description: "Bank data: accounts, balances, transactions and identity, for the Items an app links.",
		auth: {
			kind: "header",
			secret: "PLAID_SECRET",
			header: "PLAID-SECRET"
		},
		docs: "https://dashboard.plaid.com/developers/keys",
		api: "https://plaid.com/docs/api/",
		hosts: ["sandbox.plaid.com", "production.plaid.com"],
		data: "account",
		access: ["read"],
		readMethods: ["POST"],
		accountWidePaths: [
			[
				"item",
				"webhook",
				"update"
			],
			[
				"item",
				"access_token",
				"invalidate"
			],
			["item", "remove"],
			["webhook_verification_key"],
			["dashboard_user"],
			["transfer"],
			["payment_initiation"]
		],
		hint: "Plaid needs a client_id and a secret on every call, in the JSON body or in the PLAID-CLIENT-ID and PLAID-SECRET headers. The Gateway puts on one header, so the app would have to send PLAID-CLIENT-ID itself. Every endpoint is a POST.",
		secrets: [{
			name: "PLAID_SECRET",
			hint: "The secret for one environment (Sandbox or Production) from the Keys page of the Plaid Dashboard."
		}],
		rate: { note: "Set per endpoint and per Item: /accounts/get allows 15 a minute per Item and 15,000 a minute per client." },
		example: "list the last 30 days of transactions on a linked account",
		verified: false,
		tags: ["finance", "banking"]
	},
	attio: {
		mode: "api_key",
		label: "Attio",
		description: "CRM: people, companies, deals, lists, notes and tasks in one Attio workspace.",
		auth: {
			kind: "bearer",
			secret: "ATTIO_API_KEY"
		},
		docs: "https://attio.com/help/reference/apps/generating-an-api-key",
		api: "https://docs.attio.com/rest-api/overview",
		hosts: ["api.attio.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["v2", "self"],
			["v2", "webhooks"],
			["v2", "workspace_members"]
		],
		hint: "An access token a workspace admin makes under Workspace settings > Developers, scoped to what the app needs; the Gateway sends it as a bearer token. Listing and searching records are POSTs, so an app that lists records needs write access.",
		secrets: [{
			name: "ATTIO_API_KEY",
			hint: "An access token from Workspace settings > Developers, with only the scopes the app needs."
		}],
		smoke: {
			method: "GET",
			path: "/v2/objects",
			expect: [200],
			free: true,
			note: "Lists the workspace's objects; needs the object_configuration:read scope. /v2/self answers 200 even for a revoked token."
		},
		rate: {
			perSecond: 100,
			note: "100 reads and 25 writes per second; listing records and entries also has score-based limits."
		},
		example: "find the companies we added this week and their open deals",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["crm"]
	},
	hubspot: {
		mode: "api_key",
		label: "HubSpot",
		description: "CRM and marketing: contacts, companies, deals, tickets and more in one HubSpot account.",
		auth: {
			kind: "bearer",
			secret: "HUBSPOT_API_TOKEN"
		},
		docs: "https://developers.hubspot.com/docs/apps/legacy-apps/private-apps/overview",
		api: "https://developers.hubspot.com/docs/api-reference/latest/overview",
		hosts: ["api.hubapi.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["account-info"],
			["settings", "users"],
			[
				"settings",
				"v3",
				"users"
			],
			["settings", "teams"],
			["app-webhooks"],
			["webhooks"],
			["webhooks-journal"],
			["oauth"]
		],
		hint: "An access token from a HubSpot legacy private app (Development > Legacy apps > Create legacy app > Private), scoped to what the app needs; the Gateway sends it as a bearer token. CRM search is a POST, so an app that searches needs write access.",
		secrets: [{
			name: "HUBSPOT_API_TOKEN",
			hint: "The access token of a legacy private app (Development > Legacy apps > the app > Auth), with only the scopes the app needs."
		}],
		smoke: {
			method: "GET",
			path: "/account-info/2026-09/details",
			expect: [200],
			free: true,
			note: "Account-wide, so the Gateway refuses it for apps; run it from the person's terminal."
		},
		rate: {
			perDay: 25e4,
			note: "Private apps on Free and Starter: 100 per 10 seconds per app and 250,000 a day per account; Pro 190 and 625,000; Enterprise 190 and 1,000,000."
		},
		example: "list the deals that moved to closed won this month",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["crm", "marketing"]
	},
	pipedrive: {
		mode: "api_key",
		label: "Pipedrive",
		description: "Sales CRM: deals, persons, organizations, activities and pipelines.",
		auth: {
			kind: "header",
			secret: "PIPEDRIVE_API_TOKEN",
			header: "x-api-token"
		},
		docs: "https://app.pipedrive.com/settings/api",
		api: "https://developers.pipedrive.com/docs/api/v1",
		hosts: ["api.pipedrive.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["v1", "users"],
			["v1", "webhooks"],
			["v1", "billing"],
			["v1", "permissionsets"],
			["v1", "roles"],
			["v1", "usersettings"],
			["v1", "userconnections"],
			["v1", "legacyteams"]
		],
		hint: "A personal API token from Settings > Personal preferences > API in Pipedrive; the Gateway sends it in the x-api-token header. If API is missing there, an admin enables it for the person's permission set.",
		secrets: [{
			name: "PIPEDRIVE_API_TOKEN",
			hint: "Your personal API token from Settings > Personal preferences > API; it acts as you, and each company you belong to has its own."
		}],
		smoke: {
			method: "GET",
			path: "/v1/users/me",
			expect: [200],
			free: true,
			note: "Account-wide, so the Gateway refuses it for apps; run it from the person's terminal."
		},
		cost: {
			unit: "call",
			note: "Each endpoint spends API tokens from a daily company budget of 30,000 x plan multiplier (1 to 7) x seats."
		},
		rate: { note: "Per API token: 20 (Lite) to 120 (Ultimate) requests per 2 seconds; Search 10 per 2 seconds." },
		example: "list the open deals in my main pipeline",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["crm", "sales"]
	},
	airtable: {
		mode: "api_key",
		label: "Airtable",
		description: "Bases, tables and records in the Airtable workspaces a token can reach.",
		auth: {
			kind: "bearer",
			secret: "AIRTABLE_API_TOKEN"
		},
		docs: "https://airtable.com/create/tokens",
		api: "https://airtable.com/developers/web/api/introduction",
		hosts: ["api.airtable.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			[
				"v0",
				"meta",
				"whoami"
			],
			[
				"v0",
				"meta",
				"enterpriseaccounts"
			],
			[
				"v0",
				"meta",
				"workspaces"
			],
			[
				"v0",
				"meta",
				"groups"
			],
			["v0", "bases"],
			["scim"],
			["collaborators"],
			["invites"],
			["shares"],
			["blockinstallations"]
		],
		hint: "A personal access token from airtable.com/create/tokens, limited to the scopes and bases the app needs; the Gateway sends it as a bearer token. Listing records by POST (listRecords) needs write access; the GET form doesn't.",
		secrets: [{
			name: "AIRTABLE_API_TOKEN",
			hint: "A personal access token limited to the scopes and bases the app needs."
		}],
		smoke: {
			method: "GET",
			path: "/v0/meta/whoami",
			expect: [200],
			free: true,
			note: "Account-wide, so the Gateway refuses it for apps; run it from the person's terminal."
		},
		rate: {
			perSecond: 5,
			note: "5 requests per second per base; 50 per second across all of one user's personal access tokens."
		},
		example: "list this week's new rows in my Leads table",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["database", "spreadsheet"]
	},
	notion: {
		mode: "api_key",
		label: "Notion",
		description: "Pages, databases and blocks that a Notion connection has been given.",
		auth: {
			kind: "bearer",
			secret: "NOTION_API_TOKEN"
		},
		docs: "https://app.notion.com/developers/connections",
		api: "https://developers.notion.com/reference/intro",
		hosts: ["api.notion.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["v1", "users"],
			["v1", "oauth"],
			["admin"]
		],
		hint: "An internal connection's API token (a workspace owner creates the connection in Notion's developer portal), sent as a bearer token; it reaches only pages shared with it. The app sends the Notion-Version header itself. Search and data source queries are POSTs, so an app that queries needs write access.",
		secrets: [{
			name: "NOTION_API_TOKEN",
			hint: "The API token on an internal connection's Configuration tab; share the pages it should reach with the connection."
		}],
		smoke: {
			method: "GET",
			path: "/v1/users/me",
			expect: [200],
			free: true,
			note: "Send Notion-Version: 2026-03-11 with it; account-wide, so run it from the person's terminal."
		},
		rate: {
			perMinute: 180,
			note: "Per connection: 180 a minute, 600 on Business and Enterprise; data source queries about 3 per second."
		},
		example: "find the pages in my Projects database that are due this week",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"docs",
			"notes",
			"database"
		]
	}
};
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/catalog/comms.js
var COMMS = {
	postmark: {
		mode: "api_key",
		label: "Postmark",
		description: "Transactional email: single, batch and templated messages from one Postmark server.",
		auth: {
			kind: "header",
			secret: "POSTMARK_API_TOKEN",
			header: "X-Postmark-Server-Token"
		},
		docs: "https://postmarkapp.com/support/article/1008-what-are-the-account-and-server-api-tokens",
		api: "https://postmarkapp.com/developer/api/overview",
		hosts: ["api.postmarkapp.com"],
		data: "account",
		access: ["write"],
		readMethods: [],
		writeMethods: ["POST"],
		accountWidePaths: [
			["server"],
			["servers"],
			["domains"],
			["senders"],
			["webhooks"],
			["message-streams"],
			["triggers"],
			["data-removals"]
		],
		hint: "A Server API token from the API Tokens tab of the Postmark server the app sends from; the Gateway sends it in the X-Postmark-Server-Token header.",
		secrets: [{
			name: "POSTMARK_API_TOKEN",
			hint: "A Server API token from the server's API Tokens tab, never the Account API token."
		}],
		smoke: {
			method: "GET",
			path: "/server",
			expect: [200],
			free: true,
			note: "Returns the server's settings; account-wide, so run it from a terminal."
		},
		example: "send a password reset email",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["email", "transactional"]
	},
	sendgrid: {
		mode: "api_key",
		label: "SendGrid",
		description: "Twilio SendGrid email: send transactional and marketing mail through the v3 Mail Send API.",
		auth: {
			kind: "bearer",
			secret: "SENDGRID_API_KEY"
		},
		docs: "https://app.sendgrid.com/settings/api_keys",
		api: "https://www.twilio.com/docs/sendgrid/api-reference",
		hosts: ["api.sendgrid.com", "api.eu.sendgrid.com"],
		data: "account",
		access: ["write"],
		readMethods: [],
		writeMethods: ["POST"],
		accountWidePaths: [
			["api_keys"],
			["scopes"],
			["user"],
			["subusers"],
			["teammates"],
			["sso"],
			["access_settings"],
			["whitelabel"],
			["ips"],
			["send_ips"],
			["partners"],
			["partner_settings"],
			["alerts"],
			["mail_settings"],
			["tracking_settings"],
			["verified_senders"],
			["senders"],
			["marketing", "integrations"],
			["recipients", "erasejob"]
		],
		hint: "An API key from Settings > API Keys in SendGrid, sent as a bearer token; Custom Access with Mail Send alone is enough to send. EU regional subusers call api.eu.sendgrid.com.",
		secrets: [{
			name: "SENDGRID_API_KEY",
			hint: "A Custom Access key with Mail Send only, never a Full Access key."
		}],
		smoke: {
			method: "GET",
			path: "/v3/scopes",
			expect: [200],
			free: true,
			note: "Lists the key's own scopes (the docs don't say whether a Mail-Send-only key may call it); account-wide, so run it from a terminal."
		},
		rate: { note: "Each endpoint has its own limit; answers carry X-RateLimit-Limit, -Remaining and -Reset." },
		example: "send an order confirmation email",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"email",
			"transactional",
			"marketing"
		]
	},
	twilio: {
		mode: "api_key",
		label: "Twilio",
		description: "SMS, MMS and voice: send text messages and place calls from your Twilio numbers.",
		auth: {
			kind: "basic",
			secret: "TWILIO_API_SECRET",
			as: "password",
			user: { secret: "TWILIO_API_KEY" }
		},
		docs: "https://www.twilio.com/docs/iam/api-keys/keys-in-console",
		api: "https://www.twilio.com/docs/usage/requests-to-twilio",
		hosts: ["api.twilio.com"],
		data: "account",
		access: ["write"],
		readMethods: [],
		writeMethods: ["POST"],
		accountWidePaths: [
			["keys"],
			["signingkeys"],
			["incomingphonenumbers"],
			["outgoingcallerids"],
			["applications"],
			["connectapps"],
			["authorizedconnectapps"],
			["addresses"],
			["sip"],
			["usage"],
			["balance"]
		],
		hint: "A Standard or Restricted API key from Account settings > API keys & auth tokens in the Twilio Console, sent as HTTP Basic (the key's SID and secret); a Standard key can't reach the Accounts or Keys resources. Every path names the account, so the app puts its Account SID in it: /2010-04-01/Accounts/<Account SID>/Messages.json, with a form-encoded body.",
		secrets: [{
			name: "TWILIO_API_SECRET",
			hint: "The API key's secret, shown once when the key is created."
		}, {
			name: "TWILIO_API_KEY",
			hint: "The SID of a Standard or Restricted API key, never a Main key or the Auth Token."
		}],
		example: "text a reminder to a customer's phone number",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"sms",
			"voice",
			"messaging"
		]
	},
	intercom: {
		mode: "api_key",
		label: "Intercom",
		description: "Customer messaging: contacts, companies, conversations, tickets and help center articles.",
		auth: {
			kind: "bearer",
			secret: "INTERCOM_API_TOKEN"
		},
		docs: "https://app.intercom.com/a/apps/_/developer-hub",
		api: "https://developers.intercom.com/docs/build-an-integration/learn-more/rest-apis",
		hosts: [
			"api.intercom.io",
			"api.eu.intercom.io",
			"api.au.intercom.io"
		],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["me"],
			["admins"],
			["teams"],
			["export"],
			["download"],
			["ip_allowlist"]
		],
		hint: "The Access Token of a private app in your workspace's Developer Hub, sent as a bearer token. Searching contacts, conversations or tickets is a POST, so an app that searches asks for write.",
		secrets: [{
			name: "INTERCOM_API_TOKEN",
			hint: "The Access Token on your private app's Configure > Authentication page in the Developer Hub."
		}],
		smoke: {
			method: "GET",
			path: "/me",
			expect: [200],
			free: true,
			note: "Returns the admin behind the token; account-wide, so run it from a terminal."
		},
		rate: {
			perMinute: 1e4,
			note: "Per workspace, shared by its private apps; 25,000 a minute across all apps; counted in 10-second windows."
		},
		example: "list the latest open conversations",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"support",
			"crm",
			"messaging"
		]
	},
	crisp: {
		mode: "api_key",
		label: "Crisp",
		description: "Customer chat: conversations, messages, people and visitors of one Crisp workspace.",
		auth: {
			kind: "basic",
			secret: "CRISP_API_KEY",
			as: "password",
			user: { secret: "CRISP_API_IDENTIFIER" }
		},
		docs: "https://docs.crisp.chat/guides/rest-api/authentication/website-token/",
		api: "https://docs.crisp.chat/references/rest-api/v1/",
		hosts: ["api.crisp.chat"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["operators"],
			["operator"],
			["teams"],
			["team"],
			["settings"],
			["verify"],
			["audit"],
			["plans"],
			["plugins"],
			["plugin"],
			["connect"]
		],
		hint: "A website token, which the workspace owner generates under Settings > Workspace Settings > Advanced configuration > API Token. The Gateway sends the identifier and key as HTTP Basic; the app sends X-Crisp-Tier: website on every call.",
		secrets: [{
			name: "CRISP_API_KEY",
			hint: "The token's key, shown once when the workspace owner generates it."
		}, {
			name: "CRISP_API_IDENTIFIER",
			hint: "The token's identifier, shown beside the key."
		}],
		rate: {
			perDay: 1e4,
			note: "The website token's daily quota."
		},
		example: "list the latest chat conversations on my website",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"support",
			"chat",
			"messaging"
		]
	},
	granola: {
		mode: "api_key",
		label: "Granola",
		description: "Meeting notes: list, search and read notes with their AI summaries, transcripts, folders and spaces.",
		auth: {
			kind: "bearer",
			secret: "GRANOLA_API_KEY"
		},
		docs: "https://docs.granola.ai/help-center/sharing/integrations/granola-api",
		api: "https://docs.granola.ai/introduction",
		hosts: ["public-api.granola.ai"],
		data: "account",
		access: ["read"],
		readMethods: ["GET", "POST"],
		accountWidePaths: [
			["audit"],
			["webhook-endpoints"],
			["legal-holds"]
		],
		hint: "An API key (grn_...) from the Granola desktop app's Settings > Connectors > API keys, on a Business or Enterprise plan; the Gateway sends it as a bearer token. It reads only the notes its scopes allow.",
		secrets: [{
			name: "GRANOLA_API_KEY",
			hint: "A personal or workspace API key (grn_...), with only the note scopes the apps need."
		}],
		rate: {
			perSecond: 5,
			note: "Bursts of 25 requests in 5 seconds; per user or per workspace, by the key's scope."
		},
		smoke: {
			method: "GET",
			path: "/v1/notes?page_size=1",
			expect: [200],
			free: true
		},
		example: "summarize what we decided in this week's customer calls",
		verified: {
			on: "2026-10-30",
			how: "docs"
		},
		tags: [
			"meetings",
			"notes",
			"transcripts"
		]
	},
	linear: {
		mode: "api_key",
		label: "Linear",
		description: "Issue tracking over GraphQL: issues, projects, cycles, comments and teams.",
		auth: {
			kind: "header",
			secret: "LINEAR_API_KEY",
			header: "Authorization"
		},
		docs: "https://linear.app/settings/account/security",
		api: "https://linear.app/developers/graphql",
		hosts: ["api.linear.app"],
		data: "account",
		access: ["write"],
		readMethods: [],
		writeMethods: ["POST"],
		accountWidePaths: [],
		hint: "A personal API key from Settings > Account > Security & access; the Gateway sends it as the Authorization header with no Bearer word. Every call is a POST to /graphql, queries included, so the app asks for write.",
		secrets: [{
			name: "LINEAR_API_KEY",
			hint: "A personal API key, restricted to the permissions and teams the app needs."
		}],
		rate: { note: "2,500 requests and 3,000,000 complexity points an hour per API key." },
		example: "create an issue for this bug in the Engineering team",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"issues",
			"project-management",
			"graphql"
		]
	},
	github: {
		mode: "api_key",
		label: "GitHub",
		description: "Code hosting: repositories, issues, pull requests, Actions and releases through the REST API.",
		auth: {
			kind: "bearer",
			secret: "GITHUB_API_TOKEN"
		},
		docs: "https://github.com/settings/personal-access-tokens/new",
		api: "https://docs.github.com/en/rest",
		hosts: ["api.github.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["user", "email"],
			["user", "emails"],
			["user", "public_emails"],
			["user", "gpg_keys"],
			["user", "ssh_signing_keys"],
			["user", "social_accounts"],
			["keys"],
			["hooks"],
			["secrets"],
			["members"],
			["memberships"],
			["invitations"],
			["failed_invitations"],
			["collaborators"],
			["outside_collaborators"],
			["blocks"],
			["installations"],
			["personal-access-tokens"],
			["personal-access-token-requests"],
			["credential-authorizations"],
			["audit-log"],
			["billing"]
		],
		hint: "A fine-grained personal access token from Settings > Developer settings, limited to one owner, the repositories the app needs and the least permissions; sent as a bearer token. GraphQL is a POST to /graphql, so it needs write.",
		secrets: [{
			name: "GITHUB_API_TOKEN",
			hint: "A fine-grained personal access token limited to the repositories and permissions the app needs."
		}],
		smoke: {
			method: "GET",
			path: "/user",
			expect: [200],
			free: true,
			note: "Returns the token's owner; 401 means the token is wrong."
		},
		rate: { note: "5,000 requests an hour per token; at most 100 concurrent requests and 900 points a minute across REST endpoints." },
		example: "list the open pull requests in my repository",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"code",
			"git",
			"issues"
		]
	},
	gitlab: {
		mode: "api_key",
		label: "GitLab",
		description: "Code hosting on GitLab.com: projects, issues, merge requests, pipelines and releases.",
		auth: {
			kind: "header",
			secret: "GITLAB_API_TOKEN",
			header: "PRIVATE-TOKEN"
		},
		docs: "https://gitlab.com/-/user_settings/personal_access_tokens",
		api: "https://docs.gitlab.com/api/rest/",
		hosts: ["gitlab.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["user"],
			["personal_access_tokens"],
			["access_tokens"],
			["deploy_tokens"],
			["deploy_keys"],
			["project_deploy_keys"],
			["hooks"],
			["members"],
			["pending_members"],
			["billable_members"],
			["invitations"],
			["variables"],
			["audit_events"]
		],
		hint: "A personal, project or group access token from GitLab.com, sent in the PRIVATE-TOKEN header; read_api is enough to read. Paths start with /api/v4. A self-managed GitLab needs its own registered provider.",
		secrets: [{
			name: "GITLAB_API_TOKEN",
			hint: "A personal, project or group access token with read_api, or api when the app writes."
		}],
		smoke: {
			method: "GET",
			path: "/api/v4/personal_access_tokens/self",
			expect: [200],
			free: true,
			note: "Describes a personal access token itself (401 when it is wrong or revoked); account-wide, so run it from a terminal."
		},
		rate: {
			perMinute: 2e3,
			note: "Authenticated API traffic per user on GitLab.com."
		},
		example: "list the open merge requests in my project",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"code",
			"git",
			"ci"
		]
	},
	vercel: {
		mode: "api_key",
		label: "Vercel",
		description: "Frontend hosting: projects, deployments, domains and logs through the Vercel REST API.",
		auth: {
			kind: "bearer",
			secret: "VERCEL_API_TOKEN"
		},
		docs: "https://vercel.com/account/tokens",
		api: "https://vercel.com/docs/rest-api",
		hosts: ["api.vercel.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["user"],
			["teams"],
			["members"],
			["organizations"],
			["access-groups"],
			["billing"],
			["webhooks"],
			["drains"],
			["env"],
			["v3", "events"],
			["v1", "events"],
			["v1", "integrations"],
			["installations"],
			["connect"],
			["kms"],
			["api-keys"],
			["ai-gateway"],
			["token"],
			["tokens"],
			["registrar"],
			["transfer-request"]
		],
		hint: "An access token from your account's Tokens page, sent as a bearer token; scope it to one team or one project. A team- or project-scoped token needs no teamId parameter.",
		secrets: [{
			name: "VERCEL_API_TOKEN",
			hint: "An access token scoped to one team or one project, never Full Account."
		}],
		smoke: {
			method: "GET",
			path: "/v10/projects",
			expect: [200],
			free: true,
			note: "Lists the projects the token can reach."
		},
		rate: { note: "Limits are per action (deployments, domains, teams), listed on Vercel's limits page." },
		example: "list the latest deployments of my project",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"hosting",
			"deploy",
			"frontend"
		]
	}
};
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/catalog/infra.js
var INFRA = {
	cloudflare: {
		mode: "api_key",
		label: "Cloudflare",
		description: "Cloudflare's API: zones, DNS, Workers, R2, D1, KV and the rest of an account.",
		auth: {
			kind: "bearer",
			secret: "CLOUDFLARE_PROVIDER_API_TOKEN"
		},
		docs: "https://dash.cloudflare.com/profile/api-tokens",
		api: "https://developers.cloudflare.com/api/",
		hosts: ["api.cloudflare.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			[
				"client",
				"v4",
				"user"
			],
			[
				"client",
				"v4",
				"memberships"
			],
			[
				"client",
				"v4",
				"organizations"
			],
			[
				"client",
				"v4",
				"tenants"
			],
			["members"],
			["tokens"],
			["roles"],
			["iam"],
			["subscriptions"],
			["payment-methods"],
			["pay-invoice"],
			["receipts"],
			["invoices"],
			["client-secret"],
			["billing"],
			["logs", "audit"],
			["audit_logs"],
			[
				"alerting",
				"v3",
				"destinations",
				"webhooks"
			],
			["ai", "run"],
			["ai", "v1"]
		],
		hint: "An API token from My Profile > API Tokens with only the permissions the app needs; the Gateway sends it as a bearer token. A token on the Gateway's own account can read and change the Gateway, so keep it narrow or use another account.",
		secrets: [{
			name: "CLOUDFLARE_PROVIDER_API_TOKEN",
			hint: "A user or account-owned API token scoped to the zones and permissions the app needs, never a Global API Key."
		}],
		smoke: {
			method: "GET",
			path: "/client/v4/user/tokens/verify",
			expect: [200],
			free: true,
			note: "For a user token; account-owned tokens use /client/v4/accounts/<id>/tokens/verify. Account-wide, so run it from the person's terminal."
		},
		rate: { note: "1,200 requests per 5 minutes per user or account token; 200 a second per IP; GraphQL by query cost, at most 320 per 5 minutes." },
		example: "list the DNS records for my domain",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"infrastructure",
			"dns",
			"hosting"
		]
	},
	posthog: {
		mode: "api_key",
		label: "PostHog",
		description: "Product analytics: insights, feature flags, persons, cohorts, experiments and HogQL queries.",
		auth: {
			kind: "bearer",
			secret: "POSTHOG_PERSONAL_API_KEY"
		},
		docs: "https://us.posthog.com/settings/user-api-keys",
		api: "https://posthog.com/docs/api",
		hosts: ["us.posthog.com", "eu.posthog.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["api", "users"],
			["api", "user"],
			["api", "organizations"],
			["api", "billing"],
			["api", "revoke_leaked_key"],
			["project_secret_api_keys"],
			["billing"],
			["activity_log"],
			["advanced_activity_logs"],
			["hog_functions"],
			["batch_exports"],
			["integrations"]
		],
		hint: "A personal API key from Settings > Personal API keys, with only the scopes the app needs; the Gateway sends it as a bearer token to us.posthog.com or eu.posthog.com. HogQL queries are POSTs, so an app that runs them asks for write.",
		secrets: [{
			name: "POSTHOG_PERSONAL_API_KEY",
			hint: "A personal API key (phx_...) with only the scopes the app needs, from the region the project lives in; never the project token."
		}],
		smoke: {
			method: "GET",
			host: "us.posthog.com",
			path: "/api/users/@me/",
			expect: [200],
			free: true,
			note: "Needs the user:read scope; use eu.posthog.com for an EU project. Account-wide, so run it from the person's terminal."
		},
		rate: {
			perMinute: 480,
			note: "Create, read, update and delete endpoints 480 a minute and 4,800 an hour; analytics endpoints 240 a minute; the query endpoint 2,400 an hour."
		},
		example: "list the feature flags in my project and whether each is on",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"analytics",
			"product",
			"feature-flags"
		]
	},
	mixpanel: {
		mode: "api_key",
		label: "Mixpanel",
		description: "Product analytics: saved reports, profiles, raw event export and event import.",
		auth: {
			kind: "basic",
			secret: "MIXPANEL_SERVICE_ACCOUNT_SECRET",
			as: "password",
			user: { secret: "MIXPANEL_SERVICE_ACCOUNT_USERNAME" }
		},
		docs: "https://mixpanel.com/settings/org#serviceaccounts",
		api: "https://docs.mixpanel.com/reference/overview",
		hosts: [
			"mixpanel.com",
			"eu.mixpanel.com",
			"in.mixpanel.com",
			"data.mixpanel.com",
			"data-eu.mixpanel.com",
			"data-in.mixpanel.com",
			"api.mixpanel.com",
			"api-eu.mixpanel.com",
			"api-in.mixpanel.com"
		],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			[
				"api",
				"app",
				"me"
			],
			[
				"api",
				"app",
				"organizations"
			],
			["service-accounts"],
			["data-retrievals"],
			["data-deletions"],
			["nessie"]
		],
		hint: "A service account from Organization Settings > Service Accounts; the Gateway sends its username and secret as HTTP Basic. Most calls also need the project_id parameter, and an EU or India project uses its own hosts.",
		secrets: [{
			name: "MIXPANEL_SERVICE_ACCOUNT_USERNAME",
			hint: "The service account's username, shown when it is created in Organization Settings > Service Accounts."
		}, {
			name: "MIXPANEL_SERVICE_ACCOUNT_SECRET",
			hint: "The service account's secret, shown once when it is created; give the account the narrowest role and only the projects the app needs."
		}],
		smoke: {
			method: "GET",
			host: "mixpanel.com",
			path: "/api/app/me",
			expect: [200],
			free: true,
			note: "Lists the organizations and projects the service account reaches. Account-wide, so run it from the person's terminal."
		},
		rate: { note: "Per project: Query API 60 queries an hour, 5 at once; Raw Data Export 60 an hour, 3 a second, 100 at once; ingestion about 2 GB a minute." },
		example: "pull last week's numbers from my saved Insights report",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["analytics", "product"]
	},
	segment: {
		mode: "api_key",
		label: "Segment",
		description: "Sends identify, track, page, group and alias events to a Segment source.",
		auth: {
			kind: "basic",
			secret: "SEGMENT_WRITE_KEY",
			as: "username"
		},
		docs: "https://www.twilio.com/docs/segment/connections/find-writekey",
		api: "https://www.twilio.com/docs/segment/connections/sources/catalog/libraries/server/http-api",
		hosts: ["api.segment.io", "events.eu1.segmentapis.com"],
		data: "account",
		access: ["write"],
		readMethods: [],
		writeMethods: ["POST"],
		accountWidePaths: [],
		hint: "The write key of an HTTP API source, from the source's Settings > API Keys; the Gateway sends it as the Basic username with an empty password. It only sends events; an EU workspace uses events.eu1.segmentapis.com.",
		secrets: [{
			name: "SEGMENT_WRITE_KEY",
			hint: "The write key of an HTTP API source, from the source's Settings > API Keys."
		}],
		rate: {
			perSecond: 1e3,
			note: "Recommended ceiling per workspace; 32 KB per call, 500 KB and 2,500 events per batch."
		},
		example: "record a Signed Up event for a new user",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"analytics",
			"events",
			"cdp"
		]
	},
	supabase: {
		mode: "api_key",
		label: "Supabase",
		description: "A Supabase project's Postgres REST API and Storage, with its secret key.",
		auth: {
			kind: "header",
			secret: "SUPABASE_SECRET_KEY",
			header: "apikey"
		},
		docs: "https://supabase.com/dashboard/project/_/settings/api-keys",
		api: "https://supabase.com/docs/guides/api",
		hosts: [],
		hostSetting: "SUPABASE_HOST",
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [[
			"auth",
			"v1",
			"admin"
		], ["pg"]],
		hint: "A secret key (sb_secret_...) from Settings > API Keys and the project's host; the Gateway sends the key in the apikey header. The key bypasses Row Level Security, and RPC calls are POSTs, so they need write.",
		secrets: [{
			name: "SUPABASE_SECRET_KEY",
			hint: "A secret key (sb_secret_...) from Settings > API Keys, made for this Gateway alone; it bypasses Row Level Security."
		}, {
			name: "SUPABASE_HOST",
			hint: "The project's host, <project-ref>.supabase.co, from the project URL."
		}],
		smoke: {
			method: "GET",
			path: "/rest/v1/",
			expect: [200],
			free: true,
			note: "The REST API's OpenAPI root, which only a secret key may read; sent to the host in SUPABASE_HOST."
		},
		example: "list the ten newest rows in my orders table",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"database",
			"postgres",
			"storage"
		]
	},
	turso: {
		mode: "api_key",
		label: "Turso",
		description: "Turso's Platform API: databases, groups, locations and usage for one organization.",
		auth: {
			kind: "bearer",
			secret: "TURSO_API_TOKEN"
		},
		docs: "https://docs.turso.tech/api-reference/authentication",
		api: "https://docs.turso.tech/api-reference/introduction",
		hosts: ["api.turso.tech"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["auth"],
			["api-tokens"],
			["members"],
			["invites"],
			["invoices"],
			["subscription"],
			["plans"],
			["audit-logs"],
			["v1", "user"]
		],
		hint: "An organization-scoped Platform API token (turso auth api-tokens mint <name> --org <org>); the Gateway sends it as a bearer token to api.turso.tech. It manages databases and cannot query them: that is the turso-db entry.",
		secrets: [{
			name: "TURSO_API_TOKEN",
			hint: "An organization-scoped or group-scoped Platform API token from turso auth api-tokens mint <name> --org <org>; never an unrestricted one."
		}],
		smoke: {
			method: "GET",
			path: "/v1/auth/validate",
			expect: [200],
			free: true,
			note: "Account-wide, so run it from the person's terminal."
		},
		example: "list the databases in my Turso organization",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["database", "sqlite"]
	},
	"turso-db": {
		mode: "api_key",
		label: "Turso database",
		description: "SQL over HTTP to one Turso database: queries, dumps and migration status.",
		auth: {
			kind: "bearer",
			secret: "TURSO_DB_AUTH_TOKEN"
		},
		docs: "https://docs.turso.tech/sdk/authorization/tokens",
		api: "https://docs.turso.tech/sdk/http/reference",
		hosts: [],
		hostSetting: "TURSO_DB_HOST",
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: ["POST"],
		accountWidePaths: [],
		hint: "A database token (turso db tokens create <db>) and the database's HTTP host; the Gateway sends the token as a bearer token. Every query is a POST to /v2/pipeline, so an app that queries asks for write; a --read-only token keeps it to reads.",
		secrets: [{
			name: "TURSO_DB_AUTH_TOKEN",
			hint: "A database token from turso db tokens create <db>, with --read-only or fine-grained permissions when the app only reads."
		}, {
			name: "TURSO_DB_HOST",
			hint: "The database's HTTP host, <db>-<org>.turso.io, from turso db show <db> --http-url."
		}],
		example: "count the rows in my users table",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"database",
			"sqlite",
			"sql"
		]
	},
	neon: {
		mode: "api_key",
		label: "Neon",
		description: "Neon's management API: Postgres projects, branches, databases, roles and endpoints.",
		auth: {
			kind: "bearer",
			secret: "NEON_API_KEY"
		},
		docs: "https://neon.com/docs/manage/api-keys",
		api: "https://neon.com/docs/reference/api",
		hosts: ["console.neon.tech"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			[
				"api",
				"v2",
				"auth"
			],
			[
				"api",
				"v2",
				"organizations"
			],
			["users", "me"],
			["api_keys"],
			["members"],
			["invitations"],
			["permissions"],
			["transfer_requests"],
			["billing"],
			["consumption_history"],
			["connection_uri"],
			["reveal_password"],
			["reset_password"],
			["credentials"],
			["realtime", "secret"],
			["rotate_secret"],
			["auth", "keys"],
			["auth", "webhooks"],
			["oauth_providers"],
			["email_server"],
			["email_provider"],
			["auth", "plugins"]
		],
		hint: "A project-scoped or organization API key from Settings > API keys; the Gateway sends it as a bearer token to console.neon.tech. It manages projects and branches; the database itself takes Postgres credentials, not this key.",
		secrets: [{
			name: "NEON_API_KEY",
			hint: "A project-scoped or organization API key from Settings > API keys; a project-scoped key reaches one project only."
		}],
		smoke: {
			method: "GET",
			path: "/api/v2/auth",
			expect: [200],
			free: true,
			note: "Says which credential and identity the key is. Account-wide, so run it from the person's terminal."
		},
		rate: {
			perMinute: 700,
			note: "About 11 a second, with bursts of 40 a second per route."
		},
		example: "list my Neon projects and their branches",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["database", "postgres"]
	},
	pinecone: {
		mode: "api_key",
		label: "Pinecone",
		description: "Vector database: indexes, namespaces, vectors and documents, plus hosted embedding and rerank.",
		auth: {
			kind: "header",
			secret: "PINECONE_API_KEY",
			header: "Api-Key"
		},
		docs: "https://app.pinecone.io/organizations/-/projects/-/keys",
		api: "https://docs.pinecone.io/reference/api/introduction",
		hosts: ["api.pinecone.io"],
		hostSetting: "PINECONE_HOST",
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [["admin"], ["api-keys"]],
		hint: "An API key from the project's API keys page and the host of the index the app uses; the Gateway sends the key in the Api-Key header to api.pinecone.io and that host. Query, search, embed and rerank are POSTs, so an app that uses them asks for write.",
		secrets: [{
			name: "PINECONE_API_KEY",
			hint: "An API key from the project's API keys page in the Pinecone console."
		}, {
			name: "PINECONE_HOST",
			hint: "The host of the index the app uses, <index>-<id>.svc.<env>.pinecone.io, from describe_index or the console."
		}],
		smoke: {
			method: "GET",
			host: "api.pinecone.io",
			path: "/indexes",
			expect: [200],
			free: true,
			note: "Lists the project's indexes; the app sends X-Pinecone-Api-Version itself."
		},
		example: "list my Pinecone indexes and their dimensions",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"vector",
			"database",
			"search"
		]
	},
	mapbox: {
		mode: "api_key",
		label: "Mapbox",
		description: "Maps and location: geocoding, directions, styles, tilesets and datasets.",
		auth: {
			kind: "query",
			secret: "MAPBOX_ACCESS_TOKEN",
			param: "access_token"
		},
		docs: "https://console.mapbox.com/account/access-tokens/",
		api: "https://docs.mapbox.com/api/overview/",
		hosts: ["api.mapbox.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [["tokens"]],
		hint: "An access token from Access tokens in the Mapbox console, with only the scopes the app needs; the Gateway adds it to every call as the access_token parameter.",
		secrets: [{
			name: "MAPBOX_ACCESS_TOKEN",
			hint: "An access token with only the scopes the app needs, from Access tokens in the Mapbox console."
		}],
		rate: { note: "Per token and per API: Geocoding 1,000 a minute, Directions 300, Static Images 1,250; the Tokens API 100 a minute per account." },
		example: "turn a street address into map coordinates",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"maps",
			"geocoding",
			"location"
		]
	},
	openweather: {
		mode: "api_key",
		label: "OpenWeather",
		description: "Weather data: current conditions, forecasts, One Call, history and weather map tiles.",
		auth: {
			kind: "query",
			secret: "OPENWEATHER_API_KEY",
			param: "appid"
		},
		docs: "https://home.openweathermap.org/api_keys",
		api: "https://openweathermap.org/api",
		hosts: [
			"api.openweathermap.org",
			"pro.openweathermap.org",
			"history.openweathermap.org",
			"tile.openweathermap.org",
			"maps.openweathermap.org"
		],
		data: "per-call",
		access: ["read"],
		readMethods: ["GET", "HEAD"],
		accountWidePaths: [[
			"data",
			"3",
			"stations"
		], [
			"data",
			"3",
			"measurements"
		]],
		hint: "An API key from the API keys tab of your OpenWeather account; the Gateway adds it to every call as the appid parameter. Paid products (hourly forecast, history, Weather Maps 2.0) need a plan that includes them.",
		secrets: [{
			name: "OPENWEATHER_API_KEY",
			hint: "An API key from the API keys tab of the OpenWeather account; a new key can take up to two hours to activate."
		}],
		smoke: {
			method: "GET",
			host: "api.openweathermap.org",
			path: "/data/2.5/weather?lat=51.51&lon=-0.13",
			expect: [200],
			free: true,
			note: "Counts one call against the plan's quota; free within it. A bad or not yet active key answers 401."
		},
		cost: {
			unit: "call",
			note: "One Call API 3.0 includes 1,000 calls a day free, then is paid per call."
		},
		rate: {
			perMinute: 60,
			note: "The Free plan answers 429 past 60 calls a minute."
		},
		example: "get the current weather in Lisbon",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["weather", "forecast"]
	},
	daytona: {
		mode: "api_key",
		label: "Daytona",
		description: "Sandboxes for running code: create, start, stop, archive and delete sandboxes, and manage their snapshots and volumes.",
		auth: {
			kind: "bearer",
			secret: "DAYTONA_API_KEY"
		},
		docs: "https://www.daytona.io/docs/en/api-keys/",
		api: "https://www.daytona.io/docs/en/tools/api/",
		hosts: ["app.daytona.io"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"PATCH",
			"DELETE"
		],
		accountWidePaths: [
			["organizations"],
			["organization"],
			["billing"],
			["api-keys"],
			["users"],
			["audit"],
			["webhooks"],
			["secret"],
			["docker-registry"],
			["object-storage"],
			["regions"],
			["runners"],
			["for-runner"],
			["jobs"],
			["warm-pools"],
			["preview"],
			["ssh-access", "validate"]
		],
		hint: "An API key from the Daytona dashboard's Keys page, with only the permissions the apps need; the Gateway sends it as a bearer token to app.daytona.io. Any key of an organization reaches every running sandbox in it, so give the Gateway a Daytona organization of its own.",
		secrets: [{
			name: "DAYTONA_API_KEY",
			hint: "An API key from the Daytona dashboard's Keys page: write:sandboxes and delete:sandboxes (and the snapshot or volume ones) only if an app needs them, and never manage:api_keys, manage:secrets, manage:billing or the region and runner permissions."
		}],
		smoke: {
			method: "GET",
			path: "/api/sandbox",
			expect: [200],
			free: true,
			note: "Lists the organization's sandboxes; any key may read them."
		},
		example: "start a sandbox from my snapshot and stop it when the run is done",
		verified: {
			on: "2026-11-01",
			how: "docs"
		},
		tags: [
			"sandbox",
			"compute",
			"hosting"
		]
	}
};
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/catalog/inference.js
var INFERENCE = {
	anthropic: {
		mode: "ai",
		label: "Anthropic",
		description: "Claude models through the Messages API.",
		auth: {
			kind: "bearer",
			secret: "ANTHROPIC_API_KEY"
		},
		docs: "https://platform.claude.com/settings/keys",
		api: "https://platform.claude.com/docs/en/api/overview",
		origin: "https://api.anthropic.com",
		inferenceRoutes: [
			"/v1/messages",
			"/v1/messages/count_tokens",
			"/v1/chat/completions"
		],
		unstoredRoutes: ["/v1/chat/completions"],
		shape: "anthropic",
		chat: {
			path: "/v1/chat/completions",
			seedModel: "claude-haiku-5-5"
		},
		aig: { slug: "anthropic" },
		hint: "An API key from the Claude Console's API keys page; the Gateway sends it as a bearer token. Apps send the anthropic-version header themselves.",
		secrets: [{
			name: "ANTHROPIC_API_KEY",
			hint: "A key scoped to one workspace; the Gateway strips any anthropic-workspace-id header an app sends, so the key alone decides the workspace."
		}],
		smoke: {
			method: "GET",
			path: "/v1/models",
			expect: [200],
			free: true,
			note: "Send an anthropic-version header, as every call does."
		},
		rate: { note: "Requests and tokens per minute by usage tier, on the Console's Rate limits page; token counting is free, with its own per-minute limit." },
		example: "summarize this support thread in three bullet points",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["ai", "llm"]
	},
	gemini: {
		mode: "ai",
		label: "Google Gemini",
		description: "Google's Gemini models through their OpenAI-compatible endpoint: chat, embeddings, images.",
		auth: {
			kind: "bearer",
			secret: "GEMINI_API_KEY"
		},
		docs: "https://aistudio.google.com/apikey",
		api: "https://ai.google.dev/gemini-api/docs/openai",
		origin: "https://generativelanguage.googleapis.com",
		inferenceRoutes: [
			"/v1beta/openai/chat/completions",
			"/v1beta/openai/embeddings",
			"/v1beta/openai/images/generations"
		],
		chat: {
			path: "/v1beta/openai/chat/completions",
			seedModel: "gemini-3.1-flash-lite"
		},
		embeddings: {
			path: "/v1beta/openai/embeddings",
			seedModel: "gemini-embedding-001"
		},
		hint: "An API key from Google AI Studio; the Gateway sends it as a bearer token. Apps call Gemini's OpenAI-shaped paths under /v1beta/openai.",
		secrets: [{
			name: "GEMINI_API_KEY",
			hint: "A Google AI Studio key restricted to the Gemini API only."
		}],
		smoke: {
			method: "GET",
			path: "/v1beta/openai/models",
			expect: [200],
			free: true
		},
		rate: { note: "Per project, not per key: requests and tokens per minute and requests per day, by tier (Free, then Tiers 1 to 3)." },
		example: "describe what is in this product photo",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"ai",
			"llm",
			"embeddings",
			"images"
		]
	},
	mistral: {
		mode: "ai",
		label: "Mistral AI",
		description: "Mistral's models: chat, code completion, embeddings, moderation, OCR, speech.",
		auth: {
			kind: "bearer",
			secret: "MISTRAL_API_KEY"
		},
		docs: "https://console.mistral.ai",
		api: "https://docs.mistral.ai/api/",
		origin: "https://api.mistral.ai",
		inferenceRoutes: [
			"/v1/chat/completions",
			"/v1/fim/completions",
			"/v1/embeddings",
			"/v1/moderations",
			"/v1/chat/moderations",
			"/v1/classifications",
			"/v1/chat/classifications",
			"/v1/ocr",
			"/v1/audio/transcriptions",
			"/v1/audio/speech"
		],
		chat: {
			path: "/v1/chat/completions",
			seedModel: "mistral-small-latest"
		},
		embeddings: {
			path: "/v1/embeddings",
			seedModel: "mistral-embed"
		},
		aig: { slug: "mistral" },
		hint: "An API key from API Keys in the Mistral Studio console; the Gateway sends it as a bearer token. Free mode needs no card; usage and rate limits apply.",
		secrets: [{
			name: "MISTRAL_API_KEY",
			hint: "A key from API Keys in the Studio console, with an expiry date."
		}],
		smoke: {
			method: "GET",
			path: "/v1/models",
			expect: [200],
			free: true
		},
		example: "extract the text from this scanned invoice",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"ai",
			"llm",
			"ocr",
			"embeddings"
		]
	},
	groq: {
		mode: "ai",
		label: "Groq",
		description: "Open models on Groq through OpenAI's API shape: chat, responses, transcription, speech.",
		auth: {
			kind: "bearer",
			secret: "GROQ_API_KEY"
		},
		docs: "https://console.groq.com/keys",
		api: "https://console.groq.com/docs/api-reference",
		origin: "https://api.groq.com",
		inferenceRoutes: [
			"/openai/v1/chat/completions",
			"/openai/v1/responses",
			"/openai/v1/audio/transcriptions",
			"/openai/v1/audio/translations",
			"/openai/v1/audio/speech"
		],
		chat: {
			path: "/openai/v1/chat/completions",
			seedModel: "openai/gpt-oss-20b"
		},
		aig: {
			slug: "groq",
			trim: "/openai/v1"
		},
		hint: "An API key from the Groq console; the Gateway sends it as a bearer token. Apps call the OpenAI-shaped paths under /openai/v1.",
		secrets: [{
			name: "GROQ_API_KEY",
			hint: "A key from the API Keys page of the Groq console."
		}],
		smoke: {
			method: "GET",
			path: "/openai/v1/models",
			expect: [200],
			free: true
		},
		rate: { note: "Requests and tokens per minute and per day, per model and plan, for the whole organization; the console Limits page shows them." },
		example: "transcribe this voice memo",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"ai",
			"llm",
			"speech"
		]
	},
	cohere: {
		mode: "ai",
		label: "Cohere",
		description: "Cohere's models: chat, embeddings, reranking, classification, transcription, document parsing.",
		auth: {
			kind: "bearer",
			secret: "COHERE_API_KEY"
		},
		docs: "https://dashboard.cohere.com/api-keys",
		api: "https://docs.cohere.com/reference/about",
		origin: "https://api.cohere.com",
		inferenceRoutes: [
			"/v2/chat",
			"/v2/embed",
			"/v2/rerank",
			"/v1/classify",
			"/v2/audio/transcriptions",
			"/v2/parse",
			"/v1/tokenize",
			"/v1/detokenize"
		],
		shape: "other",
		hint: "An API key from the Cohere dashboard; the Gateway sends it as a bearer token. Trial keys are free and limited; production keys are paid.",
		secrets: [{
			name: "COHERE_API_KEY",
			hint: "A production key; a trial key is limited to 1,000 calls a month."
		}],
		smoke: {
			method: "GET",
			path: "/v1/models",
			expect: [200],
			free: true
		},
		rate: { note: "Production: 500 calls a minute for Command A chat and most endpoints, rerank 1,000. Trial: 20 chat calls a minute, 1,000 calls a month." },
		example: "rerank these search results for the query refund policy",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"ai",
			"llm",
			"embeddings",
			"rerank"
		]
	},
	voyage: {
		mode: "api_key",
		label: "Voyage AI",
		description: "Embeddings and rerankers for search and retrieval: text, code, multimodal, contextualized chunks.",
		auth: {
			kind: "bearer",
			secret: "VOYAGE_API_KEY"
		},
		docs: "https://dashboard.voyageai.com/organization/api-keys",
		api: "https://docs.voyageai.com/reference/embeddings-api",
		hosts: ["api.voyageai.com"],
		data: "per-call",
		access: ["read"],
		readMethods: ["POST"],
		accountWidePaths: [["v1", "files"], ["v1", "batches"]],
		hint: "A secret key from the Voyage dashboard; the Gateway sends it as a bearer token. Apps POST to /v1/embeddings, /v1/multimodalembeddings, /v1/contextualizedembeddings and /v1/rerank.",
		secrets: [{
			name: "VOYAGE_API_KEY",
			hint: "A secret key from API keys in the Voyage dashboard."
		}],
		smoke: {
			method: "GET",
			path: "/v1/batches",
			expect: [200],
			free: true,
			note: "Lists the organization's batches, so the Gateway refuses it for apps; run it from the person's terminal."
		},
		cost: {
			unit: "token",
			note: "voyage-4 $0.06 per million tokens; the first 200 million tokens of the voyage-4 family are free per account."
		},
		rate: {
			perMinute: 2e3,
			note: "2,000 requests a minute at tier 1, doubled at tier 2, tripled at tier 3; tokens per minute vary by model."
		},
		example: "embed these product descriptions for semantic search",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"embeddings",
			"rerank",
			"search"
		]
	},
	perplexity: {
		mode: "api_key",
		label: "Perplexity",
		description: "Web-grounded answers from the Agent API, raw web search results, and embeddings.",
		auth: {
			kind: "bearer",
			secret: "PERPLEXITY_API_KEY"
		},
		docs: "https://console.perplexity.ai/project/keys",
		api: "https://docs.perplexity.ai/api-reference/agent-post",
		hosts: ["api.perplexity.ai"],
		data: "per-call",
		access: ["read"],
		readMethods: ["GET", "POST"],
		accountWidePaths: [
			["v1", "batches"],
			["v1", "files"],
			["v1", "skills"],
			["v1", "analytics"],
			["v2", "analytics"],
			["generate_auth_token"],
			["revoke_auth_token"]
		],
		hint: "An API key from the Perplexity console; the Gateway sends it as a bearer token. Apps POST to /v1/agent for researched answers and /search for result lists, and GET /v1/agent/{id} to poll a background run.",
		secrets: [{
			name: "PERPLEXITY_API_KEY",
			hint: "An API key from the project's API keys page in the Perplexity console."
		}],
		smoke: {
			method: "GET",
			path: "/orchestrator/v1/models",
			expect: [200],
			free: true
		},
		cost: {
			unit: "token",
			note: "Agent API per token plus tool fees (web_search $0.0025 a call); Search API $5 per 1,000 requests."
		},
		example: "research the latest pricing changes from our three main competitors",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"search",
			"ai",
			"research"
		]
	},
	jina: {
		mode: "api_key",
		label: "Jina AI",
		description: "Reads web pages as Markdown, searches the web, and embeds and reranks text and images.",
		auth: {
			kind: "bearer",
			secret: "JINA_API_KEY"
		},
		docs: "https://jina.ai/api-dashboard/key-manager",
		api: "https://docs.jina.ai/",
		hosts: [
			"api.jina.ai",
			"r.jina.ai",
			"s.jina.ai"
		],
		data: "per-call",
		access: ["read"],
		readMethods: ["GET", "POST"],
		accountWidePaths: [["v1", "batches"], ["echo"]],
		hint: "An API key from the Jina API dashboard; the Gateway sends it as a bearer token. Reader is r.jina.ai (POST {\"url\": ...}), Search is s.jina.ai, and embeddings and rerank are on api.jina.ai.",
		secrets: [{
			name: "JINA_API_KEY",
			hint: "A key starting jina_, from Manage API Key in the Jina API dashboard."
		}],
		smoke: {
			method: "GET",
			host: "api.jina.ai",
			path: "/v1/batches",
			expect: [200],
			free: true,
			note: "Lists the account's batch jobs, so the Gateway refuses it for apps; run it from the person's terminal."
		},
		cost: {
			unit: "token",
			note: "Billed in tokens against the account balance; GET /v1/models lists each model's price."
		},
		rate: { note: "Reader 500 requests a minute, Search 100, embeddings and rerank 500; premium keys get ten times more." },
		example: "read this article as Markdown and pull out the key claims",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"scrape",
			"search",
			"embeddings",
			"rerank"
		]
	},
	replicate: {
		mode: "api_key",
		label: "Replicate",
		description: "Runs open-source and official models by API: images, video, audio and language.",
		auth: {
			kind: "bearer",
			secret: "REPLICATE_API_TOKEN"
		},
		docs: "https://replicate.com/account/api-tokens",
		api: "https://replicate.com/docs/reference/http",
		hosts: ["api.replicate.com"],
		data: "per-call",
		access: ["read"],
		readMethods: ["POST"],
		accountWidePaths: [
			["v1", "account"],
			["v1", "deployments"],
			["v1", "files"],
			["v1", "webhooks"],
			["trainings"]
		],
		hint: "An API token from Replicate's API tokens page; the Gateway sends it as a bearer token. Apps POST to /v1/models/{owner}/{name}/predictions or /v1/predictions with Prefer: wait (up to 60 seconds), or pass a webhook URL for longer runs.",
		secrets: [{
			name: "REPLICATE_API_TOKEN",
			hint: "An API token from the API tokens page of the Replicate account."
		}],
		smoke: {
			method: "GET",
			path: "/v1/account",
			expect: [200],
			free: true,
			note: "Account-wide, so the Gateway refuses it for apps; run it from the person's terminal."
		},
		rate: {
			perMinute: 600,
			note: "Creating predictions 600 a minute; every other endpoint 3,000 a minute."
		},
		example: "generate a product photo of a ceramic mug on a wooden table",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"ai",
			"images",
			"video",
			"audio"
		]
	},
	huggingface: {
		mode: "api_key",
		label: "Hugging Face Inference",
		description: "Open models from Hugging Face's inference providers through one router: chat, embeddings, images, speech.",
		auth: {
			kind: "bearer",
			secret: "HUGGINGFACE_API_TOKEN"
		},
		docs: "https://huggingface.co/settings/tokens/new?ownUserPermissions=inference.serverless.write&tokenType=fineGrained",
		api: "https://huggingface.co/docs/inference-providers/index",
		hosts: ["router.huggingface.co"],
		data: "per-call",
		access: ["read"],
		readMethods: ["GET", "POST"],
		accountWidePaths: [],
		hint: "A fine-grained access token from Hugging Face settings with the Inference Providers permission; the Gateway sends it as a bearer token. Apps POST OpenAI-style chat to /v1/chat/completions, or other tasks under /<provider>/, such as /hf-inference/models/<model>.",
		secrets: [{
			name: "HUGGINGFACE_API_TOKEN",
			hint: "A fine-grained token with only the Make calls to Inference Providers permission."
		}],
		cost: {
			unit: "call",
			note: "Pay as you go at each provider's own rate with no markup; PRO accounts get $2 of compute credits a month."
		},
		example: "embed these support articles for semantic search",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"ai",
			"llm",
			"embeddings",
			"images"
		]
	}
};
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/catalog/search.js
var SEARCH = {
	firecrawl: {
		mode: "api_key",
		label: "Firecrawl",
		description: "Scrapes, crawls, maps and searches the web, returning clean markdown or structured data.",
		auth: {
			kind: "bearer",
			secret: "FIRECRAWL_API_KEY"
		},
		docs: "https://www.firecrawl.dev/app/api-keys",
		api: "https://docs.firecrawl.dev/api-reference/introduction",
		hosts: ["api.firecrawl.dev"],
		data: "per-call",
		access: ["read", "write"],
		readMethods: ["GET", "POST"],
		writeMethods: ["DELETE"],
		accountWidePaths: [
			["team"],
			["crawl", "active"],
			["monitor"],
			["agent"],
			["interact"],
			["support", "ask"]
		],
		hint: "An API key from Firecrawl's API keys page; the Gateway sends it as a bearer token. Scrape, crawl, map, search and extract are POSTs and job status is a GET; cancelling a crawl or batch (DELETE) needs write.",
		secrets: [{
			name: "FIRECRAWL_API_KEY",
			hint: "An API key from Firecrawl's API keys page; it starts with fc-."
		}],
		smoke: {
			method: "GET",
			path: "/v2/team/credit-usage",
			expect: [200],
			free: true,
			note: "Remaining credits; account-wide, so the Gateway refuses it for apps: run it from the person's terminal."
		},
		cost: {
			unit: "result",
			note: "Credits: 1 per page scraped or crawled, 1 per map call, 2 per 10 search results; JSON extraction and other options add more."
		},
		rate: { note: "Per team per minute, by plan: /scrape 10 on Free, 100 Hobby, 500 Standard, 5,000 Growth; /crawl 2, 20, 100, 1,000." },
		example: "scrape https://example.com/pricing into markdown",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: [
			"scrape",
			"crawl",
			"search"
		]
	},
	exa: {
		mode: "api_key",
		label: "Exa",
		description: "Web search built for AI: search results, page contents, similar links and cited answers.",
		auth: {
			kind: "header",
			secret: "EXA_API_KEY",
			header: "x-api-key"
		},
		docs: "https://dashboard.exa.ai/api-keys",
		api: "https://exa.ai/docs/reference/search",
		hosts: ["api.exa.ai"],
		data: "per-call",
		access: ["read"],
		readMethods: ["POST"],
		accountWidePaths: [
			["websets"],
			["monitors"],
			["agent"],
			["batches"]
		],
		hint: "An API key from the Exa dashboard (the free tier gives $10 of credit a month); the Gateway sends it in the x-api-key header. Search, contents, find-similar and answer are POSTs.",
		secrets: [{
			name: "EXA_API_KEY",
			hint: "An API key from the API keys page of the Exa dashboard."
		}],
		smoke: {
			method: "GET",
			path: "/websets/v0/teams/me",
			expect: [200],
			free: true,
			note: "Team info under the Websets API (the docs page leaves out the /websets prefix); account-wide, so run it from the person's terminal."
		},
		cost: {
			unit: "call",
			usd: .007,
			note: "Search $7 per 1k (auto and fast; lite $4), contents $1 per 1k pages, answer $5 per 1k; up to 10 results included."
		},
		rate: {
			perSecond: 10,
			note: "Per team: /search and /answer 10 QPS, deep search 5, /contents 100."
		},
		example: "find recent articles about solid-state batteries",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["search"]
	},
	tavily: {
		mode: "api_key",
		label: "Tavily",
		description: "Web search, page extraction, crawling and site maps for AI agents, plus research reports.",
		auth: {
			kind: "bearer",
			secret: "TAVILY_API_KEY"
		},
		docs: "https://app.tavily.com",
		api: "https://docs.tavily.com/documentation/api-reference/endpoint/search",
		hosts: ["api.tavily.com"],
		data: "per-call",
		access: ["read"],
		readMethods: ["GET", "POST"],
		accountWidePaths: [
			["usage"],
			["logs"],
			["org-usage"]
		],
		hint: "An API key from app.tavily.com (1,000 free credits a month); the Gateway sends it as a bearer token. Search, extract, crawl, map and research are POSTs; a research result is a GET.",
		secrets: [{
			name: "TAVILY_API_KEY",
			hint: "An API key from the Tavily dashboard; it starts with tvly-."
		}],
		smoke: {
			method: "GET",
			path: "/usage",
			expect: [200],
			free: true,
			note: "Key and account usage, not an endpoint that costs credits; account-wide, so run it from the person's terminal (10 calls per 10 minutes)."
		},
		cost: {
			unit: "call",
			usd: .008,
			note: "Pay as you go $0.008 per credit: basic search 1 credit, advanced 2; extract 1 credit per 5 URLs; map 1 per 10 pages."
		},
		rate: {
			perMinute: 100,
			note: "Development keys 100 per minute, production keys 1,000; crawl 100 and research 20 per minute for both."
		},
		example: "search the web for this week's news on EU AI rules",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["search", "scrape"]
	},
	serper: {
		mode: "api_key",
		label: "Serper",
		description: "Google search results as JSON: web, news, images, places, shopping, scholar and patents.",
		auth: {
			kind: "header",
			secret: "SERPER_API_KEY",
			header: "X-API-KEY"
		},
		docs: "https://serper.dev/api-keys",
		api: "https://serper.dev/playground",
		hosts: ["google.serper.dev", "scrape.serper.dev"],
		data: "per-call",
		access: ["read"],
		readMethods: ["POST"],
		accountWidePaths: [],
		hint: "An API key from serper.dev (2,500 free queries to start); the Gateway sends it in the X-API-KEY header. Every search is a POST to google.serper.dev/<type> (search, news, images, places, \u2026) with a JSON body such as {\"q\": \"\u2026\"}.",
		secrets: [{
			name: "SERPER_API_KEY",
			hint: "The API key on serper.dev's API keys page."
		}],
		cost: {
			unit: "call",
			usd: .001,
			note: "Prepaid credits, one per successful query: $1.00 per 1k on the 50k pack, down to $0.30 per 1k on the largest."
		},
		rate: {
			perSecond: 50,
			note: "Starter credits 50 queries per second; Standard 100, Scale 200, Ultimate 300."
		},
		example: "get the top Google results for best project management software",
		verified: false,
		tags: ["search", "serp"]
	},
	"brave-search": {
		mode: "api_key",
		label: "Brave Search",
		description: "Brave's independent web index: web, news, images, videos, places, LLM context and answers.",
		auth: {
			kind: "header",
			secret: "BRAVE_SEARCH_API_KEY",
			header: "X-Subscription-Token"
		},
		docs: "https://api-dashboard.search.brave.com/app/keys",
		api: "https://api-dashboard.search.brave.com/documentation",
		hosts: ["api.search.brave.com"],
		data: "per-call",
		access: ["read"],
		readMethods: ["GET", "POST"],
		accountWidePaths: [],
		hint: "Activate a plan (it includes $5 of free credit a month), then create a key under API Keys; the Gateway sends it in the X-Subscription-Token header. Searches are GETs (POST works too); answers are a POST to /res/v1/chat/completions.",
		secrets: [{
			name: "BRAVE_SEARCH_API_KEY",
			hint: "A key from the API Keys section of the Brave Search API dashboard, made after activating a plan."
		}],
		cost: {
			unit: "call",
			usd: .005,
			note: "Search $5 per 1k requests; Answers $4 per 1k plus $5 per million tokens; $5 free credit a month; only successful calls count."
		},
		rate: {
			perSecond: 50,
			note: "Search plan 50 queries per second; Answers 2 per second."
		},
		example: "search the web for the latest Cloudflare Workers release notes",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["search"]
	},
	apify: {
		mode: "api_key",
		label: "Apify",
		description: "Runs Apify Actors (ready-made scrapers and automations) and reads their datasets and stores.",
		auth: {
			kind: "bearer",
			secret: "APIFY_API_TOKEN"
		},
		docs: "https://console.apify.com/settings/integrations",
		api: "https://docs.apify.com/api/v2",
		hosts: ["api.apify.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "HEAD"],
		writeMethods: [
			"POST",
			"PUT",
			"DELETE"
		],
		accountWidePaths: [
			["users"],
			["webhooks"],
			["webhook-dispatches"],
			["env-vars"]
		],
		hint: "The API token from Apify Console, Settings > API & Integrations; the Gateway sends it as a bearer token. Reading Actors, runs and datasets needs read; starting a run is a POST, so it needs write.",
		secrets: [{
			name: "APIFY_API_TOKEN",
			hint: "The API token under Settings > API & Integrations in Apify Console."
		}],
		smoke: {
			method: "GET",
			path: "/v2/users/me",
			expect: [200],
			free: true,
			note: "The docs' verify call; account-wide, so the Gateway refuses it for apps: run it from the person's terminal."
		},
		rate: {
			perSecond: 60,
			note: "60 requests per second per resource (one Actor, run, dataset or store); 250,000 requests per minute per user overall."
		},
		example: "run the Google Maps scraper Actor for coffee shops in Austin and list the results",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["scrape", "automation"]
	},
	deepgram: {
		mode: "api_key",
		label: "Deepgram",
		description: "Speech to text, text to speech and text analysis.",
		auth: {
			kind: "bearer",
			secret: "DEEPGRAM_API_KEY",
			scheme: "Token"
		},
		docs: "https://console.deepgram.com/",
		api: "https://developers.deepgram.com/reference/deepgram-api-overview",
		hosts: [
			"api.deepgram.com",
			"api.eu.deepgram.com",
			"api.au.deepgram.com",
			"api.in.deepgram.com"
		],
		data: "per-call",
		access: ["read"],
		readMethods: ["GET", "POST"],
		accountWidePaths: [["projects"], ["auth", "grant"]],
		hint: "An API key from the Deepgram Console; the Gateway sends it as Authorization: Token <key>, and the EU, Australia and India hosts take the same key. Transcription (/v1/listen), speech (/v1/speak) and text analysis (/v1/read) are POSTs.",
		secrets: [{
			name: "DEEPGRAM_API_KEY",
			hint: "A project API key created in the Deepgram Console."
		}],
		smoke: {
			method: "GET",
			path: "/v1/models",
			expect: [200],
			free: true,
			note: "Lists the public models; it needs the key and processes no audio."
		},
		cost: {
			unit: "call",
			note: "Nova-3 pre-recorded $0.0043 per audio minute (pay as you go); Aura-2 speech $0.030 per 1k characters; $200 free credit."
		},
		rate: { note: "Concurrency per project on pay as you go: 50 pre-recorded transcriptions, 15 text-to-speech requests." },
		example: "transcribe this podcast episode and label the speakers",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["speech", "transcription"]
	},
	elevenlabs: {
		mode: "api_key",
		label: "ElevenLabs",
		description: "Text to speech, speech to text, sound effects, music and voice changing.",
		auth: {
			kind: "header",
			secret: "ELEVENLABS_API_KEY",
			header: "xi-api-key"
		},
		docs: "https://elevenlabs.io/app/settings/api-keys",
		api: "https://elevenlabs.io/docs/api-reference/introduction",
		hosts: ["api.elevenlabs.io"],
		data: "per-call",
		access: ["read"],
		readMethods: ["GET", "POST"],
		accountWidePaths: [
			["v1", "user"],
			["v1", "usage"],
			["v1", "workspace"],
			["v1", "workspaces"],
			["v1", "service-accounts"],
			["v1", "history"],
			["v1", "single-use-token"],
			["v1", "convai"],
			["v1", "dubbing"],
			["v1", "studio"],
			["v1", "pronunciation-dictionaries"],
			[
				"v1",
				"voices",
				"add"
			],
			[
				"v1",
				"voices",
				"pvc"
			],
			[
				"v1",
				"voices",
				"collections"
			],
			["edit"],
			["replicate-to-isolated-environment"],
			["v1", "text-to-voice"],
			["v1", "audio-native"],
			["v1", "productions"],
			["v1", "speech-engine"],
			[
				"v1",
				"music",
				"finetunes"
			],
			["v1", "flows"],
			["v1", "assets"],
			[
				"v1",
				"audio-isolation",
				"history"
			]
		],
		hint: "An API key from ElevenLabs' API keys page; the Gateway sends it in the xi-api-key header. Speech, transcription and sound generation are POSTs; listing voices and models are GETs.",
		secrets: [{
			name: "ELEVENLABS_API_KEY",
			hint: "An API key from ElevenLabs' API keys page; it can be scoped to the endpoints the app uses and given a credit cap."
		}],
		smoke: {
			method: "GET",
			path: "/v1/models",
			expect: [200],
			free: true,
			note: "The first request in ElevenLabs' authentication docs; it generates nothing."
		},
		example: "read this paragraph aloud in a calm narrator voice",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["speech", "audio"]
	},
	assemblyai: {
		mode: "api_key",
		label: "AssemblyAI",
		description: "Transcribes recorded audio and video, with speaker labels, redaction and subtitles.",
		auth: {
			kind: "header",
			secret: "ASSEMBLYAI_API_KEY",
			header: "Authorization"
		},
		docs: "https://www.assemblyai.com/dashboard/home",
		api: "https://www.assemblyai.com/docs",
		hosts: ["api.assemblyai.com", "api.eu.assemblyai.com"],
		data: "account",
		access: ["read", "write"],
		readMethods: ["GET", "POST"],
		writeMethods: ["DELETE"],
		accountWidePaths: [],
		hint: "The API key from your AssemblyAI dashboard; the Gateway sends it as the whole Authorization header, with no Bearer word. Audio is submitted with a POST to /v2/transcript and the app polls GET /v2/transcript/<id>; deleting a transcript needs write.",
		secrets: [{
			name: "ASSEMBLYAI_API_KEY",
			hint: "The API key on your AssemblyAI dashboard."
		}],
		smoke: {
			method: "GET",
			path: "/v2/transcript?limit=1",
			expect: [200],
			free: true,
			note: "Lists the account's latest transcript; it transcribes nothing."
		},
		cost: {
			unit: "call",
			note: "Per hour of audio submitted: Universal-3.5 Pro $0.21, Universal-2 $0.15; the free tier covers up to 185 hours of pre-recorded audio."
		},
		rate: {
			perMinute: 4e3,
			note: "20,000 requests per 5 minutes per account; 5 transcriptions in parallel on free accounts, 200 or more on paid."
		},
		example: "transcribe this sales call recording with speaker labels",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["speech", "transcription"]
	},
	newsapi: {
		mode: "api_key",
		label: "NewsAPI",
		description: "Searches news articles and live headlines from over 150,000 sources.",
		auth: {
			kind: "header",
			secret: "NEWSAPI_API_KEY",
			header: "X-Api-Key"
		},
		docs: "https://newsapi.org/register",
		api: "https://newsapi.org/docs",
		hosts: ["newsapi.org"],
		data: "per-call",
		access: ["read"],
		readMethods: ["GET"],
		accountWidePaths: [],
		hint: "An API key from newsapi.org/register; the Gateway sends it in the X-Api-Key header. The free Developer plan allows 100 requests a day, delays articles by 24 hours and is for development only; production needs a paid plan.",
		secrets: [{
			name: "NEWSAPI_API_KEY",
			hint: "The API key NewsAPI shows after you register."
		}],
		cost: {
			unit: "call",
			usd: .0018,
			note: "Developer plan free (100 requests a day, development only); Business $449 a month for 250,000 requests, then $0.0018 each."
		},
		rate: {
			perDay: 100,
			note: "Developer plan; Business includes 250,000 requests a month, Advanced 2,000,000."
		},
		example: "find today's top business headlines in the US",
		verified: {
			on: "2026-10-25",
			how: "docs"
		},
		tags: ["news"]
	}
};
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/catalog/index.js
/**
* The first fifty catalog providers beyond the ones today's apps use
* (docs/design/2026-10-provider-registry.md, section 9), one file per
* batch, merged into `CAPABILITIES` after the hand-written entries. A
* provider here is a catalog entry like DataForSEO: every gateway has it,
* its settings are settable, a row can't take its id.
*/
var CATALOG_ENTRIES = {
	...COMMERCE,
	...COMMS,
	...INFRA,
	...INFERENCE,
	...SEARCH
};
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/oauthBuiltIns.js
/**
* The OAuth providers every Gateway has built in, as `oauth2-user` specs:
* the same JSON shape as the presets (./oauthPresets.ts) and a registered
* row (`everyapp provider add`). What differs between Google, Microsoft
* and Slack is here as data: the endpoints, the API hosts, how scopes are
* separated and prefixed, the extra authorize parameters, how the account
* is named, and the scopes a token may carry beyond what the app asked.
* No code anywhere reads a provider id to decide anything.
*
* Pure data with no imports, so the catalog (./capabilities.ts) can build
* its entries from it without an import cycle. Each spec parses with
* `parseProviderSpec` and round-trips through `oauthSpecOf`
* (oauthBuiltIns.test.ts).
*/
var BUILT_IN_OAUTH_SPECS = {
	"google-workspace": {
		id: "google-workspace",
		name: "Google",
		description: "Gmail, Calendar, Drive, Search Console, Analytics and the other Google APIs, as the person who connects.",
		docs: "https://console.cloud.google.com/apis/credentials",
		api: "https://developers.google.com/identity/protocols/oauth2/scopes",
		hosts: [
			"gmail.googleapis.com",
			"www.googleapis.com",
			"searchconsole.googleapis.com",
			"analyticsdata.googleapis.com",
			"analyticsadmin.googleapis.com",
			"openidconnect.googleapis.com"
		],
		auth: {
			kind: "oauth2-user",
			authorizeUrl: "https://accounts.google.com/o/oauth2/v2/auth",
			tokenUrl: "https://oauth2.googleapis.com/token",
			clientId: "GOOGLE_WORKSPACE_CLIENT_ID",
			clientSecret: "GOOGLE_WORKSPACE_CLIENT_SECRET",
			inject: "form",
			pkce: true,
			scopeSeparator: "space",
			scopePrefix: "https://www.googleapis.com/auth/",
			authorizeParams: {
				access_type: "offline",
				prompt: "consent"
			},
			identity: {
				url: "https://openidconnect.googleapis.com/v1/userinfo",
				label: "email",
				id: "sub",
				scopes: ["openid", "email"]
			},
			tolerated: [
				"profile",
				"https://www.googleapis.com/auth/userinfo.email",
				"https://www.googleapis.com/auth/userinfo.profile"
			]
		},
		hint: "A Web application OAuth client in Google Cloud, with the Gateway's callback as its redirect URI and the scopes your apps list on its consent screen."
	},
	"microsoft-365": {
		id: "microsoft-365",
		name: "Microsoft 365",
		description: "Outlook mail and calendar, OneDrive and the rest of Microsoft Graph, as the person who connects.",
		docs: "https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade",
		api: "https://learn.microsoft.com/graph/permissions-reference",
		hosts: ["graph.microsoft.com"],
		auth: {
			kind: "oauth2-user",
			authorizeUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
			tokenUrl: "https://login.microsoftonline.com/common/oauth2/v2.0/token",
			clientId: "MICROSOFT_365_CLIENT_ID",
			clientSecret: "MICROSOFT_365_CLIENT_SECRET",
			inject: "form",
			pkce: true,
			scopeSeparator: "space",
			scopePrefix: "https://graph.microsoft.com/",
			identity: {
				url: "https://graph.microsoft.com/v1.0/me",
				label: "userPrincipalName",
				id: "id",
				scopes: ["User.Read", "offline_access"]
			},
			tolerated: [
				"openid",
				"profile",
				"email"
			]
		},
		hint: "An app registration in Entra for accounts in any organization and personal accounts, with the Gateway's callback as a Web redirect URI. If two apps share this client with different scopes, Microsoft may hand back both apps' scopes and the Gateway refuses the token: give each app its own client."
	},
	slack: {
		id: "slack",
		name: "Slack",
		description: "Channels, members and messages, as the Slack app.",
		docs: "https://api.slack.com/apps",
		api: "https://api.slack.com/scopes",
		hosts: ["slack.com"],
		auth: {
			kind: "oauth2-user",
			authorizeUrl: "https://slack.com/oauth/v2/authorize",
			tokenUrl: "https://slack.com/api/oauth.v2.access",
			revokeUrl: "https://slack.com/api/auth.revoke",
			clientId: "SLACK_CLIENT_ID",
			clientSecret: "SLACK_CLIENT_SECRET",
			inject: "form",
			pkce: false,
			scopeSeparator: "comma",
			identity: {
				url: "https://slack.com/api/auth.test",
				label: "team",
				id: "team_id"
			}
		},
		hint: "A Slack app with the Gateway's callback as its redirect URL and the bot scopes your apps list. The Gateway takes its Client ID and Client Secret, not a bot token (xoxb-)."
	}
};
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/oauthSpec.js
var SEPARATORS = ["space", "comma"];
var INJECTIONS = ["form", "basic"];
var HEADER_NAME$1 = /^[A-Za-z0-9-]{1,64}$/;
/** Headers the Gateway sets on the token request itself, or never sends. */
var RESERVED_TOKEN_HEADERS = /* @__PURE__ */ new Set([
	"authorization",
	"content-type",
	"content-length",
	"host",
	"cookie"
]);
/**
* Authorize parameters the Gateway sets itself, and
* `include_granted_scopes`, which would widen a token to every scope the
* person ever granted the client (the mint check would refuse it anyway).
*/
var RESERVED_AUTHORIZE_PARAMS = [
	"client_id",
	"redirect_uri",
	"response_type",
	"scope",
	"state",
	"code_challenge",
	"code_challenge_method",
	"include_granted_scopes"
];
var PARAM_NAME = /^[A-Za-z0-9_.-]{1,64}$/;
/** A dot path into a JSON answer, at most four segments. */
var DOT_PATH = /^[A-Za-z_][A-Za-z0-9_]{0,63}(?:\.[A-Za-z_][A-Za-z0-9_]{0,63}){0,3}$/;
var UNPRINTABLE$1 = /[\p{Cc}\p{Cf}]/u;
var MAX_SCOPES = 40;
var MAX_PARAMS = 10;
/** The fields of `auth` when its kind is `oauth2-user`. */
var OAUTH_AUTH_FIELDS = [
	"kind",
	"authorizeUrl",
	"tokenUrl",
	"revokeUrl",
	"revokeMethod",
	"clientId",
	"clientSecret",
	"inject",
	"pkce",
	"scopeSeparator",
	"scopePrefix",
	"authorizeParams",
	"tokenHeaders",
	"identity",
	"tolerated",
	"resource",
	"issuer"
];
/**
* Fields an `oauth2-user` spec had before scopes moved to each app's
* `everyapp.config.ts`, each with what to write instead: refused with
* that message rather than "unknown field".
*/
var REMOVED_OAUTH_FIELDS = {
	scopeSets: "scope sets are gone: each app lists the provider's own scopes in its everyapp.config.ts. Remove scopeSets.",
	alwaysRequested: "alwaysRequested is gone: put scopes every connect needs (a refresh token's, the identity URL's) in auth.identity.scopes.",
	tolerated: "tolerated moved into auth: auth.tolerated lists the scopes a token may carry beyond what was asked.",
	access: "access is gone for an OAuth provider: the scopes an app lists are the grant, for every method.",
	readMethods: "readMethods is gone for an OAuth provider: the scopes an app lists are the grant, for every method.",
	writeMethods: "writeMethods is gone for an OAuth provider: the scopes an app lists are the grant, for every method."
};
/** `auth` fields renamed, each with its new name. */
var RENAMED_AUTH_FIELDS = { scopeDialect: "renamed auth.scopeSeparator: space or comma (a provider's prefix goes in auth.scopePrefix)" };
function isRecord$4(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function printable(value, path, problems, max) {
	if (value === void 0) return void 0;
	if (typeof value !== "string" || value.length === 0 || value.length > max) {
		problems.push({
			path,
			message: `must be a string of 1 to ${max} characters`
		});
		return;
	}
	if (UNPRINTABLE$1.test(value)) {
		problems.push({
			path,
			message: "holds a control character"
		});
		return;
	}
	return value;
}
/**
* An https URL with a host a row may name (the caller runs the gateway's
* host rules on `host` afterwards). `{client_id}` may stand in a path
* (GitHub's revoke URL names the client there).
*/
function endpoint(value, path, problems, { query }) {
	if (value === void 0) return void 0;
	const url = printable(value, path, problems, 500);
	if (url === void 0) return void 0;
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		problems.push({
			path,
			message: "must be an https URL"
		});
		return;
	}
	if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.port || parsed.hash) {
		problems.push({
			path,
			message: parsed.port ? `must be an https URL on the default port (${parsed.port} is not: the Gateway's OAuth requests go to port 443 only), with no credentials or fragment` : "must be an https URL with no port, credentials or fragment"
		});
		return;
	}
	if (!query && parsed.search) {
		problems.push({
			path,
			message: "may not carry a query string"
		});
		return;
	}
	return {
		url,
		host: parsed.hostname.toLowerCase()
	};
}
/**
* An https URL that names something rather than being fetched (an RFC
* 8707 resource, an RFC 8414 issuer): a port is allowed, credentials and a
* fragment are not, and an issuer takes no query either.
*/
function identifierUrl(value, path, problems, { query }) {
	if (value === void 0) return void 0;
	const url = printable(value, path, problems, 2048);
	if (url === void 0) return void 0;
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		problems.push({
			path,
			message: "must be an https URL"
		});
		return;
	}
	if (parsed.protocol !== "https:" || parsed.username || parsed.password || parsed.hash || url.includes("#")) {
		problems.push({
			path,
			message: "must be an https URL with no credentials or fragment"
		});
		return;
	}
	if (!query && parsed.search) {
		problems.push({
			path,
			message: "may not carry a query string"
		});
		return;
	}
	return url;
}
function settingName$1(value, path, problems) {
	if (typeof value !== "string" || !/^[A-Z][A-Z0-9_]{2,63}$/.test(value)) {
		problems.push({
			path,
			message: "must name a Gateway setting: upper case letters, digits and underscores, a letter first, 3 to 64 characters (GITHUB_CLIENT_ID)"
		});
		return;
	}
	return value;
}
function stringMap(value, path, problems, each) {
	if (value === void 0) return void 0;
	if (!isRecord$4(value)) {
		problems.push({
			path,
			message: "must be an object of strings"
		});
		return;
	}
	const entries = Object.entries(value);
	if (entries.length > MAX_PARAMS) {
		problems.push({
			path,
			message: `at most ${MAX_PARAMS} entries`
		});
		return;
	}
	const out = {};
	for (const [name, raw] of entries) {
		const at = `${path}.${name}`;
		each(name, at);
		const text = printable(raw, at, problems, 200);
		if (text !== void 0) out[name] = text;
	}
	return out;
}
/** A list of provider scope strings: each one scope, with no space or comma, each once. */
function scopeList(value, path, problems) {
	if (value === void 0) return void 0;
	if (!Array.isArray(value) || value.length > MAX_SCOPES) {
		problems.push({
			path,
			message: `must be a list of at most ${MAX_SCOPES} scopes`
		});
		return;
	}
	const out = [];
	value.forEach((item, index) => {
		const scope = printable(item, `${path}.${index}`, problems, 200);
		if (scope === void 0) return;
		if (/\s/.test(scope) || scope.includes(",")) {
			problems.push({
				path: `${path}.${index}`,
				message: "one scope, with no space or comma"
			});
			return;
		}
		out.push(scope);
	});
	if (new Set(out).size !== out.length) problems.push({
		path,
		message: "lists a scope twice"
	});
	return out;
}
function identity(value, hosts, problems) {
	if (value === void 0) return void 0;
	if (!isRecord$4(value)) {
		problems.push({
			path: "auth.identity",
			message: "must be { url, label, id?, scopes? }"
		});
		return;
	}
	for (const field of Object.keys(value)) if (![
		"url",
		"label",
		"id",
		"scopes"
	].includes(field)) problems.push({
		path: `auth.identity.${field}`,
		message: "unknown field"
	});
	const url = endpoint(value["url"], "auth.identity.url", problems, { query: true });
	if (value["url"] === void 0) problems.push({
		path: "auth.identity.url",
		message: "required"
	});
	else if (url && !hosts.includes(url.host)) problems.push({
		path: "auth.identity.url",
		message: "must be on one of hosts (the token is sent there)"
	});
	const label = printable(value["label"], "auth.identity.label", problems, 128);
	if (label !== void 0 && !DOT_PATH.test(label)) problems.push({
		path: "auth.identity.label",
		message: "must be a JSON field name, or a dotted path to a nested one"
	});
	if (value["label"] === void 0) problems.push({
		path: "auth.identity.label",
		message: "required"
	});
	const id = printable(value["id"], "auth.identity.id", problems, 128);
	if (id !== void 0 && !DOT_PATH.test(id)) problems.push({
		path: "auth.identity.id",
		message: "must be a JSON field name, or a dotted path to a nested one"
	});
	const scopes = scopeList(value["scopes"], "auth.identity.scopes", problems);
	if (!url || label === void 0) return void 0;
	return {
		identity: {
			url: url.url,
			label,
			...id === void 0 ? {} : { id }
		},
		scopes: scopes ?? []
	};
}
/**
* Parse the OAuth half of a spec whose `auth.kind` is `oauth2-user`, with
* the common fields already parsed. Every problem is reported; on success
* the capability with its `flow`.
*/
function parseOAuthUserSpec(input, common, problems) {
	const auth = input["auth"];
	for (const field of Object.keys(auth)) {
		const renamed = RENAMED_AUTH_FIELDS[field];
		if (renamed) problems.push({
			path: `auth.${field}`,
			message: renamed
		});
		else if (!OAUTH_AUTH_FIELDS.includes(field)) problems.push({
			path: `auth.${field}`,
			message: "not a field of auth.kind oauth2-user"
		});
	}
	const authorize = endpoint(auth["authorizeUrl"], "auth.authorizeUrl", problems, { query: true });
	if (auth["authorizeUrl"] === void 0) problems.push({
		path: "auth.authorizeUrl",
		message: "required"
	});
	const token = endpoint(auth["tokenUrl"], "auth.tokenUrl", problems, { query: false });
	if (auth["tokenUrl"] === void 0) problems.push({
		path: "auth.tokenUrl",
		message: "required"
	});
	const revoke = endpoint(auth["revokeUrl"], "auth.revokeUrl", problems, { query: false });
	const revokeMethod = auth["revokeMethod"];
	if (revokeMethod !== void 0 && revokeMethod !== "POST" && revokeMethod !== "DELETE") problems.push({
		path: "auth.revokeMethod",
		message: "must be POST or DELETE"
	});
	if (revokeMethod !== void 0 && revoke === void 0) problems.push({
		path: "auth.revokeMethod",
		message: "needs a revokeUrl"
	});
	const clientId = settingName$1(auth["clientId"], "auth.clientId", problems);
	const clientSecret = auth["clientSecret"] === void 0 ? void 0 : settingName$1(auth["clientSecret"], "auth.clientSecret", problems);
	if (clientSecret !== void 0 && clientSecret === clientId) problems.push({
		path: "auth.clientSecret",
		message: "must be another setting than auth.clientId"
	});
	const inject = auth["inject"] ?? "form";
	if (!INJECTIONS.includes(inject)) problems.push({
		path: "auth.inject",
		message: "must be form (the client in the body) or basic (HTTP Basic)"
	});
	const pkce = auth["pkce"] ?? true;
	if (typeof pkce !== "boolean") problems.push({
		path: "auth.pkce",
		message: "must be true or false"
	});
	const separator = auth["scopeSeparator"] ?? "space";
	if (!SEPARATORS.includes(separator)) problems.push({
		path: "auth.scopeSeparator",
		message: `must be one of ${SEPARATORS.join(", ")}`
	});
	const prefix = endpoint(auth["scopePrefix"], "auth.scopePrefix", problems, { query: false });
	if (prefix && !prefix.url.endsWith("/")) problems.push({
		path: "auth.scopePrefix",
		message: "must end in / (https://www.googleapis.com/auth/): an app's scope is joined onto it"
	});
	const authorizeParams = stringMap(auth["authorizeParams"], "auth.authorizeParams", problems, (name, at) => {
		if (!PARAM_NAME.test(name)) problems.push({
			path: at,
			message: "must be a query parameter name"
		});
		if (RESERVED_AUTHORIZE_PARAMS.includes(name)) problems.push({
			path: at,
			message: name === "include_granted_scopes" ? "include_granted_scopes would widen the token beyond the app's scopes; the Gateway never sends it" : `${name} is a parameter the Gateway sets itself`
		});
	});
	const tokenHeaders = stringMap(auth["tokenHeaders"], "auth.tokenHeaders", problems, (name, at) => {
		if (!HEADER_NAME$1.test(name)) problems.push({
			path: at,
			message: "must be a header name"
		});
		else if (RESERVED_TOKEN_HEADERS.has(name.toLowerCase()) || name.toLowerCase().startsWith("x-everyapp-")) problems.push({
			path: at,
			message: `${name} is a header the Gateway sets itself`
		});
	});
	const parsedIdentity = identity(auth["identity"], common.hosts, problems);
	const tolerated = scopeList(auth["tolerated"], "auth.tolerated", problems);
	const resource = identifierUrl(auth["resource"], "auth.resource", problems, { query: true });
	const issuer = identifierUrl(auth["issuer"], "auth.issuer", problems, { query: false });
	if (!authorize || !token || clientId === void 0 || typeof pkce !== "boolean" || !SEPARATORS.includes(separator) || !INJECTIONS.includes(inject)) return;
	const flow = {
		authorizeUrl: authorize.url,
		tokenUrl: token.url,
		...revoke === void 0 ? {} : { revokeUrl: revoke.url },
		...revokeMethod === void 0 ? {} : { revokeMethod },
		inject,
		pkce,
		scopeSeparator: separator,
		...prefix === void 0 ? {} : { scopePrefix: prefix.url },
		...authorizeParams === void 0 ? {} : { authorizeParams },
		...tokenHeaders === void 0 ? {} : { tokenHeaders },
		...parsedIdentity === void 0 ? {} : { identity: parsedIdentity.identity },
		identityScopes: parsedIdentity?.scopes ?? [],
		tolerated: tolerated ?? [],
		...resource === void 0 ? {} : { resource },
		...issuer === void 0 ? {} : { issuer }
	};
	const capability = oauthCapabilityOf(common, {
		clientId,
		...clientSecret === void 0 ? {} : { clientSecret }
	}, flow);
	const hosts = [...common.hosts];
	for (const host of [
		authorize.host,
		token.host,
		revoke?.host
	]) if (host && !hosts.includes(host)) hosts.push(host);
	return {
		capability,
		hosts
	};
}
function oauthCapabilityOf(common, secrets, flow) {
	return {
		mode: "oauth_client",
		label: common.name,
		secrets,
		console: common.docs,
		api: [...common.hosts],
		flow,
		...common.description === void 0 ? {} : { description: common.description },
		...common.reference === void 0 ? {} : { reference: common.reference },
		...common.hint === void 0 ? {} : { hint: common.hint },
		...common.example === void 0 ? {} : { example: common.example },
		...common.tags === void 0 ? {} : { tags: common.tags }
	};
}
/**
* A spec already known to be good (a built-in, checked by its test) as
* its capability, without the parse: what the catalog runs at load, where
* calling the full parser would be an import cycle.
*/
function oauthCapabilityFromSpec(spec) {
	const { auth } = spec;
	const flow = {
		authorizeUrl: auth.authorizeUrl,
		tokenUrl: auth.tokenUrl,
		...auth.revokeUrl === void 0 ? {} : { revokeUrl: auth.revokeUrl },
		...auth.revokeMethod === void 0 ? {} : { revokeMethod: auth.revokeMethod },
		inject: auth.inject ?? "form",
		pkce: auth.pkce ?? true,
		scopeSeparator: auth.scopeSeparator ?? "space",
		...auth.scopePrefix === void 0 ? {} : { scopePrefix: auth.scopePrefix },
		...auth.authorizeParams === void 0 ? {} : { authorizeParams: { ...auth.authorizeParams } },
		...auth.tokenHeaders === void 0 ? {} : { tokenHeaders: { ...auth.tokenHeaders } },
		...auth.identity === void 0 ? {} : { identity: {
			url: auth.identity.url,
			label: auth.identity.label,
			...auth.identity.id === void 0 ? {} : { id: auth.identity.id }
		} },
		identityScopes: [...auth.identity?.scopes ?? []],
		tolerated: [...auth.tolerated ?? []]
	};
	return oauthCapabilityOf({
		id: spec.id,
		name: spec.name,
		docs: spec.docs,
		hosts: spec.hosts,
		...spec.description === void 0 ? {} : { description: spec.description },
		...spec.api === void 0 ? {} : { reference: spec.api },
		...spec.hint === void 0 ? {} : { hint: spec.hint },
		...spec.example === void 0 ? {} : { example: spec.example },
		...spec.tags === void 0 ? {} : { tags: spec.tags }
	}, {
		clientId: auth.clientId,
		...auth.clientSecret === void 0 ? {} : { clientSecret: auth.clientSecret }
	}, flow);
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/capabilities.js
/**
* A built-in OAuth provider's catalog entry from its spec, its setting
* names kept literal so `CapabilitySecret` names them.
*/
function builtInOAuth(spec, setup) {
	return {
		...oauthCapabilityFromSpec(spec),
		secrets: {
			clientId: spec.auth.clientId,
			clientSecret: spec.auth.clientSecret
		},
		setup
	};
}
var CAPABILITIES = {
	openai: {
		mode: "ai",
		label: "OpenAI",
		description: "OpenAI's models: responses, chat, embeddings, audio, images.",
		auth: {
			kind: "bearer",
			secret: "OPENAI_API_KEY"
		},
		docs: "https://platform.openai.com/api-keys",
		api: "https://platform.openai.com/docs/api-reference",
		setup: "setup/openai.md",
		origin: "https://api.openai.com",
		inferenceRoutes: [
			"/v1/responses",
			"/v1/chat/completions",
			"/v1/embeddings",
			"/v1/audio/speech",
			"/v1/audio/transcriptions",
			"/v1/audio/translations",
			"/v1/images/generations",
			"/v1/images/edits",
			"/v1/images/variations"
		],
		unstoredRoutes: ["/v1/responses", "/v1/chat/completions"],
		extraRoutes: true,
		chat: {
			path: "/v1/chat/completions",
			seedModel: "gpt-6-luna"
		},
		embeddings: {
			path: "/v1/embeddings",
			seedModel: "text-embedding-3-small"
		},
		aig: {
			slug: "openai",
			trim: "/v1"
		},
		hint: "A secret key from the API keys page; the Gateway puts it on every call as a bearer token.",
		verified: {
			on: "2026-10-25",
			how: "live"
		}
	},
	openrouter: {
		mode: "ai",
		label: "OpenRouter",
		description: "One key for many models, through OpenAI's API shape.",
		auth: {
			kind: "bearer",
			secret: "OPENROUTER_API_KEY"
		},
		docs: "https://openrouter.ai/settings/keys",
		api: "https://openrouter.ai/docs",
		setup: "setup/openrouter.md",
		origin: "https://openrouter.ai",
		inferenceRoutes: [
			"/api/v1/chat/completions",
			"/api/v1/completions",
			"/api/v1/responses",
			"/api/v1/embeddings"
		],
		chat: {
			path: "/api/v1/chat/completions",
			seedModel: "anthropic/claude-haiku-5.5"
		},
		embeddings: {
			path: "/api/v1/embeddings",
			seedModel: "openai/text-embedding-3-small"
		},
		aig: {
			slug: "openrouter",
			trim: "/api"
		},
		hint: "An API key from OpenRouter's keys page; the Gateway puts it on every call as a bearer token.",
		cost: {
			unit: "token",
			responseField: "usage.cost",
			note: "The answer's usage.cost is the call's price in USD, per model."
		},
		verified: {
			on: "2026-10-25",
			how: "live"
		}
	},
	"workers-ai": {
		mode: "ai",
		label: "Workers AI",
		description: "Cloudflare's models, in the Gateway's own account.",
		auth: {
			kind: "bearer",
			secret: "WORKERS_AI_API_TOKEN"
		},
		docs: "https://dash.cloudflare.com/profile/api-tokens",
		api: "https://developers.cloudflare.com/workers-ai/",
		setup: "setup/workers-ai.md",
		origin: "https://api.cloudflare.com",
		alsoNeeds: ["CLOUDFLARE_ACCOUNT_ID"],
		basePath: "/client/v4/accounts/{CLOUDFLARE_ACCOUNT_ID}/ai",
		inferenceRoutes: [
			"/v1/chat/completions",
			"/v1/embeddings",
			"/v1/responses"
		],
		normalize: "workers-ai",
		chat: {
			path: "/v1/chat/completions",
			seedModel: "@cf/meta/llama-4-scout-17b-16e-instruct"
		},
		embeddings: {
			path: "/v1/embeddings",
			seedModel: "@cf/baai/bge-m3"
		},
		aig: {
			slug: "workers-ai",
			header: true
		},
		hint: "A Cloudflare API token with Workers AI Read (the Workers AI page's prefilled token); the account is the Gateway's own.",
		verified: {
			on: "2026-10-25",
			how: "live"
		}
	},
	"ai-gateway": {
		mode: "ai",
		kind: "proxy",
		label: "Cloudflare AI Gateway",
		description: "Cloudflare's proxy in front of the other AI providers: logs, caching, rate limits and spend, with each provider's own key.",
		auth: {
			kind: "header",
			header: "cf-aig-authorization",
			prefix: "Bearer ",
			secret: "AI_GATEWAY_API_KEY"
		},
		authOptional: true,
		docs: "https://dash.cloudflare.com/?to=/:account/ai/ai-gateway",
		api: "https://developers.cloudflare.com/ai-gateway/",
		setup: "setup/ai-gateway.md",
		origin: "https://gateway.ai.cloudflare.com",
		alsoNeeds: ["CLOUDFLARE_ACCOUNT_ID", "AI_GATEWAY_ID"],
		basePath: "/v1/{CLOUDFLARE_ACCOUNT_ID}/{AI_GATEWAY_ID}",
		inferenceRoutes: [],
		hint: "The gateway's id from the AI Gateway page (everyapp ai gateway on makes one named everyapp); AI_GATEWAY_API_KEY only for an authenticated gateway, sent as cf-aig-authorization.",
		secrets: [{
			name: "AI_GATEWAY_ID",
			hint: "The AI Gateway's id (its name in the dashboard), in the Gateway's own Cloudflare account."
		}, {
			name: "AI_GATEWAY_API_KEY",
			hint: "An AI Gateway token with Run permission, only when the gateway is authenticated; leave unset for an open gateway."
		}],
		verified: {
			on: "2026-10-25",
			how: "docs"
		}
	},
	dataforseo: {
		mode: "api_key",
		label: "DataForSEO",
		description: "SEO data: keyword metrics, live search results, domain rankings, backlinks.",
		auth: {
			kind: "basic",
			secret: "DATAFORSEO_API_KEY",
			as: "pair"
		},
		docs: "https://app.dataforseo.com/api-access",
		api: "https://docs.dataforseo.com/v3/",
		setup: "setup/dataforseo.md",
		hosts: ["api.dataforseo.com", "sandbox.dataforseo.com"],
		access: ["read"],
		readMethods: ["GET", "POST"],
		accountWidePaths: [
			["tasks_ready"],
			["tasks_fixed"],
			["id_list"],
			["errors"],
			["appendix", "user_data"],
			["appendix", "webhook_resend"]
		],
		hint: "The API login and password from API Access, as login:password (or that pair base64-encoded); the Gateway sends them as HTTP Basic.",
		secrets: [{
			name: "DATAFORSEO_API_KEY",
			hint: "login:password, or its base64; never the dashboard sign-in password."
		}],
		cost: {
			unit: "call",
			responseField: "cost",
			note: "A Google SERP $0.002 per 10 results; a Labs task $0.012 plus $0.00012 per item."
		},
		smoke: {
			method: "GET",
			path: "/v3/appendix/user_data",
			expect: [200],
			free: true,
			note: "Account-wide, so the Gateway refuses it for apps; run it from the person's terminal."
		},
		example: "find keyword ideas for a page about running shoes",
		verified: {
			on: "2026-10-25",
			how: "live"
		}
	},
	context: {
		mode: "api_key",
		label: "Context.dev",
		description: "Scrapes and renders web pages, JavaScript included.",
		auth: {
			kind: "bearer",
			secret: "CONTEXT_API_KEY"
		},
		docs: "https://context.dev/",
		setup: "setup/context.md",
		hosts: ["api.context.dev"],
		access: ["read"],
		readMethods: ["GET", "POST"],
		accountWidePaths: [],
		hint: "An API key from the Context.dev dashboard; the Gateway puts it on every call as a bearer token.",
		verified: {
			on: "2026-10-25",
			how: "live"
		}
	},
	email: {
		mode: "service",
		label: "Email",
		access: ["write"],
		routes: { send: ["POST"] },
		settings: ["EMAIL_FROM", "EMAIL_FROM_NAME"],
		optionalSettings: [
			"EMAIL_REST_API_TOKEN",
			"CLOUDFLARE_ACCOUNT_ID",
			"RESEND_API_KEY",
			"EMAIL_PROVIDER"
		],
		setup: "setup/email.md"
	},
	members: {
		mode: "service",
		label: "Members",
		access: ["read"],
		routes: { list: ["GET"] },
		settings: [],
		optionalSettings: []
	},
	slack: builtInOAuth(BUILT_IN_OAUTH_SPECS.slack, "setup/slack.md"),
	"google-workspace": builtInOAuth(BUILT_IN_OAUTH_SPECS["google-workspace"], "setup/google.md"),
	"microsoft-365": builtInOAuth(BUILT_IN_OAUTH_SPECS["microsoft-365"], "setup/microsoft-365.md"),
	...CATALOG_ENTRIES
};
/** The Gateway settings an API-key or AI provider's `auth` names: the key first, then a Basic username held as a setting. */
function authSettingNames(auth) {
	const names = [auth.secret];
	if (auth.kind === "basic" && auth.as === "password" && typeof auth.user === "object") names.push(auth.user.secret);
	return names;
}
/** Every gateway setting `capability` reads, the ones it needs first. */
function capabilitySettings(capability) {
	switch (capability.mode) {
		case "api_key": return [...authSettingNames(capability.auth), ...capability.hostSetting ? [capability.hostSetting] : []];
		case "ai": return [...authSettingNames(capability.auth), ...capability.alsoNeeds ?? []];
		case "service": return [...capability.settings, ...capability.optionalSettings];
		case "oauth_client": return [capability.secrets.clientId, ...capability.secrets.clientSecret ? [capability.secrets.clientSecret] : []];
	}
}
var CAPABILITY_IDS = Object.keys(CAPABILITIES);
function isCapabilityId(value) {
	return typeof value === "string" && Object.hasOwn(CAPABILITIES, value);
}
/** The built-in catalog as a lookup: what every surface reads without a gateway's rows. */
var CATALOG = {
	get: (id) => isCapabilityId(id) ? CAPABILITIES[id] : void 0,
	ids: () => CAPABILITY_IDS
};
/**
* The settings `capability` needs on a request, read from the Gateway's
* settings (or `.dev.vars`): the headers to set and the query parameters
* to add, or null while any setting its `auth` names is unset or blank.
* Values are trimmed. A Basic key without a username is `login:password`
* to encode, or taken as already encoded when it holds no colon.
*/
function authorizationFor(capability, settings) {
	const declared = {};
	for (const name of capabilitySettings(capability)) declared[name] = settings[name];
	return authorizationOf(capability.auth, declared);
}
/** {@link authorizationFor} for an `auth` block alone (the SDK's AI fallback holds the block, not the entry). */
function authorizationOf(auth, settings) {
	const key = settingValue(settings[auth.secret]);
	if (!key) return null;
	switch (auth.kind) {
		case "bearer": return {
			headers: { authorization: `${auth.scheme ?? "Bearer"} ${key}` },
			query: {}
		};
		case "header": return {
			headers: { [auth.header.toLowerCase()]: `${auth.prefix ?? ""}${key}` },
			query: {}
		};
		case "query": return {
			headers: {},
			query: { [auth.param]: key }
		};
		case "basic": {
			const basic = (credentials) => ({
				headers: { authorization: `Basic ${credentials}` },
				query: {}
			});
			if (auth.as === "pair") return basic(basicCredentials(key));
			if (auth.as === "username") return basic(base64Utf8(`${key}:`));
			const user = typeof auth.user === "string" ? auth.user : settingValue(settings[auth.user.secret]);
			if (!user) return null;
			return basic(base64Utf8(`${user}:${key}`));
		}
	}
}
function settingValue(value) {
	return typeof value === "string" && value.trim() ? value.trim() : void 0;
}
/**
* The host a provider's `hostSetting` names, from its value: a bare host
* or an https origin with nothing else (no path, port, query, userinfo),
* lowercased; null when unset or not of that shape. The host rules a row
* must pass apply to it when the registry reads the row.
*/
function hostSettingValue(value) {
	const text = settingValue(value);
	if (!text) return null;
	let url;
	try {
		url = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(text) ? text : `https://${text}`);
	} catch {
		return null;
	}
	return url.protocol === "https:" && url.pathname === "/" && !url.search && !url.hash && !url.username && !url.password && !url.port && !text.endsWith("/") ? url.hostname.toLowerCase() : null;
}
/**
* The hosts an API-key provider's key may be sent to: the entry's own,
* and the one its `hostSetting` names when that is set and well-formed.
*/
function apiKeyHosts(capability, settings) {
	const named = capability.hostSetting ? hostSettingValue(settings?.[capability.hostSetting]) : null;
	return [...capability.hosts, ...named ? [named] : []];
}
/** Where AppGateway serves capability calls. */
var INTEGRATION_PROXY_PREFIX = "/api/integrations";
/**
* The AppGateway path for a call to `upstream`:
* `/api/integrations/<id>/<host><path>?<query>`. The host is in the path so
* a provider with several API hosts needs no other channel.
*/
function integrationProxyPath(id, upstream) {
	return `${INTEGRATION_PROXY_PREFIX}/${id}/${upstream.host}${upstream.pathname}${upstream.search}`;
}
/**
* A Basic credential held as one setting: `login:password` as a dashboard
* shows them, or the pair already base64-encoded (DataForSEO's rule, and
* what OpenSEO's DATAFORSEO_API_KEY has always held). A base64 string never
* holds a colon, so the colon decides.
*/
function basicCredentials(key) {
	const trimmed = key.trim();
	return trimmed.includes(":") ? base64Utf8(trimmed) : trimmed;
}
/** The base64 of `text`'s UTF-8 bytes (`btoa` takes Latin-1 only). */
function base64Utf8(text) {
	let binary = "";
	for (const byte of new TextEncoder().encode(text)) binary += String.fromCharCode(byte);
	return btoa(binary);
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/providerSpec.js
/**
* A provider spec: the shape `everyapp provider add` takes as JSON (and
* `everyapp_provider_add` as a tool argument), and the shape every
* built-in catalog entry has in TypeScript (./capabilities.ts), so a
* catalog entry is nothing a row couldn't be. `parseProviderSpec` turns
* JSON into an {@link ApiKeyCapability} or names every problem; nothing
* here reads a value: a spec names Gateway settings, never holds one.
*
* Three kinds parse: API-key providers (`auth.kind` bearer, header, query
* or basic), OAuth providers (`auth.kind` oauth2-user, the half in
* ./oauthSpec.ts: the Gateway runs the flow and holds the tokens,
* docs/design/2026-10-oauth-providers.md), and OpenAI-compatible model
* providers (`mode: "ai"`: a `baseUrl`, the key's placement, the models
* it serves and the default, its inference routes; the AI proxy serves a
* row exactly as it serves a catalog `ai` entry, inference POSTs alone,
* `store: false` on chat, the usage tap, so a new model vendor is a
* registered spec, not a catalog release).
*
* The rules that make a row safe on a particular gateway (its secret names
* are its own, its hosts are public, it shadows no catalog entry) are the
* registry's (./providerRegistry.ts), run after this parse.
*/
/** A provider id: lowercase, a letter first, 2 to 40 characters. */
var PROVIDER_ID = /^[a-z][a-z0-9-]{1,39}$/;
/** A Gateway setting name a provider may hold: upper case, 3 to 64 characters. */
var PROVIDER_SECRET_NAME = /^[A-Z][A-Z0-9_]{2,63}$/;
/** A bare lowercase host with at least one dot: labels of letters, digits and hyphens. */
var PROVIDER_HOST = /^(?=.{1,253}$)(?!-)[a-z0-9-]{1,63}(?<!-)(?:\.(?!-)[a-z0-9-]{1,63}(?<!-))+$/;
var METHODS = [
	"GET",
	"HEAD",
	"POST",
	"PUT",
	"PATCH",
	"DELETE"
];
var SEGMENT = /^[a-z0-9_-]{1,64}$/;
var HEADER_NAME = /^[A-Za-z0-9-]{1,64}$/;
var QUERY_PARAM = /^[A-Za-z0-9_.-]{1,64}$/;
var SCHEME = /^[A-Za-z][A-Za-z0-9-]{0,31}$/;
/**
* A JSON field name, or a dotted path to a nested one (`usage.cost`, at
* most four segments): the capability proxy reads a top-level name off the
* answer's head, the AI proxy a path into the usage object off its tail.
*/
var RESPONSE_FIELD = /^[A-Za-z_][A-Za-z0-9_]{0,63}(?:\.[A-Za-z_][A-Za-z0-9_]{0,63}){0,3}$/;
var DATE = /^\d{4}-\d{2}-\d{2}$/;
var TAG = /^[a-z][a-z0-9-]{0,31}$/;
/** Control and format characters: in no text a spec carries. */
var UNPRINTABLE = /[\p{Cc}\p{Cf}]/u;
/** Headers the proxy sets or strips itself: a spec can't put the key in one. */
var RESERVED_HEADERS = /* @__PURE__ */ new Set([
	"host",
	"cookie",
	"content-length",
	"content-type",
	"transfer-encoding",
	"connection",
	"upgrade",
	"te",
	"trailer",
	"keep-alive",
	"proxy-authorization",
	"proxy-authenticate",
	"forwarded",
	"x-forwarded-for",
	"x-forwarded-host",
	"x-forwarded-proto"
]);
var MAX_HOSTS = 20;
var MAX_ACCOUNT_WIDE_PATHS = 50;
/** An inference route an `ai` row names: `/v1/chat/completions`, segments of lowercase letters, digits, `_` and `-`. */
var AI_ROUTE = /^(?:\/[a-z0-9_-]+)+$/;
var MAX_AI_ROUTES = 20;
var MAX_MODELS = 100;
/** A model name as OpenAI-compatible APIs spell them: `gpt-6-luna`, `meta-llama/llama-4`, `claude-haiku-5-5:beta`. */
var MODEL_NAME = /^[A-Za-z0-9][A-Za-z0-9._:/@-]{0,199}$/;
var KNOWN_FIELDS = /* @__PURE__ */ new Set([
	"id",
	"mode",
	"name",
	"description",
	"docs",
	"api",
	"hosts",
	"hostSetting",
	"data",
	"auth",
	"secrets",
	"access",
	"readMethods",
	"writeMethods",
	"accountWidePaths",
	"hint",
	"smoke",
	"cost",
	"rate",
	"example",
	"verified",
	"tags",
	"baseUrl",
	"models",
	"defaultModel",
	"embeddingsModel",
	"routes",
	"chatRoute",
	"embeddingsRoute"
]);
/** Fields an `ai` spec never has: the key goes to one base URL, and the AI proxy's rules replace the capability proxy's. */
var NOT_AI_FIELDS = [
	"hosts",
	"hostSetting",
	"data",
	"access",
	"readMethods",
	"writeMethods",
	"accountWidePaths"
];
/** Fields an API-key spec has that an `oauth2-user` spec does not. */
var API_KEY_ONLY_FIELDS = [
	"hostSetting",
	"data",
	"secrets",
	"accountWidePaths",
	"smoke",
	"cost",
	"rate",
	"verified"
];
function isRecord$3(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function text(value, path, problems, { max, min = 1 }) {
	if (value === void 0) return void 0;
	if (typeof value !== "string") {
		problems.push({
			path,
			message: "must be a string"
		});
		return;
	}
	if (value.length < min || value.length > max) {
		problems.push({
			path,
			message: `must be ${min} to ${max} characters`
		});
		return;
	}
	if (UNPRINTABLE.test(value)) {
		problems.push({
			path,
			message: "holds a control character"
		});
		return;
	}
	return value;
}
function httpsUrl(value, path, problems) {
	const url = text(value, path, problems, { max: 500 });
	if (url === void 0) return void 0;
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		problems.push({
			path,
			message: "must be an https URL"
		});
		return;
	}
	if (parsed.protocol !== "https:") {
		problems.push({
			path,
			message: "must be an https URL"
		});
		return;
	}
	return url;
}
function stringList(value, path, problems, { max, each }) {
	if (value === void 0) return void 0;
	if (!Array.isArray(value)) {
		problems.push({
			path,
			message: "must be a list"
		});
		return;
	}
	if (value.length > max) {
		problems.push({
			path,
			message: `at most ${max} entries`
		});
		return;
	}
	const out = [];
	value.forEach((item, index) => {
		if (typeof item !== "string") {
			problems.push({
				path: `${path}.${index}`,
				message: "must be a string"
			});
			return;
		}
		each(item, `${path}.${index}`);
		out.push(item);
	});
	if (new Set(out).size !== out.length) problems.push({
		path,
		message: "lists an entry twice"
	});
	return out;
}
function methods(value, path, problems) {
	return stringList(value, path, problems, {
		max: METHODS.length,
		each: (method, at) => {
			if (!METHODS.includes(method)) problems.push({
				path: at,
				message: `must be one of ${METHODS.join(", ")}`
			});
		}
	});
}
function secretName(value, path, problems) {
	if (typeof value !== "string" || !PROVIDER_SECRET_NAME.test(value)) {
		problems.push({
			path,
			message: "must name a Gateway setting: upper case letters, digits and underscores, a letter first, 3 to 64 characters (STRIPE_API_KEY)"
		});
		return;
	}
	return value;
}
function auth(value, problems) {
	if (!isRecord$3(value)) {
		problems.push({
			path: "auth",
			message: "must be an object with a kind: bearer, header, query or basic"
		});
		return;
	}
	const kind = value["kind"];
	const secret = secretName(value["secret"], "auth.secret", problems);
	const known = (fields) => {
		for (const field of Object.keys(value)) if (!fields.includes(field)) problems.push({
			path: `auth.${field}`,
			message: `not a field of auth.kind ${String(kind)}`
		});
	};
	switch (kind) {
		case "bearer": {
			known([
				"kind",
				"secret",
				"scheme"
			]);
			const scheme = text(value["scheme"], "auth.scheme", problems, { max: 32 });
			if (scheme !== void 0 && !SCHEME.test(scheme)) problems.push({
				path: "auth.scheme",
				message: "must be a token such as Bearer, Token or Api-Key"
			});
			if (!secret) return void 0;
			return {
				kind,
				secret,
				...scheme === void 0 ? {} : { scheme }
			};
		}
		case "header": {
			known([
				"kind",
				"secret",
				"header",
				"prefix"
			]);
			const header = text(value["header"], "auth.header", problems, { max: 64 });
			if (header !== void 0) {
				if (!HEADER_NAME.test(header)) problems.push({
					path: "auth.header",
					message: "must be a header name (letters, digits, hyphens)"
				});
				else if (RESERVED_HEADERS.has(header.toLowerCase()) || header.toLowerCase().startsWith("x-everyapp-")) problems.push({
					path: "auth.header",
					message: `${header} is a header the Gateway sets or strips itself`
				});
			}
			const prefix = text(value["prefix"], "auth.prefix", problems, {
				max: 32,
				min: 0
			});
			if (!secret || header === void 0) return void 0;
			return {
				kind,
				secret,
				header,
				...prefix === void 0 ? {} : { prefix }
			};
		}
		case "query": {
			known([
				"kind",
				"secret",
				"param"
			]);
			const param = text(value["param"], "auth.param", problems, { max: 64 });
			if (param !== void 0 && !QUERY_PARAM.test(param)) problems.push({
				path: "auth.param",
				message: "must be a query parameter name"
			});
			if (!secret || param === void 0) return void 0;
			return {
				kind,
				secret,
				param
			};
		}
		case "basic": {
			known([
				"kind",
				"secret",
				"as",
				"user"
			]);
			const as = value["as"];
			if (as !== "password" && as !== "username" && as !== "pair") {
				problems.push({
					path: "auth.as",
					message: "must say where the key goes: \"password\" (beside user), \"username\" (with an empty password), or \"pair\" (the key is login:password)"
				});
				return;
			}
			if (as !== "password") {
				if (value["user"] !== void 0) problems.push({
					path: "auth.user",
					message: `not a field of auth.as ${as}`
				});
				if (!secret) return void 0;
				return {
					kind,
					secret,
					as
				};
			}
			const raw = value["user"];
			let user;
			if (typeof raw === "string") {
				const literal = text(raw, "auth.user", problems, { max: 128 });
				if (literal !== void 0 && literal.includes(":")) problems.push({
					path: "auth.user",
					message: "may not hold a colon"
				});
				user = literal;
			} else if (isRecord$3(raw) && Object.keys(raw).join() === "secret") {
				const named = secretName(raw["secret"], "auth.user.secret", problems);
				if (named !== void 0 && named === secret) problems.push({
					path: "auth.user.secret",
					message: "must be another setting than auth.secret"
				});
				user = named === void 0 ? void 0 : { secret: named };
			} else problems.push({
				path: "auth.user",
				message: "required with as: password: a string, or { secret: NAME }"
			});
			if (!secret || user === void 0) return void 0;
			return {
				kind,
				secret,
				as,
				user
			};
		}
		default:
			problems.push({
				path: "auth.kind",
				message: "must be bearer, header, query, basic or oauth2-user (an AI provider is a catalog entry, not a spec this gateway takes)"
			});
			return;
	}
}
function secretDetails(value, names, problems) {
	if (value === void 0) return void 0;
	if (!Array.isArray(value)) {
		problems.push({
			path: "secrets",
			message: "must be a list"
		});
		return;
	}
	const out = [];
	value.forEach((item, index) => {
		const at = `secrets.${index}`;
		if (!isRecord$3(item)) {
			problems.push({
				path: at,
				message: "must be an object"
			});
			return;
		}
		for (const field of Object.keys(item)) if (!["name", "hint"].includes(field)) problems.push({
			path: `${at}.${field}`,
			message: "unknown field"
		});
		const name = secretName(item["name"], `${at}.name`, problems);
		if (name !== void 0 && !names.includes(name)) problems.push({
			path: `${at}.name`,
			message: `auth names no setting ${name}`
		});
		const hint = text(item["hint"], `${at}.hint`, problems, { max: 300 });
		if (name === void 0) return;
		out.push({
			name,
			...hint === void 0 ? {} : { hint }
		});
	});
	if (new Set(out.map((detail) => detail.name)).size !== out.length) problems.push({
		path: "secrets",
		message: "names a setting twice"
	});
	return out;
}
function accountWidePaths(value, problems) {
	if (value === void 0) return void 0;
	if (!Array.isArray(value)) {
		problems.push({
			path: "accountWidePaths",
			message: "must be a list of segment runs: [[\"v1\", \"account\"]]"
		});
		return;
	}
	if (value.length > MAX_ACCOUNT_WIDE_PATHS) {
		problems.push({
			path: "accountWidePaths",
			message: `at most ${MAX_ACCOUNT_WIDE_PATHS} entries`
		});
		return;
	}
	const out = [];
	value.forEach((run, index) => {
		const at = `accountWidePaths.${index}`;
		if (!Array.isArray(run) || run.length === 0) {
			problems.push({
				path: at,
				message: "must be a non-empty list of segments"
			});
			return;
		}
		const segments = [];
		run.forEach((segment, offset) => {
			if (typeof segment !== "string" || !SEGMENT.test(segment)) {
				problems.push({
					path: `${at}.${offset}`,
					message: "must be a lowercase path segment (letters, digits, _ and -)"
				});
				return;
			}
			segments.push(segment);
		});
		if (segments.length === run.length) out.push(segments);
	});
	return out;
}
function smoke(value, hosts, problems) {
	if (value === void 0) return void 0;
	if (!isRecord$3(value)) {
		problems.push({
			path: "smoke",
			message: "must be an object"
		});
		return;
	}
	for (const field of Object.keys(value)) if (![
		"method",
		"host",
		"path",
		"expect",
		"free",
		"note"
	].includes(field)) problems.push({
		path: `smoke.${field}`,
		message: "unknown field"
	});
	const method = value["method"];
	if (method !== "GET" && method !== "HEAD" && method !== "POST") problems.push({
		path: "smoke.method",
		message: "must be GET, HEAD or POST"
	});
	const host = text(value["host"], "smoke.host", problems, { max: 253 });
	if (host !== void 0 && !hosts.includes(host)) problems.push({
		path: "smoke.host",
		message: "must be one of hosts"
	});
	const path = text(value["path"], "smoke.path", problems, { max: 500 });
	if (path !== void 0 && (!path.startsWith("/") || path.startsWith("//"))) problems.push({
		path: "smoke.path",
		message: "must start with one /"
	});
	const expect = value["expect"];
	const statuses = Array.isArray(expect) && expect.length > 0 && expect.every((status) => Number.isInteger(status) && status >= 100 && status <= 599) ? expect : void 0;
	if (!statuses) problems.push({
		path: "smoke.expect",
		message: "must list the HTTP statuses that mean the key works"
	});
	const free = value["free"];
	if (typeof free !== "boolean") problems.push({
		path: "smoke.free",
		message: "must be true or false"
	});
	const note = text(value["note"], "smoke.note", problems, { max: 200 });
	if (method !== "GET" && method !== "HEAD" && method !== "POST" || path === void 0 || !statuses || typeof free !== "boolean") return;
	return {
		method,
		...host === void 0 ? {} : { host },
		path,
		expect: statuses,
		free,
		...note === void 0 ? {} : { note }
	};
}
function nonNegative(value, path, problems) {
	if (value === void 0) return void 0;
	if (typeof value !== "number" || !Number.isFinite(value) || value < 0) {
		problems.push({
			path,
			message: "must be a number, zero or more"
		});
		return;
	}
	return value;
}
function cost(value, problems) {
	if (value === void 0) return void 0;
	if (!isRecord$3(value)) {
		problems.push({
			path: "cost",
			message: "must be an object"
		});
		return;
	}
	for (const field of Object.keys(value)) if (![
		"unit",
		"usd",
		"note",
		"responseField"
	].includes(field)) problems.push({
		path: `cost.${field}`,
		message: "unknown field"
	});
	const unit = value["unit"];
	if (unit !== "call" && unit !== "result" && unit !== "token") problems.push({
		path: "cost.unit",
		message: "must be call, result or token"
	});
	const usd = nonNegative(value["usd"], "cost.usd", problems);
	const note = text(value["note"], "cost.note", problems, { max: 200 });
	const responseField = text(value["responseField"], "cost.responseField", problems, { max: 128 });
	if (responseField !== void 0 && !RESPONSE_FIELD.test(responseField)) problems.push({
		path: "cost.responseField",
		message: "must be a JSON field name, or a dotted path to a nested one"
	});
	if (unit !== "call" && unit !== "result" && unit !== "token") return void 0;
	return {
		unit,
		...usd === void 0 ? {} : { usd },
		...note === void 0 ? {} : { note },
		...responseField === void 0 ? {} : { responseField }
	};
}
function rate(value, problems) {
	if (value === void 0) return void 0;
	if (!isRecord$3(value)) {
		problems.push({
			path: "rate",
			message: "must be an object"
		});
		return;
	}
	for (const field of Object.keys(value)) if (![
		"perSecond",
		"perMinute",
		"perDay",
		"note"
	].includes(field)) problems.push({
		path: `rate.${field}`,
		message: "unknown field"
	});
	const perSecond = nonNegative(value["perSecond"], "rate.perSecond", problems);
	const perMinute = nonNegative(value["perMinute"], "rate.perMinute", problems);
	const perDay = nonNegative(value["perDay"], "rate.perDay", problems);
	const note = text(value["note"], "rate.note", problems, { max: 200 });
	return {
		...perSecond === void 0 ? {} : { perSecond },
		...perMinute === void 0 ? {} : { perMinute },
		...perDay === void 0 ? {} : { perDay },
		...note === void 0 ? {} : { note }
	};
}
function verified(value, problems) {
	if (value === void 0) return void 0;
	if (value === false) return false;
	if (isRecord$3(value) && typeof value["on"] === "string" && DATE.test(value["on"]) && (value["how"] === "docs" || value["how"] === "live") && Object.keys(value).length === 2) return {
		on: value["on"],
		how: value["how"]
	};
	problems.push({
		path: "verified",
		message: "must be false, or { \"on\": \"YYYY-MM-DD\", \"how\": \"docs\" | \"live\" }"
	});
}
/** `access`, `readMethods` and `writeMethods`, shared by both kinds. */
function grants(input, problems) {
	const access = stringList(input["access"], "access", problems, {
		max: 2,
		each: (level, at) => {
			if (level !== "read" && level !== "write") problems.push({
				path: at,
				message: "must be read or write"
			});
		}
	});
	if (access && access.length === 0) problems.push({
		path: "access",
		message: "must list read, write or both"
	});
	const readMethods = methods(input["readMethods"], "readMethods", problems);
	if (readMethods && readMethods.length === 0 && (!Array.isArray(access) || access.includes("read"))) problems.push({
		path: "readMethods",
		message: "must list a method unless access is write alone"
	});
	return {
		access,
		readMethods,
		writeMethods: methods(input["writeMethods"], "writeMethods", problems)
	};
}
function tagList(value, problems) {
	return stringList(value, "tags", problems, {
		max: 10,
		each: (tag, at) => {
			if (!TAG.test(tag)) problems.push({
				path: at,
				message: "must be a lowercase word"
			});
		}
	});
}
/**
* Parse a provider spec. Every problem is reported, with its path, so a
* person fixes the file once. On success the id and the catalog-shaped
* capability, defaults filled in (`access` read, `readMethods` GET and
* HEAD, no account-wide paths).
*/
function parseProviderSpec(input) {
	const problems = [];
	if (!isRecord$3(input)) return {
		ok: false,
		problems: [{
			path: "(root)",
			message: "must be a JSON object"
		}]
	};
	const oauthSpec = isRecord$3(input["auth"]) && input["auth"]["kind"] === "oauth2-user";
	for (const field of Object.keys(input)) {
		if (oauthSpec && Object.hasOwn(REMOVED_OAUTH_FIELDS, field)) continue;
		if (!KNOWN_FIELDS.has(field)) problems.push({
			path: field,
			message: "unknown field"
		});
	}
	const id = input["id"];
	if (typeof id !== "string" || !PROVIDER_ID.test(id)) problems.push({
		path: "id",
		message: "must be lowercase letters, digits and hyphens, a letter first, 2 to 40 characters (stripe)"
	});
	const isOAuth = isRecord$3(input["auth"]) && input["auth"]["kind"] === "oauth2-user";
	const isAi = input["mode"] === "ai";
	const expectedMode = isOAuth ? "oauth_client" : "api_key";
	if (!isAi && input["mode"] !== void 0 && input["mode"] !== expectedMode) problems.push({
		path: "mode",
		message: isOAuth ? "an oauth2-user spec's mode is oauth_client (or left out)" : "this gateway registers api_key, oauth_client (auth.kind oauth2-user) and ai (mode: \"ai\", an OpenAI-compatible model provider) providers"
	});
	if (isAi && isOAuth) problems.push({
		path: "auth.kind",
		message: "an ai spec's key is a bearer, header, query or basic key, never oauth2-user"
	});
	const name = text(input["name"], "name", problems, { max: 64 });
	if (input["name"] === void 0) problems.push({
		path: "name",
		message: "required"
	});
	const description = text(input["description"], "description", problems, { max: 200 });
	const docs = httpsUrl(input["docs"], "docs", problems);
	if (input["docs"] === void 0) problems.push({
		path: "docs",
		message: "required: where the person gets the key, an https URL"
	});
	const api = httpsUrl(input["api"], "api", problems);
	const hosts = stringList(input["hosts"], "hosts", problems, {
		max: MAX_HOSTS,
		each: (host, at) => {
			if (!PROVIDER_HOST.test(host)) problems.push({
				path: at,
				message: "must be a bare lowercase host with a dot and no port, path or scheme (api.stripe.com)"
			});
		}
	});
	if (isAi && !isOAuth) return parseAiSpec(input, problems, {
		id,
		name,
		description,
		docs,
		api
	});
	if (isOAuth) {
		for (const [field, message] of Object.entries(REMOVED_OAUTH_FIELDS)) if (input[field] !== void 0) problems.push({
			path: field,
			message
		});
		const hint = text(input["hint"], "hint", problems, { max: 500 });
		const example = text(input["example"], "example", problems, { max: 200 });
		const tags = tagList(input["tags"], problems);
		for (const field of API_KEY_ONLY_FIELDS) if (input[field] !== void 0) problems.push({
			path: field,
			message: "not a field of an oauth2-user spec"
		});
		if (input["hosts"] === void 0 || hosts && hosts.length === 0) problems.push({
			path: "hosts",
			message: "required: at least one API host the token is sent to"
		});
		const parsed = typeof id === "string" && name !== void 0 && docs !== void 0 && hosts !== void 0 ? parseOAuthUserSpec(input, {
			id,
			name,
			docs,
			hosts,
			...description === void 0 ? {} : { description },
			...api === void 0 ? {} : { reference: api },
			...hint === void 0 ? {} : { hint },
			...example === void 0 ? {} : { example },
			...tags === void 0 ? {} : { tags }
		}, problems) : void 0;
		if (problems.length > 0 || !parsed || typeof id !== "string") return {
			ok: false,
			problems
		};
		return {
			ok: true,
			id,
			capability: parsed.capability
		};
	}
	const hostSetting = input["hostSetting"] === void 0 ? void 0 : secretName(input["hostSetting"], "hostSetting", problems);
	if (hostSetting === void 0 && (input["hosts"] === void 0 || hosts && hosts.length === 0)) problems.push({
		path: "hosts",
		message: "required: at least one host, or a hostSetting naming one"
	});
	const rawData = input["data"];
	if (rawData !== void 0 && rawData !== "per-call" && rawData !== "account") problems.push({
		path: "data",
		message: "must be per-call or account"
	});
	const data = rawData === "per-call" || rawData === "account" ? rawData : void 0;
	const parsedAuth = auth(input["auth"], problems);
	if (input["auth"] === void 0) problems.push({
		path: "auth",
		message: "required"
	});
	if (hostSetting !== void 0 && parsedAuth && authSettingNames(parsedAuth).includes(hostSetting)) problems.push({
		path: "hostSetting",
		message: "must be another setting than the key"
	});
	const secrets = secretDetails(input["secrets"], [...parsedAuth ? authSettingNames(parsedAuth) : [], ...hostSetting === void 0 ? [] : [hostSetting]], problems);
	const { access, readMethods, writeMethods } = grants(input, problems);
	const paths = accountWidePaths(input["accountWidePaths"], problems);
	const hint = text(input["hint"], "hint", problems, { max: 500 });
	const smokeRequest = smoke(input["smoke"], hosts ?? [], problems);
	const parsedCost = cost(input["cost"], problems);
	const parsedRate = rate(input["rate"], problems);
	const example = text(input["example"], "example", problems, { max: 200 });
	const parsedVerified = verified(input["verified"], problems);
	const tags = tagList(input["tags"], problems);
	if (problems.length > 0 || typeof id !== "string" || name === void 0 || docs === void 0 || !hosts && hostSetting === void 0 || !parsedAuth) return {
		ok: false,
		problems
	};
	return {
		ok: true,
		id,
		capability: {
			mode: "api_key",
			label: name,
			auth: parsedAuth,
			docs,
			hosts: hosts ?? [],
			...hostSetting === void 0 ? {} : { hostSetting },
			...data === void 0 ? {} : { data },
			access: access ?? ["read"],
			readMethods: readMethods ?? ["GET", "HEAD"],
			accountWidePaths: paths ?? [],
			...description === void 0 ? {} : { description },
			...api === void 0 ? {} : { api },
			...secrets === void 0 ? {} : { secrets },
			...writeMethods === void 0 ? {} : { writeMethods },
			...hint === void 0 ? {} : { hint },
			...smokeRequest === void 0 ? {} : { smoke: smokeRequest },
			...parsedCost === void 0 ? {} : { cost: parsedCost },
			...parsedRate === void 0 ? {} : { rate: parsedRate },
			...example === void 0 ? {} : { example },
			...parsedVerified === void 0 ? {} : { verified: parsedVerified },
			...tags === void 0 ? {} : { tags }
		}
	};
}
/**
* The `ai` half of `parseProviderSpec`: an OpenAI-compatible model
* provider. `baseUrl` is where the app's path is joined (`https://api.groq.com/openai`:
* the origin, and a base path the proxy keeps in front of every route);
* `auth` places the key as an API-key spec does; `models` lists what the
* provider serves (1 to 100; the proxy refuses any other) with
* `defaultModel` the one the Gateway's default route fills in and
* `embeddingsModel` the one for `/api/ai/default/v1/embeddings`; `routes`
* are the inference paths apps may POST to (default chat, and embeddings
* with an embeddings model), `chatRoute` and `embeddingsRoute` which of
* them the default route maps onto. Chat answers are never stored
* (`store: false` on the chat route). `cost.responseField` is where the
* answer carries the call's price, read by the usage tap as OpenRouter's
* `usage.cost` is.
*/
function parseAiSpec(input, problems, common) {
	for (const field of NOT_AI_FIELDS) if (input[field] !== void 0) problems.push({
		path: field,
		message: "not a field of an ai spec"
	});
	const base = httpsUrl(input["baseUrl"], "baseUrl", problems);
	let origin;
	let basePath;
	if (input["baseUrl"] === void 0) problems.push({
		path: "baseUrl",
		message: "required: the https URL the app's paths are joined onto (https://api.groq.com/openai)"
	});
	else if (base !== void 0) {
		const url = new URL(base);
		if (url.search || url.hash || url.username || url.password || url.port) problems.push({
			path: "baseUrl",
			message: "must be an https URL with no query, fragment, credentials or port"
		});
		else if (!PROVIDER_HOST.test(url.hostname)) problems.push({
			path: "baseUrl",
			message: "must name a public host with a dot (api.groq.com)"
		});
		else {
			origin = url.origin;
			const path = url.pathname.replace(/\/+$/, "");
			if (path && !AI_ROUTE.test(path)) problems.push({
				path: "baseUrl",
				message: "its path must be segments of lowercase letters, digits, _ and -"
			});
			else if (path) basePath = path;
		}
	}
	const parsedAuth = auth(input["auth"], problems);
	if (input["auth"] === void 0) problems.push({
		path: "auth",
		message: "required"
	});
	const secrets = secretDetails(input["secrets"], parsedAuth ? authSettingNames(parsedAuth) : [], problems);
	const models = stringList(input["models"], "models", problems, {
		max: MAX_MODELS,
		each: (model, at) => {
			if (!MODEL_NAME.test(model)) problems.push({
				path: at,
				message: "must be a model name (gpt-6-luna, meta-llama/llama-4)"
			});
		}
	});
	if (input["models"] === void 0 || models && models.length === 0) problems.push({
		path: "models",
		message: "required: the models the provider serves, at least one"
	});
	const defaultModel = text(input["defaultModel"], "defaultModel", problems, { max: 200 });
	if (input["defaultModel"] === void 0) problems.push({
		path: "defaultModel",
		message: "required: the chat model the Gateway fills in when an app names none; one of models"
	});
	else if (defaultModel !== void 0 && models && !models.includes(defaultModel)) problems.push({
		path: "defaultModel",
		message: "must be one of models"
	});
	const embeddingsModel = text(input["embeddingsModel"], "embeddingsModel", problems, { max: 200 });
	if (embeddingsModel !== void 0 && models && !models.includes(embeddingsModel)) problems.push({
		path: "embeddingsModel",
		message: "must be one of models"
	});
	const routeList = (value, path) => stringList(value, path, problems, {
		max: MAX_AI_ROUTES,
		each: (route, at) => {
			if (!AI_ROUTE.test(route)) problems.push({
				path: at,
				message: "must be a path of lowercase segments starting with / (/v1/chat/completions)"
			});
		}
	});
	const chatRoute = text(input["chatRoute"], "chatRoute", problems, { max: 200 }) ?? "/v1/chat/completions";
	const embeddingsRoute = text(input["embeddingsRoute"], "embeddingsRoute", problems, { max: 200 }) ?? "/v1/embeddings";
	for (const [field, route] of [["chatRoute", chatRoute], ["embeddingsRoute", embeddingsRoute]]) if (!AI_ROUTE.test(route)) problems.push({
		path: field,
		message: "must be a path of lowercase segments starting with /"
	});
	const routes = routeList(input["routes"], "routes") ?? [chatRoute, ...embeddingsModel !== void 0 ? [embeddingsRoute] : []];
	if (routes.length === 0) problems.push({
		path: "routes",
		message: "must list a route"
	});
	if (!routes.includes(chatRoute)) problems.push({
		path: "chatRoute",
		message: "must be one of routes"
	});
	if (embeddingsModel !== void 0 && !routes.includes(embeddingsRoute)) problems.push({
		path: "embeddingsRoute",
		message: "must be one of routes"
	});
	const hint = text(input["hint"], "hint", problems, { max: 500 });
	const smokeRequest = smoke(input["smoke"], origin ? [new URL(origin).host] : [], problems);
	const parsedCost = cost(input["cost"], problems);
	const parsedRate = rate(input["rate"], problems);
	const example = text(input["example"], "example", problems, { max: 200 });
	const parsedVerified = verified(input["verified"], problems);
	const tags = tagList(input["tags"], problems);
	const { id, name, description, docs, api } = common;
	if (problems.length > 0 || typeof id !== "string" || name === void 0 || docs === void 0 || origin === void 0 || !parsedAuth || !models || defaultModel === void 0) return {
		ok: false,
		problems
	};
	return {
		ok: true,
		id,
		capability: {
			mode: "ai",
			label: name,
			auth: parsedAuth,
			docs,
			origin,
			...basePath === void 0 ? {} : { basePath },
			inferenceRoutes: routes,
			unstoredRoutes: [chatRoute],
			shape: "openai",
			chat: {
				path: chatRoute,
				seedModel: defaultModel
			},
			...embeddingsModel === void 0 ? {} : { embeddings: {
				path: embeddingsRoute,
				seedModel: embeddingsModel
			} },
			models,
			...description === void 0 ? {} : { description },
			...api === void 0 ? {} : { api },
			...secrets === void 0 ? {} : { secrets },
			...hint === void 0 ? {} : { hint },
			...smokeRequest === void 0 ? {} : { smoke: smokeRequest },
			...parsedCost === void 0 ? {} : { cost: parsedCost },
			...parsedRate === void 0 ? {} : { rate: parsedRate },
			...example === void 0 ? {} : { example },
			...parsedVerified === void 0 ? {} : { verified: parsedVerified },
			...tags === void 0 ? {} : { tags }
		}
	};
}
/** The problems as one line: `auth.secret: must name a Gateway setting; hosts.0: \u2026`. */
function describeSpecProblems(problems) {
	return problems.map((problem) => `${problem.path}: ${problem.message}`).join("; ");
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/devProviders.js
/**
* A provider registered on a gateway, in local development
* (docs/design/2026-10-provider-registry.md, section 4). There is no
* gateway to ask in `everyapp dev`, so the spec comes from the app's
* directory: `everyapp provider add` (run in an app directory) and
* `everyapp provider show <id> --save` write it to
* `.everyapp/providers/<id>.json`, `everyAppWorker()` reads every such
* file when it builds the dev Worker and hands them over as one text
* binding, {@link DEV_PROVIDERS_ENV}, and `integrationFetch()`'s local
* fallback resolves an id outside the catalog from it, with the
* developer's own key from `.dev.vars` under the spec's setting names.
*
* The binding is JSON: `[{ "file": ".everyapp/providers/stripe.json",
* "spec": <the file's JSON, or its text when it isn't JSON> }]`. Each spec
* is parsed here, with the same parser `provider add` uses; one that
* doesn't parse is ignored until an app asks for its id, which then gets
* a ConfigurationError naming the file.
*/
/** The dev Worker's binding holding the specs (a copy is in ../cloudflare/worker.ts, kept in step by a test). */
var DEV_PROVIDERS_ENV = "EVERYAPP_DEV_PROVIDERS";
/** Where the specs live in an app, relative to its directory. */
var DEV_PROVIDERS_DIR = ".everyapp/providers";
/** The file `everyapp dev` reads a registered provider's spec from. */
function devProviderFile(id) {
	return `${DEV_PROVIDERS_DIR}/${id}.json`;
}
function isRecord$2(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
/** The files the binding carries; none when it is absent or not of its shape. */
function devProviderFiles(value) {
	if (typeof value !== "string") return [];
	let parsed;
	try {
		parsed = JSON.parse(value);
	} catch {
		return [];
	}
	if (!Array.isArray(parsed)) return [];
	return parsed.flatMap((entry) => isRecord$2(entry) && typeof entry["file"] === "string" ? [{
		file: entry["file"],
		spec: entry["spec"]
	}] : []);
}
/**
* `id`'s spec from the dev Worker's {@link DEV_PROVIDERS_ENV}: a file whose
* spec says that id, or whose name is `<id>.json`. A file that matches but
* doesn't parse (or names another id) is the problem; no file is too,
* naming the command that writes one.
*/
function resolveDevProvider(values, id) {
	const matching = devProviderFiles(values[DEV_PROVIDERS_ENV]).filter((entry) => isRecord$2(entry.spec) && entry.spec["id"] === id || entry.file.split("/").at(-1) === `${id}.json`);
	let problem = null;
	for (const entry of matching) {
		const parsed = parseProviderSpec(typeof entry.spec === "string" ? null : entry.spec);
		if (!parsed.ok) {
			problem ??= typeof entry.spec === "string" ? `${entry.file} isn't JSON` : `${entry.file} isn't a provider spec: ${describeSpecProblems(parsed.problems)}`;
			continue;
		}
		if (parsed.id !== id) {
			problem ??= `${entry.file} is ${parsed.id}'s spec, not ${id}'s`;
			continue;
		}
		return {
			found: true,
			capability: parsed.capability,
			file: entry.file
		};
	}
	return {
		found: false,
		problem: problem ? `${problem}. Write it again with everyapp provider show ${id} --save in the app's directory, then start everyapp dev again.` : `"${id}" isn't in the built-in provider catalog, and no ${devProviderFile(id)} describes it. A provider registered on the gateway (everyapp provider add) is reached through the EVERY_APP_GATEWAY binding; for everyapp dev, run everyapp provider show ${id} --save in the app's directory, then start everyapp dev again.`
	};
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/aiProviders.js
/**
* The gateway's AI providers as the SDK's local-dev fallback reaches them:
* with no gateway binding, a developer's own key, under the name of the
* gateway secret that holds it, goes to the provider directly. Deployed
* apps always go through the gateway, which holds the real keys. The
* providers themselves are the catalog's `ai` entries (./capabilities.ts);
* this derives the fallback's view of each, and holds the one response
* rewrite the gateway has (Workers AI's numeric tokens).
*/
/** The fallback's view of one `ai` catalog entry. */
function devAiProviderSpec(capability) {
	const { basePath, normalize } = capability;
	return {
		origin: capability.origin,
		...capability.chat ? { chat: capability.chat } : {},
		...capability.embeddings ? { embeddings: capability.embeddings } : {},
		keyEnv: capability.auth.secret,
		auth: capability.auth,
		docs: capability.docs,
		...capability.setup === void 0 ? {} : { setup: capability.setup },
		...capability.alsoNeeds === void 0 ? {} : { alsoNeeds: capability.alsoNeeds },
		...basePath === void 0 ? {} : { basePath: (settings) => fillBasePath(basePath, settings) ?? "" },
		...normalize === "workers-ai" ? { normalizeResponse: normalizeWorkersAiResponse } : {}
	};
}
Object.fromEntries(CAPABILITY_IDS.flatMap((id) => {
	const capability = CAPABILITIES[id];
	return capability.mode === "ai" && !("kind" in capability && capability.kind === "proxy") ? [[id, devAiProviderSpec(capability)]] : [];
}));
/**
* An `ai` entry's `basePath` with each `{SETTING}` filled from the
* settings, URL-encoded (`/client/v4/accounts/{CLOUDFLARE_ACCOUNT_ID}/ai`
* with `acc 1` makes `/client/v4/accounts/acc%201/ai`), or null while a
* named setting is unset or blank.
*/
function fillBasePath(template, settings) {
	let missing = false;
	const filled = template.replace(/\{([A-Z][A-Z0-9_]*)\}/g, (_, name) => {
		const value = settings[name];
		if (typeof value !== "string" || !value.trim()) {
			missing = true;
			return "";
		}
		return encodeURIComponent(value.trim());
	});
	return missing ? null : filled;
}
var WORKERS_AI_NORMALIZED_ROUTES = /* @__PURE__ */ new Set(["/v1/chat/completions"]);
/** Text fields of a chat completion choice that OpenAI clients require as strings. */
var TEXT_FIELDS = [
	"content",
	"reasoning_content",
	"reasoning"
];
var NUMERIC_TEXT_FIELD = /"(?:content|reasoning_content|reasoning)"\s*:\s*-?\d/;
/**
* Workers AI's OpenAI-compatible chat completions on the vLLM-backed models
* (Meta's Llama among them) send a token made only of digits as a JSON
* number (`"delta":{"content":18}`), which OpenAI clients refuse:
* `@ai-sdk/openai-compatible` drops the token and reports an error part.
* This turns such numbers back into strings, in `choices[].delta` (streams)
* and `choices[].message` (whole JSON bodies); every other event or body
* passes through byte for byte. Remove it once Cloudflare sends strings.
*/
function normalizeWorkersAiResponse(path, response) {
	if (!response.body || !WORKERS_AI_NORMALIZED_ROUTES.has(path)) return response;
	const contentType = (response.headers.get("content-type") ?? "").toLowerCase();
	const transform = contentType.startsWith("text/event-stream") ? normalizeSseLines() : contentType.startsWith("application/json") ? normalizeJsonBody() : null;
	if (!transform) return response;
	const headers = new Headers(response.headers);
	headers.delete("content-length");
	return new Response(response.body.pipeThrough(transform), {
		status: response.status,
		statusText: response.statusText,
		headers
	});
}
/** Stringify numeric text fields of every choice in a chat completion (chunk). */
function stringifyNumericText(payload) {
	if (!isRecord$1(payload) || !Array.isArray(payload["choices"])) return false;
	let changed = false;
	for (const choice of payload["choices"]) {
		if (!isRecord$1(choice)) continue;
		for (const part of [choice["delta"], choice["message"]]) {
			if (!isRecord$1(part)) continue;
			for (const field of TEXT_FIELDS) {
				const value = part[field];
				if (typeof value === "number") {
					part[field] = String(value);
					changed = true;
				}
			}
		}
	}
	return changed;
}
/** `json` with its numeric text fields as strings, or null when it has none. */
function normalizedJson(json) {
	if (!NUMERIC_TEXT_FIELD.test(json)) return null;
	let payload;
	try {
		payload = JSON.parse(json);
	} catch {
		return null;
	}
	return stringifyNumericText(payload) ? JSON.stringify(payload) : null;
}
/**
* An SSE stream, line by line: a `data:` line whose JSON has a numeric text
* field is rewritten, every other line (and its line ending) is kept.
*/
function normalizeSseLines() {
	const decoder = new TextDecoder();
	const encoder = new TextEncoder();
	let pending = "";
	const normalizeLine = (line) => {
		const match = /^(data:[ ]?)(.*?)(\r?)$/s.exec(line);
		if (!match) return line;
		const rewritten = normalizedJson(match[2]);
		return rewritten === null ? line : `${match[1]}${rewritten}${match[3]}`;
	};
	return new TransformStream({
		transform(chunk, controller) {
			pending += decoder.decode(chunk, { stream: true });
			const end = pending.lastIndexOf("\n");
			if (end === -1) return;
			const complete = pending.slice(0, end + 1);
			pending = pending.slice(end + 1);
			controller.enqueue(encoder.encode(complete.split("\n").map(normalizeLine).join("\n")));
		},
		flush(controller) {
			pending += decoder.decode();
			if (pending) controller.enqueue(encoder.encode(normalizeLine(pending)));
		}
	});
}
/** A whole JSON body: rewritten when it has a numeric text field, else kept as sent. */
function normalizeJsonBody() {
	const chunks = [];
	return new TransformStream({
		transform(chunk) {
			chunks.push(chunk);
		},
		flush(controller) {
			const decoder = new TextDecoder();
			const rewritten = normalizedJson(chunks.map((chunk) => decoder.decode(chunk, { stream: true })).join("") + decoder.decode());
			if (rewritten !== null) {
				controller.enqueue(new TextEncoder().encode(rewritten));
				return;
			}
			for (const chunk of chunks) controller.enqueue(chunk);
		}
	});
}
function isRecord$1(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/signInProviders.js
/**
* The sign-in providers a Gateway can offer beside passwords ("Continue
* with Google"), as data: what each one is called, the Worker secrets it
* reads, where the OAuth app is made, the scopes asked for and which claim
* becomes the email. One catalog serves the Gateway (which providers are
* on, the sign-in page's buttons, Manage workspace \u2192 Sign-in), the CLI
* (`everyapp signin add|list|show|remove`, `secret set`), the manifest
* validator (an app's own secret can never take one of these names) and
* the docs' drift tests.
*
* Naming rule, agreed with the provider registry's conventions
* (docs/design/2026-10-provider-registry.md, section 6): a sign-in
* provider's settings are `<ID>_SIGNIN_<FIELD>`, with FIELD one of
* CLIENT_ID, CLIENT_SECRET, ISSUER, LABEL or TENANT. The `_SIGNIN_` infix is
* what keeps the family apart from the API providers' `<ID>_API_KEY`,
* `<ID>_CLIENT_ID` (the OAuth clients the Gateway holds for apps) and the
* MCP apps' `<ID>_MCP_TOKEN`: `GOOGLE_SIGNIN_CLIENT_ID` is the sign-in
* provider's, `GOOGLE_WORKSPACE_CLIENT_ID` the OAuth client apps use, and
* a registered provider row or an app manifest can never claim a name in
* the family (isSignInSettingName).
*
* The settings are Worker secrets, set under the Cloudflare login (`everyapp
* signin add`, or `secret set`), never from the admin UI or an agent
* connection: a stolen session can't add a way in.
*/
var SIGN_IN_PROVIDER_IDS = [
	"google",
	"microsoft",
	"github",
	"apple",
	"cloudflare",
	"oidc"
];
function settingName(id, field) {
	return `${id.toUpperCase()}_SIGNIN_${field}`;
}
function clientPair(id, what) {
	return [{
		name: settingName(id, "CLIENT_ID"),
		role: "clientId",
		required: true,
		plain: true,
		what: what.clientId
	}, {
		name: settingName(id, "CLIENT_SECRET"),
		role: "clientSecret",
		required: true,
		plain: false,
		what: what.clientSecret
	}];
}
var IDENTITY_SCOPES = [
	"openid",
	"email",
	"profile"
];
var SIGN_IN_PROVIDERS = {
	google: {
		id: "google",
		label: "Google",
		console: "https://console.cloud.google.com/apis/credentials",
		appNoun: "OAuth client ID (Web application)",
		settings: clientPair("google", {
			clientId: "The OAuth client's Client ID (ends in .apps.googleusercontent.com)",
			clientSecret: "The OAuth client's Client secret"
		}),
		scopes: IDENTITY_SCOPES,
		emailClaim: "the ID token's `email`, counted as verified only when its `email_verified` is true (every Google account's own address is)",
		setup: "setup/signin-google.md",
		notes: ["An OAuth consent screen still in Testing only signs in the test users listed on it; publish it for everyone else."]
	},
	microsoft: {
		id: "microsoft",
		label: "Microsoft",
		console: "https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade",
		appNoun: "App registration",
		settings: [...clientPair("microsoft", {
			clientId: "The app registration's Application (client) ID",
			clientSecret: "A client secret from Certificates & secrets (it expires; 24 months at most)"
		}), {
			name: settingName("microsoft", "TENANT"),
			role: "tenant",
			required: false,
			plain: true,
			what: "The Directory (tenant) ID to pin sign-in to your own directory; unset means any Microsoft account (common), which then needs the xms_edov claim"
		}],
		scopes: IDENTITY_SCOPES,
		emailClaim: "the ID token's `email`, counted as verified when MICROSOFT_SIGNIN_TENANT pins your own directory, or the token carries `xms_edov: true` (the optional claim that says the domain's owner verified it), `email_verified: true`, a matching `verified_primary_email`, or comes from a personal Microsoft account",
		setup: "setup/signin-microsoft.md",
		notes: ["Without MICROSOFT_SIGNIN_TENANT, add the optional claims `email` and `xms_edov` under Token configuration, or every sign-in is refused as unverified: any tenant's admin can put any address on their users."]
	},
	github: {
		id: "github",
		label: "GitHub",
		console: "https://github.com/settings/developers",
		appNoun: "OAuth App",
		settings: clientPair("github", {
			clientId: "The OAuth App's Client ID",
			clientSecret: "A client secret generated on the OAuth App"
		}),
		scopes: ["read:user", "user:email"],
		emailClaim: "the primary address from GitHub's emails API, counted as verified only when GitHub marks it verified",
		setup: "setup/signin-github.md",
		notes: ["GitHub Apps are something else: make an OAuth App (Settings \u2192 Developer settings \u2192 OAuth Apps)."]
	},
	apple: {
		id: "apple",
		label: "Apple",
		console: "https://developer.apple.com/account/resources/identifiers/list/serviceId",
		appNoun: "Services ID",
		settings: clientPair("apple", {
			clientId: "The Services ID's identifier (com.example.gateway)",
			clientSecret: "The client secret JWT you generate from your Sign in with Apple key (ES256; valid six months at most, then generate it again)"
		}),
		scopes: ["email", "name"],
		emailClaim: "the ID token's `email`, counted as verified only when its `email_verified` is true; someone who chose Hide My Email arrives as a @privaterelay.appleid.com address, which no invitation names",
		setup: "setup/signin-apple.md",
		notes: ["Apple returns to the Gateway with a POST; behind the outer ring, `everyapp access on` leaves /api/auth/callback/apple public (it only redirects to the same URL as a GET, which Access then checks).", "The client secret is a JWT that expires within six months: generate a new one before then or sign-in stops."]
	},
	cloudflare: {
		id: "cloudflare",
		label: "Cloudflare",
		console: "https://dash.cloudflare.com/?to=/:account/oauth-clients",
		appNoun: "OAuth client (Manage Account \u2192 OAuth clients)",
		settings: clientPair("cloudflare", {
			clientId: "The OAuth client's Client ID",
			clientSecret: "The OAuth client's Client secret"
		}),
		scopes: ["user-details.read"],
		emailClaim: "the Cloudflare API's /user `email` (the account's sign-in address). Cloudflare reports no verified flag, so the email counts as verified on the strength of the client being private: only members of your Cloudflare account can authorize it, and they got in by accepting an invitation sent to that address",
		setup: "setup/signin-cloudflare.md",
		notes: ["Keep the client private (the default): a public client lets any Cloudflare user sign in, and Cloudflare says nothing about whether their address is verified. Making a client public is permanent.", "The Cloudflare account's members sign in; for everyone else use Cloudflare Access's one-time PIN (`everyapp access on`) or another provider."]
	},
	oidc: {
		id: "oidc",
		label: "SSO",
		console: "your identity provider's admin console",
		appNoun: "OpenID Connect client (web application, authorization code)",
		settings: [
			{
				name: settingName("oidc", "ISSUER"),
				role: "issuer",
				required: true,
				plain: true,
				what: "The issuer URL (https://\u2026), which serves /.well-known/openid-configuration"
			},
			...clientPair("oidc", {
				clientId: "The client ID",
				clientSecret: "The client secret"
			}),
			{
				name: settingName("oidc", "LABEL"),
				role: "label",
				required: false,
				plain: true,
				what: "The button text after \"Continue with\" (default \"SSO\")"
			}
		],
		scopes: IDENTITY_SCOPES,
		emailClaim: "the ID token's `email` (else the userinfo endpoint's), counted as verified only when `email_verified` is true",
		setup: "setup/signin-oidc.md",
		notes: ["Cloudflare Access has its own settings (CLOUDFLARE_ACCESS_OIDC_*, `everyapp access`): use those for Access, this for Okta, Keycloak, Auth0, Authentik, Google Workspace as an OIDC issuer and the like. For Microsoft Entra ID use the `microsoft` provider: Entra's ID tokens carry no `email_verified`, so through this entry every sign-in would be refused as unverified.", "ID tokens must be signed with RS256 (every major provider's default)."]
	}
};
/** The catalog in listing order. */
var SIGN_IN_PROVIDER_LIST = SIGN_IN_PROVIDER_IDS.map((id) => SIGN_IN_PROVIDERS[id]);
/**
* Every setting a sign-in provider reads, in catalog order: what `everyapp
* secret set` accepts for the Gateway, and what the Gateway's dev config
* declares.
*/
var SIGN_IN_GATEWAY_SETTINGS = SIGN_IN_PROVIDER_LIST.flatMap((provider) => provider.settings.map((setting) => setting.name));
/** The plain (non-credential) ones among them: ids, the issuer, the label, the tenant. */
var PLAIN_SIGN_IN_SETTINGS = SIGN_IN_PROVIDER_LIST.flatMap((provider) => provider.settings.filter((setting) => setting.plain).map((setting) => setting.name));
/**
* The family: any name of the shape `<ID>_SIGNIN_<FIELD>`. Reserved for the
* catalog above, whether or not an entry reads the name today, so no
* registered provider row and no app manifest can ever take one.
*/
var SIGN_IN_SETTING_PATTERN = /^[A-Z][A-Z0-9_]*_SIGNIN_(CLIENT_ID|CLIENT_SECRET|ISSUER|LABEL|TENANT)$/;
function isSignInSettingName(name) {
	return SIGN_IN_SETTING_PATTERN.test(name);
}
var INSTALL_OWNED = /* @__PURE__ */ new Set([
	"GATEWAY_URL",
	"APP_BASE_DOMAIN",
	"BETTER_AUTH_SECRET",
	"JWT_PRIVATE_KEY",
	"JWT_PUBLIC_KEY",
	"GATEWAY_DEPLOYMENT_MODE",
	"CLOUDFLARE_ACCOUNT_ID",
	"THIRD_PARTY_DEPLOYS"
]);
function isInstallOwnedGatewaySetting(name) {
	return INSTALL_OWNED.has(name);
}
/**
* The settings the catalog's providers read (the AI providers' keys, the
* API-key providers' keys and hosts, the OAuth clients), in catalog order, the install's own left out: what `everyapp
* secret set` accepts because a provider reads it. A gateway's registered
* rows add theirs at run time (providerRegistry.settingNames()).
*/
var PROVIDER_GATEWAY_SETTINGS = [...new Set(CAPABILITY_IDS.flatMap((id) => {
	const capability = CAPABILITIES[id];
	return capability.mode === "service" ? [] : capabilitySettings(capability);
}))].filter((name) => !INSTALL_OWNED.has(name));
/** The Gateway's own optional settings `everyapp secret set` changes: nothing a provider reads. */
var GATEWAY_OWN_SETTINGS = [
	"EMAIL_REST_API_TOKEN",
	"RESEND_API_KEY",
	"EMAIL_PROVIDER",
	"EMAIL_FROM",
	"EMAIL_FROM_NAME",
	"MCP_OAUTH_ENABLED",
	"MCP_DCR_ENABLED",
	"MCP_ALLOWED_ORIGINS",
	"MCP_AUDIT_RETENTION_DAYS",
	"CLOUDFLARE_ACCESS_OIDC_ISSUER",
	"CLOUDFLARE_ACCESS_OIDC_CLIENT_ID",
	"CLOUDFLARE_ACCESS_OIDC_CLIENT_SECRET",
	"CLOUDFLARE_ACCESS_OIDC_LABEL",
	"CLOUDFLARE_ACCESS_TEAM_DOMAIN",
	"CLOUDFLARE_ACCESS_AUD",
	"CLOUDFLARE_ACCESS_APPS_AUD",
	"EMAIL_PASSWORD_SIGN_IN",
	"HOSTED_OPEN_SIGNUP",
	"CF_DEPLOY_TOKEN",
	"BROWSER_APP_INSTALLS",
	"DISPATCH_NAMESPACE",
	"THIRD_PARTY_DOMAIN",
	"EVENTS_ALLOW_PRIVATE_TARGETS"
];
/**
* The Gateway's optional settings `everyapp secret set` changes: every
* setting a catalog provider reads, the Gateway's own, then the sign-in
* providers' (`<ID>_SIGNIN_<FIELD>`, ./signInProviders.ts).
*/
var SETTABLE_GATEWAY_SETTINGS = [
	...PROVIDER_GATEWAY_SETTINGS,
	...GATEWAY_OWN_SETTINGS,
	...SIGN_IN_GATEWAY_SETTINGS
];
var SETTABLE = new Set(SETTABLE_GATEWAY_SETTINGS);
/**
* Whether `everyapp secret set <name>` changes the Gateway because the
* catalog or the Gateway itself reads it. A registered provider row's
* settings (a remote MCP app's `<APPID>_MCP_TOKEN` among them) are the
* registry's (`providerRegistry().settingNames()`), checked at run time.
*/
function isSettableGatewaySetting(name) {
	return SETTABLE.has(name);
}
[...PLAIN_SIGN_IN_SETTINGS];
/** Gateway settings for local testing only, set in the gateway's `.dev.vars`, never deployed. */
var DEV_ONLY_GATEWAY_SETTINGS = ["MCP_ACCESS_TOKEN_TTL", "DATAFORSEO_SANDBOX"];
function isDevOnlyGatewaySetting(name) {
	return DEV_ONLY_GATEWAY_SETTINGS.includes(name);
}
/**
* Names an app's own secret can't take: the deploy sets GATEWAY_URL on
* every Worker and builds in the identity settings, the gateway binding
* and the platform's own namespaces. Checked without regard to case. The
* SDK's `everyAppWorker()` keeps the same rule as a regex (its config
* module can't import this one); a test keeps them in step.
*/
var RESERVED_APP_SECRET_NAMES = /* @__PURE__ */ new Set(["GATEWAY_URL", "CF_VERSION_METADATA"]);
var RESERVED_APP_SECRET_PREFIXES = [
	"EVERYAPP_",
	"EVERY_APP_",
	"APP__"
];
function isReservedAppSecretName(name) {
	const upper = name.toUpperCase();
	return RESERVED_APP_SECRET_NAMES.has(upper) || RESERVED_APP_SECRET_PREFIXES.some((prefix) => upper.startsWith(prefix));
}
Object.keys({ dataforseo: {
	id: "dataforseo",
	name: "DataForSEO",
	description: "SEO data for your agent: keyword metrics and suggestions, live Google results, domain rankings, competitors and backlinks, through the Gateway's DataForSEO key.",
	capability: "dataforseo",
	why: "Serves DataForSEO's keyword, search-result, domain and backlink data to members' AI clients.",
	example: "find keyword ideas for a page about running shoes"
} }).sort();
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/events.js
/**
* The event bus's shared contract (docs/design/2026-10-events-out.md): the
* catalogue of types the gateway emits, the pattern a subscription matches
* them by, the shape and size an app's own event may have, the headers a
* delivery carries, and every limit, in one place the gateway, the CLI
* (`everyapp events`), the SDK (`emit`) and the docs drift test read.
*
* The gateway builds each type's `data` and summary in
* apps/every-app-gateway/src/server/events/catalogue.ts; this module knows
* the names, versions and one-line descriptions only.
*/
var entry = (group, type, description, version = 1) => ({
	type,
	version,
	description,
	group
});
/**
* Every type the gateway itself emits, in the order the docs list them.
* An app's own events (`app.<id>.<name>`, {@link appEventType}) are a
* pattern, not entries here. Reserved entries are emitted by sibling
* features (remote MCP apps, the provider registry) through the same bus.
*/
var EVENT_TYPES = [
	entry("member", "member.invited", "Someone was invited to the workspace"),
	entry("member", "member.joined", "Someone joined the workspace"),
	entry("member", "member.role_changed", "A member's role changed"),
	entry("member", "member.deactivated", "A member was deactivated"),
	entry("member", "member.reactivated", "A member was reactivated"),
	entry("member", "member.removed", "A member was removed"),
	entry("member", "member.password_reset", "A member reset their password"),
	entry("member", "member.invitation_cancelled", "A pending invitation was cancelled"),
	entry("organization", "organization.renamed", "The workspace was renamed"),
	entry("organization", "organization.linked_dev_changed", "Linked dev (everyapp dev against this Gateway) was turned on or off"),
	entry("app", "app.installed", "An app was installed on the Gateway"),
	entry("app", "app.updated", "An app was redeployed"),
	entry("app", "app.live", "An app went live on the Gateway"),
	entry("app", "app.removed", "An app was removed from the Gateway"),
	entry("app", "app.needs_setup", "An app needs a setting before it opens"),
	entry("app", "app.ready", "An app has every setting it needs"),
	entry("app", "app.paused_cap", "An app is paused: its monthly cap is reached"),
	entry("app", "app.tools_changed", "An app's AI tools changed"),
	entry("app", "app.renamed", "An app's name or description changed"),
	entry("app", "app.settings_changed", "An app's settings were set or unset (names only)"),
	entry("app", "app.access_changed", "Who can open an app changed"),
	entry("app", "app.email_changed", "An app's email senders or inbound changed"),
	entry("cap", "cap.warning", "An app is at 80% of its monthly cap"),
	entry("cap", "cap.reached", "An app reached its monthly cap"),
	entry("cap", "cap.raised", "An app's monthly cap, or the workspace default, was raised or removed"),
	entry("cap", "cap.changed", "An app's monthly cap, or the workspace default, was set or lowered"),
	entry("group", "group.created", "A group was created"),
	entry("group", "group.updated", "A group was renamed or described"),
	entry("group", "group.removed", "A group was removed"),
	entry("group", "group.members_changed", "A group's members changed"),
	entry("group", "group.apps_changed", "The apps a group opens changed"),
	entry("tool", "tool.blocked", "An AI client's tool call was blocked"),
	entry("tool", "tool.error", "An AI client's tool call failed"),
	entry("connection", "connection.created", "An AI app was connected"),
	entry("connection", "connection.revoked", "An AI app connection was revoked"),
	entry("connection", "connection.used", "Linked dev used the Gateway's services, or an app used a member's OAuth connection (first call of the day)"),
	entry("token", "token.created", "A personal access token was created"),
	entry("token", "token.revoked", "A personal access token was revoked"),
	entry("access", "access.changed", "Cloudflare Access was turned on or off"),
	entry("signin_provider", "signin_provider.added", "A sign-in provider (Continue with Google, \u2026) was turned on"),
	entry("signin_provider", "signin_provider.removed", "A sign-in provider was turned off"),
	entry("mcp_app", "mcp_app.added", "An MCP app was added"),
	entry("mcp_app", "mcp_app.removed", "An MCP app was removed"),
	entry("mcp_app", "mcp_app.enabled", "An MCP app is being served again"),
	entry("mcp_app", "mcp_app.disabled", "An MCP app stopped being served"),
	entry("mcp_app", "mcp_app.updated", "An MCP app's risk default, name or description changed"),
	entry("mcp_app", "mcp_app.tool_changed", "One tool of an MCP app was overridden: its risk, or on/off"),
	entry("provider", "provider.added", "A provider was registered"),
	entry("provider", "provider.removed", "A provider was removed"),
	entry("provider", "provider.updated", "A provider's spec or OAuth client was replaced"),
	entry("provider", "provider.connected", "Someone connected an account at an OAuth provider in an app"),
	entry("provider", "provider.disconnected", "An OAuth provider account was disconnected"),
	entry("provider", "provider.connection_expired", "An OAuth provider refused to refresh a connection; it needs reconnecting"),
	entry("subscription", "subscription.created", "An event subscription was added"),
	entry("subscription", "subscription.updated", "An event subscription was changed, paused or resumed"),
	entry("subscription", "subscription.removed", "An event subscription was removed"),
	entry("subscription", "subscription.redelivered", "A delivery was queued again by hand"),
	entry("ai", "ai.default_changed", "The default model provider changed"),
	entry("ai", "ai.model_changed", "A provider's default model changed"),
	entry("ping", "ping", "A test event, sent to one subscription on request")
];
new Map(EVENT_TYPES.map((info) => [info.type, info]));
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/providerRegistry.js
/**
* The provider registry: the built-in catalog (./capabilities.ts) and the
* providers one gateway registered as rows (`everyapp provider add`,
* `everyapp_provider_add`), resolved as one lookup
* (docs/design/2026-10-provider-registry.md). The catalog comes first and
* a row can never shadow it. Every row is parsed and checked again each
* time a registry is built, so a row written by hand into D1, or one that
* stopped passing the rules when a later catalog took its name, is left
* out and named in `rejected` rather than served.
*
* The rules a row must pass (the register's `registry.*` invariants):
*
*  - `registry.builtin-precedence`: not a catalog id, and never `everyapp`;
*  - `registry.row-secret-is-its-own`: each Gateway setting it names starts
*    with its own id (`STRIPE_` for `stripe`) and is nobody else's: no
*    install-owned, dev-only or reserved name, no settable Gateway setting
*    (the catalog's keys and clients included), no other row's;
*  - `registry.row-hosts-public-https`: each host is a public DNS name (not
*    an IP literal, localhost, or a `.local`, `.internal` or `.arpa` name)
*    and not one the gateway serves itself (`refuseHost`, which knows the
*    gateway's own host and `APP_BASE_DOMAIN`).
*/
/**
* The part of a row a key is set for: its hosts, its host setting and its
* auth, as one canonical string (sorted keys, sorted hosts), so that
* replacing a row's hosts or auth changes the key and the value it held
* is no longer read until the operator sets it again. For an OAuth
* provider the client is bound to its authorize, token and revoke URLs,
* its API hosts, where the client goes on the token request, its client
* setting names, and its `resource` and `issuer` when it has them
* (`oauth.client-bound-to-endpoints`): an admin who re-points `tokenUrl`
* has to paste the secret again.
*/
function providerBindingKey(capability) {
	if (capability.mode === "ai") return JSON.stringify({
		kind: "ai",
		auth: sortedAuth(capability.auth),
		origin: capability.origin,
		basePath: capability.basePath ?? null
	});
	if (capability.mode === "oauth_client") return JSON.stringify({
		kind: "oauth2-user",
		authorizeUrl: capability.flow.authorizeUrl,
		tokenUrl: capability.flow.tokenUrl,
		revokeUrl: capability.flow.revokeUrl ?? null,
		inject: capability.flow.inject,
		clientId: capability.secrets.clientId,
		clientSecret: capability.secrets.clientSecret ?? null,
		hosts: [...capability.api].sort(),
		...capability.flow?.resource === void 0 ? {} : { resource: capability.flow.resource },
		...capability.flow?.issuer === void 0 ? {} : { issuer: capability.flow.issuer }
	});
	return JSON.stringify({
		auth: sortedAuth(capability.auth),
		hostSetting: capability.hostSetting ?? null,
		hosts: [...capability.hosts].sort()
	});
}
/** An auth block with its keys sorted, one level down too, for a canonical key. */
function sortedAuth(auth) {
	return Object.fromEntries(Object.entries(auth).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([field, value]) => [field, typeof value === "object" && value !== null ? Object.fromEntries(Object.entries(value).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)) : value]));
}
/** The reserved app id no provider may take. */
var RESERVED_IDS = /* @__PURE__ */ new Set(["everyapp"]);
var IPV4 = /^\d{1,3}(\.\d{1,3}){3}$/;
var LOCAL_SUFFIXES = [
	".localhost",
	".local",
	".internal",
	".arpa"
];
/** The prefix a provider's own Gateway settings carry: `stripe` \u2192 `STRIPE_`, `tiktok-business` \u2192 `TIKTOK_BUSINESS_`. */
function providerSettingPrefix(id) {
	return `${id.toUpperCase().replace(/-/g, "_")}_`;
}
/** Why `host` can't be a row's, by the pure rules alone; null when it can. */
function publicHostProblem(host) {
	if (IPV4.test(host)) return `${host} is an IP address, not a host name`;
	if (host === "localhost" || LOCAL_SUFFIXES.some((suffix) => host.endsWith(suffix))) return `${host} is not a public host`;
	return null;
}
/**
* Why a setting name can't be a row's: a name the Gateway, the catalog or
* another provider already reads, or one outside the row's own prefix.
* Null when the row may hold it.
*/
function rowSecretProblem(id, name, taken) {
	const prefix = providerSettingPrefix(id);
	if (!name.startsWith(prefix)) return `${name} doesn't start with ${prefix}: a provider's settings carry its own id`;
	if (isInstallOwnedGatewaySetting(name)) return `${name} is one of the Gateway's own keys`;
	if (isDevOnlyGatewaySetting(name)) return `${name} is a local-development setting`;
	if (isReservedAppSecretName(name)) return `${name} is a name everyapp sets itself`;
	if (isSignInSettingName(name)) return `${name} is a sign-in provider's setting name (every <ID>_SIGNIN_<FIELD> name is the Gateway's, set with \`everyapp signin add\`)`;
	if (isSettableGatewaySetting(name)) return `${name} is a Gateway setting another provider or the Gateway reads`;
	if (taken(name)) return `${name} is another registered provider's`;
	return null;
}
/**
* Check one parsed row against the catalog and the other rows. Pure: the
* CLI runs it before writing D1, the MCP tool before writing, and the
* gateway again on every read.
*/
function checkProviderRow(id, capability, context) {
	if (RESERVED_IDS.has(id) || CAPABILITY_IDS.includes(id)) return {
		id,
		code: "PROVIDER_BUILTIN",
		message: `${id} is a built-in provider; a registered one can't take its id`
	};
	for (const name of capabilitySettings(capability)) {
		const problem = rowSecretProblem(id, name, (each) => context.rowSettings.has(each));
		if (problem) return {
			id,
			code: "PROVIDER_SECRET_TAKEN",
			message: problem
		};
	}
	for (const host of registrableHosts(capability)) {
		const problem = publicHostProblem(host) ?? context.refuseHost?.(host);
		if (problem) return {
			id,
			code: "PROVIDER_HOST_REFUSED",
			message: problem
		};
	}
	return null;
}
/**
* Every host a row sends a secret to: an API-key provider's `hosts`; an
* OAuth provider's API hosts (the token), and its authorize, token and
* revoke hosts (the client). Each passes the row host rules.
*/
function registrableHosts(capability) {
	if (capability.mode === "api_key") return [...capability.hosts];
	if (capability.mode === "ai") return [new URL(capability.origin).hostname.toLowerCase()];
	const hosts = [...capability.api];
	const urls = [
		capability.flow.authorizeUrl,
		capability.flow.tokenUrl,
		capability.flow.revokeUrl,
		capability.flow.identity?.url
	];
	for (const url of urls) {
		if (!url) continue;
		try {
			const host = new URL(url).hostname.toLowerCase();
			if (!hosts.includes(host)) hosts.push(host);
		} catch {}
	}
	return hosts;
}
/** A row's spec parsed and checked: the capability, or the refusal. */
function resolveProviderRow(row, context) {
	let spec = row.spec;
	if (typeof spec === "string") try {
		spec = JSON.parse(spec);
	} catch {
		return {
			ok: false,
			refusal: {
				id: row.id,
				code: "PROVIDER_SPEC_INVALID",
				message: "the stored spec isn't JSON"
			}
		};
	}
	const parsed = parseProviderSpec(spec);
	if (!parsed.ok) return {
		ok: false,
		refusal: {
			id: row.id,
			code: "PROVIDER_SPEC_INVALID",
			message: describeSpecProblems(parsed.problems)
		}
	};
	if (parsed.id !== row.id || !PROVIDER_ID.test(row.id)) return {
		ok: false,
		refusal: {
			id: row.id,
			code: "PROVIDER_SPEC_INVALID",
			message: `the row is ${row.id} but its spec says ${parsed.id}`
		}
	};
	const refusal = checkProviderRow(parsed.id, parsed.capability, context);
	return refusal ? {
		ok: false,
		refusal
	} : {
		ok: true,
		capability: parsed.capability
	};
}
/**
* The catalog and `rows` as one registry. Rows are taken in order; a row
* whose settings another earlier row holds is the one refused.
*/
function providerRegistry(rows = [], options = {}) {
	const catalog = new Map(CAPABILITY_IDS.map((id) => [id, CAPABILITIES[id]]));
	const accepted = /* @__PURE__ */ new Map();
	const rejected = [];
	const rowSettings = /* @__PURE__ */ new Set();
	for (const row of rows) {
		if (accepted.has(row.id)) {
			rejected.push({
				id: row.id,
				code: "PROVIDER_SPEC_INVALID",
				message: "listed twice"
			});
			continue;
		}
		const resolved = resolveProviderRow(row, {
			rowSettings,
			...options.refuseHost ? { refuseHost: options.refuseHost } : {}
		});
		if (!resolved.ok) {
			rejected.push(resolved.refusal);
			continue;
		}
		accepted.set(row.id, {
			id: row.id,
			capability: resolved.capability,
			bound: row.boundTo === providerBindingKey(resolved.capability),
			addedBy: row.addedBy ?? null,
			addedAt: row.addedAt ?? null
		});
		for (const name of capabilitySettings(resolved.capability)) rowSettings.add(name);
	}
	const all = new Map([...catalog, ...[...accepted.values()].map((row) => [row.id, row.capability])]);
	let names;
	let unbound;
	return {
		get: (id) => all.get(id),
		ids: () => [...all.keys()],
		entries: () => [...all.entries()],
		sourceOf: (id) => catalog.has(id) ? "catalog" : accepted.has(id) ? "row" : void 0,
		settingNames: () => {
			names ??= new Set([...all.values()].flatMap((capability) => capabilitySettings(capability)));
			return names;
		},
		bound: (id) => catalog.has(id) || (accepted.get(id)?.bound ?? false),
		unboundSettings: () => {
			unbound ??= new Set([...accepted.values()].filter((row) => !row.bound).flatMap((row) => capabilitySettings(row.capability)));
			return unbound;
		},
		rows: () => [...accepted.values()],
		rejected
	};
}
providerRegistry();
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/internal/identity.js
var ConfigurationError = class extends Error {
	status = 500;
	/**
	* The Gateway refusal code the same gap gets once deployed
	* (`ai_provider_not_configured`, `ai_default_not_configured`), when the
	* error is "not set up" rather than a mistake in the code.
	*/
	code;
	/** The settings that would close the gap (`.dev.vars` names in local dev). */
	settings;
	constructor(message, setup) {
		super(message);
		this.name = "ConfigurationError";
		this.code = setup?.code;
		this.settings = setup?.settings ?? [];
	}
};
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/server/context.js
/**
* The request context: whom the app is serving, kept for the whole of a
* request's work (every `await`, `ctx.waitUntil()`, a streaming body) in an
* `AsyncLocalStorage`, which every Every App Worker has (`nodejs_compat`).
*
* `everyApp()` opens it around the handler and around each tool call, with
* the verified user and the request the Gateway forwarded. Every call back
* to the Gateway made inside it (`integrationFetch`, `sendEmail`, `emit`,
* ...) is attributed to that person without a `for`.
*
* Work no request started (a cron, a Workflow step, a queue consumer, a
* Durable Object alarm) has no context of its own: it says whom each call
* is for, `for: { background: true }` (a shared app's Worker adds the
* `organizationId`). The SDK's own event delivery runs its handler under
* `withOrganization()`, which does the same for every call inside it. A
* Gateway call with neither is refused before it is made
* ({@link RequestContextError}): the SDK never acts as nobody.
*/
var scopes = new AsyncLocalStorage();
/**
* Code `request_context_missing`: a Gateway call with no `for`, outside
* any request `everyApp()` serves. Work no request started passes
* `for: { background: true }`.
*/
var RequestContextError = class extends Error {
	code = "request_context_missing";
	constructor(message) {
		super(message);
		this.name = "RequestContextError";
	}
};
/**
* Whom a Gateway call made now is for, from the context:
*
*  - the request being served, while its identity is good;
*  - else that organization's background work (the identity is about to
*    expire, or `withOrganization()` named it);
*  - `undefined` on a public route of an organization's own app, which the
*    Gateway attributes to the app's organization; and
*  - a {@link RequestContextError} outside every context.
*/
function attributionFromContext(what, now = Date.now()) {
	const scope = scopes.getStore();
	if (!scope) throw new RequestContextError(`${what} was called with no \`for\`, outside a request everyApp() serves: the call would be nobody's. Pass for: request, or for: { background: true } for work no request started (a cron, a Workflow step, a queue consumer).`);
	const served = scope.served;
	if (served?.user) {
		if (served.expiresAt === null || now < served.expiresAt - 15e3) return served.request;
		return {
			background: true,
			organizationId: served.user.orgId
		};
	}
	if (scope.organizationId) return {
		background: true,
		organizationId: scope.organizationId
	};
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/server/everyApp.js
/**
* `everyApp()` \u2014 the app-side identity boundary.
*
*   export default everyApp(handler, { tools });
*
* The wrapper verifies the gateway-injected identity before app code runs,
* stores the result on the original Request, and then delegates to the
* worker-style handler. The expected audience is the Worker's own name in
* `env.EVERYAPP_AUDIENCE`, which `everyAppWorker()` sets at deploy (the
* gateway stamps every token it mints for the app with it); only in
* development, where `everyapp dev` mints for the app id, does the app id in
* `env.EVERYAPP_APP_ID` stand in. The Worker never imports
* `everyapp.config.ts` (the Cloudflare Vite plugin hides every file
* `cloudflare.config.ts` imports from the Worker in dev).
* It also answers the gateway's internal tools contract
* (`/__everyapp/tools/*`) for the app's `defineTools()` catalog, and the
* event sink's deliveries (`/__everyapp/events`) for `events: { on }`.
*
* Around the handler and around each tool call it opens the request
* context (context.ts): every call back to the Gateway is attributed to
* the request without a `for`. A deployed Worker is pinned to its organization
* (`EVERY_APP_ORG_ID`), and an identity for any other is refused on both
* paths. The response leaves without `Set-Cookie`: the perimeter strips
* every `Cookie` before a request reaches the app, so a cookie the app's
* framework sets could never come back, and one named like the Gateway's
* session cookie would lock the person out of the app host.
*/
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/server/attribution.js
/**
* A gateway call that doesn't say whom it is for where it must: from a
* shared app's Worker, with neither the request nor an organization.
*/
var AttributionError = class extends Error {
	code = "attribution_required";
	constructor(message) {
		super(message);
		this.name = "AttributionError";
	}
};
/**
* Whom the call is for, checked before any call is made: `target` as the
* app passed it, else the request context's answer
* ({@link attributionFromContext}; a `RequestContextError` outside every
* context). A shared app's Worker must end up with the request or an
* organization, and anything passed must be one of the two shapes.
*/
function attributionFor(env, target, what) {
	const resolved = target === void 0 ? attributionFromContext(what) : target;
	checkAttribution(env, resolved, what);
	return resolved;
}
function checkAttribution(env, target, what) {
	if (target !== void 0 && !isRequest(target)) {
		if (target === null || typeof target !== "object" || !target.background) throw new AttributionError(`${what}: \`for\` is the inbound Request or { background: true, organizationId }.`);
		if (target.userId !== void 0 && !nonEmpty(target.userId)) throw new AttributionError(`${what}: { background: true, userId } needs a non-empty user id.`);
		if (target.organizationId !== void 0 && !nonEmpty(target.organizationId)) throw new AttributionError(`${what}: { background: true, organizationId } needs a non-empty organization id.`);
	}
	if (!isSharedWorker(env)) return;
	if (target === void 0 || !isRequest(target) && !target.organizationId) throw new AttributionError(`${what} in a shared app's Worker serves every organization, so it must say whom the call is for: for: request, or for: { background: true, organizationId } for work no request started.`);
}
/**
* Put the call's attribution on its headers: the request's identity, or the
* background work's organization, and never one the app set itself.
*/
function applyAttribution(headers, target) {
	headers.delete(IDENTITY_HEADER);
	headers.delete(ORG_HEADER);
	headers.delete(USER_HEADER);
	if (target === void 0) return;
	if (isRequest(target)) {
		const identity = target.headers.get(IDENTITY_HEADER);
		if (identity) headers.set(IDENTITY_HEADER, identity);
		return;
	}
	if (target.organizationId) headers.set(ORG_HEADER, target.organizationId);
	if (target.userId) headers.set(USER_HEADER, target.userId.trim());
}
function isSharedWorker(env) {
	const value = env[SHARED_ENV];
	return value === "1" || value === "true" || value === true;
}
/** Whether `for` is the inbound request (rather than background work). */
function isRequest(value) {
	return typeof value === "object" && value !== null && "headers" in value && typeof value.headers?.get === "function";
}
function nonEmpty(value) {
	return typeof value === "string" && value.trim().length > 0;
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/server/connectUrl.js
/** The path of the connect page for `provider` on the Gateway, without the app. */
function connectPath(provider) {
	return `/connect/${encodeURIComponent(provider)}`;
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/server/gatewayFetch.js
var BINDING_ORIGIN = "http://every-app-gateway.internal";
/**
* The Gateway the SDK's services call: the `EVERY_APP_GATEWAY` service
* binding when deployed; under `everyapp dev --gateway` (linked dev,
* docs/design/linked-dev.md) a `{ fetch }` that sends the same requests to
* the gateway-lite's loopback forwarder, which adds the person's token and
* forwards them to the real Gateway's `/linked-dev/<app>` route. Undefined
* with neither (stub and mirror modes: the `.dev.vars` fallbacks). A value
* under the binding's name that isn't one is answered as before by each
* caller (`ConfigurationError`).
*/
function gatewayBinding(env) {
	const values = env;
	const binding = values["EVERY_APP_GATEWAY"];
	if (binding) return binding;
	if (!values["EVERYAPP_DEV"]) return void 0;
	const url = values[LINKED_DEV_URL_ENV];
	const nonce = values[LINKED_DEV_NONCE_ENV];
	if (typeof url !== "string" || !url.trim() || typeof nonce !== "string") return;
	return linkedDevBinding(url.trim(), nonce);
}
/**
* The linked dev shim: a request to the binding's origin goes to the
* forwarder's URL with the same path and query, the run's nonce on it. The
* forwarder answers as the Gateway did, refusals included; nothing here
* falls back to a local key.
*/
function linkedDevBinding(forwarderUrl, nonce) {
	const base = forwarderUrl.replace(/\/+$/, "");
	return { fetch(input, init) {
		const outbound = new Request(input, init);
		const url = new URL(outbound.url);
		const headers = new Headers(outbound.headers);
		headers.set(LINKED_DEV_HEADER, nonce);
		return fetch(streamingRequest(`${base}${url.pathname}${url.search}`, outbound, headers));
	} };
}
/** A copy of `source` aimed at `url`, streaming its body rather than buffering it. */
function streamingRequest(url, source, headers) {
	const body = canIncludeBody(source.method) ? source.body : void 0;
	const init = {
		method: source.method,
		headers,
		body,
		signal: source.signal,
		...body ? { duplex: "half" } : {}
	};
	return new Request(url, init);
}
function canIncludeBody(method) {
	const normalized = method.toUpperCase();
	return normalized !== "GET" && normalized !== "HEAD";
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/server/refusal.js
/**
* The Gateway's own refusals, read the same way wherever they surface: a
* `Response` from a gateway fetch ({@link gatewayRefusal}), the error an
* SDK helper throws ({@link GatewayRefusalError}), or the error an AI
* client throws for a refused call (an OpenAI SDK's `APIError`, ai-sdk's
* `APICallError`) ({@link refusalFromError}).
*
* A refusal that means "not set up" (`integration_not_configured`,
* `ai_provider_not_configured`, `ai_default_not_configured`) carries what
* to do in the Gateway's words: `settings` (the setting names it needs),
* `setup` (one sentence for a person) and `command` (what an admin runs,
* `pnpm everyapp configure <app>`, or null). Show them as they are; never
* match the message text or hardcode a setting name or a command.
*/
/**
* The gateway's own refusal in `response`, or null when the response is the
* provider's answer (which may be an error of its own). Reads the body only
* for a refusal, so call it before reading the body yourself.
*/
async function gatewayRefusal(response) {
	const code = response.headers.get(GATEWAY_ERROR_HEADER);
	if (!code) return null;
	const body = await response.json().catch(() => null);
	return refusalOf(response.status, code, body);
}
/** A refusal from its status, code and body (the Gateway's `{ code, message, \u2026 }`, or OpenAI's `{ error: {\u2026} }`). */
function refusalOf(status, code, body, fallback) {
	const top = recordOf(body);
	const inner = recordOf(top?.["error"]);
	const field = (name) => top?.[name] ?? inner?.[name];
	const message = stringOf(top?.["message"]) ?? stringOf(inner?.["message"]) ?? fallback ?? `The EveryApp gateway refused the call (${code}).`;
	const settings = field("settings");
	return {
		status,
		code,
		message,
		settings: Array.isArray(settings) ? settings.filter((name) => typeof name === "string") : [],
		setup: stringOf(field("setup")) ?? null,
		command: stringOf(field("command")) ?? null
	};
}
function recordOf(value) {
	return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}
function stringOf(value) {
	return typeof value === "string" && value ? value : void 0;
}
//#endregion
//#region node_modules/.pnpm/@every-app+sdk@0.3.0-rc.14_@tanstack+react-start@1.168.60_esbuild@0.28.2_react-dom@19.2_12132004543a92fef878a57194834969/node_modules/@every-app/sdk/dist/server/integrationFetch.js
function integrationFetch({ env, provider, for: explicitTarget, optional = false }) {
	const catalogEntry = fetchableCapability(provider);
	const what = `integrationFetch("${provider}")`;
	attributionFor(env, explicitTarget, what);
	const values = env;
	const binding = gatewayBinding(env);
	if (binding && typeof binding.fetch !== "function") throw new ConfigurationError("EVERY_APP_GATEWAY is configured but is not a valid service binding.");
	const integration = catalogEntry ?? (binding ? void 0 : devRegisteredProvider(provider, values));
	const local = binding || integration?.mode !== "api_key" ? null : localAuthorization(integration, values);
	if (!binding && integration?.mode === "api_key" && !local) {
		if (optional) return null;
		throw new ConfigurationError(`${integration.label} is unavailable: deploy with the EVERY_APP_GATEWAY binding, or set ${capabilitySettings(integration).join(", ")} in .dev.vars for local development.`);
	}
	return async (input, init) => {
		const target = attributionFor(env, explicitTarget, what);
		const outbound = new Request(input, init);
		const upstream = new URL(outbound.url);
		const headers = new Headers(outbound.headers);
		headers.delete("authorization");
		headers.delete("cookie");
		if (!integration) {
			if (upstream.protocol !== "https:") throw new TypeError(`integrationFetch("${provider}") reaches https URLs only, not ${upstream.protocol}//${upstream.host}.`);
			applyAttribution(headers, target);
			return binding.fetch(streamingRequest(`${BINDING_ORIGIN}${integrationProxyPath(provider, upstream)}`, outbound, headers));
		}
		const hosts = integration.mode === "oauth_client" ? [...integration.api] : binding ? [...integration.hosts] : apiKeyHosts(integration, values);
		if (upstream.protocol !== "https:" || !hosts.includes(upstream.host)) throw new TypeError(`integrationFetch("${provider}") only reaches ${hosts.join(", ")}, not ${upstream.host}.`);
		if (binding) {
			applyAttribution(headers, target);
			return binding.fetch(streamingRequest(`${BINDING_ORIGIN}${integrationProxyPath(provider, upstream)}`, outbound, headers));
		}
		applyAttribution(headers, void 0);
		if (integration.mode === "oauth_client") return devHeldTokenCall({
			provider,
			capability: integration,
			outbound,
			upstream,
			headers,
			values
		});
		const auth = local;
		for (const [name, value] of Object.entries(auth.headers)) headers.set(name, value);
		for (const [name, value] of Object.entries(auth.query)) upstream.searchParams.set(name, value);
		return fetch(streamingRequest(upstream.toString(), outbound, headers));
	};
}
/**
* The `.dev.vars` name of a held token for `provider` in local dev
* (`GOOGLE_WORKSPACE_ACCESS_TOKEN`, `GITHUB_ACCESS_TOKEN`): a token the
* developer obtained themselves, standing in for the connection the
* gateway would hold. Dev-only: the gateway never reads it.
*/
function devAccessTokenName(provider) {
	return `${providerSettingPrefix(provider)}ACCESS_TOKEN`;
}
/**
* Where a person connects `provider` in this app:
* `/connect/<id>?app=<EVERYAPP_APP_ID>`, as the gateway's refusal and
* status name it (without the app id when the env has none).
*/
function appConnectPath(provider, values) {
	const app = stringValue(values[APP_ID_ENV]);
	return app ? `${connectPath(provider)}?app=${encodeURIComponent(app)}` : connectPath(provider);
}
/**
* An app's call to an OAuth provider's API in local dev, with no
* gateway: the developer's own token from `.dev.vars` as the bearer,
* straight to the provider (the host was checked already), or the
* gateway's `integration_not_connected` refusal without one.
*/
async function devHeldTokenCall({ provider, capability, outbound, upstream, headers, values }) {
	const token = stringValue(values[devAccessTokenName(provider)]);
	if (!token) {
		const path = appConnectPath(provider, values);
		return devRefusal(409, "integration_not_connected", `${capability.label} isn't connected here. In local dev, set ${devAccessTokenName(provider)} in .dev.vars to a token you obtained yourself; deployed, the person connects in the app at ${path}.`, {
			connectPath: path,
			reconnect: false
		});
	}
	const method = outbound.method.toUpperCase();
	headers.set("authorization", `Bearer ${token}`);
	for (const name of ["access_token", "token"]) upstream.searchParams.delete(name);
	headers.delete("x-http-method-override");
	return fetch(new Request(upstream.toString(), {
		method,
		headers,
		body: method === "GET" || method === "HEAD" ? null : outbound.body,
		signal: outbound.signal,
		redirect: "manual",
		...method === "GET" || method === "HEAD" ? {} : { duplex: "half" }
	}));
}
/**
* The developer's own key from `.dev.vars` (with EVERYAPP_DEV set), under
* the gateway's names; null until every setting it needs is.
*/
function localAuthorization(integration, values) {
	if (!values["EVERYAPP_DEV"]) return null;
	return authorizationFor(integration, values);
}
/**
* The gateway's refusal shape (`{ error, code, message }`, the code in
* `x-everyapp-error`) from the local-dev twin, so {@link gatewayRefusal}
* reads it the same way.
*/
function devRefusal(status, code, message, extra = {}) {
	return Response.json({
		error: { 409: "Conflict" }[status] ?? "Error",
		code,
		message,
		...extra
	}, {
		status,
		headers: { [GATEWAY_ERROR_HEADER]: code }
	});
}
/**
* A provider outside the catalog in local dev (no binding): the gateway
* row's spec from EVERYAPP_DEV_PROVIDERS (`.everyapp/providers/<id>.json`,
* which `everyAppWorker()` reads in dev), or a ConfigurationError naming
* the file that doesn't parse, or the command that writes one.
*/
function devRegisteredProvider(provider, values) {
	if (!values["EVERYAPP_DEV"]) throw new ConfigurationError(`"${provider}" isn't in the built-in provider catalog. A provider registered on the gateway (everyapp provider add) is reached through the EVERY_APP_GATEWAY binding, or in everyapp dev from ${devProviderFile(provider)}.`);
	const resolved = resolveDevProvider(values, provider);
	if (!resolved.found) throw new ConfigurationError(resolved.problem);
	if (resolved.capability.mode === "ai") throw new ConfigurationError(`${provider} is an AI provider: list it under providers and call it with createGatewayFetch(), not integrationFetch().`);
	return resolved.capability;
}
/**
* The provider `integrationFetch()` calls: one whose key or OAuth client
* the gateway holds, or undefined for an id outside the built-in catalog
* (a provider registered on the gateway, which the binding resolves).
*/
function fetchableCapability(provider) {
	const found = CATALOG.get(String(provider));
	if (!found) return void 0;
	if (found.mode === "service") throw new ConfigurationError(`${String(provider)} is a gateway service: call its helper from @every-app/sdk/server (sendEmail(), listMembers()), not integrationFetch().`);
	if (found.mode === "ai") throw new ConfigurationError(`${String(provider)} is an AI provider: list it under providers and call it with createGatewayFetch(), not integrationFetch().`);
	return found;
}
function stringValue(value) {
	return typeof value === "string" && value.trim() ? value.trim() : void 0;
}
new TextEncoder();
//#endregion
//#region src/shared/gateway-setup-messages.ts
/**
* What OpenSEO says when the Every App gateway holds no DataForSEO key: the
* server's refusal (which a rank check stores and the MCP tools answer with)
* and the setup dialog read this one sentence. The client's
* DATAFORSEO_AUTH_FAILED copy adds "or rejected the key it holds", because
* that code also covers DataForSEO's own 401. Plain text: ErrorState, toasts
* and tool answers render it as is, so no backticks.
*/
var DATAFORSEO_NOT_SET_UP_MESSAGE = "DataForSEO isn't set up on your Every App gateway yet. An owner or admin sets it with pnpm everyapp secret set DATAFORSEO_API_KEY.";
//#endregion
//#region src/server/lib/gateway-attribution.ts
var servedRequests = new AsyncLocalStorage();
var IDENTITY_EXPIRY_MARGIN_MS = 15e3;
/**
* The SDK's `for` for a gateway call made now: the served request while its
* identity is good, else background work.
*/
function gatewayCallFor() {
	const served = servedRequests.getStore();
	if (served && identityIsGood(served)) return served.request;
	return { background: true };
}
function identityIsGood(served) {
	return Date.now() < served.expiresAt - IDENTITY_EXPIRY_MARGIN_MS;
}
//#endregion
//#region src/server/lib/provider-access.ts
async function isBehindEveryAppGateway() {
	return isEveryAppAuthMode(await getOptionalEnvValue("AUTH_MODE"));
}
async function gatewayEnv() {
	return await getWorkersEnv() ?? {};
}
function withAuthorization(authorization) {
	return (input, init) => {
		const headers = new Headers(init?.headers);
		headers.set("Authorization", authorization);
		return fetch(input, {
			...init,
			headers
		});
	};
}
/**
* The gateway's fetch for a capability, or null without its binding. Whose
* call it is: gateway-attribution.ts.
*/
async function gatewayFetch(provider) {
	const env = await gatewayEnv();
	try {
		return integrationFetch({
			env,
			provider,
			for: gatewayCallFor()
		});
	} catch (error) {
		if (error instanceof ConfigurationError) return null;
		throw error;
	}
}
/** A fetch that reaches DataForSEO authenticated, for this deployment. */
async function getDataforseoFetch() {
	if (await isBehindEveryAppGateway()) {
		const providerFetch = await gatewayFetch("dataforseo");
		if (!providerFetch) {
			console.warn("[openseo] no DataForSEO key: set DATAFORSEO_API_KEY in .dev.vars for local development");
			throw new AppError("DATAFORSEO_AUTH_FAILED", DATAFORSEO_NOT_SET_UP_MESSAGE);
		}
		return providerFetch;
	}
	return withAuthorization(`Basic ${await getRequiredEnvValue("DATAFORSEO_API_KEY")}`);
}
/** A fetch that reaches Context.dev authenticated, or null without a key. */
async function getContextFetch() {
	if (await isBehindEveryAppGateway()) return gatewayFetch("context");
	const apiKey = await getOptionalEnvValue("CONTEXT_API_KEY");
	return apiKey ? withAuthorization(`Bearer ${apiKey}`) : null;
}
//#endregion
//#region src/server/lib/dataforseo/core.ts
var API_BASE = "https://api.dataforseo.com";
var MAX_DATAFORSEO_ERROR_PAYLOAD_LENGTH = 1600;
var DATAFORSEO_REQUEST_TIMEOUT_MS = 6e4;
var DATAFORSEO_MAX_RETRIES = 2;
var DATAFORSEO_RETRY_BACKOFF_MS = 250;
function formatDataforseoErrorPayload(value) {
	const text = typeof value === "string" ? value : (() => {
		try {
			return JSON.stringify(value);
		} catch {
			return String(value);
		}
	})();
	return text.length > MAX_DATAFORSEO_ERROR_PAYLOAD_LENGTH ? `${text.slice(0, MAX_DATAFORSEO_ERROR_PAYLOAD_LENGTH)}... [truncated]` : text;
}
function formatDataforseoRequestPath(url) {
	const rawUrl = typeof url === "string" ? url : url.url;
	try {
		return new URL(rawUrl).pathname;
	} catch {
		return rawUrl;
	}
}
/**
* A refusal the Every App gateway made itself (the app doesn't ask for
* DataForSEO, the gateway has no key, the call names no organization), as
* opposed to DataForSEO's own answer
* passed through, as OpenSEO's error; null for DataForSEO's answer.
*
* A missing key gets OpenSEO's own sentence as the message: rank checks store
* error.message and the MCP tools answer with it, and the gateway's wording
* is its operator's. The gateway's text stays in the details.
*/
async function gatewayRefusalError(response) {
	const refusal = await gatewayRefusal(response);
	if (!refusal) return null;
	const details = {
		provider: "dataforseo",
		gatewayError: refusal.code,
		gatewayMessage: refusal.message
	};
	if (refusal.code === "integration_not_configured") return new AppError("DATAFORSEO_AUTH_FAILED", DATAFORSEO_NOT_SET_UP_MESSAGE, details);
	return new AppError("AUTH_CONFIG_MISSING", refusal.message, details);
}
/**
* A DataForSEO response body as text, inflated first if it is still gzip.
* The first two bytes decide, not Content-Encoding: runtimes that already
* decoded the body keep that header, so trusting it would inflate twice.
*/
async function readDataforseoText(response) {
	const bytes = new Uint8Array(await response.arrayBuffer());
	if (bytes[0] !== 31 || bytes[1] !== 139) return new TextDecoder().decode(bytes);
	const inflated = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("gzip"));
	return new Response(inflated).text();
}
/** A request-deadline abort as UPSTREAM_UNAVAILABLE; any other error as is. */
function asDataforseoTimeoutError(error, url) {
	if (!(error instanceof Error) || error.name !== "TimeoutError" && error.name !== "AbortError") return error;
	const path = formatDataforseoRequestPath(url);
	console.warn("dataforseo.upstream-timeout", {
		event: "dataforseo.upstream-timeout",
		path
	});
	const timeoutError = new AppError("UPSTREAM_UNAVAILABLE", `DataForSEO request timed out on ${path}`, {
		provider: "dataforseo",
		providerPath: path
	});
	timeoutError.name = "DataForSEOTimeoutError";
	return timeoutError;
}
/**
* The single authenticated `fetch` used by every DataForSEO call. Throws on
* non-2xx; task-level failures (which return HTTP 200) are handled downstream
* by {@link assertOk}. An optional classifier maps recognised HTTP failures to
* product errors.
*/
function createAuthenticatedFetch(classify, maxServerErrorRetries = DATAFORSEO_MAX_RETRIES) {
	return async (url, init) => {
		const providerFetch = await getDataforseoFetch();
		const signal = init?.signal ?? AbortSignal.timeout(DATAFORSEO_REQUEST_TIMEOUT_MS);
		const headers = new Headers(init?.headers);
		if (!headers.has("Accept-Encoding")) headers.set("Accept-Encoding", "gzip");
		for (let attempt = 0;; attempt++) {
			let response;
			try {
				response = await providerFetch(url, {
					...init,
					headers,
					signal
				});
			} catch (error) {
				throw asDataforseoTimeoutError(error, url);
			}
			if (response.ok) return response;
			const refused = await gatewayRefusalError(response);
			if (refused) throw refused;
			if (response.status >= 500 && attempt < maxServerErrorRetries) {
				await new Promise((resolve) => setTimeout(resolve, DATAFORSEO_RETRY_BACKOFF_MS * (attempt + 1)));
				continue;
			}
			const rawText = await readDataforseoText(response);
			const path = formatDataforseoRequestPath(url);
			const classified = classify?.(response.status, rawText, path);
			if (classified) throw classified;
			const code = response.status >= 500 ? "UPSTREAM_UNAVAILABLE" : response.status === 429 ? "RATE_LIMITED" : response.status === 401 || response.status === 403 ? "DATAFORSEO_AUTH_FAILED" : "INTERNAL_ERROR";
			const error = new AppError(code, `DataForSEO HTTP ${response.status} on ${path}`, {
				provider: "dataforseo",
				providerStatus: String(response.status),
				providerPath: path,
				responseBody: formatDataforseoErrorPayload(rawText)
			});
			error.name = "DataForSEOHttpError";
			if (code === "UPSTREAM_UNAVAILABLE") console.warn("dataforseo.upstream-http-failed", {
				event: "dataforseo.upstream-http-failed",
				path,
				status: response.status
			});
			throw error;
		}
	};
}
async function requestDataforseo(method, path, body, options) {
	const doFetch = createAuthenticatedFetch(options.classify, options.maxServerErrorRetries);
	const url = `${options.baseUrl ?? API_BASE}${path}`;
	const response = await doFetch(url, {
		method,
		headers: {
			Accept: "application/json",
			...method === "POST" ? { "Content-Type": "application/json" } : {}
		},
		body: method === "POST" ? JSON.stringify(body) : void 0,
		signal: options.signal
	});
	let text;
	try {
		text = await readDataforseoText(response);
	} catch (error) {
		throw asDataforseoTimeoutError(error, url);
	}
	if (text === "") return null;
	const parsed = JSON.parse(text);
	warnIfUpstreamResponseFailed(parsed, path);
	return parsed;
}
/**
* POST `tasks` (the standard array-of-task-payloads body) to a DataForSEO
* endpoint and return the parsed response envelope. The task type parameter is
* the caller's claim about the payload shape \u2014 fields we act on are validated
* downstream (billing metadata in envelope.ts, items via the section fetchers'
* Zod schemas). Auth is read per-call from the Worker env.
*/
function dataforseoPost(path, tasks, options = {}) {
	return requestDataforseo("POST", path, tasks, options);
}
/**
* POST like {@link dataforseoPost} but return the UN-CONSUMED Response
* (headers only) \u2014 the same auth, retry policy, and HTTP-error ladder apply.
* For the one endpoint whose body is too big to read eagerly: Lighthouse
* gates its multi-MB body reads behind a parse lock in the audit worker, and
* passes its own `signal` so the timeout can be cleared once headers arrive.
*/
function dataforseoPostResponse(path, tasks, options = {}) {
	return createAuthenticatedFetch(options.classify, options.maxServerErrorRetries)(`${API_BASE}${path}`, {
		method: "POST",
		headers: {
			Accept: "application/json",
			"Content-Type": "application/json"
		},
		body: JSON.stringify(tasks),
		signal: options.signal
	});
}
/** GET a DataForSEO endpoint (task_get collection, appendix/locations data). */
function dataforseoGet(path, options = {}) {
	return requestDataforseo("GET", path, void 0, options);
}
//#endregion
//#region src/server/lib/dataforseo/business.ts
var NO_RETRY = { maxServerErrorRetries: 0 };
function locationParams(input) {
	return input.locationCoordinate ? { location_coordinate: input.locationCoordinate } : { location_code: input.locationCode };
}
async function fetchBusinessListingsSearch(input) {
	const task = assertOk(await dataforseoPost("/v3/business_data/business_listings/search/live", [{
		categories: input.categories,
		title: input.title,
		location_coordinate: input.locationCoordinate,
		is_claimed: input.isClaimed,
		filters: input.filters,
		order_by: input.orderBy,
		limit: input.limit,
		offset: input.offset
	}]), { treatNoResultsAsEmpty: true });
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
var questionsResultSchema = object({
	items: array(record(string(), unknown())).nullable().optional(),
	items_without_answers: array(record(string(), unknown())).nullable().optional()
}).passthrough();
function combinedQuestionItems(results) {
	return (Array.isArray(results) ? results : []).flatMap((result) => {
		const parsed = questionsResultSchema.safeParse(result ?? {});
		if (!parsed.success) return [];
		return [...parsed.data.items ?? [], ...parsed.data.items_without_answers ?? []];
	});
}
async function fetchQuestionsAnswers(input) {
	const task = assertOk(await dataforseoPost("/v3/business_data/google/questions_and_answers/live", [{
		keyword: input.keyword,
		location_coordinate: input.locationCoordinate,
		language_code: input.languageCode,
		depth: input.depth
	}]), { treatNoResultsAsEmpty: true });
	return {
		data: combinedQuestionItems(task.result),
		billing: buildTaskBilling(task)
	};
}
async function fetchMyBusinessInfo(input) {
	const task = assertOk(await dataforseoPost("/v3/business_data/google/my_business_info/live", [{
		keyword: input.keyword,
		...locationParams(input),
		language_code: input.languageCode
	}]), { treatNoResultsAsEmpty: true });
	const entry = task.result?.[0];
	const item = entry?.items?.[0];
	if (!isRecord$5(item)) return {
		data: null,
		billing: buildTaskBilling(task)
	};
	if (item.check_url == null) item.check_url = entry?.check_url;
	return {
		data: item,
		billing: buildTaskBilling(task)
	};
}
/** High execution priority: reviews normally settle within ~20s instead of
*  minutes, which is what makes a single MCP call able to return them. */
var TASK_PRIORITY_HIGH$1 = 2;
/**
* Validates a task_post response and returns the created task's id. `assertOk`
* applies the standard charged-failure ladder (a rejected post entry still
* carries the cost DataForSEO charged, and "Invalid Field" rejections stay
* non-reportable); 20100 "Task Created" is the success status for posts.
*/
function postedTaskId(response) {
	const task = assertOk(response, { okTaskStatusCode: 20100 });
	if (!task.id) throw new AppError("INTERNAL_ERROR", "DataForSEO did not return a task id");
	return {
		data: task.id,
		billing: buildTaskBilling(task)
	};
}
async function postGoogleReviewsTask(input) {
	if (input.includeOtherSources) return postedTaskId(await dataforseoPost("/v3/business_data/google/extended_reviews/task_post", [{
		keyword: input.keyword,
		cid: input.cid,
		place_id: input.placeId,
		...locationParams(input),
		language_code: input.languageCode,
		depth: input.depth,
		priority: TASK_PRIORITY_HIGH$1
	}], NO_RETRY));
	return postedTaskId(await dataforseoPost("/v3/business_data/google/reviews/task_post", [{
		keyword: input.keyword,
		cid: input.cid,
		place_id: input.placeId,
		...locationParams(input),
		language_code: input.languageCode,
		depth: input.depth,
		sort_by: input.sortBy,
		priority: TASK_PRIORITY_HIGH$1
	}], NO_RETRY));
}
async function postMyBusinessUpdatesTask(input) {
	return postedTaskId(await dataforseoPost("/v3/business_data/google/my_business_updates/task_post", [{
		keyword: input.keyword,
		...locationParams(input),
		language_code: input.languageCode,
		depth: input.depth,
		priority: TASK_PRIORITY_HIGH$1
	}], NO_RETRY));
}
object({
	category_name: string(),
	business_count: number().nullable().optional()
}).passthrough();
//#endregion
//#region src/server/lib/dataforseoBillingClassification.ts
var BILLING_SIGNALS = [
	"insufficient funds",
	"balance is too low",
	"payment required",
	"billing",
	"balance",
	"problem billing",
	"recharged"
];
var BILLING_STATUS_CODES = /* @__PURE__ */ new Set([
	40200,
	40210,
	402
]);
/**
* Maps DataForSEO balance/payment failures for a given API section to a typed
* billing error. Feature-enablement is no longer classified: Backlinks and AI
* Optimization are included in every DataForSEO account, so the only remaining
* account-level failure is a depleted balance.
*/
function createDataforseoBillingClassifier(config) {
	return (status, details, path) => {
		if (!path.includes(config.pathPrefix)) return null;
		const text = details.toLowerCase();
		const matchesBillingStatus = status != null && BILLING_STATUS_CODES.has(status);
		const matchesBillingText = BILLING_SIGNALS.some((signal) => text.includes(signal));
		if (matchesBillingStatus || matchesBillingText) return new AppError(config.billingIssueCode, config.billingIssueMessage);
		return null;
	};
}
//#endregion
//#region src/server/lib/dataforseo/backlinks.ts
var classifyBacklinksError = createDataforseoBillingClassifier({
	pathPrefix: "/backlinks/",
	billingIssueCode: "BACKLINKS_BILLING_ISSUE",
	billingIssueMessage: "The connected DataForSEO account has a billing or balance issue"
});
var backlinksSummaryItemSchema = object({
	target: string().optional(),
	rank: number().nullable().optional(),
	backlinks: number().nullable().optional(),
	referring_pages: number().nullable().optional(),
	referring_domains: number().nullable().optional(),
	broken_backlinks: number().nullable().optional(),
	broken_pages: number().nullable().optional(),
	new_backlinks: number().nullable().optional(),
	lost_backlinks: number().nullable().optional(),
	new_reffering_domains: number().nullable().optional(),
	lost_reffering_domains: number().nullable().optional(),
	new_referring_domains: number().nullable().optional(),
	lost_referring_domains: number().nullable().optional(),
	backlinks_spam_score: number().nullable().optional(),
	info: object({ target_spam_score: number().nullable().optional() }).passthrough().nullable().optional()
}).passthrough();
var backlinksItemSchema = object({
	domain_from: string().nullable().optional(),
	url_from: string().nullable().optional(),
	url_to: string().nullable().optional(),
	anchor: string().nullable().optional(),
	item_type: string().nullable().optional(),
	dofollow: boolean().nullable().optional(),
	rank: number().nullable().optional(),
	domain_from_rank: number().nullable().optional(),
	page_from_rank: number().nullable().optional(),
	backlinks_spam_score: number().nullable().optional(),
	backlink_spam_score: number().nullable().optional(),
	first_seen: string().nullable().optional(),
	last_seen: string().nullable().optional(),
	last_visited: string().nullable().optional(),
	lost_date: string().nullable().optional(),
	is_new: boolean().nullable().optional(),
	is_lost: boolean().nullable().optional(),
	is_broken: boolean().nullable().optional(),
	links_count: number().nullable().optional(),
	rel_attributes: array(string()).nullable().optional(),
	attributes: array(string()).nullable().optional()
}).passthrough();
var referringDomainItemSchema = object({
	domain: string().nullable().optional(),
	backlinks: number().nullable().optional(),
	referring_pages: number().nullable().optional(),
	rank: number().nullable().optional(),
	first_seen: string().nullable().optional(),
	broken_backlinks: number().nullable().optional(),
	broken_pages: number().nullable().optional(),
	backlinks_spam_score: number().nullable().optional(),
	target_spam_score: number().nullable().optional()
}).passthrough();
var domainPageSummaryItemSchema = object({
	page: string().nullable().optional(),
	url: string().nullable().optional(),
	backlinks: number().nullable().optional(),
	referring_domains: number().nullable().optional(),
	rank: number().nullable().optional(),
	broken_backlinks: number().nullable().optional()
}).passthrough();
var backlinksHistoryItemSchema = object({
	date: string().nullable().optional(),
	rank: number().nullable().optional(),
	backlinks: number().nullable().optional(),
	referring_domains: number().nullable().optional(),
	new_backlinks: number().nullable().optional(),
	lost_backlinks: number().nullable().optional(),
	new_reffering_domains: number().nullable().optional(),
	lost_reffering_domains: number().nullable().optional(),
	new_referring_domains: number().nullable().optional(),
	lost_referring_domains: number().nullable().optional()
}).passthrough();
function buildCommonPayload(input) {
	return {
		target: input.target,
		include_subdomains: input.includeSubdomains ?? true,
		include_indirect_links: true,
		exclude_internal_backlinks: true,
		backlinks_status_type: "live",
		rank_scale: "one_hundred"
	};
}
var assertOptions$1 = (path) => ({
	classify: classifyBacklinksError,
	classifyPath: path
});
/**
* Joins caller-provided filter expressions with the spam-score condition.
* `userFilters` arrives already and/or-joined, so the spam condition is
* appended with a single top-level "and".
*/
function combineFilters(userFilters, spamCondition) {
	const merged = [];
	if (userFilters && userFilters.length > 0) merged.push(...userFilters);
	if (spamCondition) {
		if (merged.length > 0) merged.push("and");
		merged.push(spamCondition);
	}
	return merged.length > 0 ? merged : void 0;
}
async function fetchBacklinksSummary(input) {
	const task = assertOk(await dataforseoPost("/v3/backlinks/summary/live", [buildCommonPayload(input)], { classify: classifyBacklinksError }), assertOptions$1("/v3/backlinks/summary/live"));
	const firstResult = task.result?.[0];
	if (firstResult) {
		const parsed = backlinksSummaryItemSchema.safeParse(firstResult);
		if (!parsed.success) {
			console.error("dataforseo.backlinks-summary-live.invalid-result", parsed.error.issues.slice(0, 5));
			throw new AppError("INTERNAL_ERROR", "DataForSEO backlinks-summary-live returned an invalid response shape");
		}
		return {
			data: parsed.data,
			billing: buildTaskBilling(task)
		};
	}
	return {
		data: {},
		billing: buildTaskBilling(task)
	};
}
async function fetchBacklinksRows(input) {
	const filters = combineFilters(input.filters, input.hideSpam ?? true ? [
		[
			"backlink_spam_score",
			"<",
			40
		],
		"or",
		[
			"backlink_spam_score",
			"=",
			null
		]
	] : void 0);
	const task = assertOk(await dataforseoPost("/v3/backlinks/backlinks/live", [{
		...buildCommonPayload(input),
		backlinks_status_type: input.status ?? "live",
		limit: input.limit ?? 100,
		offset: input.offset,
		order_by: input.orderBy ?? ["rank,desc"],
		mode: input.mode,
		...filters ? { filters } : {}
	}], { classify: classifyBacklinksError }), assertOptions$1("/v3/backlinks/backlinks/live"));
	return {
		data: {
			items: parseTaskItems("backlinks-live", task, backlinksItemSchema),
			totalCount: parseTaskTotalCount(task)
		},
		billing: buildTaskBilling(task)
	};
}
async function fetchReferringDomains(input) {
	const filters = combineFilters(input.filters, input.hideSpam ?? true ? [
		"backlinks_spam_score",
		"<=",
		40
	] : void 0);
	const task = assertOk(await dataforseoPost("/v3/backlinks/referring_domains/live", [{
		...buildCommonPayload(input),
		limit: input.limit ?? 100,
		offset: input.offset,
		order_by: input.orderBy ?? ["backlinks,desc"],
		...filters ? { filters } : {}
	}], { classify: classifyBacklinksError }), assertOptions$1("/v3/backlinks/referring_domains/live"));
	return {
		data: {
			items: parseTaskItems("referring-domains-live", task, referringDomainItemSchema),
			totalCount: parseTaskTotalCount(task)
		},
		billing: buildTaskBilling(task)
	};
}
async function fetchDomainPagesSummary(input) {
	const filters = input.filters && input.filters.length > 0 ? input.filters : void 0;
	const task = assertOk(await dataforseoPost("/v3/backlinks/domain_pages_summary/live", [{
		...buildCommonPayload(input),
		limit: input.limit ?? 100,
		offset: input.offset,
		order_by: input.orderBy ?? ["backlinks,desc"],
		...filters ? { filters } : {}
	}], { classify: classifyBacklinksError }), assertOptions$1("/v3/backlinks/domain_pages_summary/live"));
	return {
		data: {
			items: parseTaskItems("domain-pages-summary-live", task, domainPageSummaryItemSchema),
			totalCount: parseTaskTotalCount(task)
		},
		billing: buildTaskBilling(task)
	};
}
async function fetchBacklinksHistory(input) {
	const task = assertOk(await dataforseoPost("/v3/backlinks/history/live", [{
		target: input.target,
		date_from: input.dateFrom,
		date_to: input.dateTo,
		rank_scale: "one_hundred"
	}], { classify: classifyBacklinksError }), assertOptions$1("/v3/backlinks/history/live"));
	return {
		data: parseTaskItems("backlinks-history-live", task, backlinksHistoryItemSchema),
		billing: buildTaskBilling(task)
	};
}
//#endregion
//#region src/server/lib/dataforseo/labs.ts
var rankedSerpItemSchema = object({
	url: string().nullable().optional(),
	relative_url: string().nullable().optional(),
	rank_absolute: number().nullable().optional(),
	etv: number().nullable().optional()
}).passthrough();
var domainRankedKeywordItemSchema = object({
	keyword_data: object({
		keyword: string().nullable().optional(),
		keyword_info: object({
			search_volume: number().nullable().optional(),
			cpc: number().nullable().optional(),
			keyword_difficulty: number().nullable().optional()
		}).passthrough().nullable().optional(),
		keyword_properties: object({ keyword_difficulty: number().nullable().optional() }).passthrough().nullable().optional()
	}).passthrough().nullable().optional(),
	ranked_serp_element: object({
		serp_item: rankedSerpItemSchema.nullable().optional(),
		url: string().nullable().optional(),
		relative_url: string().nullable().optional(),
		rank_absolute: number().nullable().optional(),
		etv: number().nullable().optional()
	}).passthrough().nullable().optional(),
	keyword: string().nullable().optional()
}).passthrough();
async function fetchRelatedKeywords(input) {
	const task = assertOk(await dataforseoPost("/v3/dataforseo_labs/google/related_keywords/live", [{
		keyword: input.keyword,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: input.limit,
		depth: input.depth ?? 3,
		ignore_synonyms: input.ignoreSynonyms ?? false,
		include_clickstream_data: input.includeClickstreamData ?? false,
		include_serp_info: false
	}]));
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
async function fetchKeywordSuggestions(input) {
	const task = assertOk(await dataforseoPost("/v3/dataforseo_labs/google/keyword_suggestions/live", [{
		keyword: input.keyword,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: input.limit,
		include_clickstream_data: input.includeClickstreamData ?? false,
		include_serp_info: false,
		include_seed_keyword: true,
		ignore_synonyms: input.ignoreSynonyms ?? false,
		exact_match: false,
		filters: input.filters
	}]));
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
async function fetchKeywordIdeas(input) {
	const task = assertOk(await dataforseoPost("/v3/dataforseo_labs/google/keyword_ideas/live", [{
		keywords: [input.keyword],
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: input.limit,
		include_clickstream_data: input.includeClickstreamData ?? false,
		include_serp_info: false,
		ignore_synonyms: input.ignoreSynonyms ?? false,
		closely_variants: false
	}]));
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
async function fetchDomainRankOverview(input) {
	const task = assertOk(await dataforseoPost("/v3/dataforseo_labs/google/domain_rank_overview/live", [{
		target: input.target,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: 1
	}]));
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
async function fetchRankedKeywords(input) {
	const task = assertOk(await dataforseoPost("/v3/dataforseo_labs/google/ranked_keywords/live", [{
		target: input.target,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: input.limit,
		offset: input.offset,
		order_by: input.orderBy,
		filters: input.filters,
		item_types: input.itemTypes
	}]));
	return {
		data: {
			items: parseTaskItems("google-ranked-keywords-live", task, domainRankedKeywordItemSchema),
			totalCount: task.result?.[0]?.total_count ?? null
		},
		billing: buildTaskBilling(task)
	};
}
async function fetchRelevantPages(input) {
	const task = assertOk(await dataforseoPost("/v3/dataforseo_labs/google/relevant_pages/live", [{
		target: input.target,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: input.limit,
		offset: input.offset,
		order_by: input.orderBy,
		filters: input.filters
	}]));
	return {
		data: {
			items: task.result?.[0]?.items ?? [],
			totalCount: task.result?.[0]?.total_count ?? null
		},
		billing: buildTaskBilling(task)
	};
}
async function fetchKeywordOverview(input) {
	const task = assertOk(await dataforseoPost("/v3/dataforseo_labs/google/keyword_overview/live", [{
		keywords: input.keywords,
		location_code: input.locationCode,
		language_code: input.languageCode,
		include_clickstream_data: input.includeClickstreamData ?? false
	}]));
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
async function fetchSerpCompetitors(input) {
	const task = assertOk(await dataforseoPost("/v3/dataforseo_labs/google/serp_competitors/live", [{
		keywords: input.keywords,
		location_code: input.locationCode,
		language_code: input.languageCode,
		item_types: input.itemTypes,
		include_subdomains: input.includeSubdomains,
		limit: input.limit,
		offset: input.offset
	}]));
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
//#endregion
//#region src/server/lib/dataforseo/google-ads.ts
function taskItems(task) {
	return task.result ?? [];
}
function adsLanguageCode(languageCode) {
	return languageCode === "nb" ? "no" : languageCode;
}
async function fetchAdsSearchVolume(input) {
	const locationParams = input.locationName ? { location_name: input.locationName } : { location_code: input.locationCode };
	const task = assertOk(await dataforseoPost("/v3/keywords_data/google_ads/search_volume/live", [{
		keywords: input.keywords,
		...locationParams,
		language_code: adsLanguageCode(input.languageCode)
	}]));
	return {
		data: taskItems(task),
		billing: buildTaskBilling(task)
	};
}
async function fetchAdsKeywordIdeas(input) {
	const task = assertOk(await dataforseoPost("/v3/keywords_data/google_ads/keywords_for_keywords/live", [{
		keywords: [input.keyword],
		location_code: input.locationCode,
		language_code: adsLanguageCode(input.languageCode),
		sort_by: "search_volume"
	}]));
	return {
		data: taskItems(task).slice(0, input.limit),
		billing: buildTaskBilling(task)
	};
}
//#endregion
//#region src/shared/keyword-locations.ts
/**
* shortLabel is a *display* label; the one entry that diverges from ISO
* 3166-1 alpha-2 is the United Kingdom ("UK" reads better, ISO is "GB").
*/
var ISO_COUNTRY_OVERRIDES = { UK: "GB" };
/**
* Lowercase ISO 3166-1 alpha-2 code for a country location_code \u2014 the format
* DataForSEO's per-country endpoints (e.g. SERP locations) require.
*/
function getIsoCountryCode(locationCode) {
	const shortLabel = LOCATION_OPTIONS.find((option) => option.code === locationCode)?.shortLabel ?? "US";
	return (ISO_COUNTRY_OVERRIDES[shortLabel] ?? shortLabel).toLowerCase();
}
var LOCATION_OPTIONS = [
	{
		code: 2008,
		label: "Albania",
		shortLabel: "AL",
		languageCode: "sq"
	},
	{
		code: 2012,
		label: "Algeria",
		shortLabel: "DZ",
		languageCode: "fr"
	},
	{
		code: 2020,
		label: "Andorra",
		shortLabel: "AD",
		languageCode: "ca",
		googleAdsOnly: true
	},
	{
		code: 2024,
		label: "Angola",
		shortLabel: "AO",
		languageCode: "pt"
	},
	{
		code: 2032,
		label: "Argentina",
		shortLabel: "AR",
		languageCode: "es"
	},
	{
		code: 2051,
		label: "Armenia",
		shortLabel: "AM",
		languageCode: "hy"
	},
	{
		code: 2036,
		label: "Australia",
		shortLabel: "AU",
		languageCode: "en"
	},
	{
		code: 2040,
		label: "Austria",
		shortLabel: "AT",
		languageCode: "de"
	},
	{
		code: 2031,
		label: "Azerbaijan",
		shortLabel: "AZ",
		languageCode: "az"
	},
	{
		code: 2044,
		label: "Bahamas",
		shortLabel: "BS",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2048,
		label: "Bahrain",
		shortLabel: "BH",
		languageCode: "ar"
	},
	{
		code: 2050,
		label: "Bangladesh",
		shortLabel: "BD",
		languageCode: "bn"
	},
	{
		code: 2052,
		label: "Barbados",
		shortLabel: "BB",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2056,
		label: "Belgium",
		shortLabel: "BE",
		languageCode: "nl"
	},
	{
		code: 2084,
		label: "Belize",
		shortLabel: "BZ",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2068,
		label: "Bolivia",
		shortLabel: "BO",
		languageCode: "es"
	},
	{
		code: 2070,
		label: "Bosnia and Herzegovina",
		shortLabel: "BA",
		languageCode: "bs"
	},
	{
		code: 2072,
		label: "Botswana",
		shortLabel: "BW",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2076,
		label: "Brazil",
		shortLabel: "BR",
		languageCode: "pt"
	},
	{
		code: 2096,
		label: "Brunei",
		shortLabel: "BN",
		languageCode: "ms",
		googleAdsOnly: true
	},
	{
		code: 2100,
		label: "Bulgaria",
		shortLabel: "BG",
		languageCode: "bg"
	},
	{
		code: 2854,
		label: "Burkina Faso",
		shortLabel: "BF",
		languageCode: "fr"
	},
	{
		code: 2116,
		label: "Cambodia",
		shortLabel: "KH",
		languageCode: "en"
	},
	{
		code: 2120,
		label: "Cameroon",
		shortLabel: "CM",
		languageCode: "fr"
	},
	{
		code: 2124,
		label: "Canada",
		shortLabel: "CA",
		languageCode: "en"
	},
	{
		code: 2152,
		label: "Chile",
		shortLabel: "CL",
		languageCode: "es"
	},
	{
		code: 2170,
		label: "Colombia",
		shortLabel: "CO",
		languageCode: "es"
	},
	{
		code: 2188,
		label: "Costa Rica",
		shortLabel: "CR",
		languageCode: "es"
	},
	{
		code: 2384,
		label: "Cote d'Ivoire",
		shortLabel: "CI",
		languageCode: "fr"
	},
	{
		code: 2191,
		label: "Croatia",
		shortLabel: "HR",
		languageCode: "hr"
	},
	{
		code: 2196,
		label: "Cyprus",
		shortLabel: "CY",
		languageCode: "el"
	},
	{
		code: 2203,
		label: "Czechia",
		shortLabel: "CZ",
		languageCode: "cs"
	},
	{
		code: 2208,
		label: "Denmark",
		shortLabel: "DK",
		languageCode: "da"
	},
	{
		code: 2214,
		label: "Dominican Republic",
		shortLabel: "DO",
		languageCode: "es",
		googleAdsOnly: true
	},
	{
		code: 2218,
		label: "Ecuador",
		shortLabel: "EC",
		languageCode: "es"
	},
	{
		code: 2818,
		label: "Egypt",
		shortLabel: "EG",
		languageCode: "ar"
	},
	{
		code: 2222,
		label: "El Salvador",
		shortLabel: "SV",
		languageCode: "es"
	},
	{
		code: 2233,
		label: "Estonia",
		shortLabel: "EE",
		languageCode: "et"
	},
	{
		code: 2231,
		label: "Ethiopia",
		shortLabel: "ET",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2242,
		label: "Fiji",
		shortLabel: "FJ",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2246,
		label: "Finland",
		shortLabel: "FI",
		languageCode: "fi"
	},
	{
		code: 2250,
		label: "France",
		shortLabel: "FR",
		languageCode: "fr"
	},
	{
		code: 2268,
		label: "Georgia",
		shortLabel: "GE",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2276,
		label: "Germany",
		shortLabel: "DE",
		languageCode: "de"
	},
	{
		code: 2288,
		label: "Ghana",
		shortLabel: "GH",
		languageCode: "en"
	},
	{
		code: 2300,
		label: "Greece",
		shortLabel: "GR",
		languageCode: "el"
	},
	{
		code: 2320,
		label: "Guatemala",
		shortLabel: "GT",
		languageCode: "es"
	},
	{
		code: 2831,
		label: "Guernsey",
		shortLabel: "GG",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2328,
		label: "Guyana",
		shortLabel: "GY",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2332,
		label: "Haiti",
		shortLabel: "HT",
		languageCode: "fr",
		googleAdsOnly: true
	},
	{
		code: 2340,
		label: "Honduras",
		shortLabel: "HN",
		languageCode: "es",
		googleAdsOnly: true
	},
	{
		code: 2344,
		label: "Hong Kong",
		shortLabel: "HK",
		languageCode: "zh-TW"
	},
	{
		code: 2348,
		label: "Hungary",
		shortLabel: "HU",
		languageCode: "hu"
	},
	{
		code: 2352,
		label: "Iceland",
		shortLabel: "IS",
		languageCode: "is",
		googleAdsOnly: true
	},
	{
		code: 2356,
		label: "India",
		shortLabel: "IN",
		languageCode: "en"
	},
	{
		code: 2360,
		label: "Indonesia",
		shortLabel: "ID",
		languageCode: "id"
	},
	{
		code: 2368,
		label: "Iraq",
		shortLabel: "IQ",
		languageCode: "ar",
		googleAdsOnly: true
	},
	{
		code: 2372,
		label: "Ireland",
		shortLabel: "IE",
		languageCode: "en"
	},
	{
		code: 2833,
		label: "Isle of Man",
		shortLabel: "IM",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2376,
		label: "Israel",
		shortLabel: "IL",
		languageCode: "he"
	},
	{
		code: 2380,
		label: "Italy",
		shortLabel: "IT",
		languageCode: "it"
	},
	{
		code: 2388,
		label: "Jamaica",
		shortLabel: "JM",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2392,
		label: "Japan",
		shortLabel: "JP",
		languageCode: "ja"
	},
	{
		code: 2832,
		label: "Jersey",
		shortLabel: "JE",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2400,
		label: "Jordan",
		shortLabel: "JO",
		languageCode: "ar"
	},
	{
		code: 2398,
		label: "Kazakhstan",
		shortLabel: "KZ",
		languageCode: "ru"
	},
	{
		code: 2404,
		label: "Kenya",
		shortLabel: "KE",
		languageCode: "en"
	},
	{
		code: 2414,
		label: "Kuwait",
		shortLabel: "KW",
		languageCode: "ar",
		googleAdsOnly: true
	},
	{
		code: 2417,
		label: "Kyrgyzstan",
		shortLabel: "KG",
		languageCode: "ru",
		googleAdsOnly: true
	},
	{
		code: 2418,
		label: "Laos",
		shortLabel: "LA",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2428,
		label: "Latvia",
		shortLabel: "LV",
		languageCode: "lv"
	},
	{
		code: 2422,
		label: "Lebanon",
		shortLabel: "LB",
		languageCode: "ar",
		googleAdsOnly: true
	},
	{
		code: 2438,
		label: "Liechtenstein",
		shortLabel: "LI",
		languageCode: "de",
		googleAdsOnly: true
	},
	{
		code: 2440,
		label: "Lithuania",
		shortLabel: "LT",
		languageCode: "lt"
	},
	{
		code: 2442,
		label: "Luxembourg",
		shortLabel: "LU",
		languageCode: "fr",
		googleAdsOnly: true
	},
	{
		code: 2450,
		label: "Madagascar",
		shortLabel: "MG",
		languageCode: "fr",
		googleAdsOnly: true
	},
	{
		code: 2454,
		label: "Malawi",
		shortLabel: "MW",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2458,
		label: "Malaysia",
		shortLabel: "MY",
		languageCode: "en"
	},
	{
		code: 2462,
		label: "Maldives",
		shortLabel: "MV",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2470,
		label: "Malta",
		shortLabel: "MT",
		languageCode: "en"
	},
	{
		code: 2480,
		label: "Mauritius",
		shortLabel: "MU",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2484,
		label: "Mexico",
		shortLabel: "MX",
		languageCode: "es"
	},
	{
		code: 2498,
		label: "Moldova",
		shortLabel: "MD",
		languageCode: "ro"
	},
	{
		code: 2492,
		label: "Monaco",
		shortLabel: "MC",
		languageCode: "fr"
	},
	{
		code: 2496,
		label: "Mongolia",
		shortLabel: "MN",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2499,
		label: "Montenegro",
		shortLabel: "ME",
		languageCode: "sr",
		googleAdsOnly: true
	},
	{
		code: 2504,
		label: "Morocco",
		shortLabel: "MA",
		languageCode: "ar"
	},
	{
		code: 2508,
		label: "Mozambique",
		shortLabel: "MZ",
		languageCode: "pt",
		googleAdsOnly: true
	},
	{
		code: 2104,
		label: "Myanmar (Burma)",
		shortLabel: "MM",
		languageCode: "en"
	},
	{
		code: 2516,
		label: "Namibia",
		shortLabel: "NA",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2524,
		label: "Nepal",
		shortLabel: "NP",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2528,
		label: "Netherlands",
		shortLabel: "NL",
		languageCode: "nl"
	},
	{
		code: 2554,
		label: "New Zealand",
		shortLabel: "NZ",
		languageCode: "en"
	},
	{
		code: 2558,
		label: "Nicaragua",
		shortLabel: "NI",
		languageCode: "es"
	},
	{
		code: 2566,
		label: "Nigeria",
		shortLabel: "NG",
		languageCode: "en"
	},
	{
		code: 2807,
		label: "North Macedonia",
		shortLabel: "MK",
		languageCode: "mk"
	},
	{
		code: 2578,
		label: "Norway",
		shortLabel: "NO",
		languageCode: "nb"
	},
	{
		code: 2512,
		label: "Oman",
		shortLabel: "OM",
		languageCode: "ar",
		googleAdsOnly: true
	},
	{
		code: 2586,
		label: "Pakistan",
		shortLabel: "PK",
		languageCode: "en"
	},
	{
		code: 2275,
		label: "Palestine",
		shortLabel: "PS",
		languageCode: "ar",
		googleAdsOnly: true
	},
	{
		code: 2591,
		label: "Panama",
		shortLabel: "PA",
		languageCode: "es"
	},
	{
		code: 2598,
		label: "Papua New Guinea",
		shortLabel: "PG",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2600,
		label: "Paraguay",
		shortLabel: "PY",
		languageCode: "es"
	},
	{
		code: 2604,
		label: "Peru",
		shortLabel: "PE",
		languageCode: "es"
	},
	{
		code: 2608,
		label: "Philippines",
		shortLabel: "PH",
		languageCode: "en"
	},
	{
		code: 2616,
		label: "Poland",
		shortLabel: "PL",
		languageCode: "pl"
	},
	{
		code: 2620,
		label: "Portugal",
		shortLabel: "PT",
		languageCode: "pt"
	},
	{
		code: 2634,
		label: "Qatar",
		shortLabel: "QA",
		languageCode: "ar",
		googleAdsOnly: true
	},
	{
		code: 2642,
		label: "Romania",
		shortLabel: "RO",
		languageCode: "ro"
	},
	{
		code: 2646,
		label: "Rwanda",
		shortLabel: "RW",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2674,
		label: "San Marino",
		shortLabel: "SM",
		languageCode: "it",
		googleAdsOnly: true
	},
	{
		code: 2682,
		label: "Saudi Arabia",
		shortLabel: "SA",
		languageCode: "ar"
	},
	{
		code: 2686,
		label: "Senegal",
		shortLabel: "SN",
		languageCode: "fr"
	},
	{
		code: 2688,
		label: "Serbia",
		shortLabel: "RS",
		languageCode: "sr"
	},
	{
		code: 2702,
		label: "Singapore",
		shortLabel: "SG",
		languageCode: "en"
	},
	{
		code: 2703,
		label: "Slovakia",
		shortLabel: "SK",
		languageCode: "sk"
	},
	{
		code: 2705,
		label: "Slovenia",
		shortLabel: "SI",
		languageCode: "sl"
	},
	{
		code: 2710,
		label: "South Africa",
		shortLabel: "ZA",
		languageCode: "en"
	},
	{
		code: 2410,
		label: "South Korea",
		shortLabel: "KR",
		languageCode: "ko"
	},
	{
		code: 2724,
		label: "Spain",
		shortLabel: "ES",
		languageCode: "es"
	},
	{
		code: 2144,
		label: "Sri Lanka",
		shortLabel: "LK",
		languageCode: "en"
	},
	{
		code: 2740,
		label: "Suriname",
		shortLabel: "SR",
		languageCode: "nl",
		googleAdsOnly: true
	},
	{
		code: 2752,
		label: "Sweden",
		shortLabel: "SE",
		languageCode: "sv"
	},
	{
		code: 2756,
		label: "Switzerland",
		shortLabel: "CH",
		languageCode: "de"
	},
	{
		code: 2158,
		label: "Taiwan",
		shortLabel: "TW",
		languageCode: "zh-TW"
	},
	{
		code: 2762,
		label: "Tajikistan",
		shortLabel: "TJ",
		languageCode: "ru",
		googleAdsOnly: true
	},
	{
		code: 2834,
		label: "Tanzania",
		shortLabel: "TZ",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2764,
		label: "Thailand",
		shortLabel: "TH",
		languageCode: "th"
	},
	{
		code: 2780,
		label: "Trinidad and Tobago",
		shortLabel: "TT",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2788,
		label: "Tunisia",
		shortLabel: "TN",
		languageCode: "ar"
	},
	{
		code: 2792,
		label: "Turkiye",
		shortLabel: "TR",
		languageCode: "tr"
	},
	{
		code: 2795,
		label: "Turkmenistan",
		shortLabel: "TM",
		languageCode: "ru",
		googleAdsOnly: true
	},
	{
		code: 2800,
		label: "Uganda",
		shortLabel: "UG",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2804,
		label: "Ukraine",
		shortLabel: "UA",
		languageCode: "uk"
	},
	{
		code: 2784,
		label: "United Arab Emirates",
		shortLabel: "AE",
		languageCode: "en"
	},
	{
		code: 2826,
		label: "United Kingdom",
		shortLabel: "UK",
		languageCode: "en"
	},
	{
		code: 2840,
		label: "United States",
		shortLabel: "US",
		languageCode: "en"
	},
	{
		code: 2858,
		label: "Uruguay",
		shortLabel: "UY",
		languageCode: "es"
	},
	{
		code: 2860,
		label: "Uzbekistan",
		shortLabel: "UZ",
		languageCode: "ru",
		googleAdsOnly: true
	},
	{
		code: 2862,
		label: "Venezuela",
		shortLabel: "VE",
		languageCode: "es"
	},
	{
		code: 2704,
		label: "Vietnam",
		shortLabel: "VN",
		languageCode: "vi"
	},
	{
		code: 2894,
		label: "Zambia",
		shortLabel: "ZM",
		languageCode: "en",
		googleAdsOnly: true
	},
	{
		code: 2716,
		label: "Zimbabwe",
		shortLabel: "ZW",
		languageCode: "en",
		googleAdsOnly: true
	}
];
/**
* Languages selectable for rank tracking, which runs against the DataForSEO
* SERP (Google) API. This is the full set of language codes that API accepts;
* source/refresh it from the live endpoint (auth required):
*   GET https://api.dataforseo.com/v3/serp/google/languages
* (Country list above comes from the sibling Labs endpoint cited at the top of
* this file: /v3/dataforseo_labs/locations_and_languages.)
*
* `code` is the DataForSEO `language_code` (authoritative); `label` is its
* `language_name`, lightly cleaned for display. Deviations from the raw
* endpoint: the deprecated `iw` Hebrew alias and the redundant `no` are
* dropped (Norway uses `nb`, which both SERP and Labs accept). Every country
* default in LOCATION_OPTIONS must appear here so the picker can show it.
*
* This is the master list. Rank tracking (SERP) offers all of it for any
* country; the Labs-backed project picker shows a per-country subset via
* getLanguageOptions() below.
*/
var SERP_LANGUAGE_OPTIONS = [
	{
		code: "af",
		label: "Afrikaans"
	},
	{
		code: "ak",
		label: "Akan"
	},
	{
		code: "sq",
		label: "Albanian"
	},
	{
		code: "am",
		label: "Amharic"
	},
	{
		code: "ar",
		label: "Arabic"
	},
	{
		code: "hy",
		label: "Armenian"
	},
	{
		code: "az",
		label: "Azerbaijani"
	},
	{
		code: "ban",
		label: "Balinese"
	},
	{
		code: "eu",
		label: "Basque"
	},
	{
		code: "be",
		label: "Belarusian"
	},
	{
		code: "bn",
		label: "Bengali"
	},
	{
		code: "bs",
		label: "Bosnian"
	},
	{
		code: "bg",
		label: "Bulgarian"
	},
	{
		code: "my",
		label: "Burmese"
	},
	{
		code: "ca",
		label: "Catalan"
	},
	{
		code: "ceb",
		label: "Cebuano"
	},
	{
		code: "ny",
		label: "Chichewa"
	},
	{
		code: "zh-CN",
		label: "Chinese (Simplified)"
	},
	{
		code: "zh-TW",
		label: "Chinese (Traditional)"
	},
	{
		code: "hr",
		label: "Croatian"
	},
	{
		code: "cs",
		label: "Czech"
	},
	{
		code: "da",
		label: "Danish"
	},
	{
		code: "nl",
		label: "Dutch"
	},
	{
		code: "en",
		label: "English"
	},
	{
		code: "et",
		label: "Estonian"
	},
	{
		code: "ee",
		label: "Ewe"
	},
	{
		code: "fo",
		label: "Faroese"
	},
	{
		code: "fa",
		label: "Farsi"
	},
	{
		code: "fil",
		label: "Filipino"
	},
	{
		code: "fi",
		label: "Finnish"
	},
	{
		code: "fr",
		label: "French"
	},
	{
		code: "fy",
		label: "Frisian"
	},
	{
		code: "gaa",
		label: "Ga"
	},
	{
		code: "gl",
		label: "Galician"
	},
	{
		code: "lg",
		label: "Ganda"
	},
	{
		code: "ka",
		label: "Georgian"
	},
	{
		code: "de",
		label: "German"
	},
	{
		code: "el",
		label: "Greek"
	},
	{
		code: "gu",
		label: "Gujarati"
	},
	{
		code: "ht",
		label: "Haitian"
	},
	{
		code: "ha",
		label: "Hausa"
	},
	{
		code: "he",
		label: "Hebrew"
	},
	{
		code: "hi",
		label: "Hindi"
	},
	{
		code: "hu",
		label: "Hungarian"
	},
	{
		code: "is",
		label: "Icelandic"
	},
	{
		code: "bem",
		label: "IciBemba"
	},
	{
		code: "ig",
		label: "Igbo"
	},
	{
		code: "id",
		label: "Indonesian"
	},
	{
		code: "ga",
		label: "Irish"
	},
	{
		code: "it",
		label: "Italian"
	},
	{
		code: "ja",
		label: "Japanese"
	},
	{
		code: "kn",
		label: "Kannada"
	},
	{
		code: "kk",
		label: "Kazakh"
	},
	{
		code: "km",
		label: "Khmer"
	},
	{
		code: "rw",
		label: "Kinyarwanda"
	},
	{
		code: "rn",
		label: "Kirundi"
	},
	{
		code: "kg",
		label: "Kongo"
	},
	{
		code: "ko",
		label: "Korean"
	},
	{
		code: "mfe",
		label: "Kreol morisien"
	},
	{
		code: "crs",
		label: "Kreol Seselwa"
	},
	{
		code: "kri",
		label: "Krio"
	},
	{
		code: "ckb",
		label: "Kurdish"
	},
	{
		code: "ky",
		label: "Kyrgyz"
	},
	{
		code: "lo",
		label: "Lao"
	},
	{
		code: "lv",
		label: "Latvian"
	},
	{
		code: "ln",
		label: "Lingala"
	},
	{
		code: "lt",
		label: "Lithuanian"
	},
	{
		code: "ach",
		label: "Luo"
	},
	{
		code: "mk",
		label: "Macedonian"
	},
	{
		code: "mg",
		label: "Malagasy"
	},
	{
		code: "ms",
		label: "Malay"
	},
	{
		code: "ml",
		label: "Malayalam"
	},
	{
		code: "mt",
		label: "Maltese"
	},
	{
		code: "mi",
		label: "Maori"
	},
	{
		code: "mr",
		label: "Marathi"
	},
	{
		code: "mn",
		label: "Mongolian"
	},
	{
		code: "ne",
		label: "Nepali"
	},
	{
		code: "nso",
		label: "Northern Sotho"
	},
	{
		code: "nb",
		label: "Norwegian (Bokm\u00E5l)"
	},
	{
		code: "nyn",
		label: "Nyankole"
	},
	{
		code: "om",
		label: "Oromo"
	},
	{
		code: "ps",
		label: "Pashto"
	},
	{
		code: "pcm",
		label: "Pidgin"
	},
	{
		code: "pl",
		label: "Polish"
	},
	{
		code: "pt",
		label: "Portuguese"
	},
	{
		code: "pt-BR",
		label: "Portuguese (Brazil)"
	},
	{
		code: "pt-PT",
		label: "Portuguese (Portugal)"
	},
	{
		code: "pa",
		label: "Punjabi"
	},
	{
		code: "qu",
		label: "Quechua"
	},
	{
		code: "ro",
		label: "Romanian"
	},
	{
		code: "rm",
		label: "Romansh"
	},
	{
		code: "ru",
		label: "Russian"
	},
	{
		code: "sr",
		label: "Serbian"
	},
	{
		code: "sr-Latn",
		label: "Serbian (Latin)"
	},
	{
		code: "sr-ME",
		label: "Serbian (Montenegro)"
	},
	{
		code: "st",
		label: "Sesotho"
	},
	{
		code: "sn",
		label: "Shona"
	},
	{
		code: "loz",
		label: "Silozi"
	},
	{
		code: "sd",
		label: "Sindhi"
	},
	{
		code: "si",
		label: "Sinhalese"
	},
	{
		code: "sk",
		label: "Slovak"
	},
	{
		code: "sl",
		label: "Slovenian"
	},
	{
		code: "so",
		label: "Somali"
	},
	{
		code: "es",
		label: "Spanish"
	},
	{
		code: "es-419",
		label: "Spanish (Latin America)"
	},
	{
		code: "sw",
		label: "Swahili"
	},
	{
		code: "sv",
		label: "Swedish"
	},
	{
		code: "tl",
		label: "Tagalog"
	},
	{
		code: "tg",
		label: "Tajik"
	},
	{
		code: "ta",
		label: "Tamil"
	},
	{
		code: "te",
		label: "Telugu"
	},
	{
		code: "th",
		label: "Thai"
	},
	{
		code: "ti",
		label: "Tigrinya"
	},
	{
		code: "to",
		label: "Tonga (Tonga Islands)"
	},
	{
		code: "lua",
		label: "Tshiluba"
	},
	{
		code: "tn",
		label: "Tswana"
	},
	{
		code: "tum",
		label: "Tumbuka"
	},
	{
		code: "tr",
		label: "Turkish"
	},
	{
		code: "tk",
		label: "Turkmen"
	},
	{
		code: "uk",
		label: "Ukrainian"
	},
	{
		code: "ur",
		label: "Urdu"
	},
	{
		code: "uz",
		label: "Uzbek"
	},
	{
		code: "vi",
		label: "Vietnamese"
	},
	{
		code: "cy",
		label: "Welsh"
	},
	{
		code: "wo",
		label: "Wolof"
	},
	{
		code: "xh",
		label: "Xhosa"
	},
	{
		code: "yo",
		label: "Yoruba"
	},
	{
		code: "zu",
		label: "Zulu"
	}
];
/** Countries usable by DataForSEO Labs features (domain overview etc.). */
var LABS_LOCATION_OPTIONS = LOCATION_OPTIONS.filter((option) => !option.googleAdsOnly);
new Set(LOCATION_OPTIONS.map((option) => option.code));
new Set(LABS_LOCATION_OPTIONS.map((option) => option.code));
Object.fromEntries(LOCATION_OPTIONS.map((option) => [option.code, option.shortLabel]));
Object.fromEntries(LOCATION_OPTIONS.map((option) => [option.code, option.languageCode]));
new Set(SERP_LANGUAGE_OPTIONS.map((language) => language.code));
//#endregion
//#region src/shared/google-serp-url.ts
/** Google wraps many organic results in a google.com/goto redirect. */
function isGoogleRedirect(url) {
	try {
		const parsed = new URL(url);
		return parsed.pathname === "/goto" && /^(www\.)?google\.[a-z.]+$/.test(parsed.hostname);
	} catch {
		return false;
	}
}
//#endregion
//#region src/shared/rank-tracking.ts
/** DataForSEO task queue (standard priority): cost of first page (10 results) */
var QUEUED_BASE_PAGE_COST_USD = 6e-4;
/** DataForSEO task queue (standard priority): cost of each additional page (75% of base) */
var QUEUED_EXTRA_PAGE_COST_USD = 45e-5;
/** DataForSEO cost for a single standard-queue SERP read at the given depth. */
function costPerSerpAtDepth(depth) {
	return QUEUED_BASE_PAGE_COST_USD + (depth / 10 - 1) * QUEUED_EXTRA_PAGE_COST_USD;
}
var SERP_OPERATOR_KEYWORD = /(allinanchor|allintext|allintitle|allinurl|cache|define|definition|filetype|id|inanchor|info|intext|intitle|inurl|link|site):/i;
function serpKeywordCostMultiplier(keyword) {
	return SERP_OPERATOR_KEYWORD.test(keyword) ? 5 : 1;
}
/** High priority finishes in ~10-40 s; the normal queue takes minutes. */
var TASK_PRIORITY_HIGH = 2;
/** DataForSEO bills SERPs in pages of 10; depth outside 10-100 is rejected. */
function clampSerpDepth(depth) {
	return Math.min(100, Math.max(10, depth));
}
object({
	type: string(),
	rank_group: number().nullable().optional(),
	rank_absolute: number().nullable().optional(),
	domain: string().nullable().optional(),
	title: string().nullable().optional(),
	url: string().nullable().optional(),
	description: string().nullable().optional(),
	breadcrumb: string().nullable().optional(),
	etv: number().nullable().optional(),
	estimated_paid_traffic_cost: number().nullable().optional(),
	backlinks_info: object({
		referring_domains: number().nullable().optional(),
		backlinks: number().nullable().optional()
	}).passthrough().nullable().optional(),
	rank_changes: object({
		previous_rank_absolute: number().nullable().optional(),
		is_new: boolean().nullable().optional(),
		is_up: boolean().nullable().optional(),
		is_down: boolean().nullable().optional()
	}).passthrough().nullable().optional()
}).passthrough().transform(unwrapGoogleRedirect);
/**
* Google wraps many organic results in a google.com/goto redirect, and
* DataForSEO reports them with domain "google.com" and an encoded URL. The
* real site is only in the breadcrumb ("https://www.runnersworld.com \u203a gear").
* When the breadcrumb isn't a URL (Reddit's "230+ comments") the domain is
* unknown, which beats crediting google.com with the result.
*/
function unwrapGoogleRedirect(item) {
	if (!item.url || !isGoogleRedirect(item.url)) return item;
	return {
		...item,
		domain: breadcrumbHost(item.breadcrumb)
	};
}
function breadcrumbHost(breadcrumb) {
	const first = breadcrumb?.split("\u203A")[0]?.trim();
	if (!first || !/^https?:\/\//i.test(first)) return null;
	try {
		return new URL(first).hostname.toLowerCase().replace(/^www\./, "");
	} catch {
		return null;
	}
}
function serpQueryParams(input) {
	const device = input.device ?? "desktop";
	const locationParams = input.locationName ? { location_name: input.locationName } : { location_code: input.locationCode };
	return {
		keyword: input.keyword,
		...locationParams,
		language_code: input.languageCode,
		device,
		os: device === "desktop" ? "windows" : "android",
		depth: clampSerpDepth(input.depth ?? 10)
	};
}
async function postRankCheckTasks(input) {
	if (input.tasks.length === 0 || input.tasks.length > 100) throw new AppError("INTERNAL_ERROR", `task_post accepts 1-100 tasks, got ${input.tasks.length}`);
	const depth = clampSerpDepth(input.depth);
	const locationParams = input.locationName ? { location_name: input.locationName } : { location_code: input.locationCode };
	const response = await dataforseoPost("/v3/serp/google/organic/task_post", input.tasks.map((task) => ({
		keyword: task.keyword,
		...locationParams,
		language_code: input.languageCode,
		device: task.device,
		os: task.device === "desktop" ? "windows" : "android",
		depth,
		tag: `${task.keywordId}:${task.device}`
	})));
	if (!response || response.status_code !== 2e4) throw failedResponseError(response, "DataForSEO task_post failed");
	const byTag = new Map(input.tasks.map((task) => [`${task.keywordId}:${task.device}`, task]));
	const posted = [];
	let costUsd = 0;
	for (const entry of response.tasks ?? []) {
		costUsd += entry.cost ?? 0;
		const tag = entry.data?.tag;
		const task = typeof tag === "string" ? byTag.get(tag) : void 0;
		if (entry.status_code !== 20100 || !entry.id || !task) {
			console.warn(`dataforseo.task_post.rejected-entry (${entry.status_code}): ${entry.status_message}`);
			continue;
		}
		posted.push({
			...task,
			taskId: entry.id
		});
	}
	return {
		data: posted,
		billing: {
			path: [
				"v3",
				"serp",
				"google",
				"organic",
				"task_post"
			],
			costUsd
		}
	};
}
/**
* Posts one query's reads and returns the accepted task ids. Not retried on a
* 5xx, which does not prove the post went unbilled.
*/
async function postSerpReadTasks(input) {
	const response = await dataforseoPost("/v3/serp/google/organic/task_post", Array.from({ length: 3 }, () => ({
		...serpQueryParams(input),
		priority: TASK_PRIORITY_HIGH
	})), { maxServerErrorRetries: 0 });
	if (!response || response.status_code !== 2e4) throw failedResponseError(response, "DataForSEO task_post failed");
	const taskIds = [];
	let costUsd = 0;
	for (const entry of response.tasks ?? []) {
		costUsd += entry.cost ?? 0;
		if (entry.status_code === 20100 && entry.id) taskIds.push(entry.id);
		else console.warn(`dataforseo.task_post.rejected-entry (${entry.status_code}): ${entry.status_message}`);
	}
	const billing = {
		path: [
			"v3",
			"serp",
			"google",
			"organic",
			"task_post"
		],
		costUsd
	};
	if (taskIds.length === 0) {
		const message = response.tasks?.[0]?.status_message || "DataForSEO created no tasks";
		throw new DataforseoChargedTaskError(message, billing, invalidFieldName(message) !== null);
	}
	return {
		data: taskIds,
		billing
	};
}
async function fetchLocalSerp(input) {
	const os = input.device === "desktop" ? "windows" : "android";
	if (input.searchType === "maps") {
		const task = assertOk(await dataforseoPost("/v3/serp/google/maps/live/advanced", [{
			keyword: input.keyword,
			location_coordinate: input.locationCoordinate,
			location_name: input.locationName,
			language_code: input.languageCode,
			device: input.device,
			os,
			depth: input.depth,
			search_places: input.searchPlaces
		}]), { treatNoResultsAsEmpty: true });
		return {
			data: task.result?.[0]?.items ?? [],
			billing: buildTaskBilling(task)
		};
	}
	const task = assertOk(await dataforseoPost("/v3/serp/google/local_finder/live/advanced", [{
		keyword: input.keyword,
		location_coordinate: input.locationCoordinate,
		location_name: input.locationName,
		language_code: input.languageCode,
		device: input.device,
		os,
		depth: input.depth
	}]), { treatNoResultsAsEmpty: true });
	return {
		data: task.result?.[0]?.items ?? [],
		billing: buildTaskBilling(task)
	};
}
/**
* Posts one Maps task per coordinate and returns the task ids in input
* order, null where DataForSEO rejected an entry. Not retried on a 5xx,
* which does not prove the post went unbilled.
*/
async function postLocalSerpTasks(input) {
	const response = await dataforseoPost("/v3/serp/google/maps/task_post", input.locationCoordinates.map((coordinate, index) => ({
		keyword: input.keyword,
		location_coordinate: coordinate,
		language_code: input.languageCode,
		device: input.device,
		os: input.device === "desktop" ? "windows" : "android",
		depth: input.depth,
		search_places: false,
		priority: TASK_PRIORITY_HIGH,
		tag: String(index)
	})), { maxServerErrorRetries: 0 });
	if (!response || response.status_code !== 2e4) throw failedResponseError(response, "DataForSEO task_post failed");
	const taskIds = input.locationCoordinates.map(() => null);
	let costUsd = 0;
	for (const entry of response.tasks ?? []) {
		costUsd += entry.cost ?? 0;
		const index = Number(entry.data?.tag);
		if (entry.status_code === 20100 && entry.id && taskIds[index] === null) taskIds[index] = entry.id;
		else console.warn(`dataforseo.task_post.rejected-entry (${entry.status_code}): ${entry.status_message}`);
	}
	const billing = {
		path: [
			"v3",
			"serp",
			"google",
			"maps",
			"task_post"
		],
		costUsd
	};
	if (taskIds.every((id) => id === null)) {
		const message = response.tasks?.[0]?.status_message || "DataForSEO created no tasks";
		throw new DataforseoChargedTaskError(message, billing, invalidFieldName(message) !== null);
	}
	return {
		data: taskIds,
		billing
	};
}
//#endregion
//#region src/shared/lighthouse.ts
var LIGHTHOUSE_CATEGORIES = [
	"performance",
	"accessibility",
	"best-practices",
	"seo"
];
[...LIGHTHOUSE_CATEGORIES];
//#endregion
//#region src/server/lib/lighthouseStoredPayload.ts
var storedLighthouseMetricSchema = object({
	score: number().nullable(),
	displayValue: string().nullable(),
	numericValue: number().nullable()
});
var storedLighthouseMetricsSchema = object({
	firstContentfulPaint: storedLighthouseMetricSchema,
	largestContentfulPaint: storedLighthouseMetricSchema,
	totalBlockingTime: storedLighthouseMetricSchema,
	cumulativeLayoutShift: storedLighthouseMetricSchema,
	speedIndex: storedLighthouseMetricSchema,
	timeToInteractive: storedLighthouseMetricSchema,
	interactionToNextPaint: storedLighthouseMetricSchema,
	serverResponseTime: storedLighthouseMetricSchema
});
var storedLighthouseIssueSchema = object({
	category: _enum(LIGHTHOUSE_CATEGORIES),
	auditKey: string(),
	title: string(),
	description: string(),
	score: number().nullable(),
	scoreDisplayMode: string().nullable(),
	displayValue: string().nullable(),
	impactMs: number().nullable(),
	impactBytes: number().nullable(),
	severity: _enum([
		"critical",
		"warning",
		"info"
	]),
	items: array(string())
});
var storedLighthousePayloadSchema = object({
	version: literal(2),
	source: literal("dataforseo-lighthouse"),
	hasIssueDetails: boolean(),
	metadata: object({
		requestedUrl: string(),
		finalUrl: string(),
		strategy: _enum(["mobile", "desktop"]),
		fetchedAt: string(),
		lighthouseVersion: string().nullable(),
		taskId: string().nullable(),
		cost: number().nullable()
	}),
	scores: object({
		performance: number().nullable(),
		accessibility: number().nullable(),
		"best-practices": number().nullable(),
		seo: number().nullable()
	}),
	metrics: storedLighthouseMetricsSchema,
	issues: array(storedLighthouseIssueSchema)
});
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function scoreToPercent(score) {
	if (typeof score !== "number" || Number.isNaN(score)) return null;
	return Math.round(score * 100);
}
function buildStoredMetric(audit) {
	return {
		score: scoreToPercent(audit?.score),
		displayValue: audit?.displayValue ?? null,
		numericValue: typeof audit?.numericValue === "number" ? audit.numericValue : null
	};
}
var DIAGNOSTIC_AUDIT_KEYS = /* @__PURE__ */ new Set([
	"largest-contentful-paint-element",
	"layout-shifts",
	"diagnostics",
	"metrics",
	"network-requests",
	"network-rtt",
	"network-server-latency",
	"main-thread-tasks",
	"screenshot-thumbnails",
	"final-screenshot",
	"script-treemap-data",
	"resource-summary"
]);
function compactItem(item) {
	const preferredKeys = [
		"url",
		"source",
		"nodeLabel",
		"snippet",
		"totalBytes",
		"wastedBytes",
		"wastedMs",
		"label",
		"value"
	];
	const output = {};
	for (const key of preferredKeys) if (item[key] != null) output[key] = item[key];
	if (Object.keys(output).length === 0) for (const [key, value] of Object.entries(item).slice(0, 6)) output[key] = value;
	return JSON.stringify(output);
}
function getSeverity(input) {
	if ((input.impactMs ?? 0) >= 300 || (input.impactBytes ?? 0) >= 15e4) return "critical";
	if (input.score != null && input.score < 50) return "critical";
	if ((input.impactMs ?? 0) >= 100 || (input.impactBytes ?? 0) >= 5e4) return "warning";
	if (input.score != null && input.score < 90) return "warning";
	return "info";
}
function buildStoredLighthouseIssues(input) {
	const hasIssueDetails = LIGHTHOUSE_CATEGORIES.some((category) => (input.categories[category]?.auditRefs?.length ?? 0) > 0);
	const issues = [];
	for (const category of LIGHTHOUSE_CATEGORIES) {
		const rawRefs = input.categories[category]?.auditRefs;
		const refs = Array.isArray(rawRefs) ? rawRefs : [];
		for (const ref of refs) {
			const auditKey = ref?.id;
			if (!auditKey) continue;
			const audit = input.audits[auditKey];
			if (!audit) continue;
			const score = scoreToPercent(audit.score);
			const scoreDisplayMode = audit.scoreDisplayMode ?? null;
			if (scoreDisplayMode === "numeric") continue;
			if (DIAGNOSTIC_AUDIT_KEYS.has(auditKey)) continue;
			if (score == null || score >= 90 || scoreDisplayMode === "notApplicable" || scoreDisplayMode === "informative" || scoreDisplayMode === "manual" || scoreDisplayMode === "error") continue;
			const impactMs = typeof audit.details?.overallSavingsMs === "number" ? audit.details.overallSavingsMs : null;
			const impactBytes = typeof audit.details?.overallSavingsBytes === "number" ? audit.details.overallSavingsBytes : null;
			const rawItems = audit.details?.items;
			const items = (Array.isArray(rawItems) ? rawItems : isRecord(rawItems) ? [rawItems] : []).filter(isRecord).slice(0, 10).map(compactItem);
			issues.push({
				category,
				auditKey,
				title: audit.title ?? auditKey,
				description: audit.description ?? "",
				score,
				scoreDisplayMode,
				displayValue: audit.displayValue ?? null,
				impactMs,
				impactBytes,
				severity: getSeverity({
					score,
					impactMs,
					impactBytes
				}),
				items
			});
		}
	}
	return {
		hasIssueDetails,
		issues
	};
}
function buildStoredLighthouseMetrics(input) {
	return {
		firstContentfulPaint: buildStoredMetric(input.audits["first-contentful-paint"]),
		largestContentfulPaint: buildStoredMetric(input.audits["largest-contentful-paint"]),
		totalBlockingTime: buildStoredMetric(input.audits["total-blocking-time"]),
		cumulativeLayoutShift: buildStoredMetric(input.audits["cumulative-layout-shift"]),
		speedIndex: buildStoredMetric(input.audits["speed-index"]),
		timeToInteractive: buildStoredMetric(input.audits.interactive),
		interactionToNextPaint: buildStoredMetric(input.audits["interaction-to-next-paint"]),
		serverResponseTime: buildStoredMetric(input.audits["server-response-time"])
	};
}
//#endregion
//#region src/server/lib/dataforseoLighthousePayload.ts
var requestCategories = [
	"performance",
	"accessibility",
	"best_practices",
	"seo"
];
var lighthouseResponseSchema = object({
	requestedUrl: string().optional(),
	finalUrl: string().optional(),
	lighthouseVersion: string().optional(),
	categories: record(string(), custom()).optional(),
	audits: record(string(), custom()).optional()
});
var dataforseoTaskSchema = object({
	id: string().optional(),
	cost: number().optional(),
	status_code: number().optional(),
	status_message: string().optional(),
	result: array(lighthouseResponseSchema).optional()
});
var dataforseoLighthouseResponseSchema = object({
	status_code: number().optional(),
	status_message: string().optional(),
	tasks: array(dataforseoTaskSchema).optional()
});
function summarizeZodIssues(error, maxIssues = 3) {
	return error.issues.slice(0, maxIssues).map((issue) => {
		return `${issue.path.length > 0 ? issue.path.join(".") : "<root>"}: ${issue.message}`;
	}).join("; ");
}
function parseDataforseoLighthousePayload(payload, input) {
	const parsed = dataforseoLighthouseResponseSchema.safeParse(payload);
	if (!parsed.success) throw new Error(`DataForSEO Lighthouse returned an invalid response: ${summarizeZodIssues(parsed.error)}`);
	if (parsed.data.status_code !== 2e4) throw new Error(parsed.data.status_message ?? "DataForSEO Lighthouse request failed");
	const task = parsed.data.tasks?.[0];
	if (!task) throw new Error("DataForSEO Lighthouse response missing task");
	if (task.status_code !== 2e4) throw new Error(task.status_message ?? "DataForSEO Lighthouse task failed");
	const result = task.result?.[0];
	if (!result) throw new Error("DataForSEO Lighthouse response missing result");
	const fetchedAt = (/* @__PURE__ */ new Date()).toISOString();
	const categories = result.categories ?? {};
	const audits = result.audits ?? {};
	const issueReport = buildStoredLighthouseIssues({
		audits,
		categories
	});
	const metrics = buildStoredLighthouseMetrics({ audits });
	const storedPayload = {
		version: 2,
		source: "dataforseo-lighthouse",
		hasIssueDetails: issueReport.hasIssueDetails,
		metadata: {
			requestedUrl: result.requestedUrl ?? input.url,
			finalUrl: result.finalUrl ?? input.url,
			strategy: input.strategy,
			fetchedAt,
			lighthouseVersion: result.lighthouseVersion ?? null,
			taskId: task.id ?? null,
			cost: task.cost ?? null
		},
		scores: {
			performance: scoreToPercent(categories.performance?.score),
			accessibility: scoreToPercent(categories.accessibility?.score),
			"best-practices": scoreToPercent(categories["best-practices"]?.score),
			seo: scoreToPercent(categories.seo?.score)
		},
		metrics,
		issues: issueReport.issues
	};
	if (Object.values(storedPayload.scores).every((score) => score == null)) throw new Error(`DataForSEO Lighthouse returned no category scores for ${storedPayload.metadata.finalUrl}`);
	const validated = storedLighthousePayloadSchema.safeParse(storedPayload);
	if (!validated.success) throw new Error(`DataForSEO Lighthouse returned an invalid report: ${summarizeZodIssues(validated.error)}`);
	return storedPayload;
}
//#endregion
//#region src/server/lib/dataforseo/lighthouse.ts
var LIGHTHOUSE_PATH = "/v3/on_page/lighthouse/live/json";
var REQUEST_TIMEOUT_MS = 6e4;
var parseChain = Promise.resolve();
function withParseLock(fn) {
	const run = parseChain.then(fn, fn);
	parseChain = run.catch(() => {});
	return run;
}
async function fetchLighthouseResult$1(input) {
	const controller = new AbortController();
	const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
	let response;
	try {
		response = await dataforseoPostResponse(LIGHTHOUSE_PATH, [{
			url: input.url,
			for_mobile: input.strategy === "mobile",
			categories: [...requestCategories]
		}], {
			maxServerErrorRetries: 0,
			signal: controller.signal
		});
	} finally {
		clearTimeout(timeout);
	}
	return withParseLock(async () => {
		const body = JSON.parse(await readDataforseoText(response));
		warnIfUpstreamResponseFailed(body, LIGHTHOUSE_PATH);
		const billing = buildTaskBilling(assertOk(body));
		try {
			return {
				data: parseDataforseoLighthousePayload(body, input),
				billing
			};
		} catch (error) {
			throw new DataforseoChargedTaskError(error instanceof Error ? error.message : String(error), billing);
		}
	});
}
//#endregion
//#region src/shared/prompt-search-countries.ts
/**
* Country hints for DataForSEO LLM Responses, checked 2026-09-30.
* ChatGPT and Perplexity document ISO country codes (not dataset locations):
* https://docs.dataforseo.com/v3/ai_optimization/chat_gpt/llm_responses/live/
* https://docs.dataforseo.com/v3/ai_optimization/perplexity/llm_responses/live/
* Claude documents the finite list below. Gemini rejects the country field.
* https://docs.dataforseo.com/v3/ai_optimization/claude/llm_responses/live/
* BG was accepted with cited answers by ChatGPT and Perplexity on that date.
* Country codes use ISO 3166-1 alpha-2 (249 entries, including territories).
* These are request capabilities, not proof of search use or observed location.
*/
var WEB_SEARCH_COUNTRY_CODES = [
	"AD",
	"AE",
	"AF",
	"AG",
	"AI",
	"AL",
	"AM",
	"AO",
	"AQ",
	"AR",
	"AS",
	"AT",
	"AU",
	"AW",
	"AX",
	"AZ",
	"BA",
	"BB",
	"BD",
	"BE",
	"BF",
	"BG",
	"BH",
	"BI",
	"BJ",
	"BL",
	"BM",
	"BN",
	"BO",
	"BQ",
	"BR",
	"BS",
	"BT",
	"BV",
	"BW",
	"BY",
	"BZ",
	"CA",
	"CC",
	"CD",
	"CF",
	"CG",
	"CH",
	"CI",
	"CK",
	"CL",
	"CM",
	"CN",
	"CO",
	"CR",
	"CU",
	"CV",
	"CW",
	"CX",
	"CY",
	"CZ",
	"DE",
	"DJ",
	"DK",
	"DM",
	"DO",
	"DZ",
	"EC",
	"EE",
	"EG",
	"EH",
	"ER",
	"ES",
	"ET",
	"FI",
	"FJ",
	"FK",
	"FM",
	"FO",
	"FR",
	"GA",
	"GB",
	"GD",
	"GE",
	"GF",
	"GG",
	"GH",
	"GI",
	"GL",
	"GM",
	"GN",
	"GP",
	"GQ",
	"GR",
	"GS",
	"GT",
	"GU",
	"GW",
	"GY",
	"HK",
	"HM",
	"HN",
	"HR",
	"HT",
	"HU",
	"ID",
	"IE",
	"IL",
	"IM",
	"IN",
	"IO",
	"IQ",
	"IR",
	"IS",
	"IT",
	"JE",
	"JM",
	"JO",
	"JP",
	"KE",
	"KG",
	"KH",
	"KI",
	"KM",
	"KN",
	"KP",
	"KR",
	"KW",
	"KY",
	"KZ",
	"LA",
	"LB",
	"LC",
	"LI",
	"LK",
	"LR",
	"LS",
	"LT",
	"LU",
	"LV",
	"LY",
	"MA",
	"MC",
	"MD",
	"ME",
	"MF",
	"MG",
	"MH",
	"MK",
	"ML",
	"MM",
	"MN",
	"MO",
	"MP",
	"MQ",
	"MR",
	"MS",
	"MT",
	"MU",
	"MV",
	"MW",
	"MX",
	"MY",
	"MZ",
	"NA",
	"NC",
	"NE",
	"NF",
	"NG",
	"NI",
	"NL",
	"NO",
	"NP",
	"NR",
	"NU",
	"NZ",
	"OM",
	"PA",
	"PE",
	"PF",
	"PG",
	"PH",
	"PK",
	"PL",
	"PM",
	"PN",
	"PR",
	"PS",
	"PT",
	"PW",
	"PY",
	"QA",
	"RE",
	"RO",
	"RS",
	"RU",
	"RW",
	"SA",
	"SB",
	"SC",
	"SD",
	"SE",
	"SG",
	"SH",
	"SI",
	"SJ",
	"SK",
	"SL",
	"SM",
	"SN",
	"SO",
	"SR",
	"SS",
	"ST",
	"SV",
	"SX",
	"SY",
	"SZ",
	"TC",
	"TD",
	"TF",
	"TG",
	"TH",
	"TJ",
	"TK",
	"TL",
	"TM",
	"TN",
	"TO",
	"TR",
	"TT",
	"TV",
	"TW",
	"TZ",
	"UA",
	"UG",
	"UM",
	"US",
	"UY",
	"UZ",
	"VA",
	"VC",
	"VE",
	"VG",
	"VI",
	"VN",
	"VU",
	"WF",
	"WS",
	"YE",
	"YT",
	"ZA",
	"ZM",
	"ZW"
];
var MODEL_COUNTRIES = {
	chat_gpt: WEB_SEARCH_COUNTRY_CODES,
	claude: [
		"AR",
		"AT",
		"AU",
		"BE",
		"BR",
		"CA",
		"CH",
		"CL",
		"CN",
		"DE",
		"DK",
		"ES",
		"FI",
		"FR",
		"GB",
		"HK",
		"ID",
		"IN",
		"IT",
		"JP",
		"KR",
		"MX",
		"MY",
		"NL",
		"NO",
		"NZ",
		"PH",
		"PL",
		"PT",
		"RU",
		"SA",
		"SE",
		"TR",
		"TW",
		"US",
		"ZA"
	],
	gemini: [],
	perplexity: WEB_SEARCH_COUNTRY_CODES
};
function supportsWebSearchCountry(model, country) {
	return MODEL_COUNTRIES[model].includes(country);
}
//#endregion
//#region src/server/lib/dataforseoLlmSchemas.ts
/**
* Zod schemas for DataForSEO AI Optimization endpoints.
*
* The DataForSEO SDK does not yet ship typed bindings for `/ai_optimization/*`,
* so we POST raw JSON and validate the responses ourselves. All schemas use
* `.passthrough()` to tolerate fields the API may add in future versions.
*/
var monthlyVolumeSchema = object({
	year: number().int(),
	month: number().int().min(1).max(12),
	search_volume: number().nullable().optional()
}).passthrough();
var mentionSourceSchema = object({
	url: string().nullable().optional(),
	title: string().nullable().optional(),
	domain: string().nullable().optional()
}).passthrough();
var brandEntitySchema = object({ title: string().nullable().optional() }).passthrough();
var llmMentionItemSchema = object({
	question: string().nullable().optional(),
	answer: string().nullable().optional(),
	sources: array(mentionSourceSchema).nullable().optional(),
	search_results: array(mentionSourceSchema).nullable().optional(),
	ai_search_volume: number().nullable().optional(),
	monthly_searches: array(monthlyVolumeSchema).nullable().optional(),
	first_response_at: string().nullable().optional(),
	last_response_at: string().nullable().optional(),
	brand_entities: array(brandEntitySchema).nullable().optional()
}).passthrough();
var groupElementSchema = object({
	type: string().nullable().optional(),
	key: string().nullable().optional(),
	mentions: number().nullable().optional(),
	ai_search_volume: number().nullable().optional(),
	impressions: number().nullable().optional()
}).passthrough();
var llmAggregatedTotalSchema = object({ platform: array(groupElementSchema).nullable().optional() }).passthrough();
var llmTopPagesItemSchema = object({
	key: string().nullable().optional(),
	platform: array(groupElementSchema).nullable().optional()
}).passthrough();
var llmCrossAggregatedItemSchema = object({
	key: string().nullable().optional(),
	platform: array(groupElementSchema).nullable().optional()
}).passthrough();
var responseAnnotationSchema = object({
	type: string().nullable().optional(),
	title: string().nullable().optional(),
	url: string().nullable().optional()
}).passthrough();
var responseSectionSchema = object({
	type: string().nullable().optional(),
	text: string().nullable().optional(),
	annotations: array(responseAnnotationSchema).nullable().optional()
}).passthrough();
var responseItemSchema = object({
	type: string().nullable().optional(),
	sections: array(responseSectionSchema).nullable().optional()
}).passthrough();
var llmResponseResultSchema = object({
	model_name: string().nullable().optional(),
	output_tokens: number().nullable().optional(),
	web_search: boolean().nullable().optional(),
	items: array(responseItemSchema).nullable().optional(),
	fan_out_queries: array(string()).nullable().optional()
}).passthrough();
//#endregion
//#region src/server/lib/dataforseo/llm-models.ts
/**
* Model names come from DataForSEO's FREE ($0) per-provider catalog
* (`/v3/ai_optimization/{slug}/llm_responses/models`), so the app tracks new
* model families without code changes. This matters twice over: a hardcoded
* pin goes stale (we shipped gpt-5 while the catalog had gpt-5.5), and
* DataForSEO BILLS tasks that fail with `Invalid Field: 'model_name'`, so a
* name must be validated against the catalog before a paid dispatch.
*/
var catalogRowSchema = object({ model_name: string() });
/**
* Snapshot fallback (2026-08-25) used when the catalog endpoint is
* unreachable or lists no flagship alias: the aliases we know DataForSEO
* accepts, newest first.
*/
var FALLBACK_MODEL_NAMES = {
	chat_gpt: [
		"gpt-5.6-luna",
		"gpt-5.5",
		"gpt-5.4",
		"gpt-5.2",
		"gpt-5.1",
		"gpt-5"
	],
	claude: [
		"claude-sonnet-5",
		"claude-sonnet-4-6",
		"claude-sonnet-4-5"
	],
	gemini: ["gemini-3.5-flash"],
	perplexity: [
		"sonar-reasoning-pro",
		"sonar-pro",
		"sonar"
	]
};
var CATALOG_TTL_MS = 36e5;
var catalogCache = /* @__PURE__ */ new Map();
async function getLlmModelNames(slug) {
	const cached = catalogCache.get(slug);
	if (cached && Date.now() - cached.fetchedAt < CATALOG_TTL_MS) return cached.names;
	try {
		const names = (assertOk(await dataforseoGet(`/v3/ai_optimization/${slug}/llm_responses/models`)).result ?? []).flatMap((row) => {
			const parsed = catalogRowSchema.safeParse(row);
			return parsed.success ? [parsed.data.model_name] : [];
		});
		if (names.length === 0) return FALLBACK_MODEL_NAMES[slug];
		catalogCache.set(slug, {
			names,
			fetchedAt: Date.now()
		});
		return names;
	} catch (error) {
		console.warn(`dataforseo.llm-models.catalog-fetch failed (${slug})`, error);
		return FALLBACK_MODEL_NAMES[slug];
	}
}
/** Whether DataForSEO's catalog accepts this model name. Checked before every
*  paid dispatch because an unknown `model_name` fails as a BILLED task. */
async function isKnownLlmModelName(slug, modelName) {
	return (await getLlmModelNames(slug)).includes(modelName);
}
//#endregion
//#region src/server/lib/dataforseo/ai.ts
var classifyAiSearchError = createDataforseoBillingClassifier({
	pathPrefix: "/ai_optimization/",
	billingIssueCode: "AI_SEARCH_BILLING_ISSUE",
	billingIssueMessage: "The connected DataForSEO account has a billing or balance issue"
});
var assertOptions = (path) => ({
	classify: classifyAiSearchError,
	classifyPath: path
});
function clampLimit(value, min, max) {
	return Math.min(max, Math.max(min, Math.floor(value)));
}
function resolveLlmMentionsLimit(limit) {
	return clampLimit(limit ?? 100, 1, 1e3);
}
function targetList(target) {
	return [target];
}
function firstResult(task) {
	const first = task.result?.[0];
	return isRecord$5(first) ? first : null;
}
async function fetchLlmMentionsSearch(input) {
	const task = assertOk(await dataforseoPost("/v3/ai_optimization/llm_mentions/search/live", [{
		target: targetList(input.target),
		platform: input.platform,
		location_code: input.locationCode,
		language_code: input.languageCode,
		limit: resolveLlmMentionsLimit(input.limit),
		order_by: input.orderBy
	}], { classify: classifyAiSearchError }), assertOptions("/v3/ai_optimization/llm_mentions/search/live"));
	const items = array(llmMentionItemSchema).safeParse(firstResult(task)?.items ?? []);
	if (!items.success) throw new AppError("INTERNAL_ERROR", "DataForSEO llm_mentions/search returned an invalid mention items shape");
	return {
		data: items.data,
		billing: buildTaskBilling(task)
	};
}
async function fetchLlmAggregatedMetrics(input) {
	const task = assertOk(await dataforseoPost("/v3/ai_optimization/llm_mentions/aggregated_metrics/live", [{
		target: targetList(input.target),
		platform: input.platform,
		location_code: input.locationCode,
		language_code: input.languageCode,
		internal_list_limit: clampLimit(input.internalListLimit ?? 10, 1, 20)
	}], { classify: classifyAiSearchError }), assertOptions("/v3/ai_optimization/llm_mentions/aggregated_metrics/live"));
	const total = llmAggregatedTotalSchema.safeParse(firstResult(task)?.total ?? {});
	if (!total.success) throw new AppError("INTERNAL_ERROR", "DataForSEO llm_mentions/aggregated_metrics returned an invalid shape");
	return {
		data: total.data,
		billing: buildTaskBilling(task)
	};
}
async function fetchLlmTopPages(input) {
	const task = assertOk(await dataforseoPost("/v3/ai_optimization/llm_mentions/top_pages/live", [{
		target: targetList(input.target),
		platform: input.platform,
		location_code: input.locationCode,
		language_code: input.languageCode,
		links_scope: "sources",
		items_list_limit: clampLimit(input.itemsListLimit ?? 10, 1, 10),
		internal_list_limit: 5
	}], { classify: classifyAiSearchError }), assertOptions("/v3/ai_optimization/llm_mentions/top_pages/live"));
	const items = array(llmTopPagesItemSchema).safeParse(firstResult(task)?.items ?? []);
	if (!items.success) throw new AppError("INTERNAL_ERROR", "DataForSEO llm_mentions/top_pages returned an invalid shape");
	return {
		data: items.data,
		billing: buildTaskBilling(task)
	};
}
async function fetchLlmCrossAggregatedMetrics(input) {
	if (input.groups.length < 2 || input.groups.length > 10) throw new AppError("VALIDATION_ERROR", "DataForSEO llm_mentions/cross_aggregated_metrics requires 2 to 10 target groups");
	const task = assertOk(await dataforseoPost("/v3/ai_optimization/llm_mentions/cross_aggregated_metrics/live", [{
		targets: input.groups.map((group) => ({
			aggregation_key: group.key,
			target: targetList(group.target)
		})),
		platform: input.platform,
		location_code: input.locationCode,
		language_code: input.languageCode,
		internal_list_limit: clampLimit(input.internalListLimit ?? 5, 1, 10)
	}], { classify: classifyAiSearchError }), assertOptions("/v3/ai_optimization/llm_mentions/cross_aggregated_metrics/live"));
	const items = array(llmCrossAggregatedItemSchema).safeParse(firstResult(task)?.items ?? []);
	if (!items.success) throw new AppError("INTERNAL_ERROR", "DataForSEO llm_mentions/cross_aggregated_metrics returned an invalid shape");
	return {
		data: items.data,
		billing: buildTaskBilling(task)
	};
}
async function fetchLlmResponse(input) {
	if (!await isKnownLlmModelName(input.modelSlug, input.modelName)) throw new AppError("VALIDATION_ERROR", `Unsupported DataForSEO model_name "${input.modelName}" for ${input.modelSlug}`);
	const webSearch = input.webSearch ?? true;
	if (webSearch && input.webSearchCountryCode && !supportsWebSearchCountry(input.modelSlug, input.webSearchCountryCode)) throw new AppError("VALIDATION_ERROR", `Unsupported web-search country ${input.webSearchCountryCode} for ${input.modelSlug}`);
	const fields = {
		user_prompt: input.userPrompt,
		model_name: input.modelName,
		web_search: webSearch,
		...webSearch && input.modelSlug === "claude" ? { force_web_search: true } : {},
		max_output_tokens: clampLimit(input.maxOutputTokens ?? 1024, 256, 4096),
		...webSearch && input.webSearchCountryCode ? { web_search_country_iso_code: input.webSearchCountryCode } : {}
	};
	const task = assertOk(await dataforseoPost(`/v3/ai_optimization/${input.modelSlug}/llm_responses/live`, [fields], {
		classify: classifyAiSearchError,
		maxServerErrorRetries: 0
	}), assertOptions(`/v3/ai_optimization/${input.modelSlug}/llm_responses/live`));
	const result = llmResponseResultSchema.safeParse(firstResult(task) ?? {});
	if (!result.success) throw new AppError("INTERNAL_ERROR", "DataForSEO llm_responses returned an invalid response shape");
	return {
		data: result.data,
		billing: buildTaskBilling(task)
	};
}
//#endregion
//#region src/shared/ai-visibility.ts
function aiEngineUsesModelApi(engine) {
	return engine === "claude" || engine === "perplexity";
}
/**
* Raw DataForSEO USD for one answer, standard queue. AI Overviews is one
* organic SERP page ($0.0006) plus the async overview load ($0.0006).
*/
var AI_RECORD_COST_USD = .0012;
/**
* Raw DataForSEO USD for one live answer, used by manual runs. AI Overviews is
* one live organic SERP page ($0.002) plus the async overview load ($0.002).
*/
var AI_LIVE_RECORD_COST_USD = .004;
liveUnsupportedLocations("claude"), liveUnsupportedLocations("perplexity");
/** Countries a live engine's web search does not accept. */
function liveUnsupportedLocations(engine) {
	return LOCATION_OPTIONS.filter((option) => !supportsWebSearchCountry(engine, getIsoCountryCode(option.code).toUpperCase())).map((option) => option.code);
}
//#endregion
//#region src/server/lib/dataforseo/ai-tracking.ts
var AI_TRACKING_ENDPOINTS = {
	chatgpt: "/v3/ai_optimization/chat_gpt/llm_scraper",
	gemini: "/v3/ai_optimization/gemini/llm_scraper",
	google_ai_overview: "/v3/serp/google/organic"
};
/** Live engines have no LLM Scraper: their answers come from the live API. */
function trackingEndpoint(engine) {
	if (aiEngineUsesModelApi(engine)) throw new AppError("INTERNAL_ERROR", `${engine} answers cannot be queued`);
	return AI_TRACKING_ENDPOINTS[engine];
}
var LIVE_REQUEST_TIMEOUT_MS = 15e4;
/**
* The LLM Scraper language lists name three project-market languages
* differently, and Gemini only offers Brazilian Portuguese. The organic
* SERP uses the project-market codes.
*/
function providerLanguageCode(engine, languageCode) {
	if (engine === "google_ai_overview") return languageCode;
	if (languageCode === "nb") return "no";
	if (languageCode === "tl") return "fil";
	if (languageCode === "pt" && engine !== "chatgpt") return "pt-BR";
	return languageCode;
}
function aiTrackingTaskBody(engine, market, task) {
	return {
		keyword: task.prompt.replace(/%/g, "%25").replace(/\+/g, "%2B"),
		location_code: market.locationCode,
		language_code: providerLanguageCode(engine, market.languageCode),
		...engine === "google_ai_overview" ? {
			depth: 10,
			load_async_ai_overview: true
		} : {},
		tag: task.tag
	};
}
/**
* Posts up to 100 prompts for one engine. DataForSEO bills at task_post; the
* metered client holds credits for it and charges each task once its answer
* arrives. Rejected entries come back without a task; the caller fails their
* answers.
*/
async function postAiTrackingTasks(input) {
	if (input.tasks.length === 0 || input.tasks.length > 100) throw new AppError("INTERNAL_ERROR", `task_post accepts 1-100 tasks, got ${input.tasks.length}`);
	const endpoint = trackingEndpoint(input.engine);
	const response = await dataforseoPost(`${endpoint}/task_post`, input.tasks.map((task) => aiTrackingTaskBody(input.engine, input, task)), { maxServerErrorRetries: 0 });
	if (!response || response.status_code !== 2e4) throw failedResponseError(response, "DataForSEO task_post failed");
	const posted = [];
	let costUsd = 0;
	for (const entry of response.tasks ?? []) {
		costUsd += entry.cost ?? 0;
		const tag = entry.data?.tag;
		if (entry.status_code !== 20100 || !entry.id || typeof tag !== "string") {
			console.warn(`dataforseo.ai_tracking.task_post.rejected-entry (${entry.status_code}): ${entry.status_message}`);
			continue;
		}
		posted.push({
			tag,
			taskId: entry.id,
			costUsd: entry.cost ?? 0
		});
	}
	return {
		data: posted,
		billing: {
			path: `${endpoint}/task_post`.slice(1).split("/"),
			costUsd
		}
	};
}
function aiTrackingAnswer(task) {
	if (task.status_code !== 2e4) {
		if (isNoResultsTask(task)) return {
			status: "completed",
			result: null
		};
		const upstream = isUpstreamFailureStatus(task.status_code);
		return {
			status: "failed",
			message: task.status_message || `DataForSEO task failed (${task.status_code})`,
			code: upstream ? "UPSTREAM_UNAVAILABLE" : "INTERNAL_ERROR",
			retryable: upstream
		};
	}
	return {
		status: "completed",
		result: task.result?.[0] ?? null
	};
}
/**
* Fetches one answer from the live endpoint. DataForSEO bills each live call,
* so this is the metered call. A failed task returns a failed outcome with
* its charge, so the caller fails only that answer.
*/
async function fetchAiTrackingLiveAnswer(input) {
	const endpoint = `${trackingEndpoint(input.engine)}/live/advanced`;
	const response = await dataforseoPost(endpoint, [aiTrackingTaskBody(input.engine, input, input.task)], {
		maxServerErrorRetries: 0,
		signal: AbortSignal.timeout(LIVE_REQUEST_TIMEOUT_MS)
	});
	const task = response?.tasks?.[0];
	if (!response || response.status_code !== 2e4 || !task) throw failedResponseError(response, "DataForSEO live request failed");
	return {
		data: aiTrackingAnswer(task),
		billing: {
			path: endpoint.slice(1).split("/"),
			costUsd: task.cost ?? 0
		}
	};
}
//#endregion
//#region src/server/lib/dataforseo/pricing.ts
/**
* Raw DataForSEO USD upper bound for one metered call, computed from the
* fetcher's input before the call is made. The metering seam reserves
* `creditsForProviderUsd(estimate)` and settles on the provider's real
* `cost`, so every number here must be >= what DataForSEO actually charges
* for that input. Overestimating only refuses a call slightly early at the
* tail of a balance; underestimating lets spend past the balance.
*
* Prices are raw (pre-markup) USD from DataForSEO's per-account price table
* (the `price` object on the free GET /v3/appendix/user_data), read Sep 2026.
* That table has only each endpoint's base price, so per-page, per-depth and
* token-priced shapes are "measured": set from real billed costs, which the
* free POST /v3/<api>/id_list returns per task alongside the request
* parameters for the last month. Re-check a price against id_list, not a
* one-off fixture.
*/
var LABS_TASK_USD = .012;
var LABS_ROW_USD = 12e-5;
var GOOGLE_ADS_LIVE_TASK_USD = .09;
var BACKLINKS_TASK_USD = .024;
var BACKLINKS_ROW_USD = 36e-6;
var BUSINESS_LISTINGS_TASK_USD = .012;
var BUSINESS_LISTINGS_ROW_USD = 36e-5;
var MY_BUSINESS_INFO_LIVE_USD = .0054;
var QUESTIONS_ANSWERS_PER_20_USD = .0054;
var REVIEWS_PRIORITY_TASK_USD = .001;
var REVIEWS_PRIORITY_PER_10_USD = .0015;
var EXTENDED_REVIEWS_PRIORITY_PER_20_USD = .01;
var UPDATES_PRIORITY_TASK_USD = .003;
var UPDATES_PRIORITY_PER_10_USD = .0015;
var LIGHTHOUSE_LIVE_USD = .005;
var LLM_MENTIONS_TASK_USD = .1;
var LLM_MENTIONS_ROW_USD = .001;
var LLM_MENTIONS_ONE_ROW_USD = .101;
var LLM_RESPONSE_USD = {
	chat_gpt: {
		webSearch: .09,
		noSearch: .05
	},
	claude: {
		webSearch: .18,
		noSearch: .08
	},
	gemini: {
		webSearch: .11,
		noSearch: .05
	},
	perplexity: {
		webSearch: .04,
		noSearch: .04
	}
};
/** Estimated USD for one live LLM response at the 4096-token output cap. */
function llmResponseUsd(modelSlug, webSearch) {
	const price = LLM_RESPONSE_USD[modelSlug];
	return webSearch ? price.webSearch : price.noSearch;
}
var LOCAL_SERP_PAGE_USD = .002;
var LOCAL_SERP_TASK_USD = .0012;
/** Ties an estimator to a fetcher so it is typed against that fetcher's input. */
function priced(_fetcher, estimate) {
	return estimate;
}
function labsUsd(rows, clickstream) {
	return (LABS_TASK_USD + rows * LABS_ROW_USD) * (clickstream ? 2 : 1);
}
function backlinksUsd(rows) {
	return BACKLINKS_TASK_USD + rows * BACKLINKS_ROW_USD;
}
/** SERP endpoints bill per page of 10; a partial page is a full page. */
function serpUsd(depth, keyword) {
	return costPerSerpAtDepth(Math.ceil(depth / 10) * 10) * serpKeywordCostMultiplier(keyword);
}
function daysInclusive(from, to) {
	const ms = new Date(to).getTime() - new Date(from).getTime();
	return Math.max(1, Math.floor(ms / 864e5) + 1);
}
/** One raw-USD upper-bound estimator per entry in createDataforseoClient. */
var dataforseoPricing = {
	business: {
		businessListings: priced(fetchBusinessListingsSearch, (input) => BUSINESS_LISTINGS_TASK_USD + input.limit * BUSINESS_LISTINGS_ROW_USD),
		questionsAnswers: priced(fetchQuestionsAnswers, (input) => Math.ceil(input.depth / 20) * QUESTIONS_ANSWERS_PER_20_USD),
		myBusinessInfo: priced(fetchMyBusinessInfo, () => MY_BUSINESS_INFO_LIVE_USD),
		reviewsTaskPost: priced(postGoogleReviewsTask, (input) => input.includeOtherSources ? Math.ceil(input.depth / 20) * EXTENDED_REVIEWS_PRIORITY_PER_20_USD : REVIEWS_PRIORITY_TASK_USD + Math.ceil(input.depth / 10) * REVIEWS_PRIORITY_PER_10_USD),
		updatesTaskPost: priced(postMyBusinessUpdatesTask, (input) => UPDATES_PRIORITY_TASK_USD + Math.ceil(input.depth / 10) * UPDATES_PRIORITY_PER_10_USD)
	},
	backlinks: {
		summary: priced(fetchBacklinksSummary, () => backlinksUsd(1)),
		rows: priced(fetchBacklinksRows, (input) => backlinksUsd(input.limit ?? 100)),
		referringDomains: priced(fetchReferringDomains, (input) => backlinksUsd(input.limit ?? 100)),
		domainPages: priced(fetchDomainPagesSummary, (input) => backlinksUsd(input.limit ?? 100)),
		history: priced(fetchBacklinksHistory, (input) => backlinksUsd(daysInclusive(input.dateFrom, input.dateTo)))
	},
	keywords: {
		related: priced(fetchRelatedKeywords, (input) => labsUsd(input.limit, input.includeClickstreamData)),
		suggestions: priced(fetchKeywordSuggestions, (input) => labsUsd(input.limit, input.includeClickstreamData)),
		ideas: priced(fetchKeywordIdeas, (input) => labsUsd(input.limit, input.includeClickstreamData)),
		adsIdeas: priced(fetchAdsKeywordIdeas, () => GOOGLE_ADS_LIVE_TASK_USD),
		adsSearchVolume: priced(fetchAdsSearchVolume, () => GOOGLE_ADS_LIVE_TASK_USD)
	},
	domain: {
		rankOverview: priced(fetchDomainRankOverview, () => labsUsd(1)),
		rankedKeywords: priced(fetchRankedKeywords, (input) => labsUsd(input.limit)),
		relevantPages: priced(fetchRelevantPages, (input) => labsUsd(input.limit))
	},
	serp: {
		readsTaskPost: priced(postSerpReadTasks, (input) => 6 * serpUsd(clampSerpDepth(input.depth ?? 10), input.keyword)),
		rankCheckTaskPost: priced(postRankCheckTasks, (input) => input.tasks.reduce((sum, task) => sum + serpUsd(clampSerpDepth(input.depth), task.keyword), 0)),
		local: priced(fetchLocalSerp, (input) => input.searchType === "maps" ? LOCAL_SERP_PAGE_USD : Math.ceil(input.depth / 10) * LOCAL_SERP_PAGE_USD),
		localTaskPost: priced(postLocalSerpTasks, (input) => input.locationCoordinates.length * LOCAL_SERP_TASK_USD)
	},
	labs: {
		keywordOverview: priced(fetchKeywordOverview, (input) => labsUsd(input.keywords.length, input.includeClickstreamData)),
		serpCompetitors: priced(fetchSerpCompetitors, (input) => labsUsd(input.limit))
	},
	lighthouse: { live: priced(fetchLighthouseResult$1, () => LIGHTHOUSE_LIVE_USD) },
	aiSearch: {
		mentionsSearch: priced(fetchLlmMentionsSearch, (input) => LLM_MENTIONS_TASK_USD + resolveLlmMentionsLimit(input.limit) * LLM_MENTIONS_ROW_USD),
		aggregatedMetrics: priced(fetchLlmAggregatedMetrics, () => LLM_MENTIONS_ONE_ROW_USD),
		topPages: priced(fetchLlmTopPages, () => LLM_MENTIONS_ONE_ROW_USD),
		crossAggregatedMetrics: priced(fetchLlmCrossAggregatedMetrics, () => LLM_MENTIONS_ONE_ROW_USD),
		trackingTaskPost: priced(postAiTrackingTasks, (input) => input.tasks.length * AI_RECORD_COST_USD),
		trackingLive: priced(fetchAiTrackingLiveAnswer, () => AI_LIVE_RECORD_COST_USD),
		llmResponse: priced(fetchLlmResponse, (input) => llmResponseUsd(input.modelSlug, input.webSearch ?? true))
	}
};
//#endregion
//#region src/server/lib/dataforseo/ai-tracking-billing.ts
/**
* Autumn's longest lock, less a minute for clock skew: the run reads late
* answers until shortly before it. A hold that expires first releases its
* credits, so the run is not charged.
*/
var AI_TRACKING_HOLD_TTL_MS = 8634e4;
async function postAiTrackingTasksOnHold(customer, input) {
	if (!await isHostedServerAuthMode()) return {
		tasks: (await postAiTrackingTasks(input)).data,
		hold: null
	};
	const { holds: [hold] } = await reserveUsageCredits({
		customer,
		customerId: (await getOrCreateOrganizationCustomer(customer)).id,
		callCredits: [creditsForProviderUsd(dataforseoPricing.aiSearch.trackingTaskPost(input))],
		creditFeature: "ai_prompt_responses",
		ttlMs: AI_TRACKING_HOLD_TTL_MS
	});
	try {
		const response = await postAiTrackingTasks(input);
		return {
			tasks: response.data,
			hold: {
				hold,
				path: response.billing.path
			}
		};
	} catch (error) {
		await settleUsageCredits({
			customer,
			hold,
			costs: []
		});
		throw error;
	}
}
function settleAiTrackingHold(customer, { hold, costs }) {
	const costUsd = costs.reduce((sum, cost) => sum + cost, 0);
	return settleUsageCredits({
		customer,
		hold: hold.hold,
		creditFeature: "ai_prompt_responses",
		costs: costs.length ? [{
			costUsd,
			path: hold.path
		}] : []
	});
}
//#endregion
//#region src/server/lib/dataforseo/request-slots.ts
var MAX_PENDING_DATAFORSEO_CALLS = 4;
var requestSlots = new AsyncLocalStorage();
/**
* Runs one DataForSEO call once fewer than the cap are in flight for this
* request. Outside a request (Workflows, cron, tests) it runs at once.
*/
async function inDataforseoSlot(fn) {
	const slots = requestSlots.getStore();
	if (!slots) return fn();
	if (slots.active < MAX_PENDING_DATAFORSEO_CALLS) slots.active++;
	else await new Promise((resolve) => slots.waiting.push(resolve));
	try {
		return await fn();
	} finally {
		const next = slots.waiting.shift();
		if (next) next();
		else slots.active--;
	}
}
//#endregion
//#region src/server/lib/dataforseo/client.ts
/**
* Wraps a section fetcher with billing metering. Each entry on the client is
* `meter(customer, fetchX, dataforseoPricing.section.x, defaultFeature)`,
* which returns a function with the fetcher's own input type and resolves to
* its unwrapped `.data`.
*
* `estimateRawUsd` is required: it is the upper bound reserved before the
* call, so an entry cannot be added without a price (see pricing.ts).
*
* `defaultFeature` goes on the hold: Autumn keeps the hold and its settle as
* separate events, so a feature set only at settle reads as "Other". Callers
* can override it with `creditFeature` in the input (fetchers ignore it).
*/
function meter(customer, fetcher, estimateRawUsd, defaultFeature) {
	return (input) => meterDataforseoCall(customer, () => fetcher(input), creditsForProviderUsd(estimateRawUsd(input)), input.creditFeature ?? defaultFeature);
}
function createDataforseoClient(customer) {
	return {
		business: {
			businessListings: meter(customer, fetchBusinessListingsSearch, dataforseoPricing.business.businessListings, "local_seo"),
			questionsAnswers: meter(customer, fetchQuestionsAnswers, dataforseoPricing.business.questionsAnswers, "local_seo"),
			myBusinessInfo: meter(customer, fetchMyBusinessInfo, dataforseoPricing.business.myBusinessInfo, "local_seo"),
			reviewsTaskPost: meter(customer, postGoogleReviewsTask, dataforseoPricing.business.reviewsTaskPost, "local_seo"),
			updatesTaskPost: meter(customer, postMyBusinessUpdatesTask, dataforseoPricing.business.updatesTaskPost, "local_seo")
		},
		backlinks: {
			summary: meter(customer, fetchBacklinksSummary, dataforseoPricing.backlinks.summary, "backlinks"),
			rows: meter(customer, fetchBacklinksRows, dataforseoPricing.backlinks.rows, "backlinks"),
			referringDomains: meter(customer, fetchReferringDomains, dataforseoPricing.backlinks.referringDomains, "backlinks"),
			domainPages: meter(customer, fetchDomainPagesSummary, dataforseoPricing.backlinks.domainPages, "backlinks"),
			history: meter(customer, fetchBacklinksHistory, dataforseoPricing.backlinks.history, "backlinks")
		},
		keywords: {
			related: meter(customer, fetchRelatedKeywords, dataforseoPricing.keywords.related, "keyword_research"),
			suggestions: meter(customer, fetchKeywordSuggestions, dataforseoPricing.keywords.suggestions, "keyword_research"),
			ideas: meter(customer, fetchKeywordIdeas, dataforseoPricing.keywords.ideas, "keyword_research"),
			adsIdeas: meter(customer, fetchAdsKeywordIdeas, dataforseoPricing.keywords.adsIdeas, "keyword_research"),
			adsSearchVolume: meter(customer, fetchAdsSearchVolume, dataforseoPricing.keywords.adsSearchVolume, "keyword_research")
		},
		domain: {
			rankOverview: meter(customer, fetchDomainRankOverview, dataforseoPricing.domain.rankOverview, "domain_overview"),
			rankedKeywords: meter(customer, fetchRankedKeywords, dataforseoPricing.domain.rankedKeywords, "domain_overview"),
			relevantPages: meter(customer, fetchRelevantPages, dataforseoPricing.domain.relevantPages, "domain_overview")
		},
		serp: {
			readsTaskPostBatch: (inputs) => meterDataforseoCalls(customer, inputs.map((input) => () => postSerpReadTasks(input)), inputs.map((input) => creditsForProviderUsd(dataforseoPricing.serp.readsTaskPost(input))), "keyword_research"),
			rankCheckTaskPost: meter(customer, postRankCheckTasks, dataforseoPricing.serp.rankCheckTaskPost, "rank_tracking"),
			local: meter(customer, fetchLocalSerp, dataforseoPricing.serp.local, "local_seo"),
			localBatch: (inputs) => meterDataforseoCalls(customer, inputs.map((input) => () => fetchLocalSerp(input)), inputs.map((input) => creditsForProviderUsd(dataforseoPricing.serp.local(input))), "local_seo"),
			localTaskPost: meter(customer, postLocalSerpTasks, dataforseoPricing.serp.localTaskPost, "local_seo")
		},
		labs: {
			keywordOverview: meter(customer, fetchKeywordOverview, dataforseoPricing.labs.keywordOverview, "rank_tracking"),
			serpCompetitors: meter(customer, fetchSerpCompetitors, dataforseoPricing.labs.serpCompetitors, "keyword_research")
		},
		lighthouse: { live: meter(customer, fetchLighthouseResult$1, dataforseoPricing.lighthouse.live, "site_audit") },
		aiSearch: {
			mentionsSearch: meter(customer, fetchLlmMentionsSearch, dataforseoPricing.aiSearch.mentionsSearch, "ai_citations"),
			aggregatedMetrics: meter(customer, fetchLlmAggregatedMetrics, dataforseoPricing.aiSearch.aggregatedMetrics, "ai_citations"),
			topPages: meter(customer, fetchLlmTopPages, dataforseoPricing.aiSearch.topPages, "ai_citations"),
			crossAggregatedMetrics: meter(customer, fetchLlmCrossAggregatedMetrics, dataforseoPricing.aiSearch.crossAggregatedMetrics, "ai_citations"),
			llmResponse: meter(customer, fetchLlmResponse, dataforseoPricing.aiSearch.llmResponse, "ai_prompt_responses"),
			trackingTaskPost: (input) => postAiTrackingTasksOnHold(customer, input),
			settleTrackingHold: (input) => settleAiTrackingHold(customer, input),
			trackingLiveBatch: (inputs) => meterDataforseoCalls(customer, inputs.map((input) => () => fetchAiTrackingLiveAnswer(input)), inputs.map((input) => creditsForProviderUsd(dataforseoPricing.aiSearch.trackingLive(input))), "ai_prompt_responses")
		}
	};
}
/**
* The one seam every DataForSEO charge passes through (hosted mode only).
* Order: reserve the estimate on the org's credits -> provider calls -> settle
* the hold on their real cost. The hold is atomic in Autumn, so concurrent
* calls cannot all pass on one stale balance reading.
*
* A batch of calls shares one hold and one settle per credit pool it draws
* on, with each call placed and refused as its own hold would be (see
* reserveUsageCredits): holding and settling per call sent up to 40 Autumn
* requests per rank check batch, and enough of them hit the SDK's timeout to
* drop charges.
*/
async function meterDataforseoCalls(customer, executes, callCredits, creditFeature) {
	if (executes.length === 0) return [];
	if (!await isHostedServerAuthMode()) return Promise.allSettled(executes.map(async (execute) => (await execute()).data));
	const { holds, refusedCalls } = await reserveUsageCredits({
		customer,
		customerId: (await getOrCreateOrganizationCustomer(customer)).id,
		callCredits,
		creditFeature
	});
	const work = (async () => {
		const billed = executes.map(() => null);
		const settled = await Promise.allSettled(executes.map(async (execute, index) => {
			if (refusedCalls.includes(index)) throw new AppError("INSUFFICIENT_CREDITS");
			try {
				const result = await execute();
				billed[index] = result.billing;
				return result.data;
			} catch (error) {
				if (!(error instanceof DataforseoChargedTaskError)) throw error;
				if (error.isInvalidField && error.billing.costUsd <= 0) {
					console.warn("dataforseo.invalid-field", {
						event: "dataforseo.invalid-field",
						path: `/${error.billing.path.join("/")}`,
						field: invalidFieldName(error.message)
					});
					throw new AppError("VALIDATION_ERROR", error.message);
				}
				billed[index] = error.billing;
				throw error;
			}
		}));
		for (const hold of holds) await settleUsageCredits({
			customer,
			hold,
			creditFeature,
			costs: hold.callIndexes.map((index) => billed[index]).filter((cost) => cost !== null)
		});
		return settled;
	})();
	try {
		waitUntil(work.catch(() => void 0));
	} catch {}
	return await work;
}
async function meterDataforseoCall(customer, execute, estimatedCredits, creditFeature) {
	const [result] = await meterDataforseoCalls(customer, [() => inDataforseoSlot(execute)], [estimatedCredits], creditFeature);
	if (result.status === "rejected") throw result.reason;
	return result.value;
}
//#endregion
//#region src/server/lib/r2.ts
async function putTextToR2(key, body) {
	await env.R2.put(key, body, { httpMetadata: { contentType: "application/json" } });
	return {
		key,
		sizeBytes: Buffer.byteLength(body)
	};
}
//#endregion
//#region src/server/lib/audit/lighthouse.ts
function canonicalUrlKeyWithoutTrailingSlash(url) {
	const parsed = new URL(canonicalUrlKey(url));
	if (parsed.pathname !== "/") parsed.pathname = parsed.pathname.replace(/\/$/, "");
	return parsed.toString();
}
/** A check that produced no payload \u2014 provider error, or a failed fetch step. */
function failedLighthouseFetch(url, pageId, strategy, errorMessage) {
	return {
		result: {
			url,
			pageId,
			strategy,
			performanceScore: null,
			accessibilityScore: null,
			bestPracticesScore: null,
			seoScore: null,
			lcpMs: null,
			cls: null,
			inpMs: null,
			ttfbMs: null,
			errorMessage
		},
		payloadJson: null
	};
}
async function fetchLighthouseResult(url, pageId, strategy, billingCustomer) {
	const dataforseo = createDataforseoClient(billingCustomer);
	try {
		const data = await dataforseo.lighthouse.live({
			url,
			strategy
		});
		return {
			result: {
				url,
				pageId,
				strategy,
				performanceScore: data.scores.performance,
				accessibilityScore: data.scores.accessibility,
				bestPracticesScore: data.scores["best-practices"],
				seoScore: data.scores.seo,
				lcpMs: data.metrics.largestContentfulPaint.numericValue,
				cls: data.metrics.cumulativeLayoutShift.numericValue,
				inpMs: data.metrics.interactionToNextPaint.numericValue,
				ttfbMs: data.metrics.serverResponseTime.numericValue
			},
			payloadJson: JSON.stringify(data)
		};
	} catch (error) {
		const failed = error instanceof Error ? error : new Error(String(error));
		(failed.message.includes("Lighthouse encountered an error with the following code") ? console.warn : console.error)(`Lighthouse failed for ${url} (${strategy}): ${failed.message}`);
		return failedLighthouseFetch(url, pageId, strategy, failed.message);
	}
}
async function storeLighthouseResult(input) {
	if (!input.fetched.payloadJson) return input.fetched.result;
	const { pageId, strategy } = input.fetched.result;
	const uploaded = await putTextToR2(`site-audit/${input.projectId}/${input.auditId}/${pageId}-${strategy}.json`, input.fetched.payloadJson);
	return {
		...input.fetched.result,
		r2Key: uploaded.key,
		payloadSizeBytes: uploaded.sizeBytes
	};
}
/**
* Select which pages to run Lighthouse on, based on the chosen strategy.
*/
function selectLighthouseSample(pages, startUrl, strategy) {
	if (strategy === "none") return [];
	const validPages = pages.filter((p) => p.statusCode >= 200 && p.statusCode < 300 && p.fetchClass === "ok");
	const selected = /* @__PURE__ */ new Set();
	const startKey = canonicalUrlKey(startUrl);
	const startPage = validPages.find((p) => canonicalUrlKey(p.url) === startKey) ?? validPages.find((p) => canonicalUrlKeyWithoutTrailingSlash(p.url) === canonicalUrlKeyWithoutTrailingSlash(startUrl));
	if (startPage) selected.add(startPage.url);
	const templateGroups = /* @__PURE__ */ new Map();
	if (startPage) templateGroups.set(detectUrlTemplate(new URL(startPage.url).pathname), startPage);
	for (const page of validPages) {
		if (selected.has(page.url)) continue;
		const template = detectUrlTemplate(new URL(page.url).pathname);
		if (!templateGroups.has(template)) templateGroups.set(template, page);
	}
	for (const [, page] of templateGroups) {
		if (selected.size >= 10) break;
		selected.add(page.url);
	}
	return Array.from(selected);
}
//#endregion
//#region src/shared/json.ts
function jsonCodec(schema) {
	return codec(string(), schema, {
		decode: (jsonString, context) => {
			let parsed;
			try {
				parsed = JSON.parse(jsonString);
			} catch {
				context.issues.push({
					code: "custom",
					message: "Invalid JSON",
					input: jsonString
				});
				return NEVER;
			}
			const validated = schema.safeParse(parsed);
			if (!validated.success) {
				context.issues.push({
					code: "custom",
					message: "JSON does not match schema",
					input: jsonString
				});
				return NEVER;
			}
			return validated.data;
		},
		encode: (value) => JSON.stringify(value)
	});
}
//#endregion
//#region src/server/lib/audit/progress-kv.ts
/**
* KV-based live crawl progress.
*
* During a crawl, each crawled URL is appended to a KV key so the UI can
* poll for a live feed of crawled pages (most recent first).
*
* The KV entry auto-expires after 30 minutes \u2014 it's only needed while
* the audit is running. Once finalized, we explicitly delete it.
*/
var KV_PREFIX = "audit-progress:";
var TTL_SECONDS = 1800;
var MAX_ENTRIES = 300;
var crawledUrlEntrySchema = object({
	url: string(),
	statusCode: number(),
	title: string(),
	/** Unix timestamp ms when this page was crawled */
	crawledAt: number()
});
var crawledEntriesCodec = jsonCodec(array(crawledUrlEntrySchema));
function parseCrawledEntries(json) {
	if (!json) return [];
	const parsed = crawledEntriesCodec.safeParse(json);
	return parsed.success ? parsed.data : [];
}
function key(auditId) {
	return `${KV_PREFIX}${auditId}`;
}
/**
* Append multiple crawled URL entries in one KV write.
* New entries are prepended and the list is capped.
*/
async function pushCrawledUrls(auditId, nextEntries) {
	if (nextEntries.length === 0) return;
	const k = key(auditId);
	const entries = parseCrawledEntries(await env.KV.get(k, "text"));
	const merged = [...nextEntries, ...entries].slice(0, MAX_ENTRIES);
	await env.KV.put(k, JSON.stringify(merged), { expirationTtl: TTL_SECONDS });
}
/**
* Read all crawled URL entries for a running audit.
* Returns newest-first.
*/
async function getCrawledUrls(auditId) {
	return parseCrawledEntries(await env.KV.get(key(auditId), "text"));
}
/**
* Delete the progress key (called after audit completes).
*/
async function clear(auditId) {
	await env.KV.delete(key(auditId));
}
var AuditProgressKV = {
	pushCrawledUrls,
	getCrawledUrls,
	clear
};
//#endregion
//#region src/server/lib/audit/issues/multipage-checks.ts
var DUPLICATE_GROUP_SAMPLE = 3;
function isOkHtmlPage(page) {
	return page.fetchClass === "ok" && page.statusCode !== null && page.statusCode >= 200 && page.statusCode < 300;
}
/**
* Pages the owner already de-duplicated (noindex, or canonicalized to
* another URL) don't belong in duplicate groups \u2014 flagging them tells the
* user to fix something they already fixed.
*/
function isDuplicateCandidate(page) {
	if (!isOkHtmlPage(page) || !page.isIndexable) return false;
	const effectiveCanonical = page.canonicalUrl ?? page.headerCanonicalUrl;
	return !effectiveCanonical || effectiveCanonical === page.url;
}
function findDuplicates(pages) {
	const okPages = pages.filter(isDuplicateCandidate);
	const groupBy = (keyOf) => {
		const groups = /* @__PURE__ */ new Map();
		for (const page of okPages) {
			const key = keyOf(page);
			if (!key) continue;
			const group = groups.get(key);
			if (group) group.push(page);
			else groups.set(key, [page]);
		}
		return groups;
	};
	const issues = [];
	const emitGroups = (groups, issueType) => {
		for (const group of groups.values()) {
			if (group.length < 2) continue;
			for (const page of group) issues.push({
				issueType,
				pageId: page.id,
				pageUrl: page.url,
				details: {
					groupSize: group.length,
					otherUrls: group.filter((other) => other.id !== page.id).slice(0, DUPLICATE_GROUP_SAMPLE).map((other) => other.url)
				}
			});
		}
	};
	emitGroups(groupBy((page) => page.title || null), "duplicate-title");
	emitGroups(groupBy((page) => page.metaDescription || null), "duplicate-meta-description");
	emitGroups(groupBy((page) => page.wordCount > 0 ? page.contentHash : null), "duplicate-content");
	return issues;
}
function findRedirectChainsAndLoops(pages) {
	const redirects = /* @__PURE__ */ new Map();
	for (const page of pages) if (page.statusCode !== null && page.statusCode >= 300 && page.statusCode < 400 && page.redirectUrl) redirects.set(page.url, page);
	const redirectTargets = new Set(Array.from(redirects.values(), (page) => page.redirectUrl));
	const issues = [];
	const walked = /* @__PURE__ */ new Set();
	for (const [url, head] of redirects) {
		if (redirectTargets.has(url)) continue;
		const hops = [url];
		const seen = new Set(hops);
		walked.add(url);
		let current = head.redirectUrl;
		let isLoop = false;
		while (current) {
			if (seen.has(current)) {
				isLoop = true;
				hops.push(current);
				break;
			}
			hops.push(current);
			seen.add(current);
			if (redirects.has(current)) walked.add(current);
			current = redirects.get(current)?.redirectUrl ?? null;
		}
		if (isLoop) issues.push({
			issueType: "redirect-loop",
			pageId: head.id,
			pageUrl: url,
			details: { hops }
		});
		else if (hops.length > 2) issues.push({
			issueType: "redirect-chain",
			pageId: head.id,
			pageUrl: url,
			details: {
				hops,
				finalUrl: hops[hops.length - 1]
			}
		});
	}
	for (const [url, page] of redirects) {
		if (walked.has(url)) continue;
		const cycle = [];
		let current = url;
		while (current && !walked.has(current)) {
			walked.add(current);
			cycle.push(current);
			current = redirects.get(current)?.redirectUrl ?? null;
		}
		issues.push({
			issueType: "redirect-loop",
			pageId: page.id,
			pageUrl: url,
			details: { hops: [...cycle, url] }
		});
	}
	return issues;
}
//#endregion
//#region src/server/lib/audit/issues/multipage.ts
/**
* Cross-page checks that need the whole crawl: duplicate titles, meta
* descriptions and content, plus redirect chains and loops.
*
* Reads the audit's persisted page rows from the app DB. Link-graph checks
* (broken links, orphan pages) are not here: they run inside the
* audit's scratchpad Durable Object (AuditScratchpad.runFinalizeChecks),
* next to the link edges themselves \u2014 link rows never touch the app DB.
*/
async function runMultipageChecks(input) {
	const shellPageIds = new Set((await db.select({ pageId: auditIssues.pageId }).from(auditIssues).where(and(eq(auditIssues.auditId, input.auditId), eq(auditIssues.issueType, "javascript-rendering-suspected")))).map((row) => row.pageId));
	const pages = (await db.select({
		id: auditPages.id,
		url: auditPages.url,
		statusCode: auditPages.statusCode,
		fetchClass: auditPages.fetchClass,
		redirectUrl: auditPages.redirectUrl,
		title: auditPages.title,
		metaDescription: auditPages.metaDescription,
		contentHash: auditPages.contentHash,
		wordCount: auditPages.wordCount,
		isIndexable: auditPages.isIndexable,
		canonicalUrl: auditPages.canonicalUrl,
		headerCanonicalUrl: auditPages.headerCanonicalUrl
	}).from(auditPages).where(eq(auditPages.auditId, input.auditId))).filter((page) => !shellPageIds.has(page.id));
	return {
		issues: [...findDuplicates(pages), ...findRedirectChainsAndLoops(pages)],
		hasUnreadShells: shellPageIds.size > 0
	};
}
//#endregion
//#region src/server/lib/audit/issues/page-reporters.ts
var TITLE_MAX_CHARS = 60;
var TITLE_MIN_CHARS = 10;
var META_DESCRIPTION_MAX_CHARS = 160;
var META_DESCRIPTION_MIN_CHARS = 70;
var THIN_CONTENT_WORDS = 150;
var SLOW_RESPONSE_MS$1 = 1500;
var DEEP_PAGE_DEPTH = 5;
var MAX_FLAGGED_TEXT_CHARS = 100;
function truncateFlaggedText(text) {
	return text.length > MAX_FLAGGED_TEXT_CHARS ? `${text.slice(0, MAX_FLAGGED_TEXT_CHARS)}\u2026` : text;
}
function hasHeadingLevelSkip(headingOrder) {
	for (let i = 1; i < headingOrder.length; i++) if (headingOrder[i] > headingOrder[i - 1] + 1) return true;
	return false;
}
function runPageReporters(page) {
	const issues = [];
	const report = (issueType, details) => issues.push({
		issueType,
		pageId: page.id,
		pageUrl: page.url,
		details
	});
	if (page.fetchClass === "blocked") {
		report("blocked-page", { statusCode: page.statusCode });
		return issues;
	}
	if (page.fetchClass === "rate_limited") {
		report("rate-limited-page", { statusCode: page.statusCode });
		return issues;
	}
	if (page.fetchClass === "error") return issues;
	if (page.statusCode >= 500) {
		report("server-error", { statusCode: page.statusCode });
		return issues;
	}
	if (page.statusCode >= 400) {
		report("broken-page", { statusCode: page.statusCode });
		return issues;
	}
	if (page.statusCode >= 300) return issues;
	if (page.responseTimeMs > SLOW_RESPONSE_MS$1) report("slow-response", { responseTimeMs: page.responseTimeMs });
	if (!page.isHtml) return issues;
	if (!page.isIndexable) report("noindex-page", {
		robotsMeta: page.robotsMeta,
		xRobotsTag: page.xRobotsTag
	});
	if (page.canonicalUrl && page.headerCanonicalUrl && page.canonicalUrl !== page.headerCanonicalUrl) report("canonical-conflict", {
		htmlCanonical: page.canonicalUrl,
		headerCanonical: page.headerCanonicalUrl
	});
	const effectiveCanonical = page.canonicalUrl ?? page.headerCanonicalUrl;
	if (effectiveCanonical && effectiveCanonical !== page.url) report("canonicalized-page", { canonicalUrl: effectiveCanonical });
	if (page.crawlDepth !== null && page.crawlDepth >= DEEP_PAGE_DEPTH) report("deep-page", { crawlDepth: page.crawlDepth });
	if (page.javascriptShell) {
		report("javascript-rendering-suspected", { wordCount: page.wordCount });
		return issues;
	}
	if (!page.title) report("missing-title");
	else if (page.title.length > TITLE_MAX_CHARS) report("title-too-long", {
		length: page.title.length,
		max: TITLE_MAX_CHARS,
		title: truncateFlaggedText(page.title)
	});
	else if (page.title.length < TITLE_MIN_CHARS) report("title-too-short", {
		length: page.title.length,
		min: TITLE_MIN_CHARS,
		title: page.title
	});
	if (!page.metaDescription) report("missing-meta-description");
	else if (page.metaDescription.length > META_DESCRIPTION_MAX_CHARS) report("meta-description-too-long", {
		length: page.metaDescription.length,
		max: META_DESCRIPTION_MAX_CHARS,
		description: truncateFlaggedText(page.metaDescription)
	});
	else if (page.metaDescription.length < META_DESCRIPTION_MIN_CHARS) report("meta-description-too-short", {
		length: page.metaDescription.length,
		min: META_DESCRIPTION_MIN_CHARS,
		description: page.metaDescription
	});
	if (page.h1Count === 0) report("missing-h1");
	else if (page.h1Count > 1) report("multiple-h1", { h1Count: page.h1Count });
	if (hasHeadingLevelSkip(page.headingOrder)) report("heading-order-skip");
	if (page.isIndexable && page.wordCount < THIN_CONTENT_WORDS) report("thin-content", { wordCount: page.wordCount });
	if (page.imagesMissingAlt > 0) report("images-missing-alt", {
		imagesMissingAlt: page.imagesMissingAlt,
		imagesTotal: page.imagesTotal
	});
	if (page.isIndexable && page.links.length === 0) report("no-outgoing-links");
	return issues;
}
//#endregion
//#region src/server/workflows/siteAuditWorkflowPersist.ts
/**
* Mega-menu/footer-heavy sites can carry 1000+ links per page; cap what we
* record so a 10k-page crawl can't produce tens of millions of link targets
* to scan at finalize.
*/
var MAX_STORED_LINKS_PER_PAGE = 500;
/**
* Cap newly discovered URLs sent to the scratchpad per persist sub-batch.
* Serialized RPC messages are limited to 32 MiB; a crawler-trap page family
* (faceted nav, calendars) can emit tens of thousands of unique URLs per
* page. Dropped URLs are usually re-discovered from later pages, and a site
* generating this many is past maxPages anyway.
*/
var MAX_DISCOVERED_PER_BATCH = 2e4;
var MAX_PROGRESS_TITLE_CHARS = 300;
function shouldQueueCrawlLink(link, origin, robots, sitePlatform) {
	return isSameOrigin(link, origin) && isCrawlableUrl(link) && isAuditablePageUrl(link, sitePlatform) && robots.isAllowed(link);
}
/**
* Persists one crawled sub-batch: page rows and issues to the app DB, links
* and newly discovered URLs to the scratchpad, and progress for the UI.
*/
async function persistCrawledPages(input) {
	const { auditId, origin, robots, sitePlatform, scratchpad, pages, depthByUrl } = input;
	for (const page of pages) page.id = await deterministicAuditRowId(auditId, page.url);
	const issues = pages.flatMap((page) => runPageReporters(page));
	await AuditRepository.insertCrawledBatch(auditId, pages, issues);
	const links = [];
	const discovered = /* @__PURE__ */ new Map();
	for (const page of pages) {
		const pageDepth = depthByUrl.get(page.url) ?? null;
		const childDepth = pageDepth === null ? null : pageDepth + 1;
		const targets = [];
		for (const link of page.links) {
			if (!link.isInternal) continue;
			if (targets.length < MAX_STORED_LINKS_PER_PAGE) targets.push(link.targetUrl);
			if (discovered.size < MAX_DISCOVERED_PER_BATCH && !discovered.has(link.targetUrl) && shouldQueueCrawlLink(link.targetUrl, origin, robots, sitePlatform)) discovered.set(link.targetUrl, childDepth);
		}
		if (targets.length > 0) links.push({
			pageId: page.id,
			url: page.url,
			targets
		});
		if (page.redirectUrl && !discovered.has(page.redirectUrl) && shouldQueueCrawlLink(page.redirectUrl, origin, robots, sitePlatform)) discovered.set(page.redirectUrl, pageDepth);
	}
	const stats = await scratchpad.recordBatch({
		crawledUrls: pages.map((page) => page.url),
		pages: pages.map((page) => ({
			pageId: page.id,
			url: page.url,
			statusCode: page.statusCode,
			fetchClass: page.fetchClass,
			redirectUrl: page.redirectUrl
		})),
		links,
		discovered: Array.from(discovered, ([url, depth]) => ({
			url,
			depth
		}))
	});
	await AuditRepository.updateAuditProgress(auditId, input.workflowInstanceId, {
		pagesCrawled: stats.attempted,
		pagesTotal: Math.min(stats.seen, input.maxPages)
	});
	await AuditProgressKV.pushCrawledUrls(auditId, pages.map((page) => ({
		url: page.url,
		statusCode: page.statusCode,
		title: page.title.slice(0, MAX_PROGRESS_TITLE_CHARS),
		crawledAt: Date.now()
	})));
	return stats;
}
//#endregion
//#region src/server/lib/audit/crawl-window.ts
var CRAWL_WINDOW = {
	initial: 2,
	min: 1,
	max: 2,
	budgetBytes: 8388608
};
/**
* Limits for a chunk whose earlier attempt died mid-crawl \u2014 in production
* often exceededMemory on a heavy-page site, so a retry must not re-run the
* exact memory profile that just killed the isolate.
*/
var RETRY_CRAWL_WINDOW = {
	initial: 1,
	min: 1,
	max: 1,
	budgetBytes: 4194304
};
var SLOW_RESPONSE_MS = 1e4;
var FAST_RESPONSE_MS = 1500;
/** Floor for the observed page size so tiny-page sites can't void the bound. */
var MIN_ASSUMED_PAGE_BYTES = 65536;
/**
* Growth requires a full-size sample. The first persist sub-batch is small
* (so the byte bound reacts to heavy pages early), and a handful of fast
* pages proves too little to widen the window.
*/
var GROWTH_MIN_SAMPLE = 25;
function clampCrawlWindow(size, limits) {
	return Math.min(Math.max(size, limits.min), limits.max);
}
/**
* Adapt the window to the last persisted sub-batch. Shrinks on trouble
* (errors, blocks, very slow responses), grows only on a clean, mostly fast,
* full-size batch, and is always capped so the batch's average page size
* times the window stays inside the in-flight byte budget.
*/
function adjustCrawlWindow(windowSize, recent, limits = CRAWL_WINDOW) {
	if (recent.length === 0) return windowSize;
	const troubled = recent.filter((page) => page.fetchClass !== "ok" || page.rateLimited || (page.responseTimeMs ?? 0) >= SLOW_RESPONSE_MS).length;
	let next = windowSize;
	if (troubled * 3 >= recent.length) next = Math.max(limits.min, Math.floor(windowSize / 2));
	else {
		const fast = recent.filter((page) => page.fetchClass === "ok" && (page.responseTimeMs ?? Infinity) <= FAST_RESPONSE_MS).length;
		if (troubled === 0 && fast * 2 >= recent.length && recent.length >= GROWTH_MIN_SAMPLE) next = Math.min(limits.max, windowSize + 5);
	}
	const avgPageBytes = Math.max(recent.reduce((sum, page) => sum + page.htmlBytes, 0) / recent.length, MIN_ASSUMED_PAGE_BYTES);
	const byteBound = Math.max(limits.min, Math.floor(limits.budgetBytes / avgPageBytes));
	return Math.min(next, byteBound);
}
//#endregion
//#region src/server/workflows/site-audit-workflow-helpers.ts
/** Parse `Link: <url>; rel="canonical"` response headers. */
function parseLinkHeaderCanonical(linkHeader, pageUrl) {
	if (!linkHeader) return null;
	for (const part of linkHeader.split(",")) {
		const match = part.match(/<([^>]+)>\s*;([^]*)/);
		if (!match) continue;
		if (/rel\s*=\s*"?canonical"?/i.test(match[2])) return normalizeUrl(match[1].trim(), pageUrl, { keepTrackingParams: true });
	}
	return null;
}
/**
* One warning per 429 so production shows what the edge answers: the
* Retry-After, how fast it came back (Shopify refuses at its edge within
* milliseconds), whether the request carried a crawler signature, and the
* body's first words (Shopify writes `local_rate_limited`).
*/
async function logRateLimited(input) {
	const { url, response, responseTimeMs, attempt, signed } = input;
	let body = "";
	try {
		body = (await readTextUpTo(response.clone(), 80)).trim();
	} catch {}
	console.warn("site_audit:rate_limited", {
		url,
		attempt,
		signed,
		responseTimeMs,
		retryAfter: response.headers.get("retry-after"),
		cfCacheStatus: response.headers.get("cf-cache-status"),
		xRequestId: response.headers.get("x-request-id"),
		cfRay: response.headers.get("cf-ray"),
		body
	});
}
/**
* Fetch one URL, pausing the whole chunk and retrying once while the site
* 429s (see crawl-throttle.ts). `responseTimeMs` is measured from the last
* attempt so backoff waiting never looks like a slow server.
*/
async function fetchPage(url, throttle, access, skipBackoff) {
	for (let attempt = 1;; attempt++) {
		if (!await throttle.ready()) return null;
		const startedAt = Date.now();
		const response = await publicFetch(url, {
			headers: {
				Accept: "text/html,application/xhtml+xml",
				...await auditRequestHeaders(url, access)
			},
			redirect: "manual",
			signal: AbortSignal.timeout(15e3)
		});
		const result = {
			response,
			responseTimeMs: Date.now() - startedAt,
			rateLimited: attempt > 1
		};
		if (response.status !== 429) {
			await throttle.recovered(url);
			return result;
		}
		await logRateLimited({
			url,
			response,
			responseTimeMs: result.responseTimeMs,
			attempt,
			signed: Object.keys(crawlerHeadersFor(url, access)).length > 0
		});
		if (skipBackoff) return result;
		if (!await throttle.backoff(url, response.headers.get("retry-after"))) return result;
		await response.body?.cancel();
	}
}
/** Null leaves this URL deferred when the shared cooldown stops its fetch. */
async function crawlPage(url, crawlDepth, inSitemap, throttle, options = {}) {
	const { access, render } = options;
	const renderThrottled = Boolean(render && options.renderThrottled);
	const startTime = Date.now();
	try {
		const fetched = await fetchPage(url, throttle, access, renderThrottled);
		if (!fetched) return null;
		const { response, responseTimeMs, rateLimited } = fetched;
		let statusCode = response.status;
		const xRobotsTag = response.headers.get("x-robots-tag");
		const headerCanonicalUrl = parseLinkHeaderCanonical(response.headers.get("link"), url);
		if (statusCode >= 300 && statusCode < 400) {
			const location = response.headers.get("location");
			const redirectUrl = location ? normalizeUrl(location, url) : null;
			return emptyPageResult({
				url,
				statusCode,
				fetchClass: "ok",
				redirectUrl,
				responseTimeMs,
				xRobotsTag,
				headerCanonicalUrl,
				crawlDepth,
				inSitemap,
				rateLimited
			});
		}
		let isHtml = (response.headers.get("content-type") ?? "").includes("text/html");
		let body = isHtml ? await readTextUpTo(response, MAX_HTML_BYTES) : "";
		let fetchClass = classifyFetch(statusCode, Boolean(response.headers.get("cf-mitigated")), body.slice(0, 4e3));
		const challenged = fetchClass === "blocked" && statusCode !== 401;
		const throttled = renderThrottled && statusCode === 429;
		if (render && (throttled || challenged || isHtml && fetchClass === "ok" && statusCode < 400)) {
			if (!isHtml) await response.body?.cancel();
			try {
				const page = await render(url);
				body = page.html;
				isHtml = true;
				if (challenged || throttled) statusCode = page.status ?? 200;
				fetchClass = classifyFetch(statusCode, false, body.slice(0, 4e3));
			} catch (error) {
				if (!challenged && !throttled) throw error;
				if (throttled) await throttle.refuse(url, response.headers.get("retry-after"));
			}
		}
		if (!isHtml || fetchClass !== "ok" || statusCode >= 400) return emptyPageResult({
			url,
			statusCode,
			fetchClass,
			redirectUrl: null,
			responseTimeMs,
			xRobotsTag,
			headerCanonicalUrl,
			crawlDepth,
			inSitemap,
			htmlBytes: body.length,
			rateLimited
		});
		const { analyzeHtml } = await import("./assets/page-analyzer-CxfrqX_c.js");
		const analysis = analyzeHtml(body, url, statusCode, responseTimeMs);
		const javascriptShell = analysis.javascriptShell === true;
		const isIndexable = ![analysis.robotsMeta, xRobotsTag].filter(Boolean).join(",").toLowerCase().includes("noindex");
		const headingCount = (level) => analysis.headingOrder.filter((h) => h === level).length;
		return structuredClone({
			id: crypto.randomUUID(),
			url,
			statusCode,
			fetchClass,
			redirectUrl: null,
			title: analysis.title,
			metaDescription: analysis.metaDescription,
			canonicalUrl: analysis.canonical ? normalizeUrl(analysis.canonical, url, { keepTrackingParams: true }) ?? analysis.canonical : null,
			robotsMeta: analysis.robotsMeta,
			xRobotsTag,
			headerCanonicalUrl,
			ogTitle: analysis.ogTitle,
			ogDescription: analysis.ogDescription,
			ogImage: analysis.ogImage,
			h1Count: analysis.h1s.filter((h) => h.length > 0).length,
			h2Count: headingCount(2),
			h3Count: headingCount(3),
			h4Count: headingCount(4),
			h5Count: headingCount(5),
			h6Count: headingCount(6),
			headingOrder: analysis.headingOrder,
			wordCount: analysis.wordCount,
			contentHash: analysis.bodyText && !javascriptShell ? await sha256Hex(analysis.bodyText) : null,
			isHtml: true,
			javascriptShell,
			htmlBytes: body.length,
			rateLimited,
			imagesTotal: analysis.images.length,
			imagesMissingAlt: analysis.images.filter((img) => img.alt === null).length,
			images: analysis.images,
			links: analysis.links,
			hasStructuredData: analysis.hasStructuredData,
			hreflangTags: analysis.hreflangTags,
			isIndexable,
			responseTimeMs,
			crawlDepth,
			inSitemap
		});
	} catch (error) {
		if (throttle.checkpointFailed) throw error;
		const responseTimeMs = Date.now() - startTime;
		console.warn(`Failed to crawl ${url}:`, error);
		return emptyPageResult({
			url,
			statusCode: 0,
			fetchClass: "error",
			redirectUrl: null,
			responseTimeMs,
			xRobotsTag: null,
			headerCanonicalUrl: null,
			crawlDepth,
			inSitemap
		});
	}
}
function emptyPageResult(input) {
	return {
		id: crypto.randomUUID(),
		url: input.url,
		statusCode: input.statusCode,
		fetchClass: input.fetchClass,
		redirectUrl: input.redirectUrl,
		title: "",
		metaDescription: "",
		canonicalUrl: null,
		robotsMeta: null,
		xRobotsTag: input.xRobotsTag,
		headerCanonicalUrl: input.headerCanonicalUrl,
		ogTitle: null,
		ogDescription: null,
		ogImage: null,
		h1Count: 0,
		h2Count: 0,
		h3Count: 0,
		h4Count: 0,
		h5Count: 0,
		h6Count: 0,
		headingOrder: [],
		wordCount: 0,
		contentHash: null,
		isHtml: false,
		htmlBytes: input.htmlBytes ?? 0,
		rateLimited: input.rateLimited ?? false,
		imagesTotal: 0,
		imagesMissingAlt: 0,
		images: [],
		links: [],
		hasStructuredData: false,
		hreflangTags: [],
		isIndexable: false,
		responseTimeMs: input.responseTimeMs,
		crawlDepth: input.crawlDepth,
		inSitemap: input.inSitemap
	};
}
//#endregion
//#region src/server/workflows/pgStep.ts
/**
* `step.do` with a request-scoped Postgres client active inside the step body.
*
* Cloudflare Workflows invoke each step callback in its own execution context \u2014
* steps are independently persisted and can resume in a fresh invocation, so the
* `AsyncLocalStorage` scope opened by `withPgClient` around `run()` does NOT
* propagate into a step. Each DB-touching step must therefore open its own
* client. In D1 mode `withPgClient` is a no-op, so this is just a plain
* `step.do`. The client is lazy (postgres-js only connects on first query), so
* wrapping a step that happens not to touch the DB costs nothing.
*
* `T` mirrors `step.do`'s own `Rpc.Serializable<T>` bound so step results stay
* serializable (the workflow engine persists and replays them). Pass `undefined`
* for `config` to use the engine's default step config (matches the 2-arg
* `step.do(name, fn)` form).
*/
function pgStep(step, name, config, fn) {
	return config ? step.do(name, config, () => withPgClient(fn)) : step.do(name, () => withPgClient(fn));
}
//#endregion
//#region src/server/workflows/auditStepConfigs.ts
/**
* Explicit step configs for the site-audit workflow.
*
* Without these, steps inherit the platform default (10-minute timeout,
* multiple retries with backoff) \u2014 production audits against slow/hostile
* sites burned ~65 minutes replaying a doomed step before erroring. Every
* step now has a timeout sized to its real work and a small retry budget.
*/
/** Redirect probe of the start URL: up to 5 hops at 10s each. */
var START_URL_STEP = {
	retries: {
		limit: 2,
		delay: "5 seconds",
		backoff: "exponential"
	},
	timeout: "2 minutes"
};
/** Robots + sitemap walk (bounded at 300 docs / 15s per fetch internally). */
var DISCOVERY_STEP = {
	retries: {
		limit: 2,
		delay: "5 seconds",
		backoff: "exponential"
	},
	timeout: "4 minutes"
};
/**
* One crawl chunk: ~90s soft crawl deadline + persistence headroom. Workflows
* now and then loses an attempt whose code finished (WorkflowInternalError),
* and a long audit runs enough chunks to hit two losses in a row, so one
* retry is not enough. Chunk writes are idempotent.
*/
var CRAWL_CHUNK_STEP = {
	retries: {
		limit: 3,
		delay: "10 seconds",
		backoff: "constant"
	},
	timeout: "5 minutes"
};
/**
* One Lighthouse URL (mobile + desktop). DataForSEO charges these calls, so a
* Workflow replay must never issue them again after the step starts.
*/
var LIGHTHOUSE_FETCH_STEP = {
	retries: {
		limit: 0,
		delay: "1 second"
	},
	timeout: "5 minutes"
};
/**
* Confirms a rendered audit's credit lock. Finalizing a lock twice is refused,
* so a replay must not run it again; a failed settlement expires on its own.
*/
var SETTLE_RENDERING_STEP = {
	retries: {
		limit: 0,
		delay: "1 second"
	},
	timeout: "1 minute"
};
/** R2 + DB persistence is idempotent and safe to retry after the paid step. */
var LIGHTHOUSE_PERSIST_STEP = {
	retries: {
		limit: 3,
		delay: "5 seconds",
		backoff: "exponential"
	},
	timeout: "5 minutes"
};
/** Small DB-only steps (validate, select sample, finalize, mark-failed). */
var DB_STEP = {
	retries: {
		limit: 3,
		delay: "5 seconds",
		backoff: "exponential"
	},
	timeout: "2 minutes"
};
/** Cross-page checks read every page row of the audit \u2014 allow more time. */
var MULTIPAGE_CHECKS_STEP = {
	retries: {
		limit: 2,
		delay: "5 seconds",
		backoff: "exponential"
	},
	timeout: "5 minutes"
};
//#endregion
//#region src/server/workflows/siteAuditWorkflowCrawl.ts
/**
* The crawl runs in chunks: each chunk is one durable step that leases up to
* CHUNK_TARGET_PAGES URLs from the scratchpad DO, crawls them with a rolling
* concurrency window, and persists results incrementally (full page rows to
* the app DB, links/mirror/frontier updates to the DO). Step returns carry
* only counters, so step state stays tiny regardless of site size and the
* workflow heap stays O(one batch).
*/
var CHUNK_TARGET_PAGES = 200;
/** Stop launching new fetches after this long; leftover leases are released. */
var CHUNK_SOFT_DEADLINE_MS = 9e4;
/**
* How long past its soft deadline a chunk may keep waiting before it logs the
* fetches it is still waiting on. Longer than any single page fetch or render.
*/
var STUCK_CHUNK_GRACE_MS = 6e4;
/** Crawled pages are persisted in sub-batches of this size. */
var PERSIST_BATCH_SIZE = 25;
/**
* The first sub-batch of a chunk is deliberately small: the crawl window
* only adapts when a sub-batch persists, and on a heavy-page site a full
* 25-page batch crawled at the starting window was already enough to
* exceed the isolate's memory. Five pages tell the byte bound what the
* site's pages weigh before the window commits to more.
*/
var FIRST_PERSIST_BATCH_SIZE = 5;
/**
* Stop launching new fetches while more than this many persist sub-batches
* are waiting: persistence is sequential, so when the DB falls behind a fast
* site, unpersisted page results would otherwise pile up in memory without
* bound.
*/
var MAX_QUEUED_PERSIST_BATCHES = 2;
async function runCrawlPhase(step, params) {
	let chunkNo = 0;
	let attemptedTotal = 0;
	let pending = params.seededCount;
	let zeroProgressChunks = 0;
	let windowHint = CRAWL_WINDOW.initial;
	let throttleState;
	while (pending > 0 && attemptedTotal < params.maxPages) {
		chunkNo += 1;
		const result = await pgStep(step, `crawl-chunk-${chunkNo}`, CRAWL_CHUNK_STEP, () => runCrawlChunk({
			...params,
			chunkNo,
			attemptedBefore: attemptedTotal,
			startWindow: windowHint,
			throttleState
		}));
		attemptedTotal = result.attempted;
		pending = result.pending;
		params.renderUsage.cloudflareAttempts += result.renderUsage?.cloudflareAttempts ?? 0;
		params.renderUsage.contextCredits += result.renderUsage?.contextCredits ?? 0;
		const stoppedBy = result.rateLimited ? "crawl-rate-limited" : result.timedOut ? "crawl-time-limit" : result.outOfCredits && "crawl-credits-exhausted";
		if (stoppedBy) return {
			pagesCrawled: attemptedTotal,
			completed: false,
			stoppedBy
		};
		windowHint = result.endWindow ?? CRAWL_WINDOW.initial;
		throttleState = result.throttleState;
		if (pending > 0 && attemptedTotal < params.maxPages && result.resumeAt) {
			await step.sleepUntil(`crawl-cooldown-${chunkNo}`, result.resumeAt);
			zeroProgressChunks = 0;
			continue;
		}
		zeroProgressChunks = result.attemptedInChunk === 0 ? zeroProgressChunks + 1 : 0;
		if (zeroProgressChunks >= 2) break;
	}
	return {
		pagesCrawled: attemptedTotal,
		completed: pending === 0
	};
}
async function runCrawlChunk(input) {
	const { auditId, workflowInstanceId, origin, maxPages, robots, chunkNo } = input;
	const scratchpad = getAuditScratchpad(auditId);
	const renderDeadlineAt = input.renderHold?.deadlineAt ?? Infinity;
	let previousThrottle = await scratchpad.getCrawlThrottle() ?? input.throttleState;
	const claimLimit = Math.min(CHUNK_TARGET_PAGES, maxPages - input.attemptedBefore);
	const { urls: claimed, isRetry } = await scratchpad.claimChunk(chunkNo, claimLimit);
	const startedAt = Date.now();
	console.info("site_audit:chunk_start", {
		auditId,
		chunkNo,
		claimed: claimed.length,
		isRetry
	});
	const logChunkEnd = (result) => {
		console.info("site_audit:chunk_end", {
			auditId,
			chunkNo,
			attemptedInChunk: result.attemptedInChunk,
			attempted: result.attempted,
			pending: result.pending,
			durationMs: Date.now() - startedAt,
			rateLimited: result.rateLimited,
			timedOut: result.timedOut,
			outOfCredits: result.outOfCredits,
			resumeAt: result.resumeAt && new Date(result.resumeAt).toISOString()
		});
		return result;
	};
	const deadlineAt = Math.min(Date.now() + CHUNK_SOFT_DEADLINE_MS, renderDeadlineAt);
	if (isRetry && previousThrottle) previousThrottle = {
		...previousThrottle,
		nextRequestAt: Math.max(previousThrottle.nextRequestAt, Date.now() + previousThrottle.intervalMs)
	};
	const throttle = createCrawlThrottle(deadlineAt, previousThrottle, async (state) => {
		try {
			await scratchpad.saveCrawlThrottle(state);
		} catch {
			throw new NonRetryableError("Unable to save the site's crawl cooldown.");
		}
	});
	if (claimed.length === 0) {
		const stats = await scratchpad.getStats();
		return logChunkEnd({
			attemptedInChunk: 0,
			attempted: stats.attempted,
			pending: stats.pending,
			endWindow: input.startWindow,
			throttleState: throttle.state,
			rateLimited: throttle.stopped,
			resumeAt: throttle.state.pausedUntil > Date.now() ? throttle.state.pausedUntil : void 0
		});
	}
	const depthByUrl = new Map(claimed.map((entry) => [entry.url, entry.depth]));
	const limits = isRetry ? RETRY_CRAWL_WINDOW : CRAWL_WINDOW;
	let windowSize = isRetry ? limits.initial : clampCrawlWindow(input.startWindow, limits);
	let nextIndex = 0;
	let attemptedInChunk = 0;
	const inFlight = /* @__PURE__ */ new Set();
	const inFlightSince = /* @__PURE__ */ new Map();
	const deferred = [];
	let persistThreshold = FIRST_PERSIST_BATCH_SIZE;
	let batch = [];
	let persistChain = Promise.resolve();
	let queuedPersists = 0;
	const flush = () => {
		if (batch.length === 0) return;
		const pages = batch;
		batch = [];
		persistThreshold = PERSIST_BATCH_SIZE;
		windowSize = adjustCrawlWindow(windowSize, pages, limits);
		queuedPersists += 1;
		persistChain = persistChain.then(() => persistCrawledPages({
			auditId,
			workflowInstanceId,
			origin,
			robots,
			sitePlatform: input.sitePlatform,
			scratchpad,
			pages,
			depthByUrl,
			maxPages
		})).finally(() => {
			queuedPersists -= 1;
		});
	};
	const renderUsage = {
		cloudflareAttempts: 0,
		contextCredits: 0
	};
	const canAffordRender = (pending) => !input.renderHold || renderUsageCredits({
		cloudflareAttempts: input.renderUsage.cloudflareAttempts + renderUsage.cloudflareAttempts,
		contextCredits: input.renderUsage.contextCredits + renderUsage.contextCredits
	}) + estimateRenderingCredits(pending + 1).high <= input.renderHold.credits;
	const render = input.renderJavaScript ? async (url) => {
		const { RenderedPageService } = await import("./assets/rendered-page-DMDqZ7fR.js");
		return RenderedPageService.renderPage(url, {
			browser: env.BROWSER,
			contextFetch: await getContextFetch(),
			auditId,
			usage: renderUsage
		});
	} : void 0;
	const launch = (entry) => {
		const promise = crawlPage(entry.url, entry.depth, entry.inSitemap, throttle, {
			access: input.access,
			render,
			renderThrottled: input.sitePlatform === "shopify"
		}).then((page) => {
			if (!page) {
				deferred.push(entry.url);
				return;
			}
			attemptedInChunk += 1;
			batch.push(page);
			if (batch.length >= persistThreshold) flush();
		}).finally(() => {
			inFlight.delete(promise);
			inFlightSince.delete(entry.url);
		});
		inFlight.add(promise);
		inFlightSince.set(entry.url, Date.now());
	};
	const logFullUrls = !await isHostedServerAuthMode();
	const stuckTimer = setTimeout(() => {
		console.warn("site_audit:chunk_stuck", {
			auditId,
			chunkNo,
			queuedPersists,
			inFlight: [...inFlightSince].map(([url, since]) => ({
				url: logFullUrls ? url : new URL(url).pathname,
				seconds: Math.round((Date.now() - since) / 1e3)
			}))
		});
	}, Math.max(0, deadlineAt - Date.now()) + STUCK_CHUNK_GRACE_MS);
	while (true) {
		while (inFlight.size < windowSize && nextIndex < claimed.length && Date.now() < deadlineAt) {
			if (throttle.stopped || queuedPersists > MAX_QUEUED_PERSIST_BATCHES || !canAffordRender(inFlight.size)) break;
			launch(claimed[nextIndex]);
			nextIndex += 1;
		}
		if (inFlight.size > 0) {
			await Promise.race(inFlight);
			continue;
		}
		if (!throttle.stopped && queuedPersists > MAX_QUEUED_PERSIST_BATCHES && nextIndex < claimed.length && Date.now() < deadlineAt) {
			await persistChain;
			continue;
		}
		break;
	}
	flush();
	await persistChain;
	clearTimeout(stuckTimer);
	await scratchpad.saveCrawlThrottle(throttle.state);
	const unattempted = [...deferred, ...claimed.slice(nextIndex).map((entry) => entry.url)];
	if (unattempted.length > 0) await scratchpad.releaseUrls(unattempted);
	const stats = await scratchpad.getStats();
	const throttleState = throttle.state;
	return logChunkEnd({
		attemptedInChunk,
		attempted: stats.attempted,
		pending: stats.pending,
		endWindow: windowSize,
		rateLimited: throttle.stopped,
		outOfCredits: unattempted.length > 0 && !canAffordRender(0),
		timedOut: unattempted.length > 0 && Math.max(Date.now(), throttleState.pausedUntil, throttleState.nextRequestAt) >= renderDeadlineAt,
		throttleState,
		resumeAt: throttleState.pausedUntil > Date.now() ? throttleState.pausedUntil : void 0,
		renderUsage
	});
}
//#endregion
//#region src/server/workflows/siteAuditWorkflowPhases.ts
/**
* URLs fetched concurrently per wave. Each URL runs mobile + desktop, so one
* wave holds up to 10 paid DataForSEO calls in flight; the aux worker's parse
* lock serializes the memory-heavy payload parsing behind them.
*/
var LIGHTHOUSE_URL_CONCURRENCY = 5;
/** Frontier seeds per scratchpad RPC call. */
var SEED_RPC_BATCH = 2e3;
async function runAuditPhases(step, params) {
	const { auditId, workflowInstanceId, billingCustomer, projectId, startUrl, config, access } = params;
	const origin = getOrigin(startUrl);
	const maxPages = config.maxPages;
	const discovery = await runDiscoveryPhase(step, {
		auditId,
		workflowInstanceId,
		origin,
		startUrl,
		maxPages,
		access
	});
	const robots = parseRobotsTxt(origin, discovery.robotsText);
	const crawl = await runCrawlPhase(step, {
		...params,
		origin,
		maxPages,
		robots,
		seededCount: discovery.seededCount,
		renderJavaScript: config.renderJavaScript,
		sitePlatform: config.sitePlatform
	});
	await runLighthousePhase(step, {
		auditId,
		workflowInstanceId,
		billingCustomer,
		projectId,
		startUrl,
		config
	});
	await finalizeAudit({
		step,
		auditId,
		workflowInstanceId,
		billingCustomer,
		projectId,
		startUrl,
		config,
		crawl
	});
}
async function runDiscoveryPhase(step, input) {
	const { auditId, workflowInstanceId, origin, startUrl, maxPages, access } = input;
	return pgStep(step, "discover-urls-v2", DISCOVERY_STEP, async () => {
		const result = await discoverUrls(origin, maxPages, access);
		const robots = parseRobotsTxt(origin, result.robotsText);
		const scratchpad = getAuditScratchpad(auditId);
		let seededCount = 0;
		const normalizedStart = normalizeUrl(startUrl) ?? startUrl;
		if (robots.isAllowed(normalizedStart) && isSameOrigin(normalizedStart, origin)) {
			await scratchpad.seedStart(normalizedStart);
			seededCount += 1;
		}
		const seen = /* @__PURE__ */ new Set();
		const seeds = [];
		for (const url of result.urls) {
			const normalized = normalizeUrl(url);
			if (!normalized || seen.has(normalized)) continue;
			seen.add(normalized);
			if (!isSameOrigin(normalized, origin)) continue;
			if (!isCrawlableUrl(normalized)) continue;
			if (!isAuditablePageUrl(normalized)) continue;
			if (!robots.isAllowed(normalized)) continue;
			seeds.push(normalized);
		}
		for (let i = 0; i < seeds.length; i += SEED_RPC_BATCH) await scratchpad.seedSitemapUrls(seeds.slice(i, i + SEED_RPC_BATCH));
		seededCount += seeds.filter((seed) => seed !== normalizedStart).length;
		await AuditRepository.updateAuditProgress(auditId, workflowInstanceId, {
			pagesTotal: Math.min(seededCount, maxPages),
			currentPhase: "crawling"
		});
		return {
			robotsText: result.robotsText,
			seededCount
		};
	});
}
async function runLighthousePhase(step, params) {
	const { auditId, workflowInstanceId, billingCustomer, projectId, startUrl, config } = params;
	if (config.lighthouseStrategy === "none") return;
	const lighthouseWork = await selectLighthousePages({
		step,
		auditId,
		workflowInstanceId,
		startUrl,
		strategy: config.lighthouseStrategy
	});
	let completedChecks = 0;
	let failedChecks = 0;
	for (let chunkStart = 0; chunkStart < lighthouseWork.length; chunkStart += LIGHTHOUSE_URL_CONCURRENCY) {
		const chunk = lighthouseWork.slice(chunkStart, chunkStart + LIGHTHOUSE_URL_CONCURRENCY);
		const fetched = (await Promise.allSettled(chunk.map(({ url, pageId }, chunkOffset) => pgStep(step, `lighthouse-fetch-${chunkStart + chunkOffset + 1}`, LIGHTHOUSE_FETCH_STEP, () => Promise.all([fetchLighthouseResult(url, pageId, "mobile", billingCustomer), fetchLighthouseResult(url, pageId, "desktop", billingCustomer)]))))).flatMap((outcome, chunkOffset) => {
			if (outcome.status === "fulfilled") return outcome.value;
			const { url, pageId } = chunk[chunkOffset];
			const message = outcome.reason instanceof Error ? outcome.reason.message : String(outcome.reason);
			return ["mobile", "desktop"].map((strategy) => failedLighthouseFetch(url, pageId, strategy, message));
		});
		const chunkIndex = Math.floor(chunkStart / LIGHTHOUSE_URL_CONCURRENCY) + 1;
		const priorCompleted = completedChecks;
		const priorFailed = failedChecks;
		const counts = await pgStep(step, `lighthouse-persist-chunk-${chunkIndex}`, LIGHTHOUSE_PERSIST_STEP, async () => {
			const results = await Promise.all(fetched.map((result) => storeLighthouseResult({
				projectId,
				auditId,
				fetched: result
			})));
			await AuditRepository.insertLighthouseResults(auditId, results);
			const failed = results.filter((result) => result.errorMessage).length;
			const completed = results.length - failed;
			await AuditRepository.updateAuditProgress(auditId, workflowInstanceId, {
				lighthouseCompleted: priorCompleted + completed,
				lighthouseFailed: priorFailed + failed
			});
			return {
				completed,
				failed
			};
		});
		completedChecks += counts.completed;
		failedChecks += counts.failed;
	}
}
async function selectLighthousePages(params) {
	const { step, auditId, workflowInstanceId, startUrl, strategy } = params;
	return pgStep(step, "select-lighthouse-sample", DB_STEP, async () => {
		const crawledPages = await AuditRepository.getPagesForAudit(auditId);
		const sample = selectLighthouseSample(crawledPages.map((page) => ({
			...page,
			statusCode: page.statusCode ?? 0
		})), startUrl, strategy);
		const selectedUrls = new Set(sample);
		await AuditRepository.updateAuditProgress(auditId, workflowInstanceId, {
			currentPhase: "lighthouse",
			lighthouseTotal: sample.length * 2,
			lighthouseCompleted: 0,
			lighthouseFailed: 0
		});
		return crawledPages.flatMap((page) => selectedUrls.has(page.url) ? [{
			url: page.url,
			pageId: page.id
		}] : []);
	});
}
async function finalizeAudit(args) {
	const { step, auditId, workflowInstanceId, billingCustomer, projectId, startUrl, config, crawl } = args;
	await pgStep(step, "multipage-checks", MULTIPAGE_CHECKS_STEP, async () => {
		await AuditRepository.updateAuditProgress(auditId, workflowInstanceId, { currentPhase: "finalizing" });
		if (crawl.pagesCrawled > 0 && !await AuditRepository.hasPagesForAudit(auditId)) throw new Error(`Audit ${auditId}: crawl reported ${crawl.pagesCrawled} pages but none were persisted`);
		const checksStartedAt = Date.now();
		console.info("Audit finalization started", { auditId });
		const { issues, hasUnreadShells } = await runMultipageChecks({ auditId });
		console.info("Audit multipage checks completed", {
			auditId,
			durationMs: Date.now() - checksStartedAt,
			issueCount: issues.length
		});
		const linksStartedAt = Date.now();
		const linkIssues = await runScratchpadLinkChecks(auditId, startUrl, {
			...crawl,
			completed: crawl.completed && !hasUnreadShells
		});
		console.info("Audit link checks completed", {
			auditId,
			durationMs: Date.now() - linksStartedAt,
			issueCount: linkIssues.length
		});
		issues.push(...linkIssues);
		if (crawl.stoppedBy) issues.push({
			issueType: crawl.stoppedBy,
			pageId: null,
			pageUrl: startUrl
		});
		const persistStartedAt = Date.now();
		await AuditRepository.insertIssues(auditId, issues);
		console.info("Audit finalization issues persisted", {
			auditId,
			durationMs: Date.now() - persistStartedAt,
			issueCount: issues.length
		});
		return { issueCount: issues.length };
	});
	await pgStep(step, "finalize", DB_STEP, async () => {
		const blockedPages = await AuditRepository.countPagesByFetchClass(auditId, "blocked");
		const rateLimitedPages = await AuditRepository.countPagesByFetchClass(auditId, "rate_limited");
		await AuditRepository.completeAudit(auditId, workflowInstanceId, {
			pagesCrawled: crawl.pagesCrawled,
			pagesTotal: crawl.pagesCrawled
		});
		await captureServerEvent({
			distinctId: billingCustomer.userId,
			event: "site_audit:complete",
			organizationId: billingCustomer.organizationId,
			properties: {
				project_id: projectId,
				status: "completed",
				pages_crawled: crawl.pagesCrawled,
				pages_total: crawl.pagesCrawled,
				crawl_completed: crawl.completed,
				pages_blocked: blockedPages,
				pages_rate_limited: rateLimitedPages,
				run_lighthouse: config.lighthouseStrategy !== "none"
			}
		});
		await AuditProgressKV.clear(auditId);
		await getAuditScratchpad(auditId).destroy();
	});
}
/**
* The two finalize checks that need link edges run as SQL inside the
* audit's scratchpad DO; map their rows onto DetectedIssue.
*/
async function runScratchpadLinkChecks(auditId, startUrl, crawl) {
	const { brokenLinks, orphanPages } = await getAuditScratchpad(auditId).runFinalizeChecks({
		startUrl: normalizeUrl(startUrl) ?? startUrl,
		crawlCompleted: crawl.completed
	});
	return [...brokenLinks.map((row) => ({
		issueType: "broken-internal-link",
		pageId: row.sourcePageId,
		pageUrl: row.sourceUrl,
		dedupeKey: row.targetUrl,
		details: {
			targetUrl: row.targetUrl,
			targetStatus: row.targetStatus
		}
	})), ...orphanPages.map((row) => ({
		issueType: "orphan-page",
		pageId: row.pageId,
		pageUrl: row.url
	}))];
}
//#endregion
//#region src/server/workflows/siteAuditStart.ts
/**
* The audit workflow's first step. Anchors the audit to the site's real
* origin: a start domain that 301s elsewhere (\u2026net -> \u2026com, apex -> www)
* would otherwise dead-end after one page at the same-origin crawl boundary.
*/
async function resolveAuditStart(input) {
	const probe = await resolveStartUrlRedirects(input.startUrl, await CrawlerCredentialService.openCrawlerAccess(input.access));
	const startUrl = probe.url;
	const startHost = new URL(startUrl).hostname;
	let access = input.access ?? null;
	let crawlerCredentialId = input.config.crawlerCredentialId;
	if (startHost !== new URL(input.startUrl).hostname) {
		const credential = await CrawlerCredentialService.resolveCrawlerAccess(input.organizationId, input.projectId, startHost);
		access = credential?.sealed ?? null;
		crawlerCredentialId = credential?.id;
	}
	const config = {
		...input.config,
		sitePlatform: access || probe.poweredBy?.toLowerCase().includes("shopify") || await isShopifyHost(startHost) ? "shopify" : void 0,
		crawlerCredentialId
	};
	await AuditRepository.updateAuditStart(input.auditId, startUrl, config);
	return {
		startUrl,
		config,
		access
	};
}
//#endregion
//#region src/server/workflows/SiteAuditWorkflow.ts
/**
* Cloudflare Workflow for site audit crawling.
*
* Each step is durable - if a step fails, it retries without redoing
* completed steps.
*/
var SiteAuditWorkflow = class extends WorkflowEntrypoint {
	async run(event, step) {
		return withPgClient(() => this.runScoped(event, yieldingStep(step)));
	}
	async runScoped(event, step) {
		const { auditId, billingCustomer, projectId } = event.payload;
		const renderUsage = {
			cloudflareAttempts: 0,
			contextCredits: 0
		};
		try {
			await pgStep(step, "validate-context", DB_STEP, async () => {
				const audit = await AuditRepository.getAuditForWorkflow(auditId, event.instanceId);
				if (!audit) throw new Error("Audit workflow context mismatch");
				if (audit.projectId !== projectId) throw new Error("Audit workflow project mismatch");
			});
			const { startUrl, config, access } = await pgStep(step, "resolve-start-url", START_URL_STEP, () => resolveAuditStart({
				auditId,
				organizationId: billingCustomer.organizationId,
				projectId,
				startUrl: event.payload.startUrl,
				config: event.payload.config,
				access: event.payload.access
			}));
			await runAuditPhases(step, {
				auditId,
				workflowInstanceId: event.instanceId,
				billingCustomer,
				projectId,
				startUrl,
				config,
				access: await CrawlerCredentialService.openCrawlerAccess(access),
				renderUsage,
				renderHold: renderHoldFor(event)
			});
		} catch (error) {
			console.error(`Audit ${auditId} failed: ${describeError(error)}`, error);
			const isDeployReset = error instanceof Error && error.message.includes("Durable Object reset because its code was updated");
			const errorInfo = classifyAuditError(error);
			await pgStep(step, "mark-failed", DB_STEP, async () => {
				const runningAudit = await AuditRepository.getAuditForWorkflow(auditId, event.instanceId);
				if (runningAudit?.status !== "running") return;
				await AuditRepository.failAudit(auditId, event.instanceId, {
					...errorInfo,
					failedPhase: runningAudit?.currentPhase ?? null
				});
				if (!isDeployReset) await captureServerError(error, {
					source: "site_audit_workflow",
					audit_id: auditId,
					organization_id: billingCustomer.organizationId,
					project_id: projectId
				}, billingCustomer.userId);
				await captureServerEvent({
					distinctId: billingCustomer.userId,
					event: "site_audit:complete",
					organizationId: billingCustomer.organizationId,
					properties: {
						project_id: projectId,
						status: "failed",
						error_code: errorInfo.errorCode,
						failed_phase: runningAudit?.currentPhase,
						pages_crawled: runningAudit?.pagesCrawled,
						pages_total: runningAudit?.pagesTotal,
						run_lighthouse: event.payload.config.lighthouseStrategy !== "none"
					}
				});
			});
			throw error;
		} finally {
			const locks = event.payload.renderLocks ?? [];
			if (locks.length > 0) await pgStep(step, "settle-render-credits", SETTLE_RENDERING_STEP, () => settleRenderingLocks({
				customer: billingCustomer,
				auditId,
				locks,
				usage: renderUsage
			}));
		}
	}
};
function renderHoldFor(event) {
	const locks = event.payload.renderLocks ?? [];
	if (locks.length === 0) return void 0;
	return {
		deadlineAt: event.timestamp.getTime() + 792e5,
		credits: locks.reduce((sum, lock) => sum + lock.estimatedCredits, 0)
	};
}
//#endregion
//#region src/audit-worker.ts
var AuditEngine = class extends WorkerEntrypoint {
	fetch() {
		return new Response("Not found", { status: 404 });
	}
	/** Wipe an audit's crawl scratch state (storage + alarm). Idempotent. */
	async destroyScratchpad(auditId) {
		await getAuditScratchpad(auditId).destroy();
	}
};
//#endregion
//#region \0virtual:cloudflare/worker-entry
var worker_entry_default = AuditEngine ?? {};
//#endregion
export { AuditScratchpad, SiteAuditWorkflow, worker_entry_default as default };
