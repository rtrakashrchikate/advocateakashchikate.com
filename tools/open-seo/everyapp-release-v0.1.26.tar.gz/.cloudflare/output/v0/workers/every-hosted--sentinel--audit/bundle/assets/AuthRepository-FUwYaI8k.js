import { F as and, H as ne, I as eq, K as sql, L as exists, M as aliasedTable, N as asc, P as desc, R as gt, U as notExists, V as lt, W as or, t as db, z as inArray } from "./db-DUti_knk.js";
import { c as invitation, f as user, l as member, n as runBatch, p as userSignupCampaigns, u as organization } from "./runBatch-DHGTu4fq.js";
//#region src/server/auth/repositories/AuthRepository.ts
async function upsertDelegatedOrganization(input) {
	await db.insert(organization).values({
		id: input.id,
		name: input.name,
		slug: input.slug,
		logo: null,
		createdAt: /* @__PURE__ */ new Date(),
		metadata: null
	}).onConflictDoUpdate({
		target: organization.id,
		set: {
			name: input.name,
			slug: input.slug
		}
	});
}
async function findFirstOrganizationIdForUser(userId) {
	const [existingMembership] = await db.select({ organizationId: member.organizationId }).from(member).where(eq(member.userId, userId)).orderBy(asc(member.createdAt)).limit(1);
	return existingMembership?.organizationId ?? null;
}
async function findFirstFoundedOrganizationIdForUser(userId) {
	const earlierMember = aliasedTable(member, "earlier_member");
	const [foundedMembership] = await db.select({ organizationId: member.organizationId }).from(member).where(and(eq(member.userId, userId), eq(member.role, "owner"), notExists(db.select({ id: earlierMember.id }).from(earlierMember).where(and(eq(earlierMember.organizationId, member.organizationId), lt(earlierMember.createdAt, member.createdAt)))))).orderBy(asc(member.createdAt)).limit(1);
	return foundedMembership?.organizationId ?? null;
}
async function getHostedUser(userId) {
	return db.query.user.findFirst({
		columns: {
			id: true,
			email: true,
			name: true
		},
		where: eq(user.id, userId)
	});
}
async function getOrganizationOwner(organizationId) {
	const [owner] = await db.select({
		id: user.id,
		email: user.email
	}).from(member).innerJoin(user, eq(user.id, member.userId)).where(and(eq(member.organizationId, organizationId), eq(member.role, "owner"))).limit(1);
	return owner ?? null;
}
/** Names for a set of user ids in one query; missing ids are simply absent. */
async function getHostedUserNames(userIds) {
	if (userIds.length === 0) return [];
	return db.select({
		id: user.id,
		name: user.name
	}).from(user).where(inArray(user.id, userIds));
}
async function getMembership(userId, organizationId) {
	const [membership] = await db.select({ role: member.role }).from(member).where(and(eq(member.userId, userId), eq(member.organizationId, organizationId))).limit(1);
	return membership ?? null;
}
async function getMemberInOrganization(memberId, organizationId) {
	const [membership] = await db.select({
		userId: member.userId,
		role: member.role
	}).from(member).where(and(eq(member.id, memberId), eq(member.organizationId, organizationId))).limit(1);
	return membership ?? null;
}
async function transferOwnership(input) {
	const currentOwner = aliasedTable(member, "current_owner");
	const newOwner = aliasedTable(member, "new_owner");
	await runBatch((tx) => [
		tx.update(member).set({ role: sql`${member.role}` }).where(and(eq(member.organizationId, input.organizationId), or(eq(member.userId, input.ownerUserId), eq(member.id, input.newOwnerMemberId)))),
		tx.update(member).set({ role: "owner" }).where(and(eq(member.id, input.newOwnerMemberId), eq(member.organizationId, input.organizationId), exists(tx.select({ id: currentOwner.id }).from(currentOwner).where(and(eq(currentOwner.organizationId, input.organizationId), eq(currentOwner.userId, input.ownerUserId), eq(currentOwner.role, "owner")))))),
		tx.update(member).set({ role: "admin" }).where(and(eq(member.organizationId, input.organizationId), eq(member.userId, input.ownerUserId), eq(member.role, "owner"), exists(tx.select({ id: newOwner.id }).from(newOwner).where(and(eq(newOwner.id, input.newOwnerMemberId), eq(newOwner.organizationId, input.organizationId), ne(newOwner.userId, input.ownerUserId), eq(newOwner.role, "owner"))))))
	]);
}
async function findNewestMembershipForUser(userId) {
	const [membership] = await db.select({
		organizationId: member.organizationId,
		role: member.role
	}).from(member).where(eq(member.userId, userId)).orderBy(desc(member.createdAt)).limit(1);
	return membership ?? null;
}
async function listMembershipsForUser(userId) {
	return db.select({
		organizationId: member.organizationId,
		organizationName: organization.name,
		role: member.role
	}).from(member).innerJoin(organization, eq(member.organizationId, organization.id)).where(eq(member.userId, userId)).orderBy(asc(member.createdAt));
}
async function hasPendingInvitationForEmail(email) {
	const [pending] = await db.select({ id: invitation.id }).from(invitation).where(and(eq(sql`lower(${invitation.email})`, email.trim().toLowerCase()), eq(invitation.status, "pending"), gt(invitation.expiresAt, /* @__PURE__ */ new Date()))).limit(1);
	return pending !== void 0;
}
async function hasAnyUser() {
	const [first] = await db.select({ id: user.id }).from(user).limit(1);
	return first !== void 0;
}
async function getLastActiveOrganizationId(userId) {
	return (await db.query.user.findFirst({
		columns: { lastActiveOrganizationId: true },
		where: eq(user.id, userId)
	}))?.lastActiveOrganizationId ?? null;
}
async function setLastActiveOrganization(userId, organizationId) {
	await db.update(user).set({ lastActiveOrganizationId: organizationId }).where(eq(user.id, userId));
}
async function isAnalyticsOptedOut(userId) {
	const [record] = await db.select({ analyticsOptedOut: user.analyticsOptedOut }).from(user).where(eq(user.id, userId)).limit(1);
	return record?.analyticsOptedOut === true;
}
async function saveSignupCampaign(userId, campaign) {
	await db.insert(userSignupCampaigns).values({
		userId,
		...campaign
	});
}
async function setTermsAcceptance(userId, version, acceptedAt) {
	await db.update(user).set({
		termsAcceptedVersion: version,
		termsAcceptedAt: acceptedAt
	}).where(eq(user.id, userId));
}
async function setProductUpdatesOptIn(userId, optIn, changedAt) {
	await db.update(user).set({
		productUpdatesOptIn: optIn,
		productUpdatesChangedAt: changedAt
	}).where(eq(user.id, userId));
}
var AuthRepository = {
	upsertDelegatedOrganization,
	findFirstOrganizationIdForUser,
	findFirstFoundedOrganizationIdForUser,
	findNewestMembershipForUser,
	getMembership,
	getMemberInOrganization,
	transferOwnership,
	listMembershipsForUser,
	getLastActiveOrganizationId,
	setLastActiveOrganization,
	setTermsAcceptance,
	setProductUpdatesOptIn,
	getHostedUser,
	getHostedUserNames,
	getOrganizationOwner,
	hasPendingInvitationForEmail,
	hasAnyUser,
	isAnalyticsOptedOut,
	saveSignupCampaign
};
//#endregion
export { AuthRepository };
