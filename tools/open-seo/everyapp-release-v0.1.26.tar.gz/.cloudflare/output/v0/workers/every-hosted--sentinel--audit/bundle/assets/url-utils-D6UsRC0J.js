//#region src/server/lib/audit/url-utils.ts
/**
* URL normalization and utility functions for the site audit crawler.
*/
/**
* Click and campaign tracking params. They never change the document and every
* variant canonicalises to the clean URL, so keeping them makes the crawler
* fetch the same page again and spend its page budget on duplicates. Shopify's
* predictive search appends _pos/_sid/_ss/_kx to result links; srsltid is
* Google Merchant Center auto-tagging on product URLs.
*/
var TRACKING_PARAMS = /* @__PURE__ */ new Set([
	"_pos",
	"_sid",
	"_ss",
	"_kx",
	"srsltid",
	"fbclid",
	"gclid",
	"gbraid",
	"wbraid",
	"dclid",
	"msclkid",
	"mc_cid",
	"mc_eid"
]);
/**
* Normalize a URL for deduplication:
* - Resolve relative URLs against a base
* - Strip fragments (#...)
* - Sort query parameters
* - Lowercase the hostname
* - Drop click and campaign tracking params (see TRACKING_PARAMS), unless
*   `keepTrackingParams` is set
* - Preserve trailing slashes. A trailing slash is the canonical form on most
*   CMS platforms (WordPress etc.), which 301-redirect the non-slash version to
*   it. Stripping it here would rewrite the canonical URL into its own redirect
*   source, so the crawler would follow /path -> /path/ and strip back to /path
*   forever \u2014 a 508 loop. Keeping /path and /path/ distinct lets the redirect
*   resolve normally.
*/
function normalizeUrl(url, base, { keepTrackingParams = false } = {}) {
	try {
		const parsed = new URL(url, base);
		if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return null;
		parsed.hash = "";
		if (!keepTrackingParams) {
			for (const key of Array.from(parsed.searchParams.keys())) if (TRACKING_PARAMS.has(key) || key.startsWith("utm_")) parsed.searchParams.delete(key);
		}
		parsed.searchParams.sort();
		parsed.hostname = parsed.hostname.toLowerCase();
		return parsed.toString();
	} catch {
		return null;
	}
}
/**
* A canonical key for URL equality checks that should survive the common
* redirect patterns a site uses to reach its canonical form:
*   - trailing-slash redirects   (/services -> /services/)
*   - www <-> non-www            (www.example.com -> example.com)
*   - http -> https upgrades
*
* Forces https, drops a leading "www.", lowercases the hostname, sorts query
* params, and strips the fragment. Trailing slashes are intentionally left
* intact so two genuinely different paths never collapse together; this key is
* only for "is this effectively the same page as the start URL" comparisons
* (e.g. picking the homepage for the Lighthouse sample), not for crawl dedup.
*/
function canonicalUrlKey(url) {
	try {
		const parsed = new URL(url);
		parsed.protocol = "https:";
		parsed.hostname = parsed.hostname.toLowerCase().replace(/^www\./, "");
		parsed.hash = "";
		parsed.searchParams.sort();
		return parsed.toString();
	} catch {
		return url.toLowerCase();
	}
}
function getEffectivePort(parsed) {
	if (parsed.port) return parsed.port;
	return parsed.protocol === "https:" ? "443" : "80";
}
function areEquivalentHostnames(a, b) {
	const hostA = a.toLowerCase();
	const hostB = b.toLowerCase();
	if (hostA === hostB) return true;
	return hostA === `www.${hostB}` || hostB === `www.${hostA}`;
}
/**
* Check if a URL belongs to the same crawl boundary as the crawl target.
*
* Rules:
* - Hostname must match exactly.
* - Same protocol/port is always allowed.
* - http -> https upgrade on default ports is allowed.
*/
function isSameOrigin(url, origin) {
	try {
		const parsedUrl = new URL(url);
		const parsedOrigin = new URL(origin);
		if (!areEquivalentHostnames(parsedUrl.hostname, parsedOrigin.hostname)) return false;
		const originProtocol = parsedOrigin.protocol.toLowerCase();
		const urlProtocol = parsedUrl.protocol.toLowerCase();
		const originPort = getEffectivePort(parsedOrigin);
		const urlPort = getEffectivePort(parsedUrl);
		if (originProtocol === urlProtocol) return originPort === urlPort;
		return originProtocol === "http:" && urlProtocol === "https:" && originPort === "80" && urlPort === "443";
	} catch {
		return false;
	}
}
/**
* Detect a URL template pattern by replacing path segments that look like
* dynamic values (IDs, slugs, dates) with `:param`.
*
* Examples:
*   /blog/my-great-post      \u2192 /blog/:slug
*   /products/12345           \u2192 /products/:id
*   /users/john-doe/settings  \u2192 /users/:slug/settings
*/
function detectUrlTemplate(pathname) {
	return "/" + pathname.split("/").filter(Boolean).map((segment) => {
		if (/^\d+$/.test(segment)) return ":id";
		if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(segment)) return ":uuid";
		if (/^\d{4}-\d{2}-\d{2}$/.test(segment)) return ":date";
		if (segment.includes("-") && segment.split("-").length > 2) return ":slug";
		return segment;
	}).join("/");
}
/**
* Extract the origin (protocol + hostname + port) from a URL string.
*/
function getOrigin(url) {
	return new URL(url).origin;
}
/** Files a crawl can follow a link to but cannot audit as a page. */
var NON_DOCUMENT_EXTENSIONS = /\.(?:jpe?g|png|gif|webp|avif|svg|ico|bmp|tiff?|heic|woff2?|ttf|otf|eot|mp4|webm|m4v|mov|avi|mp3|wav|ogg|m4a|flac|css|js|mjs|json|xml|txt|map|zip|gz|tgz|tar|rar|7z|dmg|exe)$/i;
/**
* Shopify routes that are never storefront pages and that its edge refuses to
* crawlers, with an optional locale prefix (`/en/`, `/pt-br/`). The cart,
* checkout and account routes need no entry: Shopify's robots.txt disallows
* them.
*/
var SHOPIFY_NON_PAGE_PATHS = /^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(?:customer_authentication\/|customer_identity\/|discount\/|password(?:\/|$))/i;
/**
* Whether a same-origin URL is worth a page fetch. Links to images, fonts,
* scripts and other files pass the SSRF check but are not pages: Shopify
* themes link every gallery photo on the storefront origin, and one store's
* audit spent 1,986 of its 2,608 fetches on them. Unknown extensions pass.
* The trade: a broken link to such a file is no longer reported.
*
* Cloudflare's reserved `/cdn-cgi/` paths are skipped too. Its email
* obfuscation rewrites every mailto link to `/cdn-cgi/l/email-protection`,
* which answers crawlers with a 404, so a site with an email in its footer
* got one false broken link per page.
*/
function isAuditablePageUrl(url, sitePlatform) {
	let parsed;
	try {
		parsed = new URL(url);
	} catch {
		return false;
	}
	if (NON_DOCUMENT_EXTENSIONS.test(parsed.pathname)) return false;
	if (parsed.pathname.startsWith("/cdn-cgi/")) return false;
	return !(sitePlatform === "shopify" && SHOPIFY_NON_PAGE_PATHS.test(parsed.pathname));
}
//#endregion
export { isSameOrigin as a, isAuditablePageUrl as i, detectUrlTemplate as n, normalizeUrl as o, getOrigin as r, canonicalUrlKey as t };
